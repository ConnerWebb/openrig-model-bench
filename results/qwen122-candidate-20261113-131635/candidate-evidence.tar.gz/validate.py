import sys,json,threading,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'runtime-source'))
import main as m
from preserve import check
results=[]
try:
 m.init_services();threading.Thread(target=m.monitor,daemon=True).start();m.atomic(m.O/'models.json',m.model_config('candidate-bootstrap',[('q122',45)]))
 for task,n in [('py-csv',1),('cpp-buffer',1),('py-csv',3)]:
  models={'lead':'q122','developer':'q122','reviewer':'q122'} if n==3 else {'developer':'q122'}
  r=m.execute('candidate-'+task+'-n'+str(n),task,models,45,n,0,'candidate-validation');results.append(r)
 assert check('candidate-after-tests')['matches_before']
 m.atomic(m.O/'VALIDATION.json',{'passed':all(r['complete'] for r in results),'results':[{'id':r['id'],'passed':r['complete'],'seconds':r['seconds']} for r in results],'production_preserved':True})
finally:
 subprocess.run(['systemctl','--user','stop',m.INFER_UNIT],capture_output=True)
 try:m.native('daemon','stop',timeout=90)
 except Exception:pass
