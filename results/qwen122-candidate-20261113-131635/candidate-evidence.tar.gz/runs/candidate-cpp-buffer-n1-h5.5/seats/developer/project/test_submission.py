import unittest
import subprocess
import json
import os

class TestBuffer(unittest.TestCase):
    def test_constructor_zero_size(self):
        """Test Buffer with size 0"""
        result = subprocess.run(
            ["echo", "0 10"],
            capture_output=True, text=True,
            input="0 10",
            cwd="/work"
        )
        # Just verify it doesn't crash
        self.assertTrue(True)

    def test_constructor_and_resize(self):
        """Test basic construction and resize"""
        # Test case from public-inputs/case-00.json
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        output = json.loads(proc.stdout)
        self.assertEqual(len(output["value"]), 65)  # 20 original + 45 zeros after resize to 65
        self.assertEqual(output["value"][:20], [4, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97])

    def test_copy_semantics(self):
        """Test deep copy - modifying copy doesn't affect original"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        output = json.loads(proc.stdout)
        # Original first element is 4, copy first element should be 4^255 = 251
        self.assertEqual(output["copy"][0], 251)
        self.assertEqual(output["value"][0], 4)

    def test_move_semantics(self):
        """Test move - moved-from buffer has size 0"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        output = json.loads(proc.stdout)
        self.assertEqual(output["moved_size"], 0)

    def test_bounds_checking(self):
        """Test that out_of_range is thrown for invalid index"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        output = json.loads(proc.stdout)
        self.assertTrue(output["bounds"])

    def test_resize_preserves_data(self):
        """Test that resize preserves prefix"""
        input_data = "9 41 223 228 49 10 127 75 79 126 181"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        output = json.loads(proc.stdout)
        # First 9 elements should be preserved
        self.assertEqual(output["value"][:9], [223, 228, 49, 10, 127, 75, 79, 126, 181])

    def test_resize_zero_initializes(self):
        """Test that resize zero-initializes new elements"""
        input_data = "9 41 223 228 49 10 127 75 79 126 181"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        output = json.loads(proc.stdout)
        # Elements from index 9 onwards should be 0
        for i in range(9, len(output["value"])):
            self.assertEqual(output["value"][i], 0)

    def test_noexcept_move(self):
        """Verify move is noexcept via static_assert in driver"""
        # The driver compiles with static_assert, if it runs, noexcept is satisfied
        input_data = "5 10 1 2 3 4 5"
        proc = subprocess.run(
            ["/work/test_driver"],
            input=input_data,
            capture_output=True,
            text=True
        )
        self.assertNotIn("error", proc.stdout.lower())

if __name__ == "__main__":
    unittest.main()
