# Buffer Library

A C++20 buffer implementation with RAII, deep copy semantics, and noexcept move operations.

## Features

- **RAII**: Automatic resource management with proper destructor
- **Deep Copy**: Copy constructor and assignment operator perform deep copies
- **Noexcept Move**: Move constructor and assignment are noexcept
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for invalid indices
- **Resize**: Preserves existing data and zero-initializes new elements
- **Reusable Moved-From**: Moved-from buffers have size 0 and can be reused

## API

```cpp
class Buffer {
public:
    Buffer(std::size_t n = 0);                    // Construct with n zero-initialized bytes
    ~Buffer();                                     // Destructor (RAII)
    
    Buffer(const Buffer& other);                   // Deep copy constructor
    Buffer& operator=(const Buffer& other);        // Deep copy assignment
    
    Buffer(Buffer&& other) noexcept;               // Noexcept move constructor
    Buffer& operator=(Buffer&& other) noexcept;    // Noexcept move assignment
    
    std::size_t size() const noexcept;             // Return buffer size
    
    std::uint8_t& operator[](std::size_t i);       // Mutable access with bounds check
    const std::uint8_t& operator[](std::size_t i) const;  // Const access with bounds check
    
    void resize(std::size_t k);                    // Resize, preserving prefix, zero-init new
};
```

## Usage Example

```cpp
Buffer a(10);           // Create buffer of 10 zero-initialized bytes
a[0] = 42;              // Set first element
a.resize(20);           // Resize to 20, preserving first 10, zero-init rest

Buffer b = a;           // Deep copy - b is independent of a
Buffer c = std::move(a); // Move - c takes ownership, a has size 0
```

## Testing

Run tests with:
```bash
python3 test_submission.py
```

Or run the public driver:
```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_driver PUBLIC_DRIVER.cpp
echo "20 65 4 135 ..." | ./test_driver
```

## Requirements

- C++20 compiler (Clang 22 tested)
- Python 3.14+ for tests (stdlib only, no pytest)
