"""
CSV aggregation module.

Provides aggregate(path: str) -> dict[str, str] function that reads a UTF-8 CSV
file as a stream, validates and parses records, accumulates amounts by category
using exact decimal arithmetic, and returns sorted results.
"""

import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to total amounts (formatted as strings
        with exactly two decimal places), sorted by category key.
        
    Raises:
        ValueError: If the CSV is malformed (wrong header, empty category,
                   invalid amount format, extra fields, unclosed quotes, etc.)
    """
    # Pattern for valid amount: optional +, 1-12 digits, optional decimal with 1-2 digits
    # Must be non-negative, finite, no exponent
    amount_pattern = re.compile(r'^\+?\d{1,12}(\.\d{1,2})?$')
    
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        # Header must be exactly ['category', 'amount']
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly 'category,amount'")
        
        for row in reader:
            # Skip completely blank records (empty or all whitespace)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category cannot be empty")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse and accumulate using Decimal
            try:
                amount = Decimal(amount_str)
                # Check for non-negative (Decimal handles this, but be explicit)
                if amount < 0:
                    raise ValueError(f"Amount must be non-negative: {amount_str}")
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted by category, formatted with exactly 2 decimal places
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}
