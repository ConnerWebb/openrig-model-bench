# CSV Aggregation Module

A Python module for streaming CSV aggregation with exact decimal arithmetic.

## API

### `aggregate(path: str) -> dict[str, str]`

Reads a UTF-8 CSV file as a stream and aggregates amounts by category.

**Parameters:**
- `path`: Path to the CSV file (UTF-8 encoded)

**Returns:**
- A dictionary mapping category names to total amounts, formatted as strings with exactly two decimal places. The dictionary is sorted by category key.

**Raises:**
- `ValueError`: If the CSV is malformed

## CSV Format Requirements

1. **Header**: Must be exactly `category,amount`
2. **Records**: Each non-blank record must have exactly two fields
3. **Category**: 
   - Whitespace is stripped
   - Cannot be empty after stripping
   - Can contain any characters including commas, newlines (when quoted), and Unicode
4. **Amount**:
   - Whitespace is stripped
   - Optional leading `+` sign
   - 1-12 decimal digits before the decimal point
   - Optional decimal point followed by 1-2 digits
   - Must be non-negative
   - No exponent notation (e.g., `1e2` is invalid)
   - No special values like `NaN` or `Infinity`

## Features

- **Streaming parsing**: Uses Python's `csv` module for memory-efficient parsing
- **Exact arithmetic**: Uses `decimal.Decimal` for precise accumulation
- **Quoted fields**: Handles CSV quoted fields with embedded commas and newlines
- **Unicode support**: Full UTF-8 support for category names
- **Strict validation**: Rejects malformed input with clear errors

## Usage

```python
from solution import aggregate

result = aggregate('input.csv')
print(result)
# Output: {'food': '150.75', 'rent': '200.25'}
```

## Testing

Run the test suite:

```bash
python -m unittest test_solution.py
```

Or use the project's test runner:

```bash
run_tests
```

## Implementation Details

- Uses Python's built-in `csv` module for proper CSV parsing (handles quoted fields, embedded commas/newlines)
- Uses `decimal.Decimal` for exact arithmetic to avoid floating-point errors
- Validates amount format using regex before parsing
- Sorts output by category key using Python's default string sorting
