"""
Unit tests for solution.py aggregate function.
"""

import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregateValidCases(unittest.TestCase):
    """Test valid CSV inputs."""
    
    def test_simple_csv(self):
        """Test basic CSV with simple categories and amounts."""
        csv_content = "category,amount\nfood,100.50\nrent,200.25\nfood,50.25\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '150.75', 'rent': '200.25'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas."""
        csv_content = 'category,amount\n"a,b",100.00\n"c,d",200.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'a,b': '100.00', 'c,d': '200.00'})
    
    def test_quoted_fields_with_embedded_newlines(self):
        """Test quoted fields containing newlines."""
        csv_content = 'category,amount\n"line1\nline2",100.00\n"line1\nline2",50.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'line1\nline2': '150.00'})
    
    def test_quoted_fields_with_embedded_quotes(self):
        """Test quoted fields containing escaped quotes (double quotes)."""
        csv_content = 'category,amount\n"x""quote",100.00\n"x""quote",50.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'x"quote': '150.00'})
    
    def test_unicode_categories(self):
        """Test Unicode category names."""
        # Using ASCII comma as field separator, Japanese characters in category
        # Construct CSV with explicit ASCII commas to avoid full-width comma issues
        cat_jp = '日本'
        cat_emoji = 'émoji'
        csv_lines = [
            'category,amount',
            cat_jp + ',100.00',
            cat_jp + ',50.00',
            cat_emoji + ',25.50',
        ]
        csv_content = '\n'.join(csv_lines) + '\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {cat_emoji: '25.50', cat_jp: '150.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from categories and amounts."""
        csv_content = 'category,amount\n  food  ,  100.50  \n  rent  ,  200.25  \n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '100.50', 'rent': '200.25'})
    
    def test_optional_plus_sign(self):
        """Test amounts with optional plus sign."""
        csv_content = 'category,amount\nfood,+100.50\nrent,+200\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '100.50', 'rent': '200.00'})
    
    def test_integer_amounts(self):
        """Test integer amounts (no decimal point)."""
        csv_content = 'category,amount\nfood,100\nrent,200\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
    
    def test_one_decimal_digit(self):
        """Test amounts with one decimal digit."""
        csv_content = 'category,amount\nfood,100.5\nrent,200.0\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '100.50', 'rent': '200.00'})
    
    def test_two_decimal_digits(self):
        """Test amounts with two decimal digits."""
        csv_content = 'category,amount\nfood,100.50\nrent,200.25\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '100.50', 'rent': '200.25'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        csv_content = 'category,amount\nfood,100.00\n\nrent,200.00\n\n\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
    
    def test_sorted_output(self):
        """Test that output is sorted by category key."""
        csv_content = 'category,amount\nzebra,100.00\napple,200.00\nmango,50.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_max_digits_before_decimal(self):
        """Test amount with maximum 12 digits before decimal."""
        csv_content = 'category,amount\nfood,123456789012.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {'food': '123456789012.00'})


class TestAggregateInvalidCases(unittest.TestCase):
    """Test invalid CSV inputs that should raise ValueError."""
    
    def test_wrong_header(self):
        """Test wrong header raises ValueError."""
        csv_content = 'wrong,amount\nx,1\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_extra_fields(self):
        """Test record with extra fields raises ValueError."""
        csv_content = 'category,amount\nx,1,2\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test empty category raises ValueError."""
        csv_content = 'category,amount\n,100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_nan_amount(self):
        """Test NaN amount raises ValueError."""
        csv_content = 'category,amount\nx,NaN\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote(self):
        """Test unclosed quote raises ValueError."""
        csv_content = 'category,amount\n"x,100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_exponent_notation(self):
        """Test exponent notation raises ValueError."""
        csv_content = 'category,amount\nx,1e2\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_negative_amount(self):
        """Test negative amount raises ValueError."""
        csv_content = 'category,amount\nx,-100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_three_decimal_digits(self):
        """Test amount with three decimal digits raises ValueError."""
        csv_content = 'category,amount\nx,100.001\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_thirteen_digits_before_decimal(self):
        """Test amount with 13 digits before decimal raises ValueError."""
        csv_content = 'category,amount\nx,1234567890123.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file(self):
        """Test empty file raises ValueError."""
        csv_content = ''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only(self):
        """Test file with only header is valid (returns empty dict)."""
        csv_content = 'category,amount\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
