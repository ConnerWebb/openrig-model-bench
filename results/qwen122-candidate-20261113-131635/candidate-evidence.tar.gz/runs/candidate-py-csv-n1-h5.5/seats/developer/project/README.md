# CSV Aggregation Solution

## Overview

This module provides a `aggregate` function that reads a UTF-8 CSV file and computes totals by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to totals formatted with exactly
        two decimal places, sorted by category name.
        
    Raises:
        ValueError: If the CSV is malformed (wrong header, invalid amounts,
                   empty categories, wrong field counts, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each record must have exactly two fields
- **Blank records**: Completely blank lines are ignored
- **Category**: Must not be empty after whitespace stripping
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits before the decimal point
  - Optional decimal point followed by 1-2 decimal digits
  - Nonnegative, finite, no exponent notation

## Features

- **Streaming**: Reads CSV as a stream, not loading the entire file into memory
- **Exact arithmetic**: Uses Python's `Decimal` for precise accumulation
- **Unicode support**: Handles UTF-8 encoded category names
- **Quoted fields**: Properly handles CSV quoting (commas, newlines, escaped quotes)
- **Strict validation**: Rejects any malformed input with `ValueError`

## Example

```python
from solution import aggregate

result = aggregate('data.csv')
# Returns: {'food': '1234.56', 'rent': '2000.00', ...}
```

## Testing

Run the test suite:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
