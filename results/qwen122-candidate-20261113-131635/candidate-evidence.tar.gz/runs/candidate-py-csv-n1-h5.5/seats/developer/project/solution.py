import csv
import re
from decimal import Decimal, InvalidOperation
from collections import defaultdict


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic.
    Return category keys sorted, totals formatted with exactly two decimal places.
    CSV quoted commas and embedded newlines are valid.
    """
    totals = defaultdict(Decimal)
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly 'category,amount'")
        
        # Amount regex: optional +, 1-12 digits, optional decimal point with 1-2 digits
        # Pattern: ^\+?[0-9]{1,12}(\.[0-9]{1,2})?$
        amount_pattern = re.compile(r'^\+?[0-9]{1,12}(\.[0-9]{1,2})?$')
        
        for row in reader:
            # Skip completely blank records (empty list or all empty strings)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every other record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse amount using Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check for nonnegative (amount >= 0)
            if amount < 0:
                raise ValueError(f"Amount must be nonnegative: {amount_str}")
            
            totals[category] += amount
    
    # Format results with exactly two decimal places, sorted by key
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
