import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        csv_content = "category,amount\nfood,10.50\nrent,20.00\nfood,5.50\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '16.00', 'rent': '20.00'})
    
    def test_quoted_categories_with_commas(self):
        """Test categories containing commas"""
        csv_content = 'category,amount\n"a,b",100.00\n"a,b",50.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'a,b': '150.00'})
    
    def test_quoted_categories_with_quotes(self):
        """Test categories containing quotes (escaped as double quotes)"""
        csv_content = 'category,amount\n"x""quote",100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_embedded_newlines(self):
        """Test categories with embedded newlines"""
        csv_content = 'category,amount\n"two\nlines",100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'two\nlines': '100.00'})
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        # Quote the Japanese text since it may contain full-width comma
        csv_content = 'category,amount\n"日本",100.00\n"日本",50.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'日本': '150.00'})
    
    def test_unicode_categories_with_comma(self):
        """Test unicode category names containing full-width comma"""
        # Use quoted field since full-width comma is not ASCII comma
        csv_content = 'category,amount\n"日本",100.00\n"日本",50.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'日本': '150.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from categories and amounts"""
        csv_content = "category,amount\n  food  ,  10.50  \n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '10.50'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        csv_content = "category,amount\nfood,+10.50\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '10.50'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored"""
        csv_content = "category,amount\nfood,10.00\n\nrent,20.00\n\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})
    
    def test_sorted_keys(self):
        """Test that result keys are sorted"""
        csv_content = "category,amount\nzebra,1.00\napple,2.00\nmango,3.00\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_two_decimal_places(self):
        """Test that amounts are formatted with exactly two decimal places"""
        csv_content = "category,amount\nfood,10\nfood,5.5\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '15.50'})
    
    def test_invalid_header_wrong_name(self):
        """Test that wrong header name raises ValueError"""
        csv_content = "wrong,amount\nx,1\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_wrong_field_count(self):
        """Test that wrong number of header fields raises ValueError"""
        csv_content = "category,amount,extra\nx,1,2\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_field_count(self):
        """Test that records with wrong field count raise ValueError"""
        csv_content = "category,amount\nx,1,2\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test that empty category raises ValueError"""
        csv_content = "category,amount\n,1\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test that NaN amount raises ValueError"""
        csv_content = "category,amount\nx,NaN\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote(self):
        """Test that unclosed quote raises ValueError"""
        csv_content = 'category,amount\n"x,1\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_too_many_digits(self):
        """Test that amount with too many digits raises ValueError"""
        csv_content = "category,amount\nx,1234567890123\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_too_many_decimal_places(self):
        """Test that amount with too many decimal places raises ValueError"""
        csv_content = "category,amount\nx,1.234\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file(self):
        """Test that empty file raises ValueError"""
        csv_content = ""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_only_header(self):
        """Test file with only header returns empty dict"""
        csv_content = "category,amount\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
