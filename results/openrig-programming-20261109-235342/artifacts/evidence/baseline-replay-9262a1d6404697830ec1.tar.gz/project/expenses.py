#!/usr/bin/env python3
"""CSV expense summarizer - sum amounts by category with exact Decimal arithmetic."""

import sys
import csv
import io
from decimal import Decimal, InvalidOperation, DecimalException

from decimal import getcontext

# Set precision high enough for typical expense calculations
getcontext().prec = 28


def summarize(csv_text):
    """
    Parse CSV text and return a dict mapping category strings to Decimal totals.
    
    CSV must have 'category' and 'amount' headers. Blank categories become 'Uncategorized'.
    Amounts must have at most two decimal places. Rejects NaN, Infinity, missing/malformed amounts.
    
    Args:
        csv_text: CSV content as string with category,amount headers
        
    Returns:
        dict mapping category strings to Decimal totals
        
    Raises:
        ValueError: on invalid input (missing headers, malformed amounts, etc.)
    """
    lines = csv_text.splitlines()
    if not lines:
        raise ValueError("Empty CSV input")
    
    reader = csv.reader(io.StringIO(csv_text))
    
    # Read header row
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("Missing header row")
    
    # Find category and amount columns
    header_lower = [h.strip().lower() for h in header]
    
    if 'category' not in header_lower:
        raise ValueError("Missing 'category' header")
    if 'amount' not in header_lower:
        raise ValueError("Missing 'amount' header")
    
    category_idx = header_lower.index('category')
    amount_idx = header_lower.index('amount')
    
    totals = {}
    row_num = 1  # Header is row 1
    
    for row in reader:
        row_num += 1
        
        # Skip blank rows (all cells empty or whitespace)
        if not row or all(cell.strip() == '' for cell in row):
            continue
        
        # Get category
        if category_idx >= len(row):
            raise ValueError(f"Row {row_num}: missing category column")
        
        category = row[category_idx].strip()
        if not category:
            category = 'Uncategorized'
        
        # Get and validate amount
        if amount_idx >= len(row):
            raise ValueError(f"Row {row_num}: missing amount column")
        
        amount_str = row[amount_idx].strip()
        
        if not amount_str:
            raise ValueError(f"Row {row_num}: empty amount")
        
        # Validate format: optional sign, digits, optional decimal point with max 2 decimal places
        if not validate_amount_format(amount_str):
            raise ValueError(f"Row {row_num}: amount '{amount_str}' has more than two decimal places")
        
        try:
            amount = Decimal(amount_str)
        except DecimalException:
            raise ValueError(f"Row {row_num}: invalid amount '{amount_str}'")
        
        # Check for NaN and Infinity
        if not amount.is_finite():
            raise ValueError(f"Row {row_num}: non-finite amount '{amount_str}'")
        
        # Add to totals
        if category in totals:
            totals[category] += amount
        else:
            totals[category] = amount
    
    return totals


def validate_amount_format(amount_str):
    """
    Validate that amount string has at most two decimal places.
    
    Accepts optional sign, digits, optional decimal point with up to 2 digits after.
    """
    # Remove leading/trailing whitespace
    amount_str = amount_str.strip()
    
    if not amount_str:
        return False
    
    # Optional sign
    if amount_str[0] in '+-':
        amount_str = amount_str[1:]
    
    if not amount_str:
        return False
    
    # Check for decimal point
    if '.' in amount_str:
        parts = amount_str.split('.')
        if len(parts) != 2:
            return False
        
        integer_part, decimal_part = parts
        
        # Integer part must be digits (can be '0')
        if not integer_part:
            integer_part = '0'
        
        if not integer_part.isdigit():
            return False
        
        # Decimal part must be 1-2 digits
        if len(decimal_part) == 0 or len(decimal_part) > 2:
            return False
        
        if not decimal_part.isdigit():
            return False
    else:
        # Must be all digits
        if not amount_str.isdigit():
            return False
    
    return True


def main():
    """CLI entry point."""
    if len(sys.argv) != 2:
        print("Usage: python3 expenses.py INPUT.csv", file=sys.stderr)
        sys.exit(1)
    
    input_file = sys.argv[1]
    
    try:
        with open(input_file, 'r') as f:
            csv_text = f.read()
        
        result = summarize(csv_text)
        
        # Print results sorted by category using csv writer for proper quoting
        writer = csv.writer(sys.stdout)
        writer.writerow(['category', 'total'])
        for category in sorted(result.keys()):
            # Format with exactly two decimal places
            total = result[category]
            # Round to two decimal places
            total = total.quantize(Decimal('0.01'))
            writer.writerow([category, f"{total:.2f}"])
        
        sys.exit(0)
        
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print(f"Error: File not found: {input_file}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
