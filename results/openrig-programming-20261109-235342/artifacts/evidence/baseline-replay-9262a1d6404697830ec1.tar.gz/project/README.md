# Expenses CSV Summarizer

A Python command-line tool for summarizing expenses from CSV files using exact Decimal arithmetic.

## Requirements

- Python 3.6+
- Standard library only (no external dependencies)

## Usage

```bash
python3 expenses.py INPUT.csv
```

## CSV Format

The input CSV must have `category` and `amount` columns:

```csv
category,amount
Food,10.50
Transport,20.00
Food,5.25
```

### Rules

- **Category**: Whitespace is trimmed. Blank categories become `Uncategorized`.
- **Amount**: Must be a valid decimal number with at most two decimal places.
- **Signed amounts**: Both `+10.00` and `-10.00` are accepted (for refunds).
- **Blank rows**: Entirely blank rows are ignored.

## Output

The tool prints results in CSV format with categories sorted alphabetically:

```csv
category,total
Food,15.75
Transport,20.00
```

## Error Handling

Invalid input produces a concise error message to stderr and exits with a non-zero status:

- Missing headers
- Missing or empty amounts
- Malformed amounts (non-numeric)
- Excess precision (more than two decimal places)
- Non-finite values (NaN, Infinity)

## Testing

Run the test suite:

```bash
python3 test_expenses.py
```

The tests cover:
- Normal category grouping
- Exact decimal arithmetic (0.10 + 0.20 = 0.30)
- Negative refunds
- Blank categories
- Quoted commas in categories
- Empty datasets
- Malformed/missing amounts
- Non-finite values (NaN, Infinity)
- Excess precision
- Missing headers
- CLI success/failure scenarios

## Example

```bash
# Create a sample expenses file
echo 'category,amount
Food,12.50
Food,8.75
Transport,25.00
Food,-2.00' > expenses.csv

# Run the summarizer
python3 expenses.py expenses.csv
```

Output:
```csv
category,total
Food,19.25
Transport,25.00
```
