#!/usr/bin/env python3
"""Unit tests for expenses.py"""

import unittest
import sys
import os
import tempfile
import subprocess
from decimal import Decimal

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import expenses


class TestSummarize(unittest.TestCase):
    """Tests for the summarize() function."""
    
    def test_normal_grouping(self):
        """Test basic category grouping."""
        csv_text = """category,amount
Food,10.50
Food,5.25
Transport,20.00"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Food'], Decimal('15.75'))
        self.assertEqual(result['Transport'], Decimal('20.00'))
    
    def test_zero_sum_exactness(self):
        """Test that 0.10 + 0.20 equals exactly 0.30 (no floating point errors)."""
        csv_text = """category,amount
Test,0.10
Test,0.20"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Test'], Decimal('0.30'))
    
    def test_negative_refunds(self):
        """Test negative amounts for refunds."""
        csv_text = """category,amount
Food,10.00
Food,-2.50"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Food'], Decimal('7.50'))
    
    def test_blank_category(self):
        """Test that blank category becomes 'Uncategorized'."""
        csv_text = """category,amount
,10.00
Food,5.00"""
        result = expenses.summarize(csv_text)
        self.assertIn('Uncategorized', result)
        self.assertEqual(result['Uncategorized'], Decimal('10.00'))
        self.assertEqual(result['Food'], Decimal('5.00'))
    
    def test_quoted_comma_in_category(self):
        """Test category with quoted comma."""
        csv_text = """category,amount
"Food, Drinks",15.00"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Food, Drinks'], Decimal('15.00'))
    
    def test_empty_dataset(self):
        """Test empty CSV (just header)."""
        csv_text = """category,amount"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result, {})
    
    def test_malformed_amount(self):
        """Test rejection of malformed amount."""
        csv_text = """category,amount
Food,abc"""
        with self.assertRaises(ValueError) as cm:
            expenses.summarize(csv_text)
        self.assertIn('row', str(cm.exception).lower())
    
    def test_missing_amount(self):
        """Test rejection when amount column is missing."""
        csv_text = """category,amount
Food,"""
        with self.assertRaises(ValueError) as cm:
            expenses.summarize(csv_text)
        self.assertIn('row', str(cm.exception).lower())
    
    def test_nan_amount(self):
        """Test rejection of NaN amount."""
        csv_text = """category,amount
Food,NaN"""
        with self.assertRaises(ValueError) as cm:
            expenses.summarize(csv_text)
        self.assertIn('row', str(cm.exception).lower())
    
    def test_infinity_amount(self):
        """Test rejection of Infinity amount."""
        csv_text = """category,amount
Food,Infinity"""
        with self.assertRaises(ValueError) as cm:
            expenses.summarize(csv_text)
        self.assertIn('row', str(cm.exception).lower())
    
    def test_excess_precision(self):
        """Test rejection of amounts with more than two decimal places."""
        csv_text = """category,amount
Food,10.123"""
        with self.assertRaises(ValueError) as cm:
            expenses.summarize(csv_text)
        self.assertIn('row', str(cm.exception).lower())
    
    def test_missing_headers(self):
        """Test rejection when headers are missing."""
        csv_text = """Food,10.00"""
        with self.assertRaises(ValueError) as cm:
            expenses.summarize(csv_text)
        self.assertIn('header', str(cm.exception).lower())
    
    def test_blank_rows_skipped(self):
        """Test that blank rows are skipped."""
        csv_text = """category,amount
Food,10.00

Transport,5.00

"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Food'], Decimal('10.00'))
        self.assertEqual(result['Transport'], Decimal('5.00'))
    
    def test_whitespace_trimming(self):
        """Test that category whitespace is trimmed."""
        csv_text = """category,amount
  Food  ,10.00"""
        result = expenses.summarize(csv_text)
        self.assertIn('Food', result)
        self.assertNotIn('  Food  ', result)
    
    def test_signed_amounts(self):
        """Test that signed amounts are accepted."""
        csv_text = """category,amount
Food,+10.00
Transport,-5.50"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Food'], Decimal('10.00'))
        self.assertEqual(result['Transport'], Decimal('-5.50'))
    
    def test_extra_columns(self):
        """Test that extra columns are ignored."""
        csv_text = """category,amount,date,note
Food,10.00,2024-01-01,Lunch"""
        result = expenses.summarize(csv_text)
        self.assertEqual(result['Food'], Decimal('10.00'))


class TestCLI(unittest.TestCase):
    """Tests for the CLI entry point."""
    
    def test_cli_success(self):
        """Test CLI with valid input."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nFood,10.00\n")
            f.flush()
            try:
                result = subprocess.run(
                    ['python3', 'expenses.py', f.name],
                    capture_output=True,
                    text=True,
                    cwd=os.path.dirname(os.path.abspath(__file__))
                )
                self.assertEqual(result.returncode, 0)
                self.assertIn('category,total', result.stdout)
                self.assertIn('Food,10.00', result.stdout)
            finally:
                os.unlink(f.name)
    
    def test_cli_failure_invalid_amount(self):
        """Test CLI with invalid amount."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nFood,abc\n")
            f.flush()
            try:
                result = subprocess.run(
                    ['python3', 'expenses.py', f.name],
                    capture_output=True,
                    text=True,
                    cwd=os.path.dirname(os.path.abspath(__file__))
                )
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('error', result.stderr.lower())
            finally:
                os.unlink(f.name)
    
    def test_cli_missing_file(self):
        """Test CLI with missing file."""
        result = subprocess.run(
            ['python3', 'expenses.py', 'nonexistent.csv'],
            capture_output=True,
            text=True,
            cwd=os.path.dirname(os.path.abspath(__file__))
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('error', result.stderr.lower())
    
    def test_cli_usage(self):
        """Test CLI usage message."""
        result = subprocess.run(
            ['python3', 'expenses.py'],
            capture_output=True,
            text=True,
            cwd=os.path.dirname(os.path.abspath(__file__))
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('usage', result.stderr.lower())


if __name__ == '__main__':
    unittest.main()
