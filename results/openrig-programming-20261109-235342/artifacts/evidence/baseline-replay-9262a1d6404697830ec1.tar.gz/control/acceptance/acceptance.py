import importlib.util,unittest,subprocess,sys,tempfile
from pathlib import Path
from decimal import Decimal
p=Path('/work')
spec=importlib.util.spec_from_file_location('expenses',p/'expenses.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Acceptance(unittest.TestCase):
 def test_exact(self): self.assertEqual(m.summarize('category,amount\nFood,0.10\nFood,0.20\n'),{'Food':Decimal('0.30')})
 def test_refunds(self): self.assertEqual(m.summarize('category,amount\nFood,5.00\nFood,-2.25\n'),{'Food':Decimal('2.75')})
 def test_csv_and_blanks(self): self.assertEqual(m.summarize('category,amount,extra\n"Travel, work",2.10,x\n   ,1.00,y\n\nFood ,3.00,z\n'),{'Travel, work':Decimal('2.10'),'Uncategorized':Decimal('1.00'),'Food':Decimal('3.00')})
 def test_empty(self): self.assertEqual(m.summarize('category,amount\n'),{})
 def test_invalid(self):
  for a in ['','abc','NaN','sNaN','Infinity','-Infinity','1.234']:
   with self.subTest(amount=a):
    with self.assertRaises(ValueError) as e:m.summarize('category,amount\nFood,'+a+'\n')
    self.assertIn('2',str(e.exception))
 def test_headers(self):
  for text in ['', 'category\nFood\n','amount\n1.00\n']:
   with self.subTest(text=text),self.assertRaises(ValueError):m.summarize(text)
 def test_cli(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'in.csv';f.write_text('category,amount\nZ,0.10\nA,-2.00\nZ,0.20\n')
   r=subprocess.run([sys.executable,str(p/'expenses.py'),str(f)],capture_output=True,text=True,timeout=10)
   self.assertEqual(r.returncode,0,r.stderr); self.assertEqual(r.stdout.replace('\r\n','\n'),'category,total\nA,-2.00\nZ,0.30\n')
   f.write_text('category,amount\nA,bad\n');r=subprocess.run([sys.executable,str(p/'expenses.py'),str(f)],capture_output=True,text=True,timeout=10)
   self.assertNotEqual(r.returncode,0);self.assertTrue(r.stderr.strip());self.assertNotIn('Traceback',r.stderr)
unittest.main(verbosity=2)
