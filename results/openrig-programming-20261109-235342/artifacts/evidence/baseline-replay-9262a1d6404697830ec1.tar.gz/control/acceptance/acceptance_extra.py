import csv,io,subprocess,sys,tempfile,unittest
from pathlib import Path
import expenses
class ExtraChecks(unittest.TestCase):
 def test_csv_output_quotes_commas(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'input.csv';f.write_text('category,amount\n"Travel, work",2.10\n')
   r=subprocess.run([sys.executable,'expenses.py',str(f)],capture_output=True,text=True,timeout=10)
   self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(list(csv.reader(io.StringIO(r.stdout))),[['category','total'],['Travel, work','2.10']])
 def test_other_nonfinite_spellings(self):
  for a in ['+Infinity','inf','-NaN']:
   with self.subTest(amount=a),self.assertRaises(ValueError):expenses.summarize('category,amount\nFood,'+a+'\n')
 def test_physical_row_number_after_blank_line(self):
  with self.assertRaises(ValueError) as e:expenses.summarize('category,amount\n\nFood,bad\n')
  self.assertIn('3',str(e.exception))
 def test_multiline_quoted_category(self):
  self.assertEqual(list(expenses.summarize('category,amount\n"Travel\nwork",1.00\n')) ,['Travel\nwork'])
unittest.main(verbosity=2)
