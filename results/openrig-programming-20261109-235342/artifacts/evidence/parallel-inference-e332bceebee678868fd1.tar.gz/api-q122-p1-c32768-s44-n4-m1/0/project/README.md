# Integer Arithmetic Evaluator

This module provides a safe integer arithmetic evaluator that supports `+`, `-`, `*`, `//` (floor division), parentheses, and unary `+`/`-`.

## Features
- **Safe Evaluation**: No use of `eval()` or `exec()`. Parses and evaluates expressions manually.
- **Precedence**: Follows standard mathematical precedence (multiplication/division before addition/subtraction).
- **Floor Division**: Uses Python's floor division (`//`) which rounds towards negative infinity.
- **Validation**: 
  - Rejects floats, booleans, variable names, and unsupported syntax.
  - Rejects expressions longer than 4096 characters.
  - Rejects integer tokens with more than 50 digits.
  - Rejects nesting depth greater than 100.
  - Rejects intermediate values with absolute value greater than 10^100.
  - Rejects division by zero.
  - Rejects leading zeros in integer tokens.

## Usage

```python
from solution import evaluate

result = evaluate("1 + 2 * 3")
print(result)  # Output: 7

result = evaluate("-10 // 3")
print(result)  # Output: -4

try:
    evaluate("1 / 0")
except ValueError as e:
    print(e)  # Output: Division by zero
```

## Implementation Details

The evaluator uses a recursive descent parser:
1. `evaluate()`: Entry point, initializes the parser.
2. `parse_expression()`: Handles addition and subtraction (lowest precedence).
3. `parse_term()`: Handles multiplication and division.
4. `parse_factor()`: Handles unary operators, parentheses, and numbers.
5. `parse_number()`: Extracts and validates integer tokens.

All intermediate results are checked against the maximum value limit (10^100) to prevent overflow or excessive computation.

## Error Handling

The function raises `ValueError` for:
- Syntax errors (e.g., missing parentheses, unexpected characters).
- Invalid tokens (e.g., floats, booleans, variable names).
- Division by zero.
- Excessive input length, token length, or nesting depth.
- Intermediate values exceeding 10^100.
- Leading zeros in integer tokens.