# Integer Arithmetic Evaluator

This project implements a safe integer arithmetic evaluator in Python without using `eval()`, `exec()`, or external packages.

## Features

- Supports `+`, `-`, `*`, `//` (floor division), and parentheses `()`.
- Supports unary `+` and `-`.
- Follows standard operator precedence.
- Handles negative numbers correctly with Python-style floor division.
- **Security & Safety Checks**:
  - Rejects floats, booleans, variable names, and unsupported syntax.
  - Rejects text length > 4096 characters.
  - Rejects integer tokens with more than 50 digits.
  - Rejects leading zeros in integer tokens (e.g., `01`).
  - Rejects nesting depth > 100.
  - Rejects any intermediate or final result where `abs(value) > 10**100`.
  - Rejects division by zero.
  - All violations raise `ValueError`.

## Usage

Import the `evaluate` function from `solution.py`:

```python
from solution import evaluate

result = evaluate("2 + 3 * 4")  # Returns 14
result = evaluate("-10 // 3")   # Returns -4
result = evaluate("(1 + 2) * 3") # Returns 9
```

## Running Tests

Run the script directly to execute built-in test cases:

```bash
python solution.py
```

This will print the results of valid expressions and verify that invalid expressions raise `ValueError`.

## Implementation Details

- **Parsing**: Uses a recursive descent parser to handle precedence and associativity.
- **Validation**: Checks are performed during tokenization and after every arithmetic operation to ensure limits are not exceeded.
- **No External Dependencies**: Pure Python standard library only.