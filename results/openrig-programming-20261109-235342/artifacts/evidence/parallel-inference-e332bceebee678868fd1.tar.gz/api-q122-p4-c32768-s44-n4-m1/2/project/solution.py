import re
import sys

class Calculator:
    def __init__(self, text):
        if len(text) > 4096:
            raise ValueError("Text length exceeds 4096 characters.")
        self.text = text
        self.pos = 0
        self.depth = 0
        self.max_depth = 100
        self.max_digits = 50
        self.max_val = 10**100

    def evaluate(self):
        result = self.parse_expression()
        self.skip_whitespace()
        if self.pos < len(self.text):
            raise ValueError("Unexpected characters after expression.")
        return result

    def skip_whitespace(self):
        while self.pos < len(self.text) and self.text[self.pos].isspace():
            self.pos += 1

    def parse_expression(self):
        self.skip_whitespace()
        left = self.parse_term()
        
        while True:
            self.skip_whitespace()
            if self.pos >= len(self.text):
                break
            char = self.text[self.pos]
            if char == '+':
                self.pos += 1
                right = self.parse_term()
                left = left + right
            elif char == '-':
                self.pos += 1
                right = self.parse_term()
                left = left - right
            else:
                break
            self.check_limits(left)
        return left

    def parse_term(self):
        self.skip_whitespace()
        left = self.parse_factor()
        
        while True:
            self.skip_whitespace()
            if self.pos >= len(self.text):
                break
            char = self.text[self.pos]
            if char == '*':
                self.pos += 1
                right = self.parse_factor()
                left = left * right
            elif char == '/':
                self.pos += 1
                right = self.parse_factor()
                if right == 0:
                    raise ValueError("Division by zero.")
                left = left // right
            else:
                break
            self.check_limits(left)
        return left

    def parse_factor(self):
        self.skip_whitespace()
        if self.pos >= len(self.text):
            raise ValueError("Unexpected end of input.")
        
        char = self.text[self.pos]
        
        if char == '+':
            self.pos += 1
            val = self.parse_factor()
            return val
        elif char == '-':
            self.pos += 1
            val = self.parse_factor()
            return -val
        elif char == '(':
            self.depth += 1
            if self.depth > self.max_depth:
                raise ValueError("Nesting depth exceeds 100.")
            self.pos += 1
            val = self.parse_expression()
            self.skip_whitespace()
            if self.pos >= len(self.text) or self.text[self.pos] != ')':
                raise ValueError("Missing closing parenthesis.")
            self.pos += 1
            self.depth -= 1
            return val
        elif char.isdigit():
            return self.parse_number()
        else:
            raise ValueError(f"Unexpected character: {char}")

    def parse_number(self):
        start = self.pos
        while self.pos < len(self.text) and self.text[self.pos].isdigit():
            self.pos += 1
        
        num_str = self.text[start:self.pos]
        
        if len(num_str) > self.max_digits:
            raise ValueError("Integer token exceeds 50 digits.")
        
        # Check for leading zeros (e.g., "01", "007")
        if len(num_str) > 1 and num_str[0] == '0':
            raise ValueError("Leading zeros in integer tokens are not allowed.")
        
        try:
            val = int(num_str)
        except ValueError:
            raise ValueError("Invalid integer token.")
        
        self.check_limits(val)
        return val

    def check_limits(self, val):
        if abs(val) > self.max_val:
            raise ValueError("Intermediate value exceeds 10**100.")

def evaluate(text):
    calc = Calculator(text)
    return calc.evaluate()

if __name__ == "__main__":
    # Simple test cases
    test_cases = [
        ("1 + 2", 3),
        ("10 - 5", 5),
        ("3 * 4", 12),
        ("10 // 3", 3),
        ("-10 // 3", -4),
        ("(1 + 2) * 3", 9),
        ("2 + 3 * 4", 14),
        ("-5", -5),
        ("+5", 5),
        ("((1))", 1),
    ]
    
    for expr, expected in test_cases:
        try:
            result = evaluate(expr)
            print(f"evaluate('{expr}') = {result} (expected {expected}) {'OK' if result == expected else 'FAIL'}")
        except Exception as e:
            print(f"evaluate('{expr}') raised {e}")
    
    # Error cases
    error_cases = [
        "1 +",          # Incomplete
        "1 / 0",        # Div by zero
        "1 + 2 *",      # Incomplete
        "01 + 1",       # Leading zero
        "1.5 + 2",      # Float
        "true + 1",     # Bool
        "a + 1",        # Name
        "1" + "0"*51,   # Too many digits
        "(" * 101 + "1" + ")" * 101, # Too deep
    ]
    
    print("\nError cases:")
    for expr in error_cases:
        try:
            result = evaluate(expr)
            print(f"evaluate('{expr[:20]}...') = {result} (SHOULD HAVE FAILED)")
        except ValueError as e:
            print(f"evaluate('{expr[:20]}...') raised ValueError: {e} (OK)")
        except Exception as e:
            print(f"evaluate('{expr[:20]}...') raised {type(e).__name__}: {e} (OK)")