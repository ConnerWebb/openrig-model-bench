# Integer Arithmetic Evaluator

This project implements a safe integer arithmetic evaluator in Python without using `eval()` or external packages.

## Features
- Supports `+`, `-`, `*`, `//` (floor division), and parentheses `()`.
- Supports unary `+` and `-`.
- Follows standard operator precedence.
- Python-style floor division for negative numbers (e.g., `-10 // 3` equals `-4`).
- Strict validation:
  - Maximum text length: 4096 characters.
  - Maximum integer token length: 50 digits.
  - Maximum nesting depth: 100 levels.
  - Maximum intermediate absolute value: 10^100.
  - Rejects floats, booleans, variable names, and unsupported syntax.
  - Rejects leading zeros in integer tokens (e.g., `01` is invalid).
  - Rejects division by zero.

## Usage

### Running the script
```bash
python solution.py
```

### Using as a module
```python
from solution import evaluate

result = evaluate("1 + 2 * 3")
print(result)  # Output: 7

try:
    evaluate("1 / 0")
except ValueError as e:
    print(e)  # Output: Division by zero (or similar)
```

## Error Handling
The `evaluate` function raises a `ValueError` for:
- Invalid syntax (e.g., `1 + + 2` is valid, but `1 + a` is not).
- Division by zero.
- Excessive nesting depth.
- Numbers with more than 50 digits.
- Intermediate values exceeding 10^100.
- Text longer than 4096 characters.
- Leading zeros in integer literals.
- Floats or boolean literals.

## Implementation Details
- The parser uses a recursive descent approach.
- Precedence: Parentheses > Unary > Multiplication/Division > Addition/Subtraction.
- No external dependencies.
- All validation is performed during parsing.