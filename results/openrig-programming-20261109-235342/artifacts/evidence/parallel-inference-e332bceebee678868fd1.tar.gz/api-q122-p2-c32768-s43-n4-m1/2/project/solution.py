import re
import sys

class Calculator:
    def __init__(self, text):
        if len(text) > 4096:
            raise ValueError("Text length exceeds 4096")
        self.text = text
        self.pos = 0
        self.depth = 0
        self.max_depth = 100
        self.max_val = 10**100

    def evaluate(self):
        self.skip_whitespace()
        if self.pos >= len(self.text):
            raise ValueError("Empty expression")
        
        result = self.parse_expression()
        self.skip_whitespace()
        if self.pos < len(self.text):
            raise ValueError("Unexpected characters after expression")
        return result

    def skip_whitespace(self):
        while self.pos < len(self.text) and self.text[self.pos].isspace():
            self.pos += 1

    def parse_expression(self):
        # Handle unary operators at the start of an expression or after '(' or ',' (though no commas here)
        # But standard precedence: unary binds tighter than binary
        # We handle unary in parse_term or parse_factor? 
        # Actually, standard: 1 + -2. Unary is higher precedence than +, -. 
        # Let's implement: expression -> term { (+|-) term }
        # term -> factor { (*|//) factor }
        # factor -> (+|-) factor | number | ( expression )
        
        left = self.parse_factor()
        
        while self.pos < len(self.text):
            self.skip_whitespace()
            if self.pos >= len(self.text):
                break
            
            char = self.text[self.pos]
            if char == '+':
                self.pos += 1
                self.skip_whitespace()
                right = self.parse_factor()
                left = left + right
            elif char == '-':
                self.pos += 1
                self.skip_whitespace()
                right = self.parse_factor()
                left = left - right
            else:
                break
            
            if abs(left) > self.max_val:
                raise ValueError("Intermediate value exceeds limit")
        
        return left

    def parse_factor(self):
        self.skip_whitespace()
        if self.pos >= len(self.text):
            raise ValueError("Unexpected end of input")
        
        char = self.text[self.pos]
        
        if char == '+':
            self.pos += 1
            val = self.parse_factor()
            return val
        elif char == '-':
            self.pos += 1
            val = self.parse_factor()
            return -val
        elif char == '(':
            self.depth += 1
            if self.depth > self.max_depth:
                raise ValueError("Nesting depth exceeds 100")
            self.pos += 1
            val = self.parse_expression()
            self.skip_whitespace()
            if self.pos >= len(self.text) or self.text[self.pos] != ')':
                raise ValueError("Missing closing parenthesis")
            self.pos += 1
            self.depth -= 1
            return val
        elif char.isdigit():
            return self.parse_number()
        else:
            raise ValueError(f"Unexpected character: {char}")

    def parse_number(self):
        start = self.pos
        # Check for leading zero
        if self.text[self.pos] == '0' and self.pos + 1 < len(self.text) and self.text[self.pos+1].isdigit():
            raise ValueError("Leading zeros not allowed")
        
        while self.pos < len(self.text) and self.text[self.pos].isdigit():
            self.pos += 1
        
        num_str = self.text[start:self.pos]
        
        if len(num_str) > 50:
            raise ValueError("Integer token exceeds 50 digits")
        
        try:
            val = int(num_str)
        except ValueError:
            raise ValueError("Invalid integer token")
        
        if abs(val) > self.max_val:
            raise ValueError("Integer value exceeds limit")
        
        return val

def evaluate(text):
    calc = Calculator(text)
    return calc.evaluate()

if __name__ == "__main__":
    # Simple test
    try:
        print(evaluate("1 + 2 * 3"))
        print(evaluate("(1 + 2) * 3"))
        print(evaluate("-5"))
        print(evaluate("10 // 3"))
        print(evaluate("-10 // 3"))
    except ValueError as e:
        print(f"Error: {e}")