# Arithmetic Evaluator

This module provides a safe arithmetic evaluator for integer expressions.

## Features
- Supports `+`, `-`, `*`, `//` (floor division), and parentheses.
- Supports unary `+` and `-`.
- Follows standard operator precedence.
- Strict validation:
  - No `eval` or `exec` used.
  - No external packages.
  - Rejects floats, booleans, variable names, and unsupported syntax.
  - Rejects text length > 4096.
  - Rejects integer tokens with > 50 digits.
  - Rejects nesting depth > 100.
  - Rejects intermediate or final absolute values > 10^100.
  - Rejects division by zero.
  - Rejects leading zeros in integer tokens.

## Usage

```python
from solution import evaluate

result = evaluate("1 + 2 * 3")  # Returns 7
result = evaluate("(1 + 2) * 3") # Returns 9
result = evaluate("-10 // 3")    # Returns -4 (Python floor division)
```

## Error Handling

The function raises `ValueError` for:
- Invalid syntax
- Division by zero
- Excessive nesting depth
- Values exceeding limits
- Unsupported tokens (floats, names, etc.)
- Text too long

## Testing

Run the built-in tests by executing the module:

```bash
python solution.py
```

Or add your own test cases in a separate test file using `unittest` or `pytest`.
