import re
import sys

class ArithmeticEvaluator:
    def __init__(self):
        self.pos = 0
        self.text = ""
        self.max_depth = 0
        self.current_depth = 0
        self.max_value_limit = 10**100

    def evaluate(self, text: str) -> int:
        if not isinstance(text, str):
            raise ValueError("Input must be a string")
        
        if len(text) > 4096:
            raise ValueError("Text length exceeds 4096 characters")

        self.text = text
        self.pos = 0
        self.max_depth = 0
        self.current_depth = 0

        # Tokenize
        tokens = self._tokenize()
        if not tokens:
            raise ValueError("Empty expression")

        # Parse and evaluate
        try:
            result = self._parse_expression(tokens)
        except IndexError:
            raise ValueError("Unexpected end of expression")
        
        if self.pos < len(tokens):
            raise ValueError("Unexpected tokens after expression")
            
        return result

    def _tokenize(self):
        tokens = []
        pattern = r'\s*(?:(\d+)|([+\-*/()])|([a-zA-Z_][a-zA-Z0-9_]*))\s*'
        
        # We need to handle unary operators carefully, but regex splits them.
        # A better approach for tokenizing with context is manual scanning or a more complex regex.
        # Let's use a manual scanner to handle unary +/- correctly and validate tokens.
        
        i = 0
        n = len(self.text)
        
        while i < n:
            char = self.text[i]
            
            if char.isspace():
                i += 1
                continue
            
            if char.isdigit():
                start = i
                while i < n and self.text[i].isdigit():
                    i += 1
                num_str = self.text[start:i]
                if len(num_str) > 50:
                    raise ValueError("Integer token exceeds 50 digits")
                # Check for leading zeros (optional rejection as per prompt: "may be rejected")
                # We will reject if it has leading zeros and length > 1
                if len(num_str) > 1 and num_str[0] == '0':
                    raise ValueError("Leading zeros in integer tokens are not allowed")
                tokens.append(('NUM', int(num_str)))
                continue
            
            if char in '+-*/()':
                tokens.append(('OP', char))
                i += 1
                continue
            
            if char.isalpha() or char == '_':
                start = i
                while i < n and (self.text[i].isalnum() or self.text[i] == '_'):
                    i += 1
                name = self.text[start:i]
                raise ValueError(f"Unsupported name or syntax: {name}")
            
            # Check for floats (e.g., 1.2)
            if char == '.':
                # Look ahead to see if it's a float
                if i + 1 < n and self.text[i+1].isdigit():
                    raise ValueError("Floats are not supported")
                raise ValueError("Invalid syntax")
            
            raise ValueError(f"Invalid character: {char}")
        
        return tokens

    def _parse_expression(self, tokens):
        # Grammar:
        # expr   -> term ( ( '+' | '-' ) term )*  
        # term   -> factor ( ( '*' | '/' ) factor )*  
        # factor -> ( '+' | '-' ) factor | '(' expr ')' | NUM
        
        result = self._parse_term(tokens)
        
        while self.pos < len(tokens) and tokens[self.pos][0] == 'OP' and tokens[self.pos][1] in ('+', '-'):
            op = tokens[self.pos][1]
            self.pos += 1
            right = self._parse_term(tokens)
            if op == '+':
                result = result + right
            else:
                result = result - right
            
            if abs(result) > self.max_value_limit:
                raise ValueError("Intermediate value exceeds limit")
        
        return result

    def _parse_term(self, tokens):
        result = self._parse_factor(tokens)
        
        while self.pos < len(tokens) and tokens[self.pos][0] == 'OP' and tokens[self.pos][1] in ('*', '/'):
            op = tokens[self.pos][1]
            self.pos += 1
            right = self._parse_factor(tokens)
            
            if op == '*':
                result = result * right
            else:
                if right == 0:
                    raise ValueError("Division by zero")
                # Python floor division for negatives
                result = result // right
            
            if abs(result) > self.max_value_limit:
                raise ValueError("Intermediate value exceeds limit")
        
        return result

    def _parse_factor(self, tokens):
        if self.pos >= len(tokens):
            raise ValueError("Unexpected end of expression")
        
        token = tokens[self.pos]
        
        if token[0] == 'OP' and token[1] in ('+', '-'):
            # Unary operator
            op = token[1]
            self.pos += 1
            val = self._parse_factor(tokens)
            if op == '-':
                val = -val
            if abs(val) > self.max_value_limit:
                raise ValueError("Intermediate value exceeds limit")
            return val
        
        if token[0] == 'OP' and token[1] == '(':
            self.pos += 1
            self.current_depth += 1
            if self.current_depth > 100:
                raise ValueError("Nesting depth exceeds 100")
            if self.current_depth > self.max_depth:
                self.max_depth = self.current_depth
            
            val = self._parse_expression(tokens)
            
            if self.pos >= len(tokens) or tokens[self.pos][0] != 'OP' or tokens[self.pos][1] != ')':
                raise ValueError("Missing closing parenthesis")
            self.pos += 1
            self.current_depth -= 1
            return val
        
        if token[0] == 'NUM':
            val = token[1]
            self.pos += 1
            if abs(val) > self.max_value_limit:
                raise ValueError("Integer value exceeds limit")
            return val
        
        raise ValueError(f"Unexpected token: {token}")

def evaluate(text: str) -> int:
    evaluator = ArithmeticEvaluator()
    return evaluator.evaluate(text)

if __name__ == "__main__":
    # Simple test
    print(evaluate("1 + 2 * 3"))
    print(evaluate("(1 + 2) * 3"))
    print(evaluate("-5 + 3"))
    print(evaluate("10 // 3"))
    print(evaluate("-10 // 3"))
