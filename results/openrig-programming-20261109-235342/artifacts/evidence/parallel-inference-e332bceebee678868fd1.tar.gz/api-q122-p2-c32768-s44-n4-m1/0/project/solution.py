import re
import sys

class Calculator:
    def __init__(self, text):
        if len(text) > 4096:
            raise ValueError("Text length exceeds 4096")
        self.text = text
        self.pos = 0
        self.depth = 0
        self.max_depth = 100
        self.max_val = 10**100

    def evaluate(self):
        self.skip_whitespace()
        if self.pos >= len(self.text):
            raise ValueError("Empty expression")
        
        result = self.parse_expression()
        self.skip_whitespace()
        if self.pos < len(self.text):
            raise ValueError("Unexpected characters after expression")
        return result

    def skip_whitespace(self):
        while self.pos < len(self.text) and self.text[self.pos].isspace():
            self.pos += 1

    def parse_expression(self):
        left = self.parse_term()
        while True:
            self.skip_whitespace()
            if self.pos >= len(self.text):
                break
            char = self.text[self.pos]
            if char == '+':
                self.pos += 1
                right = self.parse_term()
                left = left + right
            elif char == '-':
                self.pos += 1
                right = self.parse_term()
                left = left - right
            else:
                break
            if abs(left) > self.max_val:
                raise ValueError("Intermediate value exceeds limit")
        return left

    def parse_term(self):
        left = self.parse_factor()
        while True:
            self.skip_whitespace()
            if self.pos >= len(self.text):
                break
            char = self.text[self.pos]
            if char == '*':
                self.pos += 1
                right = self.parse_factor()
                left = left * right
            elif char == '/':
                self.pos += 1
                right = self.parse_factor()
                if right == 0:
                    raise ValueError("Division by zero")
                # Python floor division behavior for negatives
                left = left // right
            else:
                break
            if abs(left) > self.max_val:
                raise ValueError("Intermediate value exceeds limit")
        return left

    def parse_factor(self):
        self.skip_whitespace()
        if self.pos >= len(self.text):
            raise ValueError("Unexpected end of expression")
        
        char = self.text[self.pos]
        
        if char == '+':
            self.pos += 1
            return self.parse_factor()
        elif char == '-':
            self.pos += 1
            val = self.parse_factor()
            if abs(-val) > self.max_val:
                raise ValueError("Intermediate value exceeds limit")
            return -val
        elif char == '(':
            self.depth += 1
            if self.depth > self.max_depth:
                raise ValueError("Nesting depth exceeds limit")
            self.pos += 1
            val = self.parse_expression()
            self.skip_whitespace()
            if self.pos >= len(self.text) or self.text[self.pos] != ')':
                raise ValueError("Missing closing parenthesis")
            self.pos += 1
            self.depth -= 1
            return val
        else:
            return self.parse_number()

    def parse_number(self):
        start = self.pos
        if self.pos >= len(self.text):
            raise ValueError("Unexpected end of expression")
        
        # Check for valid start of number
        if not self.text[self.pos].isdigit():
            raise ValueError(f"Invalid character: {self.text[self.pos]}")
        
        while self.pos < len(self.text) and self.text[self.pos].isdigit():
            self.pos += 1
        
        token = self.text[start:self.pos]
        
        # Check for leading zeros (unless it's just "0")
        if len(token) > 1 and token[0] == '0':
            raise ValueError("Leading zeros not allowed")
        
        if len(token) > 50:
            raise ValueError("Integer token exceeds 50 digits")
        
        try:
            val = int(token)
        except ValueError:
            raise ValueError("Invalid integer token")
        
        if abs(val) > self.max_val:
            raise ValueError("Integer value exceeds limit")
        
        return val

def evaluate(text):
    calc = Calculator(text)
    return calc.evaluate()

if __name__ == "__main__":
    # Simple test cases
    test_cases = [
        ("1 + 2", 3),
        ("10 - 5", 5),
        ("3 * 4", 12),
        ("10 // 3", 3),
        ("-10 // 3", -4),
        ("(1 + 2) * 3", 9),
        ("2 + 3 * 4", 14),
        ("-5", -5),
        ("+5", 5),
        ("((1))", 1),
    ]
    
    for expr, expected in test_cases:
        try:
            result = evaluate(expr)
            print(f"evaluate('{expr}') = {result} (expected {expected}) {'OK' if result == expected else 'FAIL'}")
        except Exception as e:
            print(f"evaluate('{expr}') raised {e}")
    
    # Error cases
    error_cases = [
        "1 +",           # Incomplete
        "1 / 0",         # Div by zero
        "1 + 2 *",       # Incomplete
        "abc",           # Invalid name
        "1.5",           # Float
        "True",          # Bool
        "01",            # Leading zero
        "1" * 51,        # Too many digits
        "(" * 101 + "1" + ")" * 101, # Too deep
    ]
    
    print("\nError cases:")
    for expr in error_cases:
        try:
            result = evaluate(expr)
            print(f"evaluate('{expr[:20]}...') = {result} (SHOULD HAVE FAILED)")
        except ValueError as e:
            print(f"evaluate('{expr[:20]}...') raised ValueError: {e} (OK)")
        except Exception as e:
            print(f"evaluate('{expr[:20]}...') raised {type(e).__name__}: {e} (OK)")