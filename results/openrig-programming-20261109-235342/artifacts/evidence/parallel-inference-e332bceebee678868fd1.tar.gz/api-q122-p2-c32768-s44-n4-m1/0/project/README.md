# Integer Arithmetic Evaluator

This module provides a safe integer arithmetic evaluator that supports `+`, `-`, `*`, `//` (floor division), parentheses, and unary `+`/`-`.

## Features
- **Safe Evaluation**: No use of `eval()` or `exec()`. Custom parser implemented.
- **Precedence**: Follows standard mathematical precedence (multiplication/division before addition/subtraction).
- **Floor Division**: Uses Python's floor division behavior (e.g., `-10 // 3` results in `-4`).
- **Validation**: 
  - Rejects floats, booleans, variable names, and unsupported syntax.
  - Rejects division by zero.
  - Rejects text length > 4096.
  - Rejects integer tokens with > 50 digits.
  - Rejects nesting depth > 100.
  - Rejects intermediate values with absolute value > 10^100.
  - Rejects leading zeros in integer tokens (e.g., `01` is invalid, `0` is valid).

## Usage

```python
from solution import evaluate

result = evaluate("1 + 2 * 3")
print(result)  # Output: 7

result = evaluate("-10 // 3")
print(result)  # Output: -4

try:
    evaluate("1 / 0")
except ValueError as e:
    print(f"Error: {e}")
```

## Error Handling

The `evaluate` function raises `ValueError` for:
- Syntax errors (e.g., missing operands, unexpected characters).
- Division by zero.
- Invalid tokens (floats, booleans, names).
- Leading zeros in integers.
- Excessive input length, token length, nesting depth, or intermediate values.

## Testing

Run the built-in tests by executing the script directly:

```bash
python solution.py
```

This will run a series of valid and invalid test cases to demonstrate functionality and error handling.