def aggregate(path):return {}
