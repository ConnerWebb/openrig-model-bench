#include <thread>
int x;int main(){auto f=[](){for(int i=0;i<10000;i++)x++;};std::thread a(f),b(f);a.join();b.join();}