#include <cstdlib>
int main(int argc,char**){volatile int*p=new int[1];p[argc+9]=7;delete[]p;}