"""Checkpoint and replace private services only after a finished-trial boundary."""
import sys,pathlib,json,time,subprocess,os,signal,hashlib
R=pathlib.Path('/home/cow/Documents/Codex/2026-11-05/referenced-chatgpt-conversation-this-is-an/work/openrig-campaign')
sys.path.insert(0,str(R))
from common import O,I,P,atomic
from preserve import check,checkpoint
from orchestrator import archive_db
D=O/'repairs/h5.5';unit=P['unit']+'.service';oldpid=3668881
def run(args,**kw):return subprocess.run(args,check=True,text=True,**kw)
def show(prop):return subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()
end=time.monotonic()+1800
while not (D/'boundary-pause.json').exists() and time.monotonic()<end:time.sleep(1)
assert (D/'boundary-pause.json').exists(),'No safe finished-trial boundary yet'
try:
 pause=json.load((D/'boundary-pause.json').open());assert pause['pid']==oldpid
 assert '\nState:\tT' in pathlib.Path(f'/proc/{oldpid}/status').read_text()
 assert check('h55-idle-boundary')['matches_before']
 archive_db('idle-before-h55');backup=checkpoint('idle-before-h55')
 atomic(D/'boundary-checkpoint.json',{'at':time.time(),'backup':backup,'boundary':pause,'no_active_trial_interrupted':True})
 print('Idle checkpoint preserved:',backup,flush=True)
 run(['python3',str(D/'replay_candidate.py')])
 assert json.load((D/'live-summary-replay.json').open())['passed']
 state={'at':time.time(),'link_target':str(pathlib.Path.home()/'.config/systemd/user/openrig-programming-resource-observer-m1.service'),'source_target':str(O/'repairs/monitor-m1/resource-observer.service'),'status':subprocess.check_output(['systemctl','--user','show','openrig-programming-resource-observer-m1.service','-p','ActiveState','-p','MainPID','-p','UnitFileState'],text=True)}
 atomic(D/'monitor-m1-state-before.json',state)
 # Request the stop while frozen, then resume so its pending SIGTERM runs
 # before another controller iteration. No active case exists at this boundary.
 run(['systemctl','--user','stop','--no-block',unit])
 until=time.monotonic()+10
 while show('MainPID')!='0' and show('SubState')!='stop-sigterm' and time.monotonic()<until:time.sleep(.05)
 try:os.kill(oldpid,signal.SIGCONT)
 except ProcessLookupError:pass  # systemd may already have sent SIGCONT itself
 until=time.monotonic()+180
 while show('MainPID')!='0' and time.monotonic()<until:time.sleep(.5)
 assert show('MainPID')=='0','Private main must finish its own cleanup before deployment'
 print('Old private campaign stopped at completed-trial boundary',flush=True)
 archive=pathlib.Path('/home/cow/Documents/Programming/openrig-model-bench/archive/harness/frozen-harness-v5.5');manifest=json.load((archive/'SOURCE-MANIFEST.json').open());F=O/'frozen-harness-v5.5'
 for name,h in manifest['files'].items():
  if name.startswith('replay-profile/'):continue
  assert hashlib.sha256((R/name).read_text().replace(str(R),str(F)).encode()).hexdigest()==h,name
 run(['python3',str(R/'deploy_repair.py')],cwd=R)
 until=time.monotonic()+30
 while time.monotonic()<until:
  hb=json.load((O/'heartbeat.json').open());newpid=int(show('MainPID'))
  if newpid and hb['pid']==newpid and time.time()-hb['at']<5:break
  time.sleep(.5)
 else:raise RuntimeError('New integrated resource monitor did not become fresh')
 run(['systemctl','--user','disable','--now','openrig-programming-resource-observer-m1.service'])
 old=json.load((D/'old-result-sha256.json').open());assert all(hashlib.sha256((O/n).read_bytes()).hexdigest()==h for n,h in old.items())
 assert check('h55-after-private-deployment')['matches_before']
 for n,h in manifest['files'].items():assert hashlib.sha256((F/n).read_bytes()).hexdigest()==h,n
 result={'at':time.time(),'harness_revision':'h5.5','new_main_pid':newpid,'old_main_pid':oldpid,'no_active_trial_interrupted':True,'regression_checks':140,'repository_checks':17,'installed_pi_batch_check':True,'live_replay_passed':True,'historical_results_verified':len(old),'boundary_checkpoint':backup,'production_unchanged':True,'prior_observer':'monitor-m1 disabled after integrated h5.5 monitor became fresh; source/unit/telemetry/state preserved','source_candidate_commit':'1a065f9'}
 atomic(D/'DEPLOYMENT.json',result);print(json.dumps(result,indent=2),flush=True)
finally:
 try:
  if '\nState:\tT' in pathlib.Path(f'/proc/{oldpid}/status').read_text():os.kill(oldpid,signal.SIGCONT)
 except ProcessLookupError:pass
 except FileNotFoundError:pass
