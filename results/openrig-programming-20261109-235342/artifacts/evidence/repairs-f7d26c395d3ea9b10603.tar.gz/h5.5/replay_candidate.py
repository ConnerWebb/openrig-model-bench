"""Replay the exact failed, tool-free summary only at an idle paused boundary."""
import sys,pathlib,json,threading,urllib.request,http.server,time
R=pathlib.Path('/home/cow/Documents/Codex/2026-11-05/referenced-chatgpt-conversation-this-is-an/work/openrig-campaign')
sys.path.insert(0,str(R))
import proxy
from common import O,atomic
D=O/'repairs/h5.5'
pause=json.load((D/'boundary-pause.json').open());pid=pause['pid']
assert '\nState:\tT' in pathlib.Path(f'/proc/{pid}/status').read_text(),'Only replay while the main is idle/paused'
assert (O/'runs'/pause['after_completed_case']/'result.json').exists()
original=O/'transport/b3139a5f554744b3a1e3e47a83a88d55/request.json';body=original.read_bytes()
assert not json.loads(body).get('tools')
server=http.server.ThreadingHTTPServer(('127.0.0.1',11439),proxy.Handler)
threading.Thread(target=server.serve_forever,daemon=True).start();started=time.monotonic()
try:
 req=urllib.request.Request('http://127.0.0.1:11439/diagnostic-h55-heading-summary/v1/chat/completions',body,{'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=1200) as response:
  wire=response.read();status=response.status
 (D/'live-summary-response.sse').write_bytes(wire)
 assert status==200 and b'data: [DONE]' in wire
 matches=[]
 for p in (O/'transport').glob('*/metrics.json'):
  m=json.load(p.open())
  if m.get('prefix')=='diagnostic-h55-heading-summary':matches.append((p,m))
 assert len(matches)==1;path,m=matches[0]
 assert m['complete'] and m['context_policy']['summary_envelope']=='heading-checkpoint' and m['context_policy']['after_bytes']<=48000
 result={'at':time.time(),'passed':True,'status':status,'seconds':time.monotonic()-started,'original_request':str(original.relative_to(O)),'replay_transport':str(path.parent.relative_to(O)),'metrics':m,'diagnostic_only':True,'notes':'Exact archived request through candidate proxy, same existing private model alias and sampling. No tools or model answer edits. Idle-boundary pause only; not scored as a coding task.'}
 atomic(D/'live-summary-replay.json',result);print(json.dumps(result,indent=2))
finally:
 server.shutdown();server.server_close()
