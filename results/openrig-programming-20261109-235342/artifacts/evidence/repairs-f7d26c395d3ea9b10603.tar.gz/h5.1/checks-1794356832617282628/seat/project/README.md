Reference implementation for harness qualification only.
