import unittest,tempfile,pathlib,solution
class CorrectReference(unittest.TestCase):
 def test_decimal(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'x.csv';p.write_text('category,amount\na,0.10\na,0.20\n');self.assertEqual(solution.aggregate(str(p)),{'a':'0.30'})
