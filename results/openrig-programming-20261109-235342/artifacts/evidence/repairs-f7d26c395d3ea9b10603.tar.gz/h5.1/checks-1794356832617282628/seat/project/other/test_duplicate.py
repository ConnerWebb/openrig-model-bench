import unittest
class Duplicate(unittest.TestCase):
 def test_one(self):self.assertTrue(True)
