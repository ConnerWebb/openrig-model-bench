import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import solution
 with tempfile.TemporaryDirectory() as d:
  p=pathlib.Path(d)/'input.csv';p.write_text(x['csv'],encoding='utf-8');del x
  result=solution.aggregate(str(p));print(json.dumps({'value':result},ensure_ascii=False))

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
