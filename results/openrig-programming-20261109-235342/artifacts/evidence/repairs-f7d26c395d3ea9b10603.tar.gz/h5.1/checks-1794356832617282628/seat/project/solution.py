
import csv,re
from decimal import Decimal
def aggregate(path):
 out={}
 with open(path,encoding='utf-8',newline='') as f:
  rd=csv.reader(f,strict=True)
  if next(rd,None)!=['category','amount']:raise ValueError('header')
  try:
   for row in rd:
    if not row:continue
    if len(row)!=2:raise ValueError('columns')
    k,v=(s.strip() for s in row)
    if not k or not re.fullmatch(r'\+?\d{1,12}(?:\.\d{1,2})?',v,flags=re.ASCII):raise ValueError('record')
    out[k]=out.get(k,Decimal(0))+Decimal(v)
  except csv.Error as e:raise ValueError('csv') from e
 return {k:format(out[k],'.2f') for k in sorted(out)}
