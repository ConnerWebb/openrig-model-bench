
#pragma once
#include <vector>
#include <cstdint>
#include <utility>
class Buffer{std::vector<std::uint8_t> v;public:explicit Buffer(std::size_t n=0):v(n,0){}Buffer(const Buffer&)=default;Buffer&operator=(const Buffer&)=default;Buffer(Buffer&&o)noexcept:v(std::move(o.v)){o.v.clear();}Buffer&operator=(Buffer&&o)noexcept{if(this!=&o){v=std::move(o.v);o.v.clear();}return *this;}std::size_t size()const noexcept{return v.size();}std::uint8_t&operator[](std::size_t i){return v.at(i);}const std::uint8_t&operator[](std::size_t i)const{return v.at(i);}void resize(std::size_t n){v.resize(n,0);}};
