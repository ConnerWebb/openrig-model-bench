#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <type_traits>

// Test 1: Default constructor
void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

// Test 2: Constructor with size
void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    std::cout << "test_constructor_with_size passed\n";
}

// Test 3: Bounds check on mutable operator[]
void test_bounds_check_mutable() {
    Buffer b(5);
    try {
        (void)b[10];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "test_bounds_check_mutable passed\n";
}

// Test 4: Bounds check on const operator[]
void test_bounds_check_const() {
    const Buffer b(5);
    try {
        (void)b[10];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "test_bounds_check_const passed\n";
}

// Test 5: Copy constructor (deep copy)
void test_copy_constructor() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 1 && b[1] == 2 && b[2] == 3 && b[3] == 4 && b[4] == 5);
    a[0] = 99;
    assert(b[0] == 1); // Deep copy, not shared
    std::cout << "test_copy_constructor passed\n";
}

// Test 6: Copy assignment
void test_copy_assignment() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(10);
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 1 && b[1] == 2 && b[2] == 3 && b[3] == 4 && b[4] == 5);
    a[0] = 99;
    assert(b[0] == 1); // Deep copy
    std::cout << "test_copy_assignment passed\n";
}

// Test 7: Self copy assignment
void test_self_copy_assignment() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 1 && a[1] == 2 && a[2] == 3 && a[3] == 4 && a[4] == 5);
    std::cout << "test_self_copy_assignment passed\n";
}

// Test 8: Move constructor
void test_move_constructor() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 1 && b[1] == 2 && b[2] == 3 && b[3] == 4 && b[4] == 5);
    assert(a.size() == 0); // Moved-from buffer has size 0
    std::cout << "test_move_constructor passed\n";
}

// Test 9: Move assignment
void test_move_assignment() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(10);
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 1 && b[1] == 2 && b[2] == 3 && b[3] == 4 && b[4] == 5);
    assert(a.size() == 0); // Moved-from buffer has size 0
    std::cout << "test_move_assignment passed\n";
}

// Test 10: Self move assignment
void test_self_move_assignment() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 1 && a[1] == 2 && a[2] == 3 && a[3] == 4 && a[4] == 5);
    std::cout << "test_self_move_assignment passed\n";
}

// Test 11: Resize preserving prefix and zero-initializing new bytes
void test_resize_expand() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a.resize(10);
    assert(a.size() == 10);
    assert(a[0] == 1 && a[1] == 2 && a[2] == 3 && a[3] == 4 && a[4] == 5);
    assert(a[5] == 0 && a[6] == 0 && a[7] == 0 && a[8] == 0 && a[9] == 0);
    std::cout << "test_resize_expand passed\n";
}

// Test 12: Resize shrinking
void test_resize_shrink() {
    Buffer a(10);
    for (size_t i = 0; i < 10; ++i) a[i] = i;
    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 0 && a[1] == 1 && a[2] == 2 && a[3] == 3 && a[4] == 4);
    std::cout << "test_resize_shrink passed\n";
}

// Test 13: Resize to zero
void test_resize_to_zero() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a.resize(0);
    assert(a.size() == 0);
    std::cout << "test_resize_to_zero passed\n";
}

// Test 14: Noexcept move constructor
void test_noexcept_move_constructor() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    std::cout << "test_noexcept_move_constructor passed\n";
}

// Test 15: Noexcept move assignment
void test_noexcept_move_assignment() {
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
    std::cout << "test_noexcept_move_assignment passed\n";
}

// Test 16: Reusable moved-from buffer
void test_reusable_moved_from() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    a.resize(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    assert(a.size() == 3);
    assert(a[0] == 10 && a[1] == 20 && a[2] == 30);
    std::cout << "test_reusable_moved_from passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_bounds_check_mutable();
    test_bounds_check_const();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_self_move_assignment();
    test_resize_expand();
    test_resize_shrink();
    test_resize_to_zero();
    test_noexcept_move_constructor();
    test_noexcept_move_assignment();
    test_reusable_moved_from();
    std::cout << "All tests passed!\n";
    return 0;
}
