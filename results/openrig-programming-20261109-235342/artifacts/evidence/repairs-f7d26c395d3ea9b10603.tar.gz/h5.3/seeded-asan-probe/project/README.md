# Buffer Library

A C++20 RAII buffer class for managing dynamically allocated `uint8_t` arrays with proper memory safety guarantees.

## Features

- **RAII**: Automatic memory management with destructor
- **Deep copy**: Copy constructor and assignment operator perform deep copies
- **Move semantics**: Noexcept move constructor and assignment operator
- **Bounds checking**: `operator[]` throws `std::out_of_range` for out-of-bounds access
- **Resize**: Preserves prefix and zero-initializes new bytes when expanding
- **Self-assignment safe**: Both copy and move assignment handle self-assignment correctly
- **Reusable moved-from objects**: Moved-from buffers have size 0 and can be reused

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of size `n`. Default constructor creates an empty buffer.

### Destructor
```cpp
~Buffer();
```
Releases allocated memory.

### Copy Constructor
```cpp
Buffer(const Buffer& other);
```
Creates a deep copy of `other`.

### Copy Assignment
```cpp
Buffer& operator=(const Buffer& other);
```
Performs deep copy assignment. Self-assignment is safe.

### Move Constructor
```cpp
Buffer(Buffer&& other) noexcept;
```
Takes ownership of `other`'s resources. `other` is left in a valid but unspecified state (size 0).

### Move Assignment
```cpp
Buffer& operator=(Buffer&& other) noexcept;
```
Takes ownership of `other`'s resources. Self-assignment is safe.

### Size
```cpp
std::size_t size() const noexcept;
```
Returns the current buffer size.

### Mutable Indexing
```cpp
std::uint8_t& operator[](std::size_t i);
```
Returns reference to element at index `i`. Throws `std::out_of_range` if `i >= size()`.

### Const Indexing
```cpp
const std::uint8_t& operator[](std::size_t i) const;
```
Returns const reference to element at index `i`. Throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes the buffer to size `k`. When expanding, preserves existing elements and zero-initializes new bytes. When shrinking, truncates the buffer. When resizing to 0, releases all memory.

## Memory Safety

- **No leaks**: All allocated memory is freed in destructor
- **No double frees**: Move semantics properly transfer ownership
- **No stale reads**: Moved-from buffers have size 0
- **No undefined behavior**: Bounds checking prevents out-of-bounds access

## Usage Example

```cpp
#include "solution.hpp"
#include <iostream>

int main() {
    Buffer b(5);
    b[0] = 1; b[1] = 2; b[2] = 3; b[3] = 4; b[4] = 5;
    
    // Copy
    Buffer c = b;
    
    // Move
    Buffer d = std::move(b);
    
    // Resize
    b.resize(10); // Now size 10, first 5 elements preserved, new elements zero-initialized
    
    return 0;
}
```

## Testing

Run the test suite:
```bash
clang++ -std=c++20 -fuse-ld=bfd Buffer_test.cpp -o Buffer_test
./Buffer_test
```

## Compliance

- C++20 standard
- No external dependencies (uses only stdlib)
- Noexcept move operations
- RAII pattern
- Self-assignment safe
