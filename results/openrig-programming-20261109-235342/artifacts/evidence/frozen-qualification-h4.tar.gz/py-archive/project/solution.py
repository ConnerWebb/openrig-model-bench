
import pathlib,zipfile,stat,tempfile,os,shutil
def extract_zip(archive_path,outdir):
 out=pathlib.Path(outdir)
 if out.exists():raise ValueError('exists')
 staging=None
 try:
  with zipfile.ZipFile(archive_path) as z:
   seen=set();items=[]
   for i in z.infolist():
    p=pathlib.PurePosixPath(i.filename);name=str(p)
    if not i.filename or p.is_absolute() or '..' in p.parts or '\\' in i.filename or ':' in i.filename or name in seen or stat.S_ISLNK(i.external_attr>>16):raise ValueError('unsafe')
    seen.add(name);items.append(i)
   for i in items:
    p=pathlib.PurePosixPath(i.filename)
    if any(str(parent) in seen and not any(q.is_dir() and str(pathlib.PurePosixPath(q.filename))==str(parent) for q in items) for parent in p.parents if str(parent)!='.'):raise ValueError('parent-file')
   staging=pathlib.Path(tempfile.mkdtemp(dir=out.parent))
   for i in items:
    p=staging/i.filename
    if i.is_dir():p.mkdir(parents=True,exist_ok=True)
    else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(i))
  os.rename(staging,out);return sorted(i.filename for i in items if not i.is_dir())
 except Exception as e:
  if staging and staging.exists():shutil.rmtree(staging)
  if isinstance(e,ValueError):raise
  raise ValueError('archive') from e
