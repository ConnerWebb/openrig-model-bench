
import sqlite3,json
class JobQueue:
 def __init__(self,path,max_attempts=3):
  if type(max_attempts)!=int or max_attempts<1:raise ValueError('attempts')
  self.path=path;self.max=max_attempts
  with self.db() as c:c.execute('create table if not exists jobs(id integer primary key,k text unique,p text,s text,a integer,owner text,until real)')
 def db(self):return sqlite3.connect(self.path,timeout=10)
 def enqueue(self,key,payload):
  if not isinstance(key,str) or not key:raise ValueError('key')
  with self.db() as c:return c.execute('insert or ignore into jobs(k,p,s,a) values(?,?,?,0)',(key,json.dumps(payload),'queued')).rowcount==1
 def claim(self,worker,now,lease):
  if not isinstance(worker,str) or not worker or lease<=0:raise ValueError('claim')
  with self.db() as c:
   c.execute('begin immediate');c.execute("update jobs set s='failed' where s='leased' and until<=? and a>=?",(now,self.max));r=c.execute("select id,k,p,a from jobs where a<? and (s='queued' or (s='leased' and until<=?)) order by id limit 1",(self.max,now)).fetchone()
   if r is None:return None
   c.execute("update jobs set s='leased',a=a+1,owner=?,until=? where id=?",(worker,now+lease,r[0]));return {'key':r[1],'payload':json.loads(r[2]),'attempts':r[3]+1}
 def complete(self,key,worker):
  with self.db() as c:return c.execute("update jobs set s='done' where k=? and owner=? and s='leased'",(key,worker)).rowcount==1
 def fail(self,key,worker):
  with self.db() as c:return c.execute("update jobs set s=case when a>=? then 'failed' else 'queued' end where k=? and owner=? and s='leased'",(self.max,key,worker)).rowcount==1
 def status(self,key):
  with self.db() as c:r=c.execute('select s,a from jobs where k=?',(key,)).fetchone();return None if r is None else {'state':r[0],'attempts':r[1]}
