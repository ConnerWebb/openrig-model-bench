#pragma once
#include <cstdint>
class RunningStats{std::uint64_t n=0;double avg=0,m2=0,lo=0,hi=0;public:void add(double);void merge(const RunningStats&);std::uint64_t count()const;double mean()const;double variance()const;double minimum()const;double maximum()const;};
