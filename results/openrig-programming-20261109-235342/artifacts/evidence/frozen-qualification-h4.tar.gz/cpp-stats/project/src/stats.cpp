#include "stats.hpp"
#include <cmath>
#include <algorithm>
#include <stdexcept>
void RunningStats::add(double x){if(!std::isfinite(x))throw std::invalid_argument("finite");if(!n){lo=hi=avg=x;n=1;return;}lo=std::min(lo,x);hi=std::max(hi,x);n++;double d=x-avg;avg+=d/n;m2+=d*(x-avg);}
void RunningStats::merge(const RunningStats&o){if(!o.n)return;if(!n){*this=o;return;}auto a=n,b=o.n;double otherAvg=o.avg,otherM2=o.m2,otherLo=o.lo,otherHi=o.hi;double d=otherAvg-avg;avg+=d*double(b)/(a+b);m2+=otherM2+d*d*double(a)*double(b)/(a+b);n=a+b;lo=std::min(lo,otherLo);hi=std::max(hi,otherHi);}
std::uint64_t RunningStats::count()const{return n;}double RunningStats::mean()const{if(!n)throw std::domain_error("empty");return avg;}double RunningStats::variance()const{if(!n)throw std::domain_error("empty");return m2/n;}double RunningStats::minimum()const{if(!n)throw std::domain_error("empty");return lo;}double RunningStats::maximum()const{if(!n)throw std::domain_error("empty");return hi;}
