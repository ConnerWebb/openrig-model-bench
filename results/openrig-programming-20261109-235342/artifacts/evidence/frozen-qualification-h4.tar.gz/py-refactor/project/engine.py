
def process(records,*,minimum_cents=0):
 if type(minimum_cents)!=int or minimum_cents<0:raise ValueError('minimum')
 seen=set();events=[];totals={}
 for r in records:
  if not isinstance(r,dict) or set(r)!={'id','category','cents'} or not isinstance(r['id'],str) or not r['id'].strip() or not isinstance(r['category'],str) or not r['category'].strip() or type(r['cents'])!=int or r['cents']<0:raise ValueError('record')
  v={'id':r['id'].strip(),'category':r['category'].strip(),'cents':r['cents']}
  if v['id'] in seen:continue
  seen.add(v['id'])
  if v['cents']<minimum_cents:continue
  events.append(v);totals[v['category']]=totals.get(v['category'],0)+v['cents']
 return {'events':events,'totals':dict(sorted(totals.items()))}
