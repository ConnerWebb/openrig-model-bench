
import json,urllib.request,urllib.parse,urllib.error
def fetch_pages(url,retries=2,timeout=1.):
 if isinstance(retries,bool) or not isinstance(retries,int) or retries<0 or timeout<=0:raise ValueError('options')
 def origin(u):
  p=urllib.parse.urlsplit(u)
  if p.scheme not in ['http','https'] or not p.hostname or p.username or p.password:raise ValueError('url')
  return p.scheme,p.hostname,p.port or (443 if p.scheme=='https' else 80)
 org=origin(url);seen=set();out=[]
 while url:
  if origin(url)!=org or url in seen:raise ValueError('origin/cycle')
  seen.add(url)
  for n in range(retries+1):
   try:
    with urllib.request.urlopen(url,timeout=timeout) as r:obj=json.load(r)
    break
   except urllib.error.HTTPError as e:
    if e.code not in [429,500,502,503,504] or n==retries:raise ValueError('http') from e
   except Exception as e:raise ValueError('request') from e
  if not isinstance(obj,dict) or set(obj)!= {'items','next'} or not isinstance(obj['items'],list) or any(type(v)!=int for v in obj['items']) or (obj['next'] is not None and not isinstance(obj['next'],str)):raise ValueError('schema')
  out+=obj['items'];url=urllib.parse.urljoin(url,obj['next']) if obj['next'] is not None else None
 return out
