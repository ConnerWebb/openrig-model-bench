
#pragma once
#include <vector>
#include <string>
#include <span>
#include <set>
#include <cstdint>
#include <bit>
#include <stdexcept>
struct Record{std::uint32_t id;std::string name;std::int64_t value;};
inline std::vector<std::uint8_t> encode(const std::vector<Record>&r){if(r.size()>10000)throw std::invalid_argument("count");std::vector<std::uint8_t>b={'O','G','C','1'};auto put=[&](std::uint64_t n,int bytes){for(int i=0;i<bytes;i++)b.push_back(n>>(8*i));};put(r.size(),4);std::set<std::uint32_t>seen;for(auto&v:r){if(v.name.size()>1024||!seen.insert(v.id).second)throw std::invalid_argument("record");put(v.id,4);put(v.name.size(),2);b.insert(b.end(),v.name.begin(),v.name.end());put(std::bit_cast<std::uint64_t>(v.value),8);}return b;}
inline std::vector<Record> decode(std::span<const std::uint8_t>b){std::size_t p=0;auto get=[&](int n){if((std::size_t)n>b.size()-p)throw std::invalid_argument("truncated");std::uint64_t v=0;for(int i=0;i<n;i++)v|=std::uint64_t(b[p++])<<(8*i);return v;};if(get(4)!=0x3143474f)throw std::invalid_argument("magic");auto count=get(4);if(count>10000)throw std::invalid_argument("count");std::set<std::uint32_t>seen;std::vector<Record>r;for(std::uint64_t i=0;i<count;i++){auto id=(std::uint32_t)get(4);auto n=get(2);if(n>1024||n>b.size()-p||!seen.insert(id).second)throw std::invalid_argument("record");std::string name((const char*)b.data()+p,n);p+=n;r.push_back({id,name,std::bit_cast<std::int64_t>(get(8))});}if(p!=b.size())throw std::invalid_argument("trailing");return r;}
