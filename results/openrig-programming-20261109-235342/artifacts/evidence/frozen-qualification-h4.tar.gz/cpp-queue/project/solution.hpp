
#pragma once
#include <mutex>
#include <condition_variable>
#include <deque>
#include <optional>
#include <stdexcept>
template<class T> class BoundedQueue{std::mutex m;std::condition_variable a,b;std::deque<T> q;std::size_t cap;bool done=false;public:explicit BoundedQueue(std::size_t n):cap(n){if(!n)throw std::invalid_argument("capacity");}bool push(T v){std::unique_lock l(m);b.wait(l,[&]{return done||q.size()<cap;});if(done)return false;q.push_back(std::move(v));a.notify_one();return true;}std::optional<T> pop(){std::unique_lock l(m);a.wait(l,[&]{return done||!q.empty();});if(q.empty())return {};T v=std::move(q.front());q.pop_front();b.notify_one();return v;}void close(){std::lock_guard l(m);done=true;a.notify_all();b.notify_all();}};
