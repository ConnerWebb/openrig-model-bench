
import ast,re
def evaluate(text):
 if not isinstance(text,str) or len(text)>4096 or any(len(s)>50 for s in re.findall(r'\d+',text)):raise ValueError('limit')
 try:tree=ast.parse(text.strip(),mode='eval')
 except Exception as e:raise ValueError('syntax') from e
 def visit(n,depth=0):
  if depth>100:raise ValueError('depth')
  if isinstance(n,ast.Constant) and type(n.value)==int:v=n.value
  elif isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):v=visit(n.operand,depth+1)*(1 if isinstance(n.op,ast.UAdd) else -1)
  elif isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub,ast.Mult,ast.FloorDiv)):
   a,b=visit(n.left,depth+1),visit(n.right,depth+1)
   try:v=a+b if isinstance(n.op,ast.Add) else a-b if isinstance(n.op,ast.Sub) else a*b if isinstance(n.op,ast.Mult) else a//b
   except Exception as e:raise ValueError('arithmetic') from e
  else:raise ValueError('syntax')
  if abs(v)>10**100:raise ValueError('magnitude')
  return v
 return visit(tree.body)
