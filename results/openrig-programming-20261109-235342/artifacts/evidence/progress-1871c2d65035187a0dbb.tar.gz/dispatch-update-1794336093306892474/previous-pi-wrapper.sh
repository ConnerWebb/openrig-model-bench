#!/bin/sh
set -eu
if [ -n "${PI_CODING_AGENT_DIR:-}" ]; then mkdir -p "$PI_CODING_AGENT_DIR"; if [ ! -f "$PI_CODING_AGENT_DIR/models.json" ]; then cp "/home/cow/Documents/Codex/2026-11-05/referenced-chatgpt-conversation-this-is-an/outputs/openrig-programming-20261109-235342/models.json" "$PI_CODING_AGENT_DIR/models.json"; fi; fi
case "${OPENRIG_SESSION_NAME:-}" in *@bench-replay-*) exec "/home/cow/.local/opt/framework-ai/openrig-fleet/npm/node_modules/.bin/pi" --offline --no-builtin-tools --no-extensions -e "/home/cow/Documents/Codex/2026-11-05/referenced-chatgpt-conversation-this-is-an/outputs/openrig-programming-20261109-235342/frozen-harness-v4.1/replay-profile/extension.ts" "$@" ;; esac
exec "/home/cow/.local/opt/framework-ai/openrig-fleet/npm/node_modules/.bin/pi" --offline --no-builtin-tools --no-extensions -e "/home/cow/Documents/Codex/2026-11-05/referenced-chatgpt-conversation-this-is-an/outputs/openrig-programming-20261109-235342/frozen-harness-v4.1/extension.ts" "$@"
