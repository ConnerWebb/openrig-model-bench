"""Read-only hourly audit; writes only reporting/preservation evidence, no controls."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time
import urllib.request
import zoneinfo

W=Path(__file__).resolve().parents[1]
O=W/'outputs/openrig-programming-20261109-235342'
D=O/'progress/decision-campaign-v1'
G=Path('/home/cow/Documents/Programming/openrig-model-bench')
now=time.time()
read=lambda p:json.loads(p.read_bytes())
plan=read(D/'source/plan.json')
status=read(O/'campaign-status.json')
heartbeat=read(O/'heartbeat.json')
rows=[]
for path in (O/'runs').glob('*/result.json'):
    row=read(path)
    if (row.get('harness_revision')=='h5.5' and row.get('phase')=='solo'
            and row.get('finished') and not row.get('interrupted') and 'resource_limited' in row):
        rows.append(row)
balanced=[r for r in rows if r['seed']==42 and r.get('variant',0)==0 and r['task'] in plan['balanced_tasks']]
sources={}
for folder,mp in [(D/'source',D/'source/SOURCE-MANIFEST.json'),(O/'frozen-harness-v5.5',O/'frozen-harness-v5.5-sha256.json')]:
    manifest=read(mp)
    assert all(hashlib.sha256((folder/p).read_bytes()).hexdigest()==h for p,h in manifest.items()),str(folder)
    sources[str(folder)]=len(manifest)
old=read(D/'pre-change-result-sha256.json')
assert all(hashlib.sha256((O/p).read_bytes()).hexdigest()==h for p,h in old.items())
with (O/'memory-timeline.jsonl').open('rb') as stream:
    stream.seek(max(0,stream.seek(0,2)-3*1024*1024));stream.readline();memory=[]
    for line in stream:
        try:sample=json.loads(line)
        except ValueError:continue
        if sample['at']>=now-600:memory.append(sample)
events=[]
for line in (O/'events.jsonl').open():
    try:event=json.loads(line)
    except ValueError:continue
    if event.get('at',0)>=now-4200:events.append(event)
errors=[e for e in events if e.get('kind') in ['resource_guard','monitor_error'] or e.get('kind')=='inference_request' and e.get('error')]
classified=[]
for event in errors:
    matches=[]
    for path in (O/'runs'/event.get('prefix','').split('/')[0]).glob('seats/*/control/failed-stage-*.json'):
        failure=read(path);closure=failure.get('job',{}).get('closed',{}) or {};at=closure.get('at') or failure.get('at',0)
        if event['at']-2<=at<=event['at']+event.get('seconds',0)+2:
            matches.append(dict(path=str(path),at=at,reason=failure.get('reason')))
    classification='Bounded stage cancellation' if matches else 'Needs diagnosis'
    item=dict(request=event.get('id'),kind=event.get('kind'),error=event.get('error'),classification=classification,evidence=matches)
    if event.get('upstream_status'):
        path=O/'transport'/event['id']/'upstream-error.txt'
        item['provider_error']=path.read_text()[:4000] if path.exists() else None
        item['following_request_recovered']=any(e.get('prefix')==event['prefix'] and e.get('at',0)>event['at'] and e.get('complete') for e in events)
    classified.append(item)
head=subprocess.check_output(['git','-C',str(G),'rev-parse','HEAD'],text=True).strip()
remote=subprocess.check_output(['git','-C',str(G),'ls-remote','origin','refs/heads/main'],text=True).split()[0]
with urllib.request.urlopen('http://127.0.0.1:18765/status.json',timeout=5) as response:chart=json.load(response)
sys.path.insert(0,str(W/'work/openrig-campaign'))
from preserve import check
preservation=check('decision-hourly-'+str(time.time_ns()))
assert preservation['matches_before']
current=O/'runs'/status.get('current','not-a-case')
public=sorted(current.glob('seats/*/control/public-*.json'))
public=read(public[-1]) if public else {}
jobs={p.parts[-3]:{k:r.get(k) for k in ['phase','state','failure','tests','closed']} for p in current.glob('seats/*/control/job.json') if (r:=read(p))}
latest=[]
for row in sorted(rows,key=lambda r:r['finished'])[-4:]:
    checks=sorted((O/'runs'/row['id']).glob('seats/*/control/public-*.json'));q=read(checks[-1]) if checks else {}
    latest.append(dict(id=row['id'],complete=row['complete'],resource_limited=row['resource_limited'],seconds=row['seconds'],feedback=row.get('last_stage_feedback') or row.get('failure'),last_fixed_checks={k:v.get('passed') for k,v in q.get('checks',{}).items()},last_saved_tests=q.get('authored_tests',{}).get('passed')))
resource=dict(samples=len(memory))
if memory:resource.update(minimum_available_gib=min(r['available'] for r in memory)/2**30,swapin_pages=memory[-1]['pswpin']-memory[0]['pswpin'],swapout_pages=memory[-1]['pswpout']-memory[0]['pswpout'],private_oom_kills=max(r.get('inference_oom_kills',0) for r in memory),optional_thermal_error_samples=sum(bool(r.get('temperature_errors')) for r in memory))
report=dict(at=now,dispatch='decision-v1',harness_revision='h5.5',status=status,heartbeat=heartbeat,heartbeat_age=now-heartbeat['at'],balanced_finished=len(balanced),balanced_target=48,scores={lang:dict(balanced_accepted=sum(r['language']==lang and r['complete'] for r in balanced),balanced_finished=sum(r['language']==lang for r in balanced),all_h55_accepted=sum(r['language']==lang and r['complete'] for r in rows),all_h55_finished=sum(r['language']==lang for r in rows)) for lang in ['python','cpp']},latest_finished=latest,current_jobs=jobs,current_fixed_checks={k:v.get('passed') for k,v in public.get('checks',{}).items()},current_saved_tests=public.get('authored_tests',{}).get('passed'),resource_window=resource,error_classification=classified,unexplained_errors=[e for e in classified if e['classification']=='Needs diagnosis'],sources_verified=sources,previous_result_hashes_verified=len(old),production_preserved=True,github_local_head=head,github_remote_head=remote,github_heads_match=head==remote,backup_status=read(G/'.local-backup/status.json'),live_chart=chart,admission_window=read(D/'state/admission-window.json'),attention=read(O/'ATTENTION.json') if (O/'ATTENTION.json').exists() else None,completion=read(O/'COMPLETED.json') if (O/'COMPLETED.json').exists() else None,note='This observer does not restart services, infer, alter models, execute tests, modify trials or assign agents. Source is not part of the immutable scoring/dispatch runtime.')
stamp=datetime.datetime.fromtimestamp(now,zoneinfo.ZoneInfo('America/Chicago')).strftime('%Y%m%d-%H%M%S')
path=D/'state'/('hourly-audit-'+stamp+'.json');path.write_text(json.dumps(report,indent=2))
target=G/'results'/O.name/'reports/decision-campaign-v1/state'/path.name;target.write_bytes(path.read_bytes())
print(json.dumps(dict(report=str(path),balanced=f'{len(balanced)}/48',scores=report['scores'],current=status.get('current'),heartbeat_age=report['heartbeat_age'],resources=resource,unexplained_errors=report['unexplained_errors'],github_heads_match=head==remote,backup_success=report['backup_status'].get('success'),chart_error=chart.get('error'),chart_age=now-chart['checked_at'],attention=report['attention'],completion=report['completion']),indent=2))
