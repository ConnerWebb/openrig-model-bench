import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {buildView,METRICS,scopesFor} from './chart_logic.mjs';

const snapshot=process.argv[2];
const data=JSON.parse(fs.readFileSync(path.join(snapshot,'data.json'),'utf8'));
const visual='/home/cow/.codex/visualizations/2026/11/06/01a1ae52-bfb5-7da3-8f43-d93af96c4eeb/openrig-performance.html';
const template=fs.readFileSync(visual.replace('.html','-template.html'),'utf8');
const logic=fs.readFileSync(new URL('./chart_logic.mjs',import.meta.url),'utf8');
const initial=buildView(data,{revision:'h5.5',scope:'shared',metric:'work'});
assert.deepEqual(initial.observations,{python:{passed:11,total:12},cpp:{passed:10,total:12}});
assert.equal(initial.failures.length,3);
const identity=(model,language)=>data.cases.filter(r=>r.revision==='h5.5'&&r.model===model&&r.language===language&&['py-csv','cpp-buffer'].includes(r.task)&&r.seed===42);
for(let i=0;i<data.model_order.length;i++)for(let j=0;j<2;j++){
 const a=identity(data.model_order[i],['python','cpp'][j]);assert.equal(a.length,1);
 assert.equal(initial.config.rows[i][j+1],a[0].passed?3600/a[0].seconds:0);
}
let checked=0;
for(const revision of data.revisions)for(const scope of scopesFor(data))for(const metric of Object.keys(METRICS)){
 const v=buildView(data,{revision,scope,metric});
 for(const row of v.config.rows)for(const x of row.slice(1))if(x!==null){assert(Number.isFinite(x)&&x>=0);assert(x<=v.config.spec.xDomain[1]);if(metric==='success')assert(x<=1);}
 assert.equal(v.state.revision,revision);assert.equal(v.state.scope,scope);assert.equal(v.state.metric,metric);checked++;
}
const escaped=x=>JSON.stringify(x).replaceAll('<','\\u003c');
let html=template.replace('__INITIAL_CHART__',escaped(initial.config)).replace('__DATA__',escaped(data)).replace('/*__LOGIC__*/',logic);
assert(!html.includes('__INITIAL_CHART__')&&!html.includes('__DATA__')&&!html.includes('/*__LOGIC__*/'));
assert(Buffer.byteLength(html)<1024*1024);
fs.writeFileSync(visual,html);
const examples=[
 {revision:'h5.5',scope:'shared',metric:'work'},
 {revision:'h5.5',scope:'shared',metric:'success'},
 {revision:'h5.4',scope:'all',metric:'time'},
 {revision:'h4',scope:'shared',metric:'ttft'},
 {revision:'h5.5',scope:'shared',metric:'tokens'},
 {revision:'h5.5',scope:'all',metric:'attempts'},
 {revision:'h5.5',scope:'py-queue',metric:'success'},
 {revision:'h5.5',scope:'cpp-queue',metric:'work'},
 {revision:'h5.1',scope:'shared',metric:'work'}
];
for(const [i,state] of examples.entries())fs.writeFileSync(path.join(snapshot,`chart-state-${i}.json`),JSON.stringify(buildView(data,state).config));

// Execute the actual fragment's interaction wiring with a minimal DOM; chart
// geometry/theme are provided by the pinned standard component at display time.
const moduleCode=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1]
 .replace(/import \{ mountChart \} from "[^"\n]+";/,'').replaceAll('export ','');
class Element{
 constructor(){this.children=[];this.listeners={};this.value='';this.isConnected=true;}
 append(...x){this.children.push(...x);}replaceChildren(){this.children=[];}
 addEventListener(n,f){this.listeners[n]=f;}
}
function testWiring(saved){
 const root=new Element(),lookup={};
 for(const id of ['revision','scope','metric','snapshot','status','title','readout','note','failure-count','failures'])lookup['#openrig-perf-'+id]=new Element();
 lookup['#openrig-perf-data']={textContent:JSON.stringify(data)};
 lookup['[data-viz-chart]']={textContent:JSON.stringify(initial.config)};
 lookup['[data-viz-container]']=new Element();
 root.querySelector=s=>{assert(s in lookup,`Unresolved selector ${s}`);return lookup[s];};
 const saves=[],windowListeners={};let chart;
 const sandbox={console,AbortController,document:{getElementById:id=>{assert.equal(id,'openrig-performance-v1');return root;},createElement:()=>new Element(),documentElement:{}},
  window:{openai:{widgetState:saved,setWidgetState:s=>{saves.push(s);return Promise.resolve();}},addEventListener:(n,f)=>windowListeners[n]=f},
  MutationObserver:class{observe(){}disconnect(){}},mountChart:(container,config)=>{assert.equal(container,lookup['[data-viz-container]']);chart={config};return chart;}};
 vm.createContext(sandbox);new vm.Script(moduleCode).runInContext(sandbox);
 assert.equal(saves.length,0,'Never save on initialization/restore');
 lookup['#openrig-perf-revision'].value='h5.4';lookup['#openrig-perf-scope'].value='all';lookup['#openrig-perf-metric'].value='time';
 root.listeners.change({target:lookup['#openrig-perf-metric']});
 assert.equal(chart.config.title,METRICS.time.label);assert(chart.config.description.startsWith('h5.4'));assert.equal(saves.length,1);
 assert(lookup['#openrig-perf-readout'].textContent.includes('26/32'));
 windowListeners['openai:set_globals']({detail:{globals:{widgetState:{modelContent:{openrigPerformance:{revision:'h5.5',scope:'shared',metric:'success'}}}}}});
 assert.equal(chart.config.title,METRICS.success.label);assert.equal(saves.length,1,'No save echoes on host state restoration');
}
testWiring(undefined);
testWiring({modelContent:{openrigPerformance:{revision:'h5.4',scope:'all',metric:'time'}}});
testWiring({modelContent:{openrigPerformance:{revision:'invalid',scope:'invalid',metric:'invalid'}}});
const result={passed:true,control_states_calculated:checked,interaction_scenarios:3,representative_configs:examples.length,html_bytes:Buffer.byteLength(html),visual,data_snapshot:path.join(snapshot,'data.json'),initial_summary:initial.readout};
fs.writeFileSync(path.join(snapshot,'calculation-and-interaction-checks.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
