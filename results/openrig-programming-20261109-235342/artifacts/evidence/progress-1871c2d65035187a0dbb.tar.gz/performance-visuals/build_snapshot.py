"""Read-only chart snapshot. Never controls inference, agents or services."""
import pathlib,json,time,hashlib,collections,datetime,zoneinfo,statistics

O=pathlib.Path(__file__).resolve().parents[2]
CAPTURE=time.time()
STAMP=datetime.datetime.fromtimestamp(CAPTURE,zoneinfo.ZoneInfo('America/Chicago')).strftime('%Y%m%d-%H%M%S')
DEST=pathlib.Path(__file__).resolve().parent/STAMP
DEST.mkdir(exist_ok=False)
LABELS={'next':'Qwen3-Coder-Next 80B','coder30':'Qwen3-Coder 30B','nemo':'Nemotron 3 Nano 30B','q35':'Qwen3.5 35B','devstral':'Devstral Small 2','glm':'GLM 4.7 Flash','q27q4':'Qwen 27B Q4','q9':'Qwen3.5 9B','q27q8':'Qwen 27B Q8','q122':'Qwen3.5 122B','gpt120':'GPT-OSS 120B','gpt20':'GPT-OSS 20B'}
ORDER=['next','coder30','nemo','q35','devstral','glm','q27q4','q9','q27q8','q122','gpt120','gpt20']
rows=[];excluded=collections.Counter();byid=collections.defaultdict(list);hashes={}
for path in sorted((O/'runs').glob('*/result.json')):
    raw=path.read_bytes();r=json.loads(raw)
    if r.get('interrupted'):excluded['interrupted']+=1;continue
    if r.get('phase')!='solo':excluded[r.get('phase','other')]+=1;continue
    if not r.get('finished') or r['finished']>CAPTURE or path.stat().st_mtime>CAPTURE-2:excluded['not_final_at_capture']+=1;continue
    assert set(r['models'])=={'developer'} and r['topology']==1
    revision=r.get('harness_revision') or 'legacy'
    row={'id':r['id'],'directory':path.parent.name,'revision':revision,'model':r['models']['developer'],'language':r['language'],'task':r['task'],'seed':r['seed'],'variant':r.get('variant',0),'passed':bool(r['complete']),'seconds':r['seconds'],'attempts':r.get('attempts'),'resource_limited':r.get('resource_limited'),'started':r['started'],'finished':r['finished'],'reason':str(r.get('last_stage_feedback') or r.get('failure') or '')[:420],'tokens':0,'request_seconds':0.0,'ttft':[],'measured_requests':0,'http_errors':0,'context_rejections':0}
    public=sorted(path.parent.glob('seats/*/control/public-*.json'))
    if public:
        q=json.load(public[-1].open());row['last_public_modes']={k:v.get('passed') for k,v in q.get('checks',{}).items()};row['last_saved_tests']=q.get('authored_tests',{}).get('passed')
    else:row['last_public_modes']={};row['last_saved_tests']=None
    private=sorted(path.parent.glob('attempt-*-suite.json'))
    row['private_acceptance_recorded']=bool(private)
    if private:row['last_private_passed']=json.load(private[-1].open()).get('passed')
    rows.append(row);byid[r['id']].append(row);hashes[str(path.relative_to(O))]=hashlib.sha256(raw).hexdigest()

for line in (O/'events.jsonl').open():
    try:e=json.loads(line)
    except ValueError:continue
    if e.get('kind')!='inference_request':continue
    for row in byid.get(e.get('prefix','').split('/')[0],[]):
        if not row['started']<=e.get('at',0)<=min(row['finished'],CAPTURE):continue
        if e.get('error'):row['http_errors']+=1
        if 'Pinned instructions' in e.get('error',''):row['context_rejections']+=1
        if not e.get('complete'):continue
        value=e.get('first_delivered_seconds')
        if isinstance(value,(int,float)) and value>=0:row['ttft'].append(value)
        usage=e.get('usage') or {};tokens=usage.get('completion_tokens');seconds=e.get('seconds')
        if isinstance(tokens,(int,float)) and tokens>=0 and isinstance(seconds,(int,float)) and seconds>0:
            row['tokens']+=tokens;row['request_seconds']+=seconds;row['measured_requests']+=1

for row in rows:
    row['ttft']= [round(x,6) for x in row['ttft']]
    row['seconds']=round(row['seconds'],6);row['request_seconds']=round(row['request_seconds'],6)
    row.pop('started');row.pop('finished')

revisions=sorted(set(r['revision'] for r in rows),key=lambda r:tuple(int(x) for x in r[1:].split('.')) if r.startswith('h') else (0,),reverse=True)
current=json.load((O/'campaign-status.json').open());hb=json.load((O/'heartbeat.json').open())
data={'schema':1,'captured_at':CAPTURE,'captured_label':datetime.datetime.fromtimestamp(CAPTURE,zoneinfo.ZoneInfo('America/Chicago')).strftime('%b %d, %Y · %I:%M %p %Z'),'active_revision':json.load((O/'active-harness-revision.json').open())['revision'],'running_case_at_capture':current.get('current',current['phase']),'main_pid_at_capture':hb['pid'],'revisions':revisions,'model_order':ORDER,'labels':LABELS,'excluded':dict(excluded),'cases':rows,'snapshot_policy':'Finished solo trials only; interruptions and qualification/probe controls excluded. Revisions never pooled. Resource attribution may be unknown in older evidence. Token rates use complete measured HTTP rounds and include prefill/overhead.'}
(DEST/'data.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
(DEST/'source-result-sha256.json').write_text(json.dumps(hashes,indent=2))
(DEST/'snapshot-note.txt').write_text('Read-only performance snapshot.\n'+data['captured_label']+'\nMain PID: '+str(hb['pid'])+'\nNo services, model settings, fleets or trial files were changed.\n')
print(json.dumps({'directory':str(DEST),'rows':len(rows),'revisions':revisions,'active_case':data['running_case_at_capture'],'main_pid':hb['pid'],'excluded':dict(excluded)}))
