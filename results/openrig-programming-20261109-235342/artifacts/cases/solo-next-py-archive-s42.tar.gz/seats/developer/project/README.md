# ZIP Archive Extractor

This module provides a secure ZIP archive extraction function with comprehensive validation.

## Function

```python
def extract_zip(archive_path: str, outdir: str) -> list[str]:
    """
    Extract a ZIP archive into a NEW directory, returning sorted member file paths.

    Args:
        archive_path: Path to the ZIP file.
        outdir: Path where the archive will be extracted.

    Returns:
        Sorted list of extracted file paths.

    Raises:
        ValueError: If validation fails.
    """
```

## Validation

The function rejects archives containing:
- Absolute paths
- Path traversal components (`..`)
- Backslashes in paths
- Windows drive letters (`C:`, etc.)
- Symbolic links
- Duplicate normalized paths
- Paths that escape the output directory

The output directory must not already exist.

## Usage

```python
from solution import extract_zip

# Extract archive
files = extract_zip('archive.zip', '/tmp/extracted')
print(files)  # ['dir/', 'dir/file.txt', 'other.txt']
```

## Testing

Run tests with:
```bash
python3 -m unittest test_solution
```
