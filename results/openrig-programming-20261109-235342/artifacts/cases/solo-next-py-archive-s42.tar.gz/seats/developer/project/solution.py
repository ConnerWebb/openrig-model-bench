"""ZIP archive extraction with security validation."""

import os
import zipfile
from pathlib import Path


def extract_zip(archive_path: str, outdir: str) -> list[str]:
    """
    Extract a ZIP archive into a NEW directory, returning sorted member file paths.

    Args:
        archive_path: Path to the ZIP file.
        outdir: Path where the archive will be extracted.

    Returns:
        Sorted list of extracted file paths (relative to outdir).

    Raises:
        ValueError: If validation fails (outdir exists, invalid paths, symlinks, etc.).
    """
    # Validate outdir does not exist
    if os.path.exists(outdir):
        raise ValueError(f"Output directory already exists: {outdir}")

    # Read archive and validate all entries before extraction
    with zipfile.ZipFile(archive_path, 'r') as zf:
        members = zf.infolist()
        seen_paths: set[str] = set()
        validated_entries: list[tuple[zipfile.ZipInfo, Path]] = []

        for member in members:
            # Get the filename
            filename = member.filename

            # Reject empty filenames
            if not filename:
                continue

            # Reject backslashes
            if '\\' in filename:
                raise ValueError(f"Invalid path contains backslash: {filename}")

            # Reject absolute paths
            if os.path.isabs(filename):
                raise ValueError(f"Absolute path not allowed: {filename}")

            # Reject drive colon (Windows paths)
            if ':' in filename.split('/')[0] if '/' in filename else filename:
                # Check for drive letter pattern like C:
                first_part = filename.split('/')[0]
                if len(first_part) >= 2 and first_part[1] == ':':
                    raise ValueError(f"Drive letter not allowed: {filename}")

            # Reject .. components
            if '..' in filename.split('/') or '..' in filename.split('\\'):
                raise ValueError(f"Path traversal not allowed: {filename}")

            # Normalize path for duplicate detection
            normalized = os.path.normpath(filename)

            # Reject symlinks (check external_attr for Unix symlink bit)
            if member.external_attr & 0xF0000000 == 0xA0000000:
                raise ValueError(f"Symbolic link not allowed: {filename}")

            # Check for duplicate normalized paths
            if normalized in seen_paths:
                raise ValueError(f"Duplicate path not allowed: {filename}")

            seen_paths.add(normalized)

            # Determine target path
            target_path = Path(outdir) / normalized

            # Ensure target is within outdir (prevent path traversal)
            try:
                target_path.resolve().relative_to(Path(outdir).resolve())
            except ValueError:
                raise ValueError(f"Path escapes output directory: {filename}")

            validated_entries.append((member, target_path))

        # Create output directory (must not exist)
        os.makedirs(outdir)

        # Extract validated entries
        extracted_paths: list[str] = []
        for member, target_path in validated_entries:
            # Use is_dir() method which works on ZipInfo
            if member.is_dir():
                # Create directory
                target_path.mkdir(parents=True, exist_ok=True)
                # Skip directory entries from return value
                continue
            else:
                # Create parent directories
                target_path.parent.mkdir(parents=True, exist_ok=True)
                # Extract file
                with zf.open(member) as source, open(target_path, 'wb') as target:
                    target.write(source.read())
                # Get relative path
                rel_path = target_path.relative_to(Path(outdir))
                extracted_paths.append(str(rel_path))

        # Return sorted paths
        return sorted(extracted_paths)
