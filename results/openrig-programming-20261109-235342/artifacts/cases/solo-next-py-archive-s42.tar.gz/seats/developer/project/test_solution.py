"""Tests for solution.py extract_zip function."""

import os
import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path

from solution import extract_zip


class TestExtractZip(unittest.TestCase):
    """Test cases for extract_zip function."""

    def setUp(self):
        """Create temporary directories for tests."""
        self.test_dir = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.test_dir)

    def _create_zip(self, files: dict[str, bytes]) -> str:
        """Create a ZIP file with the given files."""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for path, content in files.items():
                zf.writestr(path, content)
        return zip_path

    def test_empty_zip(self):
        """Empty ZIP creates empty outdir."""
        zip_path = self._create_zip({})
        outdir = os.path.join(self.test_dir, 'output')
        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, [])
        self.assertTrue(os.path.isdir(outdir))
        self.assertEqual(os.listdir(outdir), [])

    def test_simple_file(self):
        """Extract a single file."""
        zip_path = self._create_zip({'file.txt': b'content'})
        outdir = os.path.join(self.test_dir, 'output')
        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, ['file.txt'])
        self.assertTrue(os.path.isfile(os.path.join(outdir, 'file.txt')))
        with open(os.path.join(outdir, 'file.txt'), 'rb') as f:
            self.assertEqual(f.read(), b'content')

    def test_nested_directories(self):
        """Extract files in nested directories."""
        zip_path = self._create_zip({
            'dir1/file1.txt': b'content1',
            'dir1/dir2/file2.txt': b'content2',
        })
        outdir = os.path.join(self.test_dir, 'output')
        result = extract_zip(zip_path, outdir)
        expected = [
            'dir1/dir2/file2.txt',
            'dir1/file1.txt',
        ]
        self.assertEqual(result, expected)

    def test_directory_entries(self):
        """Directory entries are excluded from return value."""
        zip_path = self._create_zip({
            'dir/': b'',
            'dir/file.txt': b'content',
        })
        outdir = os.path.join(self.test_dir, 'output')
        result = extract_zip(zip_path, outdir)
        self.assertNotIn('dir/', result)
        self.assertIn('dir/file.txt', result)

    def test_utf8_content(self):
        """UTF-8 file contents are preserved."""
        content = 'Hello 世界 🌍'.encode('utf-8')
        zip_path = self._create_zip({'file.txt': content})
        outdir = os.path.join(self.test_dir, 'output')
        extract_zip(zip_path, outdir)
        with open(os.path.join(outdir, 'file.txt'), 'rb') as f:
            self.assertEqual(f.read(), content)

    def test_outdir_exists_raises(self):
        """ValueError if outdir already exists."""
        zip_path = self._create_zip({'file.txt': b'content'})
        outdir = os.path.join(self.test_dir, 'output')
        os.makedirs(outdir)
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_absolute_path_raises(self):
        """ValueError for absolute paths in archive."""
        zip_path = self._create_zip({'/etc/passwd': b'content'})
        outdir = os.path.join(self.test_dir, 'output')
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_path_traversal_raises(self):
        """ValueError for .. components."""
        zip_path = self._create_zip({'../etc/passwd': b'content'})
        outdir = os.path.join(self.test_dir, 'output')
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_backslash_raises(self):
        """ValueError for backslashes in path."""
        zip_path = self._create_zip({'file\\name.txt': b'content'})
        outdir = os.path.join(self.test_dir, 'output')
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_drive_letter_raises(self):
        """ValueError for drive letters."""
        zip_path = self._create_zip({'C:file.txt': b'content'})
        outdir = os.path.join(self.test_dir, 'output')
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_symlink_raises(self):
        """ValueError for symbolic links."""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        with zipfile.ZipFile(zip_path, 'w') as zf:
            # Create a symlink entry manually
            info = zipfile.ZipInfo('link.txt')
            info.create_system = 3  # Unix
            info.external_attr = 0o120777 << 16  # Symlink permission
            zf.writestr(info, 'target.txt')
        outdir = os.path.join(self.test_dir, 'output')
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_duplicate_path_raises(self):
        """ValueError for duplicate normalized paths (case-sensitive on Linux)."""
        # On Linux, file.txt and FILE.TXT are different paths
        # Use the same path with different separators to test normalization
        zip_path = self._create_zip({
            'dir/file.txt': b'content1',
            'dir//file.txt': b'content2',
        })
        outdir = os.path.join(self.test_dir, 'output')
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_no_overwrite(self):
        """ValueError if outdir already exists (no overwrites)."""
        zip_path = self._create_zip({'file.txt': b'new content'})
        outdir = os.path.join(self.test_dir, 'output')
        os.makedirs(outdir)
        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_sorted_output(self):
        """Output paths are sorted."""
        zip_path = self._create_zip({
            'z.txt': b'z',
            'a.txt': b'a',
            'b/c.txt': b'bc',
            'b/a.txt': b'ba',
        })
        outdir = os.path.join(self.test_dir, 'output')
        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, sorted(result))


if __name__ == '__main__':
    unittest.main()
