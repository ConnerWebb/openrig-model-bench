# Ledger

A ledger processing module that validates, deduplicates, and aggregates financial records.

## Overview

The `ledger` module provides a `process()` function that:

- Validates each record (id, category, cents)
- Deduplicates by id (first occurrence wins)
- Filters by minimum cents threshold
- Returns events and totals with sorted category keys

## API

### `process(records, minimum_cents=0)`

Process a list of records and return aggregated results.

**Parameters:**
- `records`: List of dictionaries with keys:
  - `id`: non-empty string (whitespace stripped)
  - `category`: non-empty string (whitespace stripped)
  - `cents`: non-negative integer (booleans invalid)
- `minimum_cents`: filter threshold, default 0 (non-negative integer, booleans invalid)

**Returns:**
```python
{
    'events': [
        {'id': str, 'category': str, 'cents': int},
        ...
    ],
    'totals': {
        'category1': int,
        'category2': int,
        ...
    }
}
```

Totals keys are sorted alphabetically.

**Raises:**
- `ValueError`: On invalid input (missing fields, wrong types, empty strings, negative cents, boolean cents/minimum_cents)

## Example

```python
from ledger import process

records = [
    {'id': 'a', 'category': 'food', 'cents': 100},
    {'id': 'b', 'category': 'transport', 'cents': 200},
    {'id': 'a', 'category': 'entertainment', 'cents': 50},  # duplicate id, ignored
]

result = process(records)
# result['events'] = [
#     {'id': 'a', 'category': 'food', 'cents': 100},
#     {'id': 'b', 'category': 'transport', 'cents': 200},
# ]
# result['totals'] = {'food': 100, 'transport': 200}
```

## Module Structure

- `ledger.py`: Public facade, exports `process()`
- `engine.py`: Implementation with validation logic
- `test_ledger.py`: Unit tests

## Testing

Run tests with:
```bash
python -m unittest test_ledger.py
```
