"""Tests for ledger module."""

import unittest
from ledger import process


class TestLedgerProcess(unittest.TestCase):
    """Tests for process() function."""

    def test_empty_input(self):
        """process([]) returns empty events/totals."""
        result = process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_single_valid_record(self):
        """Single valid record is returned with correct totals."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 100}]
        result = process(records)
        self.assertEqual(result['events'], [{'id': 'a', 'category': 'cat1', 'cents': 100}])
        self.assertEqual(result['totals'], {'cat1': 100})

    def test_whitespace_stripping(self):
        """Whitespace is stripped from id and category."""
        records = [{'id': '  a  ', 'category': '  cat1  ', 'cents': 100}]
        result = process(records)
        self.assertEqual(result['events'][0]['id'], 'a')
        self.assertEqual(result['events'][0]['category'], 'cat1')

    def test_deduplication_first_wins(self):
        """First occurrence of id wins."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 100},
            {'id': 'a', 'category': 'cat2', 'cents': 200},
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'cat1')
        self.assertEqual(result['events'][0]['cents'], 100)

    def test_minimum_cents_filter(self):
        """minimum_cents filters records."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 50},
            {'id': 'b', 'category': 'cat1', 'cents': 150},
        ]
        result = process(records, minimum_cents=100)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 150)
        self.assertEqual(result['totals'], {'cat1': 150})

    def test_totals_sorted_keys(self):
        """Totals keys are sorted."""
        records = [
            {'id': 'a', 'category': 'zebra', 'cents': 100},
            {'id': 'b', 'category': 'apple', 'cents': 100},
            {'id': 'c', 'category': 'mango', 'cents': 100},
        ]
        result = process(records)
        self.assertEqual(list(result['totals'].keys()), ['apple', 'mango', 'zebra'])

    def test_input_not_mutated(self):
        """Input records are not mutated."""
        records = [{'id': 'a', 'category': ' cat1 ', 'cents': 100}]
        original = [dict(r) for r in records]
        process(records)
        self.assertEqual(records, original)

    def test_returns_new_dict_each_time(self):
        """Each call returns a new dict, not shared mutable data."""
        result1 = process([])
        result2 = process([])
        self.assertIsNot(result1, result2)
        self.assertIsNot(result1['events'], result2['events'])
        self.assertIsNot(result1['totals'], result2['totals'])

    def test_invalid_record_not_dict(self):
        """Non-dict record raises ValueError."""
        with self.assertRaises(ValueError):
            process(['not a dict'])

    def test_invalid_record_missing_id(self):
        """Record missing id raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'category': 'cat1', 'cents': 100}])

    def test_invalid_record_id_not_string(self):
        """Record id not string raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 123, 'category': 'cat1', 'cents': 100}])

    def test_invalid_record_id_empty_after_strip(self):
        """Record id empty after stripping raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': '   ', 'category': 'cat1', 'cents': 100}])

    def test_invalid_record_missing_category(self):
        """Record missing category raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'cents': 100}])

    def test_invalid_record_category_not_string(self):
        """Record category not string raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 123, 'cents': 100}])

    def test_invalid_record_category_empty_after_strip(self):
        """Record category empty after stripping raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': '   ', 'cents': 100}])

    def test_invalid_record_missing_cents(self):
        """Record missing cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1'}])

    def test_invalid_record_cents_not_integer(self):
        """Record cents not integer raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1', 'cents': 10.5}])

    def test_invalid_record_cents_boolean(self):
        """Record cents as boolean raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1', 'cents': True}])

    def test_invalid_record_cents_negative(self):
        """Record cents negative raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1', 'cents': -1}])

    def test_invalid_minimum_cents_not_integer(self):
        """minimum_cents not integer raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=10.5)

    def test_invalid_minimum_cents_boolean(self):
        """minimum_cents as boolean raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=True)

    def test_invalid_minimum_cents_negative(self):
        """minimum_cents negative raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=-1)

    def test_multiple_categories_totals(self):
        """Totals sum correctly across multiple categories."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 100},
            {'id': 'b', 'category': 'cat2', 'cents': 200},
            {'id': 'c', 'category': 'cat1', 'cents': 50},
        ]
        result = process(records)
        self.assertEqual(result['totals'], {'cat1': 150, 'cat2': 200})

    def test_zero_minimum_cents_default(self):
        """minimum_cents defaults to 0."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 0}]
        result = process(records)
        self.assertEqual(len(result['events']), 1)

    def test_zero_cents_valid(self):
        """cents=0 is valid."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 0}]
        result = process(records)
        self.assertEqual(result['events'][0]['cents'], 0)


if __name__ == '__main__':
    unittest.main()
