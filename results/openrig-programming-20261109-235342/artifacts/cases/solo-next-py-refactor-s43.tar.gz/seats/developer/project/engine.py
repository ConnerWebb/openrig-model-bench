"""Ledger engine implementation."""

def _validate_record(record):
    """Validate a single record and return normalized record or raise ValueError."""
    if not isinstance(record, dict):
        raise ValueError("Record must be a dictionary")
    
    # Check for exact keys (no extra keys allowed)
    expected_keys = {'id', 'category', 'cents'}
    if set(record.keys()) != expected_keys:
        raise ValueError("Record has unexpected keys")
    
    # Validate id
    record_id = record['id']
    if not isinstance(record_id, str):
        raise ValueError("id must be a string")
    record_id = record_id.strip()
    if not record_id:
        raise ValueError("id must be non-empty after stripping")
    
    # Validate category
    category = record['category']
    if not isinstance(category, str):
        raise ValueError("category must be a string")
    category = category.strip()
    if not category:
        raise ValueError("category must be non-empty after stripping")
    
    # Validate cents
    cents = record['cents']
    # Boolean values are invalid (bool is subclass of int in Python)
    if isinstance(cents, bool):
        raise ValueError("cents must be an integer, not a boolean")
    if not isinstance(cents, int):
        raise ValueError("cents must be an integer")
    if cents < 0:
        raise ValueError("cents must be non-negative")
    
    return {'id': record_id, 'category': category, 'cents': cents}


def _validate_minimum_cents(minimum_cents):
    """Validate minimum_cents parameter."""
    if isinstance(minimum_cents, bool):
        raise ValueError("minimum_cents must be an integer, not a boolean")
    if not isinstance(minimum_cents, int):
        raise ValueError("minimum_cents must be an integer")
    if minimum_cents < 0:
        raise ValueError("minimum_cents must be non-negative")


def process(records, minimum_cents=0):
    """Process records and return events with totals.
    
    Args:
        records: List of record dictionaries with id, category, cents fields
        minimum_cents: Optional filter threshold (nonnegative integer, boolean invalid)
    
    Returns:
        {'events': [...], 'totals': {category: sum_cents}}
    
    Raises:
        ValueError: On invalid input
    """
    # Validate minimum_cents parameter
    _validate_minimum_cents(minimum_cents)
    
    # Validate all records first (including duplicates)
    validated_records = []
    for record in records:
        validated_records.append(_validate_record(record))
    
    # Deduplicate: first occurrence of id wins
    seen_ids = set()
    unique_records = []
    for record in validated_records:
        if record['id'] not in seen_ids:
            seen_ids.add(record['id'])
            unique_records.append(record)
    
    # Filter by minimum_cents
    filtered_records = [r for r in unique_records if r['cents'] >= minimum_cents]
    
    # Calculate totals
    totals = {}
    for record in filtered_records:
        category = record['category']
        if category not in totals:
            totals[category] = 0
        totals[category] += record['cents']
    
    # Sort totals keys
    sorted_totals = dict(sorted(totals.items()))
    
    return {'events': filtered_records, 'totals': sorted_totals}
