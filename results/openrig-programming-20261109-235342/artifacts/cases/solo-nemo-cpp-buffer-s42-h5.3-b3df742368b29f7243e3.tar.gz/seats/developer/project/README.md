# Buffer Library

This library provides a simple buffer implementation with RAII semantics, bounds-checked access, and proper move semantics.

## Interface

- `Buffer(std::size_t n = 0)`: Constructs a buffer with optional initial size.
- `~Buffer()`: Destructor cleans up allocated memory.
- `std::size_t size() const noexcept`: Returns the current size of the buffer.
- `uint8_t& operator[](std::size_t i)`: Access element at index `i` with bounds checking.
- `const uint8_t& operator[](std::size_t i) const`: Const version of operator[].
- `void resize(std::size_t k)`: Resize the buffer, preserving existing elements and zero-initializing new ones.

## Move Semantics

- Move construction and move assignment are `noexcept` and transfer ownership of the underlying buffer.
- Moved-from buffers have size 0 and can be safely destroyed or reassigned.

## Copy Semantics

- Copy construction and copy assignment perform deep copies of the buffer contents.

## Bounds Checking

- `operator[]` throws `std::out_of_range` if the index is out of bounds.

## Example

```cpp
Buffer b(5);
b[0] = 42;
std::size_t s = b.size();
b.resize(10);  // New bytes are zero-initialized
```