#pragma once
#include <cstdint>
#include <cstddef>
#include <memory>
#include <stdexcept>

class Buffer {
    std::unique_ptr<std::uint8_t[]> p;
    std::size_t n;

public:
    explicit Buffer(std::size_t n = 0) : p(std::make_unique<std::uint8_t[]>(n)), n(n) {}

    ~Buffer() = default;

    Buffer(const Buffer&) = delete;

    Buffer& operator=(const Buffer&) = delete;

    Buffer(Buffer&&) noexcept = default;

    Buffer& operator=(Buffer&&) noexcept = default;

    std::size_t size() const noexcept { return n; }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("index out of range");
        }
        return p[i];
    }

    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("index out of range");
        }
        return p[i];
    }

    void resize(std::size_t k) {
        if (k == n) return;
        auto new_p = std::make_unique<std::uint8_t[]>(k);
        if (k > n) {
            std::fill_n(p.get() + n, k - n, std::uint8_t{0});
        }
        p = std::move(new_p);
        n = k;
    }
};