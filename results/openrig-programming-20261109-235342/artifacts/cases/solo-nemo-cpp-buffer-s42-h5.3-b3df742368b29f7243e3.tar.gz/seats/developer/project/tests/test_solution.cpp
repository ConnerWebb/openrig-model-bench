#include <cassert>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

void test_default_construction() {
    Buffer b;
    assert(b.size() == 0u);
}

void test_construction_with_size() {
    Buffer b(10);
    assert(b.size() == 10u);
}

void test_access_operator() {
    Buffer b(5);
    b[0] = 42;
    assert(b[0] == 42);
}

void test_const_operator() {
    const Buffer b(5);
    // We can't directly test assignment, but we can check compilation doesn't fail
    (void)b;
}

void test_out_of_range() {
    Buffer b(5);
    try {
        b[5] = 0;
        assert(false && "Expected out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
    const Buffer cb(5);
    try {
        cb[5];
        assert(false && "Expected out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_resize_preserves_prefix() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5u);
    assert(b[0] == 1u);
    assert(b[1] == 2u);
    assert(b[2] == 3u);
    assert(b[3] == 0u);
    assert(b[4] == 0u);
}

void test_move_construction() {
    Buffer b1(5);
    b1[0] = 10;
    Buffer b2(std::move(b1));
    assert(b1.size() == 0u);
    assert(b2.size() == 5u);
    assert(b2[0] == 10);
}

void test_move_assignment() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(5);
    b2 = std::move(b1);
    assert(b1.size() == 0u);
    assert(b2.size() == 3u);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
}

void test_copy_construction() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(b1);
    assert(b2.size() == 3u);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
}

void test_copy_assignment() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(5);
    b2 = b1;
    assert(b2.size() == 3u);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
}

void test_self_copy_preserves_content() {
    Buffer b(3);
    b[0] = 10;
    b[1] = 20;
    b[2] = 30;
    Buffer b_copy = b;
    assert(b_copy.size() == 3u);
    assert(b_copy[0] == 10);
    assert(b_copy[1] == 20);
    assert(b_copy[2] == 30);
}

void test_self_move_preserves_content() {
    Buffer b(3);
    b[0] = 10;
    b[1] = 20;
    b[2] = 30;
    Buffer b_move = std::move(b);
    assert(b_move.size() == 3u);
    assert(b_move[0] == 10);
    assert(b_move[1] == 20);
    assert(b_move[2] == 30);
}

void test_resize_to_smaller() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    b.resize(3);
    assert(b.size() == 3u);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
}

void test_resize_to_larger_zero_init() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5u);
    assert(b[3] == 0);
    assert(b[4] == 0);
}

int main() {
    test_default_construction();
    test_construction_with_size();
    test_access_operator();
    test_const_operator();
    test_out_of_range();
    test_resize_preserves_prefix();
    test_move_construction();
    test_move_assignment();
    test_copy_construction();
    test_copy_assignment();
    test_self_copy_preserves_content();
    test_self_move_preserves_content();
    test_resize_to_smaller();
    test_resize_to_larger_zero_init();
    return 0;
}