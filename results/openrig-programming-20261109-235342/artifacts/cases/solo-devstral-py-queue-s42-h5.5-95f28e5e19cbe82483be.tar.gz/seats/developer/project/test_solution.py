import unittest
import json
import os
import tempfile
import solution


class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "test.db")
        self.queue = solution.JobQueue(self.db_path, max_attempts=3)
    
    def tearDown(self):
        self.temp_dir.cleanup()
    
    def test_enqueue(self):
        """Test enqueueing jobs."""
        # First enqueue should succeed
        self.assertTrue(self.queue.enqueue("job1", {"data": "test"}))
        
        # Second enqueue with same key should fail
        self.assertFalse(self.queue.enqueue("job1", {"data": "test2"}))
        
        # Different key should succeed
        self.assertTrue(self.queue.enqueue("job2", {"data": "test"}))
    
    def test_claim(self):
        """Test claiming jobs."""
        self.queue.enqueue("job1", {"data": "test"})
        
        # Claim the job
        result = self.queue.claim("worker1", 0, 10)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "job1")
        self.assertEqual(result["attempts"], 1)
        
        # Try to claim again (should succeed - lease expired)
        result2 = self.queue.claim("worker2", 100, 10)
        self.assertIsNotNone(result2)
        self.assertEqual(result2["key"], "job1")
        self.assertEqual(result2["attempts"], 2)
    
    def test_complete(self):
        """Test completing jobs."""
        self.queue.enqueue("job1", {"data": "test"})
        self.queue.claim("worker1", 0, 10)
        
        # Complete with wrong worker should fail
        self.assertFalse(self.queue.complete("job1", "worker2"))
        
        # Complete with correct worker should succeed
        self.assertTrue(self.queue.complete("job1", "worker1"))
        
        # Check status
        status = self.queue.status("job1")
        self.assertEqual(status["state"], "done")
        self.assertEqual(status["attempts"], 1)
    
    def test_fail(self):
        """Test failing jobs."""
        self.queue.enqueue("job1", {"data": "test"})
        self.queue.claim("worker1", 0, 10)
        
        # Fail with wrong worker should fail
        self.assertFalse(self.queue.fail("job1", "worker2"))
        
        # Fail with correct worker should succeed
        self.assertTrue(self.queue.fail("job1", "worker1"))
        
        # Check status - should be queued again
        status = self.queue.status("job1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 1)
    
    def test_max_attempts(self):
        """Test max attempts behavior."""
        self.queue.enqueue("job1", {"data": "test"})
        
        # Claim and fail twice
        self.queue.claim("worker1", 0, 10)
        self.queue.fail("job1", "worker1")
        
        self.queue.claim("worker1", 0, 10)
        self.queue.fail("job1", "worker1")
        
        # Third claim and fail should mark as failed
        self.queue.claim("worker1", 0, 10)
        self.queue.fail("job1", "worker1")
        
        # Check status - should be failed
        status = self.queue.status("job1")
        self.assertEqual(status["state"], "failed")
        self.assertEqual(status["attempts"], 3)
    
    def test_lease_expiry(self):
        """Test lease expiry."""
        self.queue.enqueue("job1", {"data": "test"})
        self.queue.claim("worker1", 0, 10)
        
        # Try to claim with time in the future (lease expired)
        result = self.queue.claim("worker2", 100, 10)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "job1")
        self.assertEqual(result["attempts"], 2)
    
    def test_invalid_arguments(self):
        """Test invalid argument handling."""
        with self.assertRaises(ValueError):
            solution.JobQueue("test.db", max_attempts=0)
        
        with self.assertRaises(ValueError):
            self.queue.enqueue("", {"data": "test"})
        
        with self.assertRaises(ValueError):
            self.queue.claim("", 0, 10)
        
        with self.assertRaises(ValueError):
            self.queue.claim("worker", 0, 0)
        
        with self.assertRaises(ValueError):
            self.queue.complete("", "worker")
        
        with self.assertRaises(ValueError):
            self.queue.fail("", "worker")
        
        with self.assertRaises(ValueError):
            self.queue.status("")
    
    def test_public_case(self):
        """Test the public case from PUBLIC_CASES.json."""
        # Load the public case
        with open("PUBLIC_CASES.json") as f:
            test_cases = json.load(f)
        
        # Use the first test case
        test_case = test_cases[0]
        
        # Run the operations
        result = []
        for op in test_case["driver_input"]["ops"]:
            method_name = op[0]
            args = op[1:]
            result.append(getattr(self.queue, method_name)(*args))
        
        # Check the result matches expected
        expected = test_case["expected"]["value"]
        for i, (actual, exp) in enumerate(zip(result, expected)):
            if exp is None:
                self.assertIsNone(actual, f"Operation {i} failed: expected None, got {actual}")
            elif isinstance(exp, dict):
                self.assertIsInstance(actual, dict, f"Operation {i} failed: expected dict, got {type(actual)}")
                for key in exp:
                    self.assertEqual(actual.get(key), exp[key], f"Operation {i} failed: {key} mismatch")
            else:
                self.assertEqual(actual, exp, f"Operation {i} failed: {actual} != {exp}")


if __name__ == "__main__":
    unittest.main()
