# Job Queue Implementation

This implementation provides a thread-safe job queue system with SQLite backend for persistent storage.

## Features

- **Thread-safe operations**: All queue operations are protected by locks
- **Persistent storage**: Uses SQLite database for job persistence
- **Lease management**: Jobs can be claimed with time-limited leases
- **Retry logic**: Failed jobs can be retried up to a maximum attempt count
- **Concurrent claims**: Multiple workers can claim different jobs simultaneously

## API

### JobQueue class

```python
class JobQueue:
    def __init__(self, db_path: str = ":memory:")
    """Initialize the job queue with the given database path."""

    def enqueue(self, job_id: str, payload: str, max_attempts: int = 3)
    """Add a job to the queue."""

    def claim(self, worker_id: str, lease_seconds: int) -> dict
    """Claim a job for a worker with a lease."""

    def complete(self, job_id: str)
    """Mark a claimed job as completed."""

    def fail(self, job_id: str)
    """Mark a claimed job as failed."""
```

## Implementation Details

### Database Schema

The SQLite database uses the following tables:

- `jobs`: Stores all jobs with their status and attempt count
- `claims`: Tracks which worker has claimed which job and when the lease expires

### Thread Safety

All database operations are wrapped in locks to ensure thread safety:
- `self.lock`: Protects all database operations
- `self.claim_lock`: Protects claim operations specifically

### Error Handling

The implementation validates all input parameters and raises appropriate exceptions:
- `ValueError`: For invalid arguments
- `RuntimeError`: For database errors or inconsistent states

## Testing

The implementation includes comprehensive tests:

- `test_solution.py`: Basic functionality tests
- `test_concurrent.py`: Concurrent claim tests

Run tests with:
```bash
python -m unittest discover -v
```

## Usage Example

```python
from solution import JobQueue

# Create a job queue
queue = JobQueue("jobs.db")

# Enqueue a job
queue.enqueue("job1", "process data", max_attempts=5)

# Worker claims a job
job = queue.claim("worker1", lease_seconds=30)

# Process the job
if job:
    # ... do work ...
    queue.complete(job["job_id"])
else:
    # No jobs available
    pass
```

## Performance Considerations

- Database connections are reused within the same JobQueue instance
- Locks are held only for the duration of database operations
- Batch operations are used where possible to minimize database round-trips
