import sqlite3
import json
import time
from typing import Any, Dict, Optional


class JobQueue:
    """A job queue implementation using SQLite for concurrent access."""
    
    def __init__(self, path: str, max_attempts: int = 3):
        """Initialize the job queue.
        
        Args:
            path: Path to the SQLite database file
            max_attempts: Maximum number of attempts for a job (must be positive)
        
        Raises:
            ValueError: If max_attempts is not a positive integer
        """
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()
    
    def _init_db(self):
        """Initialize the database schema."""
        with sqlite3.connect(self.path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL,
                    attempts INTEGER NOT NULL,
                    owner TEXT,
                    lease_until REAL,
                    created_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_state ON jobs(state, created_at)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_lease ON jobs(lease_until) WHERE lease_until IS NOT NULL"
            )
            conn.commit()
    
    def enqueue(self, key: str, payload: Any) -> bool:
        """Add a job to the queue if the key doesn't already exist.
        
        Args:
            key: Unique job key
            payload: JSON-compatible payload data
        
        Returns:
            True if the job was enqueued, False if the key already exists
        
        Raises:
            ValueError: If key is empty or payload is not JSON-serializable
        """
        if not key:
            raise ValueError("key cannot be empty")
        
        try:
            payload_str = json.dumps(payload)
        except (TypeError, ValueError) as e:
            raise ValueError("payload must be JSON-serializable") from e
        
        now = time.time()
        with sqlite3.connect(self.path) as conn:
            # Check if key already exists
            cursor = conn.execute(
                "SELECT 1 FROM jobs WHERE key = ?",
                (key,),
            )
            if cursor.fetchone() is not None:
                return False
            
            conn.execute(
                """
                INSERT INTO jobs (key, payload, state, attempts, owner, lease_until, created_at)
                VALUES (?, ?, 'queued', 0, NULL, NULL, ?)
                """,
                (key, payload_str, now),
            )
            return True
    
    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        """Claim a job for processing.
        
        Args:
            worker: Worker identifier
            now: Current timestamp
            lease: Lease duration in seconds (must be positive)
        
        Returns:
            Dictionary with job details if successful, None otherwise
        
        Raises:
            ValueError: If worker is empty, key is empty, or lease is not positive
        """
        if not worker:
            raise ValueError("worker cannot be empty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        
        lease_until = now + lease
        with sqlite3.connect(self.path, timeout=30.0) as conn:
            conn.execute("BEGIN IMMEDIATE")
            
            try:
                # Find the oldest job that is either queued or has expired lease
                cursor = conn.execute(
                    """
                    SELECT key, payload, attempts
                    FROM jobs
                    WHERE state IN ('queued', 'leased')
                      AND (state = 'queued' OR lease_until <= ?)
                      AND attempts < ?
                    ORDER BY created_at ASC
                    LIMIT 1
                    """,
                    (now, self.max_attempts),
                )
                row = cursor.fetchone()
                
                if not row:
                    conn.execute("ROLLBACK")
                    return None
                
                key, payload_str, attempts = row
                
                # Check if this is the last attempt
                is_last_attempt = attempts + 1 >= self.max_attempts
                
                # Update the job state based on whether it's the last attempt
                if is_last_attempt:
                    # Mark as failed immediately
                    conn.execute(
                        """
                        UPDATE jobs
                        SET state = 'failed', attempts = attempts + 1
                        WHERE key = ? AND state IN ('queued', 'leased')
                          AND (state = 'queued' OR lease_until <= ?)
                          AND attempts < ?
                        """,
                        (key, now, self.max_attempts),
                    )
                    
                    if conn.total_changes == 0:
                        conn.execute("ROLLBACK")
                        return None
                    
                    payload = json.loads(payload_str)
                    conn.execute("COMMIT")
                    return {
                        "key": key,
                        "payload": payload,
                        "attempts": attempts + 1,
                    }
                else:
                    # Update the job to leased state
                    conn.execute(
                        """
                        UPDATE jobs
                        SET state = 'leased', attempts = attempts + 1, 
                            owner = ?, lease_until = ?
                        WHERE key = ? AND state IN ('queued', 'leased')
                          AND (state = 'queued' OR lease_until <= ?)
                          AND attempts < ?
                        """,
                        (worker, lease_until, key, now, self.max_attempts),
                    )
                    
                    if conn.total_changes == 0:
                        conn.execute("ROLLBACK")
                        return None
                    
                    payload = json.loads(payload_str)
                    conn.execute("COMMIT")
                    return {
                        "key": key,
                        "payload": payload,
                        "attempts": attempts + 1,
                    }
            except Exception:
                conn.execute("ROLLBACK")
                raise
    
    def complete(self, key: str, worker: str) -> bool:
        """Mark a job as completed.
        
        Args:
            key: Job key
            worker: Worker identifier (must match current owner)
        
        Returns:
            True if the job was completed, False otherwise
        
        Raises:
            ValueError: If key or worker is empty
        """
        if not key or not worker:
            raise ValueError("key and worker cannot be empty")
        
        with sqlite3.connect(self.path) as conn:
            cursor = conn.execute(
                """
                SELECT state, owner
                FROM jobs
                WHERE key = ?
                """,
                (key,),
            )
            row = cursor.fetchone()
            
            if not row:
                return False
            
            state, owner = row
            
            # Job must be leased and owned by the specified worker
            if state != "leased" or owner != worker:
                return False
            
            # Mark as done
            conn.execute(
                "UPDATE jobs SET state = 'done' WHERE key = ?",
                (key,),
            )
            return True
    
    def fail(self, key: str, worker: str) -> bool:
        """Mark a job as failed and requeue it if attempts allow.
        
        Args:
            key: Job key
            worker: Worker identifier (must match current owner)
        
        Returns:
            True if the job was failed, False otherwise
        
        Raises:
            ValueError: If key or worker is empty
        """
        if not key or not worker:
            raise ValueError("key and worker cannot be empty")
        
        with sqlite3.connect(self.path) as conn:
            cursor = conn.execute(
                """
                SELECT state, owner, attempts
                FROM jobs
                WHERE key = ?
                """,
                (key,),
            )
            row = cursor.fetchone()
            
            if not row:
                return False
            
            state, owner, attempts = row
            
            # Job must be leased and owned by the specified worker
            if state != "leased" or owner != worker:
                return False
            
            # If max attempts reached, mark as failed
            if attempts >= self.max_attempts:
                conn.execute(
                    "UPDATE jobs SET state = 'failed' WHERE key = ?",
                    (key,),
                )
                return True
            
            # Otherwise, requeue the job
            conn.execute(
                """
                UPDATE jobs
                SET state = 'queued', owner = NULL, lease_until = NULL
                WHERE key = ?
                """,
                (key,),
            )
            return True
    
    def status(self, key: str) -> Optional[Dict[str, str]]:
        """Get the status of a job.
        
        Args:
            key: Job key
        
        Returns:
            Dictionary with state and attempts if the job exists, None otherwise
        
        Raises:
            ValueError: If key is empty
        """
        if not key:
            raise ValueError("key cannot be empty")
        
        with sqlite3.connect(self.path) as conn:
            cursor = conn.execute(
                """
                SELECT state, attempts
                FROM jobs
                WHERE key = ?
                """,
                (key,),
            )
            row = cursor.fetchone()
            
            if not row:
                return None
            
            state, attempts = row
            return {"state": state, "attempts": attempts}
