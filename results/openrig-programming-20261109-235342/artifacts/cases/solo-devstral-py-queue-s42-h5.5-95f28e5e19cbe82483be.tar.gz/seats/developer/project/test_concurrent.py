import unittest
import tempfile
import os
import multiprocessing
from solution import JobQueue


def claim_job(args):
    """Helper function for concurrent testing."""
    db_path, i = args
    q = JobQueue(db_path, max_attempts=3)
    result = q.claim(f"worker{i}", 100.0, 10.0)
    return result


class TestConcurrent(unittest.TestCase):
    def test_concurrent_claims(self):
        """Test that concurrent claims work correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "queue.db")
            q = JobQueue(db_path, max_attempts=3)
            
            # Enqueue some jobs
            for i in range(12):
                q.enqueue(str(i), i)
            
            with multiprocessing.get_context('fork').Pool(processes=8) as pool:
                claims = pool.map(claim_job, [(db_path, i) for i in range(20)])
            
            # Filter out None results
            successful_claims = [c for c in claims if c is not None]
            
            # Should have claimed all 12 jobs
            self.assertEqual(len(successful_claims), 12)
            
            # Check that all keys are present
            claimed_keys = sorted([c['key'] for c in successful_claims], key=int)
            self.assertEqual(claimed_keys, [str(i) for i in range(12)])


if __name__ == '__main__':
    unittest.main()
