#pragma once
#include <map>
#include <string>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <limits>
#include <vector>
#include <cctype>

inline std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> out;
    
    // State for CSV parsing
    bool in_quotes = false;
    std::string current_field;
    std::vector<std::string> row;
    bool header_read = false;
    
    auto trim = [](std::string s) {
        auto first = s.find_first_not_of(" \t\r");
        if (first == std::string::npos) return std::string();
        auto last = s.find_last_not_of(" \t\r");
        return s.substr(first, last - first + 1);
    };
    
    auto parse_int64 = [](const std::string& s) -> std::int64_t {
        if (s.empty()) throw std::invalid_argument("empty number");
        std::size_t pos = 0;
        if (s[0] == '+' || s[0] == '-') pos = 1;
        if (pos >= s.size()) throw std::invalid_argument("number format");
        for (std::size_t i = pos; i < s.size(); ++i) {
            if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
                throw std::invalid_argument("number format");
            }
        }
        std::size_t end_pos = 0;
        std::int64_t val = std::stoll(s, &end_pos);
        if (end_pos != s.size()) throw std::invalid_argument("number format");
        return val;
    };
    
    auto process_row = [&]() {
        // Push the last field
        row.push_back(current_field);
        current_field.clear();
        
        // If row is empty (just a newline with no content), ignore it
        if (row.empty() || (row.size() == 1 && row[0].empty())) {
            row.clear();
            return;
        }
        
        if (!header_read) {
            // Validate header
            if (row.size() != 2) throw std::invalid_argument("header columns");
            std::string h0 = trim(row[0]);
            std::string h1 = trim(row[1]);
            if (h0 != "category" || h1 != "amount") {
                throw std::invalid_argument("header");
            }
            header_read = true;
            row.clear();
            return;
        }
        
        // Data row
        if (row.size() != 2) throw std::invalid_argument("columns");
        
        std::string category = trim(row[0]);
        std::string amount_str = trim(row[1]);
        
        if (category.empty()) throw std::invalid_argument("empty category");
        if (amount_str.empty()) throw std::invalid_argument("empty amount");
        
        std::int64_t amount = parse_int64(amount_str);
        
        // Check for overflow before accumulation
        std::int64_t current = out[category];
        if ((amount > 0 && current > std::numeric_limits<std::int64_t>::max() - amount) ||
            (amount < 0 && current < std::numeric_limits<std::int64_t>::min() - amount)) {
            throw std::invalid_argument("overflow");
        }
        
        out[category] = current + amount;
        row.clear();
    };
    
    int ch;
    while ((ch = in.get()) != EOF) {
        char c = static_cast<char>(ch);
        
        if (in_quotes) {
            if (c == '"') {
                // Check for escaped quote
                int next = in.peek();
                if (next == '"') {
                    in.get(); // consume the second quote
                    current_field += '"';
                } else {
                    in_quotes = false;
                }
            } else {
                current_field += c;
            }
        } else {
            if (c == '"') {
                // Start quoted field - only valid at start of field
                if (!current_field.empty()) {
                    throw std::invalid_argument("quote in middle");
                }
                in_quotes = true;
            } else if (c == ',') {
                row.push_back(current_field);
                current_field.clear();
            } else if (c == '\n') {
                process_row();
            } else if (c == '\r') {
                // Skip \r, handle \n next
            } else {
                current_field += c;
            }
        }
    }
    
    // Handle final field/row
    if (in_quotes) {
        throw std::invalid_argument("unclosed quote");
    }
    if (!current_field.empty() || !row.empty()) {
        process_row();
    }
    
    if (!header_read) {
        throw std::invalid_argument("no header");
    }
    
    return out;
}
