# CSV Parser Module

This module provides a CSV parser that aggregates values by category.

## API

```cpp
#include "parser.hpp"

std::map<std::string, std::int64_t> aggregate(std::istream& in);
```

Parses CSV data from the input stream and returns a map of category -> accumulated amount.

### CSV Format

- Header must be exactly: `category,amount`
- Fields can be quoted with double quotes (`"`)
- Quoted fields can contain commas, newlines, and escaped quotes (`""`)
- Outer whitespace (spaces, tabs, CR) is stripped from fields
- Empty physical records are ignored
- Amount is a signed 64-bit integer (optional `+` or `-` prefix)

### Error Handling

Throws `std::invalid_argument` for:
- Wrong header
- Wrong number of columns
- Empty category or amount
- Invalid number format
- Overflow during accumulation
- Malformed quoting (unclosed quote, quote in middle of unquoted field)

## Usage

```cpp
#include "parser.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::string csv = R"(
category,amount
food,100
rent,500
food,50
)";
    
    std::istringstream ss(csv);
    auto result = aggregate(ss);
    
    for (const auto& [category, amount] : result) {
        std::cout << category << ": " << amount << "\n";
    }
    // Output:
    // food: 150
    // rent: 500
}
```

## Testing

Run the test suite:
```bash
clang++ -std=c++20 -I. test_parser.cpp -o test_parser && ./test_parser
```
