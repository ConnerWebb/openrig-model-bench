# Buffer Library

This library provides a simple buffer implementation with RAII semantics, bounds-checked access, and proper move semantics.

## Interface

- `Buffer(std::size_t n = 0)`: Constructs a buffer with optional initial size.
- `~Buffer()`: Destructor; cleans up allocated memory.
- `std::size_t size() const noexcept`: Returns the current size of the buffer.
- `uint8_t& operator[](std::size_t i)`: Mutable access with bounds checking.
- `const uint8_t& operator[](std::size_t i) const`: Const access with bounds checking.
- `void resize(std::size_t k)`: Resizes the buffer, preserving existing data.

## Guarantees

- No memory leaks.
- No double frees.
- No stale reads.
- No undefined behavior.
- Move operations are `noexcept`.
- Copy operations are deleted to enforce unique ownership.

## Testing

Run `run_tests` to execute the test suite. Ensure all tests pass before submission.