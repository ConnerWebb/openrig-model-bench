#include <cassert>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

// Helper function to compare buffers
bool equal_buffers(const Buffer& a, const Buffer& b) {
    if (a.size() != b.size()) return false;
    for (std::size_t i = 0; i < a.size(); ++i) {
        if (a[i] != b[i]) return false;
    }
    return true;
}

// Test default construction
void test_default_construction() {
    Buffer b;
    assert(b.size() == 0u);
}

// Test construction with size
void test_construction_with_size() {
    Buffer b(10);
    assert(b.size() == 10u);
}

// Test mutable operator[]
void test_mutable_operator() {
    Buffer b(5);
    b[0] = 42;
    assert(b[0] == 42);
}

// Test const operator[]
void test_const_operator() {
    const Buffer b(5);
    uint8_t val = b[0];  // Should compile
    (void)val;
}

// Test out of range access
void test_out_of_range() {
    Buffer b(5);
    try {
        b[5] = 0;
        assert(false && "Expected out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
    const Buffer cb(5);
    try {
        cb[5];
        assert(false && "Expected out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

// Test resize preserving prefix
void test_resize_preserve() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b.resize(10);
    assert(b.size() == 10u);
    assert(b[0] == 1);
    assert(b[1] == 2);
}

// Test resize smaller
void test_resize_smaller() {
    Buffer b(10);
    b[0] = 1;
    b[1] = 2;
    b.resize(3);
    assert(b.size() == 3u);
    assert(b[0] == 1);
    assert(b[1] == 2);
}

// Test move construction
void test_move_construction() {
    Buffer b1(5);
    b1[0] = 42;
    Buffer b2(std::move(b1));
    assert(b1.size() == 5u);  // b1 should retain original size after move
    assert(b2.size() == 5u);
    assert(b2[0] == 42);
}

// Test move assignment
void test_move_assignment() {
    Buffer b1(5);
    b1[0] = 42;
    Buffer b2(10);
    b2 = std::move(b1);
    assert(b1.size() == 5u);  // b1 should retain original size after move
    assert(b2.size() == 5u);
    assert(b2[0] == 42);
}

// Test copy construction is deleted
void test_copy_construction_deleted() {
    Buffer b1(5);
    // This should not compile, but we can't test that at runtime
    // Just ensure it doesn't accidentally compile
    volatile Buffer* ptr = nullptr;
    (void)ptr;
}

// Test copy assignment is deleted
void test_copy_assignment_deleted() {
    Buffer b1(5);
    // This should not compile
    volatile Buffer* ptr = nullptr;
    (void)ptr;
}

int main() {
    test_default_construction();
    test_construction_with_size();
    test_mutable_operator();
    test_const_operator();
    test_out_of_range();
    test_resize_preserve();
    test_resize_smaller();
    test_move_construction();
    test_move_assignment();
    test_copy_construction_deleted();
    test_copy_assignment_deleted();
    return 0;
}