# Ledger Processing System

This system processes financial records and generates event summaries with category totals.

## Function: `process(records, minimum_cents=0)`

Processes a list of records and returns normalized events with category totals.

### Parameters:
- `records`: List of record dictionaries with keys:
  - `id`: Non-empty string (will be stripped)
  - `category`: Non-empty string (will be stripped)
  - `cents`: Non-negative integer
- `minimum_cents`: Minimum cents threshold for inclusion (default: 0)

### Returns:
A dictionary with:
- `events`: List of normalized records in input order (first occurrence wins)
- `totals`: Dictionary with category totals, keys sorted alphabetically

### Validation:
- All inputs are validated
- Empty or invalid records raise `ValueError`
- Duplicate IDs are skipped (first occurrence wins)
- Records with `cents` < `minimum_cents` are filtered out
- No mutation of input data

### Example:
```python
result = process([
    {'id': ' 1 ', 'category': ' a ', 'cents': 100},
    {'id': ' 2 ', 'category': ' b ', 'cents': 50}
])
```