def process(records, minimum_cents=0):
    """
    Process records and return events with totals.
    
    Args:
        records: List of record dictionaries with 'id', 'category', 'cents'
        minimum_cents: Minimum cents threshold for inclusion (default 0)
        
    Returns:
        Dictionary with 'events' and 'totals' keys
        
    Raises:
        ValueError: If input validation fails
    """
    # Validate minimum_cents
    if not isinstance(minimum_cents, int) or minimum_cents < 0:
        raise ValueError("minimum_cents must be a non-negative integer")
    
    # Validate records is a list
    if not isinstance(records, list):
        raise ValueError("records must be a list")
    
    # Track seen IDs to handle deduplication
    seen_ids = set()
    
    # Store results
    events = []
    totals = {}
    
    # Process each record
    for record in records:
        # Validate record structure
        if not isinstance(record, dict):
            raise ValueError("Each record must be a dictionary")
            
        # Check for extra fields
        if len(record) != 3 or 'id' not in record or 'category' not in record or 'cents' not in record:
            raise ValueError("Each record must have exactly 'id', 'category', and 'cents' fields")
            
        # Validate and normalize id
        id_val = record['id']
        if not isinstance(id_val, str):
            raise ValueError("id must be a string")
        id_val = id_val.strip()
        if not id_val:
            raise ValueError("id cannot be empty")
            
        # Validate and normalize category
        category = record['category']
        if not isinstance(category, str):
            raise ValueError("category must be a string")
        category = category.strip()
        if not category:
            raise ValueError("category cannot be empty")
            
        # Validate and normalize cents
        cents = record['cents']
        # Check that it's an integer and not a boolean (bool is subclass of int in Python)
        if not isinstance(cents, int) or cents < 0 or type(cents) == bool:
            raise ValueError("cents must be a non-negative integer")
            
        # Skip if ID already seen (first occurrence wins)
        if id_val in seen_ids:
            continue
            
        # Add to seen IDs
        seen_ids.add(id_val)
        
        # Apply minimum_cents filter
        if cents >= minimum_cents:
            # Normalize record for output
            normalized_record = {
                'id': id_val,
                'category': category,
                'cents': cents
            }
            events.append(normalized_record)
            
            # Update totals
            if category not in totals:
                totals[category] = 0
            totals[category] += cents
    
    # Sort totals keys
    sorted_totals = dict(sorted(totals.items()))
    
    return {
        'events': events,
        'totals': sorted_totals
    }