import unittest
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine import process

class TestLedgerProcess(unittest.TestCase):
    
    def test_basic_processing(self):
        records = [
            {'id': ' 8 ', 'category': ' c ', 'cents': 1},
            {'id': ' 4 ', 'category': ' a ', 'cents': 96}
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['totals']['a'], 96)
        self.assertEqual(result['totals']['c'], 1)
    
    def test_minimum_cents_filtering(self):
        records = [
            {'id': ' 8 ', 'category': ' c ', 'cents': 1},
            {'id': ' 4 ', 'category': ' a ', 'cents': 96}
        ]
        result = process(records, minimum_cents=50)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 96)
        self.assertEqual(result['totals']['a'], 96)
    
    def test_duplicate_id_handling(self):
        records = [
            {'id': ' 1 ', 'category': ' a ', 'cents': 10},
            {'id': ' 1 ', 'category': ' b ', 'cents': 20}  # Should be skipped
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], '1')
        self.assertEqual(result['events'][0]['category'], 'a')
        self.assertEqual(result['events'][0]['cents'], 10)
        self.assertEqual(result['totals']['a'], 10)
    
    def test_boolean_cents_rejection(self):
        with self.assertRaises(ValueError):
            process([{'id': 'x', 'category': 'a', 'cents': True}])
    
    def test_extra_fields_rejection(self):
        with self.assertRaises(ValueError):
            process([{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}])

if __name__ == '__main__':
    unittest.main()