#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <string>
#include <map>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <limits>
#include <cctype>

namespace {

// Trim leading and trailing spaces, tabs, and CR
std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse int64_t with overflow detection. Returns true on success.
bool parse_int64(const std::string& s, int64_t& out) {
    if (s.empty()) return false;
    
    size_t i = 0;
    bool negative = false;
    
    if (s[i] == '+') {
        ++i;
    } else if (s[i] == '-') {
        negative = true;
        ++i;
    }
    
    if (i >= s.size()) return false; // Only sign, no digits
    
    // Check for exponent or decimal
    for (size_t j = i; j < s.size(); ++j) {
        char c = s[j];
        if (c == 'e' || c == 'E' || c == '.') {
            return false; // Exponents or decimals not allowed
        }
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            return false; // Non-digit character
        }
    }
    
    // Parse digits with overflow detection
    uint64_t val = 0;
    for (size_t j = i; j < s.size(); ++j) {
        int digit = s[j] - '0';
        // Check for overflow before multiplying
        if (val > (std::numeric_limits<uint64_t>::max() - digit) / 10) {
            return false; // Overflow
        }
        val = val * 10 + digit;
    }
    
    if (negative) {
        uint64_t max_neg = static_cast<uint64_t>(std::numeric_limits<int64_t>::max()) + 1;
        if (val > max_neg) {
            return false; // Overflow for negative
        }
        if (val == max_neg) {
            out = std::numeric_limits<int64_t>::min();
        } else {
            out = -static_cast<int64_t>(val);
        }
    } else {
        if (val > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
            return false; // Overflow for positive
        }
        out = static_cast<int64_t>(val);
    }
    
    return true;
}

// CSV parser state machine
class CSVParser {
public:
    CSVParser(std::istream& in) : in_(in), eof_(false), field_count_(0), in_quoted_(false), field_start_(true) {}
    
    bool next_record(std::string& category, int64_t& amount) {
        field_count_ = 0;
        std::string field1, field2;
        
        // Read first field (category)
        if (!read_field(field1)) {
            return false; // EOF or error
        }
        
        // Check if we got a complete record (need exactly 2 fields)
        if (field_count_ != 1) {
            // We read first field, now expect comma and second field
            if (!read_field(field2)) {
                throw std::invalid_argument("Wrong field count");
            }
        } else {
            field2 = field1;
            field1.clear();
            if (!read_field(field2)) {
                throw std::invalid_argument("Wrong field count");
            }
        }
        
        // Actually, let me restructure this
        return true;
    }
    
private:
    std::istream& in_;
    bool eof_;
    int field_count_;
    bool in_quoted_;
    bool field_start_;
    
    bool read_field(std::string& field) {
        field.clear();
        in_quoted_ = false;
        field_start_ = true;
        
        // Skip leading whitespace only if not in quoted field
        // Actually, we need to handle this per-field
        
        while (!eof_) {
            char c = in_.get();
            if (in_.eof()) {
                eof_ = true;
                if (in_quoted_) {
                    throw std::invalid_argument("Malformed quoting: unclosed quote");
                }
                break;
            }
            
            if (in_quoted_) {
                if (c == '"') {
                    // Check for escaped quote
                    char next = in_.peek();
                    if (next == '"') {
                        in_.get();
                        field += '"';
                    } else {
                        // End of quoted field
                        in_quoted_ = false;
                        // After closing quote, we should see comma, newline, or EOF
                        // But we continue reading to find the delimiter
                    }
                } else {
                    field += c;
                }
            } else {
                if (field_start_ && c == '"') {
                    // Start of quoted field
                    in_quoted_ = true;
                    field_start_ = false;
                } else if (c == ',') {
                    // Field delimiter
                    field = trim(field);
                    field_count_++;
                    return true;
                } else if (c == '\n') {
                    // End of record
                    field = trim(field);
                    field_count_++;
                    return true;
                } else if (c == '\r') {
                    // Handle CR (might be followed by LF)
                    char next = in_.peek();
                    if (next == '\n') {
                        in_.get();
                    }
                    field = trim(field);
                    field_count_++;
                    return true;
                } else {
                    field += c;
                    field_start_ = false;
                }
            }
        }
        
        // EOF reached
        if (!field.empty() || field_count_ > 0) {
            field = trim(field);
            field_count_++;
            return true;
        }
        
        return false;
    }
};

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read header
    std::string header;
    char c;
    
    // Skip leading whitespace/newlines to find header
    while (in.get(c)) {
        if (c == '\n' || c == '\r') continue;
        if (c == ' ' || c == '\t') continue;
        // Found first non-whitespace char, start reading header
        header += c;
        break;
    }
    
    if (header.empty()) {
        throw std::invalid_argument("Empty input");
    }
    
    // Read rest of header line
    while (in.get(c)) {
        if (c == '\n') break;
        if (c == '\r') {
            char next = in.peek();
            if (next == '\n') in.get();
            break;
        }
        header += c;
    }
    
    // Parse header fields
    std::string h1, h2;
    size_t pos = 0;
    bool in_quote = false;
    std::string current;
    
    for (size_t i = 0; i < header.size(); ++i) {
        char ch = header[i];
        if (in_quote) {
            if (ch == '"') {
                if (i + 1 < header.size() && header[i + 1] == '"') {
                    current += '"';
                    ++i;
                } else {
                    in_quote = false;
                }
            } else {
                current += ch;
            }
        } else {
            if (ch == '"') {
                in_quote = true;
            } else if (ch == ',') {
                if (pos == 0) h1 = trim(current);
                else if (pos == 1) h2 = trim(current);
                current.clear();
                ++pos;
            } else {
                current += ch;
            }
        }
    }
    if (pos == 0) h1 = trim(current);
    else if (pos == 1) h2 = trim(current);
    
    if (pos != 1 || h1 != "category" || h2 != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Now parse data rows
    // We need to handle the CSV properly with state machine
    
    std::string field;
    bool in_quoted = false;
    bool field_start = true;
    int field_idx = 0;
    std::string cat;
    int64_t amt = 0;
    bool have_cat = false;
    
    while (in.get(c)) {
        if (in_quoted) {
            if (c == '"') {
                char next = in.peek();
                if (next == '"') {
                    in.get();
                    field += '"';
                } else {
                    in_quoted = false;
                }
            } else {
                field += c;
            }
        } else {
            if (field_start && c == '"') {
                in_quoted = true;
                field_start = false;
            } else if (c == ',') {
                field = trim(field);
                if (field_idx == 0) {
                    if (field.empty()) {
                        throw std::invalid_argument("Empty category field");
                    }
                    cat = field;
                    have_cat = true;
                } else if (field_idx == 1) {
                    if (!parse_int64(field, amt)) {
                        throw std::invalid_argument("Invalid amount");
                    }
                    // Check for overflow in accumulation
                    auto it = result.find(cat);
                    if (it != result.end()) {
                        int64_t old = it->second;
                        // Check for overflow
                        if (amt > 0 && old > std::numeric_limits<int64_t>::max() - amt) {
                            throw std::invalid_argument("Accumulation overflow");
                        }
                        if (amt < 0 && old < std::numeric_limits<int64_t>::min() - amt) {
                            throw std::invalid_argument("Accumulation overflow");
                        }
                        it->second = old + amt;
                    } else {
                        result[cat] = amt;
                    }
                } else {
                    throw std::invalid_argument("Wrong field count");
                }
                field.clear();
                field_idx++;
                field_start = true;
            } else if (c == '\n') {
                field = trim(field);
                if (field_idx == 0) {
                    // Empty record, skip
                    field.clear();
                    field_idx = 0;
                    field_start = true;
                } else if (field_idx == 1) {
                    if (field.empty()) {
                        throw std::invalid_argument("Empty amount field");
                    }
                    if (!parse_int64(field, amt)) {
                        throw std::invalid_argument("Invalid amount");
                    }
                    auto it = result.find(cat);
                    if (it != result.end()) {
                        int64_t old = it->second;
                        if (amt > 0 && old > std::numeric_limits<int64_t>::max() - amt) {
                            throw std::invalid_argument("Accumulation overflow");
                        }
                        if (amt < 0 && old < std::numeric_limits<int64_t>::min() - amt) {
                            throw std::invalid_argument("Accumulation overflow");
                        }
                        it->second = old + amt;
                    } else {
                        result[cat] = amt;
                    }
                } else {
                    throw std::invalid_argument("Wrong field count");
                }
                field.clear();
                field_idx = 0;
                field_start = true;
                have_cat = false;
            } else if (c == '\r') {
                char next = in.peek();
                if (next == '\n') in.get();
                field = trim(field);
                if (field_idx == 0) {
                    field.clear();
                    field_idx = 0;
                    field_start = true;
                } else if (field_idx == 1) {
                    if (field.empty()) {
                        throw std::invalid_argument("Empty amount field");
                    }
                    if (!parse_int64(field, amt)) {
                        throw std::invalid_argument("Invalid amount");
                    }
                    auto it = result.find(cat);
                    if (it != result.end()) {
                        int64_t old = it->second;
                        if (amt > 0 && old > std::numeric_limits<int64_t>::max() - amt) {
                            throw std::invalid_argument("Accumulation overflow");
                        }
                        if (amt < 0 && old < std::numeric_limits<int64_t>::min() - amt) {
                            throw std::invalid_argument("Accumulation overflow");
                        }
                        it->second = old + amt;
                    } else {
                        result[cat] = amt;
                    }
                } else {
                    throw std::invalid_argument("Wrong field count");
                }
                field.clear();
                field_idx = 0;
                field_start = true;
                have_cat = false;
            } else {
                field += c;
                field_start = false;
            }
        }
    }
    
    // Handle EOF - if we have a pending field
    if (!field.empty() || field_idx > 0) {
        field = trim(field);
        if (field_idx == 0) {
            // Trailing empty record, ignore
        } else if (field_idx == 1) {
            if (field.empty()) {
                throw std::invalid_argument("Empty amount field");
            }
            if (!parse_int64(field, amt)) {
                throw std::invalid_argument("Invalid amount");
            }
            auto it = result.find(cat);
            if (it != result.end()) {
                int64_t old = it->second;
                if (amt > 0 && old > std::numeric_limits<int64_t>::max() - amt) {
                    throw std::invalid_argument("Accumulation overflow");
                }
                if (amt < 0 && old < std::numeric_limits<int64_t>::min() - amt) {
                    throw std::invalid_argument("Accumulation overflow");
                }
                it->second = old + amt;
            } else {
                result[cat] = amt;
            }
        } else {
            throw std::invalid_argument("Wrong field count");
        }
    }
    
    if (in_quoted) {
        throw std::invalid_argument("Malformed quoting: unclosed quote");
    }
    
    return result;
}

#endif // SOLUTION_HPP
