# CSV Aggregation Solution

This project implements a header-only C++20 solution for parsing and aggregating CSV data.

## API

```cpp
#include "solution.hpp"
#include <istream>
#include <map>
#include <string>
#include <cstdint>

std::map<std::string, std::int64_t> aggregate(std::istream& in);
```

## Features

- Parses CSV with header `category,amount`
- Supports quoted fields (commas, newlines, escaped double quotes)
- Trims outer spaces/tabs/CR from fields
- Validates non-empty category
- Parses signed int64 amounts (optional +/- prefix, no decimals/exponents)
- Aggregates amounts by category
- Returns sorted map (std::map)
- Throws `std::invalid_argument` on:
  - Invalid header
  - Wrong field count
  - Empty category or amount fields
  - Malformed quoting (unclosed quotes)
  - Invalid amount format (NaN, exponents, decimals)
  - Integer overflow (parsing or accumulation)

## Building and Testing

```bash
# Compile tests
clang++ -std=c++20 -fuse-ld=bfd -o test_solution test_solution.cpp

# Run tests
./test_solution
```

## Example

```cpp
std::string csv = "category,amount\nfoo,100\nbar,200\nfoo,50\n";
std::istringstream in(csv);
auto result = aggregate(in);
// result = {"bar": 200, "foo": 150}
```
