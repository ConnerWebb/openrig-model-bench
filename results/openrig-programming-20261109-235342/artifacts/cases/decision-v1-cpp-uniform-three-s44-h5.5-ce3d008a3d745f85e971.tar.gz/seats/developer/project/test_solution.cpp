#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_basic_parsing() {
    std::string csv = "category,amount\nfoo,100\nbar,200\nfoo,50\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["foo"] == 150);
    assert(result["bar"] == 200);
    std::cout << "test_basic_parsing passed\n";
}

void test_quoted_fields() {
    std::string csv = "category,amount\n\"foo,bar\",100\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 1);
    assert(result.count("foo,bar") == 1);
    assert(result["foo,bar"] == 100);
    std::cout << "test_quoted_fields passed\n";
}

void test_escaped_quotes() {
    std::string csv = "category,amount\n\"foo\"\"bar\",100\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 1);
    assert(result.count("foo\"bar") == 1);
    assert(result["foo\"bar"] == 100);
    std::cout << "test_escaped_quotes passed\n";
}

void test_multiline_quoted() {
    std::string csv = "category,amount\n\"foo\nbar\",100\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 1);
    assert(result.count("foo\nbar") == 1);
    assert(result["foo\nbar"] == 100);
    std::cout << "test_multiline_quoted passed\n";
}

void test_negative_numbers() {
    std::string csv = "category,amount\nfoo,100\nfoo,-50\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["foo"] == 50);
    std::cout << "test_negative_numbers passed\n";
}

void test_trim_fields() {
    std::string csv = "category,amount\n  foo  ,  100  \n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.count("foo") == 1);
    assert(result["foo"] == 100);
    std::cout << "test_trim_fields passed\n";
}

void test_invalid_header() {
    std::string csv = "wrong,header\nfoo,100\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_header passed\n";
    }
}

void test_wrong_field_count() {
    std::string csv = "category,amount\nfoo,100,extra\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count passed\n";
    }
}

void test_empty_category() {
    std::string csv = "category,amount\n,100\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category passed\n";
    }
}

void test_invalid_amount() {
    std::string csv = "category,amount\nfoo,NaN\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_amount passed\n";
    }
}

void test_exponent_rejected() {
    std::string csv = "category,amount\nfoo,1e2\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_exponent_rejected passed\n";
    }
}

void test_decimal_rejected() {
    std::string csv = "category,amount\nfoo,1.5\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_decimal_rejected passed\n";
    }
}

void test_overflow_amount() {
    std::string csv = "category,amount\nfoo,9223372036854775808\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow_amount passed\n";
    }
}

void test_unclosed_quote() {
    std::string csv = "category,amount\n\"foo,100\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_unclosed_quote passed\n";
    }
}

void test_max_int64() {
    std::string csv = "category,amount\nfoo,9223372036854775807\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == 9223372036854775807LL);
    std::cout << "test_max_int64 passed\n";
}

void test_min_int64() {
    std::string csv = "category,amount\nfoo,-9223372036854775808\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == -9223372036854775808LL);
    std::cout << "test_min_int64 passed\n";
}

void test_accumulation_overflow() {
    std::string csv = "category,amount\nfoo,9223372036854775807\nfoo,1\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_accumulation_overflow passed\n";
    }
}

void test_empty_records_ignored() {
    std::string csv = "category,amount\n\nfoo,100\n\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == 100);
    std::cout << "test_empty_records_ignored passed\n";
}

int main() {
    test_basic_parsing();
    test_quoted_fields();
    test_escaped_quotes();
    test_multiline_quoted();
    test_negative_numbers();
    test_trim_fields();
    test_invalid_header();
    test_wrong_field_count();
    test_empty_category();
    test_invalid_amount();
    test_exponent_rejected();
    test_decimal_rejected();
    test_overflow_amount();
    test_unclosed_quote();
    test_max_int64();
    test_min_int64();
    test_accumulation_overflow();
    test_empty_records_ignored();
    
    std::cout << "All tests passed!\n";
    return 0;
}
