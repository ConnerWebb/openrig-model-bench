import unittest
import copy
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    def test_normalize_empty(self):
        result = validation.normalize([])
        self.assertEqual(result, [])

    def test_normalize_basic(self):
        records = [{'id': ' a ', 'category': ' x ', 'cents': 10}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'a', 'category': 'x', 'cents': 10}])

    def test_normalize_preserves_duplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'x', 'cents': 2}
        ]
        result = validation.normalize(records)
        self.assertEqual(len(result), 2)

    def test_normalize_rejects_non_dict(self):
        with self.assertRaises(ValueError):
            validation.normalize(['not a dict'])

    def test_normalize_rejects_extra_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': 'x', 'cents': 1, 'extra': 2}])

    def test_normalize_rejects_missing_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': 'x'}])

    def test_normalize_rejects_empty_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '', 'category': 'x', 'cents': 1}])

    def test_normalize_rejects_whitespace_only_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '  ', 'category': 'x', 'cents': 1}])

    def test_normalize_rejects_non_string_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 123, 'category': 'x', 'cents': 1}])

    def test_normalize_rejects_empty_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': '', 'cents': 1}])

    def test_normalize_rejects_whitespace_only_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': '  ', 'cents': 1}])

    def test_normalize_rejects_non_string_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': 123, 'cents': 1}])

    def test_normalize_rejects_negative_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': 'x', 'cents': -1}])

    def test_normalize_rejects_float_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': 'x', 'cents': 1.5}])

    def test_normalize_rejects_boolean_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'a', 'category': 'x', 'cents': True}])

    def test_normalize_immutability(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        original = copy.deepcopy(records)
        validation.normalize(records)
        self.assertEqual(records, original)


class TestStorage(unittest.TestCase):
    def test_deduplicate_empty(self):
        result = storage.deduplicate([])
        self.assertEqual(result, [])

    def test_deduplicate_first_wins(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'b', 'category': 'z', 'cents': 3}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[0]['category'], 'x')
        self.assertEqual(result[1]['id'], 'b')

    def test_deduplicate_fresh_copy(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = storage.deduplicate(records)
        result[0]['id'] = 'b'
        self.assertEqual(records[0]['id'], 'a')

    def test_deduplicate_immutability(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        original = copy.deepcopy(records)
        storage.deduplicate(records)
        self.assertEqual(records, original)


class TestLedger(unittest.TestCase):
    def test_process_empty(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_process_basic(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        result = ledger.process(records)
        self.assertEqual(result['events'], [{'id': 'a', 'category': 'x', 'cents': 10}])
        self.assertEqual(result['totals'], {'x': 10})

    def test_process_totals_sorted(self):
        records = [
            {'id': 'b', 'category': 'z', 'cents': 1},
            {'id': 'a', 'category': 'a', 'cents': 2}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'z'])

    def test_process_minimum_cents(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'x', 'cents': 20},
            {'id': 'c', 'category': 'x', 'cents': 30}
        ]
        result = ledger.process(records, minimum_cents=15)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['cents'], 20)
        self.assertEqual(result['events'][1]['cents'], 30)

    def test_process_minimum_cents_zero(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 0}]
        result = ledger.process(records, minimum_cents=0)
        self.assertEqual(len(result['events']), 1)

    def test_process_minimum_cents_rejects_negative(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_process_minimum_cents_rejects_float(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=1.5)

    def test_process_minimum_cents_rejects_boolean(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)

    def test_process_immutability(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_process_composition(self):
        records = [
            {'id': '  a  ', 'category': '  x  ', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': 20},
            {'id': 'b', 'category': 'x', 'cents': 30}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['id'], 'a')
        self.assertEqual(result['events'][0]['category'], 'x')
        self.assertEqual(result['events'][0]['cents'], 10)
        self.assertEqual(result['events'][1]['id'], 'b')
        self.assertEqual(result['totals'], {'x': 40})


if __name__ == '__main__':
    unittest.main()
