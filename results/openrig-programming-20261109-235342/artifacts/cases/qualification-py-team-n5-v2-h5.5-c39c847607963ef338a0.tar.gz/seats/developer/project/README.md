# validation.py

Normalizes and validates records per the team contract.

## normalize(records)

Takes a list of record dictionaries and returns a new list of normalized records.

### Requirements

- Each record must be a dict with exactly the keys: `id`, `category`, `cents`.
- `id` and `category` must be non-empty strings (whitespace is stripped).
- `cents` must be a non-negative integer (booleans are rejected).
- Invalid records raise `ValueError('record')`.
- Input is never mutated; a new list and new dictionaries are returned.
- Duplicates and order are preserved.
