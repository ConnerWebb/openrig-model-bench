import unittest
from validation import normalize


class TestNormalize(unittest.TestCase):

    def test_empty_input(self):
        result = normalize([])
        self.assertEqual(result, [])
        self.assertIsNot(result, [])

    def test_basic_normalization(self):
        records = [{'id': ' 8 ', 'category': ' c ', 'cents': 1}]
        result = normalize(records)
        self.assertEqual(result, [{'id': '8', 'category': 'c', 'cents': 1}])

    def test_preserves_order_and_duplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'b', 'category': 'x', 'cents': 3},
        ]
        result = normalize(records)
        self.assertEqual(result, records)

    def test_input_not_mutated(self):
        records = [{'id': ' 8 ', 'category': ' c ', 'cents': 1}]
        result = normalize(records)
        self.assertEqual(records[0], {'id': ' 8 ', 'category': ' c ', 'cents': 1})
        self.assertIsNot(result[0], records[0])

    def test_rejects_non_dict(self):
        with self.assertRaises(ValueError):
            normalize(['not a dict'])

    def test_rejects_missing_keys(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x'}])

    def test_rejects_extra_keys(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x', 'cents': 1, 'extra': 0}])

    def test_rejects_empty_id(self):
        with self.assertRaises(ValueError):
            normalize([{'id': '', 'category': 'x', 'cents': 1}])

    def test_rejects_whitespace_only_id(self):
        with self.assertRaises(ValueError):
            normalize([{'id': '   ', 'category': 'x', 'cents': 1}])

    def test_rejects_non_string_id(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 1, 'category': 'x', 'cents': 1}])

    def test_rejects_empty_category(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': '', 'cents': 1}])

    def test_rejects_whitespace_only_category(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': '   ', 'cents': 1}])

    def test_rejects_non_string_category(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 1, 'cents': 1}])

    def test_rejects_negative_cents(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x', 'cents': -1}])

    def test_rejects_boolean_cents(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x', 'cents': True}])

    def test_rejects_float_cents(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x', 'cents': 1.5}])


if __name__ == '__main__':
    unittest.main()
