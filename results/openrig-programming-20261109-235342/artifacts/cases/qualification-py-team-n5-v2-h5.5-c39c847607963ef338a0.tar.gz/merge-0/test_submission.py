import unittest
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    def test_valid_record(self):
        r = {'id': ' x ', 'category': ' a ', 'cents': 5}
        result = validation.normalize([r])
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])

    def test_invalid_missing_key(self):
        r = {'id': 'x', 'category': 'a'}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_extra_key(self):
        r = {'id': 'x', 'category': 'a', 'cents': 5, 'extra': 1}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_id_not_string(self):
        r = {'id': 1, 'category': 'a', 'cents': 5}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_id_empty(self):
        r = {'id': '', 'category': 'a', 'cents': 5}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_id_whitespace_only(self):
        r = {'id': '   ', 'category': 'a', 'cents': 5}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_category_not_string(self):
        r = {'id': 'x', 'category': 1, 'cents': 5}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_category_empty(self):
        r = {'id': 'x', 'category': '', 'cents': 5}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_cents_not_int(self):
        r = {'id': 'x', 'category': 'a', 'cents': 5.0}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_cents_boolean(self):
        r = {'id': 'x', 'category': 'a', 'cents': True}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_cents_negative(self):
        r = {'id': 'x', 'category': 'a', 'cents': -1}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_empty_input(self):
        self.assertEqual(validation.normalize([]), [])


class TestStorage(unittest.TestCase):
    def test_no_duplicates(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = storage.deduplicate(records)
        self.assertEqual(result, records)

    def test_duplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'b', 'category': 'z', 'cents': 3}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[1]['id'], 'b')

    def test_first_wins(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result[0]['category'], 'x')

    def test_empty_input(self):
        self.assertEqual(storage.deduplicate([]), [])


class TestLedger(unittest.TestCase):
    def test_basic(self):
        r = [{'id': 'x', 'category': 'a', 'cents': 5}]
        result = ledger.process(r)
        self.assertEqual(result['events'], [{'id': 'x', 'category': 'a', 'cents': 5}])
        self.assertEqual(result['totals'], {'a': 5})

    def test_deduplication(self):
        r = [
            {'id': 'x', 'category': 'a', 'cents': 5},
            {'id': 'x', 'category': 'b', 'cents': 10}
        ]
        result = ledger.process(r)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'a')
        self.assertEqual(result['totals'], {'a': 5})

    def test_minimum_cents(self):
        r = [
            {'id': 'x', 'category': 'a', 'cents': 5},
            {'id': 'y', 'category': 'b', 'cents': 10}
        ]
        result = ledger.process(r, minimum_cents=7)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'y')
        self.assertEqual(result['totals'], {'b': 10})

    def test_minimum_cents_invalid(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_minimum_cents_boolean(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)

    def test_empty_input(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_totals_sorted(self):
        r = [
            {'id': 'x', 'category': 'c', 'cents': 1},
            {'id': 'y', 'category': 'a', 'cents': 2},
            {'id': 'z', 'category': 'b', 'cents': 3}
        ]
        result = ledger.process(r)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_input_not_mutated(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original_id = r[0]['id']
        original_category = r[0]['category']
        ledger.process(r)
        self.assertEqual(r[0]['id'], original_id)
        self.assertEqual(r[0]['category'], original_category)

    def test_returned_data_not_shared(self):
        r1 = [{'id': 'x', 'category': 'a', 'cents': 1}]
        r2 = [{'id': 'y', 'category': 'b', 'cents': 2}]
        result1 = ledger.process(r1)
        result2 = ledger.process(r2)
        self.assertNotEqual(id(result1['events']), id(result2['events']))
        self.assertNotEqual(id(result1['totals']), id(result2['totals']))


if __name__ == '__main__':
    unittest.main()
