# Ledger Toolkit

A Python library for processing transaction-like records with validation, deduplication, and aggregation.

## Modules

### `validation.py`

Normalizes and validates records.

**API:**
```python
normalize(records: list[dict]) -> list[dict]
```

- Validates each record has exactly `id` (non-empty stripped str), `category` (non-empty stripped str), `cents` (non-negative int).
- Rejects boolean values for `cents`.
- Returns fresh list of normalized records with stripped `id` and `category`.
- Raises `ValueError` on invalid input.

### `storage.py`

Deduplicates records by first-occurrence `id`.

**API:**
```python
deduplicate(records: list[dict]) -> list[dict]
```

- Assumes input is already validated.
- Returns fresh list with only first occurrence of each `id`.
- Does not mutate input.

### `ledger.py`

Composes validation and storage with optional filtering.

**API:**
```python
process(records: list[dict], *, minimum_cents: int = 0) -> dict
```

- Normalizes and validates all records.
- Deduplicates by first-occurrence `id`.
- Filters events where `cents >= minimum_cents`.
- Returns `{'events': list[dict], 'totals': dict}` with `totals` keys sorted.
- Raises `ValueError` on invalid input or invalid `minimum_cents`.

## Usage

```python
from ledger import process

records = [
    {'id': '  item1  ', 'category': '  food  ', 'cents': 100},
    {'id': 'item1', 'category': 'food', 'cents': 200},  # duplicate, ignored
    {'id': 'item2', 'category': 'transport', 'cents': 50}
]

result = process(records, minimum_cents=50)
# result = {
#   'events': [
#     {'id': 'item1', 'category': 'food', 'cents': 100},
#     {'id': 'item2', 'category': 'transport', 'cents': 50}
#   ],
#   'totals': {'food': 100, 'transport': 50}
# }
```

## Testing

Run unit tests:
```bash
python3 -m unittest test_submission.py
```
