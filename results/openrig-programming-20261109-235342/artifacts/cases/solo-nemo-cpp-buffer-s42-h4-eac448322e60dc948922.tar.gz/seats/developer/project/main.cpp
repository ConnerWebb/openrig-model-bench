#include "solution.hpp"
#include <iostream>
#include <vector>

int main() {
    Buffer buf(5);
    std::cout << "size: " << buf.size() << std::endl;
    buf[0] = 42;
    std::cout << "first byte: " << static_cast<int>(buf[0]) << std::endl;
    buf.resize(10);
    std::cout << "new size: " << buf.size() << std::endl;
    return 0;
}
