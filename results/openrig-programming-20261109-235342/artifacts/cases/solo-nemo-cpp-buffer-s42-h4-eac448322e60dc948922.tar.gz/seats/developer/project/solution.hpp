#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <stdexcept>
#include <algorithm>

class Buffer {
    std::vector<std::uint8_t> data_;
public:
    Buffer(std::size_t n = 0) : data_(n, 0) {}
    std::size_t size() const noexcept { return data_.size(); }
    std::uint8_t& operator[](std::size_t i) {
        if (i >= size()) throw std::out_of_range("index out of range");
        return data_[i];
    }
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= size()) throw std::out_of_range("index out of range");
        return data_[i];
    }
    void resize(std::size_t k) {
        data_.resize(k, 0);
        data_.shrink_to_fit();
    }
};

