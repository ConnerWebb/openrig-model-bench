# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **RAII-based memory management**: Automatic resource cleanup via destructor
- **Deep copy semantics**: Copy constructor and copy assignment perform deep copies
- **Noexcept move operations**: Move constructor and move assignment are noexcept
- **Moved-from state**: Moved-from buffers have size 0 and are reusable
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Resize with preservation**: `resize()` preserves existing prefix and zero-initializes new elements

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized. Default constructor creates an empty buffer.

### Destructor
```cpp
~Buffer();
```
Frees allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy: allocates new memory and copies contents.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Transfer ownership. Moved-from buffer has size 0 and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
`size()` returns the buffer size. `operator[]` provides bounds-checked access, throwing `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes the buffer to `k` bytes. Preserves existing prefix (up to `min(old_size, k)`), zero-initializes new bytes.

## Example

```cpp
Buffer a(5);
a[0] = 42;
Buffer b = a;  // Deep copy
Buffer c = std::move(a);  // Move, a is now empty
a.resize(10);  // a can be reused
```

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

## Testing

Run `run_tests` to execute the public test suite.
