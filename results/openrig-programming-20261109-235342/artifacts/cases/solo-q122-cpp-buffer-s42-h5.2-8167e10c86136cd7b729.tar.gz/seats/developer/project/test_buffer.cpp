#include <iostream>
#include <cassert>
#include <stdexcept>
#include <cstdint>
#include <cstddef>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_mutable_operator() {
    Buffer b(5);
    for (std::size_t i = 0; i < b.size(); ++i) {
        b[i] = static_cast<std::uint8_t>(i * 10);
    }
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i * 10));
    }
    std::cout << "test_mutable_operator passed\n";
}

void test_const_operator() {
    Buffer b(5);
    for (std::size_t i = 0; i < b.size(); ++i) {
        b[i] = static_cast<std::uint8_t>(i * 10);
    }
    const Buffer& cb = b;
    for (std::size_t i = 0; i < cb.size(); ++i) {
        assert(cb[i] == static_cast<std::uint8_t>(i * 10));
    }
    std::cout << "test_const_operator passed\n";
}

void test_bounds_check_out_of_range() {
    Buffer b(5);
    bool caught = false;
    try {
        (void)b[5];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    caught = false;
    try {
        const Buffer& cb = b;
        (void)cb[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    std::cout << "test_bounds_check_out_of_range passed\n";
}

void test_resize_preserves_prefix() {
    Buffer b(5);
    for (std::size_t i = 0; i < b.size(); ++i) {
        b[i] = static_cast<std::uint8_t>(i + 1);
    }
    b.resize(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    for (std::size_t i = 5; i < 10; ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_resize_preserves_prefix passed\n";
}

void test_resize_shrinks() {
    Buffer b(10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        b[i] = static_cast<std::uint8_t>(i + 1);
    }
    b.resize(5);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    std::cout << "test_resize_shrinks passed\n";
}

void test_copy_constructor_deep_copy() {
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(a);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    a[0] = 255;
    assert(b[0] == 1);
    std::cout << "test_copy_constructor_deep_copy passed\n";
}

void test_copy_assignment_deep_copy() {
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    a[0] = 255;
    assert(b[0] == 1);
    std::cout << "test_copy_assignment_deep_copy passed\n";
}

void test_move_constructor_noexcept() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>, "Move constructor must be noexcept");
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(std::move(a));
    assert(b.size() == 5);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    assert(a.size() == 0);
    std::cout << "test_move_constructor_noexcept passed\n";
}

void test_move_assignment_noexcept() {
    static_assert(std::is_nothrow_move_assignable_v<Buffer>, "Move assignment must be noexcept");
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(3);
    b = std::move(a);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    assert(a.size() == 0);
    std::cout << "test_move_assignment_noexcept passed\n";
}

void test_moved_from_reusable() {
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(std::move(a));
    assert(a.size() == 0);
    a.resize(3);
    assert(a.size() == 3);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i * 10);
    }
    assert(a[0] == 0);
    assert(a[1] == 10);
    assert(a[2] == 20);
    std::cout << "test_moved_from_reusable passed\n";
}

void test_self_copy() {
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    a = a;
    for (std::size_t i = 0; i < a.size(); ++i) {
        assert(a[i] == static_cast<std::uint8_t>(i + 1));
    }
    std::cout << "test_self_copy passed\n";
}

void test_self_move() {
    Buffer a(5);
    for (std::size_t i = 0; i < a.size(); ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    a = std::move(a);
    for (std::size_t i = 0; i < a.size(); ++i) {
        assert(a[i] == static_cast<std::uint8_t>(i + 1));
    }
    std::cout << "test_self_move passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_mutable_operator();
    test_const_operator();
    test_bounds_check_out_of_range();
    test_resize_preserves_prefix();
    test_resize_shrinks();
    test_copy_constructor_deep_copy();
    test_copy_assignment_deep_copy();
    test_move_constructor_noexcept();
    test_move_assignment_noexcept();
    test_moved_from_reusable();
    test_self_copy();
    test_self_move();
    std::cout << "All tests passed!\n";
    return 0;
}
