# LRU Cache Implementation

A C++20 implementation of an LRU (Least Recently Used) cache with O(1) average time complexity for `get`, `put`, and `erase` operations.

## API

```cpp
class LruCache {
public:
    explicit LruCache(size_t capacity);
    
    void put(int key, std::string value);
    bool get(int key, std::string& out);
    bool erase(int key);
    size_t size() const;
    std::vector<std::pair<int, std::string>> snapshot() const;
};
```

- `put(key, value)`: Insert or update a key-value pair. Makes the key most recently used. Evicts LRU key on overflow if capacity is exceeded.
- `get(key, out)`: Retrieve value by key. Returns `true` if found, `false` otherwise. Makes the key most recently used.
- `erase(key)`: Remove a key. Returns `true` if key existed, `false` otherwise.
- `size()`: Return current number of items.
- `snapshot()`: Return items in MRU order (most recent first). Does not affect recency.

## Implementation Details

- Uses `std::list` for ordering and `std::unordered_map` for O(1) lookups.
- Copying is disabled (no copy constructor/assignment).
- RAII-compliant with proper resource management.

## Testing

Run tests with:
```bash
clang++ -std=c++20 -o solution_test solution_test.cpp && ./solution_test
```
