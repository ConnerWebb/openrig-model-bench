#include <iostream>
#include <cassert>
#include "solution.hpp"

void test_basic_operations() {
    LruCache cache(3);
    assert(cache.size() == 0);
    
    cache.put(1, "one");
    assert(cache.size() == 1);
    
    cache.put(2, "two");
    assert(cache.size() == 2);
    
    cache.put(3, "three");
    assert(cache.size() == 3);
    
    std::string out;
    assert(cache.get(1, out) == true);
    assert(out == "one");
    
    assert(cache.get(2, out) == true);
    assert(out == "two");
    
    assert(cache.get(3, out) == true);
    assert(out == "three");
    
    auto snap = cache.snapshot();
    assert(snap.size() == 3);
    assert(snap[0].first == 3);
    assert(snap[0].second == "three");
    assert(snap[1].first == 2);
    assert(snap[1].second == "two");
    assert(snap[2].first == 1);
    assert(snap[2].second == "one");
}

void test_eviction() {
    LruCache cache(2);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string out;
    assert(cache.get(1, out) == false);
    assert(cache.get(2, out) == true);
    assert(out == "two");
    assert(cache.get(3, out) == true);
    assert(out == "three");
    
    assert(cache.size() == 2);
}

void test_update_existing() {
    LruCache cache(3);
    cache.put(1, "one");
    cache.put(1, "ONE");
    
    std::string out;
    assert(cache.get(1, out) == true);
    assert(out == "ONE");
    assert(cache.size() == 1);
}

void test_erase() {
    LruCache cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    assert(cache.erase(2) == true);
    assert(cache.size() == 2);
    
    std::string out;
    assert(cache.get(2, out) == false);
    assert(cache.get(1, out) == true);
    assert(cache.get(3, out) == true);
    
    assert(cache.erase(2) == false);
    assert(cache.erase(1) == true);
    assert(cache.size() == 1);
}

void test_snapshot_order() {
    LruCache cache(4);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string out;
    cache.get(1, out);
    
    auto snap = cache.snapshot();
    assert(snap.size() == 3);
    assert(snap[0].first == 1);
    assert(snap[1].first == 3);
    assert(snap[2].first == 2);
}

void test_capacity_zero() {
    LruCache cache(0);
    cache.put(1, "one");
    assert(cache.size() == 0);
    
    std::string out;
    assert(cache.get(1, out) == false);
    assert(cache.erase(1) == false);
}

void test_empty_snapshot() {
    LruCache cache(5);
    auto snap = cache.snapshot();
    assert(snap.empty());
}

int main() {
    test_basic_operations();
    test_eviction();
    test_update_existing();
    test_erase();
    test_snapshot_order();
    test_capacity_zero();
    test_empty_snapshot();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
