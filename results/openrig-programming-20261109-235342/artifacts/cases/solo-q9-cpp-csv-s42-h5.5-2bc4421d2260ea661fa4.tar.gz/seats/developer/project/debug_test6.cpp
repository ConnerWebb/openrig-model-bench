#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>
#include "solution.hpp"

int main() {
    // Test case 0 from PUBLIC_CASES.json - using the actual CSV content
    std::string csv = "category,amount\n\"x\"\"quote\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\"x\"\"quote\",-22826\n\"x\"\"quote\",-4598\n\"x\"\"quote\",-26830\n日本,39039\n\"a,b\",29914\nrent,15786\n日本,-8138\nfood,15570\n\"x\"\"quote\",-26030\n\"two\nlines\",54977\n\"x\"\"quote\",-5124\nrent,12112\n\"two\nlines\",28447\nfood,57027\nfood,2732\n";
    
    // Parse the first line
    std::string line;
    std::istringstream in(csv);
    std::getline(in, line);
    
    // Parse the second line
    std::getline(in, line);
    
    // Parse the CSV line
    std::vector<std::string> fields = aggregate_impl::parse_csv_line(line);
    
    std::string category = fields[0];
    std::string amount_str = fields[1];
    
    std::cout << "Category: [" << category << "]" << std::endl;
    std::cout << "Amount: [" << amount_str << "]" << std::endl;
    
    // Check if the amount is valid
    if (aggregate_impl::is_valid_integer_value(amount_str)) {
        std::cout << "Amount is valid" << std::endl;
    } else {
        std::cout << "Amount is invalid" << std::endl;
    }
    
    // Convert to int64_t
    try {
        int64_t amount = aggregate_impl::to_int64(amount_str);
        std::cout << "Amount as int64_t: " << amount << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Error converting amount: " << e.what() << std::endl;
    }
    
    return 0;
}
