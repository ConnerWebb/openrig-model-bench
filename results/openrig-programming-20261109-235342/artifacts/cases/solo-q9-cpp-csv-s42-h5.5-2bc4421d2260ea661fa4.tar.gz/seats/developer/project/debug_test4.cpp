#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>
#include "solution.hpp"

int main() {
    // Test case 0 from PUBLIC_CASES.json - using the actual CSV content
    std::string csv = "category,amount\n\"x\"\"quote\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\"x\"\"quote\",-22826\n\"x\"\"quote\",-4598\n\"x\"\"quote\",-26830\n日本,39039\n\"a,b\",29914\nrent,15786\n日本,-8138\nfood,15570\n\"x\"\"quote\",-26030\n\"two\nlines\",54977\n\"x\"\"quote\",-5124\nrent,12112\n\"two\nlines\",28447\nfood,57027\nfood,2732\n";
    
    // Parse the first line
    std::string line;
    std::istringstream in(csv);
    std::getline(in, line);
    
    std::cout << "First line: [" << line << "]" << std::endl;
    std::cout << "Line length: " << line.size() << std::endl;
    
    // Check if the line is correct
    if (line == "category,amount") {
        std::cout << "Header is correct" << std::endl;
    } else {
        std::cout << "Header is incorrect" << std::endl;
    }
    
    // Parse the second line
    std::getline(in, line);
    std::cout << "Second line: [" << line << "]" << std::endl;
    std::cout << "Line length: " << line.size() << std::endl;
    
    // Check if the second line is correct
    if (line == "\"x\"\"quote\",51268") {
        std::cout << "Second line is correct" << std::endl;
    } else {
        std::cout << "Second line is incorrect" << std::endl;
    }
    
    return 0;
}
