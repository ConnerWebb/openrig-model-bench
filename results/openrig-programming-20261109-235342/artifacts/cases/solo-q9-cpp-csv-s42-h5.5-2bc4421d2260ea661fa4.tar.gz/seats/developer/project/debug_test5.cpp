#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>
#include "solution.hpp"

int main() {
    // Test case 0 from PUBLIC_CASES.json - using the actual CSV content
    std::string csv = "category,amount\n\"x\"\"quote\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\"x\"\"quote\",-22826\n\"x\"\"quote\",-4598\n\"x\"\"quote\",-26830\n日本,39039\n\"a,b\",29914\nrent,15786\n日本,-8138\nfood,15570\n\"x\"\"quote\",-26030\n\"two\nlines\",54977\n\"x\"\"quote\",-5124\nrent,12112\n\"two\nlines\",28447\nfood,57027\nfood,2732\n";
    
    // Parse the first line
    std::string line;
    std::istringstream in(csv);
    std::getline(in, line);
    
    std::cout << "First line: [" << line << "]" << std::endl;
    
    // Parse the second line
    std::getline(in, line);
    std::cout << "Second line: [" << line << "]" << std::endl;
    
    // Parse the CSV line
    std::vector<std::string> fields = aggregate_impl::parse_csv_line(line);
    std::cout << "Fields size: " << fields.size() << std::endl;
    for (size_t i = 0; i < fields.size(); i++) {
        std::cout << "Field " << i << ": [" << fields[i] << "]" << std::endl;
    }
    
    return 0;
}
