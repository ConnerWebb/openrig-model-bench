#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && std::isspace(static_cast<unsigned char>(s[start]))) {
        ++start;
    }
    size_t end = s.size();
    while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1]))) {
        --end;
    }
    return s.substr(start, end - start);
}

std::string parse_field(const std::string& line, size_t& pos) {
    std::string result;
    
    if (pos >= line.size()) {
        throw std::invalid_argument("Unexpected end of input");
    }
    
    char c = line[pos];
    
    if (c == '"') {
        // Quoted field
        ++pos; // skip opening quote
        while (pos < line.size()) {
            c = line[pos];
            if (c == '"') {
                if (pos + 1 < line.size() && line[pos + 1] == '"') {
                    // Escaped quote
                    result += '"';
                    pos += 2;
                } else {
                    // End of quoted field
                    ++pos; // skip closing quote
                    break;
                }
            } else {
                result += c;
                ++pos;
            }
        }
    } else {
        // Unquoted field
        while (pos < line.size() && line[pos] != ',' && line[pos] != '\n' && line[pos] != '\r') {
            result += line[pos];
            ++pos;
        }
    }
    
    return result;
}

std::vector<std::string> parse_csv_line(std::string& line) {
    std::vector<std::string> fields;
    size_t pos = 0;
    
    while (pos < line.size()) {
        std::string field = parse_field(line, pos);
        fields.push_back(field);
        
        if (pos >= line.size()) {
            break;
        }
        
        char c = line[pos];
        if (c == ',') {
            ++pos; // skip comma
        } else if (c == '\n' || c == '\r') {
            // End of record
            break;
        } else {
            // Unexpected character
            throw std::invalid_argument("Invalid CSV character");
        }
    }
    
    return fields;
}

long long parse_amount(const std::string& s) {
    std::string trimmed = trim(s);
    if (trimmed.empty()) {
        throw std::invalid_argument("Empty amount field");
    }
    
    try {
        return std::stoll(trimmed);
    } catch (const std::exception&) {
        throw std::invalid_argument("Invalid amount format");
    }
}

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& input) {
    std::map<std::string, std::int64_t> result;
    std::string line;
    
    // Read and validate header
    if (!std::getline(input, line)) {
        throw std::invalid_argument("Empty input");
    }
    
    // Parse header
    std::vector<std::string> header_fields = parse_csv_line(line);
    if (header_fields.size() != 2) {
        throw std::invalid_argument("Invalid header: expected 2 fields");
    }
    
    if (trim(header_fields[0]) != "category" || trim(header_fields[1]) != "amount") {
        throw std::invalid_argument("Invalid header: expected 'category,amount'");
    }
    
    // Process data rows
    while (std::getline(input, line)) {
        // Skip empty lines
        if (line.empty()) {
            continue;
        }
        
        // Check if line is just whitespace
        bool all_whitespace = true;
        for (char c : line) {
            if (!std::isspace(static_cast<unsigned char>(c))) {
                all_whitespace = false;
                break;
            }
        }
        if (all_whitespace) {
            continue;
        }
        
        try {
            std::vector<std::string> fields = parse_csv_line(line);
            
            if (fields.size() != 2) {
                throw std::invalid_argument("Invalid record: expected 2 fields");
            }
            
            std::string category = trim(fields[0]);
            long long amount = parse_amount(fields[1]);
            
            if (category.empty()) {
                throw std::invalid_argument("Empty category field");
            }
            
            result[category] += amount;
        } catch (const std::exception&) {
            throw; // Re-throw the exception
        }
    }
    
    return result;
}

int main() {
    std::string csv = R"(category,amount
"x""quote",51268
food,4725
rent,69177)";
    
    std::istringstream in(csv);
    try {
        auto result = aggregate(in);
        for (const auto& [k, v] : result) {
            std::cout << k << " = " << v << std::endl;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
