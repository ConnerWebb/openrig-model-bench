#pragma once
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <stdexcept>
#include <cctype>
#include <climits>

namespace aggregate_impl {

// Parse a CSV line into fields, handling quoted fields with escaped quotes and newlines
std::vector<std::string> parse_csv_line(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool in_quotes = false;
    size_t i = 0;
    
    while (i < line.size()) {
        char c = line[i];
        
        if (in_quotes) {
            if (c == '"') {
                // Check if this is an escaped quote (followed by another quote)
                if (i + 1 < line.size() && line[i + 1] == '"') {
                    field += '"';
                    i += 2;
                } else {
                    // End of quoted field
                    in_quotes = false;
                    i++;
                }
            } else {
                field += c;
                i++;
            }
        } else {
            if (c == '"') {
                // Start of quoted field
                in_quotes = true;
                i++;
            } else if (c == ',') {
                // End of field
                fields.push_back(field);
                field.clear();
                i++;
            } else if (c == '\n' || c == '\r') {
                // End of line (shouldn't happen in middle of parsing unless in quotes)
                // If we're not in quotes, this is the end of the line
                fields.push_back(field);
                return fields;
            } else {
                field += c;
                i++;
            }
        }
    }
    
    // Add the last field
    fields.push_back(field);
    
    return fields;
}

// Check if a string is a valid integer (no scientific notation)
bool is_valid_integer_value(const std::string& s) {
    if (s.empty()) return false;
    
    // Check for scientific notation
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == 'e' || s[i] == 'E') {
            return false;
        }
    }
    
    // Check for NaN, Inf, etc.
    std::string lower_s = s;
    for (auto& c : lower_s) {
        c = std::tolower(static_cast<unsigned char>(c));
    }
    
    if (lower_s == "nan" || lower_s == "inf" || lower_s == "-inf" || lower_s == "+inf") {
        return false;
    }
    
    // Check if it's a valid integer (optional sign followed by digits)
    size_t start = 0;
    if (s[0] == '-' || s[0] == '+') {
        start = 1;
    }
    
    if (start >= s.size()) return false;
    
    for (size_t i = start; i < s.size(); i++) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            return false;
        }
    }
    
    return true;
}

// Convert string to int64_t, checking for overflow
int64_t to_int64(const std::string& s) {
    if (!is_valid_integer_value(s)) {
        throw std::runtime_error("Invalid integer value");
    }
    
    // Use stoll with explicit base 10
    try {
        int64_t result = std::stoll(s, nullptr, 10);
        
        // Verify the conversion is correct (no overflow)
        std::string result_str = std::to_string(result);
        if (result_str != s) {
            throw std::runtime_error("Integer overflow");
        }
        
        return result;
    } catch (const std::exception&) {
        throw std::runtime_error("Integer overflow");
    }
}

} // namespace aggregate_impl

std::map<std::string, int64_t> aggregate(std::istream& in) {
    std::map<std::string, int64_t> result;
    std::string line;
    
    // Read header
    if (!std::getline(in, line)) {
        throw std::runtime_error("Empty input");
    }
    
    // Parse header
    std::vector<std::string> header_fields = aggregate_impl::parse_csv_line(line);
    if (header_fields.size() != 2) {
        throw std::runtime_error("Invalid header");
    }
    
    if (header_fields[0] != "category" || header_fields[1] != "amount") {
        throw std::runtime_error("Invalid header");
    }
    
    // Read data rows
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        
        // Check if line is just whitespace
        bool all_whitespace = true;
        for (char c : line) {
            if (!std::isspace(static_cast<unsigned char>(c))) {
                all_whitespace = false;
                break;
            }
        }
        if (all_whitespace) continue;
        
        std::vector<std::string> fields = aggregate_impl::parse_csv_line(line);
        if (fields.size() != 2) {
            throw std::runtime_error("Invalid row");
        }
        
        std::string category = fields[0];
        std::string amount_str = fields[1];
        
        // Check for empty category
        if (category.empty()) {
            throw std::runtime_error("Empty category");
        }
        
        // Check for valid integer
        if (!aggregate_impl::is_valid_integer_value(amount_str)) {
            throw std::runtime_error("Invalid amount");
        }
        
        // Convert to int64_t
        int64_t amount = aggregate_impl::to_int64(amount_str);
        
        // Add to result (check for overflow)
        try {
            // Check if adding would overflow
            if (amount > 0 && result[category] > INT64_MAX - amount) {
                throw std::runtime_error("Overflow");
            }
            if (amount < 0 && result[category] < INT64_MIN - amount) {
                throw std::runtime_error("Overflow");
            }
            result[category] += amount;
        } catch (...) {
            throw std::runtime_error("Overflow");
        }
    }
    
    return result;
}
