#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>
#include "solution.hpp"

int main() {
    // Test case with newline in quoted field
    std::string csv = "category,amount\n\"two\nlines\",54977\n";
    
    // Parse the first line
    std::string line;
    std::istringstream in(csv);
    std::getline(in, line);
    
    std::cout << "First line: [" << line << "]" << std::endl;
    
    // Parse the second line
    std::getline(in, line);
    std::cout << "Second line: [" << line << "]" << std::endl;
    
    // Parse the CSV line
    std::vector<std::string> fields = aggregate_impl::parse_csv_line(line);
    std::cout << "Fields size: " << fields.size() << std::endl;
    for (size_t i = 0; i < fields.size(); i++) {
        std::cout << "Field " << i << ": [" << fields[i] << "]" << std::endl;
    }
    
    return 0;
}
