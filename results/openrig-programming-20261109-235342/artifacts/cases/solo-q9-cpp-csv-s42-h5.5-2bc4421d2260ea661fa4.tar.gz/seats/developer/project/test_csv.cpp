#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>
#include "solution.hpp"

int main() {
    std::string csv = R"(category,amount
"x""quote",51268
food,4725)";
    
    std::istringstream in(csv);
    try {
        auto result = aggregate(in);
        for (const auto& [k, v] : result) {
            std::cout << k << " = " << v << std::endl;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
