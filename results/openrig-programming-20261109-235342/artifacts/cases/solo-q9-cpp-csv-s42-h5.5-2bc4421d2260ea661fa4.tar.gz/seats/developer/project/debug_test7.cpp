#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <cctype>
#include "solution.hpp"

int main() {
    // Test case 0 from PUBLIC_CASES.json - using the actual CSV content
    std::string csv = "category,amount\n\"x\"\"quote\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\"x\"\"quote\",-22826\n\"x\"\"quote\",-4598\n\"x\"\"quote\",-26830\n日本,39039\n\"a,b\",29914\nrent,15786\n日本,-8138\nfood,15570\n\"x\"\"quote\",-26030\n\"two\nlines\",54977\n\"x\"\"quote\",-5124\nrent,12112\n\"two\nlines\",28447\nfood,57027\nfood,2732\n";
    
    // Parse the first line
    std::string line;
    std::istringstream in(csv);
    std::getline(in, line);
    
    // Parse the header
    std::vector<std::string> header_fields = aggregate_impl::parse_csv_line(line);
    std::cout << "Header fields size: " << header_fields.size() << std::endl;
    std::cout << "Header field 0: [" << header_fields[0] << "]" << std::endl;
    std::cout << "Header field 1: [" << header_fields[1] << "]" << std::endl;
    
    if (header_fields[0] != "category" || header_fields[1] != "amount") {
        std::cout << "Invalid header" << std::endl;
        return 1;
    }
    
    std::cout << "Header is valid" << std::endl;
    
    // Read data rows
    int row_num = 0;
    while (std::getline(in, line)) {
        row_num++;
        std::cout << "Row " << row_num << ": [" << line << "]" << std::endl;
        
        if (line.empty()) continue;
        
        // Check if line is just whitespace
        bool all_whitespace = true;
        for (char c : line) {
            if (!std::isspace(static_cast<unsigned char>(c))) {
                all_whitespace = false;
                break;
            }
        }
        if (all_whitespace) continue;
        
        std::vector<std::string> fields = aggregate_impl::parse_csv_line(line);
        std::cout << "  Fields size: " << fields.size() << std::endl;
        
        if (fields.size() != 2) {
            std::cout << "  Invalid row: expected 2 fields" << std::endl;
            return 1;
        }
        
        std::string category = fields[0];
        std::string amount_str = fields[1];
        
        std::cout << "  Category: [" << category << "]" << std::endl;
        std::cout << "  Amount: [" << amount_str << "]" << std::endl;
        
        // Check for empty category
        if (category.empty()) {
            std::cout << "  Empty category" << std::endl;
            return 1;
        }
        
        // Check for valid integer
        if (!aggregate_impl::is_valid_integer_value(amount_str)) {
            std::cout << "  Invalid amount" << std::endl;
            return 1;
        }
        
        // Convert to int64_t
        try {
            int64_t amount = aggregate_impl::to_int64(amount_str);
            std::cout << "  Amount as int64_t: " << amount << std::endl;
        } catch (const std::exception& e) {
            std::cout << "  Error converting amount: " << e.what() << std::endl;
            return 1;
        }
    }
    
    std::cout << "All rows parsed successfully" << std::endl;
    
    return 0;
}
