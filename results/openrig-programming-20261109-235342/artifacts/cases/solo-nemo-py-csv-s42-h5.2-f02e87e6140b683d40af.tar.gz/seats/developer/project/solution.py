import csv
import decimal
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    totals = {}
    with open(path, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader, None)
        if header is None:
            return {}
        # Validate header
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid header")
        
        for row_num, row in enumerate(reader, start=2):  # start=2 because header is line 1
            # Skip completely blank rows
            if not any(cell.strip() for cell in row):
                continue
            
            if len(row) != 2:
                raise ValueError(f"Row {row_num}: expected 2 fields, got {len(row)}")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            if not category:
                raise ValueError(f"Row {row_num}: category is empty")
            
            # Validate amount format: optional +, 1-12 decimal digits, optional decimal point with 1 or 2 digits
            # No exponent, must be finite and non-negative
            if not amount_str:
                raise ValueError(f"Row {row_num}: amount is empty")
            
            # Check for valid characters and format
            allowed_chars = set('0123456789+-.')
            if any(c not in allowed_chars for c in amount_str):
                raise ValueError(f"Row {row_num}: invalid character in amount")
            
            # Check for multiple decimal points
            if amount_str.count('.') > 1:
                raise ValueError(f"Row {row_num}: multiple decimal points")
            
            # Check for exponent
            if 'e' in amount_str.lower():
                raise ValueError(f"Row {row_num}: exponent not allowed")
            
            # Strip leading + if present
            if amount_str.startswith('+'):
                amount_str = amount_str[1:]
            
            # Must have at least one digit
            if not any(c.isdigit() for c in amount_str):
                raise ValueError(f"Row {row_num}: amount must contain digits")
            
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Row {row_num}: cannot parse amount as decimal")
            
            if amount < 0:
                raise ValueError(f"Row {row_num}: amount must be non-negative")
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly two decimal places
    result = {}
    for category in sorted(totals.keys()):
        formatted = f"{totals[category]:.2f}"
        result[category] = formatted
    
    return result