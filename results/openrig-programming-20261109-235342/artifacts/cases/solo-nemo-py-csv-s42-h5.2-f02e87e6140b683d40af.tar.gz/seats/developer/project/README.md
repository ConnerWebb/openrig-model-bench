# Solution Overview

This project implements a CSV aggregation tool that reads a CSV file with exactly two columns: `category` and `amount`. The tool processes the file according to the following specifications:

## Requirements

1. **Input Format**:
   - Header must be exactly `category,amount`
   - Each non-blank record must have exactly two fields
   - Category must not be empty after stripping whitespace
   - Amount must be a non-negative number with optional leading `+`, 1-12 digits before the decimal point, optional decimal point followed by 1-2 digits
   - No exponent notation allowed
   - Completely blank rows are ignored
   - CSV can contain quoted commas and embedded newlines

2. **Processing**:
   - Accumulate amounts for each category using exact decimal arithmetic
   - Return category keys sorted alphabetically
   - Amounts must be formatted with exactly two decimal places

3. **Error Handling**:
   - Raise `ValueError` for any malformed input
   - Specific error conditions include:
     - Invalid header format
     - Incorrect number of fields per row
     - Empty category
     - Invalid amount format
     - Negative amounts
     - Non-numeric amounts

## Implementation Details

The solution uses Python's `csv` module for robust CSV parsing and `decimal.Decimal` for exact arithmetic. The implementation:

1. Reads the CSV file line by line
2. Validates the header row
3. Processes each subsequent row, skipping completely blank rows
4. Validates each row according to the specified rules
5. Accumulates amounts using `Decimal` for precision
6. Returns results with categories sorted and amounts formatted to two decimal places

## Usage

The module provides a single function:
```python
def aggregate(path: str) -> dict[str, str]:
    """Aggregate amounts by category from a CSV file."""
    # Implementation details...
```

The function is designed to be used with the provided driver script which reads JSON input containing the CSV data and outputs results in a specific JSON format.

## Test Cases

The project includes several test cases covering:
- Normal operation with various CSV formats
- Error conditions that should raise `ValueError`
- Edge cases with special characters and formatting

Run tests using the provided test suite.