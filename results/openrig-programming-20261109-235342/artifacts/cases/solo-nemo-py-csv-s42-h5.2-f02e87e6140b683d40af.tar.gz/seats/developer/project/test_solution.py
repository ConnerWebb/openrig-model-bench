import unittest
from solution import aggregate
import tempfile
import pathlib

class TestAggregate(unittest.TestCase):
    def test_basic_case(self):
        csv_content = '''category,amount
food,10.5
rent,20.75
food,5.25
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '15.75', 'rent': '20.75'})

    def test_quoted_commas(self):
        csv_content = '''category,amount
"x""quote",10.5
"two\nlines",20.75
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertIn('x"quote', result)
            self.assertIn('two\nlines', result)

    def test_unicode_categories(self):
        csv_content = '''category,amount
日本,10.5
日本,20.75
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '31.25'})

    def test_empty_rows_ignored(self):
        csv_content = '''category,amount

food,10.5

rent,20.75

'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50', 'rent': '20.75'})

    def test_invalid_header(self):
        csv_content = '''wrong,amount
food,10.5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_invalid_amount_format(self):
        csv_content = '''category,amount
food,10.5.5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_negative_amount(self):
        csv_content = '''category,amount
food,-10.5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_exponent_not_allowed(self):
        csv_content = '''category,amount
food,1e5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_too_many_decimal_digits(self):
        csv_content = '''category,amount
food,1234567890123.456
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_empty_category(self):
        csv_content = '''category,amount

,10.5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_too_few_fields(self):
        csv_content = '''category,amount
food
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_valid_small_amount(self):
        csv_content = '''category,amount
food,.5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '0.50'})

    def test_leading_plus(self):
        csv_content = '''category,amount
food,+10.5
'''
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})

if __name__ == '__main__':
    unittest.main()