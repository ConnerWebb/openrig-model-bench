#!/usr/bin/env python3
"""Unit tests for Buffer class using unittest.TestCase."""
import unittest
import subprocess
import json
import os

class TestBuffer(unittest.TestCase):
    """Test cases for the Buffer C++ class."""

    def run_driver(self, input_data):
        """Run the C++ driver with given input and return parsed JSON result."""
        cmd = ["clang++", "-std=c++20", "-fuse-ld=bfd", "-o", "/tmp/buffer_test", "PUBLIC_DRIVER.cpp", "solution.hpp", "-I."]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            self.fail(f"Compilation failed: {result.stderr}")
        
        result = subprocess.run(["/tmp/buffer_test"], input=input_data, capture_output=True, text=True)
        if result.returncode != 0:
            self.fail(f"Runtime failed: {result.stderr}")
        
        try:
            return json.loads(result.stdout.strip())
        except json.JSONDecodeError:
            self.fail(f"Invalid JSON output: {result.stdout}")

    def test_default_constructor(self):
        """Test default constructor creates buffer of size 0."""
        result = self.run_driver("0 0")
        self.assertIn("value", result)
        self.assertEqual(result["value"], [])

    def test_constructor_with_size(self):
        """Test constructor with size parameter."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        self.assertEqual(result["value"], [1, 2, 3, 4, 5])

    def test_bounds_check_mutable(self):
        """Test that mutable operator[] throws out_of_range for out-of-bounds."""
        result = self.run_driver("5 10\n1 2 3 4 5")
        self.assertIn("bounds", result)
        self.assertTrue(result["bounds"])

    def test_bounds_check_const(self):
        """Test that const operator[] throws out_of_range for out-of-bounds."""
        result = self.run_driver("5 10\n1 2 3 4 5")
        self.assertIn("bounds", result)
        self.assertTrue(result["bounds"])

    def test_copy_constructor(self):
        """Test deep copy via copy constructor."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        self.assertEqual(result["value"], [1, 2, 3, 4, 5])
        self.assertIn("copy", result)
        # After b=a and b[0]^=255, copy should have original values
        self.assertEqual(result["copy"], [1, 2, 3, 4, 5])

    def test_move_constructor(self):
        """Test move constructor preserves content and sets moved-from size to 0."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        self.assertIn("moved_size", result)
        self.assertEqual(result["moved_size"], 0)

    def test_resize_expand(self):
        """Test resize expands and zero-initializes new bytes."""
        result = self.run_driver("5 10\n1 2 3 4 5")
        self.assertEqual(result["value"], [1, 2, 3, 4, 5, 0, 0, 0, 0, 0])

    def test_resize_shrink(self):
        """Test resize shrinks and preserves prefix."""
        result = self.run_driver("10 5\n0 1 2 3 4 5 6 7 8 9")
        self.assertEqual(result["value"], [0, 1, 2, 3, 4])

    def test_resize_to_zero(self):
        """Test resize to zero."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        self.assertEqual(result["value"], [])

    def test_noexcept_move_constructible(self):
        """Test Buffer is nothrow move constructible."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        # This is checked by static_assert in driver, but we verify it compiles
        self.assertIn("value", result)

    def test_noexcept_move_assignable(self):
        """Test Buffer is nothrow move assignable."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        # This is checked by static_assert in driver, but we verify it compiles
        self.assertIn("value", result)

    def test_self_copy_assignment(self):
        """Test self copy assignment preserves content."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        self.assertEqual(result["value"], [1, 2, 3, 4, 5])

    def test_self_move_assignment(self):
        """Test self move assignment preserves content."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        self.assertEqual(result["value"], [1, 2, 3, 4, 5])

    def test_reusable_moved_from(self):
        """Test moved-from buffer is reusable."""
        result = self.run_driver("5 0\n1 2 3 4 5")
        # After move, a should be size 0, but we can resize it again
        self.assertIn("moved_size", result)
        self.assertEqual(result["moved_size"], 0)

if __name__ == "__main__":
    unittest.main()
