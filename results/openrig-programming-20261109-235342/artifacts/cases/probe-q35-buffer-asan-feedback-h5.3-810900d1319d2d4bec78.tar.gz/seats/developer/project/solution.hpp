#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <cstring>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Default constructor: size 0
    Buffer(std::size_t n = 0) : p(n > 0 ? new std::uint8_t[n] : nullptr), n(n) {}

    // Destructor
    ~Buffer() { delete[] p; }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p(other.n > 0 ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (n > 0) {
            std::copy(other.p, other.p + n, p);
        }
    }

    // Copy assignment (deep copy, self-assignment safe)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] p;
            n = other.n;
            p = n > 0 ? new std::uint8_t[n] : nullptr;
            if (n > 0) {
                std::copy(other.p, other.p + n, p);
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Size
    std::size_t size() const noexcept { return n; }

    // Mutable operator[] with bounds check
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const operator[] with bounds check
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize: preserve prefix, zero-initialize new bytes
    void resize(std::size_t k) {
        if (k == n) return;
        if (k == 0) {
            delete[] p;
            p = nullptr;
            n = 0;
            return;
        }
        std::uint8_t* new_p = k > 0 ? new std::uint8_t[k] : nullptr;
        std::size_t copy_len = (k < n) ? k : n;
        if (copy_len > 0) {
            std::copy(p, p + copy_len, new_p);
        }
        // Zero-initialize remaining bytes
        if (k > copy_len) {
            memset(new_p + copy_len, 0, k - copy_len);
        }
        delete[] p;
        p = new_p;
        n = k;
    }
};
