# Buffer Library

A C++20 RAII buffer class implementing a safe, bounds-checked container for `uint8_t` elements.

## Features

- **RAII Management**: Automatic memory management with no leaks, double frees, or stale reads.
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for invalid indices.
- **Deep Copy**: Copy constructor and assignment perform deep copies.
- **Move Semantics**: Noexcept move constructor and assignment; moved-from buffers have size 0 and are reusable.
- **Self-Assignment Safe**: Both copy and move assignments handle self-assignment correctly.
- **Resizable**: `resize()` preserves prefix and zero-initializes new bytes.

## API

```cpp
class Buffer {
    Buffer(std::size_t n = 0);              // Default constructor (size 0)
    ~Buffer();                               // Destructor
    Buffer(const Buffer& other);             // Copy constructor (deep copy)
    Buffer& operator=(const Buffer& other);  // Copy assignment (deep copy)
    Buffer(Buffer&& other) noexcept;         // Move constructor
    Buffer& operator=(Buffer&& other) noexcept; // Move assignment
    std::size_t size() const noexcept;       // Return buffer size
    std::uint8_t& operator[](std::size_t i); // Mutable access (bounds-checked)
    const std::uint8_t& operator[](std::size_t i) const; // Const access (bounds-checked)
    void resize(std::size_t k);              // Resize (preserve prefix, zero-init new)
};
```

## Usage Example

```cpp
Buffer a(5);
a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;

Buffer b(a);  // Deep copy
Buffer c = std::move(a);  // Move (a.size() == 0)

a.resize(10);  // Size 10, first 5 elements preserved, new bytes zero-initialized
```

## Testing

Run tests with:
```bash
python3 Buffer_test.py
```

Tests cover:
- Default and sized constructors
- Bounds checking on mutable and const access
- Deep copy semantics
- Move semantics (noexcept, reusable moved-from buffers)
- Self-assignment handling
- Resize operations

## Compilation

```bash
clang++ -std=c++20 -fuse-ld=bfd -o buffer_test PUBLIC_DRIVER.cpp solution.hpp -I.
```

## Safety Guarantees

- No memory leaks
- No double frees
- No stale reads
- No undefined behavior
- All operations are exception-safe where applicable
