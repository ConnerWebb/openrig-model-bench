#pragma once
#include <unordered_map>
#include <list>
#include <vector>
#include <string>

class LruCache {
private:
    size_t capacity_;
    std::unordered_map<int, std::list<std::pair<int, std::string>>::iterator> cache_;
    std::list<std::pair<int, std::string>> lru_list_;

public:
    explicit LruCache(size_t capacity) : capacity_(capacity) {}

    void put(int key, const std::string& value) {
        if (capacity_ == 0) {
            return;
        }

        auto it = cache_.find(key);
        if (it != cache_.end()) {
            // Key exists, update value and move to front (MRU)
            it->second->second = value;
            lru_list_.splice(lru_list_.begin(), lru_list_, it->second);
        } else {
            // Key doesn't exist
            if (lru_list_.size() >= capacity_) {
                // Remove LRU item
                int lru_key = lru_list_.back().first;
                cache_.erase(lru_key);
                lru_list_.pop_back();
            }
            // Add new item to front (MRU)
            lru_list_.emplace_front(key, value);
            cache_[key] = lru_list_.begin();
        }
    }

    bool get(int key, std::string& out) {
        auto it = cache_.find(key);
        if (it == cache_.end()) {
            return false;
        }
        // Move to front (MRU)
        lru_list_.splice(lru_list_.begin(), lru_list_, it->second);
        out = it->second->second;
        return true;
    }

    bool erase(int key) {
        auto it = cache_.find(key);
        if (it == cache_.end()) {
            return false;
        }
        lru_list_.erase(it->second);
        cache_.erase(it);
        return true;
    }

    size_t size() const {
        return lru_list_.size();
    }

    std::vector<std::pair<int, std::string>> snapshot() const {
        std::vector<std::pair<int, std::string>> result;
        result.reserve(lru_list_.size());
        for (const auto& pair : lru_list_) {
            result.emplace_back(pair.first, pair.second);
        }
        return result;
    }
};