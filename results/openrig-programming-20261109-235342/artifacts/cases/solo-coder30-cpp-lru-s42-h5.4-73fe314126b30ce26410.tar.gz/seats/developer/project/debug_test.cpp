#include <iostream>
#include "solution.hpp"

int main() {
    LruCache cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::cout << "After putting 1, 2, 3:" << std::endl;
    auto snapshot = cache.snapshot();
    std::cout << "Snapshot size: " << snapshot.size() << std::endl;
    for (size_t i = 0; i < snapshot.size(); ++i) {
        std::cout << "  [" << snapshot[i].first << ", " << snapshot[i].second << "]" << std::endl;
    }
    
    // Access 1 to make it MRU
    std::string value;
    cache.get(1, value);
    
    std::cout << "After getting 1 (making it MRU):" << std::endl;
    snapshot = cache.snapshot();
    std::cout << "Snapshot size: " << snapshot.size() << std::endl;
    for (size_t i = 0; i < snapshot.size(); ++i) {
        std::cout << "  [" << snapshot[i].first << ", " << snapshot[i].second << "]" << std::endl;
    }
    
    return 0;
}