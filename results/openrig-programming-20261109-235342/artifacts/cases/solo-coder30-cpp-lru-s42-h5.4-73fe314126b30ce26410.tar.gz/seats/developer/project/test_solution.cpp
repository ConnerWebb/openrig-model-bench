#include <iostream>
#include <cassert>
#include <string>
#include "solution.hpp"

void test_basic_operations() {
    LruCache cache(2);
    
    // Test put and get
    cache.put(1, "one");
    cache.put(2, "two");
    
    std::string value;
    assert(cache.get(1, value));
    assert(value == "one");
    
    assert(cache.get(2, value));
    assert(value == "two");
    
    // Test update existing key
    cache.put(1, "updated");
    assert(cache.get(1, value));
    assert(value == "updated");
    
    // Test eviction
    cache.put(3, "three"); // This should evict key 2
    assert(!cache.get(2, value)); // Should not find key 2
    
    assert(cache.get(1, value));
    assert(value == "updated");
    
    assert(cache.get(3, value));
    assert(value == "three");
    
    // Test erase
    assert(cache.erase(1));
    assert(!cache.erase(1)); // Should not find key 1 anymore
    assert(!cache.get(1, value)); // Should not find key 1 anymore
    
    assert(cache.size() == 1);
}

void test_capacity_zero() {
    LruCache cache(0);
    
    cache.put(1, "one");
    assert(cache.size() == 0);
    std::string value;
    assert(!cache.get(1, value));
    assert(!cache.erase(1));
}

void test_snapshot() {
    LruCache cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    auto snapshot = cache.snapshot();
    assert(snapshot.size() == 3);
    // Snapshot should return items in MRU order (most recently used first)
    assert(snapshot[0].first == 3);
    assert(snapshot[0].second == "three");
    assert(snapshot[1].first == 2);
    assert(snapshot[1].second == "two");
    assert(snapshot[2].first == 1);
    assert(snapshot[2].second == "one");
    
    // Access 1 to make it MRU
    std::string value;
    cache.get(1, value);
    
    snapshot = cache.snapshot();
    assert(snapshot.size() == 3);
    // Now 1 should be MRU
    assert(snapshot[0].first == 1);
    assert(snapshot[0].second == "one");
    assert(snapshot[1].first == 3);
    assert(snapshot[1].second == "three");
    assert(snapshot[2].first == 2);
    assert(snapshot[2].second == "two");
}

int main() {
    test_basic_operations();
    test_capacity_zero();
    test_snapshot();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}