# LRU Cache Implementation

This is a C++20 implementation of an LRU (Least Recently Used) Cache with the following features:

## Features
- **O(1) average time complexity** for put, get, and erase operations
- **Correct MRU (Most Recently Used) behavior**: Successful get and every put make the key MRU
- **Proper eviction**: When capacity is exceeded, the LRU item is evicted
- **Capacity 0 handling**: When capacity is 0, the cache stores nothing
- **Snapshot functionality**: Returns all items in MRU order
- **Correct RAII**: Proper resource management
- **Copy semantics**: Copying is disabled as required

## Interface
```cpp
class LruCache {
public:
    explicit LruCache(size_t capacity);
    
    void put(int key, const std::string& value);
    bool get(int key, std::string& out);
    bool erase(int key);
    size_t size() const;
    std::vector<std::pair<int, std::string>> snapshot() const;
};
```

## Implementation Details
- Uses `std::unordered_map` for O(1) key lookup
- Uses `std::list` to maintain order of usage (MRU at front)
- When a key is accessed (get/put), it's moved to the front of the list
- When capacity is exceeded, the last element (LRU) is removed
- The snapshot returns items in MRU order (most recent first)

## Usage Example
```cpp
LruCache cache(2);
cache.put(1, "one");
cache.put(2, "two");
std::string value;
if (cache.get(1, value)) {
    // value contains "one"
}
cache.put(3, "three"); // Evicts key 2
cache.erase(1); // Removes key 1
```