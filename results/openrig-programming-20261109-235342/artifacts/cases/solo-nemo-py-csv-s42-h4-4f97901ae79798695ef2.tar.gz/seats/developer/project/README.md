# CSV Aggregation Solution

This project implements a Python function `aggregate(path: str) -> dict[str, str]` that reads a CSV file with a specific format and aggregates the amounts by category using exact decimal arithmetic.

## Implementation Details

- Reads CSV files with header `category,amount`
- Strips whitespace from category and amount fields
- Validates that categories are non-empty and amounts match the expected format
- Uses `decimal.Decimal` for exact arithmetic
- Returns a dictionary with categories as keys and amounts formatted to exactly two decimal places, with keys sorted

## Usage

```python
from solution import aggregate

result = aggregate('path/to/file.csv')
print(result)
```

## Testing

Tests are written in `test_solution.py` and use the public test cases provided in `PUBLIC_CASES.json`. The tests validate both correct behavior and proper error handling for malformed input.

