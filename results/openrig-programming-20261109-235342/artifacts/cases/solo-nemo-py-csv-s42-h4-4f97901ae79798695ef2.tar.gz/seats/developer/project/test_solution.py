import json
import tempfile
import os
from solution import aggregate

def run_test(driver_input_csv: str, expected: dict):
    # Write CSV to a temporary file
    with tempfile.NamedTemporaryFile(mode='w+', delete=False, encoding='utf-8') as tmp:
        tmp.write(driver_input_csv)
        tmp_path = tmp.name
    try:
        result = aggregate(tmp_path)
        if 'error' in expected:
            # Expecting ValueError
            try:
                aggregate(tmp_path)
                raise AssertionError(f"Expected ValueError but got result: {result}")
            except ValueError:
                pass  # Expected error raised
            except Exception as e:
                raise AssertionError(f"Expected ValueError but got {type(e).__name__}: {e}")
        else:
            # Compare result with expected values
            # The expected dict contains a 'value' key with the actual result mapping
            if 'value' not in expected:
                raise AssertionError(f"Test case missing 'value' key")
            expected_values = expected['value']
            if not expected_values:
                raise AssertionError(f"Expected non-empty value dict but got empty")
            for key, expected_val in expected_values.items():
                if key not in result:
                    raise AssertionError(f"Key '{key}' missing from result")
                if result[key] != expected_val:
                    raise AssertionError(f"For key '{key}', expected '{expected_val}' but got '{result[key]}'")
    finally:
        os.unlink(tmp_path)

# Load test cases from PUBLIC_CASES.json
with open('PUBLIC_CASES.json', 'r', encoding='utf-8') as f:
    cases = json.load(f)

# Run each test case
for case in cases:
    driver_input = case['driver_input']['csv']
    expected = case['expected']
    run_test(driver_input, expected)

print("All tests passed.")
