import csv, sys, decimal, re

decimal.getcontext().prec = 20

def aggregate(path: str) -> dict[str, str]:
    totals = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            return {}
        if header != ['category', 'amount']:
            raise ValueError('Header must be exactly category,amount')
        for row_num, row in enumerate(reader, start=2):
            if not row:
                continue
            if len(row) != 2:
                raise ValueError(f'Record {row_num} must have exactly two fields')
            category, amount_str = row
            category = category.strip()
            amount_str = amount_str.strip()
            if not category:
                raise ValueError(f'Empty category in record {row_num}')
            # Validate amount format: optional leading +, digits, optional decimal part
            if not re.fullmatch(r'\+?\d+(\.\d{1,2})?', amount_str):
                raise ValueError(f'Invalid amount format in record {row_num}: {amount_str}')
            amount = decimal.Decimal(amount_str)
            if amount.is_infinite() or amount.is_signed():
                raise ValueError(f'Amount must be non-negative finite number in record {row_num}')
            totals[category] = totals.get(category, decimal.Decimal('0'))
            totals[category] += amount
    # Format totals to exactly two decimal places
    formatted = {k: f"{v:.2f}" for k, v in totals.items()}
    # Return dict with keys sorted
    return {k: formatted[k] for k in sorted(formatted)}
