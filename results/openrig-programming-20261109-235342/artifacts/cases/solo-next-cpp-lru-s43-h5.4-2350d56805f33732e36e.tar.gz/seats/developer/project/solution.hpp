#pragma once

#include <list>
#include <unordered_map>
#include <vector>
#include <utility>

class LruCache {
public:
    explicit LruCache(size_t capacity) : capacity_(capacity) {}

    void put(int key, std::string value) {
        auto it = map_.find(key);
        if (it != map_.end()) {
            it->second->second = std::move(value);
            list_.splice(list_.begin(), list_, it->second);
            return;
        }

        if (list_.size() >= capacity_) {
            if (!list_.empty()) {
                auto last = list_.back();
                map_.erase(last.first);
                list_.pop_back();
            }
        }

        list_.emplace_front(key, std::move(value));
        map_[key] = list_.begin();
    }

    bool get(int key, std::string& out) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }
        list_.splice(list_.begin(), list_, it->second);
        out = it->second->second;
        return true;
    }

    bool erase(int key) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }
        list_.erase(it->second);
        map_.erase(it);
        return true;
    }

    size_t size() const {
        return list_.size();
    }

    std::vector<std::pair<int, std::string>> snapshot() const {
        std::vector<std::pair<int, std::string>> result;
        result.reserve(list_.size());
        for (const auto& item : list_) {
            result.emplace_back(item.first, item.second);
        }
        return result;
    }

private:
    size_t capacity_;
    std::list<std::pair<int, std::string>> list_;
    std::unordered_map<int, std::list<std::pair<int, std::string>>::iterator> map_;
};
