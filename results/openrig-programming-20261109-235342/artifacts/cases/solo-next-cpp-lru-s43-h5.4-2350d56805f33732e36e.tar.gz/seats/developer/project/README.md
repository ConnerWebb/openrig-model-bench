# LRU Cache Implementation

A C++20 implementation of an LRU (Least Recently Used) cache with O(1) average time complexity for get, put, and erase operations.

## API

```cpp
class LruCache {
public:
    explicit LruCache(size_t capacity);
    void put(int key, std::string value);
    bool get(int key, std::string& out);
    bool erase(int key);
    size_t size() const;
    std::vector<std::pair<int, std::string>> snapshot() const;
};
```

## Usage

```cpp
#include "solution.hpp"

int main() {
    LruCache cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string value;
    cache.get(1, value); // value = "one", returns true
    
    cache.put(4, "four"); // evicts key 2 (LRU)
    
    auto snapshot = cache.snapshot(); // [(3,"three"), (1,"one"), (4,"four")]
}
```

## Implementation Details

- Uses `std::list` for ordering (most recent at front)
- Uses `std::unordered_map` for O(1) key lookup
- On overflow, the least recently used item (back of list) is evicted
- `get()` and `put()` both move the accessed key to the front (most recent)
- `snapshot()` returns items in order from most to least recent
