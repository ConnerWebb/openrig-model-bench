#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"
std::string js(const std::string&s){std::ostringstream o;o<<'"';for(unsigned char c:s){if(c=='"'||c=='\\')o<<'\\'<<c;else if(c=='\n')o<<"\\n";else if(c=='\r')o<<"\\r";else if(c=='\t')o<<"\\t";else if(c<32)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)c<<std::dec;else o<<c;}o<<'"';return o.str();}
int main(){try{
int cap,n;std::cin>>cap>>n;LruCache q(cap);std::cout<<"{\"value\":[";for(int i=0;i<n;i++){if(i)std::cout<<',';char op;int k;std::cin>>op;if(op=='P'){std::string v;std::cin>>k>>std::quoted(v);q.put(k,v);std::cout<<"null";}else if(op=='G'){std::cin>>k;std::string v="UNCHANGED";bool ok=q.get(k,v);std::cout<<"["<<(ok?"true":"false")<<','<<js(v)<<']';}else if(op=='E'){std::cin>>k;std::cout<<(q.erase(k)?"true":"false");}else if(op=='S'){std::cout<<'[';bool first=true;for(auto&[a,b]:q.snapshot()){if(!first)std::cout<<',';first=false;std::cout<<'['<<a<<','<<js(b)<<']';}std::cout<<']';}else throw std::invalid_argument("op");}std::cout<<"],\"size\":"<<q.size()<<'}';
}catch(const std::exception&e){std::cout<<"{\"error\":\"ValueError\"}";}catch(...){std::cout<<"{\"error\":\"ValueError\"}";}std::cout<<std::endl;}
