import sqlite3
import json
from typing import Any, Dict, Optional


class JobQueue:
    """SQLite-based job queue with atomic operations."""

    def __init__(self, path: str, max_attempts: int = 3):
        """Initialize the job queue.

        Args:
            path: Path to SQLite database file
            max_attempts: Maximum number of attempts before a job is failed

        Raises:
            ValueError: If max_attempts is not positive
        """
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")

        self.max_attempts = max_attempts
        self.path = path
        self._init_db()

    def _init_db(self):
        """Initialize the database schema."""
        with sqlite3.connect(self.path, check_same_thread=False) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL,
                    attempts INTEGER NOT NULL,
                    owner TEXT,
                    lease_until REAL
                )
            ''')
            conn.commit()
            conn.commit()

    def _json_load(self, s: str) -> Any:
        """Load JSON string to Python object."""
        return json.loads(s)

    def _json_dump(self, obj: Any) -> str:
        """Dump Python object to JSON string."""
        return json.dumps(obj)

    def enqueue(self, key: str, payload: Any) -> bool:
        """Enqueue a job with the given key and payload.

        Args:
            key: Unique identifier for the job
            payload: JSON-serializable value to store with the job

        Returns:
            True if the job was enqueued, False if the key already exists

        Raises:
            ValueError: If key is empty or payload is not JSON-serializable
        """
        if not key:
            raise ValueError("key cannot be empty")

        try:
            payload_str = self._json_dump(payload)
        except (TypeError, ValueError) as e:
            raise ValueError("payload must be JSON-serializable") from e

        with sqlite3.connect(self.path, check_same_thread=False) as conn:
            try:
                conn.execute(
                    'INSERT INTO jobs (key, payload, state, attempts) '
                    'VALUES (?, ?, ?, 0)',
                    (key, payload_str, 'queued')
                )
                conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        """Atomically claim the oldest eligible job.

        Args:
            worker: Identifier of the worker claiming the job
            now: Current timestamp
            lease: Lease duration in seconds

        Returns:
            Dictionary with key, payload, and attempts, or None if no job is eligible

        Raises:
            ValueError: If worker is empty or lease is not positive
        """
        if not worker:
            raise ValueError("worker cannot be empty")

        if lease <= 0:
            raise ValueError("lease must be positive")

        with sqlite3.connect(self.path, check_same_thread=False) as conn:
            conn.execute('BEGIN IMMEDIATE')
            try:
                # Find oldest eligible job
                cursor = conn.execute('''
                    SELECT key, payload, attempts
                    FROM jobs
                    WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                      AND attempts < ?
                    ORDER BY key ASC
                    LIMIT 1
                ''', (now, self.max_attempts))

                row = cursor.fetchone()
                if not row:
                    conn.rollback()
                    return None

                key, payload_str, attempts = row
                payload = self._json_load(payload_str)

                # Update job state (don't increment attempts here, it's already incremented in fail)
                conn.execute('''
                    UPDATE jobs
                    SET state = 'leased',
                        owner = ?,
                        lease_until = ?
                    WHERE key = ?
                ''', (worker, now + lease, key))

                conn.commit()
                return {
                    'key': key,
                    'payload': payload,
                    'attempts': attempts
                }
            except Exception:
                conn.rollback()
                raise

    def complete(self, key: str, worker: str) -> bool:
        """Complete a job that is currently leased by the specified worker.

        Args:
            key: Identifier of the job to complete
            worker: Identifier of the worker claiming to own the job

        Returns:
            True if the job was completed, False otherwise

        Raises:
            ValueError: If key or worker is empty
        """
        if not key:
            raise ValueError("key cannot be empty")

        if not worker:
            raise ValueError("worker cannot be empty")

        with sqlite3.connect(self.path, check_same_thread=False) as conn:
            conn.execute('BEGIN IMMEDIATE')
            try:
                # Check if job is leased by the specified worker
                cursor = conn.execute('''
                    SELECT owner
                    FROM jobs
                    WHERE key = ? AND state = 'leased'
                ''', (key,))

                row = cursor.fetchone()
                if not row or row[0] != worker:
                    conn.rollback()
                    return False

                # Update job state
                conn.execute(
                    'UPDATE jobs SET state = ? WHERE key = ?',
                    ('done', key)
                )

                conn.commit()
                return True
            except Exception:
                conn.rollback()
                raise

    def fail(self, key: str, worker: str) -> bool:
        """Fail a job that is currently leased by the specified worker.

        Args:
            key: Identifier of the job to fail
            worker: Identifier of the worker claiming to own the job

        Returns:
            True if the job was failed, False otherwise

        Raises:
            ValueError: If key or worker is empty
        """
        if not key:
            raise ValueError("key cannot be empty")

        if not worker:
            raise ValueError("worker cannot be empty")

        with sqlite3.connect(self.path, check_same_thread=False) as conn:
            conn.execute('BEGIN IMMEDIATE')
            try:
                # Check if job is leased by the specified worker
                cursor = conn.execute('''
                    SELECT owner, attempts
                    FROM jobs
                    WHERE key = ? AND state = 'leased'
                ''', (key,))

                row = cursor.fetchone()
                if not row or row[0] != worker:
                    conn.rollback()
                    return False

                owner, attempts = row

                # If attempts are exhausted, mark as failed
                if attempts >= self.max_attempts:
                    conn.execute(
                        'UPDATE jobs SET state = ? WHERE key = ?',
                        ('failed', key)
                    )
                else:
                    # Requeue the job (don't increment attempts here, it's already incremented in claim)
                    conn.execute('''
                        UPDATE jobs
                        SET state = 'queued',
                            owner = NULL,
                            lease_until = NULL
                        WHERE key = ?
                    ''', (key,))

                conn.commit()
                return True
            except Exception:
                conn.rollback()
                raise

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        """Get the status of a job.

        Args:
            key: Identifier of the job

        Returns:
            Dictionary with state and attempts, or None if the job doesn't exist
        """
        with sqlite3.connect(self.path, check_same_thread=False) as conn:
            cursor = conn.execute(
                'SELECT state, attempts FROM jobs WHERE key = ?',
                (key,)
            )

            row = cursor.fetchone()
            if not row:
                return None

            state, attempts = row
            return {
                'state': state,
                'attempts': attempts
            }