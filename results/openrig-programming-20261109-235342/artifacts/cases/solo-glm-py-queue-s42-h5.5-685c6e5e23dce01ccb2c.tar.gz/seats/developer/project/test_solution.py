import unittest
import json
import tempfile
import os
import sys
sys.path.insert(0, '/work')
import solution


class TestJobQueue(unittest.TestCase):
    """Test suite for JobQueue implementation."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')

    def tearDown(self):
        """Clean up test fixtures."""
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.temp_dir)

    def test_enqueue_basic(self):
        """Test basic enqueue operation."""
        q = solution.JobQueue(self.db_path)
        result = q.enqueue('a', {'v': 5304})
        self.assertTrue(result)

    def test_enqueue_duplicate(self):
        """Test that duplicate enqueue returns False."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        result = q.enqueue('a', 'ignored')
        self.assertFalse(result)

    def test_enqueue_invalid_key(self):
        """Test that empty key raises ValueError."""
        q = solution.JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue('', {'v': 5304})

    def test_enqueue_invalid_payload(self):
        """Test that non-JSON payload raises ValueError."""
        q = solution.JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue('a', lambda x: x)

    def test_enqueue_invalid_max_attempts(self):
        """Test that non-positive max_attempts raises ValueError."""
        with self.assertRaises(ValueError):
            solution.JobQueue(self.db_path, max_attempts=0)

    def test_claim_basic(self):
        """Test basic claim operation."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        result = q.claim('w', 0, 5)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['payload'], {'v': 5304})
        self.assertEqual(result['attempts'], 1)

    def test_claim_no_jobs(self):
        """Test claim when no jobs are available."""
        q = solution.JobQueue(self.db_path)
        result = q.claim('w', 0, 5)
        self.assertIsNone(result)

    def test_claim_invalid_worker(self):
        """Test that empty worker raises ValueError."""
        q = solution.JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim('', 0, 5)

    def test_claim_invalid_lease(self):
        """Test that non-positive lease raises ValueError."""
        q = solution.JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim('w', 0, 0)

    def test_claim_leased_job(self):
        """Test claiming a leased job."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.claim('w2', 0, 5)
        self.assertIsNone(result)

    def test_claim_expired_lease(self):
        """Test claiming a job with expired lease."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.claim('w2', 10, 5)
        self.assertIsNotNone(result)
        self.assertEqual(result['attempts'], 1)

    def test_claim_oldest_first(self):
        """Test that oldest job is claimed first."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('b', {'v': 1})
        q.enqueue('a', {'v': 2})
        result = q.claim('w', 0, 5)
        self.assertEqual(result['key'], 'a')

    def test_claim_attempts_increment(self):
        """Test that attempts are incremented on claim."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        result1 = q.claim('w', 0, 5)
        result2 = q.claim('w', 0, 5)
        self.assertEqual(result1['attempts'], 1)
        self.assertEqual(result2['attempts'], 2)

    def test_complete_success(self):
        """Test successful completion."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.complete('a', 'w')
        self.assertTrue(result)

    def test_complete_wrong_worker(self):
        """Test completion with wrong worker."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.complete('a', 'wrong')
        self.assertFalse(result)

    def test_complete_nonexistent(self):
        """Test completion of nonexistent job."""
        q = solution.JobQueue(self.db_path)
        result = q.complete('a', 'w')
        self.assertFalse(result)

    def test_fail_success(self):
        """Test successful fail operation."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.fail('a', 'w')
        self.assertTrue(result)

    def test_fail_wrong_worker(self):
        """Test fail with wrong worker."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.fail('a', 'wrong')
        self.assertFalse(result)

    def test_fail_requeue(self):
        """Test that fail requeues the job."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        q.fail('a', 'w')
        result = q.claim('w2', 0, 5)
        self.assertIsNotNone(result)
        self.assertEqual(result['attempts'], 2)

    def test_fail_exhausted_attempts(self):
        """Test that fail marks job as failed when attempts exhausted."""
        q = solution.JobQueue(self.db_path, max_attempts=2)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        q.fail('a', 'w')
        q.fail('a', 'w')
        result = q.claim('w2', 0, 5)
        self.assertIsNone(result)

    def test_status_queued(self):
        """Test status of queued job."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        result = q.status('a')
        self.assertEqual(result['state'], 'queued')
        self.assertEqual(result['attempts'], 0)

    def test_status_leased(self):
        """Test status of leased job."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        result = q.status('a')
        self.assertEqual(result['state'], 'leased')

    def test_status_done(self):
        """Test status of completed job."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        q.complete('a', 'w')
        result = q.status('a')
        self.assertEqual(result['state'], 'done')

    def test_status_failed(self):
        """Test status of failed job."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.claim('w', 0, 5)
        q.fail('a', 'w')
        result = q.status('a')
        self.assertEqual(result['state'], 'failed')

    def test_status_nonexistent(self):
        """Test status of nonexistent job."""
        q = solution.JobQueue(self.db_path)
        result = q.status('a')
        self.assertIsNone(result)

    def test_multiple_workers(self):
        """Test concurrent access from multiple workers."""
        q = solution.JobQueue(self.db_path)
        q.enqueue('a', {'v': 5304})
        q.enqueue('b', {'v': 8330})
        result1 = q.claim('w1', 0, 5)
        result2 = q.claim('w2', 0, 5)
        self.assertIsNotNone(result1)
        self.assertIsNotNone(result2)
        self.assertNotEqual(result1['key'], result2['key'])

    def test_shared_database(self):
        """Test that multiple instances share the same database."""
        q1 = solution.JobQueue(self.db_path)
        q2 = solution.JobQueue(self.db_path)
        q1.enqueue('a', {'v': 5304})
        result = q2.claim('w', 0, 5)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'a')

    def test_json_payload(self):
        """Test that JSON payloads are correctly serialized/deserialized."""
        q = solution.JobQueue(self.db_path)
        complex_payload = {
            'nested': {'list': [1, 2, 3]},
            'string': 'test',
            'number': 42
        }
        q.enqueue('a', complex_payload)
        result = q.claim('w', 0, 5)
        self.assertEqual(result['payload'], complex_payload)

    def test_max_attempts_parameter(self):
        """Test custom max_attempts parameter."""
        q = solution.JobQueue(self.db_path, max_attempts=5)
        self.assertEqual(q.max_attempts, 5)


if __name__ == '__main__':
    unittest.main()