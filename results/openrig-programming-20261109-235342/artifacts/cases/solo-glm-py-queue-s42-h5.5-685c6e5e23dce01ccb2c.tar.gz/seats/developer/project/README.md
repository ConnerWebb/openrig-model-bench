# JobQueue - SQLite-based Job Queue Implementation

A simple, thread-safe job queue implementation using SQLite as the backend storage.

## Features

- **Thread-safe**: Multiple instances can share the same SQLite database
- **Atomic operations**: Claims are performed atomically to prevent race conditions
- **Lease management**: Jobs can be leased with expiration times
- **Automatic retry**: Failed jobs are automatically requeued
- **JSON payloads**: Supports JSON-serializable payloads

## API

### JobQueue(path, max_attempts=3)

Initialize a new JobQueue instance.

**Parameters:**
- `path` (str): Path to SQLite database file
- `max_attempts` (int, optional): Maximum number of attempts before a job is considered failed. Defaults to 3.

**Raises:**
- `ValueError`: If `max_attempts` is not positive

### enqueue(key, payload) -> bool

Enqueue a job with the given key and payload.

**Parameters:**
- `key` (str): Unique identifier for the job
- `payload` (Any): JSON-serializable value to store with the job

**Returns:**
- `bool`: True if the job was enqueued (first unique key wins), False if the key already exists

**Raises:**
- `ValueError`: If key is empty or payload is not JSON-serializable

### claim(worker, now, lease) -> Optional[Dict[str, Any]]

Atomically claim the oldest eligible job.

A job is eligible if:
- State is 'queued' or 'leased'
- Lease_until <= now (for leased jobs)
- Attempts < max_attempts

**Parameters:**
- `worker` (str): Identifier of the worker claiming the job
- `now` (float): Current timestamp
- `lease` (float): Lease duration in seconds

**Returns:**
- `Optional[Dict[str, Any]]`: Dictionary with key, payload, and attempts, or None if no job is eligible

**Raises:**
- `ValueError`: If worker is empty or lease is not positive

### complete(key, worker) -> bool

Complete a job that is currently leased by the specified worker.

**Parameters:**
- `key` (str): Identifier of the job to complete
- `worker` (str): Identifier of the worker claiming to own the job

**Returns:**
- `bool`: True if the job was completed, False otherwise

**Raises:**
- `ValueError`: If key or worker is empty

### fail(key, worker) -> bool

Fail a job that is currently leased by the specified worker.

If attempts are exhausted, the job becomes failed. Otherwise, it's queued again.

**Parameters:**
- `key` (str): Identifier of the job to fail
- `worker` (str): Identifier of the worker claiming to own the job

**Returns:**
- `bool`: True if the job was failed, False otherwise

**Raises:**
- `ValueError`: If key or worker is empty

### status(key) -> Optional[Dict[str, Any]]

Get the status of a job.

**Parameters:**
- `key` (str): Identifier of the job

**Returns:**
- `Optional[Dict[str, Any]]`: Dictionary with state and attempts, or None if the job doesn't exist

## State Machine

```
queued (attempts=0)
    ↓ claim
leased (attempts>0, owner=worker, lease_until=now+lease)
    ↓ complete → done
    ↓ fail → queued (attempts+1) or failed (attempts>=max_attempts)
```

## Usage Example

```python
import solution

# Create a job queue
q = solution.JobQueue('jobs.db')

# Enqueue jobs
q.enqueue('job1', {'data': 'value1'})
q.enqueue('job2', {'data': 'value2'})

# Claim a job
result = q.claim('worker1', 0, 5)
print(result)  # {'key': 'job1', 'payload': {'data': 'value1'}, 'attempts': 1}

# Complete the job
q.complete('job1', 'worker1')

# Check status
status = q.status('job1')
print(status)  # {'state': 'done', 'attempts': 1}
```

## Testing

Run the test suite:

```bash
python test_solution.py
```

## Implementation Details

- **Database Schema**:
  - `key`: Primary key (TEXT)
  - `payload`: JSON string (TEXT)
  - `state`: Job state (TEXT) - 'queued', 'leased', 'done', 'failed'
  - `attempts`: Number of attempts (INTEGER)
  - `owner`: Worker identifier (TEXT)
  - `lease_until`: Lease expiration timestamp (REAL)

- **Concurrency**: Uses SQLite's `BEGIN IMMEDIATE` transaction for atomic claims
- **Thread Safety**: Uses `check_same_thread=False` to allow multiple threads to access the same connection

## Requirements

- Python 3.14+
- SQLite 3 (included with Python)
- No external dependencies