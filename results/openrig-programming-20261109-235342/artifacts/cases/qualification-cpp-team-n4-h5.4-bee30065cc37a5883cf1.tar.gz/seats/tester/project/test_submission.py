import unittest
import subprocess
import json
import os
import tempfile

class TestSubmission(unittest.TestCase):
    def _run_driver(self, input_str):
        with tempfile.TemporaryDirectory() as tmpdir:
            driver_path = os.path.join(tmpdir, "driver")
            cpp_path = os.path.join(tmpdir, "driver.cpp")
            with open(cpp_path, "w") as f:
                f.write(open("/work/PUBLIC_DRIVER.cpp").read())
            compile_cmd = ["clang++", "-fuse-ld=bfd", "-std=c++20", "-O2", "-I", "/work", "-o", driver_path, cpp_path]
            result = subprocess.run(compile_cmd, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
            proc = subprocess.run([driver_path], input=input_str, capture_output=True, text=True, timeout=5)
            return proc.stdout.strip(), proc.returncode

    def _parse_output(self, out):
        if out.startswith("{\"error\""):
            return {"error": "ValueError"}
        return json.loads(out)

    def test_case_00(self):
        inp = open("/work/public-inputs/case-00.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-00.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_01(self):
        inp = open("/work/public-inputs/case-01.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-01.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_02(self):
        inp = open("/work/public-inputs/case-02.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-02.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_03(self):
        inp = open("/work/public-inputs/case-03.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-03.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_04(self):
        inp = open("/work/public-inputs/case-04.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-04.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_05(self):
        inp = open("/work/public-inputs/case-05.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-05.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_06(self):
        inp = open("/work/public-inputs/case-06.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-06.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_07(self):
        inp = open("/work/public-inputs/case-07.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-07.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_08(self):
        inp = open("/work/public-inputs/case-08.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-08.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_09(self):
        inp = open("/work/public-inputs/case-09.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-09.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_10(self):
        inp = open("/work/public-inputs/case-10.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-10.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_11(self):
        inp = open("/work/public-inputs/case-11.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-11.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_case_12(self):
        inp = open("/work/public-inputs/case-12.json").read().strip()
        out, rc = self._run_driver(inp)
        expected = json.loads(open("/work/public-inputs/case-12.json").read().strip())
        self.assertEqual(self._parse_output(out), expected)

    def test_cache_lru(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            driver_path = os.path.join(tmpdir, "driver")
            cpp_path = os.path.join(tmpdir, "driver.cpp")
            with open(cpp_path, "w") as f:
                f.write(open("/work/PUBLIC_DRIVER.cpp").read())
            compile_cmd = ["clang++", "-fuse-ld=bfd", "-std=c++20", "-O2", "-I", "/work", "-o", driver_path, cpp_path]
            result = subprocess.run(compile_cmd, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
            inp = "1 2 10 P 1 \"a\" P 2 \"b\" P 3 \"c\" G 1 G 2 G 3 S"
            proc = subprocess.run([driver_path], input=inp, capture_output=True, text=True, timeout=5)
            out = proc.stdout.strip()
            data = json.loads(out)
            self.assertEqual(data["size"], 2)
            self.assertEqual(data["value"][0], [False, "UNCHANGED"])
            self.assertEqual(data["value"][1], [True, "b"])
            self.assertEqual(data["value"][2], [True, "c"])
            self.assertEqual(data["value"][3], [[2, "b"], [3, "c"]])

    def test_stats_basic(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            driver_path = os.path.join(tmpdir, "driver")
            cpp_path = os.path.join(tmpdir, "driver.cpp")
            with open(cpp_path, "w") as f:
                f.write(open("/work/PUBLIC_DRIVER.cpp").read())
            compile_cmd = ["clang++", "-fuse-ld=bfd", "-std=c++20", "-O2", "-I", "/work", "-o", driver_path, cpp_path]
            result = subprocess.run(compile_cmd, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
            inp = "2 5 2 0 1.0 2.0 3.0 4.0 5.0"
            proc = subprocess.run([driver_path], input=inp, capture_output=True, text=True, timeout=5)
            out = proc.stdout.strip()
            data = json.loads(out)
            self.assertEqual(data["value"][0], 10)
            self.assertAlmostEqual(data["value"][1], 5.5, places=6)
            self.assertAlmostEqual(data["value"][2], 8.25, places=6)
            self.assertEqual(data["value"][3], 1.0)
            self.assertEqual(data["value"][4], 10.0)

if __name__ == "__main__":
    unittest.main()
