#include <iostream>
#include <sstream>
#include <cassert>
#include "parser.hpp"
int main() {
  std::istringstream in("category,amount\na,100\nb,200\n");
  auto res = aggregate(in);
  assert(res["a"] == 100);
  assert(res["b"] == 200);
  std::cout << "parser basic OK\n";
  return 0;
}
