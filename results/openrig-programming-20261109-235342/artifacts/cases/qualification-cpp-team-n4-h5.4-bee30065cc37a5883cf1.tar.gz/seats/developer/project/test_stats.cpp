#include <iostream>
#include <cassert>
#include "stats.hpp"
int main() {
  RunningStats s;
  s.add(2.0);
  s.add(4.0);
  assert(s.count() == 2);
  assert(s.mean() == 3.0);
  assert(s.variance() == 1.0);
  assert(s.minimum() == 2.0);
  assert(s.maximum() == 4.0);
  std::cout << "stats basic OK\n";
  return 0;
}
