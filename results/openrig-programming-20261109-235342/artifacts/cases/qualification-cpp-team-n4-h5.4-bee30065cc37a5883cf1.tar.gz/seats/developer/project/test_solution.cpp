#include <iostream>
#include <sstream>
#include <cassert>
#include "solution.hpp"
int main() {
  // Test aggregate
  std::istringstream in1("category,amount\na,100\nb,200\n");
  auto res = aggregate(in1);
  assert(res["a"] == 100);
  assert(res["b"] == 200);

  // Test LruCache
  LruCache c(2);
  c.put(1, "one");
  c.put(2, "two");
  std::string v;
  assert(c.get(1, v) && v == "one");
  assert(c.size() == 2);

  // Test RunningStats
  RunningStats s;
  s.add(2.0);
  s.add(4.0);
  assert(s.mean() == 3.0);

  std::cout << "solution basic OK\n";
  return 0;
}
