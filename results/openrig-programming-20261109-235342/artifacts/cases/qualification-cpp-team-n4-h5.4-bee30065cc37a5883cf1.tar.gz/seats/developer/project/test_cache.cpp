#include <iostream>
#include <cassert>
#include "cache.hpp"
int main() {
  LruCache c(2);
  c.put(1, "one");
  c.put(2, "two");
  std::string v;
  assert(c.get(1, v) && v == "one");
  assert(c.get(2, v) && v == "two");
  c.put(3, "three");
  assert(!c.get(1, v));
  assert(c.get(3, v) && v == "three");
  assert(c.size() == 2);
  auto snap = c.snapshot();
  assert(snap.size() == 2);
  std::cout << "cache basic OK\n";
  return 0;
}
