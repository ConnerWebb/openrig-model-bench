# CSV Aggregate Module

Provides `aggregate(std::istream&)` that parses CSV with header `category,amount`, supports quoted fields with embedded commas/newlines and escaped double quotes, and returns a sorted `std::map<std::string,std::int64_t>` of category totals.

## Usage

```cpp
#include "parser.hpp"
#include <sstream>
#include <iostream>

int main() {
  std::istringstream in("category,amount\nfood,100\nrent,500\nfood,50\n");
  auto result = aggregate(in);
  for (auto& [k,v] : result) std::cout << k << ": " << v << "\n";
  // Output:
  // food: 150
  // rent: 500
}
```

## Error handling

Throws `std::invalid_argument` for:
- Wrong header
- Wrong field count
- Empty category or amount
- Non-integer or out-of-range amount
- Malformed quoting
