#ifndef PARSER_HPP
#define PARSER_HPP

#include <map>
#include <string>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <cctype>
#include <limits>

namespace {

std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

bool is_digit(char c) {
    return c >= '0' && c <= '9';
}

bool is_sign(char c) {
    return c == '+' || c == '-';
}

bool is_valid_digit_sequence(const std::string& s, size_t start, size_t len) {
    if (len == 0) return false;
    size_t i = 0;
    if (start < s.size() && is_sign(s[start])) {
        ++i;
        ++start;
        --len;
    }
    if (len == 0) return false;
    for (size_t j = 0; j < len; ++j) {
        if (!is_digit(s[start + j])) return false;
    }
    return true;
}

std::int64_t parse_int64(const std::string& s, size_t start, size_t len) {
    if (!is_valid_digit_sequence(s, start, len)) {
        throw std::invalid_argument("invalid integer");
    }
    bool negative = false;
    size_t pos = start;
    if (pos < s.size() && is_sign(s[pos])) {
        if (s[pos] == '-') negative = true;
        ++pos;
    }
    std::int64_t value = 0;
    for (size_t i = 0; i < len; ++i) {
        char c = s[pos + i];
        if (!is_digit(c)) {
            throw std::invalid_argument("invalid integer");
        }
        int digit = c - '0';
        if (negative) {
            if (value < (std::numeric_limits<std::int64_t>::min() + digit) / 10) {
                throw std::invalid_argument("integer overflow");
            }
            value = value * 10 - digit;
        } else {
            if (value > (std::numeric_limits<std::int64_t>::max() - digit) / 10) {
                throw std::invalid_argument("integer overflow");
            }
            value = value * 10 + digit;
        }
    }
    return value;
}

struct CSVParser {
    std::istream& in;
    std::string buffer;
    size_t pos = 0;
    size_t len = 0;
    bool eof = false;

    explicit CSVParser(std::istream& is) : in(is) {}

    char peek() {
        if (pos >= len && !eof) {
            if (!std::getline(in, buffer)) {
                eof = true;
                return '\0';
            }
            buffer += '\n';
            len = buffer.size();
            pos = 0;
        }
        if (pos >= len) return '\0';
        return buffer[pos];
    }

    char get() {
        char c = peek();
        if (c != '\0') ++pos;
        return c;
    }

    bool is_whitespace(char c) {
        return c == ' ' || c == '\t' || c == '\r';
    }

    bool is_line_end(char c) {
        return c == '\n' || c == '\0';
    }

    std::string read_quoted_field() {
        std::string result;
        if (peek() != '"') {
            throw std::invalid_argument("expected quoted field");
        }
        get(); // consume opening quote
        while (true) {
            char c = peek();
            if (c == '"') {
                get(); // consume quote
                if (peek() == '"') {
                    result += '"';
                    get(); // consume escaped quote
                } else {
                    break;
                }
            } else if (c == '\n' || c == '\0') {
                throw std::invalid_argument("unterminated quoted field");
            } else {
                result += c;
                get();
            }
        }
        return result;
    }

    std::string read_unquoted_field() {
        std::string result;
        while (true) {
            char c = peek();
            if (c == ',' || c == '\n' || c == '\0') {
                break;
            }
            if (c == '"') {
                throw std::invalid_argument("unquoted field contains quote");
            }
            result += c;
            get();
        }
        return result;
    }

    std::string read_field() {
        if (peek() == '"') {
            return read_quoted_field();
        } else {
            return read_unquoted_field();
        }
    }

    bool skip_whitespace() {
        bool skipped = false;
        while (is_whitespace(peek())) {
            get();
            skipped = true;
        }
        return skipped;
    }

    bool read_line(std::string& field1, std::string& field2) {
        skip_whitespace();
        if (peek() == '\n' || peek() == '\0') {
            return false;
        }
        field1 = read_field();
        skip_whitespace();
        if (peek() != ',') {
            throw std::invalid_argument("expected comma separator");
        }
        get(); // consume comma
        skip_whitespace();
        field2 = read_field();
        skip_whitespace();
        char c = peek();
        if (!is_line_end(c)) {
            throw std::invalid_argument("expected end of line");
        }
        if (c == '\n') get();
        return true;
    }

    bool is_header_line(const std::string& f1, const std::string& f2) {
        return f1 == "category" && f2 == "amount";
    }
};

}

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    CSVParser parser(in);
    std::string field1, field2;
    if (!parser.read_line(field1, field2)) {
        throw std::invalid_argument("empty input");
    }
    if (!parser.is_header_line(field1, field2)) {
        throw std::invalid_argument("invalid header");
    }
    std::map<std::string, std::int64_t> result;
    while (true) {
        if (!parser.read_line(field1, field2)) break;
        std::string cat = strip(field1);
        std::string amt = strip(field2);
        if (cat.empty()) {
            throw std::invalid_argument("empty category");
        }
        if (amt.empty()) {
            throw std::invalid_argument("empty amount");
        }
        std::int64_t value = parse_int64(amt, 0, amt.size());
        result[cat] += value;
    }
    return result;
}

#endif
