# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep Copy**: Copy constructor and assignment perform deep copies of buffer contents
- **Noexcept Move**: Move constructor and assignment are noexcept and leave the source in a valid, reusable state with size 0
- **Bounds Checking**: Both mutable and const `operator[]` throw `std::out_of_range` on invalid indices
- **Resize**: Preserves existing prefix and zero-initializes new elements when expanding
- **RAII**: Proper resource management with no memory leaks or double frees

## API

```cpp
class Buffer {
public:
    Buffer(std::size_t n = 0);                    // Construct with n zero-initialized bytes
    ~Buffer();                                    // Destructor

    Buffer(const Buffer& other);                  // Deep copy constructor
    Buffer& operator=(const Buffer& other);       // Deep copy assignment

    Buffer(Buffer&& other) noexcept;              // Move constructor (noexcept)
    Buffer& operator=(Buffer&& other) noexcept;   // Move assignment (noexcept)

    std::size_t size() const noexcept;            // Return buffer size

    std::uint8_t& operator[](std::size_t i);      // Mutable access with bounds check
    const std::uint8_t& operator[](std::size_t i) const;  // Const access with bounds check

    void resize(std::size_t k);                   // Resize, preserving prefix, zero-init new
};
```

## Usage Example

```cpp
Buffer a(5);
a[0] = 1;
a[1] = 2;

Buffer b = a;           // Deep copy
Buffer c = std::move(a); // Move, a.size() becomes 0

a.resize(10);           // Expand, new bytes are zero
```

## Building

Compile with C++20 support:
```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
```

## Testing

Run the test suite:
```bash
./test_buffer
```
