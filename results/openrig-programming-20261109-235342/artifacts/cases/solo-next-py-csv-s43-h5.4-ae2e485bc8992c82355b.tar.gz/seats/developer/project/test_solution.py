import unittest
import tempfile
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):

    def test_basic(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.50\nrent,200.25\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50", "rent": "200.25"})

    def test_aggregation(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.50\nfood,99.50\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "200.00"})

    def test_whitespace_stripping(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n  food  ,  100.50  \n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50"})

    def test_empty_category_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n,100.50\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_invalid_header_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("wrong,header\nfood,100.50\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_too_many_fields_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.50,extra\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_nan_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,NaN\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_empty_file_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_quoted_comma(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"a,b",100.50\n')
            result = aggregate(p)
            self.assertEqual(result, {"a,b": "100.50"})

    def test_embedded_newline(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"two\nlines",100.50\n')
            result = aggregate(p)
            self.assertEqual(result, {"two\nlines": "100.50"})

    def test_quoted_quote(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"x""quote",100.50\n')
            result = aggregate(p)
            self.assertEqual(result, {"x\"quote": "100.50"})

    def test_blank_rows_ignored(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n\nfood,100.50\n\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50"})

    def test_amount_with_plus(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,+100.50\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50"})

    def test_amount_no_decimal(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.00"})

    def test_amount_one_decimal(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.5\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50"})

    def test_amount_three_decimals_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.123\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_amount_leading_zero_int_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,0100.50\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_amount_exponent_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,1e5\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_negative_amount_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,-100.50\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_empty_amount_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_unbalanced_quote_raises(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"x,1\n')
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_sorted_keys(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nz,1\na,2\nm,3\n")
            result = aggregate(p)
            self.assertEqual(list(result.keys()), ["a", "m", "z"])


if __name__ == '__main__':
    unittest.main()
