import csv
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("Empty file")
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        totals = {}
        for row in reader:
            if row == []:
                continue
            if len(row) != 2:
                raise ValueError("Invalid row")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            if not category:
                raise ValueError("Empty category")
            
            if not amount_str:
                raise ValueError("Empty amount")
            
            if amount_str[0] == '+':
                amount_str = amount_str[1:]
            
            if not amount_str:
                raise ValueError("Empty amount after plus")
            
            if 'e' in amount_str.lower():
                raise ValueError("Exponent in amount")
            
            if '.' in amount_str:
                parts = amount_str.split('.')
                if len(parts) != 2:
                    raise ValueError("Invalid amount")
                int_part, dec_part = parts
                if not int_part and not dec_part:
                    raise ValueError("Invalid amount")
                if len(dec_part) > 2:
                    raise ValueError("Too many decimal places")
                if len(dec_part) < 1:
                    raise ValueError("Invalid amount")
                if len(int_part) > 1 and int_part[0] == '0':
                    raise ValueError("Leading zero in integer part")
            else:
                int_part = amount_str
            
            if not int_part:
                raise ValueError("Invalid amount")
            
            if len(int_part) > 12:
                raise ValueError("Too many digits")
            if len(int_part) > 1 and int_part[0] == '0':
                raise ValueError("Leading zero in integer part")
            
            try:
                value = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError("Invalid amount")
            
            if value.is_nan() or value.is_infinite():
                raise ValueError("Invalid amount")
            
            if value < 0:
                raise ValueError("Negative amount")
            
            if category in totals:
                totals[category] += value
            else:
                totals[category] = value
        
        if not totals:
            raise ValueError("No data rows")
        
        result = {}
        for cat in sorted(totals.keys()):
            result[cat] = format(totals[cat], '.2f')
        
        return result
