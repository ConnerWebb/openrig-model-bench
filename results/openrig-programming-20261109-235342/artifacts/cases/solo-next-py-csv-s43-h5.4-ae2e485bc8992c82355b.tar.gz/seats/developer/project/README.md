# CSV Aggregate Solution

This solution implements `aggregate(path: str) -> dict[str, str]` that reads a UTF-8 CSV file and aggregates amounts by category.

## Requirements

- Header must be exactly `category,amount`
- Ignores completely blank records
- Strips whitespace from category and amount
- Category must not be empty
- Amount format: optional `+`, 1-12 decimal digits, optional decimal point followed by 1-2 digits
- Nonnegative, finite, no exponent allowed
- Uses exact decimal arithmetic
- Returns category keys sorted, totals formatted with exactly two decimal places
- Handles CSV quoted commas and embedded newlines

## Usage

```python
from solution import aggregate

result = aggregate("path/to/file.csv")
print(result)
# {"category1": "123.45", "category2": "678.90"}
```

## Testing

Run tests with:
```bash
python3 -m unittest test_solution.py
```
