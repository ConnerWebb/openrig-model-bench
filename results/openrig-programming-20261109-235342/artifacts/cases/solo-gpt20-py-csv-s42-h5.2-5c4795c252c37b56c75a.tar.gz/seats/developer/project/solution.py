"""Solution for CSV aggregation.

The function :func:`aggregate` reads a UTF‑8 encoded CSV file that contains a
header ``category,amount`` and returns a mapping from category to the total
amount for that category.  The implementation follows the rules described in
``TASK.txt``.
"""

from __future__ import annotations

import csv
import decimal
from pathlib import Path
from typing import Dict

# Configure decimal to avoid floating point errors.
decimal.getcontext().prec = 28

# Regular expression for amount validation.
import re
_AMOUNT_RE = re.compile(r"^[+]?\d{1,12}(?:\.\d{1,2})?$")


def _validate_amount(text: str) -> decimal.Decimal:
    """Validate and convert *text* to :class:`decimal.Decimal`.

    The function accepts an optional leading ``+`` and up to 12 digits before
    an optional decimal point followed by 1 or 2 digits.  It raises
    :class:`ValueError` if the format is not respected.
    """
    if not _AMOUNT_RE.match(text):
        raise ValueError(f"Invalid amount format: {text!r}")
    return decimal.Decimal(text)


def aggregate(path: str | Path) -> Dict[str, str]:
    """Aggregate amounts per category from a CSV file.

    Parameters
    ----------
    path:
        Path to the CSV file.

    Returns
    -------
    dict[str, str]
        Mapping from category to the total amount formatted with two decimal
        places.  The keys are sorted alphabetically.

    Raises
    ------
    ValueError
        If the file is malformed according to the specification.
    """
    totals: Dict[str, decimal.Decimal] = {}

    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        if header != ["category", "amount"]:
            raise ValueError("Header must be exactly 'category,amount'")

        for lineno, row in enumerate(reader, start=2):
            # Skip completely blank rows (all fields empty or whitespace).
            if all(not field.strip() for field in row):
                continue
            if len(row) != 2:
                raise ValueError(f"Line {lineno}: expected 2 fields, got {len(row)}")
            cat_raw, amt_raw = row
            cat = cat_raw.strip()
            amt = amt_raw.strip()
            if not cat:
                raise ValueError(f"Line {lineno}: category cannot be empty")
            dec = _validate_amount(amt)
            totals[cat] = totals.get(cat, decimal.Decimal("0")) + dec

    # Format totals with exactly two decimal places.
    formatted: Dict[str, str] = {
        cat: f"{totals[cat]:.2f}" for cat in sorted(totals)
    }
    return formatted


if __name__ == "__main__":  # pragma: no cover
    import sys
    if len(sys.argv) != 2:
        sys.exit("Usage: python solution.py <csv-file>")
    print(aggregate(sys.argv[1]))
