# CSV Aggregator

This repository contains a small utility that aggregates monetary amounts by
category from a UTF‑8 encoded CSV file.

## Usage

```bash
python solution.py path/to/file.csv
```

The script prints a JSON‑like dictionary mapping each category to the total
amount formatted with two decimal places.

## API

```python
from solution import aggregate

result = aggregate("data.csv")
# result is a dict[str, str] with sorted keys
```

The function raises :class:`ValueError` if the input does not conform to the
specification.

## Tests

Run the test suite with:

```bash
python -m unittest discover -s tests
```

The tests cover normal operation and various error conditions.
