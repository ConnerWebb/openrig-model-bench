import unittest
import tempfile
import os
from pathlib import Path
from solution import aggregate

class TestAggregate(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "data.csv"

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, content: str):
        self.path.write_text(content, encoding="utf-8")

    def test_basic(self):
        self.write("category,amount\nfood,10.00\nfood,5.5\nbooks,3\n")
        expected = {"books": "3.00", "food": "15.50"}
        self.assertEqual(aggregate(self.path), expected)

    def test_whitespace_and_blank(self):
        self.write("category,amount\n  food  ,  1.00  \n\nbooks,2.5\n")
        expected = {"books": "2.50", "food": "1.00"}
        self.assertEqual(aggregate(self.path), expected)

    def test_invalid_header(self):
        self.write("cat,amt\nfoo,1.00\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_invalid_amount(self):
        self.write("category,amount\nfoo,abc\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_empty_category(self):
        self.write("category,amount\n ,1.00\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_decimal_precision(self):
        self.write("category,amount\nfoo,0.1\nfoo,0.2\n")
        self.assertEqual(aggregate(self.path), {"foo": "0.30"})

    def test_large_amount(self):
        self.write("category,amount\nfoo,123456789012.34\n")
        self.assertEqual(aggregate(self.path), {"foo": "123456789012.34"})

    def test_more_than_two_decimals(self):
        self.write("category,amount\nfoo,1.234\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_exponent_not_allowed(self):
        self.write("category,amount\nfoo,1e3\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_negative_not_allowed(self):
        self.write("category,amount\nfoo,-1.00\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

if __name__ == "__main__":  # pragma: no cover
    unittest.main()
