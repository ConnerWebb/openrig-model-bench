# CSV Aggregation Solution

## Overview

This module provides a `aggregate` function that reads a UTF-8 CSV file and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with totals formatted to 2 decimal places.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to formatted totals (2 decimal places)
        
    Raises:
        ValueError: If the CSV is malformed (invalid header, wrong field count,
                   invalid amount format, empty category, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank line must have exactly 2 fields
- **Category**: Whitespace-stripped, must not be empty
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits before optional decimal point
  - If decimal point present, 1-2 digits after it
  - Non-negative, finite, no exponent notation

## Features

- **Streaming**: Reads file line-by-line via csv.reader
- **Exact Arithmetic**: Uses Python's `decimal.Decimal` for precise accumulation
- **Proper CSV Parsing**: Handles quoted fields with embedded commas, newlines, and escaped quotes
- **Validation**: Strict validation of header, field counts, and amount format
- **Sorted Output**: Returns categories in sorted order

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```

## Examples

```python
# Basic usage
result = aggregate('data.csv')
# Returns: {'food': '123.45', 'rent': '999.99'}

# Handles quoted fields
# "a,b",100.00  -> category "a,b" with amount 100.00

# Handles embedded newlines
# "line1
# line2",50.00  -> category "line1\nline2" with amount 50.00
```
