import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.25\nfood,5.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.25'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_quoted_fields_with_embedded_newlines(self):
        """Test quoted fields containing newlines"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"line1\nline2",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'line1\nline2': '50.00'})
    
    def test_escaped_quotes(self):
        """Test escaped quotes in quoted fields"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_blank_lines_ignored(self):
        """Test that completely blank lines are ignored"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.00\n\nrent,20.00\n\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_integer_amounts(self):
        """Test integer amounts without decimal point"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,100\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '100.00'})
    
    def test_invalid_header_wrong_columns(self):
        """Test invalid header with wrong column names"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,amount\nx,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_extra_columns(self):
        """Test invalid header with extra columns"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount,extra\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_wrong_field_count(self):
        """Test record with wrong number of fields"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test empty category after stripping"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test invalid amount NaN"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_exponent(self):
        """Test invalid amount with exponent"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1e5\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_negative(self):
        """Test invalid negative amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,-10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_too_many_digits(self):
        """Test amount with too many digits before decimal"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1234567890123\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_too_many_decimal_places(self):
        """Test amount with too many decimal places"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.123\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote(self):
        """Test unclosed quote in CSV"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_sorted_output(self):
        """Test that output is sorted by category key"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nzebra,10.00\napple,20.00\nmango,30.00\n', encoding='utf-8')
            result = aggregate(str(p))
            keys = list(result.keys())
            self.assertEqual(keys, ['apple', 'mango', 'zebra'])
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"日本",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00'})


if __name__ == '__main__':
    unittest.main()
