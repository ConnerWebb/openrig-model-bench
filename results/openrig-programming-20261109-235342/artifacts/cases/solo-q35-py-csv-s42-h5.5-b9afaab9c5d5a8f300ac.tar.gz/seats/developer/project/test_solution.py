"""Tests for solution.aggregate."""
import tempfile
import unittest
from pathlib import Path
from solution import aggregate


class TestAggregate(unittest.TestCase):
    def _write_and_call(self, csv_content: str) -> dict:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            path = f.name
        try:
            return aggregate(path)
        finally:
            Path(path).unlink()

    def test_basic_aggregation(self):
        csv = "category,amount\nfood,10.00\nfood,20.00\nrent,30.00\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"food": "30.00", "rent": "30.00"})

    def test_quoted_fields(self):
        csv = 'category,amount\n"x""quote",10.00\n"x""quote",20.00\n'
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x\"quote": "30.00"})

    def test_comma_in_quoted_field(self):
        csv = 'category,amount\n"a,b",10.00\n"a,b",20.00\n'
        result = self._write_and_call(csv)
        self.assertEqual(result, {"a,b": "30.00"})

    def test_newline_in_quoted_field(self):
        csv = 'category,amount\n"two\nlines",10.00\n"two\nlines",20.00\n'
        result = self._write_and_call(csv)
        self.assertEqual(result, {"two\nlines": "30.00"})

    def test_japanese_category(self):
        csv = "category,amount\n日本,10.00\n日本,20.00\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"日本": "30.00"})

    def test_header_must_be_exact(self):
        csv = "wrong,amount\nx,1\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_wrong_number_of_fields(self):
        csv = "category,amount\nx,1,2\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_empty_category(self):
        csv = "category,amount\n,1\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_invalid_amount_nan(self):
        csv = "category,amount\nx,NaN\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_malformed_quoted_field(self):
        csv = 'category,amount\n"x,1\n'
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_amount_with_leading_plus(self):
        csv = "category,amount\nx,+10.00\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "10.00"})

    def test_amount_with_decimal(self):
        csv = "category,amount\nx,10.5\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "10.50"})

    def test_amount_with_two_decimal_places(self):
        csv = "category,amount\nx,10.55\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "10.55"})

    def test_amount_with_one_decimal_place(self):
        csv = "category,amount\nx,10.5\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "10.50"})

    def test_amount_with_zero_decimal_places(self):
        csv = "category,amount\nx,10\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "10.00"})

    def test_blank_lines_ignored(self):
        csv = "category,amount\n\nfood,10.00\n\nrent,20.00\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"food": "10.00", "rent": "20.00"})

    def test_whitespace_stripped(self):
        csv = "category,amount\n  food  ,  10.00  \n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"food": "10.00"})

    def test_amount_too_many_digits(self):
        csv = "category,amount\nx,1234567890123\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_amount_too_many_decimal_places(self):
        csv = "category,amount\nx,10.123\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_negative_amount(self):
        csv = "category,amount\nx,-10.00\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_empty_amount(self):
        csv = "category,amount\nx,\n"
        with self.assertRaises(ValueError):
            self._write_and_call(csv)

    def test_only_fractional_part(self):
        csv = "category,amount\nx,.5\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "0.50"})

    def test_only_fractional_part_with_two_digits(self):
        csv = "category,amount\nx,.55\n"
        result = self._write_and_call(csv)
        self.assertEqual(result, {"x": "0.55"})


if __name__ == '__main__':
    unittest.main()
