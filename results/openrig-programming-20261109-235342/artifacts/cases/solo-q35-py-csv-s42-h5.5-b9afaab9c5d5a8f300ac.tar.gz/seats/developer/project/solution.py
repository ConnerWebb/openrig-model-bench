"""CSV category aggregation with exact decimal arithmetic."""
import csv
from decimal import Decimal, InvalidOperation
from typing import Dict


def aggregate(path: str) -> Dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount: optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits.
    Nonnegative, finite, no exponent. Reject malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted,
    totals formatted with exactly two decimal places.
    """
    totals: Dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None or [h.strip() for h in header] != ['category', 'amount']:
            raise ValueError("Header must be exactly 'category,amount'")

        for row in reader:
            # Skip completely blank records (csv.reader may return empty list for blank lines)
            if not row:
                continue

            if len(row) != 2:
                raise ValueError(f"Expected exactly two fields, got {len(row)}")

            category = row[0].strip()
            amount_str = row[1].strip()

            if not category:
                raise ValueError("Category must not be empty")

            # Validate amount format: optional +, 1–12 digits, optional . followed by 1–2 digits
            if not _is_valid_amount(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")

            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount value: {amount_str}")

            if amount < 0:
                raise ValueError(f"Amount must be nonnegative: {amount}")

            totals[category] = totals.get(category, Decimal('0')) + amount

    # Format with exactly two decimal places
    return {k: str(v.quantize(Decimal('0.01'))) for k, v in sorted(totals.items())}


def _is_valid_amount(s: str) -> bool:
    """
    Validate amount format:
    - Optional leading '+'
    - 1 to 12 decimal digits
    - Optional decimal point followed by 1 or 2 digits
    - No exponent, no NaN, no inf
    - Can have only fractional part (e.g., .5, .55)
    """
    if not s:
        return False

    # Strip optional leading '+'
    if s.startswith('+'):
        s = s[1:]

    if not s:
        return False

    # Split into integer and fractional parts
    if '.' in s:
        parts = s.split('.')
        if len(parts) != 2:
            return False
        int_part, frac_part = parts
        if not int_part and not frac_part:
            return False
        if len(frac_part) > 2:
            return False
        if not frac_part.isdigit():
            return False
        if not int_part:
            # Only fractional part, must have at least 1 digit
            return len(frac_part) >= 1 and len(frac_part) <= 2
        if not int_part.isdigit():
            return False
        if len(int_part) > 12:
            return False
    else:
        if not s.isdigit():
            return False
        if len(s) > 12:
            return False

    return True
