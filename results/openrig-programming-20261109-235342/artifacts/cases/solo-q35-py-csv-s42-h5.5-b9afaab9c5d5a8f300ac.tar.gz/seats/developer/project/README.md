# CSV Category Aggregation

This module provides a function to aggregate CSV data by category using exact decimal arithmetic.

## Function

```python
def aggregate(path: str) -> dict[str, str]
```

Reads a UTF-8 CSV file and aggregates amounts by category.

### Requirements

- Header must be exactly `category,amount`
- Completely blank records are ignored
- Every non-blank record must have exactly two fields
- Category and amount fields are stripped of whitespace
- Category must not be empty after stripping
- Amount format:
  - Optional leading `+`
  - 1 to 12 decimal digits
  - Optional decimal point followed by 1 or 2 digits
  - Nonnegative, finite, no exponent
  - No NaN or inf values
- Malformed input raises `ValueError`

### Return Value

Returns a dictionary with:
- Keys: category names (sorted alphabetically)
- Values: totals formatted with exactly two decimal places

### Example

```python
result = aggregate("data.csv")
# Returns: {"food": "100.00", "rent": "200.00"}
```

## Usage

```python
from solution import aggregate

result = aggregate("input.csv")
print(result)
```

## Testing

Run tests with:

```bash
python3 -m unittest test_solution.py
```

## Dependencies

- Python 3.14 stdlib
- Uses `decimal.Decimal` for exact arithmetic
- Uses `csv` module for proper CSV parsing (handles quoted fields, embedded commas, newlines)
