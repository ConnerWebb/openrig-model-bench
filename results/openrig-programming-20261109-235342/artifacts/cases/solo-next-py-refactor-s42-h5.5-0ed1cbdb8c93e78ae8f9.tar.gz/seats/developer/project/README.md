# Ledger Processing Module

This module provides functionality to process ledger records with validation, deduplication, and aggregation.

## Files

- `ledger.py` - Public facade module
- `engine.py` - Implementation module
- `test_ledger.py` - Unit tests

## API

### `ledger.process(records, minimum_cents=0)`

Process a list of records and return normalized events and totals.

**Parameters:**
- `records`: List of dictionaries with keys `id`, `category`, `cents`
- `minimum_cents`: Optional minimum cents filter (default: 0)

**Returns:**
- Dictionary with:
  - `events`: List of normalized records (in input order, first occurrence wins)
  - `totals`: Dictionary mapping category to sum of cents (keys sorted)

**Validation Rules:**
- `id`: must be a nonempty stripped string
- `category`: must be a nonempty stripped string
- `cents`: must be a nonnegative integer (booleans are invalid)
- Records must have exactly the three required keys
- First occurrence of an `id` wins (duplicates are skipped)
- `minimum_cents`: must be a nonnegative integer (booleans are invalid)

**Raises:**
- `ValueError` if any record or parameter is invalid

**Behavior:**
- Input records are never mutated
- Returns fresh data structures on each call (no shared mutable state)
- `process([])` returns `{"events": [], "totals": {}}`

## Usage Example

```python
import ledger

records = [
    {"id": " 1 ", "category": " food ", "cents": 100},
    {"id": "2", "category": "transport", "cents": 50},
    {"id": "1", "category": "food", "cents": 200}  # duplicate id, skipped
]

result = ledger.process(records)
# result = {
#     "events": [
#         {"id": "1", "category": "food", "cents": 100},
#         {"id": "2", "category": "transport", "cents": 50}
#     ],
#     "totals": {"food": 100, "transport": 50}
# }
```

## Running Tests

```bash
python3 -m unittest test_ledger.py
```
