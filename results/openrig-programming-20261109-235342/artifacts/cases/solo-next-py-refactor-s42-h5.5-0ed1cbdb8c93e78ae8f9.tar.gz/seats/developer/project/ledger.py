"""Public facade module for ledger processing."""
from typing import Any, Dict, List
from engine import process as _process


def process(records: List[Dict[str, Any]], minimum_cents: int = 0) -> Dict[str, Any]:
    """Process records and return normalized events and totals.
    
    Args:
        records: List of record dictionaries with keys 'id', 'category', 'cents'.
        minimum_cents: Optional minimum cents filter (default 0).
    
    Returns:
        Dictionary with 'events' (list of normalized records) and 'totals' (dict of category sums).
    
    Raises:
        ValueError: If any record is invalid or minimum_cents is invalid.
    """
    return _process(records, minimum_cents)
