"""Unit tests for ledger module."""
import unittest
import copy
import ledger


class TestLedgerProcess(unittest.TestCase):
    """Tests for the process function."""

    def test_empty_input(self):
        """Test empty input returns empty events and totals."""
        result = ledger.process([])
        self.assertEqual(result, {"events": [], "totals": {}})

    def test_single_valid_record(self):
        """Test single valid record."""
        records = [{"id": "x", "category": "a", "cents": 100}]
        result = ledger.process(records)
        self.assertEqual(result["events"], [{"id": "x", "category": "a", "cents": 100}])
        self.assertEqual(result["totals"], {"a": 100})

    def test_whitespace_stripping(self):
        """Test id and category whitespace is stripped."""
        records = [{"id": " x ", "category": " a ", "cents": 100}]
        result = ledger.process(records)
        self.assertEqual(result["events"][0]["id"], "x")
        self.assertEqual(result["events"][0]["category"], "a")

    def test_duplicate_id_first_wins(self):
        """Test first occurrence of id wins."""
        records = [
            {"id": "x", "category": "a", "cents": 100},
            {"id": "x", "category": "b", "cents": 200}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(result["events"][0]["category"], "a")
        self.assertEqual(result["events"][0]["cents"], 100)

    def test_totals_calculation(self):
        """Test totals are calculated correctly."""
        records = [
            {"id": "x", "category": "a", "cents": 100},
            {"id": "y", "category": "a", "cents": 50},
            {"id": "z", "category": "b", "cents": 200}
        ]
        result = ledger.process(records)
        self.assertEqual(result["totals"], {"a": 150, "b": 200})

    def test_totals_keys_sorted(self):
        """Test totals keys are sorted."""
        records = [
            {"id": "x", "category": "c", "cents": 100},
            {"id": "y", "category": "a", "cents": 50},
            {"id": "z", "category": "b", "cents": 200}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result["totals"].keys()), ["a", "b", "c"])

    def test_minimum_cents_filter(self):
        """Test minimum_cents filter works."""
        records = [
            {"id": "x", "category": "a", "cents": 100},
            {"id": "y", "category": "a", "cents": 50}
        ]
        result = ledger.process(records, minimum_cents=75)
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(result["events"][0]["cents"], 100)

    def test_minimum_cents_zero(self):
        """Test minimum_cents=0 includes all valid records."""
        records = [
            {"id": "x", "category": "a", "cents": 0},
            {"id": "y", "category": "a", "cents": 1}
        ]
        result = ledger.process(records, minimum_cents=0)
        self.assertEqual(len(result["events"]), 2)

    def test_input_not_mutated(self):
        """Test input records are not mutated."""
        records = [{"id": "x", "category": " a ", "cents": 100}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_boolean_cents_invalid(self):
        """Test boolean cents values are invalid."""
        records = [{"id": "x", "category": "a", "cents": True}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_negative_cents_invalid(self):
        """Test negative cents values are invalid."""
        records = [{"id": "x", "category": "a", "cents": -1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_empty_id_invalid(self):
        """Test empty id is invalid."""
        records = [{"id": "", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_whitespace_only_id_invalid(self):
        """Test whitespace-only id is invalid."""
        records = [{"id": "   ", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_empty_category_invalid(self):
        """Test empty category is invalid."""
        records = [{"id": "x", "category": "", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_extra_keys_invalid(self):
        """Test extra keys in record are invalid."""
        records = [{"id": "x", "category": "a", "cents": 1, "extra": 2}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_missing_keys_invalid(self):
        """Test missing keys in record are invalid."""
        records = [{"id": "x", "category": "a"}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_non_dict_record_invalid(self):
        """Test non-dict record is invalid."""
        records = ["not a dict"]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_non_int_cents_invalid(self):
        """Test non-int cents is invalid."""
        records = [{"id": "x", "category": "a", "cents": "100"}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_float_cents_invalid(self):
        """Test float cents is invalid."""
        records = [{"id": "x", "category": "a", "cents": 100.5}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_minimum_cents_boolean_invalid(self):
        """Test boolean minimum_cents is invalid."""
        records = [{"id": "x", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)

    def test_minimum_cents_negative_invalid(self):
        """Test negative minimum_cents is invalid."""
        records = [{"id": "x", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)

    def test_multiple_minimum_cents_filter(self):
        """Test minimum_cents filter with multiple records."""
        records = [
            {"id": "x", "category": "a", "cents": 10},
            {"id": "y", "category": "a", "cents": 20},
            {"id": "z", "category": "a", "cents": 30}
        ]
        result = ledger.process(records, minimum_cents=15)
        self.assertEqual(len(result["events"]), 2)
        self.assertEqual(result["totals"], {"a": 50})

    def test_first_wins_after_filter(self):
        """Test first occurrence wins even with minimum_cents filter."""
        records = [
            {"id": "x", "category": "a", "cents": 10},
            {"id": "x", "category": "b", "cents": 100}
        ]
        result = ledger.process(records, minimum_cents=5)
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(result["events"][0]["category"], "a")


if __name__ == "__main__":
    unittest.main()
