"""Implementation module for ledger processing."""
from typing import Any, Dict, List, Tuple


def _is_valid_id(value: Any) -> bool:
    """Check if value is a nonempty stripped string."""
    return isinstance(value, str) and value.strip() != ""


def _is_valid_category(value: Any) -> bool:
    """Check if value is a nonempty stripped string."""
    return isinstance(value, str) and value.strip() != ""


def _is_valid_cents(value: Any) -> bool:
    """Check if value is a nonnegative integer (excluding booleans)."""
    if isinstance(value, bool):
        return False
    if not isinstance(value, int):
        return False
    return value >= 0


def _is_valid_record(record: Any) -> bool:
    """Check if record has exactly the required keys with valid values."""
    if not isinstance(record, dict):
        return False
    required_keys = {"id", "category", "cents"}
    if set(record.keys()) != required_keys:
        return False
    if not _is_valid_id(record["id"]):
        return False
    if not _is_valid_category(record["category"]):
        return False
    if not _is_valid_cents(record["cents"]):
        return False
    return True


def _validate_record(record: Dict[str, Any]) -> None:
    """Validate a single record, raise ValueError if invalid."""
    if not isinstance(record, dict):
        raise ValueError("Record must be a dictionary")
    required_keys = {"id", "category", "cents"}
    if set(record.keys()) != required_keys:
        raise ValueError("Record must have exactly id, category, and cents keys")
    if not _is_valid_id(record["id"]):
        raise ValueError("id must be a nonempty stripped string")
    if not _is_valid_category(record["category"]):
        raise ValueError("category must be a nonempty stripped string")
    if not _is_valid_cents(record["cents"]):
        raise ValueError("cents must be a nonnegative integer")


def _validate_minimum_cents(minimum_cents: Any) -> None:
    """Validate minimum_cents parameter."""
    if isinstance(minimum_cents, bool):
        raise ValueError("minimum_cents must be a nonnegative integer")
    if not isinstance(minimum_cents, int):
        raise ValueError("minimum_cents must be a nonnegative integer")
    if minimum_cents < 0:
        raise ValueError("minimum_cents must be a nonnegative integer")


def process(records: List[Dict[str, Any]], minimum_cents: int = 0) -> Dict[str, Any]:
    """Process records and return normalized events and totals."""
    _validate_minimum_cents(minimum_cents)
    
    seen_ids = set()
    events: List[Dict[str, Any]] = []
    totals: Dict[str, int] = {}
    
    for record in records:
        _validate_record(record)
        
        normalized_id = record["id"].strip()
        normalized_category = record["category"].strip()
        normalized_cents = record["cents"]
        
        if normalized_id in seen_ids:
            continue
        
        seen_ids.add(normalized_id)
        
        if normalized_cents < minimum_cents:
            continue
        
        normalized_record = {
            "id": normalized_id,
            "category": normalized_category,
            "cents": normalized_cents
        }
        events.append(normalized_record)
        
        if normalized_category not in totals:
            totals[normalized_category] = 0
        totals[normalized_category] += normalized_cents
    
    sorted_totals = dict(sorted(totals.items()))
    
    return {
        "events": events,
        "totals": sorted_totals
    }
