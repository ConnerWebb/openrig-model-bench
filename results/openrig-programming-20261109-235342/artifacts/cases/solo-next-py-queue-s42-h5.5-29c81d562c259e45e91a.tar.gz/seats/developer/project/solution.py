import sqlite3
import json
import threading
from typing import Optional, Dict, Any


class JobQueue:
    _lock = threading.Lock()

    def __init__(self, path: str, max_attempts: int = 3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self._path = path
        self._max_attempts = max_attempts
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(self._path, isolation_level=None)
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        with JobQueue._lock:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL,
                    attempts INTEGER NOT NULL,
                    owner TEXT,
                    lease_until REAL
                )
            """)

    def enqueue(self, key: str, payload: Any) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        payload_json = json.dumps(payload)
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT state FROM jobs WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row is not None:
                if row[0] == "queued":
                    return False
                else:
                    return False
            conn.execute(
                "INSERT INTO jobs (key, payload, state, attempts) VALUES (?, ?, 'queued', 0)",
                (key, payload_json)
            )
            return True

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not worker:
            raise ValueError("worker must be nonempty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        lease_until = now + lease
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute(
                """
                SELECT key, payload, attempts FROM jobs
                WHERE state = 'queued' AND attempts < ? AND (lease_until IS NULL OR lease_until <= ?)
                ORDER BY key LIMIT 1
                """,
                (self._max_attempts, now)
            )
            row = cursor.fetchone()
            if row is None:
                return None
            key, payload_json, attempts = row
            payload = json.loads(payload_json)
            conn.execute(
                """
                UPDATE jobs
                SET state = 'leased', owner = ?, lease_until = ?, attempts = attempts + 1
                WHERE key = ?
                """,
                (worker, lease_until, key)
            )
            return {"key": key, "payload": payload, "attempts": attempts + 1}

    def complete(self, key: str, worker: str) -> bool:
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT owner FROM jobs WHERE key = ? AND state = 'leased'", (key,))
            row = cursor.fetchone()
            if row is None or row[0] != worker:
                return False
            conn.execute("UPDATE jobs SET state = 'done' WHERE key = ?", (key,))
            return True

    def fail(self, key: str, worker: str) -> bool:
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT owner, attempts FROM jobs WHERE key = ? AND state = 'leased'", (key,))
            row = cursor.fetchone()
            if row is None or row[0] != worker:
                return False
            attempts = row[1]
            if attempts >= self._max_attempts:
                conn.execute("UPDATE jobs SET state = 'failed' WHERE key = ?", (key,))
            else:
                conn.execute(
                    "UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?",
                    (key,)
                )
            return True

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not key:
            raise ValueError("key must be nonempty")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT state, attempts FROM jobs WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row is None:
                return None
            return {"state": row[0], "attempts": row[1]}
