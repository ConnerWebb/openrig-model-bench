import unittest
import tempfile
import pathlib
import json
import threading
import time
import subprocess
import sys

from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    def test_enqueue_and_claim(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            self.assertTrue(q.enqueue("a", {"v": 1}))
            self.assertFalse(q.enqueue("a", {"v": 2}))
            claim = q.claim("w", 0, 10)
            self.assertIsNotNone(claim)
            self.assertEqual(claim["key"], "a")
            self.assertEqual(claim["payload"], {"v": 1})
            self.assertEqual(claim["attempts"], 1)

    def test_complete(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            q.enqueue("a", {"v": 1})
            q.claim("w", 0, 10)
            self.assertTrue(q.complete("a", "w"))
            status = q.status("a")
            self.assertEqual(status["state"], "done")

    def test_fail(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            q.enqueue("a", {"v": 1})
            q.claim("w", 0, 10)
            self.assertTrue(q.fail("a", "w"))
            status = q.status("a")
            self.assertEqual(status["state"], "queued")

    def test_status(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            self.assertIsNone(q.status("nonexistent"))
            q.enqueue("a", {"v": 1})
            status = q.status("a")
            self.assertEqual(status["state"], "queued")
            self.assertEqual(status["attempts"], 0)

    def test_invalid_args(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            with self.assertRaises(ValueError):
                q.enqueue("", {"v": 1})
            with self.assertRaises(ValueError):
                q.claim("", 0, 10)
            with self.assertRaises(ValueError):
                q.claim("w", 0, 0)
            with self.assertRaises(ValueError):
                JobQueue(str(pathlib.Path(tmpdir) / "q.db"), max_attempts=0)

    def test_claim_expires(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            q.enqueue("a", {"v": 1})
            q.claim("w", 0, 5)
            claim = q.claim("w2", 10, 5)
            self.assertIsNotNone(claim)
            self.assertEqual(claim["key"], "a")

    def test_max_attempts(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"), max_attempts=1)
            q.enqueue("a", {"v": 1})
            q.claim("w", 0, 10)
            q.fail("a", "w")
            status = q.status("a")
            self.assertEqual(status["state"], "failed")

    def test_wrong_owner(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            q.enqueue("a", {"v": 1})
            q.claim("w", 0, 10)
            self.assertFalse(q.complete("a", "wrong"))
            self.assertFalse(q.fail("a", "wrong"))

    def test_public_case_00(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            ops = [
                ("enqueue", "a", {"v": 5304}),
                ("enqueue", "a", "ignored"),
                ("claim", "w", 0, 5),
                ("complete", "a", "wrong"),
                ("fail", "a", "w"),
                ("claim", "w2", 1, 5),
                ("complete", "a", "w2"),
                ("status", "a"),
                ("claim", "w3", 100, 5),
            ]
            expected = [True, False, {"key": "a", "payload": {"v": 5304}, "attempts": 1}, False, True,
                        {"key": "a", "payload": {"v": 5304}, "attempts": 2}, True,
                        {"state": "done", "attempts": 2}, None]
            results = []
            for op in ops:
                method = getattr(q, op[0])
                result = method(*op[1:])
                results.append(result)
            self.assertEqual(results, expected)

    def test_public_case_04_max_attempts_1(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"), max_attempts=1)
            ops = [
                ("enqueue", "x", 0),
                ("claim", "w", 0, 2),
                ("claim", "other", 2, 2),
                ("status", "x"),
            ]
            results = []
            for op in ops:
                method = getattr(q, op[0])
                result = method(*op[1:])
                results.append(result)
            expected = [True, {"key": "x", "payload": 0, "attempts": 1}, None, {"state": "leased", "attempts": 1}]
            self.assertEqual(results, expected)

    def test_concurrent(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = str(pathlib.Path(tmpdir) / "q.db")
            q = JobQueue(db_path)
            for i in range(12):
                q.enqueue(str(i), i)
            results = []
            for i in range(20):
                worker = f"worker{i}"
                claim = q.claim(worker, 100.0, 10.0)
                if claim:
                    results.append(claim["key"])
            self.assertEqual(len(results), 12)
            self.assertEqual(sorted(results), [str(i) for i in range(12)])

    def test_claim_empty_queue(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            self.assertIsNone(q.claim("w", 0, 10))

    def test_claim_invalid_lease(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            with self.assertRaises(ValueError):
                q.claim("w", 0, 0)

    def test_claim_invalid_worker(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            with self.assertRaises(ValueError):
                q.claim("", 0, 10)

    def test_complete_invalid_args(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            with self.assertRaises(ValueError):
                q.complete("", "w")
            with self.assertRaises(ValueError):
                q.complete("a", "")

    def test_fail_invalid_args(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            with self.assertRaises(ValueError):
                q.fail("", "w")
            with self.assertRaises(ValueError):
                q.fail("a", "")

    def test_status_invalid_args(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            q = JobQueue(str(pathlib.Path(tmpdir) / "q.db"))
            with self.assertRaises(ValueError):
                q.status("")


if __name__ == "__main__":
    unittest.main()
