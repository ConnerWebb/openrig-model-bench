# JobQueue

SQLite-based job queue implementation.

## API

- `JobQueue(path, max_attempts=3)` - Initialize queue with SQLite database path.
- `enqueue(key, payload) -> bool` - Add job; first unique key wins.
- `claim(worker, now, lease) -> dict or None` - Atomically claim oldest eligible job.
- `complete(key, worker) -> bool` - Mark job done (owner must match).
- `fail(key, worker) -> bool` - Requeue or mark failed (owner must match).
- `status(key) -> dict or None` - Return `{state, attempts}` or None.

## States

- `queued` - Ready to claim.
- `leased` - Currently claimed.
- `done` - Completed successfully.
- `failed` - Exhausted max_attempts.

## Validation

- Nonempty `key` and `worker`.
- Positive `lease` and `max_attempts`.
- Raises `ValueError` for invalid arguments.

## Thread Safety

Uses SQLite WAL and a global lock for atomic operations.
