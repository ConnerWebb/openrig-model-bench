import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import solution
 with tempfile.TemporaryDirectory() as d:
  q=solution.JobQueue(str(pathlib.Path(d)/'q.db'),x.get('max_attempts',3));out=[]
  for op in x.get('ops',[]):out.append(getattr(q,op[0])(*op[1:]))
  if 'concurrent' in x:
   import multiprocessing
   n=x['concurrent'];[q.enqueue(str(i),i) for i in range(n)]
   def f(i):
    other=solution.JobQueue(str(pathlib.Path(d)/'q.db'),x.get('max_attempts',3));return other.claim('worker'+str(i),100.,10.)
   with multiprocessing.get_context('fork').Pool(processes=8) as pool:claims=list(pool.map(f,range(n+8)))
   out.append(sorted([r['key'] for r in claims if r is not None],key=int))
  print(json.dumps({'value':out}))

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
