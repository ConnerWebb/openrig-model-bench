# CSV Aggregator

This module provides a function to aggregate CSV data by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary with sorted category keys and totals formatted to 2 decimal places
        
    Raises:
        ValueError: If the CSV is malformed (invalid header, wrong field count,
                   empty category, invalid amount format, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank record must have exactly two fields
- **Category**: Whitespace-stripped, must not be empty
- **Amount**: 
  - Optional `+` prefix
  - 1-12 decimal digits
  - Optional decimal point followed by 1-2 digits
  - Nonnegative and finite (no exponent notation)
- **Quoting**: Standard CSV quoting rules apply (quoted commas, embedded newlines, escaped quotes)

## Example

```python
from solution import aggregate

result = aggregate('data.csv')
# Returns: {'food': '1234.56', 'rent': '500.00', ...}
```

## Testing

Run the test suite:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
