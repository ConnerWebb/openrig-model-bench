import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.25\nfood,5.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.25'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_embedded_newlines(self):
        """Test fields with embedded newlines"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"two\nlines",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '50.00'})
    
    def test_quoted_quotes(self):
        """Test quoted fields with escaped quotes"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.00\n\nrent,20.00\n\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})
    
    def test_invalid_header(self):
        """Test that invalid header raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,header\nx,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test that empty category raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_format(self):
        """Test that invalid amount format raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_wrong_field_count(self):
        """Test that wrong field count raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_with_plus(self):
        """Test amount with optional + prefix"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.50'})
    
    def test_amount_decimal_places(self):
        """Test various decimal place formats"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10\ny,10.5\nz,10.55\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.00', 'y': '10.50', 'z': '10.55'})
    
    def test_sorted_keys(self):
        """Test that result keys are sorted"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nz,1\na,2\nm,3\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['a', 'm', 'z'])
    
    def test_empty_file(self):
        """Test empty file raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_only_header(self):
        """Test file with only header returns empty dict"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
