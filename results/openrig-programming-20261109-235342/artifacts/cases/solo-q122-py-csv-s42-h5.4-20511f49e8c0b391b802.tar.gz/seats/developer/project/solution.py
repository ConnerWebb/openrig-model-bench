import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted category keys with totals formatted to exactly 2 decimal places.
    """
    # Regex for valid amount: optional +, 1-12 digits, optional decimal with 1-2 digits
    amount_pattern = re.compile(r'^\+?\d{1,12}(\.\d{1,2})?$')
    
    totals = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly category,amount")
        
        for row in reader:
            # Skip completely blank records (empty row or all fields empty/whitespace)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Every other record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse and accumulate using exact decimal arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check for nonnegative, finite
            if amount < 0 or not amount.is_finite():
                raise ValueError(f"Amount must be nonnegative and finite: {amount}")
            
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format totals with exactly 2 decimal places, sorted by key
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
