#include <iostream>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

void test_constructor_default() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_constructor_default passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_constructor_with_values() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    std::cout << "test_constructor_with_values passed\n";
}

void test_size() {
    Buffer b(42);
    assert(b.size() == 42);
    std::cout << "test_size passed\n";
}

void test_operator_index() {
    Buffer b(5);
    b[0] = 10;
    b[1] = 20;
    b[2] = 30;
    b[3] = 40;
    b[4] = 50;
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    assert(b[3] == 40);
    assert(b[4] == 50);
    std::cout << "test_operator_index passed\n";
}

void test_bounds_checking() {
    Buffer b(5);
    bool caught = false;
    try {
        (void)b[5];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    std::cout << "test_bounds_checking passed\n";
}

void test_resize_smaller() {
    Buffer b(10);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    std::cout << "test_resize_smaller passed\n";
}

void test_resize_larger() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
    std::cout << "test_resize_larger passed\n";
}

void test_resize_zero() {
    Buffer b(5);
    b[0] = 1;
    b.resize(0);
    assert(b.size() == 0);
    std::cout << "test_resize_zero passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    a[0] = 99;
    assert(b[0] == 1);  // b should be independent
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    Buffer b;
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    a[0] = 99;
    assert(b[0] == 1);  // b should be independent
    std::cout << "test_copy_assignment passed\n";
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    assert(a.size() == 0);  // a should be empty
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    Buffer b;
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    assert(a.size() == 0);  // a should be empty
    std::cout << "test_move_assignment passed\n";
}

void test_moved_from_reusable() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    // Now use a again
    a.resize(3);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    assert(a.size() == 3);
    assert(a[0] == 10);
    assert(a[1] == 20);
    assert(a[2] == 30);
    std::cout << "test_moved_from_reusable passed\n";
}

void test_self_copy_preserves() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    b = b;
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    std::cout << "test_self_copy_preserves passed\n";
}

void test_self_move_preserves() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    b = std::move(b);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    std::cout << "test_self_move_preserves passed\n";
}

void test_noexcept_properties() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
    std::cout << "test_noexcept_properties passed\n";
}

void test_const_operator() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    const Buffer& cb = b;
    assert(cb[0] == 1);
    assert(cb[1] == 2);
    assert(cb[2] == 3);
    assert(cb[3] == 4);
    assert(cb[4] == 5);
    std::cout << "test_const_operator passed\n";
}

int main() {
    std::cout << "Running Buffer tests...\n";
    test_constructor_default();
    test_constructor_with_size();
    test_constructor_with_values();
    test_size();
    test_operator_index();
    test_bounds_checking();
    test_resize_smaller();
    test_resize_larger();
    test_resize_zero();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_moved_from_reusable();
    test_self_copy_preserves();
    test_self_move_preserves();
    test_noexcept_properties();
    test_const_operator();
    std::cout << "All tests passed!\n";
    return 0;
}