# Buffer Library

A C++20 RAII buffer class with deep copy semantics, bounds-checked element access, and move semantics.

## Features

- **Constructor**: `Buffer(size_t n = 0)` - Creates a buffer of specified size (default 0)
- **Size**: `size() const noexcept` - Returns the current buffer size
- **Element Access**: `operator[](size_t)` with bounds checking - Throws `std::out_of_range` on invalid access
- **Resize**: `resize(size_t)` - Preserves existing prefix and zero-initializes new bytes
- **Copy Semantics**: Deep copy construction and assignment
- **Move Semantics**: Noexcept move construction and assignment
- **Moved-from State**: Buffers become size 0 and are reusable
- **Self-copy/Self-move**: Content is preserved

## Requirements

- C++20
- Clang 22
- `-fuse-ld=bfd`

## Usage Example

```cpp
#include "solution.hpp"

int main() {
    // Create a buffer of size 10
    Buffer b(10);

    // Set some values
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;

    // Resize to 5 (preserves first 3 elements)
    b.resize(5);

    // Resize to 15 (preserves first 5, zeros rest)
    b.resize(15);

    // Copy
    Buffer c = b;

    // Move
    Buffer d = std::move(c);

    // Access size
    std::size_t sz = b.size();

    return 0;
}
```

## Testing

Run the test suite:

```bash
clang++ -std=c++20 -fuse-ld=bfd test_buffer.cpp -o test_buffer
./test_buffer
```

Or use the provided test runner:

```bash
run_tests
```

## Implementation Details

- Uses RAII for automatic memory management
- Deep copy ensures independent copies
- Bounds checking prevents out-of-range access
- Move semantics enable efficient resource transfer
- Noexcept guarantees for move operations
- Self-copy and self-move are handled correctly