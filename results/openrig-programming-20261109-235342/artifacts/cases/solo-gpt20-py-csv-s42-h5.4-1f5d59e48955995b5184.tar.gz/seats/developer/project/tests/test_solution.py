import unittest
import tempfile
import os
from solution import aggregate

class TestAggregate(unittest.TestCase):
    def _write(self, content: str) -> str:
        fd, path = tempfile.mkstemp(suffix=".csv")
        os.close(fd)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def test_basic(self):
        csv = "category,amount\nfood,1.23\nfood,2.34\n"\
            "transport,5.00\n"
        path = self._write(csv)
        self.assertEqual(aggregate(path), {"food": "3.57", "transport": "5.00"})

    def test_blank_lines(self):
        csv = "category,amount\n\nfood,1.00\n\n"
        path = self._write(csv)
        self.assertEqual(aggregate(path), {"food": "1.00"})

    def test_empty_category(self):
        csv = "category,amount\n,1.00\n"
        path = self._write(csv)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_invalid_amount(self):
        csv = "category,amount\nfood,abc\n"
        path = self._write(csv)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_sorted_keys(self):
        csv = "category,amount\nB,1\nA,2\n"
        path = self._write(csv)
        self.assertEqual(aggregate(path), {"A": "2.00", "B": "1.00"})

    def test_whitespace_and_plus(self):
        csv = "category,amount\nfood, +1.00\n"
        path = self._write(csv)
        self.assertEqual(aggregate(path), {"food": "1.00"})

if __name__ == "__main__":
    unittest.main()
