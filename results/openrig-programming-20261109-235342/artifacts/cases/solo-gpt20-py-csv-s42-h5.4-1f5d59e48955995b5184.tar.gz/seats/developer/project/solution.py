import csv
import decimal
import re
from pathlib import Path
from typing import Dict

# Decimal context for exact arithmetic
_DECIMAL_CONTEXT = decimal.Context(prec=28, traps=[decimal.InvalidOperation])

# Regex for amount: optional +, 1-12 digits, optional . and 1-2 digits
_AMOUNT_RE = re.compile(r"^\+?(?=\d)(\d{1,12})(?:\.(\d{1,2}))?$")


def _parse_amount(raw: str) -> decimal.Decimal:
    s = raw.strip()
    if not _AMOUNT_RE.match(s):
        raise ValueError(f"Invalid amount: {raw!r}")
    try:
        d = _DECIMAL_CONTEXT.create_decimal(s)
    except Exception as e:
        raise ValueError(f"Invalid amount: {raw!r}") from e
    if not d.is_finite() or d < 0:
        raise ValueError(f"Invalid amount: {raw!r}")
    return d


def aggregate(path: str | Path) -> Dict[str, str]:
    totals: Dict[str, decimal.Decimal] = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f, skipinitialspace=True)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        if len(header) != 2 or header[0].strip().lower() != "category" or header[1].strip().lower() != "amount":
            raise ValueError("Header must be exactly 'category,amount'")
        for row in reader:
            if not row or all(cell.strip() == "" for cell in row):
                continue
            if len(row) != 2:
                raise ValueError(f"Malformed record: {row}")
            cat_raw, amt_raw = row
            cat = cat_raw.strip()
            if not cat:
                raise ValueError("Category cannot be empty")
            amt = _parse_amount(amt_raw)
            totals[cat] = totals.get(cat, decimal.Decimal("0")) + amt
    return {k: f"{totals[k]:.2f}" for k in sorted(totals)}
