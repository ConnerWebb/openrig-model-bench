# CSV Aggregator

This project implements a simple CSV aggregation function in Python.

## Function
```python
aggregate(path: str | Path) -> Dict[str, str]
```
* Reads a UTF‑8 CSV file.
* Header must be exactly `category,amount`.
* Ignores blank records.
* Each non‑blank record must have two fields.
* Category is stripped and must not be empty.
* Amount is parsed as a non‑negative decimal with 1‑12 digits before the decimal point and 1‑2 after, no exponent.
* Accumulates totals using exact decimal arithmetic.
* Returns a dictionary with sorted keys and totals formatted to two decimal places.

## Tests
Run with `python -m unittest discover`.

## License
MIT.
