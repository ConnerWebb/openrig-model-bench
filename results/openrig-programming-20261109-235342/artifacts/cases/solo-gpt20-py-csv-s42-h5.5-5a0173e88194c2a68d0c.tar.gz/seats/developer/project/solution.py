"""Solution for CSV aggregation.

The function :func:`aggregate` reads a UTF‑8 encoded CSV file that must contain
exactly two columns with the header ``category,amount``.  Each non‑blank line
must contain exactly two fields.  The function strips surrounding whitespace
from both fields, validates the amount format and accumulates the totals per
category using :class:`decimal.Decimal` for exact arithmetic.

The result is a ``dict`` mapping each category to a string representation of
its total rounded to two decimal places.  The dictionary keys are sorted
alphabetically.

The implementation streams the file line by line and never loads the entire
file into memory.
"""

from __future__ import annotations

import csv
import decimal
from pathlib import Path
from typing import Dict

# Configure Decimal to avoid scientific notation and to use exact arithmetic
decimal.getcontext().prec = 28

# Regular expression for amount validation
import re
_AMOUNT_RE = re.compile(r"^\s*([+]?)(\d{1,12})(?:\.(\d{1,2}))?\s*$")


def _validate_amount(raw: str) -> decimal.Decimal:
    """Validate and convert *raw* to :class:`decimal.Decimal`.

    The function accepts an optional leading ``+`` sign, 1–12 digits before an
    optional decimal point and 1–2 digits after the point.  No exponent part
    is allowed.  Leading/trailing whitespace is ignored.
    """
    m = _AMOUNT_RE.match(raw)
    if not m:
        raise ValueError(f"Invalid amount format: {raw!r}")
    sign, int_part, frac_part = m.group(1, 2, 3)
    # Build a canonical string for Decimal
    s = f"{sign}{int_part}"
    if frac_part is not None:
        s += f".{frac_part}"
    return decimal.Decimal(s)


def aggregate(path: str | Path) -> Dict[str, str]:
    """Aggregate amounts per category from a CSV file.

    Parameters
    ----------
    path:
        Path to the UTF‑8 encoded CSV file.

    Returns
    -------
    dict
        Mapping of category to total amount formatted with exactly two
        decimal places.
    """
    totals: Dict[str, decimal.Decimal] = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("CSV file is empty")
        if len(header) != 2 or header[0].strip() != "category" or header[1].strip() != "amount":
            raise ValueError("Header must be exactly 'category,amount'")
        for row in reader:
            # Skip completely blank rows (all fields empty or whitespace)
            if all(not field.strip() for field in row):
                continue
            if len(row) != 2:
                raise ValueError(f"Malformed row: {row}")
            cat_raw, amt_raw = row
            cat = cat_raw.strip()
            if not cat:
                raise ValueError("Category cannot be empty")
            amt = _validate_amount(amt_raw)
            totals[cat] = totals.get(cat, decimal.Decimal("0")) + amt
    # Format totals with two decimal places, sorted keys
    result: Dict[str, str] = {}
    for cat in sorted(totals):
        # quantize to two decimal places, rounding half up
        formatted = str(totals[cat].quantize(decimal.Decimal("0.01"), rounding=decimal.ROUND_HALF_UP))
        result[cat] = formatted
    return result

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python solution.py <csv-file>")
        sys.exit(1)
    print(aggregate(sys.argv[1]))
