# CSV Aggregator

This repository implements a simple CSV aggregation utility.

## Function

```python
aggregate(path: str | Path) -> Dict[str, str]
```

* Reads a UTF‑8 CSV file with header `category,amount`.
* Ignores completely blank rows.
* Validates each row: exactly two fields, non‑empty category, amount matches
  `+?\d{1,12}(\.\d{1,2})?`.
* Accumulates totals per category using exact decimal arithmetic.
* Returns a dictionary with sorted keys and totals formatted to two decimal
  places.

## Tests

Run the tests with:

```bash
python -m unittest test_solution.py
```

The test suite covers normal operation, whitespace handling, error cases and
decimal rounding.
