import unittest
import tempfile
import os
from solution import aggregate

class TestAggregate(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "data.csv")

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, content):
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(content)

    def test_basic(self):
        self.write("category,amount\nA,1.00\nB,2.5\nA,3.25\n")
        expected = {"A": "4.25", "B": "2.50"}
        self.assertEqual(aggregate(self.path), expected)

    def test_whitespace_and_blank(self):
        self.write("category,amount\n  A  ,  1.00  \n\nB,2.00\n")
        expected = {"A": "1.00", "B": "2.00"}
        self.assertEqual(aggregate(self.path), expected)

    def test_invalid_header(self):
        self.write("cat,amt\nA,1.00\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_invalid_row(self):
        self.write("category,amount\nA,1.00\nB\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_invalid_amount(self):
        self.write("category,amount\nA,1.234\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_empty_category(self):
        self.write("category,amount\n ,1.00\n")
        with self.assertRaises(ValueError):
            aggregate(self.path)

    def test_large_amount(self):
        self.write("category,amount\nA,123456789012.34\n")
        expected = {"A": "123456789012.34"}
        self.assertEqual(aggregate(self.path), expected)

    def test_sorted_keys(self):
        self.write("category,amount\nB,1.00\nA,2.00\n")
        result = aggregate(self.path)
        self.assertEqual(list(result.keys()), ["A", "B"])

if __name__ == "__main__":
    unittest.main()
