#include "stats.hpp"
#include <cmath>
#include <iostream>
#include <limits>
#include <cassert>

void test_empty_stats() {
    RunningStats rs;
    assert(rs.count() == 0);
    
    bool threw = false;
    try { rs.mean(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
    
    threw = false;
    try { rs.variance(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
    
    threw = false;
    try { rs.minimum(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
    
    threw = false;
    try { rs.maximum(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
}

void test_single_value() {
    RunningStats rs;
    rs.add(42.0);
    
    assert(rs.count() == 1);
    assert(std::abs(rs.mean() - 42.0) < 1e-10);
    assert(std::abs(rs.variance() - 0.0) < 1e-10);
    assert(std::abs(rs.minimum() - 42.0) < 1e-10);
    assert(std::abs(rs.maximum() - 42.0) < 1e-10);
}

void test_multiple_values() {
    RunningStats rs;
    rs.add(1.0);
    rs.add(2.0);
    rs.add(3.0);
    rs.add(4.0);
    rs.add(5.0);
    
    assert(rs.count() == 5);
    assert(std::abs(rs.mean() - 3.0) < 1e-10);
    assert(std::abs(rs.variance() - 2.0) < 1e-10);
    assert(std::abs(rs.minimum() - 1.0) < 1e-10);
    assert(std::abs(rs.maximum() - 5.0) < 1e-10);
}

void test_nan_rejection() {
    RunningStats rs;
    rs.add(1.0);
    rs.add(2.0);
    
    bool threw = false;
    try { rs.add(std::numeric_limits<double>::quiet_NaN()); }
    catch (const std::invalid_argument&) { threw = true; }
    assert(threw);
    assert(rs.count() == 2);
    
    threw = false;
    try { rs.add(std::numeric_limits<double>::infinity()); }
    catch (const std::invalid_argument&) { threw = true; }
    assert(threw);
    assert(rs.count() == 2);
    
    threw = false;
    try { rs.add(-std::numeric_limits<double>::infinity()); }
    catch (const std::invalid_argument&) { threw = true; }
    assert(threw);
    assert(rs.count() == 2);
}

void test_merge_empty() {
    RunningStats rs1, rs2;
    rs1.merge(rs2);
    assert(rs1.count() == 0);
    rs2.merge(rs1);
    assert(rs2.count() == 0);
}

void test_merge_into_empty() {
    RunningStats rs1, rs2;
    rs1.add(1.0);
    rs1.add(2.0);
    rs1.add(3.0);
    rs2.merge(rs1);
    assert(rs2.count() == 3);
    assert(std::abs(rs2.mean() - 2.0) < 1e-10);
    assert(std::abs(rs2.minimum() - 1.0) < 1e-10);
    assert(std::abs(rs2.maximum() - 3.0) < 1e-10);
}

void test_merge_into_nonempty() {
    RunningStats rs1, rs2;
    rs1.add(1.0);
    rs1.add(2.0);
    rs2.add(3.0);
    rs2.add(4.0);
    rs2.add(5.0);
    rs1.merge(rs2);
    assert(rs1.count() == 5);
    assert(std::abs(rs1.mean() - 3.0) < 1e-10);
    assert(std::abs(rs1.minimum() - 1.0) < 1e-10);
    assert(std::abs(rs1.maximum() - 5.0) < 1e-10);
}

void test_self_merge() {
    RunningStats rs;
    rs.add(1.0);
    rs.add(2.0);
    rs.add(3.0);
    double original_mean = rs.mean();
    double original_variance = rs.variance();
    rs.merge(rs);
    assert(rs.count() == 6);
    assert(std::abs(rs.mean() - original_mean) < 1e-10);
    assert(std::abs(rs.variance() - original_variance) < 1e-10);
}

void test_large_values_stability() {
    RunningStats rs;
    double values[] = {
        42.0, 9.0, 0.0, 1000000030.0, 1000000058.0, 999999902.0, 999999967.0,
        999999939.0, 1000000093.0, 999999951.0, 999999967.0, 999999922.0,
        999999951.0, 1000000031.0, 999999914.0, 1000000052.0, 999999949.0,
        1000000029.0, 999999906.0, 1000000077.0, 1000000034.0, 999999993.0,
        1000000017.0, 1000000094.0, 999999933.0, 999999989.0, 1000000065.0,
        999999942.0, 999999909.0, 999999989.0, 1000000055.0, 999999907.0,
        999999999.0, 1000000065.0, 1000000049.0, 999999948.0, 999999938.0,
        999999982.0, 1000000011.0, 1000000014.0, 999999924.0, 1000000069.0,
        999999905.0, 999999963.0, 1000000054.0
    };
    for (double v : values) rs.add(v);
    assert(rs.count() == 48);
    assert(std::abs(rs.mean() - 999999990.1428572) < 1e-4 + 1e-6 * 999999990.1428572);
    assert(std::abs(rs.variance() - 3466.598639455782) < 1e-4 + 1e-6 * 999999990.1428572);
    assert(std::abs(rs.minimum() - 0.0) < 1e-10);
    assert(std::abs(rs.maximum() - 1000000094.0) < 1e-10);
}

void test_merge_preserves_stability() {
    RunningStats rs1, rs2;
    double values1[] = {42.0, 9.0, 0.0, 1000000030.0, 1000000058.0, 999999902.0, 999999967.0};
    double values2[] = {999999939.0, 1000000093.0, 999999951.0, 999999967.0, 999999922.0};
    for (double v : values1) rs1.add(v);
    for (double v : values2) rs2.add(v);
    rs1.merge(rs2);
    assert(rs1.count() == 12);
    assert(std::abs(rs1.mean() - 999999990.1428572) < 1e-4 + 1e-6 * 999999990.1428572);
    assert(std::abs(rs1.variance() - 3466.598639455782) < 1e-4 + 1e-6 * 999999990.1428572);
    assert(std::abs(rs1.minimum() - 0.0) < 1e-10);
    assert(std::abs(rs1.maximum() - 1000000094.0) < 1e-10);
}

int main() {
    test_empty_stats();
    test_single_value();
    test_multiple_values();
    test_nan_rejection();
    test_merge_empty();
    test_merge_into_empty();
    test_merge_into_nonempty();
    test_self_merge();
    test_large_values_stability();
    test_merge_preserves_stability();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
