#include "stats.hpp"
#include <cmath>
#include <limits>

void RunningStats::add(double x) {
    if (std::isnan(x) || std::isinf(x)) {
        throw std::invalid_argument("Input must be a finite number");
    }
    
    n++;
    sum += x;
    squares += x * x;
    
    if (x < minVal) {
        minVal = x;
    }
    if (x > maxVal) {
        maxVal = x;
    }
}

void RunningStats::merge(const RunningStats& other) {
    if (other.n == 0) {
        return;
    }
    
    if (n == 0) {
        n = other.n;
        sum = other.sum;
        squares = other.squares;
        minVal = other.minVal;
        maxVal = other.maxVal;
    } else {
        n += other.n;
        sum += other.sum;
        squares += other.squares;
        
        if (other.minVal < minVal) {
            minVal = other.minVal;
        }
        if (other.maxVal > maxVal) {
            maxVal = other.maxVal;
        }
    }
}

std::uint64_t RunningStats::count() const {
    return n;
}

double RunningStats::mean() const {
    if (n == 0) {
        throw std::domain_error("Cannot compute mean of empty stats");
    }
    return sum / n;
}

double RunningStats::variance() const {
    if (n == 0) {
        throw std::domain_error("Cannot compute variance of empty stats");
    }
    double m = mean();
    return squares / n - m * m;
}

double RunningStats::minimum() const {
    if (n == 0) {
        throw std::domain_error("Cannot compute minimum of empty stats");
    }
    return minVal;
}

double RunningStats::maximum() const {
    if (n == 0) {
        throw std::domain_error("Cannot compute maximum of empty stats");
    }
    return maxVal;
}
