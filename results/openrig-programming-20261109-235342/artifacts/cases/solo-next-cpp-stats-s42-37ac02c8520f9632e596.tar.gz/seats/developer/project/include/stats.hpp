#pragma once
#include <cstdint>
#include <stdexcept>

class RunningStats {
public:
    void add(double x);
    void merge(const RunningStats& other);
    std::uint64_t count() const;
    double mean() const;
    double variance() const;
    double minimum() const;
    double maximum() const;

private:
    std::uint64_t n = 0;
    double sum = 0.0;
    double squares = 0.0;
    double minVal = std::numeric_limits<double>::infinity();
    double maxVal = -std::numeric_limits<double>::infinity();
};
