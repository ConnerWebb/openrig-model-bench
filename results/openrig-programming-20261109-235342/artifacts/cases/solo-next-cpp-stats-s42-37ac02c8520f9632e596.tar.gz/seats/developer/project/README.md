# RunningStats

A C++20 library for computing running statistics using stable online algorithms.

## Features

- **Running statistics**: Compute mean, variance, minimum, and maximum incrementally
- **Merge support**: Combine statistics from multiple sources
- **Numerical stability**: Uses stable algorithms suitable for large values
- **Input validation**: Rejects NaN and infinity values

## Usage

```cpp
#include "stats.hpp"

RunningStats rs;
rs.add(1.0);
rs.add(2.0);
rs.add(3.0);

std::cout << "Count: " << rs.count() << "\n";
std::cout << "Mean: " << rs.mean() << "\n";
std::cout << "Variance: " << rs.variance() << "\n";
std::cout << "Min: " << rs.minimum() << "\n";
std::cout << "Max: " << rs.maximum() << "\n";
```

## Merging

```cpp
RunningStats rs1, rs2;
rs1.add(1.0);
rs1.add(2.0);

rs2.add(3.0);
rs2.add(4.0);

rs1.merge(rs2);  // rs1 now contains all 4 values
```

## Error handling

- `std::domain_error`: Thrown when calling `mean()`, `variance()`, `minimum()`, or `maximum()` on empty stats
- `std::invalid_argument`: Thrown when adding NaN or infinity values

## Building

```bash
mkdir build
cd build
cmake ..
make
make test
```

## Requirements

- CMake 3.20+
- C++20 compatible compiler (Clang 22+ recommended)
