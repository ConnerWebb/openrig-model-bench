#include "solution.hpp"
#include <sstream>
#include <iostream>
#include <cassert>

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\nfood,50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["food"] == 150);
    assert(result["rent"] == 200);
    std::cout << "test_basic passed\n";
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nrent,100\nfood,25\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["food"] == -25);
    assert(result["rent"] == 100);
    std::cout << "test_negative passed\n";
}

void test_quoted_fields() {
    std::string input = "category,amount\n\"a,b\",100\n\"c,d\",200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["c,d"] == 200);
    std::cout << "test_quoted_fields passed\n";
}

void test_quoted_with_newlines() {
    std::string input = "category,amount\n\"two\nlines\",100\nfood,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["two\nlines"] == 100);
    assert(result["food"] == 200);
    std::cout << "test_quoted_with_newlines passed\n";
}

void test_escaped_quotes() {
    std::string input = "category,amount\n\"x\"\"quote\",100\nfood,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["x\"quote"] == 100);
    assert(result["food"] == 200);
    std::cout << "test_escaped_quotes passed\n";
}

void test_whitespace_stripping() {
    std::string input = "category,amount\n  food  ,  100  \n\trent\t,\t200\t\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_whitespace_stripping passed\n";
}

void test_empty_fields() {
    std::string input = "category,amount\n,100\n";
    std::istringstream iss(input);
    
    try {
        auto result = aggregate(iss);
        std::cerr << "test_empty_fields failed: should have thrown\n";
        exit(1);
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_fields passed\n";
    }
}

void test_wrong_field_count() {
    std::string input = "category,amount\nfood,100,extra\n";
    std::istringstream iss(input);
    
    try {
        auto result = aggregate(iss);
        std::cerr << "test_wrong_field_count failed: should have thrown\n";
        exit(1);
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count passed\n";
    }
}

void test_invalid_header() {
    std::string input = "cat,amt\nfood,100\n";
    std::istringstream iss(input);
    
    try {
        auto result = aggregate(iss);
        std::cerr << "test_invalid_header failed: should have thrown\n";
        exit(1);
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_header passed\n";
    }
}

void test_overflow() {
    std::string input = "category,amount\nfood,9999999999999999999\n";
    std::istringstream iss(input);
    
    try {
        auto result = aggregate(iss);
        std::cerr << "test_overflow failed: should have thrown\n";
        exit(1);
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow passed\n";
    }
}

void test_positive_sign() {
    std::string input = "category,amount\nfood,+100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["food"] == 100);
    std::cout << "test_positive_sign passed\n";
}

void test_empty_physical_records_ignored() {
    std::string input = "category,amount\nfood,100\n\nrent,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_empty_physical_records_ignored passed\n";
}

void test_public_case_1() {
    std::string input = "\"category,amount\n\\\"x\\\"\\\"quote\\\"\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\"\\\",-22826\n\\\"x\\\"\\\"quote\\\"\\\",-4598\n\\\"x\\\"\\\"quote\\\"\\\",-26830\n日本,39039\n\\\"a,b\\\"\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\"\\\",-26030\n\\\"two\nlines\\\"\\\",54977\n\\\"x\\\"\\\"quote\\\"\\\",-5124\nrent,12112\n\\\"two\nlines\\\"\\\",28447\nfood,57027\nfood,2732\n\"";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["a,b"] == 29914);
    assert(result["food"] == 76201);
    assert(result["rent"] == 101592);
    assert(result["two\nlines"] == 83424);
    assert(result["x\"quote"] == -34140);
    assert(result["日本"] == 30901);
    std::cout << "test_public_case_1 passed\n";
}

void test_public_case_2() {
    std::string input = "\"category,amount\nrent,-9556\nrent,66551\n\\\"x\\\"\\\"quote\\\"\\\",16496\n\\\"a,b\\\"\\\",45807\nfood,2933\n\\\"a,b\\\"\\\",-2689\n\\\"two\nlines\\\"\\\",-26164\nfood,-17212\nrent,-17129\n\\\"a,b\\\"\\\",-11765\n\\\"two\nlines\\\"\\\",32601\n\\\"two\nlines\\\"\\\",44138\n\\\"x\\\"\\\"quote\\\"\\\",16953\n\\\"a,b\\\"\\\",-17563\nrent,9736\n\\\"x\\\"\\\"quote\\\"\\\",-1687\nrent,45449\n\\\"two\nlines\\\"\\\",32422\n\\\"x\\\"\\\"quote\\\"\\\",12082\n\\\"a,b\\\"\\\",-17578\n日本,68439\n日本,51787\n\\\"x\\\"\\\"quote\\\"\\\",3800\n日本,67827\nfood,-25402\nrent,-999\n\\\"two\nlines\\\"\\\",12732\n日本,36085\n\\\"x\\\"\\\"quote\\\"\\\",10273\nrent,5384\nrent,-22978\n\\\"two\nlines\\\"\\\",40487\n\\\"two\nlines\\\"\\\",1264\nrent,48802\nfood,-2246\n日本,27744\n\\\"a,b\\\"\\\",31246\n\\\"two\nlines\\\"\\\",3911\n\"";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["a,b"] == 27458);
    assert(result["food"] == -41927);
    assert(result["rent"] == 125260);
    assert(result["two\nlines"] == 141391);
    assert(result["x\"quote"] == 57917);
    assert(result["日本"] == 251882);
    std::cout << "test_public_case_2 passed\n";
}

void test_public_case_3() {
    std::string input = "\"category,amount\n\\\"two\nlines\\\"\\\",40111\n日本,11763\n\\\"x\\\"\\\"quote\\\"\\\",33647\n\\\"x\\\"\\\"quote\\\"\\\",34543\nfood,23459\nrent,29515\n\\\"a,b\\\"\\\",54538\n\\\"x\\\"\\\"quote\\\"\\\",35679\n日本,8085\n日本,-28222\nfood,25384\n\\\"two\nlines\\\"\\\"\\\",-21563\n\\\"a,b\\\"\\\",2524\n\\\"a,b\\\"\\\",48367\n日本,-10120\n\\\"two\nlines\\\"\\\",58926\n\\\"x\\\"\\\"quote\\\"\\\",42784\n\\\"a,b\\\"\\\",47727\n\\\"two\nlines\\\"\\\",-23503\n\"";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["a,b"] == 153156);
    assert(result["food"] == 48843);
    assert(result["rent"] == 29515);
    assert(result["two\nlines"] == 53971);
    assert(result["x\"quote"] == 146653);
    assert(result["日本"] == -18494);
    std::cout << "test_public_case_3 passed\n";
}

int main() {
    test_basic();
    test_negative();
    test_quoted_fields();
    test_quoted_with_newlines();
    test_escaped_quotes();
    test_whitespace_stripping();
    test_empty_fields();
    test_wrong_field_count();
    test_invalid_header();
    test_overflow();
    test_positive_sign();
    test_empty_physical_records_ignored();
    test_public_case_1();
    test_public_case_2();
    test_public_case_3();
    
    std::cout << "\nAll tests passed!\n";
    return 0;
}
