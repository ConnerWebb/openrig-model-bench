#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <stdexcept>
#include <cctype>
#include <vector>
#include <cstdint>
#include <limits>

namespace detail {

// Strip carriage return, spaces, and tabs from both ends of a string
inline std::string strip_cr(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse a single CSV field, handling escaped quotes
// The escape sequence \" produces a quote character
// Returns the parsed field and updates pos to point after the field (or comma/newline)
inline std::string parse_csv_field(const std::string& input, size_t& pos) {
    if (pos >= input.size()) {
        return "";
    }
    
    // Unquoted field - read until comma or newline
    size_t start = pos;
    while (pos < input.size() && input[pos] != ',' && input[pos] != '\n') {
        ++pos;
    }
    std::string field = input.substr(start, pos - start);
    
    // Process escape sequences: \" -> "
    std::string result;
    size_t i = 0;
    while (i < field.size()) {
        if (field[i] == '\\' && i + 1 < field.size() && field[i + 1] == '"') {
            result += '"';
            i += 2;
        } else {
            result += field[i];
            ++i;
        }
    }
    
    return result;
}

// Parse a complete CSV line, returning fields
// Updates pos to after the newline
inline std::vector<std::string> parse_csv_line(const std::string& input, size_t& pos) {
    std::vector<std::string> fields;
    while (pos < input.size()) {
        fields.push_back(parse_csv_field(input, pos));
        if (pos >= input.size()) {
            break;
        }
        if (input[pos] == ',') {
            ++pos; // skip comma, read next field
        } else if (input[pos] == '\n') {
            ++pos; // skip newline
            break;
        }
    }
    return fields;
}

// Parse a signed 64-bit integer
// Throws std::invalid_argument on overflow or malformed input
inline std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) {
        throw std::invalid_argument("Empty integer string");
    }
    
    size_t idx = 0;
    bool negative = false;
    
    // Skip leading whitespace
    while (idx < s.size() && std::isspace(s[idx])) {
        ++idx;
    }
    
    if (idx >= s.size()) {
        throw std::invalid_argument("Empty integer string after whitespace");
    }
    
    // Check for sign
    if (s[idx] == '-') {
        negative = true;
        ++idx;
    } else if (s[idx] == '+') {
        ++idx;
    }
    
    if (idx >= s.size()) {
        throw std::invalid_argument("No digits after sign");
    }
    
    // Check for valid digits
    if (!std::isdigit(s[idx])) {
        throw std::invalid_argument("Invalid digit");
    }
    
    std::int64_t result = 0;
    while (idx < s.size() && std::isdigit(s[idx])) {
        int digit = s[idx] - '0';
        
        // Check for overflow
        if (result > (std::numeric_limits<std::int64_t>::max() - digit) / 10) {
            throw std::invalid_argument("Integer overflow");
        }
        
        result = result * 10 + digit;
        ++idx;
    }
    
    // Skip trailing whitespace
    while (idx < s.size() && std::isspace(s[idx])) {
        ++idx;
    }
    
    if (idx < s.size()) {
        throw std::invalid_argument("Trailing characters");
    }
    
    if (negative) {
        result = -result;
    }
    
    return result;
}

} // namespace detail

inline std::map<std::string, std::int64_t> aggregate(std::istream& is) {
    std::string line;
    std::getline(is, line);
    
    // Parse and validate header
    size_t pos = 0;
    auto header_fields = detail::parse_csv_line(line, pos);
    
    if (header_fields.size() != 2) {
        throw std::invalid_argument("Expected exactly 2 header fields");
    }
    
    // Strip and validate header fields
    std::string category_field = detail::strip_cr(header_fields[0]);
    std::string amount_field = detail::strip_cr(header_fields[1]);
    
    if (category_field != "category" || amount_field != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    std::map<std::string, std::int64_t> result;
    
    while (std::getline(is, line)) {
        // Skip empty lines
        if (detail::strip_cr(line).empty()) {
            continue;
        }
        
        pos = 0;
        auto fields = detail::parse_csv_line(line, pos);
        
        if (fields.size() != 2) {
            throw std::invalid_argument("Expected exactly 2 fields per row");
        }
        
        std::string category = detail::strip_cr(fields[0]);
        std::string amount_str = detail::strip_cr(fields[1]);
        
        if (category.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        
        std::int64_t amount = detail::parse_int64(amount_str);
        
        // Check for overflow when accumulating
        if ((amount > 0 && result[category] > std::numeric_limits<std::int64_t>::max() - amount) ||
            (amount < 0 && result[category] < std::numeric_limits<std::int64_t>::min() - amount)) {
            throw std::invalid_argument("Integer overflow in accumulation");
        }
        
        result[category] += amount;
    }
    
    return result;
}

#endif
