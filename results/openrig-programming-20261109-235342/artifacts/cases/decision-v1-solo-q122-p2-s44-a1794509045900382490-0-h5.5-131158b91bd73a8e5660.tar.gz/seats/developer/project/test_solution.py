import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.00\nfood,5.50', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n rent ,20.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50', 'rent': '20.00'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,10.00\n\nrent,20.00\n   \nfood,5.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '15.00', 'rent': '20.00'})
    
    def test_quoted_commas(self):
        """Test handling of quoted commas in category"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"a,b",100.00\n"a,b",50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '150.00'})
    
    def test_embedded_newlines(self):
        """Test handling of embedded newlines in quoted fields"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"two\nlines",100.00\n"two\nlines",50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '150.00'})
    
    def test_double_quotes_escaped(self):
        """Test handling of escaped double quotes"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"x""quote",100.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,+10.50\nrent,+20', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50', 'rent': '20.00'})
    
    def test_integer_amounts(self):
        """Test integer amounts (no decimal point)"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,10\nrent,20', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})
    
    def test_sorted_keys(self):
        """Test that result keys are sorted"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nzebra,10.00\napple,20.00\nmango,30.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_empty_category_raises(self):
        """Test that empty category raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n,10.00', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_wrong_header_raises(self):
        """Test that wrong header raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('wrong,header\nx,10.00', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_wrong_field_count_raises(self):
        """Test that wrong field count raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,1,2', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_negative_amount_raises(self):
        """Test that negative amount raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,-1', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_exponent_raises(self):
        """Test that exponent notation raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,1e2', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_nan_raises(self):
        """Test that NaN raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,NaN', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_too_many_decimal_places_raises(self):
        """Test that more than 2 decimal places raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,1.001', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_large_amount(self):
        """Test large amount (up to 12 digits)"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,999999999999', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '999999999999.00'})
    
    def test_too_many_digits_raises(self):
        """Test that more than 12 digits raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,1000000000000', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file_raises(self):
        """Test that empty file raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only(self):
        """Test file with only header returns empty dict"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {})
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"日本",100.00\n"日本",50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '150.00'})


if __name__ == '__main__':
    unittest.main()
