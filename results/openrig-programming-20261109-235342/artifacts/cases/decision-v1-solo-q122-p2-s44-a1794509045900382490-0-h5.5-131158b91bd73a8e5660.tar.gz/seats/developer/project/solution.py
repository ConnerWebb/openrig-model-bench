import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Accumulate using exact decimal arithmetic. Return sorted category keys
    with totals formatted to exactly two decimal places.
    """
    totals = {}
    
    # Amount pattern: optional +, 1-12 digits, optional decimal point with 1-2 digits
    # Must be nonnegative, finite, no exponent
    amount_pattern = re.compile(r'^\+?(\d{1,12})(?:\.(\d{1,2}))?$')
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly category,amount")
        
        for row in reader:
            # Skip completely blank records (empty row or all fields empty/whitespace)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Every other record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate amount format
            match = amount_pattern.match(amount_str)
            if not match:
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse amount using Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check for nonnegative (amount >= 0)
            if amount < 0:
                raise ValueError(f"Amount must be nonnegative: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly two decimal places, sorted by key
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
