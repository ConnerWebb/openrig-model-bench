# Solution: CSV Aggregator

## Overview

This module implements a CSV aggregator that reads UTF-8 CSV files and computes totals by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Accumulate using exact decimal arithmetic. Return sorted category keys
    with totals formatted to exactly two decimal places.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to formatted totals (2 decimal places)
        
    Raises:
        ValueError: If the CSV is malformed (wrong header, invalid amount format,
                   empty category, wrong field count, etc.)
    """
```

## Input Format

- CSV file with header exactly `category,amount`
- Each data row must have exactly two fields
- Completely blank rows are ignored
- Whitespace is stripped from both category and amount
- Category must not be empty after stripping
- Amount format: optional `+`, 1-13 decimal digits, optional decimal point followed by 1-2 digits
- Amounts must be nonnegative (no negative signs, no NaN, no infinity)
- Exponent notation (e.g., `1e2`) is not allowed
- Quoted fields with embedded commas and newlines are supported

## Output Format

- Dictionary with category names as keys (sorted alphabetically)
- Values are strings formatted with exactly two decimal places (e.g., `"123.45"`)

## Example

```python
>>> aggregate("data.csv")
{'food': '150.00', 'rent': '500.00'}
```

## Testing

Run the test suite with:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
