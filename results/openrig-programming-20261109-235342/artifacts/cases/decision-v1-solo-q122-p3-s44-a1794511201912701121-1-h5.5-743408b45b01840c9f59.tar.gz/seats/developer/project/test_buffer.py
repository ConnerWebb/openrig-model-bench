import unittest
import subprocess
import json
import sys

class TestBuffer(unittest.TestCase):
    def run_driver(self, input_data):
        """Run the C++ driver with given input and return parsed JSON output."""
        result = subprocess.run(
            ['./driver'],
            input=input_data,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return {"error": "Driver execution failed"}
        try:
            return json.loads(result.stdout.strip())
        except json.JSONDecodeError:
            return {"error": "Invalid JSON output"}

    def test_case_00(self):
        """Test case from public-inputs/case-00.json"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        expected = {
            "value": [4, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "moved_size": 0,
            "copy": [251, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97],
            "bounds": True
        }
        result = self.run_driver(input_data)
        self.assertEqual(result.get("value"), expected["value"])
        self.assertEqual(result.get("moved_size"), expected["moved_size"])
        self.assertEqual(result.get("copy"), expected["copy"])
        self.assertEqual(result.get("bounds"), expected["bounds"])

    def test_case_01(self):
        """Test case from public-inputs/case-01.json"""
        input_data = "9 41 223 228 49 10 127 75 79 126 181"
        result = self.run_driver(input_data)
        self.assertNotIn("error", result)
        self.assertIn("value", result)
        self.assertIn("moved_size", result)
        self.assertIn("copy", result)
        self.assertIn("bounds", result)

    def test_case_02(self):
        """Test case from public-inputs/case-02.json"""
        input_data = "19 74 8 128 179 106 201 14 35 49 127 50 151 71 212 244 252 183 151 48 104"
        result = self.run_driver(input_data)
        self.assertNotIn("error", result)
        self.assertIn("value", result)

    def test_case_03(self):
        """Test case from public-inputs/case-03.json"""
        input_data = "19 79 110 82 225 243 164 133 48 132 12 17 96 113 241 166 157 124 138 72 27"
        result = self.run_driver(input_data)
        self.assertNotIn("error", result)
        self.assertIn("value", result)

    def test_empty_buffer(self):
        """Test empty buffer construction and operations"""
        input_data = "0 10"
        result = self.run_driver(input_data)
        self.assertNotIn("error", result)
        # After resize to 10, value should be 10 zeros
        self.assertEqual(result.get("value"), [0] * 10)
        self.assertEqual(result.get("moved_size"), 0)
        self.assertEqual(result.get("copy"), [])
        self.assertTrue(result.get("bounds"))

    def test_zero_resize(self):
        """Test resizing to zero"""
        input_data = "5 0 1 2 3 4 5"
        result = self.run_driver(input_data)
        self.assertNotIn("error", result)
        # After resize to 0, value should be empty
        self.assertEqual(result.get("value"), [])

if __name__ == '__main__':
    unittest.main()
