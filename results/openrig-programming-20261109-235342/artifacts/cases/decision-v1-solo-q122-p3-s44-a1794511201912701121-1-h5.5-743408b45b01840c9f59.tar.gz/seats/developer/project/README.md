# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Constructor**: `Buffer(size_t n = 0)` - Creates a buffer of `n` bytes, zero-initialized
- **Size**: `size() const noexcept` - Returns the current buffer size
- **Access**: `operator[](size_t)` - Bounds-checked mutable and const access, throws `std::out_of_range`
- **Resize**: `resize(size_t k)` - Resizes buffer preserving prefix, zero-initializing new bytes
- **Copy Semantics**: Deep copy construction and assignment
- **Move Semantics**: Noexcept move construction and assignment; moved-from buffers have size 0 and are reusable
- **Self-assignment**: Self-copy and self-move preserve content

## Implementation Details

- Uses RAII with proper resource management
- No memory leaks, double frees, or undefined behavior
- Standard containers allowed (used raw pointers with proper delete[])
- Elements are `uint8_t`

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o driver PUBLIC_DRIVER.cpp
```

## Testing

Run the test suite:
```bash
python3 -m unittest test_buffer.py
```

Or use the project's test runner:
```bash
run_tests
```

## API Contract

1. `Buffer(n=0)` - Construct buffer of size n, zero-initialized
2. `size() const` - Return buffer size
3. `operator[](i)` - Access element at index i, throw `out_of_range` if i >= size()
4. `resize(k)` - Resize to k bytes, preserve first min(n,k) bytes, zero-initialize new bytes
5. Copy constructor/assignment - Deep copy
6. Move constructor/assignment - Noexcept, moved-from buffer has size 0
