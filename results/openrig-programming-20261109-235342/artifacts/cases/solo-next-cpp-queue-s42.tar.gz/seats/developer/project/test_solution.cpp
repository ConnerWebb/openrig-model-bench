#include "solution.hpp"
#include <thread>
#include <vector>
#include <iostream>
#include <cassert>
#include <chrono>
#include <atomic>

void test_basic_push_pop() {
    BoundedQueue<int> q(3);
    assert(q.push(1));
    assert(q.push(2));
    assert(q.push(3));
    
    auto v1 = q.pop();
    assert(v1.has_value() && v1.value() == 1);
    
    auto v2 = q.pop();
    assert(v2.has_value() && v2.value() == 2);
    
    auto v3 = q.pop();
    assert(v3.has_value() && v3.value() == 3);
    
    auto v4 = q.pop();
    assert(!v4.has_value());
}

void test_zero_capacity_throws() {
    bool threw = false;
    try {
        BoundedQueue<int> q(0);
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
}

void test_close_wakes_all() {
    BoundedQueue<int> q(1);
    
    std::thread producer([&]() {
        bool pushed = q.push(1);
        assert(pushed);
    });
    
    std::thread consumer([&]() {
        auto v = q.pop();
        assert(v.has_value() && v.value() == 1);
    });
    
    producer.join();
    consumer.join();
}

void test_push_after_close_returns_false() {
    BoundedQueue<int> q(3);
    q.close();
    assert(!q.push(1));
}

void test_pop_after_close_drains() {
    BoundedQueue<int> q(3);
    q.push(1);
    q.push(2);
    q.push(3);
    q.close();
    
    auto v1 = q.pop();
    assert(v1.has_value() && v1.value() == 1);
    
    auto v2 = q.pop();
    assert(v2.has_value() && v2.value() == 2);
    
    auto v3 = q.pop();
    assert(v3.has_value() && v3.value() == 3);
    
    auto v4 = q.pop();
    assert(!v4.has_value());
}

void test_move_only_type() {
    struct MoveOnly {
        int value;
        MoveOnly(int v) : value(v) {}
        MoveOnly(MoveOnly&&) = default;
        MoveOnly& operator=(MoveOnly&&) = default;
        MoveOnly(const MoveOnly&) = delete;
        MoveOnly& operator=(const MoveOnly&) = delete;
    };
    
    BoundedQueue<MoveOnly> q(2);
    assert(q.push(MoveOnly(42)));
    assert(q.push(MoveOnly(43)));
    
    auto v1 = q.pop();
    assert(v1.has_value() && v1.value().value == 42);
    
    auto v2 = q.pop();
    assert(v2.has_value() && v2.value().value == 43);
}

void test_fifo_order() {
    BoundedQueue<int> q(5);
    for (int i = 0; i < 5; ++i) {
        q.push(i);
    }
    
    for (int i = 0; i < 5; ++i) {
        auto v = q.pop();
        assert(v.has_value() && v.value() == i);
    }
}

void test_idempotent_close() {
    BoundedQueue<int> q(3);
    q.close();
    q.close();
    q.close();
    assert(!q.push(1));
}

void test_close_wakes_blocked_producer() {
    BoundedQueue<int> q(1);
    std::atomic<bool> producer_blocked{true};
    std::atomic<bool> producer_done{false};
    
    std::thread producer([&]() {
        bool pushed = q.push(1);
        assert(pushed);
        producer_blocked = false;
        bool pushed2 = q.push(2);
        assert(!pushed2);
        producer_done = true;
    });
    
    std::thread closer([&]() {
        while (producer_blocked) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        q.close();
    });
    
    producer.join();
    closer.join();
    assert(producer_done);
}

void test_close_wakes_blocked_consumer() {
    BoundedQueue<int> q(1);
    std::atomic<bool> consumer_done{false};
    
    std::thread consumer([&]() {
        auto v = q.pop();
        assert(!v.has_value());
        consumer_done = true;
    });
    
    std::thread closer([&]() {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        q.close();
    });
    
    consumer.join();
    closer.join();
    assert(consumer_done);
}

int main() {
    test_basic_push_pop();
    test_zero_capacity_throws();
    test_close_wakes_all();
    test_push_after_close_returns_false();
    test_pop_after_close_drains();
    test_move_only_type();
    test_fifo_order();
    test_idempotent_close();
    test_close_wakes_blocked_producer();
    test_close_wakes_blocked_consumer();
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
