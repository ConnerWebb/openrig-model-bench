#ifndef BOUNDED_QUEUE_HPP
#define BOUNDED_QUEUE_HPP

#include <queue>
#include <optional>
#include <stdexcept>
#include <mutex>
#include <condition_variable>
#include <atomic>

template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity) : capacity_(capacity), closed_(false) {
        if (capacity == 0) {
            throw std::invalid_argument("capacity cannot be zero");
        }
    }

    bool push(T value) {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_producers_.wait(lock, [this]() {
            return queue_.size() < capacity_;
        });
        
        if (closed_.load()) {
            return false;
        }
        
        queue_.push(std::move(value));
        cv_consumers_.notify_one();
        return true;
    }

    std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_consumers_.wait(lock, [this]() {
            return !queue_.empty() || closed_.load();
        });
        
        if (queue_.empty()) {
            return std::nullopt;
        }
        
        T value = std::move(queue_.front());
        queue_.pop();
        cv_producers_.notify_one();
        return value;
    }

    void close() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (closed_.exchange(true)) {
                return; // idempotent
            }
        }
        cv_producers_.notify_all();
        cv_consumers_.notify_all();
    }

private:
    size_t capacity_;
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable cv_producers_;
    std::condition_variable cv_consumers_;
    std::atomic<bool> closed_;
};

#endif // BOUNDED_QUEUE_HPP
