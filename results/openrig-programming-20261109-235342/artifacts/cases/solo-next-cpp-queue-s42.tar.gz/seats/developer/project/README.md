# BoundedQueue

A C++20 header-only thread-safe bounded queue implementation.

## Features

- **Thread-safe**: Uses mutex and condition variables for synchronization
- **Blocking operations**: `push()` blocks when full, `pop()` blocks when empty
- **Graceful shutdown**: `close()` wakes all waiting threads
- **FIFO ordering**: Elements are returned in the order they were pushed
- **Move-only support**: Works with move-only types
- **Idempotent close**: Calling `close()` multiple times is safe

## Usage

```cpp
#include "solution.hpp"

BoundedQueue<int> queue(10);  // capacity of 10

// Push returns false after close
if (queue.push(42)) {
    // Successfully pushed
}

// Pop blocks while empty
auto value = queue.pop();
if (value.has_value()) {
    // Use value.value()
}

// Close wakes all waiting threads
queue.close();
```

## API

- `explicit BoundedQueue(size_t capacity)` - Constructor, throws `std::invalid_argument` if capacity is zero
- `bool push(T value)` - Pushes a value, blocks if full, returns false after close
- `std::optional<T> pop()` - Pops a value, blocks if empty, returns nullopt after drain
- `void close()` - Closes the queue, wakes all waiting threads, idempotent

## Building and Testing

```bash
clang++ -std=c++20 -pthread test_solution.cpp -o test_solution
./test_solution
```
