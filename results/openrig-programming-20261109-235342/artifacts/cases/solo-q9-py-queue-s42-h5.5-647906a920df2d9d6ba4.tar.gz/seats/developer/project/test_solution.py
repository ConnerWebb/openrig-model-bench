import unittest
import tempfile
import time
import json
from pathlib import Path
from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    
    def setUp(self):
        """Set up a temporary database for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = Path(self.temp_dir) / 'test.db'
        self.queue = JobQueue(str(self.db_path), max_attempts=3)
    
    def tearDown(self):
        """Clean up after each test."""
        self.queue.close()
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_enqueue_unique_key(self):
        """Test that enqueue returns True for unique keys."""
        result = self.queue.enqueue('key1', {'value': 1})
        self.assertTrue(result)
    
    def test_enqueue_duplicate_key(self):
        """Test that enqueue returns False for duplicate keys."""
        self.queue.enqueue('key1', {'value': 1})
        result = self.queue.enqueue('key1', {'value': 2})
        self.assertFalse(result)
    
    def test_enqueue_invalid_key(self):
        """Test that enqueue raises ValueError for empty key."""
        with self.assertRaises(ValueError):
            self.queue.enqueue('', {'value': 1})
    
    def test_claim_returns_job(self):
        """Test that claim returns a job dict."""
        self.queue.enqueue('key1', {'value': 42})
        result = self.queue.claim('worker1', time.time(), 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'key1')
        self.assertEqual(result['payload'], {'value': 42})
        self.assertEqual(result['attempts'], 1)
    
    def test_claim_returns_none_when_no_jobs(self):
        """Test that claim returns None when no jobs available."""
        result = self.queue.claim('worker1', time.time(), 10.0)
        self.assertIsNone(result)
    
    def test_claim_invalid_worker(self):
        """Test that claim raises ValueError for empty worker."""
        with self.assertRaises(ValueError):
            self.queue.claim('', time.time(), 10.0)
    
    def test_claim_invalid_lease(self):
        """Test that claim raises ValueError for invalid lease."""
        with self.assertRaises(ValueError):
            self.queue.claim('worker1', time.time(), 0)
    
    def test_complete_success(self):
        """Test that complete succeeds when worker matches."""
        self.queue.enqueue('key1', {'value': 1})
        self.queue.claim('worker1', time.time(), 10.0)
        result = self.queue.complete('key1', 'worker1')
        self.assertTrue(result)
    
    def test_complete_wrong_worker(self):
        """Test that complete fails when worker doesn't match."""
        self.queue.enqueue('key1', {'value': 1})
        self.queue.claim('worker1', time.time(), 10.0)
        result = self.queue.complete('key1', 'wrong_worker')
        self.assertFalse(result)
    
    def test_complete_done_state(self):
        """Test that complete sets state to done."""
        self.queue.enqueue('key1', {'value': 1})
        self.queue.claim('worker1', time.time(), 10.0)
        self.queue.complete('key1', 'worker1')
        status = self.queue.status('key1')
        self.assertEqual(status['state'], 'done')
    
    def test_fail_success(self):
        """Test that fail succeeds when worker matches."""
        self.queue.enqueue('key1', {'value': 1})
        self.queue.claim('worker1', time.time(), 10.0)
        result = self.queue.fail('key1', 'worker1')
        self.assertTrue(result)
    
    def test_fail_wrong_worker(self):
        """Test that fail fails when worker doesn't match."""
        self.queue.enqueue('key1', {'value': 1})
        self.queue.claim('worker1', time.time(), 10.0)
        result = self.queue.fail('key1', 'wrong_worker')
        self.assertFalse(result)
    
    def test_fail_requeues_job(self):
        """Test that fail requeues the job."""
        self.queue.enqueue('key1', {'value': 1})
        self.queue.claim('worker1', time.time(), 10.0)
        self.queue.fail('key1', 'worker1')
        status = self.queue.status('key1')
        self.assertEqual(status['state'], 'queued')
    
    def test_fail_exhausted_attempts(self):
        """Test that fail marks job as failed when attempts exhausted."""
        # Enqueue and claim multiple times to exhaust attempts
        self.queue.enqueue('key1', {'value': 1})
        for i in range(3):
            self.queue.claim('worker1', time.time(), 10.0)
        
        # Now fail should mark as failed
        result = self.queue.fail('key1', 'worker1')
        self.assertTrue(result)
        status = self.queue.status('key1')
        self.assertEqual(status['state'], 'failed')
    
    def test_status_returns_dict(self):
        """Test that status returns a dict."""
        self.queue.enqueue('key1', {'value': 1})
        status = self.queue.status('key1')
        self.assertIsInstance(status, dict)
        self.assertIn('state', status)
        self.assertIn('attempts', status)
    
    def test_status_returns_none_for_nonexistent(self):
        """Test that status returns None for non-existent key."""
        status = self.queue.status('nonexistent')
        self.assertIsNone(status)
    
    def test_status_invalid_key(self):
        """Test that status raises ValueError for empty key."""
        with self.assertRaises(ValueError):
            self.queue.status('')
    
    def test_complete_after_claim_expires(self):
        """Test that complete works after lease expires."""
        self.queue.enqueue('key1', {'value': 1})
        # Claim with very short lease
        result = self.queue.claim('worker1', time.time(), 0.001)
        self.assertIsNotNone(result)
        
        # Wait for lease to expire
        time.sleep(0.1)
        
        # Now complete should still work (owner check is what matters)
        result = self.queue.complete('key1', 'worker1')
        self.assertTrue(result)
    
    def test_claim_expires_old_jobs(self):
        """Test that claim picks up expired jobs."""
        self.queue.enqueue('key1', {'value': 1})
        # Claim with very short lease
        result = self.queue.claim('worker1', time.time(), 0.001)
        self.assertIsNotNone(result)
        
        # Wait for lease to expire
        time.sleep(0.1)
        
        # Now claim should pick up the expired job
        result = self.queue.claim('worker2', time.time(), 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'key1')
    
    def test_enqueue_payload_types(self):
        """Test that various payload types are stored correctly."""
        self.queue.enqueue('key1', {'nested': {'value': 42}})
        self.queue.enqueue('key2', [1, 2, 3])
        self.queue.enqueue('key3', 'string')
        self.queue.enqueue('key4', 123)
        
        result = self.queue.claim('worker1', time.time(), 10.0)
        self.assertEqual(result['payload'], {'nested': {'value': 42}})
    
    def test_max_attempts_parameter(self):
        """Test that max_attempts parameter works correctly."""
        with tempfile.TemporaryDirectory() as d:
            q = JobQueue(str(Path(d) / 'q.db'), max_attempts=2)
            
            q.enqueue('key1', {'value': 1})
            q.claim('worker1', time.time(), 10.0)
            q.claim('worker1', time.time(), 10.0)
            
            # Third claim should fail or be rejected
            result = q.claim('worker1', time.time(), 10.0)
            self.assertIsNone(result)
            
            q.close()


class TestPublicCases(unittest.TestCase):
    """Test cases from the public cases file."""
    
    def setUp(self):
        """Set up a temporary database for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = Path(self.temp_dir) / 'test.db'
        self.queue = JobQueue(str(self.db_path), max_attempts=3)
    
    def tearDown(self):
        """Clean up after each test."""
        self.queue.close()
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_case_00(self):
        """Test case 00 from public cases."""
        ops = [
            ['enqueue', 'a', {'v': 5304}],
            ['enqueue', 'a', 'ignored'],
            ['claim', 'w', 0, 5],
            ['complete', 'a', 'wrong'],
            ['fail', 'a', 'w'],
            ['claim', 'w2', 1, 5],
            ['complete', 'a', 'w2'],
            ['status', 'a'],
            ['claim', 'w3', 100, 5],
        ]
        
        expected = [
            True,
            False,
            {'key': 'a', 'payload': {'v': 5304}, 'attempts': 1},
            False,
            True,
            {'key': 'a', 'payload': {'v': 5304}, 'attempts': 2},
            True,
            {'state': 'done', 'attempts': 2},
            None,
        ]
        
        for i, op in enumerate(ops):
            if op[0] == 'enqueue':
                key = op[1]
                payload = op[2]
                result = self.queue.enqueue(key, payload)
                self.assertEqual(result, expected[i], f"Op {i}: enqueue failed")
            elif op[0] == 'claim':
                worker = op[1]
                now = op[2]
                lease = op[3]
                result = self.queue.claim(worker, now, lease)
                self.assertEqual(result, expected[i], f"Op {i}: claim failed")
            elif op[0] == 'complete':
                key = op[1]
                worker = op[2]
                result = self.queue.complete(key, worker)
                self.assertEqual(result, expected[i], f"Op {i}: complete failed")
            elif op[0] == 'fail':
                key = op[1]
                worker = op[2]
                result = self.queue.fail(key, worker)
                self.assertEqual(result, expected[i], f"Op {i}: fail failed")
            elif op[0] == 'status':
                key = op[1]
                result = self.queue.status(key)
                self.assertEqual(result, expected[i], f"Op {i}: status failed")
    
    def test_case_01(self):
        """Test case 01 from public cases."""
        ops = [
            ['enqueue', 'a', {'v': 8330}],
            ['enqueue', 'a', 'ignored'],
            ['claim', 'w', 0, 5],
            ['complete', 'a', 'wrong'],
            ['fail', 'a', 'w'],
            ['claim', 'w2', 1, 5],
            ['complete', 'a', 'w2'],
            ['status', 'a'],
            ['claim', 'w3', 100, 5],
        ]
        
        expected = [
            True,
            False,
            {'key': 'a', 'payload': {'v': 8330}, 'attempts': 1},
            False,
            True,
            {'key': 'a', 'payload': {'v': 8330}, 'attempts': 2},
            True,
            {'state': 'done', 'attempts': 2},
            None,
        ]
        
        for i, op in enumerate(ops):
            if op[0] == 'enqueue':
                key = op[1]
                payload = op[2]
                result = self.queue.enqueue(key, payload)
                self.assertEqual(result, expected[i], f"Op {i}: enqueue failed")
            elif op[0] == 'claim':
                worker = op[1]
                now = op[2]
                lease = op[3]
                result = self.queue.claim(worker, now, lease)
                self.assertEqual(result, expected[i], f"Op {i}: claim failed")
            elif op[0] == 'complete':
                key = op[1]
                worker = op[2]
                result = self.queue.complete(key, worker)
                self.assertEqual(result, expected[i], f"Op {i}: complete failed")
            elif op[0] == 'fail':
                key = op[1]
                worker = op[2]
                result = self.queue.fail(key, worker)
                self.assertEqual(result, expected[i], f"Op {i}: fail failed")
            elif op[0] == 'status':
                key = op[1]
                result = self.queue.status(key)
                self.assertEqual(result, expected[i], f"Op {i}: status failed")


if __name__ == '__main__':
    unittest.main()
