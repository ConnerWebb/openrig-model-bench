# JobQueue Implementation

A SQLite-based job queue implementation for managing job lifecycle with atomic operations.

## Features

- **Atomic enqueue/claim operations**: First unique key wins, preventing duplicate job submissions
- **Lease-based claiming**: Jobs are leased to workers with configurable lease duration
- **Automatic expiration**: Expired leases are automatically picked up by other workers
- **Attempt tracking**: Jobs track attempts and can be re-queued on failure
- **Worker validation**: Complete/fail operations require matching worker ownership

## API

### `JobQueue(path, max_attempts=3)`

Initialize a new job queue.

- `path`: Path to the SQLite database file
- `max_attempts`: Maximum number of attempts before a job is considered failed (default: 3)

### `enqueue(key, payload) -> bool`

Enqueue a job with the given key and payload.

- `key`: Unique job key (first unique key wins)
- `payload`: JSON-compatible value to store
- Returns `True` if enqueued, `False` if key already exists

### `claim(worker, now, lease) -> dict or None`

Atomically claim the oldest available job.

- `worker`: Worker identifier
- `now`: Current timestamp
- `lease`: Lease duration in seconds
- Returns `dict` with `{key, payload, attempts}` or `None` if no job available

### `complete(key, worker) -> bool`

Complete a job. Requires matching currently leased owner.

- `key`: Job key
- `worker`: Worker identifier
- Returns `True` if completed successfully, `False` otherwise

### `fail(key, worker) -> bool`

Fail a job. Requires matching currently leased owner.

- `key`: Job key
- `worker`: Worker identifier
- Returns `True` if failed successfully, `False` otherwise
- If attempts < max_attempts, job is re-queued
- If attempts >= max_attempts, job is marked as failed

### `status(key) -> dict or None`

Get the status of a job.

- `key`: Job key
- Returns `dict` with `{state, attempts}` or `None` if job doesn't exist

## State Machine

```
queued -> leased -> done (on complete)
queued -> leased -> queued (on fail, if attempts < max_attempts)
queued -> leased -> failed (on fail, if attempts >= max_attempts)
```

## Thread Safety

The implementation uses SQLite with WAL mode and proper transaction handling to ensure atomic operations across multiple processes.

## Usage Example

```python
from solution import JobQueue
import time

# Create a job queue
queue = JobQueue('jobs.db', max_attempts=3)

# Enqueue a job
queue.enqueue('job1', {'task': 'process_data'})

# Claim the job
result = queue.claim('worker1', time.time(), 30.0)
if result:
    print(f"Claimed job: {result['key']}")
    
    # Do work...
    
    # Complete the job
    queue.complete(result['key'], 'worker1')

# Or fail the job
queue.fail(result['key'], 'worker1')
```

## Testing

Run tests with:
```bash
python3 -m unittest test_solution.py
```

## License

MIT
