import sqlite3
import json
import time
from pathlib import Path


class JobQueue:
    """
    A job queue implementation using SQLite.
    
    Methods:
        enqueue(key, payload) -> bool: First unique key wins, sets state='queued', attempts=0
        claim(worker, now, lease) -> dict or None: Atomically claims oldest job
        complete(key, worker) -> bool: Completes job if leased by worker
        fail(key, worker) -> bool: Fails job if leased by worker
        status(key) -> dict or None: Returns {state, attempts} or None
    """
    
    def __init__(self, db_path: str, max_attempts: int = 3):
        """
        Initialize the job queue.
        
        Args:
            db_path: Path to the SQLite database file
            max_attempts: Maximum number of attempts for a job before it's considered failed
        """
        self.db_path = Path(db_path)
        self.max_attempts = max_attempts
        
        # Ensure the directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Open a connection with WAL mode for better concurrency
        self.conn = sqlite3.connect(str(self.db_path), timeout=30.0)
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('PRAGMA busy_timeout=30000')
        
        # Create the database and tables
        self._init_db()
    
    def _init_db(self):
        """Initialize the database schema."""
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'queued',
                owner TEXT,
                lease_until REAL,
                attempts INTEGER NOT NULL DEFAULT 0,
                done INTEGER NOT NULL DEFAULT 0
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_jobs_lease_until ON jobs(lease_until)')
        self.conn.commit()
    
    def enqueue(self, key: str, payload) -> bool:
        """
        Enqueue a job with the given key and payload.
        
        Args:
            key: Unique job key (first unique key wins)
            payload: JSON-compatible value to store as payload
        
        Returns:
            True if the job was enqueued, False if key already exists
        
        Raises:
            ValueError: If key is empty or max_attempts is invalid
        """
        if not key:
            raise ValueError("key must be non-empty")
        if not isinstance(self.max_attempts, int) or self.max_attempts <= 0:
            raise ValueError("max_attempts must be positive integer")
        
        # Convert payload to JSON string for storage
        payload_json = json.dumps(payload)
        
        cursor = self.conn.cursor()
        
        # Use INSERT OR IGNORE to handle duplicate keys
        cursor.execute('''
            INSERT OR IGNORE INTO jobs (key, payload, state, attempts)
            VALUES (?, ?, 'queued', 0)
        ''', (key, payload_json))
        
        self.conn.commit()
        return cursor.rowcount > 0
    
    def claim(self, worker: str, now: float, lease: float) -> dict:
        """
        Atomically claim the oldest available job.
        
        Args:
            worker: Worker identifier
            now: Current timestamp
            lease: Lease duration in seconds
        
        Returns:
            dict with {key, payload, attempts} or None if no job available
        
        Raises:
            ValueError: If worker is empty, lease <= 0, or max_attempts invalid
        """
        if not worker:
            raise ValueError("worker must be non-empty")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be positive")
        
        cursor = self.conn.cursor()
        
        # Start a transaction
        self.conn.execute('BEGIN')
        
        try:
            # Find jobs that are queued or have expired lease
            cursor.execute('''
                SELECT key, payload, attempts FROM jobs
                WHERE state IN ('queued', 'leased')
                AND (owner IS NULL OR lease_until <= ?)
                ORDER BY attempts ASC, key ASC
                LIMIT 1
            ''', (now,))
            
            row = cursor.fetchone()
            if row is None:
                self.conn.execute('ROLLBACK')
                return None
            
            key, payload_json, attempts = row
            
            # Check if max attempts reached before claiming
            if attempts >= self.max_attempts:
                self.conn.execute('ROLLBACK')
                return None
            
            # Atomically claim the job
            cursor.execute('''
                UPDATE jobs
                SET state = 'leased', owner = ?, lease_until = ?, attempts = attempts + 1
                WHERE key = ?
            ''', (worker, now + lease, key))
            
            if cursor.rowcount == 0:
                # Another process claimed it
                self.conn.execute('ROLLBACK')
                return None
            
            self.conn.commit()
            
            return {
                'key': key,
                'payload': json.loads(payload_json),
                'attempts': attempts + 1
            }
        except Exception:
            self.conn.execute('ROLLBACK')
            raise
    
    def complete(self, key: str, worker: str) -> bool:
        """
        Complete a job. Requires matching currently leased owner.
        
        Args:
            key: Job key
            worker: Worker identifier
        
        Returns:
            True if completed successfully, False otherwise
        
        Raises:
            ValueError: If key or worker is empty
        """
        if not key:
            raise ValueError("key must be non-empty")
        if not worker:
            raise ValueError("worker must be non-empty")
        
        cursor = self.conn.cursor()
        
        # Start a transaction
        self.conn.execute('BEGIN')
        
        try:
            # Check if job is leased by this worker
            cursor.execute('''
                SELECT owner, lease_until FROM jobs WHERE key = ?
            ''', (key,))
            
            row = cursor.fetchone()
            if row is None:
                self.conn.execute('ROLLBACK')
                return False
            
            owner, lease_until = row
            if owner != worker:
                self.conn.execute('ROLLBACK')
                return False
            
            cursor.execute('''
                UPDATE jobs
                SET state = 'done', done = 1
                WHERE key = ?
            ''', (key,))
            
            if cursor.rowcount == 0:
                self.conn.execute('ROLLBACK')
                return False
            
            self.conn.commit()
            return True
        except Exception:
            self.conn.execute('ROLLBACK')
            raise
    
    def fail(self, key: str, worker: str) -> bool:
        """
        Fail a job. Requires matching currently leased owner.
        
        Args:
            key: Job key
            worker: Worker identifier
        
        Returns:
            True if failed successfully, False otherwise
        
        Raises:
            ValueError: If key or worker is empty
        """
        if not key:
            raise ValueError("key must be non-empty")
        if not worker:
            raise ValueError("worker must be non-empty")
        
        cursor = self.conn.cursor()
        
        # Start a transaction
        self.conn.execute('BEGIN')
        
        try:
            # Check if job is leased by this worker
            cursor.execute('''
                SELECT owner, lease_until, attempts FROM jobs WHERE key = ?
            ''', (key,))
            
            row = cursor.fetchone()
            if row is None:
                self.conn.execute('ROLLBACK')
                return False
            
            owner, lease_until, attempts = row
            if owner != worker:
                self.conn.execute('ROLLBACK')
                return False
            
            # If attempts exhausted, mark as failed
            if attempts >= self.max_attempts:
                cursor.execute('''
                    UPDATE jobs
                    SET state = 'failed', done = 1
                    WHERE key = ?
                ''', (key,))
            else:
                # Re-queue the job
                cursor.execute('''
                    UPDATE jobs
                    SET state = 'queued', owner = NULL, lease_until = NULL
                    WHERE key = ?
                ''', (key,))
            
            if cursor.rowcount == 0:
                self.conn.execute('ROLLBACK')
                return False
            
            self.conn.commit()
            return True
        except Exception:
            self.conn.execute('ROLLBACK')
            raise
    
    def status(self, key: str) -> dict:
        """
        Get the status of a job.
        
        Args:
            key: Job key
        
        Returns:
            dict with {state, attempts} or None if job doesn't exist
        
        Raises:
            ValueError: If key is empty
        """
        if not key:
            raise ValueError("key must be non-empty")
        
        cursor = self.conn.cursor()
        
        cursor.execute('''
            SELECT state, attempts FROM jobs WHERE key = ?
        ''', (key,))
        
        row = cursor.fetchone()
        if row is None:
            return None
        
        state, attempts = row
        
        return {
            'state': state,
            'attempts': attempts
        }
    
    def close(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None


if __name__ == '__main__':
    # Test the JobQueue
    import tempfile
    
    with tempfile.TemporaryDirectory() as d:
        q = JobQueue(str(Path(d) / 'q.db'), max_attempts=3)
        
        # Test enqueue
        result = q.enqueue('test', {'value': 42})
        print(f"Enqueue result: {result}")
        
        # Test claim
        result = q.claim('worker1', time.time(), 10.0)
        print(f"Claim result: {result}")
        
        # Test status
        status = q.status('test')
        print(f"Status: {status}")
        
        # Test complete
        result = q.complete('test', 'worker1')
        print(f"Complete result: {result}")
        
        # Test status after complete
        status = q.status('test')
        print(f"Status after complete: {status}")
        
        q.close()
