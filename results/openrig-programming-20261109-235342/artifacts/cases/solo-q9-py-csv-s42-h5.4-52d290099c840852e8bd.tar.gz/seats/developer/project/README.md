# solution.py - CSV Category Aggregator

## Overview
This module provides an `aggregate(path: str) -> dict[str, str]` function that reads a UTF-8 CSV file and aggregates amounts by category.

## Usage
```python
from solution import aggregate

result = aggregate("input.csv")
# Returns: {"category1": "123.45", "category2": "678.90", ...}
```

## Requirements
- Python 3.14+ stdlib only
- Uses `decimal.Decimal` for exact arithmetic

## Input Format
- CSV with header: `category,amount`
- Each row has exactly 2 fields
- Category: non-empty string (whitespace stripped)
- Amount: nonnegative decimal (optional `+`, 1-12 digits, optional decimal point with 1-2 digits)

## Error Handling
- `ValueError` for malformed input (wrong header, wrong field count, empty category, invalid amount)

## Output Format
- Dictionary with category keys sorted alphabetically
- Values are strings formatted with exactly 2 decimal places
