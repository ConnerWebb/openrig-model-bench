"""
Aggregate CSV categories by summing amounts.
"""
import csv
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted, totals formatted with exactly two decimal places.
    """
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        # Strip whitespace from header
        header = [h.strip() for h in header]
        
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: {header}")
        
        # Process each row
        for row in reader:
            # Skip completely blank records
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Check that row has exactly 2 fields
            if len(row) != 2:
                raise ValueError(f"Row has {len(row)} fields, expected 2")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate and parse amount
            amount = _parse_amount(amount_str)
            
            # Accumulate
            totals[category] = totals.get(category, Decimal('0')) + amount
    
    # Format results with exactly 2 decimal places, sorted by key
    result = {}
    for category in sorted(totals.keys()):
        total = totals[category]
        # Format with exactly 2 decimal places
        formatted = f"{total:.2f}"
        result[category] = formatted
    
    return result


def _parse_amount(amount_str: str) -> Decimal:
    """
    Parse amount string. Must be:
    - Optional leading +
    - 1-12 decimal digits
    - Optional decimal point followed by 1 or 2 digits
    - Nonnegative, finite, no exponent
    """
    if not amount_str:
        raise ValueError("Empty amount")
    
    # Check for exponent notation (not allowed)
    if 'e' in amount_str.lower():
        raise ValueError("Exponent notation not allowed")
    
    # Check for NaN, Inf, etc.
    if amount_str.lower() in ('nan', 'inf', '-inf', '+inf', 'infinity', '-infinity'):
        raise ValueError("Invalid amount: NaN/Inf not allowed")
    
    # Strip leading + if present
    if amount_str.startswith('+'):
        amount_str = amount_str[1:]
    
    if not amount_str:
        raise ValueError("Empty amount after stripping +")
    
    # Check for decimal point
    if '.' in amount_str:
        parts = amount_str.split('.')
        if len(parts) != 2:
            raise ValueError("Multiple decimal points")
        integer_part, decimal_part = parts
        if not integer_part:
            raise ValueError("Empty integer part")
        if not decimal_part:
            raise ValueError("Empty decimal part")
        if len(decimal_part) > 2:
            raise ValueError("Decimal part must have 1-2 digits")
    else:
        integer_part = amount_str
        decimal_part = ''
        if not integer_part:
            raise ValueError("Empty integer part")
    
    # Validate integer part: 1-12 digits
    if len(integer_part) > 12:
        raise ValueError("Integer part too long")
    
    # Validate decimal part: 0-2 digits (already checked above)
    
    # Try to parse as Decimal to catch any other issues
    try:
        amount = Decimal(amount_str)
    except InvalidOperation:
        raise ValueError(f"Invalid amount: {amount_str}")
    
    # Check for negative or infinite
    if amount < 0:
        raise ValueError("Amount must be nonnegative")
    if not amount.is_finite():
        raise ValueError("Amount must be finite")
    
    return amount
