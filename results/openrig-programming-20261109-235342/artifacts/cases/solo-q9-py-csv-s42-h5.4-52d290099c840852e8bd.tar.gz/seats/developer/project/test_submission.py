"""
Tests for solution.py aggregate function.
"""
import unittest
import tempfile
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        csv_data = "category,amount\nfood,100.50\nfood,200.25\nrent,500.00\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['food'], '300.75')
                self.assertEqual(result['rent'], '500.00')
            finally:
                os.unlink(f.name)
    
    def test_quoted_category(self):
        """Test quoted category with embedded quotes."""
        csv_data = 'category,amount\n"x""quote",812.68\n"x""quote",71.74\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['x"quote'], '884.42')  # 812.68 + 71.74
            finally:
                os.unlink(f.name)
    
    def test_multiline_category(self):
        """Test category with embedded newlines."""
        csv_data = 'category,amount\n"two\nlines",849.77\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['two\nlines'], '849.77')
            finally:
                os.unlink(f.name)
    
    def test_unicode_category(self):
        """Test unicode category."""
        csv_data = 'category,amount\n日本,690.39\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['日本'], '690.39')
            finally:
                os.unlink(f.name)
    
    def test_comma_in_category(self):
        """Test category with comma."""
        csv_data = 'category,amount\n"a,b",599.14\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['a,b'], '599.14')
            finally:
                os.unlink(f.name)
    
    def test_empty_category_error(self):
        """Test that empty category raises ValueError."""
        csv_data = 'category,amount\n,1\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_wrong_header_error(self):
        """Test that wrong header raises ValueError."""
        csv_data = 'wrong,amount\nx,1\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_too_many_fields_error(self):
        """Test that row with too many fields raises ValueError."""
        csv_data = 'category,amount\nx,1,2\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_nan_amount_error(self):
        """Test that NaN amount raises ValueError."""
        csv_data = 'category,amount\nx,NaN\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_negative_amount_error(self):
        """Test that negative amount raises ValueError."""
        csv_data = 'category,amount\nx,-5.00\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_plus_sign_amount(self):
        """Test amount with leading +."""
        csv_data = 'category,amount\nx,+100.50\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['x'], '100.50')
            finally:
                os.unlink(f.name)
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_data = 'category,amount\n  food  ,  100.50  \n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['food'], '100.50')
            finally:
                os.unlink(f.name)
    
    def test_sorted_output(self):
        """Test that output keys are sorted."""
        csv_data = 'category,amount\nzebra,100.00\napple,200.00\nbanana,300.00\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(list(result.keys()), ['apple', 'banana', 'zebra'])
            finally:
                os.unlink(f.name)
    
    def test_two_decimal_places(self):
        """Test that amounts are formatted with exactly 2 decimal places."""
        csv_data = 'category,amount\nx,100\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['x'], '100.00')
            finally:
                os.unlink(f.name)


if __name__ == '__main__':
    unittest.main()
