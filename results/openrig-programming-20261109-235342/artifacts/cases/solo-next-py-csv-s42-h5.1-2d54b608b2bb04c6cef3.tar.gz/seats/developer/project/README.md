# CSV Aggregate Solution

Implements `aggregate(path: str) -> dict[str, str]` that reads a UTF-8 CSV file and returns category totals.

## Requirements

- Header must be exactly `category,amount`
- Blank lines are ignored
- Each non-blank row must have exactly two fields
- Category must not be empty after stripping whitespace
- Amount format: optional `+`, 1–12 digits, optional decimal point with 1–2 digits
- No negative, NaN, infinity, or exponent values
- Uses exact decimal arithmetic via `decimal.Decimal`
- Returns sorted keys with totals formatted to exactly two decimal places

## Usage

```python
from solution import aggregate
result = aggregate("data.csv")
# result: {"category1": "123.45", ...}
```

## Tests

Run `python test_solution.py` to execute unit tests.
