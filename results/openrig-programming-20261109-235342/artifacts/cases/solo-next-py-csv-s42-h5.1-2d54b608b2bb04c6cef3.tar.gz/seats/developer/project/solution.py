import csv
from decimal import Decimal, InvalidOperation
import os


def aggregate(path: str) -> dict[str, str]:
    totals: dict[str, Decimal] = {}
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("Empty file")
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        has_data = False
        for row in reader:
            if row is None:
                continue
            if len(row) == 0:
                continue
            if len(row) == 1 and row[0].strip() == '':
                continue
            has_data = True
            if len(row) != 2:
                raise ValueError("Invalid row field count")
            category = row[0].strip()
            amount_str = row[1].strip()
            if not category:
                raise ValueError("Empty category")
            if not amount_str:
                raise ValueError("Empty amount")
            if not _is_valid_amount(amount_str):
                raise ValueError("Invalid amount format")
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError("Invalid amount")
            if amount.is_nan() or amount.is_infinite():
                raise ValueError("Invalid amount")
            if amount < 0:
                raise ValueError("Negative amount")
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
        if not has_data:
            raise ValueError("No data rows")
    result: dict[str, str] = {}
    for cat in sorted(totals.keys()):
        val = totals[cat]
        result[cat] = f"{val:.2f}"
    return result


def _is_valid_amount(s: str) -> bool:
    if not s:
        return False
    s = s.strip()
    if not s:
        return False
    if s[0] == '+':
        s = s[1:]
    if not s:
        return False
    if '.' in s:
        parts = s.split('.')
        if len(parts) != 2:
            return False
        int_part, frac_part = parts
        if not int_part:
            return False
        if not frac_part:
            return False
        if len(frac_part) > 2:
            return False
        if not int_part.isdigit() or not frac_part.isdigit():
            return False
        if len(int_part) > 12:
            return False
    else:
        if not s.isdigit():
            return False
        if len(s) > 12:
            return False
    return True
