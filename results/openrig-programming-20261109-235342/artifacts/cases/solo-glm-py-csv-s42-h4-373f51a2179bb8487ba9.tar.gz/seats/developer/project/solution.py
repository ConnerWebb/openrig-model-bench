#!/usr/bin/env python3
"""
CSV aggregator with exact decimal arithmetic.

aggregate(path: str) -> dict[str, str]
- Reads UTF-8 CSV as a stream.
- Header must be exactly: category,amount
- Ignores completely blank records.
- Every other record must have exactly two fields.
- Strips whitespace from category and amount.
- Category must not be empty.
- Amount format: optional '+', 1–12 decimal digits, optional '.' followed by 1 or 2 digits.
- Nonnegative, finite, no exponent.
- Rejects malformed input with ValueError.
- Accumulates using exact decimal arithmetic.
- Returns category keys sorted, totals formatted with exactly two decimal places.
- CSV quoted commas and embedded newlines are valid.
"""

from __future__ import annotations

import csv
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterator, Tuple


# Decimal arithmetic using Python's built-in decimal module for exactness.
from decimal import Decimal, InvalidOperation, getcontext, ROUND_HALF_UP


# Precompile regex for amount validation.
# Optional leading '+', then 1-12 digits, optional '.' followed by 1-2 digits.
_AMOUNT_RE = re.compile(r"""
    ^
    [+]?
    (?: \d{1,12} )
    (?: \. \d{1,2} )?
    $
""", re.VERBOSE)


def _validate_amount(amount_str: str) -> Decimal:
    """Validate and convert amount string to Decimal.

    Args:
        amount_str: The raw amount string.

    Returns:
        The Decimal value.

    Raises:
        ValueError: If the amount is malformed or invalid.
    """
    if not _AMOUNT_RE.fullmatch(amount_str):
        raise ValueError(f"Invalid amount: {amount_str!r}")

    try:
        return Decimal(amount_str)
    except InvalidOperation as exc:
        raise ValueError(f"Invalid amount: {amount_str!r}") from exc


def _parse_row(row: Tuple[str, str]) -> Tuple[str, Decimal]:
    """Parse a CSV row into (category, amount).

    Args:
        row: A tuple of two strings from CSV reader.

    Returns:
        A tuple of (category, amount).

    Raises:
        ValueError: If the row is malformed or category is empty.
    """
    if len(row) != 2:
        raise ValueError(f"Expected exactly two fields, got {len(row)}")

    category, amount_str = row
    category = category.strip()
    amount_str = amount_str.strip()

    if not category:
        raise ValueError("Category must not be empty")

    amount = _validate_amount(amount_str)
    return category, amount


def _read_csv_stream(path: str) -> Iterator[Tuple[str, str]]:
    """Read CSV file as a stream, yielding rows.

    Args:
        path: Path to the CSV file.

    Yields:
        Tuples of (category, amount) strings.
    """
    with Path(path).open("r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            # Skip completely blank rows.
            if not row or all(cell.strip() == "" for cell in row):
                continue
            yield row


def aggregate(path: str) -> Dict[str, str]:
    """Aggregate amounts by category from a CSV file.

    Args:
        path: Path to the CSV file.

    Returns:
        A dictionary mapping category names to total amounts as strings with exactly two decimal places.

    Raises:
        ValueError: If the CSV header is malformed or any record is malformed.
    """
    totals: defaultdict[str, Decimal] = defaultdict(Decimal)

    # Read header to validate it.
    with Path(path).open("r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("CSV file is empty")

        if header != ["category", "amount"]:
            raise ValueError(f"Invalid header: {header}")

    # Stream through the rest of the file.
    for row in _read_csv_stream(path):
        category, amount = _parse_row(row)
        totals[category] += amount

    # Format totals with exactly two decimal places.
    result: Dict[str, str] = {
        category: f"{total:.2f}"
        for category, total in sorted(totals.items())
    }

    return result


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <csv_path>", file=sys.stderr)
        sys.exit(1)

    result = aggregate(sys.argv[1])
    import json
    print(json.dumps(result, indent=2))