#!/usr/bin/env python3
"""
Test suite for solution.py aggregate().

Uses unittest framework. Tests cover:
- Valid CSV parsing and aggregation
- Malformed input rejection
- Exact decimal arithmetic
- Quoted fields with commas and newlines
"""

from __future__ import annotations

import csv
import json
import os
import re
import sys
import tempfile
import unittest
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from typing import Dict, Iterator, Tuple

# Import the solution under test.
import solution


# Regex for amount validation (copied from solution for testing).
_AMOUNT_RE = re.compile(r"""
    ^
    [+]?
    (?: \d{1,12} )
    (?: \. \d{1,2} )?
    $
""", re.VERBOSE)


def _validate_amount(amount_str: str) -> Decimal:
    """Validate and convert amount string to Decimal."""
    if not _AMOUNT_RE.fullmatch(amount_str):
        raise ValueError(f"Invalid amount: {amount_str!r}")

    try:
        return Decimal(amount_str)
    except Exception as exc:
        raise ValueError(f"Invalid amount: {amount_str!r}") from exc


def _parse_row(row: Tuple[str, str]) -> Tuple[str, Decimal]:
    """Parse a CSV row into (category, amount)."""
    if len(row) != 2:
        raise ValueError(f"Expected exactly two fields, got {len(row)}")

    category, amount_str = row
    category = category.strip()
    amount_str = amount_str.strip()

    if not category:
        raise ValueError("Category must not be empty")

    amount = _validate_amount(amount_str)
    return category, amount


def _read_csv_stream(path: str) -> Iterator[Tuple[str, str]]:
    """Read CSV file as a stream, yielding rows."""
    with Path(path).open("r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or all(cell.strip() == "" for cell in row):
                continue
            yield row


def _aggregate(path: str) -> Dict[str, str]:
    """Aggregate amounts by category from a CSV file."""
    totals: defaultdict[str, Decimal] = defaultdict(Decimal)

    with Path(path).open("r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("CSV file is empty")

        if header != ["category", "amount"]:
            raise ValueError(f"Invalid header: {header}")

    for row in _read_csv_stream(path):
        category, amount = _parse_row(row)
        totals[category] += amount

    result: Dict[str, str] = {
        category: f"{total:.2f}"
        for category, total in sorted(totals.items())
    }

    return result


class TestAggregate(unittest.TestCase):
    """Test suite for aggregate() function."""

    def setUp(self):
        """Create a temporary directory for test CSV files."""
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary directory."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _write_csv(self, csv_content: str) -> str:
        """Write CSV content to a temporary file and return its path."""
        path = os.path.join(self.temp_dir, "test.csv")
        with Path(path).open("w", encoding="utf-8") as f:
            # Remove any trailing blank lines to avoid "amount" being parsed as a field
            lines = [line.rstrip() for line in csv_content.rstrip().splitlines()]
            f.write("\n".join(lines))
        return path

    def test_valid_csv_basic(self):
        """Test basic valid CSV with simple categories."""
        csv_content = """category,amount
food,10.50
rent,20.75
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"food": "10.50", "rent": "20.75"}
        self.assertEqual(result, expected)

    def test_valid_csv_multiple_entries(self):
        """Test CSV with multiple entries for same category."""
        csv_content = """category,amount
food,10.50
food,20.75
rent,30.00
rent,40.00
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"food": "31.25", "rent": "70.00"}
        self.assertEqual(result, expected)

    def test_valid_csv_decimal_places(self):
        """Test that amounts are formatted with exactly two decimal places."""
        csv_content = """category,amount
food,10.5
rent,20.75
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "10.50")
        self.assertEqual(result["rent"], "20.75")

    def test_valid_csv_whitespace(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = """category,amount
  food  ,  10.50  ,
rent,20.75
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"food": "10.50", "rent": "20.75"}
        self.assertEqual(result, expected)

    def test_valid_csv_empty_category_rejected(self):
        """Test that empty category after stripping is rejected."""
        csv_content = """category,amount
,10.50
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_invalid_amount_rejected(self):
        """Test that invalid amount format is rejected."""
        csv_content = """category,amount
food,abc
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_negative_amount_rejected(self):
        """Test that negative amount is rejected."""
        csv_content = """category,amount
food,-10.50
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_exponent_rejected(self):
        """Test that amount with exponent is rejected."""
        csv_content = """category,amount
food,1e2
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_too_many_digits(self):
        """Test that amount with more than 12 digits is rejected."""
        csv_content = """category,amount
food,1234567890123.45
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_no_decimal_part(self):
        """Test amount without decimal part."""
        csv_content = """category,amount
food,10
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "10.00")

    def test_valid_csv_one_decimal_digit(self):
        """Test amount with one decimal digit."""
        csv_content = """category,amount
food,10.5
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "10.50")

    def test_valid_csv_two_decimal_digits(self):
        """Test amount with two decimal digits."""
        csv_content = """category,amount
food,10.50
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "10.50")

    def test_valid_csv_leading_plus(self):
        """Test amount with leading '+'."""
        csv_content = """category,amount
food,+10.50
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "10.50")

    def test_valid_csv_header_mismatch(self):
        """Test that header mismatch raises ValueError."""
        csv_content = """category,amount
food,10.50
"""
        csv_path = self._write_csv(csv_content)
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write("wrong,amount\nfood,10.50\n")
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_empty_file(self):
        """Test that empty file raises ValueError."""
        csv_path = self._write_csv("")
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_blank_lines_ignored(self):
        """Test that completely blank lines are ignored."""
        csv_content = """category,amount

food,10.50

rent,20.75

"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"food": "10.50", "rent": "20.75"}
        self.assertEqual(result, expected)

    def test_valid_csv_unicode_category(self):
        """Test CSV with Unicode category names."""
        csv_content = """category,amount
日本,100.00
food,50.00
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"food": "50.00", "日本": "100.00"}
        self.assertEqual(result, expected)

    def test_valid_csv_quoted_comma(self):
        """Test CSV with quoted commas in category."""
        csv_content = """category,amount
"a,b",10.50
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"a,b": "10.50"}
        self.assertEqual(result, expected)

    def test_valid_csv_embedded_newline(self):
        """Test CSV with embedded newlines in category."""
        csv_content = """category,amount
"two
lines",10.50
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"two\nlines": "10.50"}
        self.assertEqual(result, expected)

    def test_valid_csv_mixed_quotes(self):
        """Test CSV with mixed quoted and unquoted fields."""
        csv_content = """category,amount
"x\"quote",10.50
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"x\"quote": "10.50"}
        self.assertEqual(result, expected)

    def test_valid_csv_wrong_header(self):
        """Test that wrong header raises ValueError."""
        csv_content = """wrong,amount
food,10.50
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_wrong_field_count(self):
        """Test that wrong field count raises ValueError."""
        csv_content = """category,amount
food,10.50,extra
"""
        csv_path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(csv_path)

    def test_valid_csv_exact_decimal_arithmetic(self):
        """Test that exact decimal arithmetic is used."""
        csv_content = """category,amount
food,0.01
food,0.02
food,0.03
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        expected = {"food": "0.06"}
        self.assertEqual(result, expected)

    def test_valid_csv_sorted_keys(self):
        """Test that result keys are sorted."""
        csv_content = """category,amount
z,10.00
a,20.00
m,30.00
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        keys = list(result.keys())
        self.assertEqual(keys, ["a", "m", "z"])

    def test_valid_csv_large_amount(self):
        """Test with large amount values."""
        csv_content = """category,amount
food,999999999999.99
rent,888888888888.88
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "999999999999.99")
        self.assertEqual(result["rent"], "888888888888.88")

    def test_valid_csv_small_amount(self):
        """Test with small amount values."""
        csv_content = """category,amount
food,0.01
rent,0.02
"""
        csv_path = self._write_csv(csv_content)
        result = solution.aggregate(csv_path)
        self.assertEqual(result["food"], "0.01")
        self.assertEqual(result["rent"], "0.02")


if __name__ == "__main__":
    unittest.main(verbosity=2)