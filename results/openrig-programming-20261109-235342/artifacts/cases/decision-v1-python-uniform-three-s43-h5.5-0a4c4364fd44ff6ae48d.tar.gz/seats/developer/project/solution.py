import sqlite3
import json
from typing import Optional, Dict, Any

class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        
        self.path = path
        self.max_attempts = max_attempts
        
        conn = sqlite3.connect(path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT NOT NULL DEFAULT 'queued',
                attempts INTEGER NOT NULL DEFAULT 0,
                owner TEXT,
                lease_until REAL,
                inserted_at REAL NOT NULL DEFAULT (julianday('now'))
            )
        ''')
        conn.commit()
        conn.close()
    
    def enqueue(self, key: str, payload: Any) -> bool:
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # First unique key wins - check if key exists
        cursor.execute('SELECT key FROM jobs WHERE key = ?', (key,))
        if cursor.fetchone() is not None:
            conn.close()
            return False
        
        # Insert new job
        cursor.execute('''
            INSERT INTO jobs (key, payload, state, attempts)
            VALUES (?, ?, 'queued', 0)
        ''', (key, json.dumps(payload)))
        
        conn.commit()
        conn.close()
        return True
    
    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check for expired final-attempt jobs and mark them as failed
        cursor.execute('''
            UPDATE jobs
            SET state = 'failed'
            WHERE state = 'leased'
              AND lease_until <= ?
              AND attempts >= ?
        ''', (now, self.max_attempts))
        
        # Use a single atomic UPDATE to claim the oldest eligible job
        # This prevents race conditions between multiple processes
        cursor.execute('''
            UPDATE jobs
            SET state = 'leased',
                owner = ?,
                lease_until = ?,
                attempts = attempts + 1
            WHERE key = (
                SELECT key FROM jobs
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                  AND attempts < ?
                ORDER BY inserted_at ASC
                LIMIT 1
            )
            RETURNING key, payload, attempts
        ''', (worker, now + lease, now, self.max_attempts))
        
        row = cursor.fetchone()
        if row is None:
            conn.commit()
            conn.close()
            return None
        
        key, payload_json, attempts = row
        conn.commit()
        conn.close()
        
        return {
            'key': key,
            'payload': json.loads(payload_json),
            'attempts': attempts
        }
    
    def complete(self, key: str, worker: str) -> bool:
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check if job exists and is leased to this worker
        cursor.execute('''
            SELECT state, owner
            FROM jobs
            WHERE key = ?
        ''', (key,))
        
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return False
        
        state, owner = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # Mark as done
        cursor.execute('''
            UPDATE jobs
            SET state = 'done'
            WHERE key = ?
        ''', (key,))
        
        conn.commit()
        conn.close()
        return True
    
    def fail(self, key: str, worker: str) -> bool:
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check if job exists and is leased to this worker
        cursor.execute('''
            SELECT state, owner, attempts
            FROM jobs
            WHERE key = ?
        ''', (key,))
        
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return False
        
        state, owner, attempts = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # If attempts exhausted, mark as failed; otherwise requeue
        if attempts >= self.max_attempts:
            cursor.execute('''
                UPDATE jobs
                SET state = 'failed'
                WHERE key = ?
            ''', (key,))
        else:
            cursor.execute('''
                UPDATE jobs
                SET state = 'queued',
                    owner = NULL,
                    lease_until = NULL
                WHERE key = ?
            ''', (key,))
        
        conn.commit()
        conn.close()
        return True
    
    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT state, attempts
            FROM jobs
            WHERE key = ?
        ''', (key,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row is None:
            return None
        
        state, attempts = row
        return {
            'state': state,
            'attempts': attempts
        }
