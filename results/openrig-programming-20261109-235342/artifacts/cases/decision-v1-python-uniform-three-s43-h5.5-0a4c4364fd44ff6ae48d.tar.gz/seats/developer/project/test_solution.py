import unittest
import tempfile
import os
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')
        self.q = JobQueue(self.db_path)
    
    def tearDown(self):
        os.unlink(self.db_path)
    
    def test_enqueue_first_wins(self):
        self.assertTrue(self.q.enqueue('key1', {'data': 1}))
        self.assertFalse(self.q.enqueue('key1', {'data': 2}))
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)
    
    def test_enqueue_validation(self):
        with self.assertRaises(ValueError):
            self.q.enqueue('', 'payload')
        with self.assertRaises(ValueError):
            self.q.enqueue(None, 'payload')
    
    def test_claim_basic(self):
        self.q.enqueue('key1', {'v': 5304})
        result = self.q.claim('worker1', 0, 5)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'key1')
        self.assertEqual(result['payload'], {'v': 5304})
        self.assertEqual(result['attempts'], 1)
        
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'leased')
        self.assertEqual(status['attempts'], 1)
    
    def test_claim_no_eligible_jobs(self):
        result = self.q.claim('worker1', 0, 5)
        self.assertIsNone(result)
    
    def test_claim_expired_lease_final_attempt(self):
        self.q.enqueue('key1', {'v': 1})
        # Claim it 3 times (max_attempts=3)
        self.q.claim('w1', 0, 5)
        self.q.fail('key1', 'w1')
        self.q.claim('w2', 1, 5)
        self.q.fail('key1', 'w2')
        self.q.claim('w3', 2, 5)
        # Now attempts=3, lease expires
        result = self.q.claim('w4', 100, 5)  # now=100, lease_until was 7
        self.assertIsNone(result)  # No eligible jobs
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'failed')
    
    def test_claim_oldest_first(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.enqueue('key2', {'v': 2})
        result = self.q.claim('w', 0, 5)
        self.assertEqual(result['key'], 'key1')
    
    def test_claim_requeues_after_fail(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.q.fail('key1', 'w1')
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 1)
    
    def test_complete_success(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.assertTrue(self.q.complete('key1', 'w1'))
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'done')
    
    def test_complete_wrong_worker(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.assertFalse(self.q.complete('key1', 'w2'))
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'leased')
    
    def test_complete_not_leased(self):
        self.q.enqueue('key1', {'v': 1})
        self.assertFalse(self.q.complete('key1', 'w1'))
    
    def test_fail_success(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.assertTrue(self.q.fail('key1', 'w1'))
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'queued')
    
    def test_fail_wrong_worker(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.assertFalse(self.q.fail('key1', 'w2'))
    
    def test_fail_exhausted_attempts(self):
        # max_attempts=3
        self.q = JobQueue(self.db_path, max_attempts=3)
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.q.fail('key1', 'w1')
        self.q.claim('w2', 1, 5)
        self.q.fail('key1', 'w2')
        self.q.claim('w3', 2, 5)
        # Now attempts=3, fail should mark as failed
        self.assertTrue(self.q.fail('key1', 'w3'))
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'failed')
    
    def test_status_nonexistent(self):
        self.assertIsNone(self.q.status('nonexistent'))
    
    def test_status_after_complete(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)
        self.q.complete('key1', 'w1')
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'done')
        self.assertEqual(status['attempts'], 1)
    
    def test_claim_expired_lease_reclaims(self):
        self.q.enqueue('key1', {'v': 1})
        self.q.claim('w1', 0, 5)  # lease_until=5
        # Now at time 10, lease expired but attempts < max_attempts
        result = self.q.claim('w2', 10, 5)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'key1')
        self.assertEqual(result['attempts'], 2)
    
    def test_validation_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)
    
    def test_validation_lease(self):
        self.q.enqueue('key1', {'v': 1})
        with self.assertRaises(ValueError):
            self.q.claim('w', 0, 0)
        with self.assertRaises(ValueError):
            self.q.claim('w', 0, -1)
    
    def test_validation_worker(self):
        self.q.enqueue('key1', {'v': 1})
        with self.assertRaises(ValueError):
            self.q.claim('', 0, 5)
    
    def test_validation_complete_worker(self):
        self.q.enqueue('key1', {'v': 1})
        with self.assertRaises(ValueError):
            self.q.complete('key1', '')
    
    def test_validation_fail_worker(self):
        self.q.enqueue('key1', {'v': 1})
        with self.assertRaises(ValueError):
            self.q.fail('key1', '')

if __name__ == '__main__':
    unittest.main()
