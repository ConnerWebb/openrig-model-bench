# JobQueue

A SQLite-based job queue implementation for distributed task processing with lease management and retry logic.

## Overview

`JobQueue` provides a thread-safe, process-safe job queue using SQLite as the backend. It supports:
- Atomic job claiming with lease expiration
- Automatic retry on failure (up to max_attempts)
- Concurrent access from multiple processes
- Job state tracking (queued, leased, done, failed)

## Constructor

```python
JobQueue(path: str, max_attempts: int = 3)
```

**Parameters:**
- `path`: Path to the SQLite database file
- `max_attempts`: Maximum number of claim attempts before a job is marked as failed (default: 3)

**Raises:** `ValueError` if `max_attempts` is not a positive integer.

## Methods

### enqueue(key, payload) -> bool

Enqueue a new job. First unique key wins.

**Parameters:**
- `key`: Unique string identifier for the job
- `payload`: JSON-compatible value containing job data

**Returns:** `True` if job was enqueued, `False` if key already exists.

**Raises:** `ValueError` if key is empty or not a string.

**State after enqueue:** `queued`, `attempts=0`

### claim(worker, now, lease) -> dict or None

Atomically claim the oldest eligible job.

**Parameters:**
- `worker`: String identifier of the worker claiming the job
- `now`: Current timestamp (float)
- `lease`: Lease duration in seconds (must be positive)

**Returns:** Dictionary with `key`, `payload`, and `attempts` if a job was claimed, `None` if no eligible jobs.

**Eligible jobs:** Jobs in `queued` state, or `leased` state with `lease_until <= now` and `attempts < max_attempts`.

**Raises:** `ValueError` if worker is empty, lease is not positive, or lease is not a number.

**State after claim:** `leased`, `attempts` incremented, `owner` set to worker, `lease_until` set to `now + lease`.

### complete(key, worker) -> bool

Mark a leased job as complete.

**Parameters:**
- `key`: Job key
- `worker`: Worker that must own the lease

**Returns:** `True` if job was completed, `False` if job doesn't exist or is not leased to this worker.

**Raises:** `ValueError` if key or worker is empty.

**State after complete:** `done`

### fail(key, worker) -> bool

Mark a leased job as failed (requeue or mark as permanently failed).

**Parameters:**
- `key`: Job key
- `worker`: Worker that must own the lease

**Returns:** `True` if job was processed, `False` if job doesn't exist or is not leased to this worker.

**Raises:** `ValueError` if key or worker is empty.

**Behavior:**
- If `attempts < max_attempts`: Job is requeued (`state=queued`, lease cleared)
- If `attempts >= max_attempts`: Job is permanently failed (`state=failed`)

### status(key) -> dict or None

Get the current status of a job.

**Parameters:**
- `key`: Job key

**Returns:** Dictionary with `state` and `attempts`, or `None` if job doesn't exist.

**Raises:** `ValueError` if key is empty.

## Job States

- `queued`: Job is available for claiming
- `leased`: Job is being processed by a worker
- `done`: Job completed successfully
- `failed`: Job exhausted all attempts

## Concurrency

Multiple instances/processes can safely share the same database. The implementation uses SQLite's atomic operations to prevent lost or duplicate claims.

## Example

```python
from solution import JobQueue

q = JobQueue('/tmp/jobs.db', max_attempts=3)

# Enqueue a job
q.enqueue('task-1', {'command': 'process', 'data': [1, 2, 3]})

# Claim a job
result = q.claim('worker-1', now=100.0, lease=30.0)
if result:
    print(f"Claimed job {result['key']}")
    # Process the job...
    q.complete(result['key'], 'worker-1')

# Check status
status = q.status('task-1')
print(f"State: {status['state']}, Attempts: {status['attempts']}")
```
