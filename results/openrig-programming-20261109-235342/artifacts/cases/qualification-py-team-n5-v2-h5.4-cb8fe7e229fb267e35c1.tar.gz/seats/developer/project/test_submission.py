import unittest
import copy
import validation


class TestNormalize(unittest.TestCase):
    def test_basic_normalization(self):
        x = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        result = validation.normalize(x)
        self.assertEqual(result, [{'id': 'a', 'category': 'b', 'cents': 2}])
        # Ensure input is unchanged
        self.assertEqual(x[0]['id'], ' a ')

    def test_empty_input(self):
        self.assertEqual(validation.normalize([]), [])

    def test_multiple_records_preserves_order_and_duplicates(self):
        records = [
            {'id': '1', 'category': 'x', 'cents': 10},
            {'id': '1', 'category': 'y', 'cents': 20},
            {'id': '2', 'category': 'x', 'cents': 5}
        ]
        result = validation.normalize(records)
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['id'], '1')
        self.assertEqual(result[1]['id'], '1')
        self.assertEqual(result[2]['id'], '2')

    def test_whitespace_stripping(self):
        records = [{'id': '  abc  ', 'category': '\tdef\n', 'cents': 0}]
        result = validation.normalize(records)
        self.assertEqual(result[0]['id'], 'abc')
        self.assertEqual(result[0]['category'], 'def')

    def test_cents_zero_allowed(self):
        records = [{'id': 'a', 'category': 'b', 'cents': 0}]
        self.assertEqual(validation.normalize(records), records)

    def test_negative_cents_raises(self):
        records = [{'id': 'a', 'category': 'b', 'cents': -1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_boolean_cents_raises(self):
        records = [{'id': 'a', 'category': 'b', 'cents': True}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_missing_key_raises(self):
        records = [{'id': 'a', 'category': 'b'}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_extra_key_raises(self):
        records = [{'id': 'a', 'category': 'b', 'cents': 1, 'extra': 0}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_non_string_id_raises(self):
        records = [{'id': 1, 'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_empty_string_id_raises(self):
        records = [{'id': '', 'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_whitespace_only_id_raises(self):
        records = [{'id': '   ', 'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_non_string_category_raises(self):
        records = [{'id': 'a', 'category': 1, 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_empty_string_category_raises(self):
        records = [{'id': 'a', 'category': '', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_non_int_cents_raises(self):
        records = [{'id': 'a', 'category': 'b', 'cents': 1.5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_input_immutability(self):
        records = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        original = copy.deepcopy(records)
        validation.normalize(records)
        self.assertEqual(records, original)


if __name__ == '__main__':
    unittest.main()
