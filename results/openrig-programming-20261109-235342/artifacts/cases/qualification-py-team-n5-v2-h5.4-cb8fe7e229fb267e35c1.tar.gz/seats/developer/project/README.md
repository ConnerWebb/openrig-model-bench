# Team Validation Module

## Overview
This project provides a single validation module (`validation.py`) that normalizes and validates records per the team contract.

## Module: `validation`

### Function: `normalize(records)`

Validates and normalizes a list of records.

**Contract:**
- Input: `records` must be a list of dictionaries.
- Each record must contain exactly the keys: `'id'`, `'category'`, `'cents'`.
- `'id'` and `'category'` must be nonempty strings after stripping whitespace.
- `'cents'` must be a nonnegative integer. Booleans are explicitly rejected.
- Returns a new list of dictionaries with stripped strings and unchanged cents.
- Input is never mutated.
- Raises `ValueError` on any invalid record.

**Implementation notes:**
- Booleans are rejected for `'cents'` even though `bool` is a subclass of `int` in Python.
- All validation is performed per-record; first invalid record raises immediately.
- Duplicates and order are preserved.

## Architecture

The project uses a three-module architecture:

1. **validation** (`validation.py`): Record normalization and validation.
2. **storage** (`storage.py`): Deduplication by id, preserving first occurrence.
3. **ledger** (`ledger.py`): Composes validation and deduplication, applies minimum_cents filter, returns sorted totals.

Only `validation.py` is in scope for this assignment. `storage.py` and `ledger.py` are read-only integration context.

## Testing

Run `python test_submission.py` to execute the built-in unit tests.
