import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import validation as solution
 import copy
 original=copy.deepcopy(x['records']);v=solution.normalize(x['records']);print(json.dumps({'value':v,'input_unchanged':x['records']==original}))

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
