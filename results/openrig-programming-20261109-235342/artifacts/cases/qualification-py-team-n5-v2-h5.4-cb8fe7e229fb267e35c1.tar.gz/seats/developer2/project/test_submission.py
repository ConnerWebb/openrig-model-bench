import unittest
import copy
import json
import os
import sys

sys.path.insert(0, '/work')
import validation
import storage
import ledger


class TestValidation(unittest.TestCase):
    def test_normalize_basic(self):
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])

    def test_normalize_empty(self):
        self.assertEqual(validation.normalize([]), [])

    def test_normalize_rejects_missing_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a'}])
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'cents': 1}])
        with self.assertRaises(ValueError):
            validation.normalize([{'category': 'a', 'cents': 1}])

    def test_normalize_rejects_extra_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}])

    def test_normalize_rejects_empty_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '', 'category': 'a', 'cents': 1}])
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '   ', 'category': 'a', 'cents': 1}])

    def test_normalize_rejects_empty_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '', 'cents': 1}])
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '   ', 'cents': 1}])

    def test_normalize_rejects_negative_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': -1}])

    def test_normalize_rejects_boolean_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': True}])
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': False}])

    def test_normalize_rejects_float_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': 1.5}])

    def test_normalize_rejects_non_dict(self):
        with self.assertRaises(ValueError):
            validation.normalize(['not a dict'])
        with self.assertRaises(ValueError):
            validation.normalize([None])

    def test_normalize_preserves_input_unchanged(self):
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = copy.deepcopy(records)
        validation.normalize(records)
        self.assertEqual(records, original)


class TestStorage(unittest.TestCase):
    def test_deduplicate_basic(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}, {'id': 'a', 'category': 'y', 'cents': 2}]
        result = storage.deduplicate(records)
        self.assertEqual(result, [{'id': 'a', 'category': 'x', 'cents': 1}])

    def test_deduplicate_empty(self):
        self.assertEqual(storage.deduplicate([]), [])

    def test_deduplicate_first_wins(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'a', 'category': 'z', 'cents': 3}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result[0]['category'], 'x')

    def test_deduplicate_returns_fresh_copies(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = storage.deduplicate(records)
        result[0]['category'] = 'y'
        self.assertEqual(records[0]['category'], 'x')

    def test_deduplicate_preserves_order(self):
        records = [
            {'id': 'b', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'c', 'category': 'z', 'cents': 3}
        ]
        result = storage.deduplicate(records)
        self.assertEqual([r['id'] for r in result], ['b', 'a', 'c'])


class TestLedger(unittest.TestCase):
    def test_process_basic(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 5}]
        result = ledger.process(records)
        self.assertEqual(result, {'events': [{'id': 'x', 'category': 'a', 'cents': 5}], 'totals': {'a': 5}})

    def test_process_empty(self):
        self.assertEqual(ledger.process([]), {'events': [], 'totals': {}})

    def test_process_deduplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'x')

    def test_process_sorts_totals(self):
        records = [
            {'id': 'a', 'category': 'c', 'cents': 1},
            {'id': 'b', 'category': 'a', 'cents': 2},
            {'id': 'c', 'category': 'b', 'cents': 3}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_process_minimum_cents(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'x', 'cents': 10}
        ]
        result = ledger.process(records, minimum_cents=7)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'b')

    def test_process_rejects_boolean_minimum_cents(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=False)

    def test_process_rejects_negative_minimum_cents(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_process_rejects_float_minimum_cents(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=1.5)

    def test_process_input_unchanged(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 5}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_process_composes_validation_and_storage(self):
        records = [
            {'id': ' x ', 'category': ' a ', 'cents': 5},
            {'id': ' x ', 'category': ' b ', 'cents': 10}
        ]
        result = ledger.process(records)
        self.assertEqual(result['events'][0]['id'], 'x')
        self.assertEqual(result['events'][0]['category'], 'a')


class TestPublicCases(unittest.TestCase):
    def test_public_cases(self):
        public_dir = '/work/public-inputs'
        for fname in sorted(os.listdir(public_dir)):
            if not fname.endswith('.json'):
                continue
            path = os.path.join(public_dir, fname)
            with open(path) as f:
                case = json.load(f)
            records = case['records']
            if 'minimum' in case:
                minimum = case['minimum']
            else:
                minimum = 0
            try:
                result = ledger.process(records, minimum_cents=minimum)
                self.assertIn('events', result)
                self.assertIn('totals', result)
            except ValueError:
                pass


if __name__ == '__main__':
    unittest.main()
