# Ledger Toolkit

Three-module library for processing transaction records.

## Modules

- `validation.py`: `normalize(records)` validates and normalizes records.
- `storage.py`: `deduplicate(records)` removes duplicate IDs, keeping first occurrence.
- `ledger.py`: `process(records, *, minimum_cents=0)` composes both helpers.

## Record format

Each record must be a dict with exactly:
- `id`: nonempty stripped `str`
- `category`: nonempty stripped `str`
- `cents`: nonnegative `int` (booleans are invalid)

## API

- `validation.normalize(records)` → list of fresh normalized records (duplicates preserved)
- `storage.deduplicate(records)` → list of fresh copies, first ID wins
- `ledger.process(records, *, minimum_cents=0)` → `{'events': [...], 'totals': {...}}`
  - `events`: deduplicated, filtered records in input order
  - `totals`: category sums, keys sorted

## Errors

Invalid input raises `ValueError`.
