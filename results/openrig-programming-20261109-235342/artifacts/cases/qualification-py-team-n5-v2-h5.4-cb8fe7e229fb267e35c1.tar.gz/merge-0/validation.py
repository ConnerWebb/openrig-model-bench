def normalize(records):
    """
    Validate and normalize a list of records.

    Each record must be a dict with exactly the keys 'id', 'category', and 'cents'.
    - 'id' and 'category' must be nonempty strings after stripping whitespace.
    - 'cents' must be a nonnegative integer (booleans are rejected).
    Returns a new list of normalized dictionaries; input is never mutated.
    Raises ValueError on any invalid record.
    """
    if not isinstance(records, list):
        raise ValueError('records')

    out = []
    for idx, r in enumerate(records):
        if not isinstance(r, dict):
            raise ValueError(f'record {idx}')
        if set(r.keys()) != {'id', 'category', 'cents'}:
            raise ValueError(f'record {idx}')
        rid = r['id']
        cat = r['category']
        cents = r['cents']

        if not isinstance(rid, str) or not rid.strip():
            raise ValueError(f'record {idx}')
        if not isinstance(cat, str) or not cat.strip():
            raise ValueError(f'record {idx}')
        # Reject booleans explicitly (bool is subclass of int in Python)
        if isinstance(cents, bool) or not isinstance(cents, int):
            raise ValueError(f'record {idx}')
        if cents < 0:
            raise ValueError(f'record {idx}')

        out.append({
            'id': rid.strip(),
            'category': cat.strip(),
            'cents': cents
        })

    return out
