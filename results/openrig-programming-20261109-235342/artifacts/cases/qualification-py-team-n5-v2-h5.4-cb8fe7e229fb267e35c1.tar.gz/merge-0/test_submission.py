import unittest
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    def test_valid_record(self):
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])
        self.assertIsNot(result, records)

    def test_empty_id(self):
        records = [{'id': '', 'category': 'a', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_empty_category(self):
        records = [{'id': 'x', 'category': '', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_negative_cents(self):
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_boolean_cents(self):
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_non_int_cents(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 5.5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_extra_keys(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 5, 'extra': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_missing_keys(self):
        records = [{'id': 'x', 'category': 'a'}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_non_dict_record(self):
        records = ['not a dict']
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_non_list_input(self):
        with self.assertRaises(ValueError):
            validation.normalize('not a list')

    def test_whitespace_stripping(self):
        records = [{'id': '  id  ', 'category': '  cat  ', 'cents': 10}]
        result = validation.normalize(records)
        self.assertEqual(result[0]['id'], 'id')
        self.assertEqual(result[0]['category'], 'cat')


class TestStorage(unittest.TestCase):
    def test_no_duplicates(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = storage.deduplicate(records)
        self.assertEqual(result, records)

    def test_duplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['category'], 'x')

    def test_first_wins(self):
        records = [
            {'id': 'a', 'category': 'first', 'cents': 1},
            {'id': 'b', 'category': 'second', 'cents': 2},
            {'id': 'a', 'category': 'third', 'cents': 3}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['category'], 'first')
        self.assertEqual(result[1]['category'], 'second')

    def test_fresh_copy(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = storage.deduplicate(records)
        self.assertIsNot(result[0], records[0])


class TestLedger(unittest.TestCase):
    def test_basic(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 5}]
        result = ledger.process(records)
        self.assertEqual(result['events'], [{'id': 'x', 'category': 'a', 'cents': 5}])
        self.assertEqual(result['totals'], {'a': 5})

    def test_empty(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_deduplication(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'x')

    def test_minimum_cents(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'x', 'cents': 10}
        ]
        result = ledger.process(records, minimum_cents=7)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 10)
        self.assertEqual(result['totals'], {'x': 10})

    def test_minimum_cents_zero_default(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)

    def test_invalid_minimum_cents(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_invalid_minimum_cents_bool(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)

    def test_totals_sorted(self):
        records = [
            {'id': 'a', 'category': 'z', 'cents': 1},
            {'id': 'b', 'category': 'a', 'cents': 2}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'z'])

    def test_no_mutation(self):
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = records[0].copy()
        ledger.process(records)
        self.assertEqual(records[0], original)


class TestIntegration(unittest.TestCase):
    def test_public_case_1(self):
        records = [
            {'id': ' 8 ', 'category': ' c ', 'cents': 1},
            {'id': ' 4 ', 'category': ' a ', 'cents': 96},
            {'id': ' 3 ', 'category': ' b ', 'cents': 11},
            {'id': ' 3 ', 'category': ' c ', 'cents': 7},
            {'id': ' 9 ', 'category': ' a ', 'cents': 64}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 4)
        self.assertEqual(result['totals'], {'a': 160, 'b': 11, 'c': 1})

    def test_validation_then_deduplication_order(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'b', 'category': 'z', 'cents': 3}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['id'], 'a')
        self.assertEqual(result['events'][1]['id'], 'b')


if __name__ == '__main__':
    unittest.main()
