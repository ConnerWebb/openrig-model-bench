import json
import os
import tempfile
import unittest

import solution


class JobQueueTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "q.db")
        self.q = solution.JobQueue(self.path)

    def tearDown(self):
        self.q.close()
        self.dir.cleanup()

    def test_enqueue_first_wins(self):
        self.assertTrue(self.q.enqueue("a", {"v": 1}))
        self.assertFalse(self.q.enqueue("a", "ignored"))
        self.assertEqual(self.q.status("a"), {"state": "queued", "attempts": 0})

    def test_claim_complete_flow(self):
        self.q.enqueue("a", {"v": 5})
        r = self.q.claim("w", 0, 5)
        self.assertEqual(r, {"key": "a", "payload": {"v": 5}, "attempts": 1})
        self.assertFalse(self.q.complete("a", "wrong"))
        self.assertTrue(self.q.fail("a", "w"))
        r2 = self.q.claim("w2", 1, 5)
        self.assertEqual(r2["attempts"], 2)
        self.assertTrue(self.q.complete("a", "w2"))
        self.assertEqual(self.q.status("a"), {"state": "done", "attempts": 2})
        self.assertIsNone(self.q.claim("w3", 100, 5))

    def test_max_attempts_exhausted(self):
        q = solution.JobQueue(self.path, max_attempts=1)
        q.enqueue("x", 0)
        self.assertIsNotNone(q.claim("w", 0, 2))
        self.assertIsNone(q.claim("other", 2, 2))
        self.assertEqual(q.status("x"), {"state": "failed", "attempts": 1})
        q.close()

    def test_expired_lease_reclaim(self):
        self.q.enqueue("a", "p")
        self.q.claim("w1", 0, 5)
        self.assertIsNone(self.q.claim("w2", 3, 5))
        r = self.q.claim("w2", 6, 5)
        self.assertEqual(r["attempts"], 2)

    def test_oldest_first(self):
        self.q.enqueue("b", 1)
        self.q.enqueue("a", 2)
        self.assertEqual(self.q.claim("w", 0, 5)["key"], "b")
        self.assertEqual(self.q.claim("w", 0, 5)["key"], "a")

    def test_invalid_args(self):
        with self.assertRaises(ValueError):
            self.q.claim("", 0, 1)
        with self.assertRaises(ValueError):
            self.q.claim("w", 0, 0)
        with self.assertRaises(ValueError):
            self.q.claim("w", 0, -1)
        with self.assertRaises(ValueError):
            self.q.enqueue("", "x")
        with self.assertRaises(ValueError):
            solution.JobQueue(self.path, max_attempts=0)
        with self.assertRaises(ValueError):
            solution.JobQueue(self.path, max_attempts=1.5)

    def test_status_missing(self):
        self.assertIsNone(self.q.status("nope"))

    def test_shared_db(self):
        other = solution.JobQueue(self.path)
        self.q.enqueue("a", {"v": 9})
        self.assertEqual(other.status("a"), {"state": "queued", "attempts": 0})
        other.close()


if __name__ == "__main__":
    unittest.main()
