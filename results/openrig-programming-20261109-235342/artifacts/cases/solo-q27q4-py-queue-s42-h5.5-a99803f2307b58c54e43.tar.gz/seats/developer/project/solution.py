"""SQLite-backed job queue with leases, retries and atomic claims."""
import json
import sqlite3
import threading


def _check_str(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string")


def _check_now(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("now must be a number")


def _check_lease(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("lease must be a number")
    if value <= 0:
        raise ValueError("lease must be positive")


class JobQueue:
    def __init__(self, path, max_attempts=3):
        if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self._path = str(path)
        self._max_attempts = max_attempts
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                state TEXT NOT NULL,
                attempts INTEGER NOT NULL,
                owner TEXT,
                lease_until REAL,
                seq INTEGER NOT NULL
            )"""
        )
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS _lock (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                token TEXT
            )"""
        )
        self._conn.execute(
            "INSERT OR IGNORE INTO _lock (id, token) VALUES (1, '')"
        )
        self._conn.commit()

    def _claimable(self, now):
        return (
            "state = 'queued' OR "
            "(state = 'leased' AND lease_until <= ? AND attempts < ?)"
        )

    def enqueue(self, key, payload):
        _check_str(key, "key")
        try:
            blob = json.dumps(payload)
        except (TypeError, ValueError) as exc:
            raise ValueError("payload must be JSON-compatible") from exc
        with self._lock, self._conn:
            exists = self._conn.execute(
                "SELECT 1 FROM jobs WHERE key = ?", (key,)
            ).fetchone()
            if exists is not None:
                return False
            self._conn.execute(
                "INSERT INTO jobs (key, payload, state, attempts, seq) "
                "VALUES (?, ?, 'queued', 0, (SELECT COALESCE(MAX(seq), -1) + 1 FROM jobs))",
                (key, blob),
            )
        return True

    def claim(self, worker, now, lease):
        _check_str(worker, "worker")
        _check_now(now)
        _check_lease(lease)
        with self._lock, self._conn:
            # Serialize claimers across processes.
            self._conn.execute("BEGIN IMMEDIATE")
            self._conn.execute(
                "UPDATE _lock SET token = ? WHERE id = 1", (worker,)
            )
            # Expire final-attempt leases to failed.
            self._conn.execute(
                "UPDATE jobs SET state = 'failed', owner = NULL, lease_until = NULL "
                "WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?",
                (now, self._max_attempts),
            )
            row = self._conn.execute(
                "SELECT key FROM jobs WHERE " + self._claimable(now) +
                " ORDER BY seq ASC LIMIT 1",
                (now, self._max_attempts),
            ).fetchone()
            if row is None:
                self._conn.commit()
                return None
            key = row[0]
            self._conn.execute(
                "UPDATE jobs SET state = 'leased', owner = ?, lease_until = ?, "
                "attempts = attempts + 1 WHERE key = ?",
                (worker, now + lease, key),
            )
            payload, attempts = self._conn.execute(
                "SELECT payload, attempts FROM jobs WHERE key = ?", (key,)
            ).fetchone()
            self._conn.commit()
        return {"key": key, "payload": json.loads(payload), "attempts": attempts}

    def _owned(self, key, worker):
        _check_str(key, "key")
        _check_str(worker, "worker")
        row = self._conn.execute(
            "SELECT state, owner FROM jobs WHERE key = ?", (key,)
        ).fetchone()
        return row is not None and row[0] == "leased" and row[1] == worker

    def complete(self, key, worker):
        with self._lock, self._conn:
            if not self._owned(key, worker):
                return False
            self._conn.execute(
                "UPDATE jobs SET state = 'done', owner = NULL, lease_until = NULL "
                "WHERE key = ?",
                (key,),
            )
        return True

    def fail(self, key, worker):
        with self._lock, self._conn:
            if not self._owned(key, worker):
                return False
            attempts = self._conn.execute(
                "SELECT attempts FROM jobs WHERE key = ?", (key,)
            ).fetchone()[0]
            if attempts >= self._max_attempts:
                state = "failed"
            else:
                state = "queued"
            self._conn.execute(
                "UPDATE jobs SET state = ?, owner = NULL, lease_until = NULL "
                "WHERE key = ?",
                (state, key),
            )
        return True

    def status(self, key):
        _check_str(key, "key")
        row = self._conn.execute(
            "SELECT state, attempts FROM jobs WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        return {"state": row[0], "attempts": row[1]}

    def close(self):
        with self._lock:
            self._conn.close()
