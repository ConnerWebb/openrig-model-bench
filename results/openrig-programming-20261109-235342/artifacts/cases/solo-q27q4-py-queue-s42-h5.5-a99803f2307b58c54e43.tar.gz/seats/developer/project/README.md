# JobQueue

A SQLite-backed job queue with leases, retries and atomic claims.

## API

`JobQueue(path, max_attempts=3)` — opens (or creates) the SQLite database at
`path`. Multiple instances/processes sharing the same path share the queue.

- `enqueue(key, payload) -> bool` — inserts a new job in state `queued` with
  `attempts=0`. The first unique key wins; duplicate keys return `False`.
- `claim(worker, now, lease) -> dict | None` — atomically picks the oldest
  insertion that is `queued`, or `leased` with `lease_until <= now` and
  `attempts < max_attempts`. Increments `attempts`, sets the owner and lease
  expiry, and returns `{"key", "payload", "attempts"}`.
- `complete(key, worker) -> bool` — marks a currently leased job `done`;
  requires the matching owner.
- `fail(key, worker) -> bool` — re-queues a leased job unless attempts are
  exhausted, in which case it becomes `failed`; requires the matching owner.
- `status(key) -> dict | None` — returns `{"state", "attempts"}` or `None`.

## Validation

`lease > 0`, nonempty `worker`/`key`, and a positive integer `max_attempts`
are required; invalid arguments raise `ValueError`.

## Concurrency

Claims are performed inside a single SQLite transaction, so separate
processes cannot lose or duplicate a live claim.

## Tests

`python3 -m unittest test_solution -v`
