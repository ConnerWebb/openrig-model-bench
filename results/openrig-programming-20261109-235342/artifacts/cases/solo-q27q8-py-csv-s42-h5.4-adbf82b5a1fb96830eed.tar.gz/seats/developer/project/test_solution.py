import json
import pathlib
import tempfile
import unittest

import solution


def _run(csv_text):
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d) / "input.csv"
        p.write_text(csv_text, encoding="utf-8")
        return solution.aggregate(str(p))


class AggregateTests(unittest.TestCase):
    def test_public_cases(self):
        cases = json.loads(pathlib.Path("PUBLIC_CASES.json").read_text(encoding="utf-8"))
        for i, case in enumerate(cases):
            with self.subTest(case=i):
                csv_text = case["driver_input"]["csv"]
                expected = case["expected"]
                if "error" in expected:
                    exc = ValueError
                    with self.assertRaises(exc):
                        _run(csv_text)
                else:
                    self.assertEqual(_run(csv_text), expected["value"])

    def test_blank_lines_ignored(self):
        self.assertEqual(
            _run("category,amount\n\nx,1.5\n\n\ny,2\n"),
            {"x": "1.50", "y": "2.00"},
        )

    def test_whitespace_stripped(self):
        self.assertEqual(_run("category,amount\n  x  ,  +12.3 \n"), {"x": "12.30"})

    def test_exact_decimal_accumulation(self):
        # 0.1 + 0.2 must be exactly 0.30, not 0.30000000000000004
        self.assertEqual(_run("category,amount\nx,0.1\nx,0.2\n"), {"x": "0.30"})

    def test_twelve_digit_max(self):
        self.assertEqual(_run("category,amount\nx,123456789012\n"), {"x": "123456789012.00"})

    def test_rejects_thirteen_digits(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,1234567890123\n")

    def test_rejects_exponent(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,1e2\n")

    def test_rejects_negative(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,-1\n")

    def test_rejects_three_decimals(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,1.001\n")

    def test_rejects_nan_inf(self):
        for bad in ("NaN", "Infinity", "-Infinity", "inf"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    _run(f"category,amount\nx,{bad}\n")

    def test_rejects_bad_header(self):
        with self.assertRaises(ValueError):
            _run("wrong,amount\nx,1\n")

    def test_rejects_empty_file(self):
        with self.assertRaises(ValueError):
            _run("")

    def test_rejects_unterminated_quote(self):
        with self.assertRaises(ValueError):
            _run('category,amount\n"x,1\n')

    def test_quoted_comma_and_newline(self):
        self.assertEqual(
            _run('category,amount\n"a,b",1.00\n"two\nlines",2.50\n'),
            {"a,b": "1.00", "two\nlines": "2.50"},
        )

    def test_sorted_keys(self):
        result = _run("category,amount\nz,1\na,2\nm,3\n")
        self.assertEqual(list(result), ["a", "m", "z"])


if __name__ == "__main__":
    unittest.main()
