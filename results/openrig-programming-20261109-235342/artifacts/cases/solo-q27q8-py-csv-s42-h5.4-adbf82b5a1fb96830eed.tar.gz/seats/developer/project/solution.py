"""Aggregate CSV amounts per category with exact decimal arithmetic."""
import csv
import re
from decimal import Decimal

_AMOUNT_RE = re.compile(r'\A\+?(?:\d{1,12})(?:\.\d{1,2})?\Z')


def _parse_amount(raw: str) -> Decimal:
    s = raw.strip()
    if not _AMOUNT_RE.match(s):
        raise ValueError(f"malformed amount: {raw!r}")
    return Decimal(s)


def aggregate(path: str) -> dict:
    totals: dict = {}
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("missing header")
        if header != ["category", "amount"]:
            raise ValueError("bad header")
        for row in reader:
            if not row or all(field.strip() == "" for field in row):
                continue
            if len(row) != 2:
                raise ValueError(f"bad record: {row!r}")
            category = row[0].strip()
            if not category:
                raise ValueError("empty category")
            amount = _parse_amount(row[1])
            totals[category] = totals.get(category, Decimal(0)) + amount
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}
