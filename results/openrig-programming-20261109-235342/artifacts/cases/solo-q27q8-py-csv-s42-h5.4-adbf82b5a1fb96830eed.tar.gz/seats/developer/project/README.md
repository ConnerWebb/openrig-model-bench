# CSV Category Aggregator

`solution.aggregate(path: str) -> dict[str, str]` reads a UTF-8 CSV file as a
stream and sums the `amount` column per `category`.

## Contract

- The header must be exactly `category,amount`; anything else raises
  `ValueError`.
- Completely blank records are ignored; every other record must have exactly
  two fields.
- `category` and `amount` are stripped of surrounding whitespace; the category
  must be non-empty after stripping.
- `amount` grammar: optional `+`, 1–12 decimal digits, optional `.` followed
  by 1 or 2 digits. Nonnegative, finite, no exponent. Anything else (including
  `NaN`, `Infinity`, negatives, more than 12 digits, or more than 2 decimal
  places) raises `ValueError`.
- Accumulation uses exact `decimal.Decimal` arithmetic (no float drift).
- Quoted fields with embedded commas/newlines are valid CSV and are handled by
  the stdlib `csv` reader.
- Returns a dict with category keys in sorted order and totals formatted with
  exactly two decimal places.

## Usage

```python
from solution import aggregate
totals = aggregate("input.csv")  # {"food": "2262.01", ...}
```

## Tests

`test_solution.py` covers the public cases plus edge cases (blank lines,
whitespace, exact decimal math, digit limits, malformed amounts, bad headers,
unterminated quotes, embedded commas/newlines, key ordering). Run with:

```
python3 -m unittest test_solution -v
```
