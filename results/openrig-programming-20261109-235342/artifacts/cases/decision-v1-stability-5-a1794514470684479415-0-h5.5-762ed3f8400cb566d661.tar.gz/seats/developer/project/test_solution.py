import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.25\nfood,5.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.25'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\n\nrent,20.25\n\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50', 'rent': '20.25'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_quoted_fields_with_newlines(self):
        """Test quoted fields containing newlines"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"two\nlines",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '50.00'})
    
    def test_escaped_quotes(self):
        """Test escaped quotes in quoted fields"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_invalid_header_wrong_names(self):
        """Test that wrong header names raise ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,amount\nx,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_wrong_field_count(self):
        """Test that wrong number of header fields raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount,extra\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_field_count(self):
        """Test that records with wrong field count raise ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test that empty category raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test that NaN amount raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_exponent(self):
        """Test that exponent notation raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1e2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_negative(self):
        """Test that negative amount raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,-10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_too_many_digits(self):
        """Test that more than 12 digits raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1234567890123\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_too_many_decimal_places(self):
        """Test that more than 2 decimal places raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.123\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unterminated_quote(self):
        """Test that unterminated quote raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_sorted_output(self):
        """Test that output keys are sorted"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nzebra,10.00\napple,20.00\nmango,30.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_exact_decimal_arithmetic(self):
        """Test that decimal arithmetic is exact (no floating point errors)"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,0.1\nx,0.2\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '0.30'})
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Build content with ASCII comma after unicode text
            header = 'category,amount\n'
            # 日本 in UTF-8 is E6 97 A5 E6 9C AC, followed by ASCII comma 2C
            row = bytes([0xE6, 0x97, 0xA5, 0xE6, 0x9C, 0xAC, 0x2C, 0x31, 0x30, 0x30, 0x2E, 0x30, 0x30, 0x0A])
            content = header + row.decode('utf-8')
            p.write_text(content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00'})


if __name__ == '__main__':
    unittest.main()
