# Solution: CSV Category Aggregator

## Overview

This module implements a CSV aggregator that reads UTF-8 CSV files, validates the data, and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted category keys with totals formatted to 2 decimal places.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to formatted totals (2 decimal places)
        
    Raises:
        ValueError: If the CSV is malformed (invalid header, wrong field count,
                   empty category, invalid amount format, etc.)
    """
```

## Input Format

- CSV file with header exactly `category,amount`
- Quoted fields are supported (including commas and newlines within quotes)
- Escaped quotes use double-quote syntax (`""`)
- Blank records (completely empty lines) are ignored
- Non-blank records must have exactly two fields

## Amount Validation

Amounts must match the pattern:
- Optional leading `+` sign
- 1-12 decimal digits
- Optional decimal point followed by 1-2 digits
- Nonnegative, finite, no exponent notation

Examples of valid amounts: `10`, `+10`, `10.5`, `10.50`, `+123456789012`
Examples of invalid amounts: `-10`, `10.123`, `1e2`, `NaN`, `1234567890123`

## Output Format

- Keys are sorted alphabetically
- Values are formatted with exactly 2 decimal places

## Testing

Run tests with:
```bash
python3 -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
