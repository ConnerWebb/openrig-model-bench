import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted category keys with totals formatted to 2 decimal places.
    """
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid header")
        
        for row in reader:
            # Skip completely blank records (empty row or all empty fields)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate amount format: optional +, 1-12 decimal digits, optional decimal point
            # followed by 1 or 2 digits. Nonnegative, finite, no exponent.
            amount_pattern = r'^\+?[0-9]{1,12}(\.[0-9]{1,2})?$'
            if not re.match(amount_pattern, amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse as Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check nonnegative and finite
            if amount < 0 or not amount.is_finite():
                raise ValueError(f"Amount must be nonnegative and finite: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted keys with totals formatted to 2 decimal places
    result = {}
    for key in sorted(totals.keys()):
        total = totals[key]
        # Format with exactly 2 decimal places
        result[key] = f"{total:.2f}"
    
    return result
