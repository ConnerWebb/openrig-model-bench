# CSV Aggregate Solution

This solution implements `aggregate(path: str) -> dict[str, str]` as specified in TASK.txt.

## Implementation

- Reads UTF-8 CSV as a stream using Python's `csv` module for proper handling of quoted fields, embedded newlines, and escaped quotes.
- Validates header as exactly `category,amount`.
- Ignores completely blank records; all other records must have exactly two fields.
- Strips whitespace from category and amount; category must not be empty after stripping.
- Validates amount format: optional `+`, 1-12 digits, optional decimal point followed by 1-2 digits. No exponent notation allowed.
- Rejects NaN, infinity, and negative amounts with `ValueError`.
- Uses `decimal.Decimal` for exact arithmetic accumulation.
- Returns category keys sorted, with totals formatted to exactly two decimal places.

## Tests

Run `python test_solution.py` to execute all tests against public cases.

## Usage

```python
from solution import aggregate
result = aggregate("path/to/input.csv")
# result is a dict with sorted category keys and string values formatted as "X.XX"
```
