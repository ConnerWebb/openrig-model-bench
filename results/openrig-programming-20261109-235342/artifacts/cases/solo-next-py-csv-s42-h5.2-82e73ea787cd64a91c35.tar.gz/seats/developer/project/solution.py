import csv
from decimal import Decimal, InvalidOperation
import os


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted, totals formatted
    with exactly two decimal places. CSV quoted commas and embedded newlines are valid.
    """
    totals: dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("Empty file")
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")

        for row in reader:
            # Completely blank records are ignored
            if len(row) == 0 or (len(row) == 1 and row[0].strip() == ''):
                continue

            if len(row) != 2:
                raise ValueError("Invalid row length")

            category = row[0].strip()
            amount_str = row[1].strip()

            if not category:
                raise ValueError("Empty category")

            # Validate amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits
            amount_validated = _validate_amount(amount_str)
            if amount_validated is None:
                raise ValueError("Invalid amount format")

            try:
                amount = Decimal(amount_validated)
            except InvalidOperation:
                raise ValueError("Invalid amount")

            if amount.is_nan() or amount.is_infinite():
                raise ValueError("Invalid amount")

            if amount < 0:
                raise ValueError("Negative amount")

            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount

    # Format totals with exactly two decimal places
    result = {cat: f"{total:.2f}" for cat, total in sorted(totals.items())}
    return result


def _validate_amount(s: str) -> str | None:
    """
    Validate amount string: optional +, 1-12 digits, optional decimal point followed by 1-2 digits.
    No exponent, nonnegative, finite.
    Returns the normalized string if valid, None otherwise.
    """
    if not s:
        return None

    # Check for exponent
    if 'e' in s.lower():
        return None

    # Handle optional leading +
    if s.startswith('+'):
        s = s[1:]
        if not s:
            return None

    # Split by decimal point
    if '.' in s:
        parts = s.split('.')
        if len(parts) != 2:
            return None
        int_part, frac_part = parts
        # Integer part: 1-12 digits
        if not (1 <= len(int_part) <= 12) or not int_part.isdigit():
            return None
        # Fraction part: 1-2 digits
        if not (1 <= len(frac_part) <= 2) or not frac_part.isdigit():
            return None
        return s
    else:
        # No decimal point: 1-12 digits
        if not (1 <= len(s) <= 12) or not s.isdigit():
            return None
        return s
