import unittest
import os
import tempfile
import json
from solution import aggregate


class TestAggregate(unittest.TestCase):
    def test_public_case_00(self):
        with open('public-inputs/case-00.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(p)
        expected = {
            "a,b": "599.14",
            "food": "2262.01",
            "rent": "2215.92",
            "two\nlines": "1434.24",
            "x\"quote": "1458.60",
            "日本": "909.01"
        }
        self.assertEqual(result, expected)

    def test_public_case_01(self):
        with open('public-inputs/case-01.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(p)
        expected = {
            "a,b": "2074.58",
            "food": "780.73",
            "rent": "3952.60",
            "two\nlines": "3813.91",
            "x\"quote": "2379.17",
            "日本": "4018.82"
        }
        self.assertEqual(result, expected)

    def test_public_case_02(self):
        with open('public-inputs/case-02.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(p)
        expected = {
            "a,b": "2731.56",
            "food": "1088.43",
            "rent": "595.15",
            "two\nlines": "1739.71",
            "x\"quote": "2666.53",
            "日本": "1015.06"
        }
        self.assertEqual(result, expected)

    def test_public_case_03(self):
        with open('public-inputs/case-03.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(p)
        expected = {
            "a,b": "1531.97",
            "food": "1327.96",
            "rent": "631.30",
            "two\nlines": "1436.88",
            "x\"quote": "2449.70",
            "日本": "3293.74"
        }
        self.assertEqual(result, expected)

    def test_public_case_04_wrong_header(self):
        with open('public-inputs/case-04.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_public_case_05_extra_field(self):
        with open('public-inputs/case-05.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_public_case_06_empty_category(self):
        with open('public-inputs/case-06.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_public_case_07_nan(self):
        with open('public-inputs/case-07.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_public_case_08_unclosed_quote(self):
        with open('public-inputs/case-08.csv', 'r', encoding='utf-8') as f:
            csv_content = f.read()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(p)


if __name__ == '__main__':
    unittest.main()
