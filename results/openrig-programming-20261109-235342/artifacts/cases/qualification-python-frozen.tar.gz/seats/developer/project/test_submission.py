import unittest
import tempfile
import pathlib
import solution


class TestAggregate(unittest.TestCase):
    """Comprehensive tests for the aggregate function."""
    
    def test_basic_aggregation(self):
        """Test basic aggregation with simple categories."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.00\nb,2.50\na,0.50\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.50', 'b': '2.50'})
    
    def test_decimal_precision(self):
        """Test decimal precision handling."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,0.10\na,0.20\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '0.30'})
    
    def test_header_validation(self):
        """Test that invalid headers raise ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('cat,amt\na,1.00\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_header_validation_wrong_columns(self):
        """Test header with wrong column names."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,price\na,1.00\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_header_validation_extra_column(self):
        """Test header with extra column."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount,extra\na,1.00,x\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_blank_records_ignored(self):
        """Test that blank records are ignored."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.00\n\nb,2.00\n\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.00', 'b': '2.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from fields."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n  a  ,  1.00  \n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.00'})
    
    def test_empty_category_rejected(self):
        """Test that empty category is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n,1.00\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_empty_category_after_strip_rejected(self):
        """Test that empty category after stripping is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n   ,1.00\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_with_plus_sign(self):
        """Test amount with optional + sign."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,+1.00\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.00'})
    
    def test_amount_without_decimal(self):
        """Test amount without decimal point."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,123\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '123.00'})
    
    def test_amount_with_one_decimal(self):
        """Test amount with one decimal place."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.5\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.50'})
    
    def test_amount_with_two_decimals(self):
        """Test amount with two decimal places."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.55\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.55'})
    
    def test_amount_max_digits(self):
        """Test amount with maximum 12 digits."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,123456789012\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '123456789012.00'})
    
    def test_amount_too_many_digits(self):
        """Test that amount with more than 12 digits is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1234567890123\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_three_decimals_rejected(self):
        """Test that amount with three decimal places is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.555\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_empty_decimal_rejected(self):
        """Test that amount with empty decimal part is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_only_decimal_rejected(self):
        """Test that amount with only decimal point is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,.\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_no_digits_rejected(self):
        """Test that amount with no digits is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,+\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_extra_field_rejected(self):
        """Test that extra fields are rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.00,x\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_amount_missing_field_rejected(self):
        """Test that missing fields are rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_quoted_fields(self):
        """Test CSV with quoted fields containing commas."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n"a,b",100.00\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_quoted_fields_with_embedded_newlines(self):
        """Test CSV with quoted fields containing embedded newlines."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n"a\nb",100.00\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a\nb': '100.00'})
    
    def test_quoted_fields_with_quotes(self):
        """Test CSV with quoted fields containing escaped quotes."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n"a""b",100.00\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a"b': '100.00'})
    
    def test_unicode_categories(self):
        """Test CSV with unicode category names."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n日本,100.00\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00'})
    
    def test_sorted_output(self):
        """Test that output keys are sorted."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nz,1.00\na,2.00\nm,3.00\n')
            result = solution.aggregate(str(p))
            self.assertEqual(list(result.keys()), ['a', 'm', 'z'])
    
    def test_empty_file(self):
        """Test empty file raises ValueError for missing header."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_header_only(self):
        """Test file with only header returns empty dict."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {})
    
    def test_negative_amount_rejected(self):
        """Test that negative amounts are rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,-1.00\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))
    
    def test_zero_amount(self):
        """Test zero amount is valid."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,0\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '0.00'})
    
    def test_large_aggregation(self):
        """Test aggregation with many categories."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            lines = ['category,amount']
            for i in range(100):
                lines.append(f'cat{i % 10},{i}.00')
            p.write_text('\n'.join(lines))
            result = solution.aggregate(str(p))
            self.assertEqual(len(result), 10)
    
    def test_decimal_rounding(self):
        """Test proper decimal rounding with 2 decimal places."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,0.99\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '0.99'})
    
    def test_multiple_blank_rows(self):
        """Test multiple consecutive blank rows."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n\n\na,1.00\n\n\n')
            result = solution.aggregate(str(p))
            self.assertEqual(result, {'a': '1.00'})


if __name__ == '__main__':
    unittest.main()
