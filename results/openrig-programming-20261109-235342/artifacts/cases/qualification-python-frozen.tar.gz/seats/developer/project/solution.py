import csv
import re
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    """Aggregate amounts by category from a UTF-8 CSV file.
    
    Args:
        path: Path to CSV file with header category,amount
        
    Returns:
        Dict mapping category names to totals formatted to 2 decimal places
        
    Raises:
        ValueError: For malformed input
    """
    out = {}
    
    with open(path, encoding='utf-8', newline='') as f:
        rd = csv.reader(f, strict=True)
        
        # Validate header
        header = next(rd, None)
        if header != ['category', 'amount']:
            raise ValueError('header')
        
        # Amount pattern: optional +, 1-12 digits, optional .1-2 digits
        amount_pattern = re.compile(r'^\+?\d{1,12}(?:\.\d{1,2})?$')
        
        try:
            for row in rd:
                # Skip completely blank records
                if not row:
                    continue
                
                # Every non-blank record must have exactly 2 fields
                if len(row) != 2:
                    raise ValueError('columns')
                
                category, amount_str = (s.strip() for s in row)
                
                # Category must not be empty
                if not category:
                    raise ValueError('category_empty')
                
                # Validate amount format
                if not amount_pattern.match(amount_str):
                    raise ValueError('amount_format')
                
                # Validate amount is a valid decimal
                try:
                    amount = Decimal(amount_str)
                except InvalidOperation:
                    raise ValueError('amount_invalid')
                
                # Accumulate
                out[category] = out.get(category, Decimal(0)) + amount
                
        except csv.Error as e:
            raise ValueError('csv') from e
    
    # Return sorted keys with totals formatted to 2 decimal places
    return {k: format(out[k], '.2f') for k in sorted(out)}
