# CSV Aggregate Function

This module provides a function to aggregate numeric amounts by category from CSV files.

## Usage

```python
from solution import aggregate

# Aggregate amounts from a CSV file
result = aggregate('data.csv')
print(result)  # {'category1': '123.45', 'category2': '678.90'}
```

## Function Signature

```python
def aggregate(path: str) -> dict[str, str]:
    """Aggregate amounts by category from a UTF-8 CSV file.
    
    Args:
        path: Path to CSV file with header category,amount
        
    Returns:
        Dict mapping category names to totals formatted to 2 decimal places
        
    Raises:
        ValueError: For malformed input
    """
```

## CSV Format

The input CSV file must have:
- Header row: `category,amount`
- UTF-8 encoding
- Standard CSV quoting rules (quoted fields, embedded newlines, escaped quotes)

## Amount Validation

Amounts must match the pattern: `^\+?\d{1,12}(?:\.\d{1,2})?$`

This means:
- Optional `+` prefix
- 1-12 decimal digits
- Optional decimal point followed by 1-2 digits
- No negative values
- No exponent notation

## Error Handling

The function raises `ValueError` for:
- Invalid header (must be exactly `category,amount`)
- Wrong number of fields in a row
- Empty category after stripping whitespace
- Invalid amount format
- CSV parsing errors

## Examples

```python
# Basic aggregation
aggregate('data.csv')
# Input:
#   category,amount
#   food,10.00
#   rent,100.00
#   food,5.00
# Output: {'food': '15.00', 'rent': '100.00'}

# With whitespace
aggregate('data.csv')
# Input:
#   category,amount
#   food,  10.00
#   rent,100.00
# Output: {'food': '10.00', 'rent': '100.00'}

# With quoted fields
aggregate('data.csv')
# Input:
#   category,amount
#   "a,b",10.00
#   "a""b",20.00
# Output: {'a,b': '10.00', 'a"b': '20.00'}
```

## Implementation Details

- Uses `decimal.Decimal` for exact arithmetic
- Returns sorted category keys
- Totals formatted with exactly 2 decimal places
- Blank rows are ignored
- Non-blank rows must have exactly 2 fields
