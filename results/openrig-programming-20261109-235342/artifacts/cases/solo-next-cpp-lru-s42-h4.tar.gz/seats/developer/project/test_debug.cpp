#include "solution.hpp"
#include <iostream>
#include <string>

int main() {
    LruCache<int, std::string> cache(5);
    
    cache.put(4, "x96");
    std::cout << "After P 4 x96: ";
    auto snap = cache.snapshot();
    for (const auto& [k, v] : snap) std::cout << "[" << k << "," << v << "] ";
    std::cout << std::endl;
    
    cache.put(4, "x25");
    std::cout << "After P 4 x25: ";
    snap = cache.snapshot();
    for (const auto& [k, v] : snap) std::cout << "[" << k << "," << v << "] ";
    std::cout << std::endl;
    
    return 0;
}
