#include "solution.hpp"
#include <cassert>
#include <iostream>
#include <string>

void test_basic_put_get() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string out;
    assert(cache.get(1, out) == true);
    assert(out == "one");
    assert(cache.get(2, out) == true);
    assert(out == "two");
    assert(cache.get(3, out) == true);
    assert(out == "three");
}

void test_eviction() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    cache.put(4, "four");  // Should evict key 1 (LRU)
    
    std::string out;
    assert(cache.get(1, out) == false);  // Evicted
    assert(cache.get(2, out) == true);
    assert(out == "two");
    assert(cache.get(3, out) == true);
    assert(out == "three");
    assert(cache.get(4, out) == true);
    assert(out == "four");
}

void test_update_doesnt_evict() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    cache.put(1, "updated");  // Update, should not evict
    
    std::string out;
    assert(cache.get(1, out) == true);
    assert(out == "updated");
    assert(cache.get(2, out) == true);  // 2 should still be there
    assert(out == "two");
}

void test_get_makes_mru() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string out;
    cache.get(1, out);  // Make 1 MRU
    
    cache.put(4, "four");  // Should evict 2 (now LRU)
    
    assert(cache.get(2, out) == false);  // Evicted
    assert(cache.get(1, out) == true);
    assert(out == "one");  // Original value, not updated
    assert(cache.get(3, out) == true);
    assert(out == "three");
    assert(cache.get(4, out) == true);
    assert(out == "four");
}

void test_erase() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    assert(cache.erase(2) == true);
    assert(cache.erase(2) == false);  // Already erased
    
    std::string out;
    assert(cache.get(2, out) == false);
    assert(cache.get(1, out) == true);
    assert(cache.get(3, out) == true);
}

void test_snapshot() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    auto snap = cache.snapshot();
    assert(snap.size() == 3);
    assert(snap[0].first == 3);  // MRU
    assert(snap[0].second == "three");
    assert(snap[1].first == 2);
    assert(snap[1].second == "two");
    assert(snap[2].first == 1);  // LRU
    assert(snap[2].second == "one");
}

void test_snapshot_updates_mru() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    cache.snapshot();  // Should not affect recency
    
    cache.put(4, "four");  // Should evict 1 (still LRU)
    
    std::string out;
    assert(cache.get(1, out) == false);
    assert(cache.get(2, out) == true);
}

void test_capacity_zero() {
    LruCache<int, std::string> cache(0);
    cache.put(1, "one");
    assert(cache.size() == 0);
    
    std::string out;
    assert(cache.get(1, out) == false);
}

void test_get_miss_leaves_out_unchanged() {
    LruCache<int, std::string> cache(3);
    cache.put(1, "one");
    
    std::string out = "UNCHANGED";
    assert(cache.get(2, out) == false);
    assert(out == "UNCHANGED");  // Should remain unchanged
}

void test_complex_scenario() {
    // Test from PUBLIC_CASES.json first case
    LruCache<int, std::string> cache(5);
    
    // Just test basic operations that match the expected behavior
    // P 4 "x96" - put key 4 with value "x96"
    cache.put(4, "x96");
    // P 4 "x25" - update key 4 with value "x25"
    cache.put(4, "x25");
    
    // S - snapshot should show [[4, "x25"]]
    auto snap = cache.snapshot();
    assert(snap.size() == 1);
    assert(snap[0].first == 4);
    assert(snap[0].second == "x25");
    
    // E 2 - erase key 2 (doesn't exist)
    assert(cache.erase(2) == false);
    
    // G 2 - get key 2 (doesn't exist)
    std::string out;
    assert(cache.get(2, out) == false);
    assert(out == "UNCHANGED");
    
    // P 5 "日本3" - put key 5 with value "日本3"
    cache.put(5, "日本3");
    
    // E 9 - erase key 9 (doesn't exist)
    assert(cache.erase(9) == false);
    
    // P 2 "two words55" - put key 2
    cache.put(2, "two words55");
    
    // E 1 - erase key 1 (doesn't exist)
    assert(cache.erase(1) == false);
    
    // P 3 "日本18" - put key 3
    cache.put(3, "日本18");
    
    // P 3 "日本65" - update key 3
    cache.put(3, "日本65");
    
    // G 4 - get key 4
    assert(cache.get(4, out) == true);
    assert(out == "x25");
    
    // S - snapshot
    snap = cache.snapshot();
    assert(snap.size() == 4);
    
    // G 5 - get key 5
    assert(cache.get(5, out) == true);
    assert(out == "日本3");
    
    // P 6 "x8" - put key 6
    cache.put(6, "x8");
    
    // P 3 "x37" - update key 3
    cache.put(3, "x37");
    
    // P 6 "two words63" - update key 6
    cache.put(6, "two words63");
    
    // S - snapshot
    snap = cache.snapshot();
    assert(snap.size() == 5);
    
    // G 4 - get key 4
    assert(cache.get(4, out) == true);
    assert(out == "x25");
    
    // P 3 "two words79" - update key 3
    cache.put(3, "two words79");
    
    // P 2 "日本56" - update key 2
    cache.put(2, "日本56");
    
    // E 8 - erase key 8 (doesn't exist)
    assert(cache.erase(8) == false);
    
    // G 4 - get key 4
    assert(cache.get(4, out) == true);
    assert(out == "x25");
    
    // P 9 "日本33" - put key 9
    cache.put(9, "日本33");
    
    // P 0 "x28" - put key 0
    cache.put(0, "x28");
    
    // E 5 - erase key 5
    assert(cache.erase(5) == true);
    
    // Final size should be 5
    assert(cache.size() == 5);
    
    std::cout << "Complex scenario test passed" << std::endl;
}

int main() {
    test_basic_put_get();
    std::cout << "test_basic_put_get passed" << std::endl;
    
    test_eviction();
    std::cout << "test_eviction passed" << std::endl;
    
    test_update_doesnt_evict();
    std::cout << "test_update_doesnt_evict passed" << std::endl;
    
    test_get_makes_mru();
    std::cout << "test_get_makes_mru passed" << std::endl;
    
    test_erase();
    std::cout << "test_erase passed" << std::endl;
    
    test_snapshot();
    std::cout << "test_snapshot passed" << std::endl;
    
    test_snapshot_updates_mru();
    std::cout << "test_snapshot_updates_mru passed" << std::endl;
    
    test_capacity_zero();
    std::cout << "test_capacity_zero passed" << std::endl;
    
    test_get_miss_leaves_out_unchanged();
    std::cout << "test_get_miss_leaves_out_unchanged passed" << std::endl;
    
    test_complex_scenario();
    std::cout << "test_complex_scenario passed" << std::endl;
    
    std::cout << "\nAll tests passed!" << std::endl;
    return 0;
}
