# LRU Cache Implementation

A C++20 implementation of a Least Recently Used (LRU) cache with O(1) average time complexity for get, put, and erase operations.

## Features

- **O(1) average time complexity**: Uses a combination of hash map and doubly-linked list
- **C++20 standard**: Modern C++ features and best practices
- **RAII compliant**: Proper resource management with automatic cleanup
- **Thread-safe design**: Not thread-safe by design (follows standard library pattern)
- **Copy disabled**: Prevents accidental copying that could invalidate iterators

## API

```cpp
template<typename K, typename V>
class LruCache {
public:
    explicit LruCache(size_t capacity);
    
    // Insert or update a key-value pair. Makes key MRU.
    void put(const K& key, const V& value);
    
    // Get value by key. Makes key MRU. Returns false if not found.
    bool get(const K& key, V& out);
    
    // Erase a key. Returns true if key existed.
    bool erase(const K& key);
    
    // Current number of items in cache.
    size_t size() const;
    
    // Get all items in order from MRU to LRU.
    std::vector<std::pair<K, V>> snapshot() const;
};
```

## Usage Example

```cpp
#include "solution.hpp"
#include <iostream>

int main() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string value;
    if (cache.get(1, value)) {
        std::cout << "Got: " << value << std::endl;  // "one"
    }
    
    cache.put(4, "four");  // Evicts key 2 (LRU)
    
    auto snapshot = cache.snapshot();
    for (const auto& [key, value] : snapshot) {
        std::cout << key << ": " << value << std::endl;
    }
    
    return 0;
}
```

## Compilation

```bash
clang++ -std=c++20 -fuse-ld=bfd -o tests tests.cpp
./tests
```

## Implementation Details

- **Data structure**: `std::list` for ordering (MRU at front, LRU at back) + `std::unordered_map` for O(1) lookup
- **Eviction policy**: When capacity is reached, the least recently used item (back of list) is evicted
- **MRU update**: Both `get()` and `put()` operations make the accessed key most recently used
- **Snapshot**: Returns items in order from most to least recently used without affecting recency
