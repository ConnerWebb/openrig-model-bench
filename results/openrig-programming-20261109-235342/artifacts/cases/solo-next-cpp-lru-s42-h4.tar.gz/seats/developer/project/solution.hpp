#ifndef LRU_CACHE_HPP
#define LRU_CACHE_HPP

#include <list>
#include <unordered_map>
#include <vector>
#include <utility>

template<typename K, typename V>
class LruCache {
public:
    explicit LruCache(size_t capacity) : capacity_(capacity) {}

    void put(const K& key, const V& value) {
        auto it = map_.find(key);
        if (it != map_.end()) {
            // Key exists, update value in list and move to front
            it->second.second->second = value;
            list_.splice(list_.begin(), list_, it->second.second);
            return;
        }

        // Key doesn't exist, check if we need to evict
        if (capacity_ > 0 && list_.size() >= capacity_) {
            // Evict LRU (back of list)
            auto lru_key = list_.back().first;
            list_.pop_back();
            map_.erase(lru_key);
        }

        // Insert new key-value pair at front (only if capacity > 0)
        if (capacity_ > 0) {
            list_.push_front({key, value});
            map_[key] = {value, list_.begin()};
        }
    }

    bool get(const K& key, V& out) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }

        // Move to front (most recently used)
        list_.splice(list_.begin(), list_, it->second.second);
        out = it->second.first;
        return true;
    }

    bool erase(const K& key) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }

        list_.erase(it->second.second);
        map_.erase(it);
        return true;
    }

    size_t size() const {
        return list_.size();
    }

    std::vector<std::pair<K, V>> snapshot() const {
        std::vector<std::pair<K, V>> result;
        // Iterate from front (MRU) to back (LRU)
        for (auto it = list_.begin(); it != list_.end(); ++it) {
            result.push_back(*it);
        }
        return result;
    }

private:
    size_t capacity_;
    std::list<std::pair<K, V>> list_;  // Front = MRU, Back = LRU
    std::unordered_map<K, std::pair<V, typename std::list<std::pair<K, V>>::iterator>> map_;
};

#endif // LRU_CACHE_HPP
