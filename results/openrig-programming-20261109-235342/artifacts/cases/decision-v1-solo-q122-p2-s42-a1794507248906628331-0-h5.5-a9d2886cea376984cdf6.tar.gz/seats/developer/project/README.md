# Solution: CSV Aggregator

## Overview

This module implements a CSV aggregator that reads UTF-8 CSV files and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to totals formatted with exactly
        two decimal places, sorted by category key.
        
    Raises:
        ValueError: If the input is malformed (wrong header, invalid amounts,
                   empty categories, wrong field counts, etc.)
    """
```

## Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank record must have exactly two fields
- **Category**: Must not be empty after stripping whitespace
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits before optional decimal point
  - If decimal point present, 1-2 digits after it
  - Nonnegative, finite, no exponent notation
- **Blank records**: Completely blank lines are ignored
- **Quoting**: Standard CSV quoting rules apply (commas, newlines, and quotes in quoted fields)
- **Arithmetic**: Exact decimal arithmetic using Python's `decimal` module
- **Output**: Categories sorted alphabetically, amounts formatted with exactly 2 decimal places

## Usage

```python
from solution import aggregate

result = aggregate('input.csv')
print(result)  # {'food': '150.00', 'rent': '200.00'}
```

## Testing

Run the test suite:

```bash
python -m unittest test_solution.py
```

Or use the project's test runner:

```bash
run_tests
```

## Implementation Notes

- Uses Python's built-in `csv` module for proper CSV parsing (handles quoted fields, embedded newlines, escaped quotes)
- Uses `decimal.Decimal` for exact arithmetic to avoid floating-point errors
- Streams the file line by line via the csv reader
- Validates all input strictly, raising `ValueError` for any malformed data
