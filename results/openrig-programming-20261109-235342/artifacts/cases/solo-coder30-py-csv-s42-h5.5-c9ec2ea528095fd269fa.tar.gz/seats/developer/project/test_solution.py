import unittest
import tempfile
import os
from solution import aggregate

class TestAggregate(unittest.TestCase):
    
    def test_basic_functionality(self):
        # Test with the first case from public inputs
        csv_content = '''category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
'''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            os.unlink(f.name)
            
        expected = {
            'a,b': '599.14',
            'food': '2262.01',
            'rent': '2215.92',
            'two\nlines': '1434.24',
            'x"quote': '1458.60',
            '日本': '909.01'
        }
        self.assertEqual(result, expected)
    
    def test_empty_file(self):
        csv_content = '''category,amount
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            os.unlink(f.name)
        self.assertEqual(result, {})
    
    def test_blank_lines(self):
        csv_content = '''category,amount

food,100.00

rent,200.00

'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            os.unlink(f.name)
        expected = {'food': '100.00', 'rent': '200.00'}
        self.assertEqual(result, expected)
    
    def test_invalid_header(self):
        csv_content = '''wrong,amount
x,1
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_wrong_field_count(self):
        csv_content = '''category,amount
x,1,2
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_empty_category(self):
        csv_content = '''category,amount
,1
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_invalid_amount(self):
        csv_content = '''category,amount
x,NaN
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_negative_amount(self):
        csv_content = '''category,amount
x,-1.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

if __name__ == '__main__':
    unittest.main()