import csv
import decimal
from decimal import Decimal
from typing import Dict
import re

def aggregate(path: str) -> Dict[str, str]:
    """
    Aggregate CSV data by category, summing amounts with exact decimal arithmetic.
    
    Args:
        path: Path to UTF-8 CSV file with header 'category,amount'
        
    Returns:
        Dictionary with category keys sorted and totals formatted with exactly two decimal places
        
    Raises:
        ValueError: For malformed input
    """
    # Initialize result dictionary
    totals = {}
    
    # Set decimal precision high enough for exact arithmetic
    decimal.getcontext().prec = 50
    
    with open(path, 'r', encoding='utf-8') as f:
        # Use csv.reader to handle quoted fields and embedded newlines
        reader = csv.reader(f)
        
        # Read header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
            
        if header != ['category', 'amount']:
            raise ValueError("Header must be exactly 'category,amount'")
        
        # Process each row
        for row_num, row in enumerate(reader, start=2):  # Start at 2 since header is row 1
            # Skip completely blank records
            if not any(row):
                continue
                
            # Each row must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Row {row_num} must have exactly two fields")
                
            category, amount_str = row
            
            # Strip whitespace from category
            category = category.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError(f"Row {row_num} category must not be empty")
                
            # Parse amount with exact decimal arithmetic
            try:
                # Validate amount format: optional +, 1-12 digits, optional decimal point, 1-2 digits
                # Also check that it's not in exponential notation
                if 'e' in amount_str.lower():
                    raise ValueError(f"Row {row_num} amount must not contain exponent")
                
                amount = Decimal(amount_str)
                
                # Check if amount is finite and non-negative
                if not (amount.is_finite() and amount >= 0):
                    raise ValueError(f"Row {row_num} amount must be non-negative and finite")
                
                # Validate format: at most 12 digits before decimal point, at most 2 after
                amount_str_clean = str(amount)
                if '.' in amount_str_clean:
                    integer_part, decimal_part = amount_str_clean.split('.')
                    if len(integer_part) > 12:
                        raise ValueError(f"Row {row_num} amount must have at most 12 digits before decimal point")
                    if len(decimal_part) > 2:
                        raise ValueError(f"Row {row_num} amount must have at most 2 digits after decimal point")
                else:
                    # No decimal point - integer part
                    if len(amount_str_clean) > 12:
                        raise ValueError(f"Row {row_num} amount must have at most 12 digits before decimal point")
                    
            except (decimal.InvalidOperation, ValueError):
                raise ValueError(f"Row {row_num} amount must be a valid decimal number")
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly two decimal places and return sorted by category
    result = {}
    for category in sorted(totals.keys()):
        result[category] = format(totals[category], '.2f')
    
    return result