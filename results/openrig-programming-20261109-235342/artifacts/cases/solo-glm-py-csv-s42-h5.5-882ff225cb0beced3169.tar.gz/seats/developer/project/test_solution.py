import unittest
import os
import tempfile
import shutil
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def setUp(self):
        """Create a temporary directory for test files."""
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.temp_dir)

    def _create_test_file(self, filename, content):
        """Helper to create a test CSV file."""
        path = os.path.join(self.temp_dir, filename)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return path

    def test_valid_csv(self):
        """Test with valid CSV data."""
        csv_content = """category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
"""
        path = self._create_test_file('test.csv', csv_content)
        result = aggregate(path)

        expected = {
            "a,b": "599.14",
            "food": "2262.01",
            "rent": "2215.92",
            "two\nlines": "1434.24",
            "x\"quote": "1458.60",
            "日本": "909.01"
        }
        self.assertEqual(result, expected)

    def test_empty_file(self):
        """Test with empty file."""
        path = self._create_test_file('empty.csv', '')
        result = aggregate(path)
        self.assertEqual(result, {})

    def test_no_records(self):
        """Test with file containing only header."""
        csv_content = "category,amount\n"
        path = self._create_test_file('no_records.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {})

    def test_blank_records(self):
        """Test that blank records are ignored."""
        csv_content = """category,amount
food,100
rent,200

food,50
"""
        path = self._create_test_file('blank_records.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "150.00", "rent": "200.00"})

    def test_invalid_header(self):
        """Test with invalid header."""
        csv_content = "category,amount,extra\nfood,100\n"
        path = self._create_test_file('invalid_header.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Header must be exactly 'category,amount'", str(cm.exception))

    def test_wrong_header(self):
        """Test with wrong header."""
        csv_content = "cat,amount\nfood,100\n"
        path = self._create_test_file('wrong_header.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Header must be exactly 'category,amount'", str(cm.exception))

    def test_wrong_column_count(self):
        """Test with wrong number of columns."""
        csv_content = "category,amount\nfood,100,extra\n"
        path = self._create_test_file('wrong_columns.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("expected 2 fields", str(cm.exception))

    def test_empty_category(self):
        """Test with empty category."""
        csv_content = "category,amount\n,100\n"
        path = self._create_test_file('empty_category.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("empty category", str(cm.exception))

    def test_invalid_amount_format(self):
        """Test with invalid amount format."""
        csv_content = "category,amount\nfood,abc\n"
        path = self._create_test_file('invalid_amount.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("invalid amount", str(cm.exception))

    def test_negative_amount(self):
        """Test with negative amount."""
        csv_content = "category,amount\nfood,-100\n"
        path = self._create_test_file('negative_amount.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("invalid amount", str(cm.exception))

    def test_amount_with_exponent(self):
        """Test with amount containing exponent."""
        csv_content = "category,amount\nfood,1e2\n"
        path = self._create_test_file('exponent_amount.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("invalid amount", str(cm.exception))

    def test_amount_too_many_digits(self):
        """Test with amount having too many digits."""
        csv_content = "category,amount\nfood,1234567890123\n"
        path = self._create_test_file('many_digits.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("invalid amount", str(cm.exception))

    def test_amount_no_digits(self):
        """Test with amount having no digits."""
        csv_content = "category,amount\nfood,.\n"
        path = self._create_test_file('no_digits.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("invalid amount", str(cm.exception))

    def test_amount_decimal_too_many(self):
        """Test with amount having too many decimal places."""
        csv_content = "category,amount\nfood,1.234\n"
        path = self._create_test_file('many_decimals.csv', csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("invalid amount", str(cm.exception))

    def test_amount_with_plus(self):
        """Test with amount prefixed with +."""
        csv_content = "category,amount\nfood,+100.50\n"
        path = self._create_test_file('plus_amount.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.50"})

    def test_amount_with_leading_zeros(self):
        """Test with amount having leading zeros."""
        csv_content = "category,amount\nfood,00100.50\n"
        path = self._create_test_file('leading_zeros.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.50"})

    def test_amount_single_digit(self):
        """Test with single digit amount."""
        csv_content = "category,amount\nfood,5\n"
        path = self._create_test_file('single_digit.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "5.00"})

    def test_amount_two_decimal_places(self):
        """Test with amount having two decimal places."""
        csv_content = "category,amount\nfood,5.50\n"
        path = self._create_test_file('two_decimals.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "5.50"})

    def test_exact_decimal_arithmetic(self):
        """Test that exact decimal arithmetic is used."""
        csv_content = """category,amount
food,0.1
food,0.2
food,0.3
"""
        path = self._create_test_file('decimal_arithmetic.csv', csv_content)
        result = aggregate(path)
        # 0.1 + 0.2 + 0.3 = 0.6 exactly in decimal arithmetic
        self.assertEqual(result, {"food": "0.60"})

    def test_whitespace_in_category(self):
        """Test that whitespace is stripped from category."""
        csv_content = "category,amount\n  food  ,100\n"
        path = self._create_test_file('whitespace_category.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00"})

    def test_whitespace_in_amount(self):
        """Test that whitespace is stripped from amount."""
        csv_content = "category,amount\nfood, 100.50 \n"
        path = self._create_test_file('whitespace_amount.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.50"})

    def test_multiple_categories(self):
        """Test aggregation across multiple categories."""
        csv_content = """category,amount
food,100
rent,200
food,50
rent,50
"""
        path = self._create_test_file('multiple_categories.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "150.00", "rent": "250.00"})

    def test_sorted_output(self):
        """Test that output is sorted by category."""
        csv_content = """category,amount
z,100
a,200
m,300
"""
        path = self._create_test_file('sorted_output.csv', csv_content)
        result = aggregate(path)
        self.assertEqual(list(result.keys()), ['a', 'm', 'z'])


if __name__ == '__main__':
    unittest.main()