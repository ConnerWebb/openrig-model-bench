# CSV Aggregator

A Python module that reads CSV files and aggregates amounts by category using exact decimal arithmetic.

## Overview

The `aggregate` function reads a CSV file with a specific format and returns a dictionary mapping category names to their total amounts.

## Function Signature

```python
def aggregate(path: str) -> Dict[str, str]:
```

## CSV Format

The CSV file must have exactly two columns: `category` and `amount`.

### Header
- Must be exactly: `category,amount`
- Case-sensitive

### Records
- Each record must have exactly two fields
- Blank lines are ignored
- Whitespace is stripped from category and amount fields
- Category must not be empty after stripping

### Amount Format
- Optional leading `+` sign
- 1-12 digits
- Optional decimal point followed by 1 or 2 digits
- Non-negative, finite, no exponent notation
- Examples: `100`, `+50.75`, `0.01`, `123456789012.34`

### Quoted Fields
- CSV quoting is supported
- Fields can contain commas and newlines when quoted
- Example: `"two\nlines",849.77`

## Error Handling

The function raises `ValueError` for:
- Invalid header format
- Records with wrong number of fields
- Empty category names
- Invalid amount formats (negative, NaN, exponent, wrong digit count, etc.)

## Return Value

Returns a dictionary with:
- Keys: Category names (sorted alphabetically)
- Values: Total amounts formatted as strings with exactly 2 decimal places

## Example

### Input CSV
```csv
category,amount
food,347.25
rent,991.77
rent,345.17
food,261.47
```

### Output
```python
{
    "food": "608.72",
    "rent": "1336.94"
}
```

## Implementation Details

- Uses Python's `decimal.Decimal` for exact arithmetic
- Reads CSV using Python's built-in `csv` module
- Processes file as a stream (no need to read entire file into memory)
- UTF-8 encoding support

## Testing

Run the test suite with:
```bash
python -m unittest test_solution.py
```

## Requirements

- Python 3.14
- Standard library only (no external dependencies)