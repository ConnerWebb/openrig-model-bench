import csv
import re
from decimal import Decimal, InvalidOperation
from typing import Dict

# Amount regex: optional +, 1-12 digits, optional decimal point with 1-2 digits
_AMOUNT_RE = re.compile(r'^[+]?\d{1,12}(\.\d{1,2})?$')


def aggregate(path: str) -> Dict[str, str]:
    """
    Read a CSV file and aggregate amounts by category.

    Args:
        path: Path to the CSV file

    Returns:
        Dictionary mapping category names to total amounts (formatted as strings with 2 decimal places)

    Raises:
        ValueError: If the CSV header is malformed, any record is malformed, or amounts are invalid
    """
    totals: Dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)

        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            return {}

        if header != ['category', 'amount']:
            raise ValueError("Header must be exactly 'category,amount'")

        # Process each record
        for row_num, row in enumerate(reader, start=2):
            # Skip completely blank records
            if not row:
                continue

            # Every other record must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Row {row_num}: expected 2 fields, got {len(row)}")

            category, amount_str = row

            # Strip whitespace from category
            category = category.strip()
            if not category:
                raise ValueError(f"Row {row_num}: empty category")

            # Strip whitespace from amount
            amount_str = amount_str.strip()

            # Validate amount format
            if not _AMOUNT_RE.match(amount_str):
                raise ValueError(f"Row {row_num}: invalid amount '{amount_str}'")

            # Parse amount as Decimal
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Row {row_num}: invalid amount '{amount_str}'")

            # Accumulate using exact decimal arithmetic
            totals[category] = totals.get(category, Decimal('0')) + amount

    # Return sorted keys with totals formatted to 2 decimal places
    return {category: f"{total:.2f}" for category, total in sorted(totals.items())}