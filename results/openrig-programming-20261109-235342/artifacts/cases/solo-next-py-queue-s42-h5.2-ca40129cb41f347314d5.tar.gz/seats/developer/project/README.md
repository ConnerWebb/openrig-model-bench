# JobQueue

SQLite-based job queue with claim/complete/fail semantics.

## API

```python
from solution import JobQueue

# Create queue (shared across instances via same path)
q = JobQueue("path/to/db.sqlite", max_attempts=3)

# Add job (first unique key wins)
q.enqueue("job_key", {"data": 123})  # returns True/False

# Claim oldest queued/leased job (attempts < max_attempts)
job = q.claim("worker_name", now=0.0, lease=60.0)
# job = {"key": ..., "payload": ..., "attempts": ...} or None

# Mark job as done (owner must match current lease)
q.complete("job_key", "worker_name")  # returns True/False

# Mark job as failed; requeue unless exhausted
q.fail("job_key", "worker_name")  # returns True/False

# Inspect job state
status = q.status("job_key")  # {"state": ..., "attempts": ...} or None
```

## States

- `queued`: waiting to be claimed
- `leased`: currently claimed by a worker
- `done`: completed successfully
- `failed`: exhausted max_attempts

## Validation

- `key`, `worker` must be non-empty strings
- `lease` must be positive
- `max_attempts` must be positive integer
