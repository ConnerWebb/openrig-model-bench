import unittest
import os
import tempfile
import time
import json
from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')

    def tearDown(self):
        os.remove(self.db_path)

    def test_init(self):
        q = JobQueue(self.db_path)
        self.assertIsNotNone(q)

    def test_enqueue(self):
        q = JobQueue(self.db_path)
        result = q.enqueue('key1', {'data': 'test'})
        self.assertTrue(result)

    def test_enqueue_duplicate(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        result = q.enqueue('key1', {'data': 'test2'})
        self.assertFalse(result)

    def test_claim(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        result = q.claim('worker1', 0.0, 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result['key'], 'key1')
        self.assertEqual(result['payload'], {'data': 'test'})
        self.assertEqual(result['attempts'], 1)

    def test_claim_no_jobs(self):
        q = JobQueue(self.db_path)
        result = q.claim('worker1', 0.0, 10.0)
        self.assertIsNone(result)

    def test_claim_lease_not_expired(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        q.claim('worker1', 0.0, 100.0)
        result = q.claim('worker2', 50.0, 10.0)
        self.assertIsNone(result)

    def test_claim_max_attempts(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        for _ in range(3):
            q.claim('worker1', 0.0, 10.0)
        result = q.claim('worker2', 100.0, 10.0)
        self.assertIsNone(result)

    def test_complete(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        claim_result = q.claim('worker1', 0.0, 10.0)
        result = q.complete('key1', 'worker1')
        self.assertTrue(result)

    def test_complete_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        q.claim('worker1', 0.0, 10.0)
        result = q.complete('key1', 'worker2')
        self.assertFalse(result)

    def test_fail(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        q.claim('worker1', 0.0, 10.0)
        result = q.fail('key1', 'worker1')
        self.assertTrue(result)

    def test_fail_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        q.claim('worker1', 0.0, 10.0)
        result = q.fail('key1', 'worker2')
        self.assertFalse(result)

    def test_status(self):
        q = JobQueue(self.db_path)
        q.enqueue('key1', {'data': 'test'})
        status = q.status('key1')
        self.assertIsNotNone(status)
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)

    def test_status_not_found(self):
        q = JobQueue(self.db_path)
        status = q.status('nonexistent')
        self.assertIsNone(status)


if __name__ == '__main__':
    unittest.main()
