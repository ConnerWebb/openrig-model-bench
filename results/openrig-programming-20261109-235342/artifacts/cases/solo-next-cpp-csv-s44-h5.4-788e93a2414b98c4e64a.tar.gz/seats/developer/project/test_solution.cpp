#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 2) throw std::runtime_error("basic: wrong size");
    if (result["food"] != 100) throw std::runtime_error("basic: food");
    if (result["rent"] != 200) throw std::runtime_error("basic: rent");
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nfood,30\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["food"] != -20) throw std::runtime_error("negative: food");
}

void test_quoted_comma() {
    std::string input = "category,amount\n\"a,b\",100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("quoted_comma: size");
    if (result["a,b"] != 100) throw std::runtime_error("quoted_comma: key");
}

void test_quoted_newline() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("quoted_newline: size");
    if (result["two\nlines"] != 100) throw std::runtime_error("quoted_newline: key");
}

void test_escaped_quote() {
    std::string input = "category,amount\n\"x\"\"quote\",100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("escaped_quote: size");
    if (result["x\"quote"] != 100) throw std::runtime_error("escaped_quote: key");
}

void test_wrong_header() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("wrong_header: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_extra_field() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("extra_field: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("empty_category: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_nan() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("nan: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_unclosed_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("unclosed_quote: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_exponent() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("exponent: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_overflow() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("overflow: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_max_int64() {
    std::string input = "category,amount\nx,9223372036854775807\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["x"] != 9223372036854775807LL) throw std::runtime_error("max_int64: value");
}

void test_positive_sign() {
    std::string input = "category,amount\nx,+100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["x"] != 100) throw std::runtime_error("positive_sign: value");
}

void test_whitespace_trim() {
    std::string input = "category,amount\n  food  ,  +100  \n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("whitespace_trim: size");
    if (result["food"] != 100) throw std::runtime_error("whitespace_trim: value");
}

void test_empty_input() {
    std::string input = "";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("empty_input: should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_only_header() {
    std::string input = "category,amount\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (!result.empty()) throw std::runtime_error("only_header: should be empty");
}

int main() {
    std::cout << "Running test_basic..." << std::endl;
    test_basic();
    std::cout << "Running test_negative..." << std::endl;
    test_negative();
    std::cout << "Running test_quoted_comma..." << std::endl;
    test_quoted_comma();
    std::cout << "Running test_quoted_newline..." << std::endl;
    test_quoted_newline();
    std::cout << "Running test_escaped_quote..." << std::endl;
    test_escaped_quote();
    std::cout << "Running test_wrong_header..." << std::endl;
    test_wrong_header();
    std::cout << "Running test_extra_field..." << std::endl;
    test_extra_field();
    std::cout << "Running test_empty_category..." << std::endl;
    test_empty_category();
    std::cout << "Running test_nan..." << std::endl;
    test_nan();
    std::cout << "Running test_unclosed_quote..." << std::endl;
    test_unclosed_quote();
    std::cout << "Running test_exponent..." << std::endl;
    test_exponent();
    std::cout << "Running test_overflow..." << std::endl;
    test_overflow();
    std::cout << "Running test_max_int64..." << std::endl;
    test_max_int64();
    std::cout << "Running test_positive_sign..." << std::endl;
    test_positive_sign();
    std::cout << "Running test_whitespace_trim..." << std::endl;
    test_whitespace_trim();
    std::cout << "Running test_empty_input..." << std::endl;
    test_empty_input();
    std::cout << "Running test_only_header..." << std::endl;
    test_only_header();
    std::cout << "All tests passed" << std::endl;
    return 0;
}
