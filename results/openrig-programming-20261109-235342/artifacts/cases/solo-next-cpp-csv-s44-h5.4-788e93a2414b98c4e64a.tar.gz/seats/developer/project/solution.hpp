#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <cstdint>
#include <stdexcept>
#include <cctype>

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

bool is_digit(char c) { return c >= '0' && c <= '9'; }

bool parse_int64(const std::string& s, std::int64_t& out) {
    if (s.empty()) return false;
    std::size_t idx = 0;
    bool negative = false;
    if (s[idx] == '+') {
        ++idx;
    } else if (s[idx] == '-') {
        negative = true;
        ++idx;
    }
    if (idx >= s.size()) return false;
    if (!is_digit(s[idx])) return false;
    // No leading zeros allowed except for "0" itself
    if (s[idx] == '0' && idx + 1 < s.size() && is_digit(s[idx + 1])) return false;
    std::uint64_t val = 0;
    for (std::size_t i = idx; i < s.size(); ++i) {
        char c = s[i];
        if (!is_digit(c)) return false;
        std::uint64_t digit = static_cast<std::uint64_t>(c - '0');
        if (val > (std::numeric_limits<std::int64_t>::max() - digit) / 10) return false;
        val = val * 10 + digit;
    }
    if (negative) {
        const std::uint64_t max_neg = static_cast<std::uint64_t>(-(std::numeric_limits<std::int64_t>::min() + 1)) + 1;
        if (val > max_neg) return false;
        out = static_cast<std::int64_t>(-val);
    } else {
        if (val > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())) return false;
        out = static_cast<std::int64_t>(val);
    }
    return true;
}

}

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::string header_line;
    if (!std::getline(in, header_line)) {
        throw std::invalid_argument("empty input");
    }
    // Strip trailing CR if present
    if (!header_line.empty() && header_line.back() == '\r') {
        header_line.pop_back();
    }
    if (header_line != "category,amount") {
        throw std::invalid_argument("invalid header");
    }

    std::map<std::string, std::int64_t> result;
    std::string category;
    std::string amount_str;
    bool in_quotes = false;
    bool first_field = true;

    int c;
    while ((c = in.get()) != EOF) {
        char ch = static_cast<char>(c);

        // Handle CR
        if (ch == '\r') {
            continue;
        }

        // Handle newline - only as line separator when not in quotes
        if (ch == '\n') {
            if (!in_quotes) {
                // End of record
                if (first_field) {
                    // End of category field
                    first_field = false;
                } else {
                    // End of amount field - process record
                    category = trim(category);
                    amount_str = trim(amount_str);
                    if (category.empty()) {
                        throw std::invalid_argument("empty category after trim");
                    }
                    std::int64_t amount;
                    if (!parse_int64(amount_str, amount)) {
                        throw std::invalid_argument("invalid amount");
                    }
                    // Check for overflow when adding
                    if ((amount > 0 && result[category] > std::numeric_limits<std::int64_t>::max() - amount) ||
                        (amount < 0 && result[category] < std::numeric_limits<std::int64_t>::min() - amount)) {
                        throw std::invalid_argument("overflow");
                    }
                    result[category] += amount;
                    category.clear();
                    amount_str.clear();
                    first_field = true;
                }
                continue;
            }
            // Inside quotes, just add the newline
            if (first_field) {
                category += ch;
            } else {
                amount_str += ch;
            }
            continue;
        }

        if (first_field) {
            // First field (category)
            if (ch == '"') {
                if (in_quotes) {
                    // Check for escaped quote
                    int next = in.peek();
                    if (next == '"') {
                        in.get(); // consume the second quote
                        category += '"';
                    } else {
                        in_quotes = false;
                    }
                } else {
                    in_quotes = true;
                }
            } else if (ch == ',' && !in_quotes) {
                // End of category
                first_field = false;
            } else {
                category += ch;
            }
        } else {
            // Second field (amount)
            if (ch == '"') {
                if (in_quotes) {
                    // Check for escaped quote
                    int next = in.peek();
                    if (next == '"') {
                        in.get(); // consume the second quote
                        amount_str += '"';
                    } else {
                        in_quotes = false;
                    }
                } else {
                    in_quotes = true;
                }
            } else {
                amount_str += ch;
            }
        }
    }

    // Check for unclosed quote at end of input
    if (in_quotes) {
        throw std::invalid_argument("unclosed quote");
    }

    return result;
}

#endif // SOLUTION_HPP
