# CSV Aggregator

This project implements a CSV parser and aggregator for financial data.

## API

```cpp
std::map<std::string, std::int64_t> aggregate(std::istream& in);
```

Parses CSV input with header `category,amount` and returns a map of category totals.

### Input Format

- Header line: `category,amount`
- Fields: category (string), amount (int64)
- Quoted fields: `"value"` with `""` for escaped quotes
- Newlines in quoted fields are preserved

### Error Handling

Throws `std::invalid_argument` for:
- Empty input
- Invalid header
- Empty category
- Invalid amount (non-integer, NaN, exponent notation)
- Overflow (value exceeds int64 or sum overflows)
- Unclosed quotes
- Extra fields

## Building

```bash
clang++ -std=c++20 -Wall -Wextra -o test test.cpp solution.hpp
```
