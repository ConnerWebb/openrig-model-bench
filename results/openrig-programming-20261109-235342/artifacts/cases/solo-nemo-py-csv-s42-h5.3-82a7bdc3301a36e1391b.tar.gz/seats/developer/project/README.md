# Solution Overview

This project implements a CSV aggregation tool that reads a CSV file with headers `category` and `amount`, processes the data according to specific rules, and outputs the aggregated totals per category.

## Features

- **CSV Parsing**: Reads UTF-8 encoded CSV files with `category` and `amount` headers.
- **Data Validation**: 
  - Skips completely blank lines.
  - Validates that each non-blank line has exactly two fields.
  - Strips whitespace from category and amount fields.
  - Ensures category is non-empty.
  - Validates amount format: optional leading `+`, digits, optional decimal point with 1 or 2 digits.
  - Converts amount to `Decimal` for exact arithmetic.
- **Aggregation**: Accumulates amounts per category using exact decimal arithmetic.
- **Output**: Returns a dictionary with categories as keys (sorted) and totals formatted to exactly two decimal places.

## Usage

Run the script from the command line:

```bash
python solution.py <csv_file>
```

The script will print each category and its aggregated total, sorted by category name.

## Testing

The project includes public test cases in `public-inputs/` and a test suite that can be run with `run_tests`. The implementation adheres to the specified API contract and validation rules.

## License

This project is provided as-is for educational purposes.