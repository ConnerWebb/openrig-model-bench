import csv
import sys
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    totals = {}
    with open(path, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader, None)
        if header is None:
            return {}
        # Validate header
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid CSV header")
        
        for row_num, row in enumerate(reader, start=2):  # start=2 accounts for header line
            if not row:  # skip completely blank lines
                continue
            if len(row) != 2:
                raise ValueError(f"Line {row_num}: expected 2 fields, got {len(row)}")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            if not category:
                raise ValueError(f"Line {row_num}: category is empty")
            
            # Validate amount format: optional +, digits, optional decimal point with 1 or 2 digits
            if not _is_valid_amount(amount_str):
                raise ValueError(f"Line {row_num}: invalid amount format: {amount_str}")
            
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Line {row_num}: cannot convert amount to decimal: {amount_str}")
            
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format the result with exactly two decimal places
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}

def _is_valid_amount(s: str) -> bool:
    # Strip leading + if present
    if s.startswith('+'):
        s = s[1:]
    
    # Check for empty string after stripping +
    if not s:
        return False
    
    # Check if it contains a decimal point
    if '.' in s:
        # Split into integer and fractional parts
        parts = s.split('.')
        if len(parts) != 2:
            return False
        integer_part, fractional_part = parts
        # Integer part can be digits only (at least one digit)
        if not integer_part.isdigit():
            return False
        # Fractional part must be 1 or 2 digits
        if len(fractional_part) not in (1, 2) or not fractional_part.isdigit():
            return False
        return True
    else:
        # No decimal point, must be digits only
        return s.isdigit()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python solution.py <csv_file>")
        sys.exit(1)
    
    path = sys.argv[1]
    try:
        result = aggregate(path)
        for category, total in result.items():
            print(f"{category}: {total}")
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)