import unittest
from solution import aggregate
import os
import tempfile

class TestAggregate(unittest.TestCase):
    def test_valid_csv(self):
        # Test with a simple valid CSV
        result = aggregate('public-inputs/case-00.csv')
        expected = {
            'a,b': '599.14',
            'food': '2262.01',
            'rent': '2215.92',
            'two\nlines': '1434.24',
            'x"quote': '1458.60',
            '日本': '909.01'
        }
        self.assertEqual(result, expected)

    def test_empty_csv(self):
        # Test with an empty CSV (only header)
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount\n')
            temp_path = f.name
        try:
            result = aggregate(temp_path)
            self.assertEqual(result, {})
        finally:
            os.unlink(temp_path)

    def test_invalid_header(self):
        # Test with invalid header
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('wrong,amount\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_invalid_amount_format(self):
        # Test with invalid amount format
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount\nx,invalid\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_invalid_amount_too_many_decimals(self):
        # Test with too many decimal places
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount\nx,1.123\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_negative_amount(self):
        # Test with negative amount (should be rejected)
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount\nx,-1\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_missing_category(self):
        # Test with missing category
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write(',1\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_missing_amount(self):
        # Test with missing amount
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount\nx,\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_too_many_fields(self):
        # Test with too many fields
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount,x\n')
            temp_path = f.name
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)

    def test_large_number(self):
        # Test with a very large number
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            f.write('category,amount\nx,1000000000000\n')
            temp_path = f.name
        try:
            result = aggregate(temp_path)
            self.assertEqual(result, {'x': '1000000000000.00'})
        finally:
            os.unlink(temp_path)

if __name__ == '__main__':
    unittest.main()