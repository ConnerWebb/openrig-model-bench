import unittest
import sqlite3
import json
import time
import os
import tempfile

class JobQueue:
    def __init__(self, db_path: str, max_attempts: int = 3):
        self.db_path = db_path
        self.max_attempts = max_attempts
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self._init_db()

    def _init_db(self):
        cur = self.conn.cursor()
        cur.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT,
                attempts INTEGER,
                owner TEXT,
                lease_until REAL,
                done INTEGER
            )
        ''')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_state ON jobs(state)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_lease_until ON jobs(lease_until)')
        self.conn.commit()

    def enqueue(self, key: str, payload) -> bool:
        if not isinstance(key, str) or not key:
            raise ValueError('Key must be a non-empty string')
        cur = self.conn.cursor()
        cur.execute('SELECT 1 FROM jobs WHERE key = ?', (key,))
        if cur.fetchone() is not None:
            raise ValueError(f'Key \'{key}\' already exists')
        cur.execute('''
            INSERT INTO jobs (key, payload, state, attempts, owner, lease_until, done)
            VALUES (?, ?, 'queued', 0, ?, ?, 0)
        ''', (key, json.dumps(payload), self._get_worker(), time.time() + 3600))
        self.conn.commit()
        return True

    def claim(self, worker: str, now: float, lease: float) -> dict:
        if not isinstance(worker, str) or not worker:
            raise ValueError('Worker must be a non-empty string')
        if lease <= 0:
            raise ValueError('Lease must be positive')
        cur = self.conn.cursor()
        cur.execute('''
            SELECT rowid, key, payload, state, attempts, owner, lease_until, done
            FROM jobs
            WHERE state IN ('queued', 'leased')
              AND attempts < ?
              AND (state != 'leased' OR lease_until <= ?)
            ORDER BY rowid ASC
            LIMIT 1
        ''', (self.max_attempts, now))
        row = cur.fetchone()
        if not row:
            return None
        rowid, key, payload, state, attempts, owner, lease_until, done = row
        cur.execute('''
            UPDATE jobs SET state = 'leased', owner = ?, lease_until = ? WHERE rowid = ?
        ''', (worker, now + lease, rowid))
        self.conn.commit()
        return {
            'key': key,
            'payload': json.loads(payload),
            'attempts': attempts
        }

    def complete(self, key: str, worker: str) -> bool:
        cur = self.conn.conn.cursor()
        cur.execute('''
            UPDATE jobs SET state = 'done', done = 1 WHERE key = ? AND owner = ? AND state = 'leased'
        ''', (key, worker))
        self.conn.commit()
        return True

    def fail(self, key: str, worker: str) -> bool:
        cur = self.conn.cursor()
        cur.execute('''
            SELECT state FROM jobs WHERE key = ? AND owner = ?
        ''', (key, worker))
        if not cur.fetchone():
            raise ValueError('Job does not exist or is not owned by worker')
        # Get current attempts
        cur.execute('SELECT attempts FROM jobs WHERE key = ? AND owner = ?', (key, worker))
        attempts = cur.fetchone()[0]
        if attempts + 1 >= self.max_attempts:
            cur.execute('UPDATE jobs SET state = \"failed\" WHERE key = ? AND owner = ?', (key, worker))
        else:
            cur.execute('UPDATE jobs SET state = \"queued\" WHERE key = ? AND owner = ?', (key, worker))
        self.conn.commit()
        return True

    def status(self, key: str) -> dict:
        cur = self.conn.cursor()
        cur.execute('SELECT state, attempts FROM jobs WHERE key = ?', (key,))
        row = cur.fetchone()
        if not row:
            return None
        state, attempts = row
        return {'state': state, 'attempts': attempts}

    def _get_worker(self) -> str:
        # Return a unique identifier for the worker
        return 'worker_' + str(int(time.time()))

    def close(self):
        self.conn.close()

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')
        
        # Load case 0
        import json
        with open('/work/public-inputs/case-00.json', 'r') as f:
            case0 = json.load(f)
        self.ops = case0['ops']

    def test_exact_sequence(self):
        \"\"\"Test the exact sequence from case 0\"\"\"
        queue = JobQueue(self.db_path, max_attempts=3)
        results = []

        for op in self.ops:
            try:
                if op[0] == 'enqueue':
                    result = queue.enqueue(op[1], op[2])
                    results.append(result)
                elif op[0] == 'claim':
                    result = queue.claim(op[1], op[2], op[3])
                    results.append(result)
                elif op[0] == 'complete':
                    result = queue.complete(op[1], op[2])
                    results.append(result)
                elif op[0] == 'fail':
                    result = queue.fail(op[1], op[2])
                    results.append(result)
                elif op[0] == 'status':
                    result = queue.status(op[1])
                    results.append(result)
            except Exception as e:
                results.append({'error': str(e)})

        # Expected results
        expected = [
            True,  # enqueue a with payload {'v': 5304}
            False, # enqueue a again should fail
            {'key': 'a', 'payload': {'v': 5304}, 'attempts': 1},  # claim should succeed
            False, # complete with 'wrong' worker should fail
            True,  # fail should succeed
            {'key': 'a', 'payload': {'v': 5304}, 'attempts': 2},  # claim again should succeed
            True,  # complete with correct worker should succeed
            {'state': 'done', 'attempts': 2},  # status should show done with attempts 2
            None   # final status should return None
        ]

        self.assertEqual(results, expected)

if __name__ == '__main__':
    unittest.main()
