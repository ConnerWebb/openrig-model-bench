# Buffer Library

A C++20 RAII buffer implementation with bounds-checked access.

## Features

- `Buffer(size_t n=0)` - Constructor with optional size
- `size() const noexcept` - Returns buffer size
- `operator[](size_t)` - Bounds-checked mutable access (throws `std::out_of_range`)
- `const operator[](size_t)` - Bounds-checked const access
- `resize(size_t)` - Resizes buffer, preserving prefix and zero-initializing new bytes
- Deep-copy construction and assignment
- `noexcept` move construction and assignment
- Moved-from buffers have size 0 and are reusable
- Self-copy/self-move preserve content
- RAII with no leaks, double frees, or undefined behavior

## Usage

```cpp
#include "solution.hpp"

// Create buffer with size
Buffer b(20);

// Access elements
b[0] = 42;
auto val = b[0];

// Resize
b.resize(25);  // New bytes are zero-initialized

// Copy
Buffer c(b);
c = b;

// Move
Buffer d(std::move(b));
```

## Tests

Run `tests/test_buffer.cpp` to verify the implementation.
