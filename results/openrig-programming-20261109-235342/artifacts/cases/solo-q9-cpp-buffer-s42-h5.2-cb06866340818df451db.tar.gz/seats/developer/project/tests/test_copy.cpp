#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

int main() {
    Buffer b(5);
    for (int i = 0; i < 5; i++) {
        b[i] = static_cast<uint8_t>(i);
    }
    std::cout << "b.size() = " << b.size() << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "b[" << i << "] = " << (int)b[i] << std::endl;
    }
    
    Buffer c(3);
    for (int i = 0; i < 3; i++) {
        c[i] = static_cast<uint8_t>(100 + i);
    }
    std::cout << "c.size() = " << c.size() << std::endl;
    for (int i = 0; i < 3; i++) {
        std::cout << "c[" << i << "] = " << (int)c[i] << std::endl;
    }
    
    c = b;
    std::cout << "After c = b:" << std::endl;
    std::cout << "c.size() = " << c.size() << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "c[" << i << "] = " << (int)c[i] << std::endl;
    }
    std::cout << "b.size() = " << b.size() << std::endl;
    for (int i = 0; i < 5; i++) {
        std::cout << "b[" << i << "] = " << (int)b[i] << std::endl;
    }
    
    return 0;
}
