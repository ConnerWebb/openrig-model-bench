#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <memory>
#include <algorithm>

class Buffer {
public:
    using value_type = std::uint8_t;
    using size_type = std::size_t;
    using difference_type = std::ptrdiff_t;
    using pointer = value_type*;
    using const_pointer = const value_type*;
    using reference = value_type&;
    using const_reference = const value_type&;
    using iterator = pointer;
    using const_iterator = const_pointer;
    using reverse_iterator = std::reverse_iterator<iterator>;
    using const_reverse_iterator = std::reverse_iterator<const_iterator>;

private:
    std::unique_ptr<std::uint8_t[]> p_;
    std::size_t n_;

public:
    // Default constructor (size 0)
    Buffer() noexcept : p_(nullptr), n_(0) {}

    // Constructor with size
    explicit Buffer(std::size_t n) noexcept : p_(nullptr), n_(0) {
        if (n > 0) {
            p_.reset(new std::uint8_t[n]);
            std::fill(p_.get(), p_.get() + n, std::uint8_t{0});
        }
        n_ = n;
    }

    // Copy constructor
    Buffer(const Buffer& other) noexcept : p_(nullptr), n_(0) {
        if (other.n_ > 0) {
            n_ = other.n_;
            p_.reset(new std::uint8_t[n_]);
            std::copy(other.p_.get(), other.p_.get() + n_, p_.get());
        }
    }

    // Move constructor
    Buffer(Buffer&& other) noexcept : p_(std::move(other.p_)), n_(other.n_) {
        other.n_ = 0;
        other.p_.reset();
    }

    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::size_t old_n = n_;
            n_ = other.n_;
            if (n_ > 0) {
                p_.reset(new std::uint8_t[n_]);
                std::copy(other.p_.get(), other.p_.get() + n_, p_.get());
            } else {
                p_.reset();
            }
            // Zero-initialize new bytes if growing
            if (n_ > old_n) {
                std::fill(p_.get() + old_n, p_.get() + n_, std::uint8_t{0});
            }
        }
        return *this;
    }

    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            p_ = std::move(other.p_);
            std::size_t old_n = n_;
            n_ = other.n_;
            other.n_ = 0;
            other.p_.reset();
            // Zero-initialize new bytes if growing
            if (n_ > old_n) {
                std::fill(p_.get() + old_n, p_.get() + n_, std::uint8_t{0});
            }
        }
        return *this;
    }

    // Destructor (RAII - unique_ptr handles cleanup)
    ~Buffer() = default;

    // Get size
    std::size_t size() const noexcept {
        return n_;
    }

    // Bounds-checked access (mutable)
    reference operator[](std::size_t i) {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    // Bounds-checked access (const)
    const_reference operator[](std::size_t i) const {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    // Resize - preserves prefix, zero-initializes new bytes
    void resize(std::size_t n) {
        if (n < n_) {
            // Shrinking: truncate
            std::unique_ptr<std::uint8_t[]> old_p = std::move(p_);
            p_.reset();
            n_ = n;
            if (n_ > 0) {
                p_.reset(new std::uint8_t[n_]);
                std::copy(old_p.get(), old_p.get() + n_, p_.get());
            }
        } else {
            // Growing: zero-initialize new bytes
            std::size_t old_n = n_;
            n_ = n;
            if (n_ > 0) {
                if (p_ == nullptr) {
                    p_.reset(new std::uint8_t[n_]);
                    std::fill(p_.get(), p_.get() + n_, std::uint8_t{0});
                } else {
                    std::unique_ptr<std::uint8_t[]> old_p(std::move(p_));
                    p_.reset(new std::uint8_t[n_]);
                    std::copy(old_p.get(), old_p.get() + old_n, p_.get());
                    std::fill(p_.get() + old_n, p_.get() + n_, std::uint8_t{0});
                }
            }
        }
    }

    // Check if empty
    bool empty() const noexcept {
        return n_ == 0;
    }

    // Get pointer to data
    pointer data() noexcept {
        return p_.get();
    }

    // Get const pointer to data
    const_pointer data() const noexcept {
        return p_.get();
    }
};
