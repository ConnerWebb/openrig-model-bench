#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "../solution.hpp"

// Test framework for Buffer class
class BufferTest {
public:
    static void run_all_tests() {
        test_constructor_default();
        test_constructor_size();
        test_constructor_with_values();
        test_size();
        test_operator_bracket_mutable();
        test_operator_bracket_const();
        test_operator_bracket_out_of_range();
        test_resize_grow();
        test_resize_shrink();
        test_resize_same();
        test_deep_copy_constructor();
        test_deep_copy_assignment();
        test_move_constructor();
        test_move_assignment();
        test_move_from_size_zero();
        test_self_copy_preserves();
        test_self_move_preserves();
        test_empty();
        test_data();
        test_raii_no_leak();
        test_zero_init_new_bytes();
        test_copy_preserves_prefix();
        test_move_preserves_prefix();
        test_exception_safe();
        
        std::cout << "All tests passed!" << std::endl;
    }

private:
    static void test_constructor_default() {
        Buffer b;
        assert(b.size() == 0);
        assert(b.empty() == true);
        std::cout << "  test_constructor_default passed" << std::endl;
    }

    static void test_constructor_size() {
        Buffer b(5);
        assert(b.size() == 5);
        assert(b.empty() == false);
        std::cout << "  test_constructor_size passed" << std::endl;
    }

    static void test_constructor_with_values() {
        std::vector<int> values = {4, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97};
        Buffer b(20);
        for (int i = 0; i < 20; i++) {
            b[i] = values[i];
        }
        for (int i = 0; i < 20; i++) {
            assert(b[i] == values[i]);
        }
        std::cout << "  test_constructor_with_values passed" << std::endl;
    }

    static void test_size() {
        Buffer b(10);
        for (int i = 0; i < 10; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        assert(b.size() == 10);
        b.resize(15);
        assert(b.size() == 15);
        std::cout << "  test_size passed" << std::endl;
    }

    static void test_operator_bracket_mutable() {
        Buffer b(5);
        b[0] = 42;
        assert(b[0] == 42);
        std::cout << "  test_operator_bracket_mutable passed" << std::endl;
    }

    static void test_operator_bracket_const() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        const Buffer cb = b;
        assert(cb[0] == 0);
        std::cout << "  test_operator_bracket_const passed" << std::endl;
    }

    static void test_operator_bracket_out_of_range() {
        Buffer b(5);
        try {
            b[5];
            assert(false); // Should have thrown
        } catch (const std::out_of_range&) {
            // Expected
        }
        std::cout << "  test_operator_bracket_out_of_range passed" << std::endl;
    }

    static void test_resize_grow() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        b.resize(10);
        assert(b.size() == 10);
        for (int i = 0; i < 5; i++) {
            assert(b[i] == static_cast<uint8_t>(i));
        }
        for (int i = 5; i < 10; i++) {
            assert(b[i] == 0);
        }
        std::cout << "  test_resize_grow passed" << std::endl;
    }

    static void test_resize_shrink() {
        Buffer b(10);
        for (int i = 0; i < 10; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        b.resize(5);
        assert(b.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(b[i] == static_cast<uint8_t>(i));
        }
        std::cout << "  test_resize_shrink passed" << std::endl;
    }

    static void test_resize_same() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        b.resize(5);
        assert(b.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(b[i] == static_cast<uint8_t>(i));
        }
        std::cout << "  test_resize_same passed" << std::endl;
    }

    static void test_deep_copy_constructor() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c(b);
        assert(c.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(c[i] == b[i]);
        }
        std::cout << "  test_deep_copy_constructor passed" << std::endl;
    }

    static void test_deep_copy_assignment() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c(3);
        for (int i = 0; i < 3; i++) {
            c[i] = static_cast<uint8_t>(100 + i);
        }
        c = b;
        assert(c.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(c[i] == b[i]);
        }
        std::cout << "  test_deep_copy_assignment passed" << std::endl;
    }

    static void test_move_constructor() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c(std::move(b));
        assert(c.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(c[i] == static_cast<uint8_t>(i));
        }
        assert(b.size() == 0);
        std::cout << "  test_move_constructor passed" << std::endl;
    }

    static void test_move_assignment() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c(3);
        for (int i = 0; i < 3; i++) {
            c[i] = static_cast<uint8_t>(100 + i);
        }
        c = std::move(b);
        assert(c.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(c[i] == static_cast<uint8_t>(i));
        }
        assert(b.size() == 0);
        std::cout << "  test_move_assignment passed" << std::endl;
    }

    static void test_move_from_size_zero() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c(std::move(b));
        assert(c.size() == 5);
        assert(b.size() == 0);
        // b should be reusable
        b.resize(3);
        b[0] = 1;
        b[1] = 2;
        b[2] = 3;
        assert(b.size() == 3);
        assert(b[0] == 1);
        std::cout << "  test_move_from_size_zero passed" << std::endl;
    }

    static void test_self_copy_preserves() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c = b;
        assert(c.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(c[i] == b[i]);
        }
        std::cout << "  test_self_copy_preserves passed" << std::endl;
    }

    static void test_self_move_preserves() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        Buffer c = std::move(b);
        assert(c.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(c[i] == static_cast<uint8_t>(i));
        }
        assert(b.size() == 0);
        std::cout << "  test_self_move_preserves passed" << std::endl;
    }

    static void test_empty() {
        Buffer b;
        assert(b.empty() == true);
        Buffer b2(5);
        assert(b2.empty() == false);
        std::cout << "  test_empty passed" << std::endl;
    }

    static void test_data() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        assert(b.data() != nullptr);
        std::cout << "  test_data passed" << std::endl;
    }

    static void test_raii_no_leak() {
        {
            Buffer b(5);
            for (int i = 0; i < 5; i++) {
                b[i] = static_cast<uint8_t>(i);
            }
        } // b goes out of scope, should be cleaned up
        std::cout << "  test_raii_no_leak passed" << std::endl;
    }

    static void test_zero_init_new_bytes() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        b.resize(10);
        for (int i = 5; i < 10; i++) {
            assert(b[i] == 0);
        }
        std::cout << "  test_zero_init_new_bytes passed" << std::endl;
    }

    static void test_copy_preserves_prefix() {
        Buffer b(10);
        for (int i = 0; i < 10; i++) {
            b[i] = static_cast<uint8_t>(255 - i);
        }
        Buffer c(b);
        for (int i = 0; i < 10; i++) {
            assert(c[i] == b[i]);
        }
        std::cout << "  test_copy_preserves_prefix passed" << std::endl;
    }

    static void test_move_preserves_prefix() {
        Buffer b(10);
        for (int i = 0; i < 10; i++) {
            b[i] = static_cast<uint8_t>(255 - i);
        }
        Buffer c(std::move(b));
        for (int i = 0; i < 10; i++) {
            assert(c[i] == static_cast<uint8_t>(255 - i));
        }
        std::cout << "  test_move_preserves_prefix passed" << std::endl;
    }

    static void test_exception_safe() {
        Buffer b(5);
        for (int i = 0; i < 5; i++) {
            b[i] = static_cast<uint8_t>(i);
        }
        try {
            b[10];
            assert(false);
        } catch (const std::out_of_range&) {
            // Expected
        }
        assert(b.size() == 5);
        for (int i = 0; i < 5; i++) {
            assert(b[i] == static_cast<uint8_t>(i));
        }
        std::cout << "  test_exception_safe passed" << std::endl;
    }
};

int main() {
    try {
        BufferTest::run_all_tests();
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Test failed with exception: " << e.what() << std::endl;
        return 1;
    }
}
