#pragma once
#include <cstdint>
#include <stdexcept>

class RunningStats {
public:
    void add(double x);
    void merge(const RunningStats& other);
    std::uint64_t count() const;
    double mean() const;
    double variance() const;
    double minimum() const;
    double maximum() const;

private:
    std::uint64_t n = 0;
    double minVal = 0;
    double maxVal = 0;
    double meanVal = 0;
    double M2 = 0;
};
