#include "stats.hpp"
#include <cmath>
#include <limits>

void RunningStats::add(double x) {
    if (std::isnan(x) || std::isinf(x)) {
        throw std::invalid_argument("NaN or infinity not allowed");
    }
    
    if (n == 0) {
        minVal = x;
        maxVal = x;
        meanVal = x;
        n = 1;
        return;
    }
    
    double delta = x - meanVal;
    meanVal += delta / static_cast<double>(n + 1);
    double delta2 = x - meanVal;
    M2 += delta * delta2;
    
    if (x < minVal) minVal = x;
    if (x > maxVal) maxVal = x;
    
    n++;
}

void RunningStats::merge(const RunningStats& other) {
    if (other.n == 0) {
        return;
    }
    
    if (n == 0) {
        n = other.n;
        minVal = other.minVal;
        maxVal = other.maxVal;
        meanVal = other.meanVal;
        M2 = other.M2;
        return;
    }
    
    double combinedCount = static_cast<double>(n + other.n);
    double delta = other.meanVal - meanVal;
    
    meanVal = (meanVal * static_cast<double>(n) + other.meanVal * static_cast<double>(other.n)) / combinedCount;
    M2 += other.M2 + delta * delta * static_cast<double>(n) * static_cast<double>(other.n) / combinedCount;
    
    if (other.minVal < minVal) minVal = other.minVal;
    if (other.maxVal > maxVal) maxVal = other.maxVal;
    
    n += other.n;
}

std::uint64_t RunningStats::count() const {
    return n;
}

double RunningStats::mean() const {
    if (n == 0) {
        throw std::domain_error("mean() called on empty RunningStats");
    }
    return meanVal;
}

double RunningStats::variance() const {
    if (n == 0) {
        throw std::domain_error("variance() called on empty RunningStats");
    }
    return M2 / static_cast<double>(n);
}

double RunningStats::minimum() const {
    if (n == 0) {
        throw std::domain_error("minimum() called on empty RunningStats");
    }
    return minVal;
}

double RunningStats::maximum() const {
    if (n == 0) {
        throw std::domain_error("maximum() called on empty RunningStats");
    }
    return maxVal;
}
