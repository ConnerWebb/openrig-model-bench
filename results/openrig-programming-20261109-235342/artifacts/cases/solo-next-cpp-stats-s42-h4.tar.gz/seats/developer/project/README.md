# RunningStats

A C++20 library for computing running statistics using stable online algorithms.

## Features

- **Stable online algorithms**: Uses Welford's method for variance calculation to maintain numerical stability
- **Merge support**: Can merge two RunningStats instances without losing precision
- **NaN/Infinity rejection**: Automatically rejects invalid inputs
- **Empty state handling**: Throws std::domain_error for operations on empty instances

## API

```cpp
class RunningStats {
public:
    void add(double x);                    // Add a value
    void merge(const RunningStats& other); // Merge another instance
    std::uint64_t count() const;           // Number of values
    double mean() const;                   // Mean (throws if empty)
    double variance() const;               // Population variance (throws if empty)
    double minimum() const;                // Minimum value (throws if empty)
    double maximum() const;                // Maximum value (throws if empty)
};
```

## Usage

```cpp
#include "stats.hpp"
#include <iostream>

int main() {
    RunningStats rs;
    
    rs.add(10.0);
    rs.add(20.0);
    rs.add(30.0);
    
    std::cout << "Count: " << rs.count() << "\n";
    std::cout << "Mean: " << rs.mean() << "\n";
    std::cout << "Variance: " << rs.variance() << "\n";
    std::cout << "Min: " << rs.minimum() << "\n";
    std::cout << "Max: " << rs.maximum() << "\n";
    
    return 0;
}
```

## Building

```bash
mkdir build
cd build
cmake ..
make
```

## Requirements

- C++20 compatible compiler
- CMake 3.20+
