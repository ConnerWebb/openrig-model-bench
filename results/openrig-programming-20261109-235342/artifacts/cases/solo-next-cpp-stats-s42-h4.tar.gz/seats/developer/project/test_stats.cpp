#include "stats.hpp"
#include <iostream>
#include <cassert>
#include <cmath>
#include <stdexcept>
#include <vector>

void test_basic_add() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    rs.add(30.0);
    
    assert(rs.count() == 3);
    assert(std::abs(rs.mean() - 20.0) < 1e-9);
    assert(std::abs(rs.variance() - 66.66666666666666) < 1e-6);
    assert(std::abs(rs.minimum() - 10.0) < 1e-9);
    assert(std::abs(rs.maximum() - 30.0) < 1e-9);
    std::cout << "test_basic_add passed\n";
}

void test_empty_throws() {
    RunningStats rs;
    
    bool caught = false;
    try {
        rs.mean();
    } catch (const std::domain_error&) {
        caught = true;
    }
    assert(caught);
    
    caught = false;
    try {
        rs.variance();
    } catch (const std::domain_error&) {
        caught = true;
    }
    assert(caught);
    
    caught = false;
    try {
        rs.minimum();
    } catch (const std::domain_error&) {
        caught = true;
    }
    assert(caught);
    
    caught = false;
    try {
        rs.maximum();
    } catch (const std::domain_error&) {
        caught = true;
    }
    assert(caught);
    
    std::cout << "test_empty_throws passed\n";
}

void test_nan_rejection() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    uint64_t countBefore = rs.count();
    
    bool caught = false;
    try {
        rs.add(NAN);
    } catch (const std::invalid_argument&) {
        caught = true;
    }
    assert(caught);
    assert(rs.count() == countBefore);
    
    std::cout << "test_nan_rejection passed\n";
}

void test_inf_rejection() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    uint64_t countBefore = rs.count();
    
    bool caught = false;
    try {
        rs.add(INFINITY);
    } catch (const std::invalid_argument&) {
        caught = true;
    }
    assert(caught);
    
    caught = false;
    try {
        rs.add(-INFINITY);
    } catch (const std::invalid_argument&) {
        caught = true;
    }
    assert(caught);
    assert(rs.count() == countBefore);
    
    std::cout << "test_inf_rejection passed\n";
}

void test_merge_empty() {
    RunningStats rs1;
    RunningStats rs2;
    
    rs1.merge(rs2);
    assert(rs1.count() == 0);
    
    rs2.merge(rs1);
    assert(rs2.count() == 0);
    
    std::cout << "test_merge_empty passed\n";
}

void test_merge_into_empty() {
    RunningStats rs1;
    RunningStats rs2;
    rs2.add(10.0);
    rs2.add(20.0);
    
    rs1.merge(rs2);
    assert(rs1.count() == 2);
    assert(std::abs(rs1.mean() - 15.0) < 1e-9);
    assert(std::abs(rs1.minimum() - 10.0) < 1e-9);
    assert(std::abs(rs1.maximum() - 20.0) < 1e-9);
    
    std::cout << "test_merge_into_empty passed\n";
}

void test_merge_self() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    
    double meanBefore = rs.mean();
    double varBefore = rs.variance();
    
    rs.merge(rs);
    
    assert(rs.count() == 4);
    assert(std::abs(rs.mean() - meanBefore) < 1e-9);
    assert(std::abs(rs.variance() - varBefore) < 1e-9);
    
    std::cout << "test_merge_self passed\n";
}

void test_large_values() {
    RunningStats rs;
    std::vector<double> values = {
        1000000030.0, 1000000058.0, 999999902.0, 999999967.0,
        999999939.0, 1000000093.0, 999999951.0, 999999967.0,
        999999922.0, 999999951.0, 1000000031.0, 999999914.0,
        1000000052.0, 999999949.0, 1000000029.0, 999999906.0,
        1000000077.0, 1000000034.0, 999999993.0, 1000000017.0,
        1000000094.0, 999999933.0, 999999989.0, 1000000065.0,
        999999942.0, 999999909.0, 999999989.0, 1000000055.0,
        999999907.0, 999999999.0, 1000000065.0, 1000000049.0,
        999999948.0, 999999938.0, 999999982.0, 1000000011.0,
        1000000014.0, 999999924.0, 1000000069.0, 999999905.0,
        999999963.0, 1000000054.0
    };
    
    for (double v : values) {
        rs.add(v);
    }
    
    assert(rs.count() == 42);
    double expectedMean = 999999990.1428572;
    double expectedVar = 3446.598639455782;
    
    assert(std::abs(rs.mean() - expectedMean) <= 1e-4 + 1e-6 * expectedMean);
    assert(std::abs(rs.variance() - expectedVar) <= 1e-4 + 1e-6 * expectedVar);
    assert(std::abs(rs.minimum() - 999999902.0) <= 1e-4);
    assert(std::abs(rs.maximum() - 1000000094.0) <= 1e-4);
    
    std::cout << "test_large_values passed\n";
}

void test_merge_combines() {
    RunningStats rs1, rs2;
    
    rs1.add(1.0);
    rs1.add(2.0);
    rs1.add(3.0);
    
    rs2.add(4.0);
    rs2.add(5.0);
    
    rs1.merge(rs2);
    
    assert(rs1.count() == 5);
    assert(std::abs(rs1.mean() - 3.0) < 1e-9);
    assert(std::abs(rs1.minimum() - 1.0) < 1e-9);
    assert(std::abs(rs1.maximum() - 5.0) < 1e-9);
    
    std::cout << "test_merge_combines passed\n";
}

int main() {
    test_basic_add();
    test_empty_throws();
    test_nan_rejection();
    test_inf_rejection();
    test_merge_empty();
    test_merge_into_empty();
    test_merge_self();
    test_large_values();
    test_merge_combines();
    
    std::cout << "All tests passed!\n";
    return 0;
}
