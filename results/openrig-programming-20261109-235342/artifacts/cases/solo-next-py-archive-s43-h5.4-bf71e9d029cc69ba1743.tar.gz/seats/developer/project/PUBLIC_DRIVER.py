import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import solution
 import zipfile
 with tempfile.TemporaryDirectory() as d:
  d=pathlib.Path(d);p=d/'a.zip';out=d/'out'
  with zipfile.ZipFile(p,'w') as z:
   for item in x['entries']:
    i=zipfile.ZipInfo(item['name']);i.external_attr=((0o120777 if item.get('symlink') else 0o100644)<<16);z.writestr(i,item.get('text',''))
  if x.get('exists'):out.mkdir();(out/'keep').write_text('preserve')
  try:names=solution.extract_zip(str(p),str(out))
  except Exception as e:
   unchanged=(out.is_dir() and sorted(f.name for f in out.iterdir())==['keep'] and (out/'keep').read_text()=='preserve') if x.get('exists') else not out.exists();print(json.dumps({'error':type(e).__name__,'unchanged':unchanged}));sys.exit(0)
  files={str(f.relative_to(out)):f.read_text() for f in out.rglob('*') if f.is_file()};print(json.dumps({'value':names,'files':files}))

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
