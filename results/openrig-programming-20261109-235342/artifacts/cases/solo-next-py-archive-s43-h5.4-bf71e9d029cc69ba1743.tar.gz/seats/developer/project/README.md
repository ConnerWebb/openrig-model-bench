# extract_zip Implementation

This project implements `extract_zip(archive_path, outdir) -> list[str]` that extracts a ZIP archive into a new directory.

## Functionality

- Extracts ZIP files into a new output directory
- Returns a sorted list of extracted file paths
- Validates all entries before extraction:
  - Rejects if `outdir` already exists
  - Rejects absolute paths
  - Rejects paths containing `..` components
  - Rejects paths with backslashes
  - Rejects paths with drive colons (e.g., `C:`)
  - Rejects duplicate normalized paths
  - Rejects symbolic links
- Preserves UTF-8 file contents
- Creates nested directories as needed
- Does not overwrite existing files

## Usage

```python
from solution import extract_zip

# Extract a ZIP file
files = extract_zip('archive.zip', '/path/to/output')
print(files)  # ['file1.txt', 'folder/', 'folder/file2.txt']
```

## Testing

Run the tests with:
```bash
python -m unittest test_solution
```
