import zipfile
import os
import pathlib


def extract_zip(archive_path: str, outdir: str) -> list[str]:
    """
    Extract a ZIP into a NEW directory, returning sorted member file paths.
    Reject with ValueError before creating any output if:
    - outdir exists
    - any member is absolute
    - contains .. components
    - backslashes
    - drive-colon
    - duplicate normalized file/directory path
    - a symbolic link
    - path would be inside a file (e.g., a/b when a is a file)
    """
    # Validate outdir does not exist
    if os.path.exists(outdir):
        raise ValueError("outdir already exists")

    # Read the ZIP file
    with zipfile.ZipFile(archive_path, 'r') as zf:
        # First pass: validate all entries
        normalized_paths = {}  # normalized -> original name
        file_paths = set()  # normalized paths that are files
        members = zf.infolist()

        for member in members:
            name = member.filename

            # Check for backslashes
            if '\\' in name:
                raise ValueError("Path contains backslashes")

            # Check for drive colon (Windows drive letter)
            if len(name) >= 2 and name[1] == ':':
                raise ValueError("Path contains drive colon")

            # Check for absolute path
            if os.path.isabs(name):
                raise ValueError("Path is absolute")

            # Check for .. components
            parts = name.split('/')
            if '..' in parts:
                raise ValueError("Path contains .. components")

            # Check for symbolic links
            # The high 16 bits of external_attr contain Unix file mode
            # S_IFLNK = 0o120000 indicates a symlink
            if (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Symbolic link detected")

            # Normalize the path
            normalized = os.path.normpath(name)

            # Check for empty path or path that resolves to outside
            if not normalized or normalized.startswith('..'):
                raise ValueError("Invalid path")

            # Check for duplicates (using normalized path as key)
            if normalized in normalized_paths:
                raise ValueError("Duplicate path")
            normalized_paths[normalized] = name  # Store original name

            # Track if this is a file (not a directory)
            if not member.is_dir():
                file_paths.add(normalized)

        # Check if any file path is inside another file path
        for path in file_paths:
            parts = path.split('/')
            # Check all parent directories
            for i in range(1, len(parts)):
                parent = '/'.join(parts[:i])
                if parent in file_paths:
                    # This path is inside a file, which is invalid
                    raise ValueError("Path would be inside a file")

        # Create output directory
        os.makedirs(outdir, exist_ok=True)

        # Second pass: extract all entries
        for member in members:
            name = member.filename
            normalized = os.path.normpath(name)

            # Skip if it would escape the output directory
            if normalized.startswith('..'):
                raise ValueError("Path escapes output directory")

            # Determine the output path
            out_path = os.path.join(outdir, normalized)

            # Create directories
            if member.is_dir():
                os.makedirs(out_path, exist_ok=True)
            else:
                # Ensure parent directory exists and is a directory
                parent_dir = os.path.dirname(out_path)
                if parent_dir:
                    # Check if parent exists and is a file (not a directory)
                    if os.path.exists(parent_dir):
                        if not os.path.isdir(parent_dir):
                            raise ValueError("Parent is a file, not a directory")
                    else:
                        os.makedirs(parent_dir, exist_ok=True)

                # Extract file
                with zf.open(member) as src, open(out_path, 'wb') as dst:
                    dst.write(src.read())

        # Collect all file paths (only files, not directories)
        result = []
        for root, dirs, files in os.walk(outdir):
            for f in files:
                rel_path = os.path.relpath(os.path.join(root, f), outdir)
                result.append(rel_path)

        # Sort the result
        result.sort()
        return result
