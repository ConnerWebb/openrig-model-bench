import unittest
import zipfile
import os
import tempfile
import shutil
from solution import extract_zip


class TestExtractZip(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_basic_extraction(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a.txt', 'hello')
            zf.writestr('b.txt', 'world')

        result = extract_zip(zip_path, outdir)
        self.assertEqual(sorted(result), ['a.txt', 'b.txt'])
        self.assertTrue(os.path.exists(os.path.join(outdir, 'a.txt')))
        self.assertTrue(os.path.exists(os.path.join(outdir, 'b.txt')))

    def test_directory_extraction(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('folder/', '')
            zf.writestr('folder/a.txt', 'content')

        result = extract_zip(zip_path, outdir)
        self.assertEqual(sorted(result), ['folder/a.txt'])

    def test_outdir_exists_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')
        os.makedirs(outdir)

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a.txt', 'hello')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_absolute_path_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('/etc/passwd', 'malicious')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_double_dot_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('../etc/passwd', 'malicious')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_backslash_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('folder\\file.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_drive_colon_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('C:file.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_duplicate_paths_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('file.txt', 'content1')
            zf.writestr('file.txt', 'content2')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_symlink_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            info = zipfile.ZipInfo('link.txt')
            info.external_attr = (0o120777 << 16)
            zf.writestr(info, 'target')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_empty_zip(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            pass

        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, [])
        self.assertTrue(os.path.exists(outdir))

    def test_utf8_content(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a.txt', 'hello 日本')

        result = extract_zip(zip_path, outdir)
        self.assertEqual(sorted(result), ['a.txt'])
        with open(os.path.join(outdir, 'a.txt'), 'r', encoding='utf-8') as f:
            self.assertEqual(f.read(), 'hello 日本')

    def test_nested_directories(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a/b/c/d.txt', 'content')

        result = extract_zip(zip_path, outdir)
        self.assertEqual(sorted(result), ['a/b/c/d.txt'])

    def test_preserves_existing_files(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')
        os.makedirs(outdir)
        with open(os.path.join(outdir, 'keep.txt'), 'w') as f:
            f.write('preserve')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

        # Original file should still exist
        self.assertTrue(os.path.exists(os.path.join(outdir, 'keep.txt')))


if __name__ == '__main__':
    unittest.main()
