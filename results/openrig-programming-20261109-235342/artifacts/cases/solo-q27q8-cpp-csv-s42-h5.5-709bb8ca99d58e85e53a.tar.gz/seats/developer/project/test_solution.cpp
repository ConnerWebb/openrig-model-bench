#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <fstream>
#include <iostream>
#include "solution.hpp"

static int failures = 0;

static void check(bool cond, const std::string& name) {
    if (!cond) { std::cerr << "FAIL: " << name << "\n"; ++failures; }
    else { std::cout << "ok: " << name << "\n"; }
}

static bool expect_value(const std::string& csv,
                         const std::map<std::string, std::int64_t>& want,
                         const std::string& name) {
    std::istringstream in(csv);
    try {
        auto got = aggregate(in);
        if (got != want) {
            std::cerr << "FAIL: " << name << " (value mismatch)\n";
            for (auto& [k, v] : got) std::cerr << "  got [" << k << "]=" << v << "\n";
            return false;
        }
        return true;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << name << " (unexpected exception: " << e.what() << ")\n";
        return false;
    }
}

static bool expect_error(const std::string& csv, const std::string& name) {
    std::istringstream in(csv);
    try {
        auto got = aggregate(in);
        std::cerr << "FAIL: " << name << " (no exception, got "
                  << got.size() << " keys)\n";
        return false;
    } catch (const std::exception&) {
        return true;
    }
}

int main() {
    // Basic aggregation
    check(expect_value(
        "category,amount\nfood,10\nfood,20\nrent,5\n",
        {{"food", 30}, {"rent", 5}}, "basic"), "basic");

    // Quoted fields with commas, newlines, escaped quotes
    check(expect_value(
        "category,amount\n\"a,b\",1\n\"two\nlines\",2\n\"x\"\"q\",3\n",
        {{"a,b", 1}, {"two\nlines", 2}, {"x\"q", 3}}, "quoted"), "quoted");

    // Stripping spaces/tabs/CR
    check(expect_value(
        "category,amount\n  food \t,  10 \r\n\trent\t,\t-5\t\n",
        {{"food", 10}, {"rent", -5}}, "strip"), "strip");

    // Empty physical records ignored
    check(expect_value(
        "category,amount\n\nfood,1\n\n\nrent,2\n",
        {{"food", 1}, {"rent", 2}}, "empty-records"), "empty-records");

    // Signed values, + sign
    check(expect_value(
        "category,amount\nx,+7\nx,-3\n",
        {{"x", 4}}, "signed"), "signed");

    // Wrong header
    check(expect_error("wrong,amount\nx,1\n", "wrong-header"), "wrong-header");
    check(expect_error("category,amt\nx,1\n", "wrong-header2"), "wrong-header2");

    // Wrong field count
    check(expect_error("category,amount\nx,1,2\n", "three-fields"), "three-fields");
    check(expect_error("category,amount\nx\n", "one-field"), "one-field");

    // Empty category
    check(expect_error("category,amount\n,1\n", "empty-cat"), "empty-cat");
    check(expect_error("category,amount\n   ,1\n", "blank-cat"), "blank-cat");

    // Bad amounts
    check(expect_error("category,amount\nx,NaN\n", "nan"), "nan");
    check(expect_error("category,amount\nx,1e2\n", "exp"), "exp");
    check(expect_error("category,amount\nx,1.5\n", "decimal"), "decimal");
    check(expect_error("category,amount\nx,\n", "empty-amt"), "empty-amt");
    check(expect_value("category,amount\nx, 1\n", {{"x", 1}}, "ws-amt"), "ws-amt");
    check(expect_error("category,amount\nx,+\n", "plus-only"), "plus-only");
    check(expect_error("category,amount\nx,-\n", "minus-only"), "minus-only");

    // Overflow in parsing
    check(expect_error("category,amount\nx,9223372036854775808\n", "parse-overflow"), "parse-overflow");
    check(expect_error("category,amount\nx,-9223372036854775809\n", "parse-underflow"), "parse-underflow");

    // Overflow in accumulation
    check(expect_error("category,amount\nx,9223372036854775807\nx,1\n", "acc-overflow"), "acc-overflow");
    check(expect_error("category,amount\nx,-9223372036854775808\nx,-1\n", "acc-underflow"), "acc-underflow");

    // Boundary values that DO fit
    check(expect_value(
        "category,amount\nx,9223372036854775807\n",
        {{"x", 9223372036854775807LL}}, "max-ok"), "max-ok");
    check(expect_value(
        "category,amount\nx,-9223372036854775808\n",
        {{"x", std::numeric_limits<std::int64_t>::min()}}, "min-ok"), "min-ok");

    // Malformed quoting
    check(expect_error("category,amount\n\"x,1\n", "unterminated"), "unterminated");
    check(expect_error("category,amount\n\"x\"y,1\n", "garbage-after-quote"), "garbage-after-quote");

    // Missing header (empty input)
    check(expect_error("", "empty-input"), "empty-input");

    // CRLF line endings
    check(expect_value(
        "category,amount\r\nfood,1\r\nrent,2\r\n",
        {{"food", 1}, {"rent", 2}}, "crlf"), "crlf");

    // No trailing newline
    check(expect_value(
        "category,amount\nfood,1",
        {{"food", 1}}, "no-trailing-nl"), "no-trailing-nl");

    // Unicode category
    check(expect_value(
        "category,amount\n日本,100\n日本,-40\n",
        {{"日本", 60}}, "unicode"), "unicode");

    // Public cases from files
    for (int i = 0; i <= 12; ++i) {
        char path[64];
        snprintf(path, sizeof(path), "public-inputs/case-%02d.csv", i);
        std::ifstream f(path);
        if (!f) { std::cerr << "FAIL: cannot open " << path << "\n"; ++failures; continue; }
        std::string name = "public-case-" + std::to_string(i);
        try {
            auto got = aggregate(f);
            std::cout << "ok: " << name << " (" << got.size() << " keys)\n";
        } catch (const std::exception& e) {
            // Cases 04-12 are expected errors; 00-03 are expected values.
            if (i <= 3) {
                std::cerr << "FAIL: " << name << " unexpected error: " << e.what() << "\n";
                ++failures;
            } else {
                std::cout << "ok: " << name << " (expected error)\n";
            }
        }
    }

    if (failures) { std::cerr << failures << " failures\n"; return 1; }
    std::cout << "all tests passed\n";
    return 0;
}
