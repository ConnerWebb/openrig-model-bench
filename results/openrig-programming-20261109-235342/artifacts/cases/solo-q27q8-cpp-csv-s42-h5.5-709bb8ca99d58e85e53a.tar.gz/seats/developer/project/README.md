# CSV Aggregation

Header-only C++20 solution: `std::map<std::string,std::int64_t> aggregate(std::istream&)`.

## Behavior

- Parses CSV with header exactly `category,amount`.
- `amount` is a signed base-10 int64 (optional `+`/`-`, digits only, no decimals/exponents/whitespace).
- Strips outer spaces/tabs/CR from fields; category must be nonempty.
- Quoted fields allow commas, newlines, and escaped double quotes (`""`).
- Empty physical records are ignored.
- Rejects malformed quoting, wrong field count/header, empty fields, and overflow
  (in parsing or accumulation) with `std::invalid_argument`.
- Streams input record-by-record (does not load all input).
- Returns the map with sorted keys.

## Build & test

```bash
clang++ -std=c++20 -O2 -o /tmp/test_solution test_solution.cpp
/tmp/test_solution
```
