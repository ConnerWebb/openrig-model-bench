#pragma once
// Header-only CSV aggregation: std::map<std::string,std::int64_t> aggregate(std::istream&)
#include <istream>
#include <map>
#include <string>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <limits>

namespace {

inline bool is_blank(char c) { return c == ' ' || c == '\t' || c == '\r'; }

inline std::string strip(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && is_blank(s[b])) ++b;
    while (e > b && is_blank(s[e - 1])) --e;
    return s.substr(b, e - b);
}

inline std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty amount");
    size_t i = 0;
    bool neg = false;
    if (s[0] == '+' || s[0] == '-') { neg = (s[0] == '-'); i = 1; }
    if (i >= s.size()) throw std::invalid_argument("no digits in amount");
    const unsigned long long limit = neg ? 9223372036854775808ULL
                                         : 9223372036854775807ULL;
    unsigned long long v = 0;
    for (; i < s.size(); ++i) {
        char c = s[i];
        if (c < '0' || c > '9') throw std::invalid_argument("non-digit in amount");
        unsigned long long d = static_cast<unsigned long long>(c - '0');
        if (v > (limit - d) / 10) throw std::invalid_argument("amount overflow");
        v = v * 10 + d;
    }
    return neg ? -static_cast<std::int64_t>(v) : static_cast<std::int64_t>(v);
}

// Parse one CSV record. Returns false at clean EOF. Throws on malformed quoting.
inline bool parse_record(std::istream& in, std::vector<std::string>& out) {
    out.clear();
    int c = in.peek();
    if (c == std::char_traits<char>::eof()) return false;

    std::string field;
    while (true) {
        // Read one field. c is the first char (peeked).
        if (c == '"') {
            in.get(); // consume opening quote
            while (true) {
                int q = in.get();
                if (q == std::char_traits<char>::eof())
                    throw std::invalid_argument("unterminated quoted field");
                if (q == '"') {
                    int n = in.peek();
                    if (n == '"') { in.get(); field += '"'; }
                    else break; // closing quote
                } else {
                    field += static_cast<char>(q);
                }
            }
            // After closing quote: expect , or EOL/EOF
            int a = in.peek();
            if (a == ',') {
                in.get();
                out.push_back(field); field.clear();
                c = in.peek();
                continue;
            } else if (a == '\n' || a == '\r') {
                in.get();
                if (a == '\r' && in.peek() == '\n') in.get();
                out.push_back(field);
                return true;
            } else if (a == std::char_traits<char>::eof()) {
                out.push_back(field);
                return true;
            } else {
                throw std::invalid_argument("garbage after closing quote");
            }
        } else {
            // Unquoted field: consume chars until delimiter
            while (c != ',' && c != '\n' && c != '\r' &&
                   c != std::char_traits<char>::eof()) {
                field += static_cast<char>(c);
                in.get();
                c = in.peek();
            }
            if (c == ',') {
                in.get();
                out.push_back(field); field.clear();
                c = in.peek();
                continue;
            } else if (c == '\n' || c == '\r') {
                in.get();
                if (c == '\r' && in.peek() == '\n') in.get();
                out.push_back(field);
                return true;
            } else {
                // EOF
                out.push_back(field);
                return true;
            }
        }
    }
}

} // namespace

inline std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    std::vector<std::string> fields;
    bool header_seen = false;
    while (true) {
        if (!parse_record(in, fields)) break;
        if (fields.size() == 1 && fields[0].empty()) continue;
        if (fields.size() != 2)
            throw std::invalid_argument("wrong field count");
        std::string cat = strip(fields[0]);
        std::string amt = strip(fields[1]);
        if (!header_seen) {
            if (cat != "category" || amt != "amount")
                throw std::invalid_argument("bad header");
            header_seen = true;
            continue;
        }
        if (cat.empty()) throw std::invalid_argument("empty category");
        if (amt.empty()) throw std::invalid_argument("empty amount");
        std::int64_t v = parse_int64(amt);
        auto it = result.find(cat);
        if (it == result.end()) {
            result.emplace(cat, v);
        } else {
            if (v > 0 && it->second > std::numeric_limits<std::int64_t>::max() - v)
                throw std::invalid_argument("accumulation overflow");
            if (v < 0 && it->second < std::numeric_limits<std::int64_t>::min() - v)
                throw std::invalid_argument("accumulation overflow");
            it->second += v;
        }
    }
    if (!header_seen) throw std::invalid_argument("missing header");
    return result;
}
