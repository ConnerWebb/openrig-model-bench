# OGC1 Binary Codec

This project implements a binary codec for encoding/decoding a sequence of records.

## Format

- Magic: `OGC1` (4 bytes)
- Record count (uint32, little-endian)
- For each record:
  - ID (uint32, little-endian)
  - Name length (uint16, little-endian)
  - Name (UTF-8, variable length)
  - Value (int64, little-endian)

## Constraints

- Maximum record count: 10,000
- Maximum name length: 1,024 bytes
- IDs must be unique

## Files

- `solution.hpp`: Core encode/decode functions
- `solution_test.cpp`: Unit tests
- `PUBLIC_DRIVER.cpp`: Driver for grading wire protocol
