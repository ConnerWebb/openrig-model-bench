#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include <cstring>
#include "solution.hpp"

static std::string hex_encode(const std::vector<uint8_t>& bytes) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (uint8_t b : bytes) {
        oss << std::setw(2) << static_cast<int>(b);
    }
    return oss.str();
}

static std::vector<uint8_t> hex_decode(const std::string& hex) {
    std::vector<uint8_t> bytes;
    for (size_t i = 0; i < hex.size(); i += 2) {
        std::string byte_str = hex.substr(i, 2);
        unsigned char byte = static_cast<unsigned char>(std::stoul(byte_str, nullptr, 16));
        bytes.push_back(byte);
    }
    return bytes;
}



static bool records_equal(const std::vector<Record>& a, const std::vector<Record>& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (a[i].id != b[i].id || a[i].name != b[i].name || a[i].value != b[i].value) {
            return false;
        }
    }
    return true;
}

static void test_empty() {
    std::vector<Record> empty;
    auto encoded = encode(empty);
    if (encoded.size() != 8) {
        std::cerr << "FAIL: empty encode size" << std::endl;
        exit(1);
    }
    auto decoded = decode(encoded);
    if (!records_equal(empty, decoded)) {
        std::cerr << "FAIL: empty roundtrip" << std::endl;
        exit(1);
    }
    std::cout << "PASS: empty" << std::endl;
}

static void test_single_record() {
    std::vector<Record> recs = {{123, "hello", -456}};
    auto encoded = encode(recs);
    auto decoded = decode(encoded);
    if (!records_equal(recs, decoded)) {
        std::cerr << "FAIL: single record roundtrip" << std::endl;
        exit(1);
    }
    std::cout << "PASS: single record" << std::endl;
}

static void test_magic() {
    std::vector<uint8_t> bad_magic = {0x42, 0x41, 0x44, 0x21, 0x01, 0x00, 0x00, 0x00};
    try {
        decode(bad_magic);
        std::cerr << "FAIL: bad magic should throw" << std::endl;
        exit(1);
    } catch (const std::exception&) {
        std::cout << "PASS: bad magic" << std::endl;
    }
}

static void test_truncated() {
    std::vector<uint8_t> short_data = {0x4f, 0x47, 0x43, 0x31, 0x01, 0x00, 0x00, 0x00};
    try {
        decode(short_data);
        std::cerr << "FAIL: truncated should throw" << std::endl;
        exit(1);
    } catch (const std::exception&) {
        std::cout << "PASS: truncated" << std::endl;
    }
}

static void test_trailing() {
    std::vector<uint8_t> trailing = {
        0x4f, 0x47, 0x43, 0x31, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    try {
        decode(trailing);
        std::cerr << "FAIL: trailing should throw" << std::endl;
        exit(1);
    } catch (const std::exception&) {
        std::cout << "PASS: trailing" << std::endl;
    }
}

static void test_duplicate_id() {
    std::vector<Record> recs = {{1, "a", 100}, {1, "b", 200}};
    try {
        encode(recs);
        std::cerr << "FAIL: duplicate id should throw" << std::endl;
        exit(1);
    } catch (const std::exception&) {
        std::cout << "PASS: duplicate id" << std::endl;
    }
}

static void test_large_name() {
    std::string name(MAX_NAME_LEN, 'x');
    std::vector<Record> recs = {{1, name, 123}};
    auto encoded = encode(recs);
    auto decoded = decode(encoded);
    if (!records_equal(recs, decoded)) {
        std::cerr << "FAIL: large name roundtrip" << std::endl;
        exit(1);
    }
    std::cout << "PASS: large name" << std::endl;
}

static void test_over_max_count() {
    std::vector<Record> recs(MAX_COUNT + 1, {1, "x", 0});
    try {
        encode(recs);
        std::cerr << "FAIL: over max count should throw" << std::endl;
        exit(1);
    } catch (const std::exception&) {
        std::cout << "PASS: over max count" << std::endl;
    }
}

static void test_over_max_name_len() {
    std::string name(MAX_NAME_LEN + 1, 'x');
    std::vector<Record> recs = {{1, name, 0}};
    try {
        encode(recs);
        std::cerr << "FAIL: over max name len should throw" << std::endl;
        exit(1);
    } catch (const std::exception&) {
        std::cout << "PASS: over max name len" << std::endl;
    }
}

static void test_public_cases() {
    std::ifstream cases("/work/PUBLIC_CASES.json");
    if (!cases) {
        std::cerr << "FAIL: cannot open PUBLIC_CASES.json" << std::endl;
        exit(1);
    }
    std::string content((std::istreambuf_iterator<char>(cases)),
                        std::istreambuf_iterator<char>(cases));

    // Simple JSON parsing for our known format
    size_t pos = 0;
    int case_count = 0;
    while ((pos = content.find("\"input_file\"", pos)) != std::string::npos) {
        size_t file_start = content.find('"', pos + 13) + 1;
        size_t file_end = content.find('"', file_start);
        std::string file_path = "/work/public-inputs/" + content.substr(file_start, file_end - file_start);

        std::ifstream input(file_path);
        if (!input) {
            std::cerr << "FAIL: cannot open " << file_path << std::endl;
            exit(1);
        }
        std::string line;
        std::getline(input, line);

        // Remove surrounding quotes
        if (line.size() >= 2 && line.front() == '"' && line.back() == '"') {
            line = line.substr(1, line.size() - 2);
        }

        std::istringstream iss(line);
        int mode;
        iss >> mode;

        if (mode == 0) {
            // Input is records, encode and compare hex
            int n;
            iss >> n;
            std::vector<Record> recs;
            for (int i = 0; i < n; ++i) {
                Record r;
                iss >> r.id >> std::quoted(r.name) >> r.value;
                recs.push_back(r);
            }
            auto encoded = encode(recs);
            std::string expected_hex;
            size_t hex_pos = content.find("\"hex\":", pos);
            if (hex_pos != std::string::npos) {
                size_t hex_start = content.find('"', hex_pos + 6) + 1;
                size_t hex_end = content.find('"', hex_start);
                expected_hex = content.substr(hex_start, hex_end - hex_start);
            }
            std::string actual_hex = hex_encode(encoded);
            if (actual_hex != expected_hex) {
                std::cerr << "FAIL: public case " << case_count << " encode hex mismatch" << std::endl;
                std::cerr << "Expected: " << expected_hex << std::endl;
                std::cerr << "Actual:   " << actual_hex << std::endl;
                exit(1);
            }
        } else {
            // Input is hex, decode and compare
            std::string hex;
            iss >> hex;
            auto bytes = hex_decode(hex);
            auto decoded = decode(bytes);
            std::string expected_hex;
            size_t hex_pos = content.find("\"hex\":", pos);
            if (hex_pos != std::string::npos) {
                size_t hex_start = content.find('"', hex_pos + 6) + 1;
                size_t hex_end = content.find('"', hex_start);
                expected_hex = content.substr(hex_start, hex_end - hex_start);
            }
            std::string actual_hex = hex_encode(bytes);
            if (actual_hex != expected_hex) {
                std::cerr << "FAIL: public case " << case_count << " hex mismatch" << std::endl;
                exit(1);
            }
        }

        pos = file_end;
        case_count++;
    }

    std::cout << "PASS: public cases (" << case_count << ")" << std::endl;
}

int main() {
    test_empty();
    test_single_record();
    test_magic();
    test_truncated();
    test_trailing();
    test_duplicate_id();
    test_large_name();
    test_over_max_count();
    test_over_max_name_len();
    test_public_cases();

    std::cout << "All tests passed!" << std::endl;
    return 0;
}
