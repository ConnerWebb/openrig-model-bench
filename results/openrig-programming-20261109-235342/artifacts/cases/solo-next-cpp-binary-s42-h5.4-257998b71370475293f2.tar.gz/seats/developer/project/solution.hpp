#include <vector>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <span>
#include <algorithm>

struct Record {
    uint32_t id;
    std::string name;
    int64_t value;
};

static constexpr uint32_t MAGIC = 0x3143474f; // "OGC1" little-endian
static constexpr size_t MAX_COUNT = 10000;
static constexpr size_t MAX_NAME_LEN = 1024;

std::vector<uint8_t> encode(const std::vector<Record>& records) {
    if (records.size() > MAX_COUNT) {
        throw std::runtime_error("Record count exceeds limit");
    }

    std::vector<uint32_t> seen_ids;
    seen_ids.reserve(records.size());

    for (const auto& rec : records) {
        if (std::find(seen_ids.begin(), seen_ids.end(), rec.id) != seen_ids.end()) {
            throw std::runtime_error("Duplicate ID");
        }
        seen_ids.push_back(rec.id);
    }

    std::vector<uint8_t> output;
    output.reserve(4 + records.size() * (4 + 2 + 8) + 1024); // rough estimate

    // Magic "OGC1"
    output.push_back('O');
    output.push_back('G');
    output.push_back('C');
    output.push_back('1');

    // Count (little-endian uint32)
    uint32_t count = static_cast<uint32_t>(records.size());
    output.push_back(count & 0xFF);
    output.push_back((count >> 8) & 0xFF);
    output.push_back((count >> 16) & 0xFF);
    output.push_back((count >> 24) & 0xFF);

    for (const auto& rec : records) {
        // ID (little-endian uint32)
        output.push_back(rec.id & 0xFF);
        output.push_back((rec.id >> 8) & 0xFF);
        output.push_back((rec.id >> 16) & 0xFF);
        output.push_back((rec.id >> 24) & 0xFF);

        // Name length (little-endian uint16)
        uint16_t name_len = static_cast<uint16_t>(rec.name.size());
        if (name_len > MAX_NAME_LEN) {
            throw std::runtime_error("Name length exceeds limit");
        }
        output.push_back(name_len & 0xFF);
        output.push_back((name_len >> 8) & 0xFF);

        // Name bytes
        for (char c : rec.name) {
            output.push_back(static_cast<uint8_t>(c));
        }

        // Value (little-endian int64)
        int64_t v = rec.value;
        output.push_back(static_cast<uint8_t>(v & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 8) & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 16) & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 24) & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 32) & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 40) & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 48) & 0xFF));
        output.push_back(static_cast<uint8_t>((v >> 56) & 0xFF));
    }

    return output;
}

std::vector<Record> decode(std::span<const uint8_t> data) {
    if (data.size() < 8) {
        throw std::runtime_error("Data too short for header");
    }

    // Check magic
    if (data[0] != 'O' || data[1] != 'G' || data[2] != 'C' || data[3] != '1') {
        throw std::runtime_error("Invalid magic");
    }

    // Read count (little-endian uint32)
    uint32_t count = static_cast<uint32_t>(data[4]) |
                     (static_cast<uint32_t>(data[5]) << 8) |
                     (static_cast<uint32_t>(data[6]) << 16) |
                     (static_cast<uint32_t>(data[7]) << 24);

    if (count > MAX_COUNT) {
        throw std::runtime_error("Record count exceeds limit");
    }

    if (count == 0) {
        if (data.size() != 8) {
            throw std::runtime_error("Trailing bytes with zero records");
        }
        return {};
    }

    size_t pos = 8;
    std::vector<Record> records;
    records.reserve(count);

    std::vector<uint32_t> seen_ids;
    seen_ids.reserve(count);

    for (uint32_t i = 0; i < count; ++i) {
        // ID (4 bytes)
        if (pos + 4 > data.size()) {
            throw std::runtime_error("Truncated ID");
        }
        uint32_t id = static_cast<uint32_t>(data[pos]) |
                      (static_cast<uint32_t>(data[pos + 1]) << 8) |
                      (static_cast<uint32_t>(data[pos + 2]) << 16) |
                      (static_cast<uint32_t>(data[pos + 3]) << 24);
        pos += 4;

        // Check uniqueness
        if (std::find(seen_ids.begin(), seen_ids.end(), id) != seen_ids.end()) {
            throw std::runtime_error("Duplicate ID");
        }
        seen_ids.push_back(id);

        // Name length (2 bytes)
        if (pos + 2 > data.size()) {
            throw std::runtime_error("Truncated name length");
        }
        uint16_t name_len = static_cast<uint16_t>(data[pos]) |
                            (static_cast<uint16_t>(data[pos + 1]) << 8);
        pos += 2;

        if (name_len > MAX_NAME_LEN) {
            throw std::runtime_error("Name length exceeds limit");
        }

        // Name bytes
        if (pos + name_len > data.size()) {
            throw std::runtime_error("Truncated name");
        }
        std::string name(reinterpret_cast<const char*>(&data[pos]), name_len);
        pos += name_len;

        // Value (8 bytes)
        if (pos + 8 > data.size()) {
            throw std::runtime_error("Truncated value");
        }
        int64_t value = static_cast<int64_t>(data[pos]) |
                        (static_cast<int64_t>(data[pos + 1]) << 8) |
                        (static_cast<int64_t>(data[pos + 2]) << 16) |
                        (static_cast<int64_t>(data[pos + 3]) << 24) |
                        (static_cast<int64_t>(data[pos + 4]) << 32) |
                        (static_cast<int64_t>(data[pos + 5]) << 40) |
                        (static_cast<int64_t>(data[pos + 6]) << 48) |
                        (static_cast<int64_t>(data[pos + 7]) << 56);
        pos += 8;

        records.push_back({id, name, value});
    }

    if (pos != data.size()) {
        throw std::runtime_error("Trailing bytes");
    }

    return records;
}
