
#pragma once
#include <list>
#include <unordered_map>
#include <vector>
#include <string>
class LruCache{using Item=std::pair<int,std::string>;std::size_t cap;std::list<Item> q;std::unordered_map<int,std::list<Item>::iterator> index;public:explicit LruCache(std::size_t n):cap(n){}LruCache(const LruCache&)=delete;LruCache&operator=(const LruCache&)=delete;void put(int k,std::string v){auto i=index.find(k);if(i!=index.end()){i->second->second=std::move(v);q.splice(q.begin(),q,i->second);return;}if(!cap)return;q.emplace_front(k,std::move(v));index[k]=q.begin();if(q.size()>cap){index.erase(q.back().first);q.pop_back();}}bool get(int k,std::string&v){auto i=index.find(k);if(i==index.end())return false;v=i->second->second;q.splice(q.begin(),q,i->second);return true;}bool erase(int k){auto i=index.find(k);if(i==index.end())return false;q.erase(i->second);index.erase(i);return true;}std::size_t size()const{return q.size();}std::vector<Item>snapshot()const{return {q.begin(),q.end()};}};
