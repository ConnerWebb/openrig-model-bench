import unittest,tempfile,pathlib,subprocess
class CorrectReference(unittest.TestCase):
 def test_library(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/"check.cpp").write_text('#include "solution.hpp"\n#include <cassert>\n#include <sstream>\nint main(){std::istringstream i("category,amount\\na,3\\n");assert(aggregate(i).at("a")==3);LruCache c(1);c.put(1,"x");std::string out;assert(c.get(1,out)&&out=="x");RunningStats s;s.add(2);s.add(4);assert(s.mean()==3&&s.variance()==1);}');r=subprocess.run(["clang++","-fuse-ld=bfd","-std=c++20","-pthread","-I/work",str(p/"check.cpp"),"-o",str(p/"check")],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(subprocess.run([str(p/"check")]).returncode,0)
