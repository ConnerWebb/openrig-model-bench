# Buffer Library

This repository contains a minimal C++20 implementation of a `Buffer` class that stores a contiguous array of `uint8_t` values. The class is designed to be lightweight, safe, and fully RAII‑compliant.

## Features
- Default and size‑based construction.
- `size()` returns the current number of bytes.
- Bounds‑checked `operator[]` for mutable and const access.
- `resize()` preserves existing data and zero‑initializes new bytes.
- Deep copy semantics for copy construction/assignment.
- Move semantics are `noexcept` and leave the moved‑from buffer empty.
- Self‑copy and self‑move operations are safe and preserve content.

## Building and Testing
The project uses Google Test for unit tests.

```bash
# Compile tests
clang++ -std=c++20 -I. -pthread test_solution.cpp -lgtest -lgtest_main -o test_buffer

# Run tests
./test_buffer
```

All tests should pass.

## License
MIT License.
