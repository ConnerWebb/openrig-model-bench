# extract_zip Implementation

This project implements `extract_zip(archive_path, outdir) -> list[str]` as specified in TASK.txt.

## Functionality

Extracts a ZIP archive into a NEW directory, returning sorted member file paths.

### Validation Rules

The function raises `ValueError` before creating any output if:
- `outdir` already exists
- Any member path is absolute
- Any member contains `..` components
- Any member contains backslashes
- Any member contains a drive colon (e.g., `C:`)
- Duplicate normalized file/directory paths exist
- Any member is a symbolic link

### Behavior

- Creates a new output directory
- Preserves UTF-8 file contents
- Handles nested directories
- Returns sorted list of extracted file paths (directories excluded)
- Empty ZIP creates empty output directory
- No output on malformed ZIP or validation failure

## Usage

```python
from solution import extract_zip

# Extract archive to new directory
files = extract_zip('archive.zip', 'output_dir')
print(files)  # ['file1.txt', 'folder/file2.txt']
```

## Testing

Run tests with:
```bash
python test_solution.py
```

## Files

- `solution.py` - Main implementation
- `test_solution.py` - Unit tests
- `README.md` - This file
