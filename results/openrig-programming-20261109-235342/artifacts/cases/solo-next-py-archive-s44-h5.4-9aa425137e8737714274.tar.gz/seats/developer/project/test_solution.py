import unittest
import zipfile
import tempfile
import os
import pathlib
import json
import sys

sys.path.insert(0, '/work')
from solution import extract_zip


class TestExtractZip(unittest.TestCase):

    def test_basic_extraction(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('folder/', '')
                zf.writestr('folder/a.txt', '5304')
                zf.writestr('b.txt', 'hello 日本')

            result = extract_zip(zip_path, outdir)
            self.assertEqual(result, ['b.txt', 'folder/a.txt'])

            with open(os.path.join(outdir, 'b.txt'), 'r', encoding='utf-8') as f:
                self.assertEqual(f.read(), 'hello 日本')

            with open(os.path.join(outdir, 'folder/a.txt'), 'r', encoding='utf-8') as f:
                self.assertEqual(f.read(), '5304')

    def test_outdir_exists_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')
            os.makedirs(outdir)

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('a.txt', 'content')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_absolute_path_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('/absolute/path.txt', 'content')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_dot_dot_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('../evil.txt', 'content')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_backslash_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('a\\b.txt', 'content')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_drive_colon_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('C:bad.txt', 'content')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_duplicate_paths_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('a.txt', 'content1')
                zf.writestr('a.txt', 'content2')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_duplicate_normalized_paths_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('a/b.txt', 'content1')
                zf.writestr('a//b.txt', 'content2')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_symlink_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                info = zipfile.ZipInfo('link')
                info.external_attr = (0o120777 << 16)
                zf.writestr(info, '/elsewhere')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

    def test_empty_zip_creates_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                pass

            result = extract_zip(zip_path, outdir)
            self.assertEqual(result, [])
            self.assertTrue(os.path.isdir(outdir))
            self.assertEqual(len(os.listdir(outdir)), 0)

    def test_preserves_utf8(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('utf8.txt', 'こんにちは 你好 🎉')

            result = extract_zip(zip_path, outdir)
            self.assertEqual(result, ['utf8.txt'])

            with open(os.path.join(outdir, 'utf8.txt'), 'r', encoding='utf-8') as f:
                self.assertEqual(f.read(), 'こんにちは 你好 🎉')

    def test_nested_directories(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('a/b/c/d.txt', 'deep')

            result = extract_zip(zip_path, outdir)
            self.assertEqual(result, ['a/b/c/d.txt'])

            with open(os.path.join(outdir, 'a/b/c/d.txt'), 'r') as f:
                self.assertEqual(f.read(), 'deep')

    def test_no_overwrite_existing_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'out')
            os.makedirs(outdir)
            with open(os.path.join(outdir, 'keep.txt'), 'w') as f:
                f.write('preserve')

            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('new.txt', 'new content')

            with self.assertRaises(ValueError):
                extract_zip(zip_path, outdir)

            # Verify original file is preserved
            with open(os.path.join(outdir, 'keep.txt'), 'r') as f:
                self.assertEqual(f.read(), 'preserve')


if __name__ == '__main__':
    unittest.main()
