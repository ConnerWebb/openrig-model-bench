import zipfile
import os
import pathlib


def extract_zip(archive_path: str, outdir: str) -> list[str]:
    """
    Extract a ZIP archive into a NEW directory, returning sorted member file paths.
    Reject with ValueError before creating any output if:
    - outdir exists
    - any member is absolute
    - contains .. components
    - backslashes
    - drive-colon (e.g., C:)
    - duplicate normalized file/directory path
    - a symbolic link
    """
    # Validate outdir does not exist
    if os.path.exists(outdir):
        raise ValueError("Output directory already exists")

    # Validate archive path exists
    if not os.path.isfile(archive_path):
        raise ValueError("Archive file does not exist")

    # First pass: validate all entries before creating any output
    normalized_paths = set()
    entries_to_extract = []

    with zipfile.ZipFile(archive_path, 'r') as zf:
        for info in zf.infolist():
            name = info.filename

            # Skip directories (they end with / in name)
            if name.endswith('/'):
                continue

            # Check for symbolic links via external_attr
            external_attr = info.external_attr
            mode = external_attr >> 16
            is_symlink = (mode & 0o170000) == 0o120000
            if is_symlink:
                raise ValueError("Symbolic link found in archive")

            # Check for absolute path
            if os.path.isabs(name):
                raise ValueError("Absolute path found in archive")

            # Check for backslashes
            if '\\' in name:
                raise ValueError("Backslash found in path")

            # Check for drive colon (e.g., C:)
            if ':' in name:
                if len(name) > 1 and name[0].isalpha() and name[1] == ':':
                    raise ValueError("Drive colon found in path")

            # Check for .. components
            parts = name.split('/')
            for part in parts:
                if part == '..':
                    raise ValueError(".. component found in path")

            # Normalize path
            normalized = os.path.normpath(name)
            if normalized.startswith('..') or os.path.isabs(normalized):
                raise ValueError("Path traversal detected")

            # Check for duplicate normalized paths
            if normalized in normalized_paths:
                raise ValueError("Duplicate path found")
            normalized_paths.add(normalized)

            entries_to_extract.append((info, normalized))

    # Sort entries by path length to ensure directories are processed before files
    entries_to_extract.sort(key=lambda x: (x[1].count('/'), x[1]))

    # Create output directory
    os.makedirs(outdir, exist_ok=True)

    # Second pass: extract entries
    result_paths = []
    with zipfile.ZipFile(archive_path, 'r') as zf:
        for info, normalized in entries_to_extract:
            out_path = os.path.join(outdir, normalized)

            # Ensure the path is within outdir (security check)
            real_out = os.path.realpath(out_path)
            real_outdir = os.path.realpath(outdir)
            if not real_out.startswith(real_outdir + os.sep) and real_out != real_outdir:
                raise ValueError("Path traversal detected during extraction")

            # Create parent directories if needed
            parent_dir = os.path.dirname(out_path)
            if parent_dir:
                try:
                    os.makedirs(parent_dir, exist_ok=True)
                except FileExistsError:
                    # Parent directory exists but is a file, not a directory
                    raise ValueError("Path conflict")

            # Extract file content
            with zf.open(info) as src, open(out_path, 'wb') as dst:
                dst.write(src.read())

            result_paths.append(normalized)

    # Sort and return
    return sorted(result_paths)
