# Buffer Implementation

This is a C++20 implementation of a Buffer class that meets all the specified requirements.

## Features

- **RAII**: Proper resource management with constructor, destructor, copy constructor, copy assignment, move constructor, and move assignment
- **Bounds checking**: Both mutable and const `operator[]` throw `std::out_of_range` when accessing invalid indices
- **Resize functionality**: Preserves existing content and zero-initializes new elements
- **Move semantics**: Noexcept move constructor and assignment, with moved-from buffers becoming size 0 and reusable
- **Deep copying**: Copy constructor and assignment perform deep copies
- **Self operations**: Self-copy and self-move operations preserve content correctly
- **No memory leaks**: Proper cleanup in destructor and move operations

## Interface

```cpp
class Buffer {
public:
    // Constructor
    explicit Buffer(std::size_t n = 0);
    
    // Destructor
    ~Buffer();
    
    // Copy constructor
    Buffer(const Buffer& other);
    
    // Copy assignment
    Buffer& operator=(const Buffer& other);
    
    // Move constructor
    Buffer(Buffer&& other) noexcept;
    
    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept;
    
    // Size getter
    std::size_t size() const noexcept;
    
    // Mutable operator[]
    std::uint8_t& operator[](std::size_t i);
    
    // Const operator[]
    const std::uint8_t& operator[](std::size_t i) const;
    
    // Resize method
    void resize(std::size_t k);
};
```

## Requirements Met

- ✅ `Buffer(size_t n=0)` constructor
- ✅ `size() const noexcept` method
- ✅ Mutable/const `operator[](size_t)` with bounds-check `out_of_range`
- ✅ `resize(size_t)` preserving prefix and zero-initializing new bytes
- ✅ Elements are `uint8_t`
- ✅ Deep-copy construction/assignment
- ✅ Noexcept move construction/assignment
- ✅ Moved-from buffers size 0 and reusable
- ✅ Self-copy/self-move preserve content
- ✅ Use RAII, no leaks, double frees, stale reads or undefined behavior
- ✅ Standard containers are allowed