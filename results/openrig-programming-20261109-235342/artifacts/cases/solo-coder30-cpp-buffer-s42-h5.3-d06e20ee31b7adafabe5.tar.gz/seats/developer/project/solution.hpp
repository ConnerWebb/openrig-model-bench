#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>

class Buffer {
    std::uint8_t* p;
    std::size_t n;
    
public:
    // Constructor
    explicit Buffer(std::size_t n = 0) : p(new std::uint8_t[n]), n(n) {}
    
    // Destructor
    ~Buffer() {
        delete[] p;
    }
    
    // Copy constructor
    Buffer(const Buffer& other) : p(new std::uint8_t[other.n]), n(other.n) {
        for (std::size_t i = 0; i < n; ++i) {
            p[i] = other.p[i];
        }
    }
    
    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this == &other) {
            return *this;
        }
        
        delete[] p;
        n = other.n;
        p = new std::uint8_t[n];
        for (std::size_t i = 0; i < n; ++i) {
            p[i] = other.p[i];
        }
        return *this;
    }
    
    // Move constructor
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }
    
    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this == &other) {
            return *this;
        }
        
        delete[] p;
        p = other.p;
        n = other.n;
        other.p = nullptr;
        other.n = 0;
        return *this;
    }
    
    // Size getter
    std::size_t size() const noexcept {
        return n;
    }
    
    // Mutable operator[]
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }
    
    // Const operator[]
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }
    
    // Resize method
    void resize(std::size_t k) {
        if (k == n) {
            return;
        }
        
        std::uint8_t* new_p = new std::uint8_t[k];
        
        // Copy existing elements
        std::size_t copy_size = (k < n) ? k : n;
        for (std::size_t i = 0; i < copy_size; ++i) {
            new_p[i] = p[i];
        }
        
        // Zero-initialize new elements
        if (k > n) {
            for (std::size_t i = n; i < k; ++i) {
                new_p[i] = 0;
            }
        }
        
        delete[] p;
        p = new_p;
        n = k;
    }
};