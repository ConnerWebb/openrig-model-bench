#include <iostream>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "Default constructor test passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    std::cout << "Constructor with size test passed\n";
}

void test_copy_constructor() {
    Buffer b1(5);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    b1[3] = 4;
    b1[4] = 5;
    
    Buffer b2(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    assert(b2[3] == 4);
    assert(b2[4] == 5);
    
    // Modify original, should not affect copy
    b1[0] = 99;
    assert(b2[0] == 1);
    
    std::cout << "Copy constructor test passed\n";
}

void test_copy_assignment() {
    Buffer b1(3);
    b1[0] = 10;
    b1[1] = 20;
    b1[2] = 30;
    
    Buffer b2(2);
    b2[0] = 1;
    b2[1] = 2;
    
    b2 = b1;
    assert(b2.size() == 3);
    assert(b2[0] == 10);
    assert(b2[1] == 20);
    assert(b2[2] == 30);
    
    // Modify original, should not affect assigned
    b1[0] = 99;
    assert(b2[0] == 10);
    
    std::cout << "Copy assignment test passed\n";
}

void test_move_constructor() {
    Buffer b1(4);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    b1[3] = 4;
    
    Buffer b2(std::move(b1));
    assert(b1.size() == 0);
    assert(b2.size() == 4);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    assert(b2[3] == 4);
    
    std::cout << "Move constructor test passed\n";
}

void test_move_assignment() {
    Buffer b1(3);
    b1[0] = 10;
    b1[1] = 20;
    b1[2] = 30;
    
    Buffer b2(2);
    b2[0] = 1;
    b2[1] = 2;
    
    b2 = std::move(b1);
    assert(b1.size() == 0);
    assert(b2.size() == 3);
    assert(b2[0] == 10);
    assert(b2[1] == 20);
    assert(b2[2] == 30);
    
    std::cout << "Move assignment test passed\n";
}

void test_self_copy() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    b = b; // Self assignment
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    
    std::cout << "Self copy test passed\n";
}

void test_self_move() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    b = std::move(b); // Self move
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    
    std::cout << "Self move test passed\n";
}

void test_operator_brackets() {
    Buffer b(3);
    b[0] = 10;
    b[1] = 20;
    b[2] = 30;
    
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    
    // Test const access
    const Buffer& cb = b;
    assert(cb[0] == 10);
    assert(cb[1] == 20);
    assert(cb[2] == 30);
    
    std::cout << "Operator[] test passed\n";
}

void test_bounds_checking() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    try {
        b[3] = 4; // Should throw
        assert(false);
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    try {
        const Buffer& cb = b;
        (void)cb[3]; // Should throw
        assert(false);
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    std::cout << "Bounds checking test passed\n";
}

void test_resize() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    
    b.resize(7);
    assert(b.size() == 7);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
    assert(b[5] == 0);
    assert(b[6] == 0);
    
    std::cout << "Resize test passed\n";
}

void test_empty_buffer() {
    Buffer b;
    assert(b.size() == 0);
    
    try {
        b[0] = 1; // Should throw
        assert(false);
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    std::cout << "Empty buffer test passed\n";
}

int main() {
    try {
        test_default_constructor();
        test_constructor_with_size();
        test_copy_constructor();
        test_copy_assignment();
        test_move_constructor();
        test_move_assignment();
        test_self_copy();
        test_self_move();
        test_operator_brackets();
        test_bounds_checking();
        test_resize();
        test_empty_buffer();
        
        std::cout << "All tests passed!\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Test failed with exception: " << e.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "Test failed with unknown exception" << std::endl;
        return 1;
    }
}