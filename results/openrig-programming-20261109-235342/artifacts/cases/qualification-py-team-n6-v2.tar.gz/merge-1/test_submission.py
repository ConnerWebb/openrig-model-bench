import unittest,ledger
class CorrectReference(unittest.TestCase):
 def test_contract(self):
  r=[{'id':' x ','category':' a ','cents':5}];self.assertEqual(ledger.process(r)['totals'],{'a':5});self.assertEqual(r[0]['id'],' x ');self.assertEqual(ledger.process([]),{'events':[],'totals':{}})
