def normalize(records):
    """Normalize a list of records.
    
    Args:
        records: List of dicts with 'id', 'category', 'cents' fields.
        
    Returns:
        New list of normalized dicts with stripped string id/category and nonnegative int cents.
        
    Raises:
        ValueError: If any record is invalid.
    """
    if not isinstance(records, list):
        raise ValueError('records must be a list')
    
    out = []
    for r in records:
        if not isinstance(r, dict):
            raise ValueError('record must be a dict')
        
        if set(r.keys()) != {'id', 'category', 'cents'}:
            raise ValueError('record must have exactly id, category, cents fields')
        
        if not isinstance(r['id'], str) or not r['id'].strip():
            raise ValueError('id must be a nonempty string')
        
        if not isinstance(r['category'], str) or not r['category'].strip():
            raise ValueError('category must be a nonempty string')
        
        # Boolean check: bool is subclass of int, so explicitly exclude it
        if type(r['cents']) is bool or not isinstance(r['cents'], int):
            raise ValueError('cents must be an integer')
        
        if r['cents'] < 0:
            raise ValueError('cents must be nonnegative')
        
        out.append({
            'id': r['id'].strip(),
            'category': r['category'].strip(),
            'cents': r['cents']
        })
    
    return out
