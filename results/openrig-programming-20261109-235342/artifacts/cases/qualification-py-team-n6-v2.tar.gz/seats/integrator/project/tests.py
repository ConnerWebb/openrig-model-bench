"""Comprehensive tests for the ledger toolkit integration."""

import unittest
import copy
import ledger
from validation import normalize
from storage import deduplicate


class TestValidation(unittest.TestCase):
    """Tests for validation.py normalize function."""

    def test_normalize_valid_records(self):
        """Normalize should strip and validate valid records."""
        records = [{'id': ' a ', 'category': ' x ', 'cents': 10}]
        result = normalize(records)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[0]['category'], 'x')
        self.assertEqual(result[0]['cents'], 10)

    def test_normalize_empty_id_raises(self):
        """Normalize should raise on empty id."""
        with self.assertRaises(ValueError):
            normalize([{'id': '', 'category': 'x', 'cents': 1}])

    def test_normalize_whitespace_only_id_raises(self):
        """Normalize should raise on whitespace-only id."""
        with self.assertRaises(ValueError):
            normalize([{'id': '   ', 'category': 'x', 'cents': 1}])

    def test_normalize_empty_category_raises(self):
        """Normalize should raise on empty category."""
        with self.assertRaises(ValueError):
            normalize([{'id': 'x', 'category': '', 'cents': 1}])

    def test_normalize_negative_cents_raises(self):
        """Normalize should raise on negative cents."""
        with self.assertRaises(ValueError):
            normalize([{'id': 'x', 'category': 'a', 'cents': -1}])

    def test_normalize_boolean_cents_raises(self):
        """Normalize should raise on boolean cents."""
        with self.assertRaises(ValueError):
            normalize([{'id': 'x', 'category': 'a', 'cents': True}])

    def test_normalize_float_cents_raises(self):
        """Normalize should raise on float cents."""
        with self.assertRaises(ValueError):
            normalize([{'id': 'x', 'category': 'a', 'cents': 1.5}])

    def test_normalize_missing_field_raises(self):
        """Normalize should raise on missing field."""
        with self.assertRaises(ValueError):
            normalize([{'id': 'x', 'category': 'a'}])

    def test_normalize_extra_field_raises(self):
        """Normalize should raise on extra field."""
        with self.assertRaises(ValueError):
            normalize([{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}])

    def test_normalize_non_list_raises(self):
        """Normalize should raise on non-list input."""
        with self.assertRaises(ValueError):
            normalize('not a list')

    def test_normalize_returns_fresh_copy(self):
        """Normalize should return fresh copies, not mutate input."""
        records = [{'id': ' a ', 'category': ' x ', 'cents': 10}]
        result = normalize(records)
        self.assertIsNot(result[0], records[0])
        self.assertEqual(records[0]['id'], ' a ')  # Input unchanged


class TestStorage(unittest.TestCase):
    """Tests for storage.py deduplicate function."""

    def test_deduplicate_first_wins(self):
        """Deduplicate should keep first occurrence of each id."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'y', 'cents': 20},
            {'id': 'a', 'category': 'z', 'cents': 100},
        ]
        result = deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[0]['category'], 'x')
        self.assertEqual(result[0]['cents'], 10)

    def test_deduplicate_preserves_order(self):
        """Deduplicate should preserve input order."""
        records = [
            {'id': 'c', 'category': 'x', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': 20},
            {'id': 'b', 'category': 'z', 'cents': 30},
        ]
        result = deduplicate(records)
        self.assertEqual([r['id'] for r in result], ['c', 'a', 'b'])

    def test_deduplicate_returns_fresh_copy(self):
        """Deduplicate should return fresh copies."""
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        result = deduplicate(records)
        self.assertIsNot(result[0], records[0])

    def test_deduplicate_empty_list(self):
        """Deduplicate should handle empty list."""
        result = deduplicate([])
        self.assertEqual(result, [])


class TestLedger(unittest.TestCase):
    """Tests for ledger.py process function."""

    def test_process_basic(self):
        """Process should return correct events and totals."""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = ledger.process(records)
        self.assertEqual(result['events'], [{'id': 'x', 'category': 'a', 'cents': 5}])
        self.assertEqual(result['totals'], {'a': 5})

    def test_process_empty(self):
        """Process should handle empty input."""
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_process_input_unchanged(self):
        """Process should not mutate input."""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_process_deduplication(self):
        """Process should deduplicate by id, keeping first."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'y', 'cents': 20},
            {'id': 'a', 'category': 'z', 'cents': 100},
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['category'], 'x')

    def test_process_totals_sorted(self):
        """Process totals keys should be sorted."""
        records = [
            {'id': 'c', 'category': 'z', 'cents': 10},
            {'id': 'a', 'category': 'x', 'cents': 20},
            {'id': 'b', 'category': 'y', 'cents': 30},
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['x', 'y', 'z'])

    def test_process_minimum_cents(self):
        """Process should filter by minimum_cents."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'y', 'cents': 15},
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'b')

    def test_process_minimum_cents_default(self):
        """Process minimum_cents should default to 0."""
        records = [{'id': 'a', 'category': 'x', 'cents': 5}]
        result = ledger.process(records)
        self.assertEqual(result['events'][0]['cents'], 5)

    def test_process_minimum_cents_validation(self):
        """Process should validate minimum_cents."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'a', 'category': 'x', 'cents': 1}], minimum_cents=-1)
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'a', 'category': 'x', 'cents': 1}], minimum_cents=True)
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'a', 'category': 'x', 'cents': 1}], minimum_cents=1.5)

    def test_process_invalid_record_raises(self):
        """Process should validate all records before processing."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'y', 'cents': -5},
        ]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_process_no_shared_mutable_data(self):
        """Process should not return shared mutable data."""
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        result1 = ledger.process(records)
        result2 = ledger.process(records)
        result1['events'].append({'id': 'b', 'category': 'y', 'cents': 20})
        self.assertEqual(len(result2['events']), 1)

    def test_process_validation_before_deduplication(self):
        """Process should validate all records before deduplication."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': True},  # duplicate with invalid data
        ]
        with self.assertRaises(ValueError):
            ledger.process(records)


class TestIntegration(unittest.TestCase):
    """Integration tests using PUBLIC_CASES.json."""

    @classmethod
    def setUpClass(cls):
        import json
        with open('PUBLIC_CASES.json') as f:
            cls.cases = json.load(f)

    def test_public_cases(self):
        """Test all public cases."""
        for case in self.cases:
            records = case['input']['records']
            minimum = case['input'].get('minimum', 0)
            expected = case['expected']['value']

            result = ledger.process(records, minimum_cents=minimum)

            self.assertEqual(result['events'], expected['events'])
            self.assertEqual(result['totals'], expected['totals'])
            self.assertTrue(case['expected']['input_unchanged'])
            self.assertEqual(records, case['input']['records'])


if __name__ == '__main__':
    unittest.main()
