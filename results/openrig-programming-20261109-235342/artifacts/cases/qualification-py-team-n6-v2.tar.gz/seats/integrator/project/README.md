# Ledger Toolkit

A Python library for processing ledger records with validation, deduplication, and aggregation.

## Modules

### validation.py
- `normalize(records)` - Validates and normalizes a list of records
  - Strips whitespace from id and category strings
  - Validates cents is a non-negative integer (booleans rejected)
  - Returns fresh copies, never mutates input
  - Raises `ValueError` for invalid records

### storage.py
- `deduplicate(records)` - Removes duplicate ids, keeping first occurrence
  - Input must already be validated (normalize first)
  - Returns fresh copies, never mutates input
  - Preserves input order

### ledger.py
- `process(records, *, minimum_cents=0)` - Main entry point
  - Composes normalize and deduplicate
  - Filters by minimum_cents after deduplication
  - Returns `{events: [...], totals: {...}}` with sorted totals keys
  - Never mutates input, never returns shared mutable data

## Usage

```python
import ledger

records = [
    {'id': ' item1 ', 'category': ' food ', 'cents': 150},
    {'id': ' item2 ', 'category': ' transport ', 'cents': 200},
    {'id': ' item1 ', 'category': ' food ', 'cents': 100},  # duplicate id
]

result = ledger.process(records, minimum_cents=100)
# Returns:
# {
#   'events': [
#     {'id': 'item1', 'category': 'food', 'cents': 150},
#     {'id': 'item2', 'category': 'transport', 'cents': 200}
#   ],
#   'totals': {'food': 150, 'transport': 200}
# }
```

## Record Format

Each record must have exactly these fields:
- `id`: non-empty stripped string
- `category`: non-empty stripped string
- `cents`: non-negative integer (boolean values are invalid)

## Validation Rules

1. Input must be a list
2. Each record must be a dict with exactly `id`, `category`, `cents` fields
3. `id` and `category` must be non-empty strings after stripping
4. `cents` must be an integer (not bool, not float), >= 0
5. First occurrence of each `id` wins during deduplication

## Tests

Run tests with:
```bash
python3 -m unittest tests -v
```
