# Validation Module

## Overview

The `validation` module provides record normalization for ledger processing.

## Interface

### `normalize(records)`

Normalizes a list of records into a standardized format.

**Parameters:**
- `records`: List of dicts with exactly the fields `id`, `category`, `cents`

**Returns:**
- New list of dicts with:
  - `id`: stripped string
  - `category`: stripped string
  - `cents`: nonnegative integer

**Raises:**
- `ValueError`: If input is not a list, or any record is invalid

## Validation Rules

1. Input must be a list
2. Each record must be a dict with exactly three keys: `id`, `category`, `cents`
3. `id` must be a nonempty string (whitespace is stripped)
4. `category` must be a nonempty string (whitespace is stripped)
5. `cents` must be an integer (not a boolean) and nonnegative

## Usage Example

```python
from validation import normalize

records = [
    {'id': '  item1  ', 'category': '  food  ', 'cents': 100},
    {'id': 'item2', 'category': 'drink', 'cents': 50}
]

normalized = normalize(records)
# Returns:
# [
#   {'id': 'item1', 'category': 'food', 'cents': 100},
#   {'id': 'item2', 'category': 'drink', 'cents': 50}
# ]
```

## Notes

- Input is never mutated; a new list is always returned
- Duplicates are preserved (use `storage.deduplicate` to remove them)
- Boolean values are explicitly rejected for `cents` even though `bool` is a subclass of `int`
