import unittest
import validation


class TestNormalize(unittest.TestCase):
    def test_basic_normalization(self):
        x = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        result = validation.normalize(x)
        self.assertEqual(result, [{'id': 'a', 'category': 'b', 'cents': 2}])
        # Verify input immutability
        self.assertEqual(x[0]['id'], ' a ')
    
    def test_empty_input(self):
        self.assertEqual(validation.normalize([]), [])
    
    def test_multiple_records(self):
        records = [
            {'id': '1', 'category': 'cat', 'cents': 100},
            {'id': '2', 'category': 'dog', 'cents': 50}
        ]
        result = validation.normalize(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], '1')
        self.assertEqual(result[1]['id'], '2')
    
    def test_whitespace_trimming(self):
        records = [
            {'id': '  id  ', 'category': '  cat  ', 'cents': 0}
        ]
        result = validation.normalize(records)
        self.assertEqual(result[0]['id'], 'id')
        self.assertEqual(result[0]['category'], 'cat')
    
    def test_zero_cents_allowed(self):
        records = [{'id': 'x', 'category': 'y', 'cents': 0}]
        result = validation.normalize(records)
        self.assertEqual(result[0]['cents'], 0)
    
    def test_invalid_not_a_list(self):
        with self.assertRaises(ValueError):
            validation.normalize("not a list")
    
    def test_invalid_not_a_dict(self):
        with self.assertRaises(ValueError):
            validation.normalize([123])
    
    def test_invalid_extra_field(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': 1, 'extra': 'z'}])
    
    def test_invalid_missing_field(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y'}])
    
    def test_invalid_id_not_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 123, 'category': 'y', 'cents': 1}])
    
    def test_invalid_category_not_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 123, 'cents': 1}])
    
    def test_invalid_cents_not_int(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': 1.5}])
    
    def test_invalid_cents_bool(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': True}])
    
    def test_invalid_cents_negative(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': -1}])
    
    def test_invalid_id_empty_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '', 'category': 'y', 'cents': 1}])
    
    def test_invalid_id_whitespace_only(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '   ', 'category': 'y', 'cents': 1}])
    
    def test_invalid_category_empty_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '', 'cents': 1}])
    
    def test_invalid_category_whitespace_only(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '   ', 'cents': 1}])
    
    def test_input_not_mutated(self):
        records = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        original_id = records[0]['id']
        original_category = records[0]['category']
        validation.normalize(records)
        self.assertEqual(records[0]['id'], original_id)
        self.assertEqual(records[0]['category'], original_category)


if __name__ == '__main__':
    unittest.main()
