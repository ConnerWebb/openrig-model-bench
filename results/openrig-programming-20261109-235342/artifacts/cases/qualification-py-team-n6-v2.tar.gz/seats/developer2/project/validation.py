def normalize(records):
 out=[]
 for r in records:
  if not isinstance(r,dict) or set(r)!={'id','category','cents'} or not isinstance(r['id'],str) or not r['id'].strip() or not isinstance(r['category'],str) or not r['category'].strip() or type(r['cents'])!=int or r['cents']<0:raise ValueError('record')
  out.append({'id':r['id'].strip(),'category':r['category'].strip(),'cents':r['cents']})
 return out
