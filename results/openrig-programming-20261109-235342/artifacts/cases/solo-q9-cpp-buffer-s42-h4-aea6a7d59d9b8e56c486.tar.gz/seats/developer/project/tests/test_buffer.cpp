#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <vector>
#include <sstream>
#include <iomanip>

void test_constructor_default() {
    Buffer b;
    assert(b.size() == 0);
    assert(b.empty());
    std::cout << "PASS: test_constructor_default\n";
}

void test_constructor_size() {
    Buffer b(5);
    assert(b.size() == 5);
    assert(b[0] == 0);
    assert(b[4] == 0);
    std::cout << "PASS: test_constructor_size\n";
}

void test_resize_grow() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
    std::cout << "PASS: test_resize_grow\n";
}

void test_resize_shrink() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    std::cout << "PASS: test_resize_shrink\n";
}

void test_resize_same() {
    Buffer b(5);
    b[0] = 1;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    std::cout << "PASS: test_resize_same\n";
}

void test_operator_bracket_mutable() {
    Buffer b(3);
    b[0] = 42;
    assert(b[0] == 42);
    std::cout << "PASS: test_operator_bracket_mutable\n";
}

void test_operator_bracket_const() {
    const Buffer b(3);
    assert(b[0] == 0);
    std::cout << "PASS: test_operator_bracket_const\n";
}

void test_operator_bracket_out_of_bounds() {
    Buffer b(3);
    try {
        b[3];
        std::cerr << "FAIL: test_operator_bracket_out_of_bounds - should throw\n";
        assert(false);
    } catch (const std::out_of_range&) {
        std::cout << "PASS: test_operator_bracket_out_of_bounds\n";
    }
}

void test_deep_copy_constructor() {
    Buffer b1(5);
    b1[0] = 10;
    b1[1] = 20;
    Buffer b2(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 10);
    assert(b2[1] == 20);
    b1[0] = 99;
    assert(b2[0] == 10);  // b2 should not be affected
    std::cout << "PASS: test_deep_copy_constructor\n";
}

void test_deep_copy_assignment() {
    Buffer b1(5);
    b1[0] = 10;
    Buffer b2(3);
    b2 = b1;
    assert(b2.size() == 5);
    assert(b2[0] == 10);
    b1[0] = 99;
    assert(b2[0] == 10);  // b2 should not be affected
    std::cout << "PASS: test_deep_copy_assignment\n";
}

void test_move_constructor() {
    Buffer b1(5);
    b1[0] = 10;
    Buffer b2(std::move(b1));
    assert(b2.size() == 5);
    assert(b2[0] == 10);
    assert(b1.size() == 0);  // moved-from should be empty
    std::cout << "PASS: test_move_constructor\n";
}

void test_move_assignment() {
    Buffer b1(5);
    b1[0] = 10;
    Buffer b2(3);
    b2 = std::move(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 10);
    assert(b1.size() == 0);  // moved-from should be empty
    std::cout << "PASS: test_move_assignment\n";
}

void test_move_self() {
    Buffer b(5);
    b[0] = 42;
    b = std::move(b);
    assert(b.size() == 5);
    assert(b[0] == 42);  // self-move should preserve content
    std::cout << "PASS: test_move_self\n";
}

void test_copy_self() {
    Buffer b(5);
    b[0] = 42;
    b = b;
    assert(b.size() == 5);
    assert(b[0] == 42);  // self-copy should preserve content
    std::cout << "PASS: test_copy_self\n";
}

void test_moved_from_reusable() {
    Buffer b(5);
    b[0] = 10;
    Buffer b2(std::move(b));
    assert(b2.size() == 5);
    assert(b2[0] == 10);
    b2[0] = 100;  // should be able to write to moved-from buffer
    assert(b2[0] == 100);
    std::cout << "PASS: test_moved_from_reusable\n";
}

void test_resize_preserves_prefix() {
    Buffer b(10);
    for (size_t i = 0; i < 10; ++i) {
        b[i] = static_cast<std::uint8_t>(i + 1);
    }
    b.resize(5);
    for (size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
    std::cout << "PASS: test_resize_preserves_prefix\n";
}

void test_resize_zero_initializes_new_bytes() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b[3] == 0);
    assert(b[4] == 0);
    std::cout << "PASS: test_resize_zero_initializes_new_bytes\n";
}

void test_operator_equals() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(3);
    b2[0] = 1;
    b2[1] = 2;
    b2[2] = 3;
    assert(b1 == b2);
    
    Buffer b3(3);
    b3[0] = 1;
    b3[1] = 2;
    b3[2] = 4;
    assert(b1 != b3);
    std::cout << "PASS: test_operator_equals\n";
}

void test_operator_not_equals() {
    Buffer b1(3);
    b1[0] = 1;
    Buffer b2(3);
    b2[0] = 2;
    assert(b1 != b2);
    std::cout << "PASS: test_operator_not_equals\n";
}

void test_empty_buffer() {
    Buffer b;
    assert(b.empty());
    Buffer b2(0);
    assert(b2.empty());
    std::cout << "PASS: test_empty_buffer\n";
}

void test_data_pointer() {
    Buffer b(5);
    b[0] = 42;
    assert(*b.data() == 42);
    const Buffer cb(5);
    assert(*cb.data() == 0);
    std::cout << "PASS: test_data_pointer\n";
}

int main() {
    test_constructor_default();
    test_constructor_size();
    test_resize_grow();
    test_resize_shrink();
    test_resize_same();
    test_operator_bracket_mutable();
    test_operator_bracket_const();
    test_operator_bracket_out_of_bounds();
    test_deep_copy_constructor();
    test_deep_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_move_self();
    test_copy_self();
    test_moved_from_reusable();
    test_resize_preserves_prefix();
    test_resize_zero_initializes_new_bytes();
    test_operator_equals();
    test_operator_not_equals();
    test_empty_buffer();
    test_data_pointer();
    
    std::cout << "\nAll tests passed!\n";
    return 0;
}
