#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>

class Buffer {
public:
    using value_type = std::uint8_t;
    using size_type = std::size_t;

private:
    std::uint8_t* p_;
    size_type n_;

public:
    constexpr Buffer() noexcept : p_(nullptr), n_(0) {}

    explicit Buffer(size_type n) : n_(n) {
        if (n_ == 0) {
            p_ = nullptr;
        } else {
            p_ = new(std::nothrow) std::uint8_t[n_];
            if (p_ == nullptr) {
                throw std::bad_alloc();
            }
            // Zero-initialize the buffer
            std::fill(p_, p_ + n_, static_cast<std::uint8_t>(0));
        }
    }

    Buffer(const Buffer& other) noexcept(false) : p_(nullptr), n_(other.n_) {
        if (n_ > 0) {
            p_ = new std::uint8_t[n_];
            if (p_ != nullptr) {
                std::copy(other.p_, other.p_ + n_, p_);
            } else {
                throw std::bad_alloc();
            }
        }
    }

    Buffer(Buffer&& other) noexcept : p_(other.p_), n_(other.n_) {
        other.p_ = nullptr;
        other.n_ = 0;
    }

    ~Buffer() noexcept {
        delete[] p_;
    }

    Buffer& operator=(const Buffer& other) noexcept(false) {
        if (this != &other) {
            delete[] p_;
            n_ = other.n_;
            if (n_ > 0) {
                p_ = new std::uint8_t[n_];
                if (p_ == nullptr) {
                    throw std::bad_alloc();
                }
                std::copy(other.p_, other.p_ + n_, p_);
            } else {
                p_ = nullptr;
            }
        }
        return *this;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p_;
            p_ = other.p_;
            n_ = other.n_;
            other.p_ = nullptr;
            other.n_ = 0;
        }
        return *this;
    }

    size_type size() const noexcept {
        return n_;
    }

    bool empty() const noexcept {
        return n_ == 0;
    }

    value_type& operator[](size_type i) {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    const value_type& operator[](size_type i) const {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    void resize(size_type n) {
        if (n > n_) {
            std::uint8_t* new_p = new std::uint8_t[n];
            if (new_p == nullptr) {
                throw std::bad_alloc();
            }
            // Copy existing data
            size_type copy_count = (n_ < n) ? n_ : n;
            std::copy(p_, p_ + copy_count, new_p);
            // Zero-initialize new bytes
            std::fill(new_p + copy_count, new_p + n, static_cast<std::uint8_t>(0));
            delete[] p_;
            p_ = new_p;
            n_ = n;
        } else if (n < n_) {
            // Shrink: keep existing data, zero-pad if needed
            std::uint8_t* new_p = new std::uint8_t[n];
            if (new_p == nullptr) {
                throw std::bad_alloc();
            }
            size_type copy_count = (n_ < n) ? n_ : n;
            std::copy(p_, p_ + copy_count, new_p);
            std::fill(new_p + copy_count, new_p + n, static_cast<std::uint8_t>(0));
            delete[] p_;
            p_ = new_p;
            n_ = n;
        }
        // If n == n_, do nothing
    }

    bool operator==(const Buffer& other) const noexcept {
        if (n_ != other.n_) {
            return false;
        }
        return std::equal(p_, p_ + n_, other.p_);
    }

    bool operator!=(const Buffer& other) const noexcept {
        return !(*this == other);
    }

    // Access data pointer (for internal use or debugging)
    std::uint8_t* data() noexcept {
        return p_;
    }

    const std::uint8_t* data() const noexcept {
        return p_;
    }
};
