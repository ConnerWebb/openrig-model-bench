# Buffer Library

A C++20 RAII-based buffer implementation with bounds checking and proper memory management.

## Features

- **RAII Design**: Automatic memory management with no leaks or double-frees
- **Bounds Checking**: All index operations throw `std::out_of_range` on invalid access
- **Deep Copy Semantics**: Copy constructor and assignment operator perform deep copies
- **Move Semantics**: Efficient move constructor and assignment operator
- **Self-Copy/Self-Move**: Copying or moving a buffer onto itself preserves its content
- **Resize with Preservation**: `resize()` preserves existing data and zero-initializes new bytes
- **Zero Initialization**: All allocated buffers are zero-initialized on construction

## API

### Constructor
```cpp
Buffer() noexcept;                    // Default constructor (empty buffer)
Buffer(size_t n);                    // Constructor with size n
```

### Destructor
```cpp
~Buffer();                           // Automatically frees allocated memory
```

### Size Operations
```cpp
size_t size() const noexcept;        // Returns buffer size
bool empty() const noexcept;         // Returns true if size is 0
void resize(size_t n);               // Resizes buffer, preserving prefix
```

### Element Access
```cpp
std::uint8_t& operator[](size_t i);  // Mutable access with bounds check
const std::uint8_t& operator[](size_t i) const;  // Const access with bounds check
```

### Copy Semantics
```cpp
Buffer(const Buffer& other);         // Deep copy constructor
Buffer& operator=(const Buffer& other);  // Deep copy assignment
```

### Move Semantics
```cpp
Buffer(Buffer&& other) noexcept;     // Move constructor
Buffer& operator=(Buffer&& other) noexcept;  // Move assignment
```

### Utilities
```cpp
std::uint8_t* data() noexcept;       // Returns pointer to underlying data
const std::uint8_t* data() const noexcept;  // Const version
bool operator==(const Buffer& other) const noexcept;  // Equality comparison
bool operator!=(const Buffer& other) const noexcept;  // Inequality comparison
```

## Error Handling

- **`std::bad_alloc`**: Thrown if memory allocation fails
- **`std::out_of_range`**: Thrown when accessing an index >= size()

## Example Usage

```cpp
#include "solution.hpp"

int main() {
    // Create a buffer of size 5
    Buffer buf(5);
    
    // Write to buffer
    buf[0] = 42;
    buf[1] = 100;
    
    // Resize buffer (preserves data, zero-initializes new bytes)
    buf.resize(10);
    assert(buf[5] == 0);
    
    // Copy buffer
    Buffer buf2(buf);
    
    // Move buffer
    Buffer buf3(std::move(buf2));
    
    return 0;
}
```

## Building and Testing

```bash
# Compile and run tests
clang++-22 -std=c++20 -fuse-ld=bfd -I. tests/test_buffer.cpp -o test_buffer
./test_buffer
```

## Implementation Notes

- Uses `new[]`/`delete[]` for dynamic memory allocation
- Zero-initializes all allocated memory using `std::fill`
- Implements strong exception safety for copy operations
- Move operations are noexcept and leave moved-from objects in a valid empty state
- Self-copy and self-move operations preserve the buffer's content
