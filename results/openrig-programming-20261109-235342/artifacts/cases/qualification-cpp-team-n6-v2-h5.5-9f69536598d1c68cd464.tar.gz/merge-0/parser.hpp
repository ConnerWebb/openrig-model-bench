#pragma once
#include <map>
#include <string>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <limits>
#include <vector>
inline std::map<std::string,std::int64_t> aggregate(std::istream& in){
 std::map<std::string,std::int64_t> out;std::vector<std::string> row;std::string f;bool quote=false,closed=false,at_start=true,header=false;int ch;
 auto trim=[](std::string s){auto a=s.find_first_not_of(" \t\r"),b=s.find_last_not_of(" \t\r");return a==std::string::npos?std::string():s.substr(a,b-a+1);};
 auto record=[&]{if(row.empty()&&f.empty()&&!closed)return;row.push_back(f);f.clear();closed=false;at_start=true;if(!header){if(row!=std::vector<std::string>{"category","amount"})throw std::invalid_argument("header");header=true;}else{if(row.size()!=2)throw std::invalid_argument("columns");auto k=trim(row[0]),v=trim(row[1]);if(k.empty()||v.empty())throw std::invalid_argument("empty");std::size_t p=0;if(v[0]=='+'||v[0]=='-')p++;if(p==v.size())throw std::invalid_argument("number");for(auto i=p;i<v.size();i++)if(v[i]<'0'||v[i]>'9')throw std::invalid_argument("digit");std::size_t end=0;auto n=std::stoll(v,&end);if(end!=v.size())throw std::invalid_argument("number");auto old=out[k];bool overflow=false;if(n>0){if(old>std::numeric_limits<std::int64_t>::max()-n)overflow=true;}else if(n<0){if(old<std::numeric_limits<std::int64_t>::min()-n)overflow=true;}if(overflow)throw std::invalid_argument("overflow");out[k]=old+n;}row.clear();};
 while((ch=in.get())!=EOF){char c=ch;if(quote){if(c=='"'){if(in.peek()=='"'){in.get();f+='"';}else{quote=false;closed=true;}}else f+=c;continue;}if(c=='"'){if(!at_start||closed)throw std::invalid_argument("quote");quote=true;at_start=false;}else if(c==','){row.push_back(f);f.clear();at_start=true;closed=false;}else if(c=='\n'){record();}else{if(closed&&c!='\r')throw std::invalid_argument("after quote");if(!closed){f+=c;at_start=false;}}}
 if(quote)throw std::invalid_argument("quote");record();if(!header)throw std::invalid_argument("header");return out;
}
