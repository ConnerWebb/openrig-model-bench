import unittest,tempfile,pathlib,subprocess
class ModuleCheck(unittest.TestCase):
 def test_parser(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/"t.cpp").write_text('#include "solution.hpp"\n#include <sstream>\n#include <cassert>\nint main(){std::istringstream s("category,amount\\na,3\\n");assert(aggregate(s).at("a")==3);}');r=subprocess.run(["clang++","-fuse-ld=bfd","-std=c++20","-I/work",str(p/"t.cpp"),"-o",str(p/"t")],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(subprocess.run([str(p/"t")]).returncode,0)
