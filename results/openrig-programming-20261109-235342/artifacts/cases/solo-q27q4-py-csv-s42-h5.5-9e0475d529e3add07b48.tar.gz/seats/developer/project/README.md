# CSV Category Aggregator

## API

```python
solution.aggregate(path: str) -> dict[str, str]
```

Reads a UTF-8 CSV file **as a stream** (line-by-line via `csv.reader`, never
loading the whole file into memory) and returns a dict mapping each category
to its total amount, formatted with exactly two decimal places. Keys are
sorted.

## Contract

- Header must be exactly `category,amount`.
- Completely blank records are ignored; every other record must have exactly
  two fields.
- `category` and `amount` are whitespace-stripped; category must be non-empty.
- Amount grammar: optional `+`, 1–12 decimal digits, optional `.` followed by
  1 or 2 digits. Nonnegative, finite, no exponent.
- Any malformed input raises `ValueError`.
- Accumulation uses exact `decimal.Decimal` arithmetic (no float drift).
- Quoted commas and embedded newlines are valid CSV and handled correctly.

## Tests

`test_solution.py` (stdlib `unittest`) covers:

- All 13 public cases from `PUBLIC_CASES.json` (valid aggregates and
  `ValueError` expectations).
- Blank-line skipping, `+` prefix, integer amounts, exact decimal
  accumulation (`0.1 + 0.2 == 0.30`), whitespace stripping, and a battery of
  malformed amounts.

Run with:

```bash
python3 -m unittest test_solution -v
```
