"""Streaming CSV aggregation.

aggregate(path) reads a UTF-8 CSV file as a stream, validates each record
against a strict contract, and returns per-category totals using exact
decimal arithmetic.
"""

import csv
import re
from decimal import Decimal

# Optional '+', 1-12 digits, optional '.' followed by 1-2 digits.
_AMOUNT_RE = re.compile(r"^\+?\d{1,12}(\.\d{1,2})?$")


def _parse_amount(raw: str) -> Decimal:
    """Validate and convert one amount field to an exact Decimal."""
    text = raw.strip()
    if not _AMOUNT_RE.match(text):
        raise ValueError(f"malformed amount: {raw!r}")
    return Decimal(text)


def aggregate(path: str) -> dict[str, str]:
    """Aggregate a category,amount CSV file into sorted two-decimal totals."""
    totals: dict[str, Decimal] = {}
    with open(path, "r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("missing header")
        if header != ["category", "amount"]:
            raise ValueError("header must be exactly category,amount")
        for record in reader:
            if not record:
                continue  # completely blank record
            if len(record) != 2:
                raise ValueError(f"record must have exactly two fields: {record!r}")
            category = record[0].strip()
            if not category:
                raise ValueError("category must not be empty")
            amount = _parse_amount(record[1])
            totals[category] = totals.get(category, Decimal(0)) + amount
    return {key: f"{totals[key]:.2f}" for key in sorted(totals)}
