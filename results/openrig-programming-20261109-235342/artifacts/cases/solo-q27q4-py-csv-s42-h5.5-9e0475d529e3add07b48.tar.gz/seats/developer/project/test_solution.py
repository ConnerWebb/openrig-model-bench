import json
import pathlib
import tempfile
import unittest

import solution

CASES = json.loads(pathlib.Path("PUBLIC_CASES.json").read_text(encoding="utf-8"))


class AggregateTests(unittest.TestCase):
    def _run(self, csv_text: str):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / "input.csv"
            p.write_text(csv_text, encoding="utf-8")
            return solution.aggregate(str(p))

    def test_public_cases(self):
        for i, case in enumerate(CASES):
            with self.subTest(case=i):
                csv_text = case["driver_input"]["csv"]
                expected = case["expected"]
                if "error" in expected:
                    with self.assertRaises(ValueError):
                        self._run(csv_text)
                else:
                    self.assertEqual(self._run(csv_text), expected["value"])

    def test_blank_lines_ignored(self):
        self.assertEqual(
            self._run("category,amount\n\na,1.5\n\n\nb,2\n"),
            {"a": "1.50", "b": "2.00"},
        )

    def test_plus_sign_and_integers(self):
        self.assertEqual(
            self._run("category,amount\na,+3\nb,0\nc,123456789012\n"),
            {"a": "3.00", "b": "0.00", "c": "123456789012.00"},
        )

    def test_exact_decimal_accumulation(self):
        # 0.1 + 0.2 must be exactly 0.3, not a float artifact.
        self.assertEqual(
            self._run("category,amount\na,0.1\na,0.2\n"),
            {"a": "0.30"},
        )

    def test_whitespace_stripped(self):
        self.assertEqual(
            self._run("category,amount\n  a  ,  1.25  \n"),
            {"a": "1.25"},
        )

    def test_malformed_amounts(self):
        for bad in ["1.", ".5", "1.234", "1e3", "+", "1 2", "1,000", "inf", "1234567890123"]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    self._run(f"category,amount\nx,{bad}\n")

    def test_missing_file_raises(self):
        with self.assertRaises(OSError):
            solution.aggregate("/nonexistent/input.csv")


if __name__ == "__main__":
    unittest.main()
