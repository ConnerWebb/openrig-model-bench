import unittest
import json
import copy
import sys
import os
import tempfile
import subprocess

sys.path.insert(0, '/work')
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    def test_normalize_valid(self):
        records = [{'id': '  x  ', 'category': '  a  ', 'cents': 10}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 10}])

    def test_normalize_invalid_keys(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 10, 'extra': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_missing_keys(self):
        records = [{'id': 'x', 'category': 'a'}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_empty_id(self):
        records = [{'id': '', 'category': 'a', 'cents': 10}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_whitespace_id(self):
        records = [{'id': '   ', 'category': 'a', 'cents': 10}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_empty_category(self):
        records = [{'id': 'x', 'category': '', 'cents': 10}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_whitespace_category(self):
        records = [{'id': 'x', 'category': '   ', 'cents': 10}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_negative_cents(self):
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_boolean_cents(self):
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_non_dict(self):
        records = ['not a dict']
        with self.assertRaises(ValueError):
            validation.normalize(records)


class TestStorage(unittest.TestCase):
    def test_deduplicate_basic(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 10},
            {'id': 'y', 'category': 'b', 'cents': 20},
            {'id': 'x', 'category': 'c', 'cents': 30}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'x')
        self.assertEqual(result[1]['id'], 'y')

    def test_deduplicate_first_wins(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 10},
            {'id': 'x', 'category': 'b', 'cents': 20}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result[0]['category'], 'a')

    def test_deduplicate_no_duplicates(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 10},
            {'id': 'y', 'category': 'b', 'cents': 20}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)

    def test_deduplicate_empty(self):
        result = storage.deduplicate([])
        self.assertEqual(result, [])

    def test_deduplicate_returns_fresh_copies(self):
        records = [{'id': 'x', 'category': 'a', 'cents': 10}]
        result = storage.deduplicate(records)
        result[0]['category'] = 'modified'
        self.assertEqual(records[0]['category'], 'a')


class TestLedger(unittest.TestCase):
    def test_process_basic(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 10},
            {'id': 'y', 'category': 'b', 'cents': 20}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['totals'], {'a': 10, 'b': 20})

    def test_process_deduplication(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 10},
            {'id': 'x', 'category': 'b', 'cents': 20}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'a')
        self.assertEqual(result['totals'], {'a': 10})

    def test_process_empty(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_process_minimum_cents(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 5},
            {'id': 'y', 'category': 'b', 'cents': 15}
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'y')
        self.assertEqual(result['totals'], {'b': 15})

    def test_process_minimum_cents_zero(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': 0},
            {'id': 'y', 'category': 'b', 'cents': 10}
        ]
        result = ledger.process(records, minimum_cents=0)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['totals'], {'a': 0, 'b': 10})

    def test_process_totals_sorted(self):
        records = [
            {'id': 'x', 'category': 'c', 'cents': 10},
            {'id': 'y', 'category': 'a', 'cents': 20},
            {'id': 'z', 'category': 'b', 'cents': 30}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_process_input_unchanged(self):
        records = [
            {'id': '  x  ', 'category': '  a  ', 'cents': 10}
        ]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_process_invalid_record(self):
        records = [
            {'id': 'x', 'category': 'a', 'cents': -1}
        ]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_process_invalid_minimum_cents(self):
        records = []
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)

    def test_process_boolean_minimum_cents(self):
        records = []
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)


class TestIntegration(unittest.TestCase):
    def test_public_case_00(self):
        with open('/work/public-inputs/case-00.json') as f:
            data = json.load(f)
        records = data['records']
        result = ledger.process(records)
        self.assertIn('events', result)
        self.assertIn('totals', result)
        self.assertIsInstance(result['events'], list)
        self.assertIsInstance(result['totals'], dict)

    def test_public_case_01(self):
        with open('/work/public-inputs/case-01.json') as f:
            data = json.load(f)
        records = data['records']
        result = ledger.process(records)
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_02(self):
        with open('/work/public-inputs/case-02.json') as f:
            data = json.load(f)
        records = data['records']
        result = ledger.process(records)
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_03(self):
        with open('/work/public-inputs/case-03.json') as f:
            data = json.load(f)
        records = data['records']
        result = ledger.process(records)
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_04_invalid_cents_type(self):
        with open('/work/public-inputs/case-04.json') as f:
            data = json.load(f)
        records = data['records']
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_public_case_05_empty_id(self):
        with open('/work/public-inputs/case-05.json') as f:
            data = json.load(f)
        records = data['records']
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_public_case_06_negative_cents(self):
        with open('/work/public-inputs/case-06.json') as f:
            data = json.load(f)
        records = data['records']
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_public_case_07_extra_key(self):
        with open('/work/public-inputs/case-07.json') as f:
            data = json.load(f)
        records = data['records']
        with self.assertRaises(ValueError):
            ledger.process(records)


class TestDriver(unittest.TestCase):
    def test_driver_integration(self):
        test_cases = [
            ('/work/public-inputs/case-00.json', False),
            ('/work/public-inputs/case-04.json', True),
            ('/work/public-inputs/case-05.json', True),
            ('/work/public-inputs/case-06.json', True),
            ('/work/public-inputs/case-07.json', True),
        ]
        for case_path, should_fail in test_cases:
            with open(case_path) as f:
                data = json.load(f)
            with tempfile.TemporaryDirectory() as tmpdir:
                input_path = os.path.join(tmpdir, 'input.json')
                output_path = os.path.join(tmpdir, 'output.json')
                with open(input_path, 'w') as f:
                    json.dump(data, f)
                cmd = [
                    sys.executable, '/work/PUBLIC_DRIVER.py'
                ]
                with open(input_path) as inp:
                    proc = subprocess.run(
                        cmd, stdin=inp, capture_output=True, text=True, cwd=tmpdir
                    )
                if should_fail:
                    self.assertIn('error', proc.stdout, f'Expected error for {case_path}')
                else:
                    self.assertNotIn('error', proc.stdout, f'Unexpected error for {case_path}')
                    output = json.loads(proc.stdout)
                    self.assertIn('value', output)
                    self.assertIn('empty', output)
                    self.assertIn('input_unchanged', output)


if __name__ == '__main__':
    unittest.main()
