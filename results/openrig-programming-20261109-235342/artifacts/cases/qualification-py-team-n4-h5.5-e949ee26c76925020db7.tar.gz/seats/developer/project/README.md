# Ledger Toolkit

Three-module toolkit for normalizing, deduplicating, and aggregating ledger records.

## Modules

### validation.py
- `normalize(records)` → list of fresh normalized records
- Validates every record: `id` and `category` must be nonempty stripped strings; `cents` must be a nonnegative integer (booleans are invalid); record must have exactly these three keys.
- Preserves duplicates; never mutates input.

### storage.py
- `deduplicate(records)` → list of fresh copies
- Input must already be validated.
- Retains first occurrence of each `id` in input order.

### ledger.py
- `process(records, *, minimum_cents=0)` → `{'events': [...], 'totals': {...}}`
- Composes `normalize` and `deduplicate`, then filters by `minimum_cents`.
- Returns events in input order (after deduplication) and totals with sorted category keys.
- `minimum_cents` must be a nonnegative integer (booleans are invalid).

## Usage

```python
from ledger import process

records = [
    {'id': 'a', 'category': 'x', 'cents': 10},
    {'id': 'b', 'category': 'x', 'cents': 20},
]
result = process(records, minimum_cents=15)
# result = {'events': [{'id': 'b', 'category': 'x', 'cents': 20}], 'totals': {'x': 20}}
```

## Tests

Run `python3 test_submission.py` to validate against public cases and custom tests.
