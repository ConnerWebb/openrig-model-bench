"""Tests for JobQueue implementation."""

import json
import os
import tempfile
import time
import unittest

from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    """Test cases for JobQueue."""

    def setUp(self):
        """Create a temporary database for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test.db")

    def tearDown(self):
        """Clean up temporary files."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_enqueue_new_key(self):
        """Test enqueueing a new key returns True."""
        queue = JobQueue(self.db_path)
        result = queue.enqueue("key1", {"data": "value"})
        self.assertTrue(result)

    def test_enqueue_duplicate_key(self):
        """Test enqueueing a duplicate key returns False."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        result = queue.enqueue("key1", {"data": "new_value"})
        self.assertFalse(result)

    def test_enqueue_empty_key_raises(self):
        """Test enqueueing with empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.enqueue("", {"data": "value"})

    def test_claim_returns_job(self):
        """Test claiming a job returns the job data."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        result = queue.claim("worker1", 1000.0, 60.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": "value"})
        self.assertEqual(result["attempts"], 1)

    def test_claim_no_jobs(self):
        """Test claiming when no jobs exist returns None."""
        queue = JobQueue(self.db_path)
        result = queue.claim("worker1", 1000.0, 60.0)
        self.assertIsNone(result)

    def test_claim_sets_state(self):
        """Test claiming a job sets its state to leased."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        status = queue.status("key1")
        self.assertEqual(status["state"], "leased")

    def test_claim_empty_worker_raises(self):
        """Test claiming with empty worker raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("", 1000.0, 60.0)

    def test_claim_zero_lease_raises(self):
        """Test claiming with zero lease raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("worker1", 1000.0, 0.0)

    def test_claim_negative_lease_raises(self):
        """Test claiming with negative lease raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("worker1", 1000.0, -1.0)

    def test_claim_negative_max_attempts_raises(self):
        """Test initializing with negative max_attempts raises ValueError."""
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)

    def test_claim_negative_max_attempts_zero_raises(self):
        """Test initializing with zero max_attempts raises ValueError."""
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)

    def test_complete_success(self):
        """Test completing a job returns True."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        result = queue.complete("key1", "worker1")
        self.assertTrue(result)

    def test_complete_wrong_worker(self):
        """Test completing with wrong worker returns False."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        result = queue.complete("key1", "worker2")
        self.assertFalse(result)

    def test_complete_not_found(self):
        """Test completing a non-existent job returns False."""
        queue = JobQueue(self.db_path)
        result = queue.complete("key1", "worker1")
        self.assertFalse(result)

    def test_complete_empty_key_raises(self):
        """Test completing with empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.complete("", "worker1")

    def test_complete_empty_worker_raises(self):
        """Test completing with empty worker raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.complete("key1", "")

    def test_fail_success(self):
        """Test failing a job returns True."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        result = queue.fail("key1", "worker1")
        self.assertTrue(result)

    def test_fail_wrong_worker(self):
        """Test failing with wrong worker returns False."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        result = queue.fail("key1", "worker2")
        self.assertFalse(result)

    def test_fail_requeues(self):
        """Test failing a job requeues it if attempts < max_attempts."""
        queue = JobQueue(self.db_path, max_attempts=3)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        queue.fail("key1", "worker1")
        status = queue.status("key1")
        self.assertEqual(status["state"], "queued")

    def test_fail_exhausted(self):
        """Test failing a job marks as failed when attempts exhausted."""
        queue = JobQueue(self.db_path, max_attempts=1)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        queue.fail("key1", "worker1")
        status = queue.status("key1")
        self.assertEqual(status["state"], "failed")

    def test_fail_empty_key_raises(self):
        """Test failing with empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.fail("", "worker1")

    def test_fail_empty_worker_raises(self):
        """Test failing with empty worker raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.fail("key1", "")

    def test_status_found(self):
        """Test status returns job info."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        status = queue.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_status_not_found(self):
        """Test status returns None for non-existent job."""
        queue = JobQueue(self.db_path)
        status = queue.status("key1")
        self.assertIsNone(status)

    def test_status_empty_key_raises(self):
        """Test status with empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.status("")

    def test_claim_oldest_first(self):
        """Test claiming returns jobs in insertion order."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value1"})
        queue.enqueue("key2", {"data": "value2"})
        result1 = queue.claim("worker1", 1000.0, 60.0)
        result2 = queue.claim("worker1", 1000.0, 60.0)
        self.assertEqual(result1["key"], "key1")
        self.assertEqual(result2["key"], "key2")

    def test_claim_expired_lease(self):
        """Test claiming an expired lease returns the job."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        # Lease expires at 1060, claim at 1061
        result = queue.claim("worker2", 1061.0, 60.0)
        self.assertEqual(result["key"], "key1")

    def test_claim_max_attempts(self):
        """Test jobs with max attempts are not claimed."""
        queue = JobQueue(self.db_path, max_attempts=2)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        queue.fail("key1", "worker1")
        queue.claim("worker1", 1000.0, 60.0)
        queue.fail("key1", "worker1")
        # Now at max attempts, should not claim
        result = queue.claim("worker1", 1000.0, 60.0)
        self.assertIsNone(result)

    def test_claim_non_expired_lease(self):
        """Test jobs with non-expired lease are not claimed."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value"})
        queue.claim("worker1", 1000.0, 60.0)
        # Lease expires at 1060, claim at 1059
        result = queue.claim("worker2", 1059.0, 60.0)
        self.assertIsNone(result)

    def test_multiple_workers(self):
        """Test multiple workers can claim different jobs."""
        queue = JobQueue(self.db_path)
        queue.enqueue("key1", {"data": "value1"})
        queue.enqueue("key2", {"data": "value2"})
        result1 = queue.claim("worker1", 1000.0, 60.0)
        result2 = queue.claim("worker2", 1000.0, 60.0)
        self.assertEqual(result1["key"], "key1")
        self.assertEqual(result2["key"], "key2")

    def test_json_payload(self):
        """Test various JSON-compatible payloads."""
        queue = JobQueue(self.db_path)
        payloads = [
            {"data": "value"},
            [1, 2, 3],
            "string",
            123,
            True,
            None,
            {"nested": {"data": "value"}}
        ]
        for i, payload in enumerate(payloads):
            queue.enqueue(f"key{i}", payload)
            result = queue.claim(f"worker{i}", 1000.0, 60.0)
            self.assertEqual(result["payload"], payload)

    def test_separate_instances_share_db(self):
        """Test separate instances share the database."""
        queue1 = JobQueue(self.db_path)
        queue1.enqueue("key1", {"data": "value1"})
        queue2 = JobQueue(self.db_path)
        result = queue2.claim("worker1", 1000.0, 60.0)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": "value1"})


if __name__ == "__main__":
    unittest.main()
