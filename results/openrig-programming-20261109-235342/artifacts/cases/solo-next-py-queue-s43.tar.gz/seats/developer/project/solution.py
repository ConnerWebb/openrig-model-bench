"""JobQueue implementation using SQLite."""

import json
import sqlite3
from typing import Optional, Dict, Any


class JobQueue:
    """A job queue using SQLite for persistence and atomic operations."""

    def __init__(self, path: str, max_attempts: int = 3):
        """Initialize the queue with a database path and max attempts."""
        if max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        """Get a database connection with appropriate settings."""
        conn = sqlite3.connect(self.path, isolation_level=None)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_db(self) -> None:
        """Initialize the database schema."""
        conn = self._get_conn()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'queued',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    owner TEXT,
                    lease_until REAL,
                    inserted INTEGER NOT NULL DEFAULT 0
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_jobs_state_owner
                ON jobs(state, owner, lease_until)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_jobs_state_attempts
                ON jobs(state, attempts)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_jobs_inserted
                ON jobs(inserted)
            """)
        finally:
            conn.close()

    def enqueue(self, key: str, payload: Any) -> bool:
        """Add a job to the queue. Returns True if inserted, False if key exists."""
        if not key:
            raise ValueError("key must be non-empty")
        
        payload_json = json.dumps(payload)
        conn = self._get_conn()
        try:
            conn.execute("""
                INSERT OR IGNORE INTO jobs (key, payload, state, attempts, inserted)
                VALUES (?, ?, 'queued', 0, COALESCE((SELECT MAX(inserted) FROM jobs), 0) + 1)
            """, (key, payload_json))
            # Check if row was actually inserted
            cursor = conn.execute("SELECT changes()")
            return cursor.fetchone()[0] == 1
        finally:
            conn.close()

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        """Claim the oldest eligible job for a worker."""
        if not worker:
            raise ValueError("worker must be non-empty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        
        lease_until = now + lease
        
        conn = self._get_conn()
        try:
            # Find the oldest eligible job (queued or leased with expired lease)
            # that hasn't exceeded max_attempts, ordered by insertion order
            cursor = conn.execute("""
                SELECT key, payload, attempts
                FROM jobs
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                  AND attempts < ?
                ORDER BY inserted ASC
                LIMIT 1
            """, (now, self.max_attempts))
            
            row = cursor.fetchone()
            if row is None:
                return None
            
            key, payload_json, attempts = row
            payload = json.loads(payload_json)
            
            new_attempts = attempts + 1
            # If attempts exhausted after this claim, mark as failed
            if new_attempts >= self.max_attempts:
                conn.execute("""
                    UPDATE jobs
                    SET state = 'failed',
                        attempts = ?
                    WHERE key = ?
                """, (new_attempts, key))
            else:
                conn.execute("""
                    UPDATE jobs
                    SET state = 'leased',
                        owner = ?,
                        lease_until = ?,
                        attempts = ?
                    WHERE key = ?
                """, (worker, lease_until, new_attempts, key))
            
            return {
                "key": key,
                "payload": payload,
                "attempts": new_attempts
            }
        finally:
            conn.close()

    def complete(self, key: str, worker: str) -> bool:
        """Mark a job as completed. Requires matching owner."""
        if not key:
            raise ValueError("key must be non-empty")
        if not worker:
            raise ValueError("worker must be non-empty")
        
        conn = self._get_conn()
        try:
            # Verify the job is leased by this worker
            cursor = conn.execute(
                "SELECT state, owner FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            if row is None:
                return False
            state, owner = row
            if state != 'leased' or owner != worker:
                return False
            
            # Mark as done
            conn.execute("""
                UPDATE jobs
                SET state = 'done'
                WHERE key = ?
            """, (key,))
            return True
        finally:
            conn.close()

    def fail(self, key: str, worker: str) -> bool:
        """Mark a job as failed. Requires matching owner."""
        if not key:
            raise ValueError("key must be non-empty")
        if not worker:
            raise ValueError("worker must be non-empty")
        
        conn = self._get_conn()
        try:
            # Verify the job is leased by this worker
            cursor = conn.execute(
                "SELECT state, owner, attempts FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            if row is None:
                return False
            state, owner, attempts = row
            if state != 'leased' or owner != worker:
                return False
            
            # If attempts exhausted, mark as failed; otherwise requeue
            if attempts >= self.max_attempts:
                conn.execute("""
                    UPDATE jobs
                    SET state = 'failed'
                    WHERE key = ?
                """, (key,))
            else:
                conn.execute("""
                    UPDATE jobs
                    SET state = 'queued',
                        owner = NULL,
                        lease_until = NULL
                    WHERE key = ?
                """, (key,))
            return True
        finally:
            conn.close()

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        """Get the status of a job."""
        if not key:
            raise ValueError("key must be non-empty")
        
        conn = self._get_conn()
        try:
            cursor = conn.execute(
                "SELECT state, attempts FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            if row is None:
                return None
            state, attempts = row
            return {
                "state": state,
                "attempts": attempts
            }
        finally:
            conn.close()
