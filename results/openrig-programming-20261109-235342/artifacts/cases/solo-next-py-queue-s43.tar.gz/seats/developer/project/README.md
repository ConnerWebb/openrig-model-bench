# JobQueue

A job queue implementation using SQLite for persistence and atomic operations.

## Features

- **Persistent storage**: Jobs are stored in SQLite, surviving process restarts
- **Atomic operations**: All operations are atomic, preventing race conditions
- **Worker leasing**: Jobs can be claimed by workers with configurable lease timeouts
- **Retry with max attempts**: Failed jobs are requeued up to a configurable maximum
- **Multiple workers**: Multiple workers can claim and process jobs concurrently

## Usage

```python
from solution import JobQueue

# Create a queue
queue = JobQueue("jobs.db", max_attempts=3)

# Add a job
queue.enqueue("job1", {"data": "value"})

# Claim a job (returns None if no jobs available)
job = queue.claim("worker1", time.time(), lease=60.0)
if job:
    print(f"Processing job {job['key']}")
    # Mark as complete
    queue.complete(job["key"], "worker1")
    # Or mark as failed
    # queue.fail(job["key"], "worker1")

# Check job status
status = queue.status("job1")
print(f"State: {status['state']}, Attempts: {status['attempts']}")
```

## API

### `JobQueue(path, max_attempts=3)`

Create a new job queue.

- `path`: Path to the SQLite database file
- `max_attempts`: Maximum number of attempts before marking a job as failed

### `enqueue(key, payload) -> bool`

Add a job to the queue.

- `key`: Unique identifier for the job
- `payload`: JSON-compatible value (dict, list, string, number, bool, None)
- Returns `True` if the job was inserted, `False` if the key already exists

### `claim(worker, now, lease) -> dict or None`

Claim the oldest eligible job for a worker.

- `worker`: Worker identifier
- `now`: Current timestamp (float)
- `lease`: Lease duration in seconds
- Returns a dict with `key`, `payload`, and `attempts`, or `None` if no jobs available

### `complete(key, worker) -> bool`

Mark a job as completed.

- `key`: Job identifier
- `worker`: Worker identifier (must match current owner)
- Returns `True` if successful, `False` otherwise

### `fail(key, worker) -> bool`

Mark a job as failed.

- `key`: Job identifier
- `worker`: Worker identifier (must match current owner)
- Returns `True` if successful, `False` otherwise
- If attempts < max_attempts, job is requeued; otherwise marked as failed

### `status(key) -> dict or None`

Get the status of a job.

- `key`: Job identifier
- Returns a dict with `state` and `attempts`, or `None` if not found

## States

- `queued`: Job is waiting to be claimed
- `leased`: Job is claimed by a worker
- `done`: Job was completed successfully
- `failed`: Job failed after max_attempts

## Error Handling

- Empty `key` or `worker` raises `ValueError`
- `lease <= 0` raises `ValueError`
- `max_attempts <= 0` raises `ValueError`

## Testing

```bash
python -m unittest test_solution
```
