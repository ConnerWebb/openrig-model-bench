# Buffer Library

A C++20 RAII-based buffer class with deep-copy semantics, move support, and bounds-checked access.

## Features

- `Buffer(size_t n=0)`: Construct with optional size, zero-initialized elements
- `size() const noexcept`: Return current buffer size
- `operator[](size_t)`: Bounds-checked mutable and const access, throws `std::out_of_range` on overflow
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction and assignment (noexcept move as well)
- Moved-from buffers have size 0 and are reusable
- Self-assignment and self-move preserve content

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // 10 zero-initialized bytes
b[0] = 42;              // mutable access
const Buffer& cb = b;
std::cout << (int)cb[0]; // const access

Buffer copy = b;        // deep copy
Buffer moved = std::move(b); // move; b is now empty
b.resize(20);           // resize, preserve prefix, zero-fill new bytes
```

## Testing

Run `run_tests` to verify against public cases and any local tests.
