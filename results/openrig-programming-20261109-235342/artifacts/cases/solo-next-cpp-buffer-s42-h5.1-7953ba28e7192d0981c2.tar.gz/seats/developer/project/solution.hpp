#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <memory>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    explicit Buffer(std::size_t n = 0) : p(n ? new std::uint8_t[n] : nullptr), n(n) {
        if (p) {
            std::fill(p, p + n, 0);
        }
    }

    ~Buffer() noexcept {
        delete[] p;
    }

    Buffer(const Buffer& other) : p(other.n ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (p && other.p) {
            std::copy(other.p, other.p + n, p);
        }
    }

    Buffer& operator=(const Buffer& other) noexcept {
        if (this != &other) {
            std::uint8_t* new_p = other.n ? new std::uint8_t[other.n] : nullptr;
            if (new_p && other.p) {
                std::copy(other.p, other.p + other.n, new_p);
            }
            delete[] p;
            p = new_p;
            n = other.n;
        }
        return *this;
    }

    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    std::size_t size() const noexcept {
        return n;
    }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    std::uint8_t operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    void resize(std::size_t k) {
        if (k == n) return;
        std::uint8_t* new_p = k ? new std::uint8_t[k] : nullptr;
        if (new_p) {
            std::fill(new_p, new_p + k, 0);
            if (p && n > 0) {
                std::size_t copy_n = std::min(n, k);
                std::copy(p, p + copy_n, new_p);
            }
        }
        delete[] p;
        p = new_p;
        n = k;
    }
};
