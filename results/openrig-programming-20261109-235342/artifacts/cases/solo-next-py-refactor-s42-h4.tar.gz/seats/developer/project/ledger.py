"""Ledger public facade - provides process(records) API."""

from engine import process

__all__ = ['process']
