"""Unit tests for ledger module."""

import unittest
from ledger import process


class TestLedgerProcess(unittest.TestCase):
    """Tests for the process function."""

    def test_empty_input(self):
        """process([]) returns empty events/totals."""
        result = process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_empty_input_with_minimum(self):
        """process([], minimum_cents=10) returns empty events/totals."""
        result = process([], minimum_cents=10)
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_single_valid_record(self):
        """Single valid record is returned with correct totals."""
        records = [{'id': 'a', 'category': 'x', 'cents': 100}]
        result = process(records)
        self.assertEqual(result['events'], [{'id': 'a', 'category': 'x', 'cents': 100}])
        self.assertEqual(result['totals'], {'x': 100})

    def test_whitespace_stripping(self):
        """Whitespace is stripped from id and category."""
        records = [{'id': ' a ', 'category': ' x ', 'cents': 50}]
        result = process(records)
        self.assertEqual(result['events'][0]['id'], 'a')
        self.assertEqual(result['events'][0]['category'], 'x')

    def test_minimum_cents_filter(self):
        """Records below minimum_cents are excluded."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 50},
            {'id': 'b', 'category': 'x', 'cents': 150},
        ]
        result = process(records, minimum_cents=100)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'b')
        self.assertEqual(result['totals'], {'x': 150})

    def test_minimum_cents_zero_default(self):
        """minimum_cents defaults to 0."""
        records = [{'id': 'a', 'category': 'x', 'cents': 0}]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 0)

    def test_deduplication_first_wins(self):
        """First occurrence of duplicate id wins."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 100},
            {'id': 'a', 'category': 'y', 'cents': 200},
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'x')
        self.assertEqual(result['events'][0]['cents'], 100)

    def test_totals_sorted_keys(self):
        """Totals keys are sorted."""
        records = [
            {'id': 'a', 'category': 'z', 'cents': 10},
            {'id': 'b', 'category': 'a', 'cents': 20},
            {'id': 'c', 'category': 'm', 'cents': 30},
        ]
        result = process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'm', 'z'])
        self.assertEqual(result['totals'], {'a': 20, 'm': 30, 'z': 10})

    def test_input_not_mutated(self):
        """Original records are not mutated."""
        records = [{'id': 'a', 'category': ' x ', 'cents': 100}]
        original = {'id': 'a', 'category': ' x ', 'cents': 100}
        process(records)
        self.assertEqual(records[0], original)

    def test_returns_new_dict_not_shared(self):
        """Return value is a new dict, not shared between calls."""
        result1 = process([{'id': 'a', 'category': 'x', 'cents': 100}])
        result2 = process([{'id': 'b', 'category': 'y', 'cents': 200}])
        self.assertIsNot(result1, result2)
        self.assertIsNot(result1['events'], result2['events'])
        self.assertIsNot(result1['totals'], result2['totals'])

    def test_invalid_record_not_dict(self):
        """Non-dict record raises ValueError."""
        with self.assertRaises(ValueError):
            process(['not a dict'])

    def test_invalid_record_extra_keys(self):
        """Record with extra keys raises ValueError."""
        records = [{'id': 'a', 'category': 'x', 'cents': 100, 'extra': 1}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_record_missing_keys(self):
        """Record with missing keys raises ValueError."""
        records = [{'id': 'a', 'category': 'x'}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_id_empty_string(self):
        """Empty id string raises ValueError."""
        records = [{'id': '', 'category': 'x', 'cents': 100}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_id_whitespace_only(self):
        """Whitespace-only id raises ValueError."""
        records = [{'id': '   ', 'category': 'x', 'cents': 100}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_id_not_string(self):
        """Non-string id raises ValueError."""
        records = [{'id': 123, 'category': 'x', 'cents': 100}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_category_empty_string(self):
        """Empty category string raises ValueError."""
        records = [{'id': 'a', 'category': '', 'cents': 100}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_category_not_string(self):
        """Non-string category raises ValueError."""
        records = [{'id': 'a', 'category': 123, 'cents': 100}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_cents_negative(self):
        """Negative cents raises ValueError."""
        records = [{'id': 'a', 'category': 'x', 'cents': -1}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_cents_boolean(self):
        """Boolean cents raises ValueError."""
        records = [{'id': 'a', 'category': 'x', 'cents': True}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_cents_float(self):
        """Float cents raises ValueError."""
        records = [{'id': 'a', 'category': 'x', 'cents': 10.5}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_cents_not_int(self):
        """Non-int cents raises ValueError."""
        records = [{'id': 'a', 'category': 'x', 'cents': '100'}]
        with self.assertRaises(ValueError):
            process(records)

    def test_invalid_minimum_cents_negative(self):
        """Negative minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=-1)

    def test_invalid_minimum_cents_boolean(self):
        """Boolean minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=True)

    def test_invalid_minimum_cents_float(self):
        """Float minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=10.5)

    def test_input_order_preserved(self):
        """Events are in input order (after deduplication)."""
        records = [
            {'id': 'c', 'category': 'x', 'cents': 300},
            {'id': 'a', 'category': 'x', 'cents': 100},
            {'id': 'b', 'category': 'x', 'cents': 200},
        ]
        result = process(records)
        self.assertEqual([e['id'] for e in result['events']], ['c', 'a', 'b'])

    def test_multiple_categories_totals(self):
        """Totals are correctly summed per category."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 100},
            {'id': 'b', 'category': 'y', 'cents': 200},
            {'id': 'c', 'category': 'x', 'cents': 50},
        ]
        result = process(records)
        self.assertEqual(result['totals'], {'x': 150, 'y': 200})

    def test_filter_excludes_all(self):
        """Filter can exclude all records."""
        records = [{'id': 'a', 'category': 'x', 'cents': 50}]
        result = process(records, minimum_cents=100)
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_filter_includes_all(self):
        """Filter with minimum_cents=0 includes all records."""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 0},
            {'id': 'b', 'category': 'x', 'cents': 100},
        ]
        result = process(records, minimum_cents=0)
        self.assertEqual(len(result['events']), 2)


if __name__ == '__main__':
    unittest.main()
