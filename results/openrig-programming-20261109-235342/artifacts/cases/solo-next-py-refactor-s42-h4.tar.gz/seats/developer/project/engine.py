"""Ledger engine implementation - internal processing logic."""

def _validate_record(record):
    """Validate a single record and return normalized version.
    
    Raises ValueError if record is invalid.
    """
    if not isinstance(record, dict):
        raise ValueError("Record must be a dictionary")
    
    # Check for extra keys
    allowed_keys = {'id', 'category', 'cents'}
    if set(record.keys()) != allowed_keys:
        raise ValueError("Record must have exactly id, category, and cents keys")
    
    # Validate id: nonempty stripped string
    record_id = record['id']
    if not isinstance(record_id, str):
        raise ValueError("id must be a string")
    record_id = record_id.strip()
    if not record_id:
        raise ValueError("id must be nonempty after stripping")
    
    # Validate category: nonempty stripped string
    category = record['category']
    if not isinstance(category, str):
        raise ValueError("category must be a string")
    category = category.strip()
    if not category:
        raise ValueError("category must be nonempty after stripping")
    
    # Validate cents: nonnegative integer, boolean values are invalid
    cents = record['cents']
    if isinstance(cents, bool):
        raise ValueError("cents cannot be a boolean")
    if not isinstance(cents, int):
        raise ValueError("cents must be an integer")
    if cents < 0:
        raise ValueError("cents must be nonnegative")
    
    return {'id': record_id, 'category': category, 'cents': cents}


def process(records, minimum_cents=0):
    """Process records and return events with totals.
    
    Args:
        records: List of record dictionaries with id, category, cents
        minimum_cents: Optional filter for minimum cents value (default 0)
    
    Returns:
        {'events': [...], 'totals': {category: sum_cents}}
    
    Raises:
        ValueError: If any record is invalid
    """
    # Validate minimum_cents parameter
    if isinstance(minimum_cents, bool):
        raise ValueError("minimum_cents cannot be a boolean")
    if not isinstance(minimum_cents, int):
        raise ValueError("minimum_cents must be an integer")
    if minimum_cents < 0:
        raise ValueError("minimum_cents must be nonnegative")
    
    # Handle empty input
    if not records:
        return {'events': [], 'totals': {}}
    
    # Validate all records first (before any processing)
    validated_records = []
    for record in records:
        validated_records.append(_validate_record(record))
    
    # Deduplicate: first occurrence of id wins
    seen_ids = set()
    unique_records = []
    for record in validated_records:
        if record['id'] not in seen_ids:
            seen_ids.add(record['id'])
            unique_records.append(record)
    
    # Apply minimum_cents filter and build result
    events = []
    totals = {}
    
    for record in unique_records:
        if record['cents'] >= minimum_cents:
            events.append(record)
            category = record['category']
            if category not in totals:
                totals[category] = 0
            totals[category] += record['cents']
    
    # Sort totals keys
    sorted_totals = dict(sorted(totals.items()))
    
    return {'events': events, 'totals': sorted_totals}
