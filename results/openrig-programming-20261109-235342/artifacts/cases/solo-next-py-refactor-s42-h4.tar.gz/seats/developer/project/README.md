# Ledger

A ledger processing module that validates, deduplicates, and aggregates records.

## Overview

This module provides a `process(records, minimum_cents=0)` function that:

- Validates each record has exactly `id`, `category`, and `cents` fields
- Strips whitespace from `id` and `category` strings
- Ensures `id` and `category` are nonempty after stripping
- Validates `cents` is a nonnegative integer (booleans are invalid)
- Deduplicates by `id`, keeping only the first occurrence
- Filters records by `minimum_cents` threshold
- Returns events in input order with sorted category totals

## Usage

```python
from ledger import process

records = [
    {'id': ' 8 ', 'category': ' c ', 'cents': 1},
    {'id': ' 4 ', 'category': ' a ', 'cents': 96},
]

result = process(records)
# Returns:
# {
#   'events': [
#     {'id': '8', 'category': 'c', 'cents': 1},
#     {'id': '4', 'category': 'a', 'cents': 96},
#   ],
#   'totals': {'a': 96, 'c': 1}
# }
```

With minimum filter:

```python
result = process(records, minimum_cents=50)
# Only records with cents >= 50 are included
```

## Record Validation

Each record must be a dictionary with exactly these keys:

- `id`: nonempty string (whitespace is stripped)
- `category`: nonempty string (whitespace is stripped)
- `cents`: nonnegative integer (booleans are rejected)

Invalid records raise `ValueError`.

## Module Structure

- `ledger.py`: Public facade, exports `process()`
- `engine.py`: Internal implementation logic
- `test_submission.py`: Unit tests
