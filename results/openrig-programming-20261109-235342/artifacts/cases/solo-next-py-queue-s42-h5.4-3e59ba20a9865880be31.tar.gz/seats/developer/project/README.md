# JobQueue

SQLite-backed job queue with claim/complete/fail semantics.

## API

- `JobQueue(path, max_attempts=3)` - Initialize queue with SQLite DB at `path`.
- `enqueue(key, payload) -> bool` - Add job; returns `False` if key exists.
- `claim(worker, now, lease) -> dict|None` - Atomically claim oldest eligible job.
- `complete(key, worker) -> bool` - Mark job done (requires matching owner).
- `fail(key, worker) -> bool` - Requeue or mark failed based on attempts.
- `status(key) -> dict|None` - Return `{state, attempts}` or `None`.

## States

- `queued` - Pending claim.
- `leased` - Currently claimed with expiry.
- `done` - Completed successfully.
- `failed` - Exhausted attempts.

## Validation

- Raises `ValueError` for empty `key`/`worker`, non-positive `lease`/`max_attempts`.

## Thread safety

Uses SQLite WAL mode and a global lock for atomic operations.
