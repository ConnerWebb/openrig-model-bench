import sqlite3
import json
import threading
from typing import Optional, Dict, Any


class JobQueue:
    _lock = threading.Lock()

    def __init__(self, path: str, max_attempts: int = 3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self._path = path
        self._max_attempts = max_attempts
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, 'conn'):
            self._local.conn = sqlite3.connect(self._path, isolation_level=None)
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self):
        with JobQueue._lock:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'queued',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    owner TEXT,
                    lease_until REAL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_state_lease ON jobs(state, lease_until, attempts)")

    def enqueue(self, key: str, payload: Any) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        payload_json = json.dumps(payload)
        with JobQueue._lock:
            conn = self._get_conn()
            try:
                conn.execute(
                    "INSERT INTO jobs (key, payload, state, attempts) VALUES (?, ?, 'queued', 0)",
                    (key, payload_json)
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not worker:
            raise ValueError("worker must be nonempty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        lease_until = now + lease

        with JobQueue._lock:
            conn = self._get_conn()
            # Mark expired leases as queued again, but mark final-attempt jobs as failed
            conn.execute(
                "UPDATE jobs SET state='queued', owner=NULL, lease_until=NULL "
                "WHERE state='leased' AND lease_until<=? AND attempts<?",
                (now, self._max_attempts)
            )
            conn.execute(
                "UPDATE jobs SET state='failed' "
                "WHERE state='leased' AND lease_until<=? AND attempts>=?",
                (now, self._max_attempts)
            )
            # Use BEGIN IMMEDIATE to get a write lock before selecting
            conn.execute("BEGIN IMMEDIATE")
            try:
                # Find next eligible job (oldest first) with FOR UPDATE semantics
                row = conn.execute(
                    "SELECT key, payload, attempts FROM jobs "
                    "WHERE state='queued' AND attempts<? "
                    "ORDER BY rowid LIMIT 1",
                    (self._max_attempts,)
                ).fetchone()
                if row is None:
                    conn.execute("ROLLBACK")
                    return None
                key, payload_json, attempts = row
                payload = json.loads(payload_json)
                new_attempts = attempts + 1
                conn.execute(
                    "UPDATE jobs SET state='leased', owner=?, lease_until=?, attempts=? WHERE key=?",
                    (worker, lease_until, new_attempts, key)
                )
                conn.execute("COMMIT")
                return {"key": key, "payload": payload, "attempts": new_attempts}
            except:
                conn.execute("ROLLBACK")
                raise

    def complete(self, key: str, worker: str) -> bool:
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        with JobQueue._lock:
            conn = self._get_conn()
            row = conn.execute("SELECT state, owner FROM jobs WHERE key=?", (key,)).fetchone()
            if row is None:
                return False
            state, owner = row
            if state != 'leased' or owner != worker:
                return False
            conn.execute("UPDATE jobs SET state='done' WHERE key=?", (key,))
            return True

    def fail(self, key: str, worker: str) -> bool:
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        with JobQueue._lock:
            conn = self._get_conn()
            row = conn.execute("SELECT state, owner, attempts FROM jobs WHERE key=?", (key,)).fetchone()
            if row is None:
                return False
            state, owner, attempts = row
            if state != 'leased' or owner != worker:
                return False
            if attempts >= self._max_attempts:
                conn.execute("UPDATE jobs SET state='failed' WHERE key=?", (key,))
            else:
                conn.execute(
                    "UPDATE jobs SET state='queued', owner=NULL, lease_until=NULL WHERE key=?",
                    (key,)
                )
            return True

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not key:
            raise ValueError("key must be nonempty")
        with JobQueue._lock:
            conn = self._get_conn()
            row = conn.execute("SELECT state, attempts FROM jobs WHERE key=?", (key,)).fetchone()
            if row is None:
                return None
            state, attempts = row
            return {"state": state, "attempts": attempts}
