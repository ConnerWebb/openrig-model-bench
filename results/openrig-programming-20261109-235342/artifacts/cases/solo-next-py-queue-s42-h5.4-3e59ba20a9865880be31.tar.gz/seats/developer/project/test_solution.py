import unittest
import tempfile
import pathlib
import json
import threading
import time
import sqlite3

from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = pathlib.Path(self.tmpdir.name) / "q.db"

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_enqueue_new_key(self):
        q = JobQueue(str(self.db_path))
        self.assertTrue(q.enqueue("key1", {"data": 123}))

    def test_enqueue_duplicate_key(self):
        q = JobQueue(str(self.db_path))
        self.assertTrue(q.enqueue("key1", {"data": 123}))
        self.assertFalse(q.enqueue("key1", {"data": 456}))

    def test_claim_basic(self):
        q = JobQueue(str(self.db_path))
        q.enqueue("key1", {"data": 123})
        result = q.claim("worker1", 0.0, 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": 123})
        self.assertEqual(result["attempts"], 1)

    def test_claim_no_jobs(self):
        q = JobQueue(str(self.db_path))
        result = q.claim("worker1", 0.0, 10.0)
        self.assertIsNone(result)

    def test_claim_expires_leased(self):
        q = JobQueue(str(self.db_path))
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 5.0)
        result = q.claim("worker2", 10.0, 5.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")

    def test_complete(self):
        q = JobQueue(str(self.db_path))
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertTrue(q.complete("key1", "worker1"))

    def test_complete_wrong_worker(self):
        q = JobQueue(str(self.db_path))
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertFalse(q.complete("key1", "worker2"))

    def test_fail_and_requeue(self):
        q = JobQueue(str(self.db_path))
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertTrue(q.fail("key1", "worker1"))
        result = q.claim("worker2", 0.0, 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["attempts"], 2)

    def test_fail_max_attempts(self):
        q = JobQueue(str(self.db_path), max_attempts=1)
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertTrue(q.fail("key1", "worker1"))
        self.assertEqual(q.status("key1")["state"], "failed")

    def test_status(self):
        q = JobQueue(str(self.db_path))
        q.enqueue("key1", {"data": 123})
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_status_missing_key(self):
        q = JobQueue(str(self.db_path))
        status = q.status("nonexistent")
        self.assertIsNone(status)

    def test_invalid_worker_empty(self):
        q = JobQueue(str(self.db_path))
        with self.assertRaises(ValueError):
            q.claim("", 0.0, 10.0)

    def test_invalid_lease_zero(self):
        q = JobQueue(str(self.db_path))
        with self.assertRaises(ValueError):
            q.claim("worker", 0.0, 0)

    def test_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(str(self.db_path), max_attempts=0)

    def test_invalid_key_empty(self):
        q = JobQueue(str(self.db_path))
        with self.assertRaises(ValueError):
            q.enqueue("", {})

    def test_concurrent_access(self):
        q = JobQueue(str(self.db_path))
        n = 10
        for i in range(n):
            q.enqueue(str(i), i)

        results = []
        lock = threading.Lock()

        def worker(wid):
            local_q = JobQueue(str(self.db_path))
            for _ in range(2):
                r = local_q.claim(f"w{wid}", 0.0, 100.0)
                if r:
                    with lock:
                        results.append(r["key"])

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(results), n)
        self.assertEqual(len(set(results)), n)

    def test_shared_db_instances(self):
        q1 = JobQueue(str(self.db_path))
        q1.enqueue("key1", {"data": 123})
        q2 = JobQueue(str(self.db_path))
        result = q2.claim("worker1", 0.0, 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")


if __name__ == "__main__":
    unittest.main()
