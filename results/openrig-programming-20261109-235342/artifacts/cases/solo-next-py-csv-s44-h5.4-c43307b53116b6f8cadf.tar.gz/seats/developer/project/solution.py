import csv
from decimal import Decimal, InvalidOperation
import re


def aggregate(path: str) -> dict[str, str]:
    totals: dict[str, Decimal] = {}
    amount_pattern = re.compile(r'^\+?(?:\d{1,12}(?:\.\d{1,2})?|\d{1,12})$')

    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("Empty file")
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")

        for row in reader:
            if not row:
                continue
            if len(row) != 2:
                raise ValueError("Invalid row fields")
            category, amount_str = row
            category = category.strip()
            if not category:
                raise ValueError("Empty category")
            amount_str = amount_str.strip()
            if not amount_pattern.match(amount_str):
                raise ValueError("Invalid amount format")
            try:
                amount = Decimal(amount_str)
                if amount.is_nan() or amount.is_infinite():
                    raise ValueError("Invalid amount value")
            except InvalidOperation:
                raise ValueError("Invalid amount value")
            totals[category] = totals.get(category, Decimal('0')) + amount

    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}
