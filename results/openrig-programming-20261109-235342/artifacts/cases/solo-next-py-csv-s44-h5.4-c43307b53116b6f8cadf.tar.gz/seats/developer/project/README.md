# CSV Aggregate Solution

This project implements `aggregate(path: str) -> dict[str, str]` that reads a UTF-8 CSV file with header `category,amount` and returns category totals formatted to two decimal places.

## Implementation

- Uses Python's `csv` module for proper parsing (handles quoted commas and embedded newlines).
- Uses `decimal.Decimal` for exact arithmetic.
- Validates amount format with regex: optional `+`, 1–12 digits, optional decimal point with 1–2 digits.
- Rejects empty categories, malformed amounts (NaN, infinity), wrong headers, and incorrect field counts.
- Returns sorted keys with totals formatted as `"{:.2f}"`.

## Tests

Run `python test_solution.py` to execute all unit tests covering basic functionality, edge cases, and public test cases.
