#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cassert>
#include <cstdint>
#include <climits>
#include "solution.hpp"

int main() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream iss(input);
    try {
        auto result = aggregate(iss);
        std::cout << "No exception thrown" << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cout << "invalid_argument: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        std::cout << "other exception (" << typeid(e).name() << "): " << e.what() << std::endl;
    }
    return 0;
}
