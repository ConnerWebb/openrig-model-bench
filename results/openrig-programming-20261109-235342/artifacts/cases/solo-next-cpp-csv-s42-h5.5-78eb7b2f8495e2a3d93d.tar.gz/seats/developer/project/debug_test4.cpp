#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cstdint>
#include <climits>
#include "solution.hpp"

int main() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        auto result = aggregate(iss);
        std::cout << "No exception thrown" << std::endl;
        for (const auto& p : result) {
            std::cout << p.first << ": " << p.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "exception: " << e.what() << std::endl;
    }
    return 0;
}
