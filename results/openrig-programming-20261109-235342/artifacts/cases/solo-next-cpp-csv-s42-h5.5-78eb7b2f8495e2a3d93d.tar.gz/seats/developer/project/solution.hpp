#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <stdexcept>
#include <cstdint>
#include <cctype>
#include <vector>
#include <algorithm>

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty integer string");
    size_t idx = 0;
    if (s[0] == '+' || s[0] == '-') idx = 1;
    if (idx >= s.size()) throw std::invalid_argument("no digits");
    if (s[idx] == '0' && idx + 1 < s.size()) {
        if (s[idx+1] == 'x' || s[idx+1] == 'X') throw std::invalid_argument("hex not allowed");
        if (std::isdigit(static_cast<unsigned char>(s[idx+1]))) {
            throw std::invalid_argument("leading zeros not allowed");
        }
    }
    for (size_t i = idx; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("non-digit in integer");
        }
    }
    
    // Check for overflow before parsing
    std::string abs_str = s;
    if (abs_str[0] == '+' || abs_str[0] == '-') {
        abs_str = abs_str.substr(1);
    }
    
    if (abs_str.size() > 19) throw std::invalid_argument("overflow");
    
    if (abs_str.size() == 19) {
        // Compare with max/min 19-digit limits
        std::string max_limit = "9223372036854775807";
        std::string min_limit = "9223372036854775808"; // abs of INT64_MIN
        
        if (s[0] == '-') {
            if (abs_str > min_limit) throw std::invalid_argument("overflow");
        } else {
            if (abs_str > max_limit) throw std::invalid_argument("overflow");
        }
    }
    
    // Now safe to parse
    if (s[0] == '-') {
        std::string abs_str = s.substr(1);
        // Special case: INT64_MIN cannot be represented as positive int64
        if (abs_str == "9223372036854775808") {
            return INT64_MIN;
        }
        return -std::stoll(abs_str);
    } else {
        std::string abs_str = s[0] == '+' ? s.substr(1) : s;
        return std::stoll(abs_str);
    }
}

// Parse a single CSV record from content starting at pos
// Returns the fields and updates pos to point after the record
std::vector<std::string> parse_csv_record(const std::string& content, size_t& pos) {
    std::vector<std::string> fields;
    
    while (pos < content.size()) {
        // Skip leading whitespace (shouldn't be needed but just in case)
        while (pos < content.size() && (content[pos] == ' ' || content[pos] == '\t')) {
            ++pos;
        }
        
        if (pos >= content.size()) break;
        
        if (content[pos] == '"') {
            // Quoted field
            ++pos;
            std::string result;
            bool ended = false;
            while (pos < content.size()) {
                if (content[pos] == '"') {
                    if (pos + 1 < content.size() && content[pos+1] == '"') {
                        // Escaped quote
                        result += '"';
                        pos += 2;
                    } else {
                        // End of quoted field
                        ++pos;
                        ended = true;
                        break;
                    }
                } else {
                    result += content[pos];
                    ++pos;
                }
            }
            if (!ended) {
                throw std::invalid_argument("unterminated quote");
            }
            fields.push_back(result);
        } else {
            // Unquoted field
            size_t start = pos;
            while (pos < content.size() && content[pos] != ',' && content[pos] != '\r' && content[pos] != '\n') {
                ++pos;
            }
            fields.push_back(content.substr(start, pos - start));
        }
        
        // Check for comma (next field) or line ending
        if (pos >= content.size()) break;
        
        if (content[pos] == ',') {
            ++pos; // Skip comma and continue to next field
        } else if (content[pos] == '\r' || content[pos] == '\n') {
            // Line ending
            if (content[pos] == '\r') ++pos;
            if (pos < content.size() && content[pos] == '\n') ++pos;
            break; // End of record
        }
    }
    
    return fields;
}

}

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    // Read entire input into a string to handle embedded newlines
    std::string content;
    char c;
    while (in.get(c)) {
        content += c;
    }
    
    if (content.empty()) throw std::invalid_argument("empty input");
    
    // Parse header
    size_t pos = 0;
    
    // Skip BOM if present
    if (content.size() >= 3 && static_cast<unsigned char>(content[0]) == 0xEF &&
        static_cast<unsigned char>(content[1]) == 0xBB && static_cast<unsigned char>(content[2]) == 0xBF) {
        pos = 3;
    }
    
    // Find end of header line
    size_t header_end = pos;
    while (header_end < content.size() && content[header_end] != '\r' && content[header_end] != '\n') {
        ++header_end;
    }
    
    std::string header = content.substr(pos, header_end - pos);
    if (header != "category,amount") {
        throw std::invalid_argument("wrong header");
    }
    
    pos = header_end;
    
    // Skip line ending
    if (pos < content.size() && content[pos] == '\r') ++pos;
    if (pos < content.size() && content[pos] == '\n') ++pos;
    
    std::map<std::string, std::int64_t> result;
    
    while (pos < content.size()) {
        // Skip empty lines
        size_t line_start = pos;
        while (pos < content.size() && (content[pos] == '\r' || content[pos] == '\n')) {
            ++pos;
        }
        if (pos >= content.size()) break;
        
        // Check if this is an empty line (just whitespace)
        size_t check_pos = pos;
        bool only_whitespace = true;
        while (check_pos < content.size() && content[check_pos] != '\r' && content[check_pos] != '\n') {
            if (content[check_pos] != ' ' && content[check_pos] != '\t') {
                only_whitespace = false;
                break;
            }
            ++check_pos;
        }
        if (only_whitespace) {
            // Skip to end of line
            while (pos < content.size() && content[pos] != '\r' && content[pos] != '\n') {
                ++pos;
            }
            if (pos < content.size() && content[pos] == '\r') ++pos;
            if (pos < content.size() && content[pos] == '\n') ++pos;
            continue;
        }
        
        // Parse the record
        std::vector<std::string> fields = parse_csv_record(content, pos);
        
        if (fields.size() != 2) {
            throw std::invalid_argument("wrong number of fields");
        }
        
        std::string category = trim(fields[0]);
        std::string amount_str = trim(fields[1]);
        
        if (category.empty()) throw std::invalid_argument("empty category");
        if (amount_str.empty()) throw std::invalid_argument("empty amount");
        
        std::int64_t amount = parse_int64(amount_str);
        
        // Check for overflow when adding
        if (result.find(category) != result.end()) {
            std::int64_t old_val = result[category];
            if ((amount > 0 && old_val > INT64_MAX - amount) ||
                (amount < 0 && old_val < INT64_MIN - amount)) {
                throw std::invalid_argument("overflow");
            }
        }
        
        result[category] += amount;
    }
    
    return result;
}

#endif
