#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cassert>
#include "solution.hpp"

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nfood,30\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["food"] == -20);
}

void test_quoted_comma() {
    std::string input = "category,amount\n\"a,b\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["a,b"] == 100);
}

void test_quoted_newline() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
}

void test_escaped_quote() {
    std::string input = "category,amount\n\"x\"\"quote\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["x\"quote"] == 100);
}

void test_wrong_header() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_extra_field() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_nan() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_unterminated_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_exponent() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_overflow() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_max_int64() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        auto result = aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_min_int64() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream iss(input);
    try {
        auto result = aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_empty_input() {
    std::string input = "";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_empty_header() {
    std::string input = "category,amount\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.empty());
}

void test_whitespace_trim() {
    std::string input = "category,amount\n  food  ,  +100  \n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["food"] == 100);
}

void test_public_case0() {
    std::string input = "category,amount\n\"x\"\"quote\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\"x\"\"quote\",-22826\n\"x\"\"quote\",-4598\n\"x\"\"quote\",-26830\n日本,39039\n\"a,b\",29914\nrent,15786\n日本,-8138\nfood,15570\n\"x\"\"quote\",-26030\n\"two\nlines\",54977\n\"x\"\"quote\",-5124\nrent,12112\n\"two\nlines\",28447\nfood,57027\nfood,2732\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["a,b"] == 29914);
    assert(result["food"] == 76201);
    assert(result["rent"] == 101592);
    assert(result["two\nlines"] == 83424);
    assert(result["x\"quote"] == -34140);
    assert(result["日本"] == 30901);
}

int main() {
    test_basic();
    test_negative();
    test_quoted_comma();
    test_quoted_newline();
    test_escaped_quote();
    test_wrong_header();
    test_extra_field();
    test_empty_category();
    test_nan();
    test_unterminated_quote();
    test_exponent();
    test_overflow();
    test_max_int64();
    test_min_int64();
    test_empty_input();
    test_empty_header();
    test_whitespace_trim();
    test_public_case0();
    std::cout << "All tests passed" << std::endl;
    return 0;
}
