#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cassert>
#include "solution.hpp"

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_basic passed" << std::endl;
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nfood,30\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["food"] == -20);
    std::cout << "test_negative passed" << std::endl;
}

void test_max_int64() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        auto result = aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
        std::cout << "test_max_int64 passed" << std::endl;
    }
}

int main() {
    test_basic();
    test_negative();
    test_max_int64();
    std::cout << "All tests passed" << std::endl;
    return 0;
}
