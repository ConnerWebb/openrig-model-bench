#include <iostream>
#include <string>
#include <cstdint>

int main() {
    std::string s = "9223372036854775807";
    std::string abs_str = s;
    
    std::cout << "s = " << s << std::endl;
    std::cout << "abs_str = " << abs_str << std::endl;
    std::cout << "abs_str.size() = " << abs_str.size() << std::endl;
    
    std::string max_limit = "9223372036854775807";
    std::cout << "max_limit = " << max_limit << std::endl;
    std::cout << "abs_str > max_limit: " << (abs_str > max_limit) << std::endl;
    std::cout << "abs_str == max_limit: " << (abs_str == max_limit) << std::endl;
    
    return 0;
}
