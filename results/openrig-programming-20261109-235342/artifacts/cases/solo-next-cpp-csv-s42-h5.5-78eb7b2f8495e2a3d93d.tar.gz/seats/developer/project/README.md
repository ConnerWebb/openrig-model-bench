# CSV Aggregator

This project implements a CSV parser and aggregator for financial data.

## Overview

The `aggregate` function parses a CSV input with columns `category` and `amount`, and returns a map of category totals. It handles:
- Basic integer parsing with overflow detection
- Quoted fields with embedded commas, newlines, and escaped quotes
- Whitespace trimming
- Proper error handling for malformed input

## Usage

```cpp
#include "solution.hpp"
#include <sstream>

std::string input = "category,amount\nfood,100\nrent,200\n";
std::istringstream iss(input);
auto result = aggregate(iss);
// result["food"] == 100, result["rent"] == 200
```

## Implementation Details

- Integer parsing validates format and checks for overflow before conversion
- CSV parsing handles quoted fields per RFC 4180 with CRLF line endings
- Aggregation accumulates amounts per category with overflow checks
