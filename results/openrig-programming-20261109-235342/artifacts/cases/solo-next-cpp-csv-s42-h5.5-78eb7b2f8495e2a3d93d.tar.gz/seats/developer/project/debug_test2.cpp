#include <iostream>
#include <string>
#include <cstdint>
#include <climits>

int main() {
    std::string s = "9223372036854775807";
    std::cout << "INT64_MAX = " << INT64_MAX << std::endl;
    std::cout << "s = " << s << std::endl;
    try {
        std::int64_t val = std::stoll(s);
        std::cout << "val = " << val << std::endl;
    } catch (const std::exception& e) {
        std::cout << "exception: " << e.what() << std::endl;
    }
    return 0;
}
