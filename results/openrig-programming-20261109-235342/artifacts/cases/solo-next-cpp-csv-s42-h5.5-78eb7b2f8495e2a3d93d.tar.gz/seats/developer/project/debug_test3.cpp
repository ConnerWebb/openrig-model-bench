#include <iostream>
#include <string>
#include <cstdint>
#include <climits>

std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty integer string");
    size_t idx = 0;
    if (s[0] == '+' || s[0] == '-') idx = 1;
    if (idx >= s.size()) throw std::invalid_argument("no digits");
    if (s[idx] == '0' && idx + 1 < s.size()) {
        if (s[idx+1] == 'x' || s[idx+1] == 'X') throw std::invalid_argument("hex not allowed");
        if (std::isdigit(static_cast<unsigned char>(s[idx+1]))) {
            throw std::invalid_argument("leading zeros not allowed");
        }
    }
    for (size_t i = idx; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("non-digit in integer");
        }
    }
    
    std::string abs_str = s;
    if (abs_str[0] == '+' || abs_str[0] == '-') {
        abs_str = abs_str.substr(1);
    }
    
    std::cout << "DEBUG: abs_str = '" << abs_str << "', size = " << abs_str.size() << std::endl;
    
    if (abs_str.size() > 19) throw std::invalid_argument("overflow");
    
    if (abs_str.size() == 19) {
        std::string max_limit = "9223372036854775807";
        std::string min_limit = "9223372036854775808";
        
        std::cout << "DEBUG: comparing '" << abs_str << "' with max_limit '" << max_limit << "'" << std::endl;
        std::cout << "DEBUG: abs_str > max_limit = " << (abs_str > max_limit) << std::endl;
        
        if (s[0] == '-') {
            if (abs_str > min_limit) throw std::invalid_argument("overflow");
        } else {
            if (abs_str > max_limit) throw std::invalid_argument("overflow");
        }
    }
    
    if (s[0] == '-') {
        std::string abs_str2 = s.substr(1);
        return -std::stoll(abs_str2);
    } else {
        std::string abs_str2 = s[0] == '+' ? s.substr(1) : s;
        return std::stoll(abs_str2);
    }
}

int main() {
    std::string s = "9223372036854775807";
    try {
        std::int64_t val = parse_int64(s);
        std::cout << "val = " << val << std::endl;
    } catch (const std::exception& e) {
        std::cout << "exception: " << e.what() << std::endl;
    }
    return 0;
}
