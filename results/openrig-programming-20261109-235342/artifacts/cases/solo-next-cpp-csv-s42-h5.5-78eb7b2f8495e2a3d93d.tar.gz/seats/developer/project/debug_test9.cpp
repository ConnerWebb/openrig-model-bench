#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cassert>
#include <cstdint>
#include <climits>
#include "solution.hpp"

int main() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream iss(input);
    try {
        auto result = aggregate(iss);
        std::cout << "No exception thrown" << std::endl;
        for (const auto& p : result) {
            std::cout << p.first << ": " << p.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "exception: " << e.what() << std::endl;
    }
    
    // Test parse_int64 directly
    try {
        std::int64_t val = parse_int64("-9223372036854775808");
        std::cout << "parse_int64(-9223372036854775808) = " << val << std::endl;
    } catch (const std::exception& e) {
        std::cout << "parse_int64 exception: " << e.what() << std::endl;
    }
    
    return 0;
}
