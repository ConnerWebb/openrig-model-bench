# Buffer Library

A C++20 RAII-based buffer implementation with deep copy semantics, move semantics, and bounds checking.

## Features

- **Constructor**: `Buffer(size_t n = 0)` - Creates a buffer of specified size, zero-initialized
- **Size query**: `size() const noexcept` - Returns the current buffer size
- **Element access**: `operator[](size_t)` - Mutable and const versions with bounds checking
- **Resizing**: `resize(size_t)` - Shrinks or grows buffer, preserving prefix and zero-initializing new bytes
- **Copy semantics**: Deep copy construction and assignment
- **Move semantics**: Noexcept move construction and assignment
- **Moved-from state**: Buffers become size 0 and reusable after move
- **Self-copy/self-move**: Preserves content

## API

### Constructor
```cpp
Buffer(size_t n = 0)
```
Creates a buffer of size `n` with all elements zero-initialized.

### Size
```cpp
size_t size() const noexcept
```
Returns the current buffer size.

### Element Access
```cpp
std::uint8_t& operator[](size_t i)
const std::uint8_t& operator[](size_t i) const
```
Returns reference to element at index `i`. Throws `std::out_of_range` if index is out of bounds.

### Resize
```cpp
void resize(size_t k)
```
Resizes the buffer to size `k`. If `k < current size`, truncates. If `k > current size`, extends with zeros.

## Requirements

- C++20
- No external dependencies
- No memory leaks
- No double frees
- No stale reads
- No undefined behavior

## Testing

Run the test suite:
```bash
clang++ -std=c++20 -fuse-ld=bfd test_buffer.cpp -o test_buffer && ./test_buffer
```

## Implementation Notes

- Uses RAII for automatic memory management
- Deep copy ensures independent buffers
- Move semantics use `noexcept` for optimal performance
- Bounds checking prevents out-of-range access
- Zero-initialization ensures predictable behavior