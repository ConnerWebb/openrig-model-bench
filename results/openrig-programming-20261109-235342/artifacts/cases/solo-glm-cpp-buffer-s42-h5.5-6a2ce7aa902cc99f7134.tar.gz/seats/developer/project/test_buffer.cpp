#include <iostream>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

void test_constructor_default() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_constructor_default passed\n";
}

void test_constructor_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_size passed\n";
}

void test_constructor_size_with_values() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    std::cout << "test_constructor_size_with_values passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    a[0] = 99;
    assert(b[0] == 10);
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer b;
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    a[0] = 99;
    assert(b[0] == 10);
    std::cout << "test_copy_assignment passed\n";
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 10);
    assert(a[1] == 20);
    assert(a[2] == 30);
    std::cout << "test_self_copy passed\n";
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    assert(a.size() == 0);
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer b;
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    assert(a.size() == 0);
    std::cout << "test_move_assignment passed\n";
}

void test_self_move() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 10);
    assert(a[1] == 20);
    assert(a[2] == 30);
    std::cout << "test_self_move passed\n";
}

void test_resize_smaller() {
    Buffer b(10);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    std::cout << "test_resize_smaller passed\n";
}

void test_resize_larger() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(10);
    assert(b.size() == 10);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    for (std::size_t i = 3; i < 10; ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_resize_larger passed\n";
}

void test_resize_same() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    std::cout << "test_resize_same passed\n";
}

void test_bounds_check_const() {
    Buffer b(5);
    b[0] = 10;
    try {
        const Buffer& cb = b;
        (void)cb[10];
        assert(false);
    } catch (const std::out_of_range&) {
        std::cout << "test_bounds_check_const passed\n";
    }
}

void test_bounds_check_mutable() {
    Buffer b(5);
    b[0] = 10;
    try {
        (void)b[10];
        assert(false);
    } catch (const std::out_of_range&) {
        std::cout << "test_bounds_check_mutable passed\n";
    }
}

void test_operator_square_brackets() {
    Buffer b(5);
    b[0] = 100;
    b[1] = 200;
    b[2] = 44;
    assert(b[0] == 100);
    assert(b[1] == 200);
    assert(b[2] == 44);
    std::cout << "test_operator_square_brackets passed\n";
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
    std::cout << "test_noexcept_move passed\n";
}

void test_deep_copy() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer b(a);
    b[0] = 99;
    assert(a[0] == 10);
    assert(b[0] == 99);
    std::cout << "test_deep_copy passed\n";
}

void test_moved_from_reusable() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(a.size() == 0);
    a.resize(3);
    assert(a.size() == 3);
    std::cout << "test_moved_from_reusable passed\n";
}

void test_all() {
    test_constructor_default();
    test_constructor_size();
    test_constructor_size_with_values();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy();
    test_move_constructor();
    test_move_assignment();
    test_self_move();
    test_resize_smaller();
    test_resize_larger();
    test_resize_same();
    test_bounds_check_const();
    test_bounds_check_mutable();
    test_operator_square_brackets();
    test_noexcept_move();
    test_deep_copy();
    test_moved_from_reusable();
    std::cout << "All tests passed!\n";
}

int main() {
    test_all();
    return 0;
}