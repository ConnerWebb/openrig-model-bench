#pragma once
#include <cstdint>
#include <cstddef>
#include <algorithm>
#include <stdexcept>
#include <utility>

class Buffer {
private:
    std::uint8_t* p;
    std::size_t n;

    void allocate(std::size_t size) {
        p = new std::uint8_t[size];
        n = size;
    }

    void copy_from(const Buffer& other) {
        if (other.p && other.n > 0) {
            allocate(other.n);
            std::copy(other.p, other.p + other.n, p);
        } else {
            allocate(0);
        }
    }

    void zero_fill(std::size_t start, std::size_t end) {
        if (p && start < end) {
            std::fill(p + start, p + end, 0);
        }
    }

public:
    Buffer() : p(nullptr), n(0) {}

    explicit Buffer(std::size_t n) {
        allocate(n);
        if (n > 0) {
            std::fill(p, p + n, 0);
        }
    }

    Buffer(const Buffer& other) {
        copy_from(other);
    }

    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] p;
            copy_from(other);
        }
        return *this;
    }

    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    ~Buffer() {
        delete[] p;
    }

    std::size_t size() const noexcept {
        return n;
    }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    void resize(std::size_t k) {
        if (k < n) {
            n = k;
        } else if (k > n) {
            std::uint8_t* old_p = p;
            std::size_t old_n = n;
            allocate(k);
            if (old_p && old_n > 0) {
                std::copy(old_p, old_p + old_n, p);
            }
            zero_fill(old_n, k);
            delete[] old_p;
        }
    }
};