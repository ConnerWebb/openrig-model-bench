# Buffer Library

A C++20 buffer implementation with deep-copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep-copy construction/assignment**: Independent copies of buffer data
- **Noexcept move operations**: Efficient transfers with moved-from buffers having size 0
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Resize with preservation**: `resize()` preserves existing data and zero-initializes new bytes
- **RAII**: Automatic resource management, no leaks or double frees

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized.

### Destructor
```cpp
~Buffer();
```
Releases allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy: creates independent copy of buffer data.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Noexcept move: transfers ownership. Moved-from buffer has size 0 and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
Returns buffer size and element access with bounds checking.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes buffer to `k` bytes, preserving prefix and zero-initializing new bytes.

## Testing

Compile and run tests:
```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

Run public tests:
```bash
run_tests
```

## Requirements

- C++20 compiler
- Clang 22+ recommended
