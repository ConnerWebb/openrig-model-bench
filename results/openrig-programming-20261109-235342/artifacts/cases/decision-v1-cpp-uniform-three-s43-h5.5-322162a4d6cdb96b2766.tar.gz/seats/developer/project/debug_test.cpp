#include <iostream>
#include <sstream>
#include <string>
#include "solution.hpp"

int main() {
    std::string input = "category,amount\nfood,100\n";
    std::istringstream iss(input);
    
    // Debug: print what we're parsing
    std::cout << "Input: [" << input << "]" << std::endl;
    
    try {
        auto result = aggregate(iss);
        std::cout << "Success! Result size: " << result.size() << std::endl;
        for (const auto& [k, v] : result) {
            std::cout << "  " << k << " -> " << v << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
    
    return 0;
}
