#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_whitespace_stripping() {
    std::string input = "category,amount\n  food  ,  100  \n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 1);
    assert(result["food"] == 100);
    std::cout << "test_whitespace_stripping passed\n";
}

int main() {
    test_whitespace_stripping();
    return 0;
}
