#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_negative_amounts() {
    std::string input = "category,amount\nfood,100\nfood,-30\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["food"] == 70);
    std::cout << "test_negative_amounts passed\n";
}

int main() {
    test_negative_amounts();
    return 0;
}
