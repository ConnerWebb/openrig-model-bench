#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_basic_csv() {
    std::string input = "category,amount\nfood,100\nrent,200\nfood,50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["food"] == 150);
    assert(result["rent"] == 200);
    std::cout << "test_basic_csv passed\n";
}

void test_quoted_fields() {
    std::string input = "category,amount\n\"a,b\",100\n\"x\"\"quote\",50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["x\"quote"] == 50);
    std::cout << "test_quoted_fields passed\n";
}

void test_newlines_in_quotes() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
    std::cout << "test_newlines_in_quotes passed\n";
}

void test_whitespace_stripping() {
    std::string input = "category,amount\n  food  ,  100  \n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 1);
    assert(result["food"] == 100);
    std::cout << "test_whitespace_stripping passed\n";
}

void test_negative_amounts() {
    std::string input = "category,amount\nfood,100\nfood,-30\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["food"] == 70);
    std::cout << "test_negative_amounts passed\n";
}

void test_optional_plus_sign() {
    std::string input = "category,amount\nfood,+100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["food"] == 100);
    std::cout << "test_optional_plus_sign passed\n";
}

void test_invalid_header() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_header passed\n";
    }
}

void test_wrong_field_count() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count passed\n";
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category passed\n";
    }
}

void test_invalid_amount() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_amount passed\n";
    }
}

void test_unterminated_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_unterminated_quote passed\n";
    }
}

int main() {
    test_basic_csv();
    test_quoted_fields();
    test_newlines_in_quotes();
    test_whitespace_stripping();
    test_negative_amounts();
    test_optional_plus_sign();
    test_invalid_header();
    test_wrong_field_count();
    test_empty_category();
    test_invalid_amount();
    test_unterminated_quote();
    std::cout << "All tests passed!\n";
    return 0;
}
