#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_invalid_amount() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_amount passed\n";
    }
}

int main() {
    test_invalid_amount();
    return 0;
}
