#include <iostream>
#include <sstream>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <algorithm>
#include <cctype>

namespace {

std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

class CSVParser {
public:
    CSVParser(std::istream& is) : in_(is), eof_(false) {
        fill_buffer();
        std::cout << "Initial buffer: [" << buffer_ << "], size=" << buffer_.size() << std::endl;
    }
    
    bool parse_header() {
        std::string field1 = read_field();
        std::string field2 = read_field();
        
        std::cout << "Header: field1=[" << field1 << "], field2=[" << field2 << "]" << std::endl;
        std::cout << "After header: buffer_pos_=" << buffer_pos_ << ", buffer_.size()=" << buffer_.size() << std::endl;
        
        char c = peek();
        std::cout << "After header fields, peek: '" << c << "' (int: " << (int)c << ")" << std::endl;
        
        if (c == ',') {
            return false;
        }
        
        std::string h1 = strip(field1);
        std::string h2 = strip(field2);
        
        if (h1 != "category" || h2 != "amount") {
            return false;
        }
        
        // Consume the newline after header
        if (c == '\n') {
            std::cout << "Consuming newline after header" << std::endl;
            in_.get();
            std::cout << "After in_.get(): buffer_pos_=" << buffer_pos_ << ", buffer_.size()=" << buffer_.size() << std::endl;
        } else if (c == '\r') {
            std::cout << "Consuming CR after header" << std::endl;
            in_.get();
            if (peek() == '\n') {
                std::cout << "Consuming LF after CR" << std::endl;
                in_.get();
            }
        }
        
        return true;
    }
    
    bool next_record(std::string& category, int64_t& amount) {
        std::cout << "next_record called, buffer_pos_=" << buffer_pos_ << ", buffer_.size()=" << buffer_.size() << std::endl;
        
        if (eof_ && buffer_pos_ >= buffer_.size()) {
            std::cout << "EOF reached, returning false" << std::endl;
            return false;
        }
        
        std::string field1 = read_field();
        std::cout << "After reading field1: [" << field1 << "], buffer_pos_=" << buffer_pos_ << std::endl;
        
        if (eof_ && buffer_pos_ >= buffer_.size()) {
            std::string stripped = strip(field1);
            if (stripped.empty()) {
                std::cout << "Empty field at EOF, returning false" << std::endl;
                return false;
            }
            throw std::invalid_argument("Missing amount field");
        }
        
        std::string field2 = read_field();
        std::cout << "After reading field2: [" << field2 << "]" << std::endl;
        
        char c = peek();
        std::cout << "After field2, peek: '" << c << "'" << std::endl;
        
        if (c == ',') {
            throw std::invalid_argument("Too many fields");
        }
        
        if (c == '\n') {
            in_.get();
        } else if (c == '\r') {
            in_.get();
            if (peek() == '\n') in_.get();
        }
        
        category = strip(field1);
        std::string amount_str = strip(field2);
        
        std::cout << "category=[" << category << "], amount_str=[" << amount_str << "]" << std::endl;
        
        if (category.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        return true;
    }
    
private:
    std::istream& in_;
    std::string buffer_;
    size_t buffer_pos_ = 0;
    bool eof_ = false;
    
    void fill_buffer() {
        if (eof_) return;
        char c;
        if (in_.get(c)) {
            buffer_ += c;
            std::cout << "fill_buffer: added '" << c << "', buffer now [" << buffer_ << "], size=" << buffer_.size() << std::endl;
        } else {
            eof_ = true;
            std::cout << "fill_buffer: EOF" << std::endl;
        }
    }
    
    char peek() {
        std::cout << "peek: buffer_pos_=" << buffer_pos_ << ", buffer_.size()=" << buffer_.size() << std::endl;
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        return '\0';
    }
    
    char get() {
        std::cout << "get: buffer_pos_=" << buffer_pos_ << ", buffer_.size()=" << buffer_.size() << std::endl;
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        return '\0';
    }
    
    std::string read_field() {
        std::string result;
        char c = peek();
        
        if (c == '"') {
            get(); // consume opening quote
            while (true) {
                c = get();
                if (c == '\0') {
                    throw std::invalid_argument("Unterminated quoted field");
                }
                if (c == '"') {
                    char next = peek();
                    if (next == '"') {
                        result += '"';
                        get();
                    } else {
                        break;
                    }
                } else {
                    result += c;
                }
            }
            c = peek();
            if (c == ',') {
                get();
            } else if (c != '\n' && c != '\r' && c != '\0') {
                throw std::invalid_argument("Invalid character after quoted field");
            }
        } else {
            while (true) {
                c = peek();
                if (c == ',') {
                    get();
                    break;
                } else if (c == '\n' || c == '\r' || c == '\0') {
                    break;
                }
                result += get();
            }
        }
        
        return result;
    }
};

}

int main() {
    std::string input = "category,amount\nfood,100\n";
    std::istringstream iss(input);
    
    std::cout << "Input: [" << input << "]" << std::endl;
    
    CSVParser parser(iss);
    bool ok = parser.parse_header();
    std::cout << "Header parse: " << (ok ? "OK" : "FAIL") << std::endl;
    
    std::string cat;
    int64_t amt;
    ok = parser.next_record(cat, amt);
    std::cout << "next_record: " << (ok ? "OK" : "FAIL") << ", cat=[" << cat << "], amt=" << amt << std::endl;
    
    return 0;
}
