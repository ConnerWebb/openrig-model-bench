#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_empty_input() {
    std::string input = "category,amount\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.empty());
    std::cout << "test_empty_input passed\n";
}

int main() {
    test_empty_input();
    return 0;
}
