#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_basic_csv() {
    std::string input = "category,amount\nfood,100\nrent,200\nfood,50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["food"] == 150);
    assert(result["rent"] == 200);
    std::cout << "test_basic_csv passed\n";
}

int main() {
    test_basic_csv();
    return 0;
}
