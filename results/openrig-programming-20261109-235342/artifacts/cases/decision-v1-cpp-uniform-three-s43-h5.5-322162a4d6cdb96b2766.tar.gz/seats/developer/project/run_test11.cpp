#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_unterminated_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_unterminated_quote passed\n";
    }
}

int main() {
    test_unterminated_quote();
    return 0;
}
