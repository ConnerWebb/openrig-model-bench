#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_unicode_categories() {
    std::string input = "category,amount\n日本，100\n日本，50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 1);
    assert(result["日本"] == 150);
    std::cout << "test_unicode_categories passed\n";
}

int main() {
    test_unicode_categories();
    return 0;
}
