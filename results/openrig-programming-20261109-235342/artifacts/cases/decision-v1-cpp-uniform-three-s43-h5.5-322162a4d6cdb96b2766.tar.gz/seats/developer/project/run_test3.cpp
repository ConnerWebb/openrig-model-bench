#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_newlines_in_quotes() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
    std::cout << "test_newlines_in_quotes passed\n";
}

int main() {
    test_newlines_in_quotes();
    return 0;
}
