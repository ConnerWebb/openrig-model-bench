#include <iostream>
#include <sstream>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <algorithm>
#include <cctype>

namespace {

std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

class CSVParser {
public:
    CSVParser(std::istream& is) : in_(is), eof_(false) {
        fill_buffer();
    }
    
    bool parse_header() {
        std::string field1 = read_field();
        std::string field2 = read_field();
        
        std::cout << "field1: [" << field1 << "]" << std::endl;
        std::cout << "field2: [" << field2 << "]" << std::endl;
        
        char c = peek();
        std::cout << "peek after fields: '" << c << "' (int: " << (int)c << ")" << std::endl;
        
        if (c == ',') {
            return false;
        }
        
        std::string h1 = strip(field1);
        std::string h2 = strip(field2);
        
        std::cout << "h1: [" << h1 << "]" << std::endl;
        std::cout << "h2: [" << h2 << "]" << std::endl;
        
        if (h1 != "category" || h2 != "amount") {
            return false;
        }
        
        if (c == '\n') {
            in_.get();
        } else if (c == '\r') {
            in_.get();
            if (peek() == '\n') in_.get();
        }
        
        return true;
    }
    
private:
    std::istream& in_;
    std::string buffer_;
    size_t buffer_pos_ = 0;
    bool eof_ = false;
    
    void fill_buffer() {
        if (eof_) return;
        char c;
        if (in_.get(c)) {
            buffer_ += c;
        } else {
            eof_ = true;
        }
    }
    
    char peek() {
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        return '\0';
    }
    
    char get() {
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        return '\0';
    }
    
    std::string read_field() {
        std::string result;
        char c = peek();
        
        std::cout << "read_field start, peek: '" << c << "'" << std::endl;
        
        if (c == '"') {
            get(); // consume opening quote
            while (true) {
                c = get();
                if (c == '\0') {
                    throw std::invalid_argument("Unterminated quoted field");
                }
                if (c == '"') {
                    char next = peek();
                    if (next == '"') {
                        result += '"';
                        get();
                    } else {
                        break;
                    }
                } else {
                    result += c;
                }
            }
            c = peek();
            if (c != ',' && c != '\n' && c != '\r' && c != '\0') {
                throw std::invalid_argument("Invalid character after quoted field");
            }
        } else {
            while (true) {
                c = peek();
                if (c == ',' || c == '\n' || c == '\r' || c == '\0') {
                    break;
                }
                result += get();
            }
        }
        
        std::cout << "read_field result: [" << result << "]" << std::endl;
        return result;
    }
};

}

int main() {
    std::string input = "category,amount\nfood,100\n";
    std::istringstream iss(input);
    
    std::cout << "Input: [" << input << "]" << std::endl;
    
    CSVParser parser(iss);
    bool ok = parser.parse_header();
    std::cout << "Header parse: " << (ok ? "OK" : "FAIL") << std::endl;
    
    return 0;
}
