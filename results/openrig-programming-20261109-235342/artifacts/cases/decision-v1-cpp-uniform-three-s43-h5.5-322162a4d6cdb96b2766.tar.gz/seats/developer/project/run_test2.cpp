#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_quoted_fields() {
    std::string input = "category,amount\n\"a,b\",100\n\"x\"\"quote\",50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["x\"quote"] == 50);
    std::cout << "test_quoted_fields passed\n";
}

int main() {
    test_quoted_fields();
    return 0;
}
