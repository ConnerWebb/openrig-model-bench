#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_optional_plus_sign() {
    std::string input = "category,amount\nfood,+100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result["food"] == 100);
    std::cout << "test_optional_plus_sign passed\n";
}

int main() {
    test_optional_plus_sign();
    return 0;
}
