#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <algorithm>
#include <cctype>

namespace {

// Strip leading/trailing whitespace (spaces, tabs, CR)
std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse int64 with overflow detection. Returns true on success.
bool parse_int64(const std::string& s, int64_t& out) {
    if (s.empty()) return false;
    
    size_t i = 0;
    bool negative = false;
    
    if (s[i] == '+') {
        ++i;
    } else if (s[i] == '-') {
        negative = true;
        ++i;
    }
    
    if (i >= s.size()) return false; // Only sign, no digits
    
    // Check for any non-digit characters
    for (size_t j = i; j < s.size(); ++j) {
        if (!std::isdigit(static_cast<unsigned char>(s[j]))) {
            return false;
        }
    }
    
    // Parse digits with overflow detection
    uint64_t val = 0;
    for (size_t j = i; j < s.size(); ++j) {
        int digit = s[j] - '0';
        if (val > (std::numeric_limits<uint64_t>::max() - digit) / 10) {
            return false; // Overflow
        }
        val = val * 10 + digit;
    }
    
    if (negative) {
        uint64_t max_neg = static_cast<uint64_t>(std::numeric_limits<int64_t>::max()) + 1; // 9223372036854775808
        if (val > max_neg) {
            return false; // Overflow for negative
        }
        // Handle INT64_MIN specially to avoid UB
        if (val == max_neg) {
            out = std::numeric_limits<int64_t>::min();
        } else {
            out = -static_cast<int64_t>(val);
        }
    } else {
        if (val > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
            return false; // Overflow for positive
        }
        out = static_cast<int64_t>(val);
    }
    
    return true;
}

// Check if accumulation would overflow
bool would_overflow(int64_t current, int64_t add) {
    if (add > 0 && current > std::numeric_limits<int64_t>::max() - add) {
        return true;
    }
    if (add < 0 && current < std::numeric_limits<int64_t>::min() - add) {
        return true;
    }
    return false;
}

// CSV Parser that handles quoted fields, escaped quotes, newlines within quotes
class CSVParser {
public:
    CSVParser(std::istream& is) : in_(is), eof_(false) {
        fill_buffer();
    }
    
    // Parse header, return true if valid "category,amount"
    bool parse_header() {
        std::string field1 = read_field();
        std::string field2 = read_field();
        
        // Check for trailing content (should be end of line or EOF)
        char c = peek();
        if (c == ',') {
            // Third field exists - wrong header
            return false;
        }
        
        std::string h1 = strip(field1);
        std::string h2 = strip(field2);
        
        if (h1 != "category" || h2 != "amount") {
            return false;
        }
        
        // Consume the newline after header
        if (c == '\n') {
            get();
        } else if (c == '\r') {
            get();
            if (peek() == '\n') get();
        }
        
        return true;
    }
    
    // Parse next record. Returns true if a record was read.
    // Sets category and amount. Throws on error.
    bool next_record(std::string& category, int64_t& amount) {
        // Skip empty physical records (lines with only whitespace)
        // But we need to handle this carefully with quoted fields
        
        // First, check if we're at EOF
        if (eof_ && buffer_pos_ >= buffer_.size()) {
            return false;
        }
        
        // Read first field (category)
        std::string field1 = read_field();
        
        // Check if we got an empty field at EOF (end of input)
        if (eof_ && buffer_pos_ >= buffer_.size()) {
            // Check if field1 is empty or whitespace-only
            std::string stripped = strip(field1);
            if (stripped.empty()) {
                return false; // Empty record at end
            }
            // We have a field but no second field - error
            throw std::invalid_argument("Missing amount field");
        }
        
        // Read second field (amount)
        std::string field2 = read_field();
        
        // Check for extra fields
        char c = peek();
        if (c == ',') {
            throw std::invalid_argument("Too many fields");
        }
        
        // Consume newline
        if (c == '\n') {
            get();
        } else if (c == '\r') {
            get();
            if (peek() == '\n') get();
        }
        
        // Strip and validate fields
        category = strip(field1);
        std::string amount_str = strip(field2);
        
        if (category.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        if (!parse_int64(amount_str, amount)) {
            throw std::invalid_argument("Invalid amount format");
        }
        
        return true;
    }
    
private:
    std::istream& in_;
    std::string buffer_;
    size_t buffer_pos_ = 0;
    bool eof_ = false;
    
    void fill_buffer() {
        if (eof_) return;
        char c;
        if (in_.get(c)) {
            buffer_ += c;
        } else {
            eof_ = true;
        }
    }
    
    char peek() {
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        return '\0';
    }
    
    char get() {
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        return '\0';
    }
    
    std::string read_field() {
        std::string result;
        char c = peek();
        
        if (c == '"') {
            // Quoted field
            get(); // consume opening quote
            while (true) {
                c = get();
                if (c == '\0') {
                    throw std::invalid_argument("Unterminated quoted field");
                }
                if (c == '"') {
                    // Check for escaped quote
                    char next = peek();
                    if (next == '"') {
                        // Escaped quote
                        result += '"';
                        get(); // consume second quote
                    } else {
                        // End of quoted field
                        break;
                    }
                } else {
                    result += c;
                }
            }
            // After closing quote, consume the delimiter (comma or newline)
            c = peek();
            if (c == ',') {
                get();
            } else if (c == '\n' || c == '\r' || c == '\0') {
                // End of record or EOF - don't consume newline here, caller handles it
            } else {
                throw std::invalid_argument("Invalid character after quoted field");
            }
        } else {
            // Unquoted field - read until comma or newline
            while (true) {
                c = peek();
                if (c == ',') {
                    get(); // consume the comma
                    break;
                } else if (c == '\n' || c == '\r' || c == '\0') {
                    // End of record or EOF - don't consume newline here
                    break;
                }
                result += get();
            }
        }
        
        return result;
    }
};

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& is) {
    CSVParser parser(is);
    
    // Parse and validate header
    if (!parser.parse_header()) {
        throw std::invalid_argument("Invalid header: expected 'category,amount'");
    }
    
    std::map<std::string, std::int64_t> result;
    
    while (true) {
        std::string category;
        int64_t amount;
        
        try {
            if (!parser.next_record(category, amount)) {
                break; // End of input
            }
        } catch (const std::invalid_argument&) {
            throw; // Re-throw parsing errors
        }
        
        // Check for overflow in accumulation
        auto it = result.find(category);
        if (it != result.end()) {
            if (would_overflow(it->second, amount)) {
                throw std::invalid_argument("Overflow in category accumulation");
            }
            it->second += amount;
        } else {
            result[category] = amount;
        }
    }
    
    return result;
}

#endif // SOLUTION_HPP
