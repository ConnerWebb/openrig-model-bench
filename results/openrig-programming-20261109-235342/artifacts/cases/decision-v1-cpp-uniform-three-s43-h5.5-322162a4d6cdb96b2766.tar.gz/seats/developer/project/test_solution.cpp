#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

void test_unicode_categories() {
    // Using ASCII comma as delimiter, Unicode characters in category names
    std::string input = "category,amount\n日本，100\n日本，50\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    
    assert(result.size() == 1);
    assert(result["日本"] == 150);
    std::cout << "test_unicode_categories passed\n";
}

int main() {
    test_unicode_categories();
    std::cout << "All tests passed!\n";
    return 0;
}
