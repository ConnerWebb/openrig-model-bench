#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_overflow_amount() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow_amount passed\n";
    }
}

int main() {
    test_overflow_amount();
    return 0;
}
