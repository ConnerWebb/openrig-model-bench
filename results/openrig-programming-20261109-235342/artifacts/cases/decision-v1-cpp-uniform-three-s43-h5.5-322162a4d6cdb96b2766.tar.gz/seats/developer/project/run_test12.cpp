#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_scientific_notation() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_scientific_notation passed\n";
    }
}

int main() {
    test_scientific_notation();
    return 0;
}
