#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

int main() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream iss(input);
    
    std::cout << "Input: [" << input << "]" << std::endl;
    std::cout << "Input size: " << input.size() << std::endl;
    
    try {
        auto result = aggregate(iss);
        std::cout << "Result size: " << result.size() << std::endl;
        for (const auto& [k, v] : result) {
            std::cout << "  [" << k << "] = " << v << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
    }
    
    return 0;
}
