#include <iostream>
#include <sstream>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <algorithm>
#include <cctype>

namespace {

std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

class CSVParser {
public:
    CSVParser(std::istream& is) : in_(is), eof_(false) {
        fill_buffer();
    }
    
    bool parse_header() {
        std::string field1 = read_field();
        std::string field2 = read_field();
        
        char c = peek();
        
        if (c == ',') {
            return false;
        }
        
        std::string h1 = strip(field1);
        std::string h2 = strip(field2);
        
        if (h1 != "category" || h2 != "amount") {
            return false;
        }
        
        // Consume the newline after header
        if (c == '\n') {
            get();
        } else if (c == '\r') {
            get();
            if (peek() == '\n') get();
        }
        
        return true;
    }
    
    bool next_record(std::string& category, int64_t& amount) {
        if (eof_ && buffer_pos_ >= buffer_.size()) {
            return false;
        }
        
        std::string field1 = read_field();
        
        if (eof_ && buffer_pos_ >= buffer_.size()) {
            std::string stripped = strip(field1);
            if (stripped.empty()) {
                return false;
            }
            throw std::invalid_argument("Missing amount field");
        }
        
        std::string field2 = read_field();
        
        char c = peek();
        
        if (c == ',') {
            throw std::invalid_argument("Too many fields");
        }
        
        if (c == '\n') {
            get();
        } else if (c == '\r') {
            get();
            if (peek() == '\n') get();
        }
        
        category = strip(field1);
        std::string amount_str = strip(field2);
        
        if (category.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        return true;
    }
    
private:
    std::istream& in_;
    std::string buffer_;
    size_t buffer_pos_ = 0;
    bool eof_ = false;
    
    void fill_buffer() {
        if (eof_) return;
        char c;
        if (in_.get(c)) {
            buffer_ += c;
        } else {
            eof_ = true;
        }
    }
    
    char peek() {
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_];
        }
        return '\0';
    }
    
    char get() {
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        if (eof_) return '\0';
        fill_buffer();
        if (buffer_pos_ < buffer_.size()) {
            return buffer_[buffer_pos_++];
        }
        return '\0';
    }
    
    std::string read_field() {
        std::string result;
        char c = peek();
        
        if (c == '"') {
            get(); // consume opening quote
            while (true) {
                c = get();
                if (c == '\0') {
                    throw std::invalid_argument("Unterminated quoted field");
                }
                if (c == '"') {
                    char next = peek();
                    if (next == '"') {
                        result += '"';
                        get();
                    } else {
                        break;
                    }
                } else {
                    result += c;
                }
            }
            c = peek();
            if (c == ',') {
                get();
            } else if (c != '\n' && c != '\r' && c != '\0') {
                throw std::invalid_argument("Invalid character after quoted field");
            }
        } else {
            while (true) {
                c = peek();
                if (c == ',') {
                    get();
                    break;
                } else if (c == '\n' || c == '\r' || c == '\0') {
                    break;
                }
                result += get();
            }
        }
        
        return result;
    }
};

}

int main() {
    std::string input = "category,amount\nfood,100\n";
    std::istringstream iss(input);
    
    std::cout << "Input: [" << input << "]" << std::endl;
    
    CSVParser parser(iss);
    bool ok = parser.parse_header();
    std::cout << "Header parse: " << (ok ? "OK" : "FAIL") << std::endl;
    
    std::string cat;
    int64_t amt;
    ok = parser.next_record(cat, amt);
    std::cout << "next_record: " << (ok ? "OK" : "FAIL") << ", cat=[" << cat << "], amt=" << amt << std::endl;
    
    return 0;
}
