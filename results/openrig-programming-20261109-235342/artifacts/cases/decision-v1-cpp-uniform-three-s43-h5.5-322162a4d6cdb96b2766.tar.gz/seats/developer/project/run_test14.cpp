#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_accumulation_overflow() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_accumulation_overflow passed\n";
    }
}

int main() {
    test_accumulation_overflow();
    return 0;
}
