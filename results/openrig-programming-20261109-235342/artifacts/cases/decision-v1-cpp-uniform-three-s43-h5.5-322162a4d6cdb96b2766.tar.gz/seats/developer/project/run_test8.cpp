#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_wrong_field_count() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count passed\n";
    }
}

int main() {
    test_wrong_field_count();
    return 0;
}
