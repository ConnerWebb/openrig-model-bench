# Buffer Library

A C++20 buffer implementation with deep copy semantics, bounds-checked access, and safe move operations.

## Features

- **RAII-based memory management**: Automatic cleanup, no memory leaks
- **Deep copy semantics**: Copy constructor and assignment create independent copies
- **Noexcept move operations**: Efficient transfers with proper moved-from state
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Safe resize**: Preserves existing data, zero-initializes new elements
- **Self-assignment safe**: Copy and move assignment handle self-assignment correctly
- **Reusable moved-from state**: Moved-from buffers have size 0 and can be reused

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of size `n`, zero-initialized. Default constructor creates an empty buffer.

### Destructor
```cpp
~Buffer();
```
Frees allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy: creates an independent copy with the same contents.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Transfers ownership. Moved-from buffer has size 0 and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
std::uint8_t operator[](std::size_t i) const;
```
Returns buffer size and element access with bounds checking. Throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t new_size);
```
Resizes the buffer. Preserves prefix up to `min(old_size, new_size)`. New elements are zero-initialized.

## Building

```bash
clang++ -std=c++20 -Wall -Wextra -o test_buffer test_buffer.cpp
./test_buffer
```

## Testing

Run the included test suite:
```bash
./test_buffer
```

All tests should pass with "All tests passed!" output.
