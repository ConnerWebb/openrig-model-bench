#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <utility>

class Buffer {
    std::uint8_t* data_;
    std::size_t size_;

public:
    // Default constructor
    Buffer(std::size_t n = 0) : data_(n > 0 ? new std::uint8_t[n]{} : nullptr), size_(n) {}

    // Destructor
    ~Buffer() {
        delete[] data_;
    }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) 
        : data_(other.size_ > 0 ? new std::uint8_t[other.size_]{} : nullptr), 
          size_(other.size_) {
        if (size_ > 0) {
            for (std::size_t i = 0; i < size_; ++i) {
                data_[i] = other.data_[i];
            }
        }
    }

    // Copy assignment (deep copy, self-assignment safe)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] data_;
            size_ = other.size_;
            data_ = size_ > 0 ? new std::uint8_t[size_]{} : nullptr;
            if (size_ > 0) {
                for (std::size_t i = 0; i < size_; ++i) {
                    data_[i] = other.data_[i];
                }
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept 
        : data_(other.data_), 
          size_(other.size_) {
        other.data_ = nullptr;
        other.size_ = 0;
    }

    // Move assignment (noexcept, self-move safe)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] data_;
            data_ = other.data_;
            size_ = other.size_;
            other.data_ = nullptr;
            other.size_ = 0;
        }
        return *this;
    }

    // Size accessor
    std::size_t size() const noexcept {
        return size_;
    }

    // Mutable operator[] with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= size_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return data_[i];
    }

    // Const operator[] with bounds checking
    std::uint8_t operator[](std::size_t i) const {
        if (i >= size_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return data_[i];
    }

    // Resize preserving prefix, zero-initializing new bytes
    void resize(std::size_t new_size) {
        if (new_size == size_) {
            return;
        }

        std::uint8_t* new_data = new_size > 0 ? new std::uint8_t[new_size]{} : nullptr;
        
        // Copy prefix (min of old and new size)
        std::size_t copy_size = (new_size < size_) ? new_size : size_;
        if (copy_size > 0 && data_ != nullptr) {
            for (std::size_t i = 0; i < copy_size; ++i) {
                new_data[i] = data_[i];
            }
        }

        delete[] data_;
        data_ = new_data;
        size_ = new_size;
    }
};
