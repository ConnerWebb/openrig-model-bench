#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
}

void test_mutable_operator() {
    Buffer b(5);
    b[0] = 10;
    b[1] = 20;
    b[2] = 30;
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
}

void test_const_operator() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    const Buffer& cb = b;
    assert(cb[0] == 1);
    assert(cb[1] == 2);
    assert(cb[2] == 3);
}

void test_bounds_check() {
    Buffer b(5);
    try {
        (void)b[10];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_const_bounds_check() {
    Buffer b(5);
    const Buffer& cb = b;
    try {
        (void)cb[10];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_resize_larger() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
}

void test_resize_smaller() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
}

void test_copy_constructor() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(b1);
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    b2[0] = 99;
    assert(b1[0] == 1);  // Deep copy verified
}

void test_copy_assignment() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(5);
    b2 = b1;
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    b2[0] = 99;
    assert(b1[0] == 1);  // Deep copy verified
}

void test_move_constructor() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(std::move(b1));
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    assert(b1.size() == 0);  // Moved-from is empty
}

void test_move_assignment() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(5);
    b2 = std::move(b1);
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    assert(b1.size() == 0);  // Moved-from is empty
}

void test_self_copy() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b = b;
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
}

void test_self_move() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b = std::move(b);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
}

void test_moved_from_reusable() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    Buffer b2(std::move(b1));
    assert(b1.size() == 0);
    b1.resize(2);
    assert(b1.size() == 2);
    b1[0] = 10;
    b1[1] = 20;
    assert(b1[0] == 10);
    assert(b1[1] == 20);
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_mutable_operator();
    test_const_operator();
    test_bounds_check();
    test_const_bounds_check();
    test_resize_larger();
    test_resize_smaller();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_self_copy();
    test_self_move();
    test_moved_from_reusable();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
