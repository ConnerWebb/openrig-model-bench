"""Tests for solution.py aggregate function."""

import unittest
from solution import aggregate
import tempfile
import os


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("food,10.50\n")
            f.write("rent,200.00\n")
            f.write("food,5.50\n")
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"food": "16.00", "rent": "200.00"})
        finally:
            os.unlink(path)
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write('"a,b",100.00\n')
            f.write('"a,b",50.00\n')
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"a,b": "150.00"})
        finally:
            os.unlink(path)
    
    def test_quoted_fields_with_newlines(self):
        """Test quoted fields containing newlines."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write('"two\nlines",100.00\n')
            f.write('"two\nlines",50.00\n')
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"two\nlines": "150.00"})
        finally:
            os.unlink(path)
    
    def test_quoted_quotes(self):
        """Test quoted fields with escaped quotes (double quotes)."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write('"x""quote",100.00\n')
            f.write('"x""quote",50.00\n')
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {'x"quote': "150.00"})
        finally:
            os.unlink(path)
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("food,10.00\n")
            f.write("\n")
            f.write("  \n")
            f.write("rent,20.00\n")
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"food": "10.00", "rent": "20.00"})
        finally:
            os.unlink(path)
    
    def test_whitespace_stripped(self):
        """Test that whitespace is stripped from category and amount."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("  food  ,  10.50  \n")
            f.write("  rent  ,  20.00  \n")
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"food": "10.50", "rent": "20.00"})
        finally:
            os.unlink(path)
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("food,+10.50\n")
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"food": "10.50"})
        finally:
            os.unlink(path)
    
    def test_invalid_header_wrong_name(self):
        """Test that wrong header name raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("wrong,amount\n")
            f.write("x,1\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_invalid_header_wrong_count(self):
        """Test that wrong number of header fields raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount,extra\n")
            f.write("x,1,2\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write(",1\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_invalid_amount_nan(self):
        """Test that NaN raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("x,NaN\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_invalid_amount_exponent(self):
        """Test that exponent notation raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("x,1e2\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_invalid_amount_too_many_decimal_digits(self):
        """Test that more than 2 decimal digits raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("x,1.234\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_invalid_amount_too_many_digits(self):
        """Test that more than 12 digits raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("x,1234567890123\n")  # 13 digits
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_invalid_record_wrong_field_count(self):
        """Test that record with wrong field count raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("x,1,2\n")
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_unterminated_quote(self):
        """Test that unterminated quote raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write('"x,1\n')
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_sorted_output(self):
        """Test that output is sorted by category."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("zebra,10.00\n")
            f.write("apple,20.00\n")
            f.write("mango,30.00\n")
            path = f.name
        
        try:
            result = aggregate(path)
            keys = list(result.keys())
            self.assertEqual(keys, ["apple", "mango", "zebra"])
        finally:
            os.unlink(path)
    
    def test_unicode_categories(self):
        """Test unicode category names."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("日本,100.00\n")
            f.write("日本,50.00\n")
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {"日本": "150.00"})
        finally:
            os.unlink(path)
    
    def test_exact_decimal_arithmetic(self):
        """Test that decimal arithmetic is exact (no floating point errors)."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            f.write("x,0.1\n")
            f.write("x,0.2\n")
            path = f.name
        
        try:
            result = aggregate(path)
            # 0.1 + 0.2 should be exactly 0.30, not 0.30000000000000004
            self.assertEqual(result, {"x": "0.30"})
        finally:
            os.unlink(path)
    
    def test_empty_file(self):
        """Test that empty file raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_header_only(self):
        """Test file with only header (no data rows)."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("category,amount\n")
            path = f.name
        
        try:
            result = aggregate(path)
            self.assertEqual(result, {})
        finally:
            os.unlink(path)


if __name__ == '__main__':
    unittest.main()
