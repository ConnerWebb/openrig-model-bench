"""CSV aggregation solution using exact decimal arithmetic."""

import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream, aggregate amounts by category.
    
    Args:
        path: Path to CSV file with header "category,amount"
        
    Returns:
        Dict mapping category to total (formatted with 2 decimal places),
        sorted by category key.
        
    Raises:
        ValueError: If header is invalid, category is empty, or amount is malformed.
    """
    # Regex for valid amount: optional +, 1-12 digits, optional decimal with 1-2 digits
    # Must be non-negative, no exponent, finite
    amount_pattern = re.compile(r'^\+?\d{1,12}(\.\d{1,2})?$')
    
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        # Read line by line but handle CSV properly with csv module
        # We need to stream, so we'll use csv.reader which handles quoted fields
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid header: must be exactly 'category,amount'")
        
        for row in reader:
            # Skip completely blank records (empty row or all empty fields)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse as Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check for non-negative and finite
            if amount < 0 or not amount.is_finite():
                raise ValueError(f"Amount must be non-negative and finite: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted by category, formatted with 2 decimal places
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
