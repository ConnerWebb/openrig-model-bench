# CSV Aggregation Solution

This module provides a function to aggregate CSV data by category using exact decimal arithmetic.

## Function

```python
def aggregate(path: str) -> dict[str, str]
```

Reads a UTF-8 CSV file and returns aggregated totals by category.

### Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: 
  - Completely blank records are ignored
  - Every other record must have exactly two fields
  - Whitespace is stripped from both category and amount
  - Category must not be empty
- **Amount format**:
  - Optional leading `+` sign
  - 1-12 decimal digits before the decimal point
  - Optional decimal point followed by 1-2 digits
  - Non-negative, finite, no exponent notation
- **CSV parsing**: Properly handles quoted fields with embedded commas, newlines, and escaped quotes

### Returns

A dictionary mapping category names to totals, sorted by category key, with amounts formatted to exactly 2 decimal places.

### Raises

`ValueError` for:
- Invalid header
- Empty category
- Malformed amount (wrong format, too many digits, exponent notation, NaN, etc.)
- Wrong number of fields in a non-blank record
- Unterminated quotes

### Example

```python
>>> aggregate("data.csv")
{'food': '2262.01', 'rent': '2215.92', 'x"quote': '1458.60'}
```

## Running Tests

```bash
python -m pytest test_solution.py -v
```

Or use the harness test runner:
```bash
run_tests
```
