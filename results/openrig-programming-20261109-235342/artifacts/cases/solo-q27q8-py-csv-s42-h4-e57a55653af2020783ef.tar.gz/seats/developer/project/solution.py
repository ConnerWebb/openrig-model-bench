"""Stream-aggregate a category/amount CSV into exact decimal totals."""

import csv
import re
from decimal import Decimal

_AMOUNT_RE = re.compile(r"^[+]?[0-9]{1,12}(\.[0-9]{1,2})?$")


def _parse_amount(raw: str) -> Decimal:
    text = raw.strip()
    if not _AMOUNT_RE.match(text):
        raise ValueError(f"malformed amount: {raw!r}")
    return Decimal(text)


def aggregate(path: str) -> dict[str, str]:
    """Read the CSV at *path* as a stream and sum amounts per category.

    The header must be exactly ``category,amount``. Completely blank
    records are ignored; every other record must have exactly two fields.
    Categories are whitespace-stripped and must be non-empty. Amounts are
    nonnegative, finite, at most 12 integer digits and at most 2 decimal
    digits, with an optional leading ``+`` and no exponent. Any malformed
    input raises :class:`ValueError`. Returns category keys sorted, with
    totals formatted to exactly two decimal places.
    """
    totals: dict[str, Decimal] = {}
    with open(path, "r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, None)
        if header is None or header != ["category", "amount"]:
            raise ValueError("header must be exactly category,amount")
        for record in reader:
            if not record or all(field.strip() == "" for field in record):
                continue
            if len(record) != 2:
                raise ValueError(f"record must have exactly two fields: {record!r}")
            category = record[0].strip()
            if not category:
                raise ValueError("category must not be empty")
            amount = _parse_amount(record[1])
            totals[category] = totals.get(category, Decimal("0")) + amount
    return {key: f"{value:.2f}" for key, value in sorted(totals.items())}
