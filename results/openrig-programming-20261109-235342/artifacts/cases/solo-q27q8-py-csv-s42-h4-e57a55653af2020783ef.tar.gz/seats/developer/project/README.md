# CSV Category Aggregator

`solution.aggregate(path: str) -> dict[str, str]` reads a UTF-8 CSV file as a
stream and sums the `amount` column per `category`.

## Contract

- The header row must be exactly `category,amount`; anything else raises
  `ValueError`.
- Completely blank records are ignored. Every other record must have exactly
  two fields.
- `category` and `amount` are whitespace-stripped; the category must be
  non-empty after stripping.
- Amounts are nonnegative, finite, with an optional leading `+`, 1–12 integer
  digits, and an optional decimal point followed by 1 or 2 digits. No
  exponent, no `NaN`/`Infinity`.
- Any malformed input (bad header, wrong field count, empty category, bad
  amount, unterminated quote) raises `ValueError`.
- Totals use exact `decimal.Decimal` arithmetic.
- The result maps category keys (sorted) to totals formatted with exactly two
  decimal places.
- Quoted commas and embedded newlines in categories are valid CSV and are
  handled by the standard `csv` module.
- The file is read as a stream (line by line via `csv.reader`), never loaded
  into memory in one go.

## Usage

```python
from solution import aggregate

totals = aggregate("data.csv")
# e.g. {"food": "2262.01", "rent": "2215.92"}
```

## Tests

```bash
python3 -m unittest test_solution -v
```
