"""Tests for solution.aggregate."""

import os
import tempfile
import unittest

from solution import aggregate


def run_csv(csv_text: str):
    fd, path = tempfile.mkstemp(suffix=".csv")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(csv_text)
        return aggregate(path)
    finally:
        os.unlink(path)


class AggregateTests(unittest.TestCase):
    def test_basic_totals_and_sorting(self):
        result = run_csv("category,amount\nfood,1.00\nrent,2.5\nfood,0.25\n")
        self.assertEqual(result, {"food": "1.25", "rent": "2.50"})

    def test_quoted_comma_and_newline_categories(self):
        result = run_csv('category,amount\n"a,b",10.00\n"two\nlines",20.01\n')
        self.assertEqual(result, {"a,b": "10.00", "two\nlines": "20.01"})

    def test_escaped_quotes(self):
        result = run_csv('category,amount\n"x""quote",5.00\n')
        self.assertEqual(result, {'x"quote': "5.00"})

    def test_blank_records_ignored(self):
        result = run_csv("category,amount\n\nfood,1.00\n   \nfood,2.00\n")
        self.assertEqual(result, {"food": "3.00"})

    def test_whitespace_stripped(self):
        result = run_csv("category,amount\n  food  ,  1.5  \n")
        self.assertEqual(result, {"food": "1.50"})

    def test_optional_plus_sign(self):
        result = run_csv("category,amount\nx,+3\ny,+0.10\n")
        self.assertEqual(result, {"x": "3.00", "y": "0.10"})

    def test_exact_decimal_arithmetic(self):
        result = run_csv("category,amount\nx,0.1\nx,0.2\n")
        self.assertEqual(result, {"x": "0.30"})

    def test_twelve_digit_amount(self):
        result = run_csv("category,amount\nx,999999999999\n")
        self.assertEqual(result, {"x": "999999999999.00"})

    def test_header_must_match(self):
        with self.assertRaises(ValueError):
            run_csv("wrong,amount\nx,1\n")
        with self.assertRaises(ValueError):
            run_csv("category, amount\nx,1\n")
        with self.assertRaises(ValueError):
            run_csv("category,amount,extra\nx,1,2\n")

    def test_empty_file_rejected(self):
        with self.assertRaises(ValueError):
            run_csv("")

    def test_wrong_field_count(self):
        with self.assertRaises(ValueError):
            run_csv("category,amount\nx,1,2\n")
        with self.assertRaises(ValueError):
            run_csv("category,amount\nx\n")

    def test_empty_category_rejected(self):
        with self.assertRaises(ValueError):
            run_csv("category,amount\n,1\n")
        with self.assertRaises(ValueError):
            run_csv("category,amount\n   ,1\n")

    def test_malformed_amounts_rejected(self):
        bad = [
            "x,NaN",
            "x,1e2",
            "x,-1",
            "x,1.001",
            "x,1000000000000",
            "x,1.",
            "x,.5",
            "x,1.2.3",
            "x,",
            "x,  ",
            "x,+",
            "x,1,2",
            "x,0x10",
            "x,Infinity",
        ]
        for row in bad:
            with self.assertRaises(ValueError, msg=row):
                run_csv(f"category,amount\n{row}\n")

    def test_unterminated_quote_rejected(self):
        with self.assertRaises(ValueError):
            run_csv('category,amount\n"x,1\n')

    def test_unicode_categories(self):
        result = run_csv("category,amount\n日本,100.00\n日本,0.01\n")
        self.assertEqual(result, {"日本": "100.01"})

    def test_public_case_one(self):
        csv_text = (
            'category,amount\n"x""quote",812.68\nfood,347.25\nrent,991.77\n'
            "rent,345.17\nfood,261.47\n\"x\"\"quote\",71.74\n\"x\"\"quote\",254.02\n"
            "\"x\"\"quote\",31.70\n日本,690.39\n\"a,b\",599.14\nrent,457.86\n"
            "日本,218.62\nfood,455.70\n\"x\"\"quote\",39.70\n\"two\nlines\",849.77\n"
            "\"x\"\"quote\",248.76\nrent,421.12\n\"two\nlines\",584.47\n"
            "food,870.27\nfood,327.32\n"
        )
        self.assertEqual(
            run_csv(csv_text),
            {
                "a,b": "599.14",
                "food": "2262.01",
                "rent": "2215.92",
                "two\nlines": "1434.24",
                'x"quote': "1458.60",
                "日本": "909.01",
            },
        )


if __name__ == "__main__":
    unittest.main()
