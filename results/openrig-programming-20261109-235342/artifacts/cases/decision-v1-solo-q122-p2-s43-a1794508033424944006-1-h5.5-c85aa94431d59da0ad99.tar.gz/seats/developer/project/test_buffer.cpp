#include <iostream>
#include <cassert>
#include <stdexcept>
#include <cstdint>
#include <cstddef>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);

    // Modify original, copy should be unchanged
    a[0] = 99;
    assert(b[0] == 1);
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);

    // Modify original, copy should be unchanged
    a[0] = 99;
    assert(b[0] == 1);
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    assert(a.size() == 0);
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    Buffer b(3);
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    assert(a.size() == 0);
}

void test_move_from_reusable() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    Buffer b(std::move(a));
    assert(a.size() == 0);

    // Reuse moved-from buffer
    a.resize(3);
    assert(a.size() == 3);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    assert(a[0] == 10);
    assert(a[1] == 20);
    assert(a[2] == 30);
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    a = a;
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
}

void test_self_move() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
}

void test_bounds_check_mutable() {
    Buffer a(5);
    try {
        (void)a[5];
        assert(false); // Should have thrown
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_bounds_check_const() {
    Buffer a(5);
    const Buffer& ca = a;
    try {
        (void)ca[5];
        assert(false); // Should have thrown
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_resize_larger() {
    Buffer a(3);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;

    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 0);
    assert(a[4] == 0);
}

void test_resize_smaller() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
}

void test_resize_same() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
}

void test_resize_to_zero() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    a.resize(0);
    assert(a.size() == 0);
}

void test_resize_from_zero() {
    Buffer a;
    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 0);
    assert(a[1] == 0);
    assert(a[2] == 0);
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_move_from_reusable();
    test_self_copy();
    test_self_move();
    test_bounds_check_mutable();
    test_bounds_check_const();
    test_resize_larger();
    test_resize_smaller();
    test_resize_same();
    test_resize_to_zero();
    test_resize_from_zero();
    test_noexcept_move();

    std::cout << "All tests passed!" << std::endl;
    return 0;
}
