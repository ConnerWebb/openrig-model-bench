import unittest
import json
import http.server
import threading
import urllib.parse
import urllib.request
import urllib.error
import socket
import time


class TestFetchPages(unittest.TestCase):
    def _start_server(self, routes, port=None):
        calls = []
        counts = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                n = counts.get(self.path, 0)
                counts[self.path] = n + 1
                route = routes.get(self.path, {"status": 404})
                statuses = route.get("statuses", [route.get("status", 200)])
                status = statuses[min(n, len(statuses) - 1)]
                self.send_response(status)
                self.end_headers()
                if "raw" in route:
                    self.wfile.write(route["raw"].encode())
                else:
                    self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(
            ("127.0.0.1", port or 0), Handler
        )
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server, server.server_port, calls

    def test_basic_two_pages(self):
        routes = {
            "/a": {
                "statuses": [200],
                "body": {
                    "items": [-18, 30, 58, -98, -33],
                    "next": "/b",
                },
            },
            "/b": {
                "body": {"items": [-61, 93, -49], "next": None}
            },
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            result = solution.fetch_pages(f"http://127.0.0.1:{port}/a")
            self.assertEqual(
                result, [-18, 30, 58, -98, -33, -61, 93, -49]
            )
            self.assertEqual(calls, ["/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_retry_on_503(self):
        routes = {
            "/a": {
                "statuses": [503, 200],
                "body": {
                    "items": [-33, -78, -49, 31, -86],
                    "next": "/b",
                },
            },
            "/b": {
                "body": {"items": [52, -51, 29], "next": None}
            },
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            result = solution.fetch_pages(f"http://127.0.0.1:{port}/a")
            self.assertEqual(
                result, [-33, -78, -49, 31, -86, 52, -51, 29]
            )
            self.assertEqual(calls, ["/a", "/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_invalid_retries_negative(self):
        import solution

        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", retries=-1)

    def test_invalid_timeout_zero(self):
        import solution

        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", timeout=0)

    def test_invalid_timeout_negative(self):
        import solution

        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", timeout=-1.5)

    def test_non_http_url(self):
        import solution

        with self.assertRaises(ValueError):
            solution.fetch_pages("ftp://example.com")

    def test_relative_url_initial(self):
        import solution

        with self.assertRaises(ValueError):
            solution.fetch_pages("/relative/path")

    def test_cross_origin_absolute_next(self):
        routes = {
            "/a": {
                "body": {
                    "items": [1, 2, 3],
                    "next": "http://other.com/b",
                }
            }
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_repeated_page_url(self):
        routes = {
            "/a": {
                "body": {"items": [1, 2, 3], "next": "/a"}
            }
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_invalid_json(self):
        routes = {
            "/a": {"raw": "not valid json"}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_missing_items_field(self):
        routes = {
            "/a": {"body": {"data": [1, 2, 3]}}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_items_with_bool(self):
        routes = {
            "/a": {"body": {"items": [True, False]}}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_items_not_list(self):
        routes = {
            "/a": {"body": {"items": 123}}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_max_retries_exceeded(self):
        routes = {
            "/a": {"statuses": [503]}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a", retries=2)
        finally:
            server.shutdown()
            server.server_close()

    def test_non_2xx_status(self):
        routes = {
            "/a": {"status": 404}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_empty_items(self):
        routes = {
            "/a": {"body": {"items": [], "next": None}}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_relative_next_url(self):
        routes = {
            "/a": {
                "body": {"items": [1, 2], "next": "/b"}
            },
            "/b": {
                "body": {"items": [3, 4], "next": None}
            },
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            result = solution.fetch_pages(f"http://127.0.0.1:{port}/a")
            self.assertEqual(result, [1, 2, 3, 4])
            self.assertEqual(calls, ["/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_json_not_object(self):
        routes = {
            "/a": {"body": [1, 2, 3]}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_next_not_string(self):
        routes = {
            "/a": {"body": {"items": [], "next": 123}}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_missing_next_field(self):
        routes = {
            "/a": {"body": {"items": [1, 2, 3]}}
        }
        server, port, calls = self._start_server(routes)
        try:
            import solution

            result = solution.fetch_pages(f"http://127.0.0.1:{port}/a")
            self.assertEqual(result, [1, 2, 3])
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
