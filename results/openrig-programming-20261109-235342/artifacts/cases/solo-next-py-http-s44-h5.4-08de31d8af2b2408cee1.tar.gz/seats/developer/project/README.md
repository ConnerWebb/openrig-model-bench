# fetch_pages Implementation

This project implements `fetch_pages(url, retries=2, timeout=1.0) -> list` as specified in `TASK.txt`.

## API

```python
def fetch_pages(url, retries=2, timeout=1.0) -> list
```

Fetches JSON pages over HTTP using Python stdlib. Each page is an object with `items` (list of integers, booleans are not integers) and `next` (same-origin absolute URL, relative URL, or null). Returns a flat list of all items across pages in order.

### Validation

- `retries` must be a non-negative integer
- `timeout` must be a positive number
- Initial `url` must be a valid HTTP/HTTPS URL
- Rejects cross-origin URLs, repeated page URLs, invalid schema/JSON, and non-HTTP initial URLs with `ValueError`

### Retry Behavior

- Retries only on status codes 429, 500, 502, 503, 504
- Up to `retries` additional attempts per page
- Other HTTP/network failures and exhausted retries raise `ValueError`

### URL Resolution

- Relative `next` URLs (starting with `/`) are resolved against the current page's origin
- Cross-origin `next` URLs are rejected

## Running Tests

```bash
python3 -m unittest test_solution
```

## Example

```python
from solution import fetch_pages

items = fetch_pages("http://example.com/api/page1")
print(items)  # [1, 2, 3, 4, 5, ...]
```
