import json
import urllib.request
import urllib.error
import urllib.parse
import os


def fetch_pages(url, retries=2, timeout=1.0):
    if not isinstance(retries, int) or retries < 0:
        raise ValueError("retries must be a non-negative integer")
    if not isinstance(timeout, (int, float)) or timeout <= 0:
        raise ValueError("timeout must be a positive number")

    if not isinstance(url, str) or not url.lower().startswith("http"):
        raise ValueError("url must be a valid HTTP URL")

    parsed_url = urllib.parse.urlparse(url)
    if parsed_url.scheme not in ("http", "https"):
        raise ValueError("url must be an HTTP or HTTPS URL")

    base_netloc = parsed_url.netloc
    visited = set()
    all_items = []

    current_url = url

    while current_url is not None:
        parsed_current = urllib.parse.urlparse(current_url)
        if parsed_current.netloc != base_netloc:
            raise ValueError("Cross-origin URL not allowed")

        if current_url in visited:
            raise ValueError("Repeated page URL detected")
        visited.add(current_url)

        items, next_url = _fetch_page(current_url, retries, timeout, base_netloc)
        all_items.extend(items)
        current_url = next_url

    return all_items


def _fetch_page(url, retries, timeout, base_netloc):
    last_error = None

    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                body = response.read().decode("utf-8")
                data = json.loads(body)

                if not isinstance(data, dict):
                    raise ValueError("JSON must be an object")

                if "items" not in data:
                    raise ValueError("Missing 'items' field")

                items = data["items"]
                if not isinstance(items, list):
                    raise ValueError("'items' must be a list")

                if len(items) == 0:
                    raise ValueError("'items' must not be empty")

                for item in items:
                    if isinstance(item, bool) or not isinstance(item, int):
                        raise ValueError("All items must be integers (no bools)")

                next_url = data.get("next")
                if next_url is not None:
                    if not isinstance(next_url, str):
                        raise ValueError("'next' must be a string or null")

                    if next_url.startswith("/"):
                        parsed = urllib.parse.urlparse(url)
                        next_url = f"{parsed.scheme}://{parsed.netloc}{next_url}"
                    else:
                        parsed_next = urllib.parse.urlparse(next_url)
                        if parsed_next.netloc and parsed_next.netloc != base_netloc:
                            raise ValueError("Cross-origin URL not allowed")

                return items, next_url

        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504):
                last_error = e
                continue
            else:
                raise ValueError(f"HTTP error {e.code}")
        except urllib.error.URLError as e:
            raise ValueError(f"URL error: {e.reason}")
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON")
        except Exception as e:
            raise ValueError(f"Error fetching page: {e}")

    raise ValueError(f"Max retries exceeded: {last_error}" if last_error else "Max retries exceeded")
