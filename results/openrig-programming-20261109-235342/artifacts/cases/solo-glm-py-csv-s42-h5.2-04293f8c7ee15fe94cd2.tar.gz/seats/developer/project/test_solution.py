import unittest
import os
import tempfile
from decimal import Decimal
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def setUp(self):
        """Create temporary directory for test files."""
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary directory."""
        import shutil
        shutil.rmtree(self.temp_dir)

    def _create_csv(self, content: str) -> str:
        """Helper to create a CSV file and return its path."""
        path = os.path.join(self.temp_dir, 'test.csv')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return path

    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        csv_content = """category,amount
food,10.00
food,20.00
rent,30.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'food': '30.00', 'rent': '30.00'})

    def test_decimal_precision(self):
        """Test that decimal arithmetic is used correctly."""
        csv_content = """category,amount
a,0.01
b,0.02
c,0.03
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'a': '0.01', 'b': '0.02', 'c': '0.03'})

    def test_whitespace_handling(self):
        """Test stripping of whitespace."""
        csv_content = """category,amount
  food  ,  10.00  
  food  ,  20.00  
  rent  ,  30.00  
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'food': '30.00', 'rent': '30.00'})

    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        csv_content = """category,amount
,10.00
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("empty category", str(cm.exception))

    def test_invalid_amount_format(self):
        """Test that invalid amount format raises ValueError."""
        csv_content = """category,amount
a,abc
b,1.23.45
c,12.345
d,1.234567890123
e,+
f,1
g,1.
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Invalid amount format", str(cm.exception))

    def test_invalid_amount_value(self):
        """Test that invalid amount value raises ValueError."""
        csv_content = """category,amount
a,NaN
b,Infinity
c,1e2
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Invalid amount format", str(cm.exception))

    def test_wrong_header(self):
        """Test that wrong header raises ValueError."""
        csv_content = """wrong,amount
a,10.00
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Invalid header", str(cm.exception))

    def test_extra_fields(self):
        """Test that extra fields in row raise ValueError."""
        csv_content = """category,amount
a,10.00,extra
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("expected 2 fields", str(cm.exception))

    def test_missing_fields(self):
        """Test that missing fields in row raise ValueError."""
        csv_content = """category,amount
a,10.00
b
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("expected 2 fields", str(cm.exception))

    def test_empty_file(self):
        """Test that empty file raises ValueError."""
        csv_content = ""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Empty CSV file", str(cm.exception))

    def test_quoted_fields_with_commas(self):
        """Test quoted fields with embedded commas."""
        csv_content = """category,amount
"a,b",10.00
"a,b",20.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'a,b': '30.00'})

    def test_quoted_fields_with_newlines(self):
        """Test quoted fields with embedded newlines."""
        csv_content = """category,amount
"two
lines",10.00
"two
lines",20.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'two\nlines': '30.00'})

    def test_double_quotes(self):
        """Test double quotes in quoted fields."""
        csv_content = """category,amount
"x""quote",10.00
"x""quote",20.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'x"quote': '30.00'})

    def test_unicode_categories(self):
        """Test Unicode category names."""
        csv_content = """category,amount
日本,10.00
日本,20.00
food,30.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'food': '30.00', '日本': '30.00'})

    def test_negative_amount_rejected(self):
        """Test that negative amounts are rejected."""
        csv_content = """category,amount
a,-10.00
"""
        path = self._create_csv(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn("Invalid amount format", str(cm.exception))

    def test_zero_amount(self):
        """Test that zero amounts are accepted."""
        csv_content = """category,amount
a,0.00
b,0.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'a': '0.00', 'b': '0.00'})

    def test_sorted_output(self):
        """Test that output is sorted alphabetically."""
        csv_content = """category,amount
z,10.00
a,20.00
m,30.00
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(list(result.keys()), ['a', 'm', 'z'])

    def test_two_decimal_places(self):
        """Test that all amounts have exactly two decimal places."""
        csv_content = """category,amount
a,1.00
b,1.50
c,1.55
d,1.55
e,1.55
"""
        path = self._create_csv(csv_content)
        result = aggregate(path)
        for value in result.values():
            self.assertEqual(value, f"{Decimal(value):.2f}")


if __name__ == '__main__':
    unittest.main()