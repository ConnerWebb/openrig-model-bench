# CSV Aggregator

A Python module that reads CSV files and aggregates amounts by category using exact decimal arithmetic.

## Overview

The `aggregate()` function reads a CSV file with a header row containing exactly two columns: `category` and `amount`. It parses each record, validates the data, and returns a dictionary mapping category names to their total amounts formatted as strings with exactly two decimal places.

## Features

- **Exact decimal arithmetic**: Uses Python's `Decimal` type for precise calculations
- **CSV parsing**: Handles quoted fields with embedded commas and newlines
- **Input validation**: Strict validation of amount format and data integrity
- **Whitespace handling**: Strips whitespace from category and amount fields
- **Unicode support**: Handles Unicode category names

## API

```python
from solution import aggregate

result = aggregate("path/to/file.csv")
# Returns: {'category1': '100.00', 'category2': '200.50', ...}
```

## Requirements

- Python 3.14 (stdlib only)
- No external dependencies

## CSV Format

### Header
Must be exactly: `category,amount`

### Records
Each record should have exactly two fields:
1. **category**: Non-empty string (whitespace stripped)
2. **amount**: Number with optional `+` prefix, 1-12 digits, optional decimal point with 1-2 digits

### Amount Format
- Optional leading `+` sign
- 1-12 digits before decimal point
- Optional decimal point followed by 1-2 digits
- Examples: `0`, `1`, `123456789012`, `+123.45`, `12.3`, `123.45`

### Quoted Fields
Fields can be quoted to include commas or newlines:
- `"a,b"` → category: `a,b`
- `"two\nlines"` → category: `two\nlines`
- `"x""quote"` → category: `x"quote`

## Error Handling

The function raises `ValueError` for:
- Incorrect header
- Empty CSV file
- Rows with incorrect number of fields
- Empty category names
- Invalid amount format
- Invalid amount values (NaN, Infinity, etc.)

## Examples

### Basic Usage
```python
result = aggregate("expenses.csv")
# {'food': '30.00', 'rent': '30.00'}
```

### With Quoted Fields
```python
# expenses.csv:
# category,amount
# "a,b",10.00
# "a,b",20.00

result = aggregate("expenses.csv")
# {'a,b': '30.00'}
```

### With Unicode
```python
# expenses.csv:
# category,amount
# 日本,10.00
# 日本,20.00

result = aggregate("expenses.csv")
# {'日本': '30.00'}
```

## Testing

Run the test suite:
```bash
python -m unittest test_solution.py
```

## Implementation Details

- Uses Python's built-in `csv` module for parsing
- Uses `decimal.Decimal` for exact arithmetic
- Regex pattern for amount validation: `^[+]?\d{1,12}(\.\d{1,2})?$`
- Results are sorted alphabetically by category name
- All amounts formatted with exactly two decimal places