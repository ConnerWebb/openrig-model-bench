import csv
import re
from decimal import Decimal, InvalidOperation
from typing import Dict

# Amount regex: optional +, 1-12 digits, optional decimal point with 1-2 digits
_AMOUNT_RE = re.compile(r'^[+]?\d{1,12}(\.\d{1,2})?$')


def _parse_amount(amount_str: str) -> Decimal:
    """Parse and validate amount string, returning Decimal."""
    amount_str = amount_str.strip()
    if not _AMOUNT_RE.match(amount_str):
        raise ValueError(f"Invalid amount format: {amount_str!r}")
    try:
        return Decimal(amount_str)
    except InvalidOperation:
        raise ValueError(f"Invalid amount value: {amount_str!r}")


def aggregate(path: str) -> Dict[str, str]:
    """
    Read a CSV file and aggregate amounts by category.

    Args:
        path: Path to CSV file with header "category,amount"

    Returns:
        Dictionary mapping category names to total amounts formatted as strings
        with exactly two decimal places. Categories are sorted alphabetically.

    Raises:
        ValueError: If CSV header is incorrect, amount format is invalid,
                    category is empty, or any other parsing error occurs.
    """
    totals: Dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")

        # Validate header
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: {header}")

        for row_num, row in enumerate(reader, start=2):
            # Skip completely blank rows
            if not row:
                continue

            # Must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Row {row_num}: expected 2 fields, got {len(row)}")

            category, amount_str = row

            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()

            # Category must not be empty
            if not category:
                raise ValueError(f"Row {row_num}: empty category")

            # Parse and validate amount
            try:
                amount = _parse_amount(amount_str)
            except ValueError as e:
                raise ValueError(f"Row {row_num}: {e}")

            # Accumulate using exact decimal arithmetic
            totals[category] = totals.get(category, Decimal('0')) + amount

    # Format results with exactly two decimal places
    result: Dict[str, str] = {cat: f"{total:.2f}" for cat, total in totals.items()}

    # Return sorted by category name
    return dict(sorted(result.items()))