import csv
import sys
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    totals = {}
    with open(path, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader)
        if header != ['category', 'amount']:
            raise ValueError("Header must be exactly 'category,amount'")
        for row in reader:
            if not any(row):
                continue
            if len(row) != 2:
                raise ValueError(f"Row must have exactly 2 fields, got {len(row)}")
            category, amount_str = row
            category = category.strip()
            amount_str = amount_str.strip()
            if not category:
                raise ValueError("Category must not be empty")
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            if amount < 0:
                raise ValueError("Amount must be non-negative")
            # Check if the amount has more than 2 decimal places or uses exponent notation
            if amount.as_tuple().exponent != 0:
                # Convert to string to check for '.' or 'e'/'E' in the original string
                if '.' in amount_str or 'e' in amount_str.lower():
                    raise ValueError("Amount must be finite and without exponent")
            totals[category] = totals.get(category, Decimal(0)) + amount
    # Format the result with exactly two decimal places
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python solution.py <csv-file>")
        sys.exit(1)
    path = sys.argv[1]
    result = aggregate(path)
    for category, total in result.items():
        print(f"{category}: {total}")