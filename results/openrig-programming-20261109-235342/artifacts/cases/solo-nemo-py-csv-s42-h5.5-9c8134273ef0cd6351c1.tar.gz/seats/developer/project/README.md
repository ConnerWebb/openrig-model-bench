# CSV Aggregator

This project implements a Python script `solution.py` that reads a CSV file with exactly two columns: `category` and `amount`. It aggregates the amounts by category using exact decimal arithmetic and outputs the results sorted by category, formatted to two decimal places.

## Requirements

- Python 3.14
- Standard library only

## Usage

```bash
python solution.py <csv-file>
```

The CSV file must have a header row with exactly `category,amount`. Each subsequent row must contain exactly two fields. Empty rows are ignored. Categories are stripped of whitespace and must not be empty. Amounts must be valid non-negative decimal numbers without exponents.

## Testing

The project includes public test cases located in `/work/public-inputs/`. To run the fixed public checks and any custom tests, use:

```bash
run_tests
```

All tests must pass for successful completion.

## Implementation Details

- The script uses Python's `decimal.Decimal` for exact arithmetic.
- It validates input according to the specified constraints.
- The output dictionary keys are sorted and values are formatted to exactly two decimal places.