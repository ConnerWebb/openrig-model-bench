import unittest
import tempfile
import os
import json
import subprocess
import sys


class TestAggregate(unittest.TestCase):

    def _run_driver(self, csv_content: str) -> dict:
        """Run PUBLIC_DRIVER.py with given CSV content."""
        data = {"csv": csv_content}
        result = subprocess.run(
            [sys.executable, "PUBLIC_DRIVER.py"],
            input=json.dumps(data),
            capture_output=True,
            text=True,
            cwd="/work"
        )
        if result.returncode != 0:
            raise RuntimeError(f"Driver failed: {result.stderr}")
        return json.loads(result.stdout)

    def test_case_00(self):
        csv_content = """category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32"""
        expected = {
            "a,b": "599.14",
            "food": "2262.01",
            "rent": "2215.92",
            "two\nlines": "1434.24",
            "x\"quote": "1458.60",
            "日本": "909.01"
        }
        result = self._run_driver(csv_content)
        self.assertEqual(result["value"], expected)

    def test_case_04_invalid_header(self):
        csv_content = "wrong,amount\nx,1\n"
        result = self._run_driver(csv_content)
        self.assertEqual(result["error"], "ValueError")

    def test_case_05_extra_field(self):
        csv_content = "category,amount\nx,1,2\n"
        result = self._run_driver(csv_content)
        self.assertEqual(result["error"], "ValueError")

    def test_case_06_empty_category(self):
        csv_content = "category,amount\n,1\n"
        result = self._run_driver(csv_content)
        self.assertEqual(result["error"], "ValueError")

    def test_case_07_nan(self):
        csv_content = "category,amount\nx,NaN\n"
        result = self._run_driver(csv_content)
        self.assertEqual(result["error"], "ValueError")

    def test_case_08_unclosed_quote(self):
        csv_content = "category,amount\n\"x,1\n"
        result = self._run_driver(csv_content)
        self.assertEqual(result["error"], "ValueError")


if __name__ == "__main__":
    unittest.main()
