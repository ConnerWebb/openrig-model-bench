import csv
from decimal import Decimal, InvalidOperation
import os


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted, totals formatted
    with exactly two decimal places. CSV quoted commas and embedded newlines are valid.
    """
    totals: dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)

        # Read header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")

        if header != ['category', 'amount']:
            raise ValueError("Invalid header")

        for row in reader:
            # Check for blank row (completely blank means all fields are empty strings)
            if len(row) == 0 or all(field.strip() == '' for field in row):
                continue

            # Every non-blank row must have exactly two fields
            if len(row) != 2:
                raise ValueError("Invalid row field count")

            category_raw, amount_raw = row

            # Strip whitespace
            category = category_raw.strip()
            amount_str = amount_raw.strip()

            # Category must not be empty
            if not category:
                raise ValueError("Empty category")

            # Validate amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits
            if not _is_valid_amount(amount_str):
                raise ValueError(f"Invalid amount: {amount_str}")

            # Parse with Decimal
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")

            # Check for NaN, infinity, negative
            if amount.is_nan() or amount.is_infinite() or amount < 0:
                raise ValueError(f"Invalid amount: {amount_str}")

            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount

    # Format with exactly two decimal places, sorted keys
    result = {cat: f"{total:.2f}" for cat, total in sorted(totals.items())}
    return result


def _is_valid_amount(s: str) -> bool:
    """
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits.
    No exponent. Nonnegative, finite.
    """
    if not s:
        return False

    # Optional leading +
    if s.startswith('+'):
        s = s[1:]
        if not s:
            return False

    # Split on decimal point
    if '.' in s:
        parts = s.split('.')
        if len(parts) != 2:
            return False
        integer_part, fractional_part = parts

        # Integer part: 1-12 digits
        if not (1 <= len(integer_part) <= 12) or not integer_part.isdigit():
            return False

        # Fractional part: 1-2 digits
        if not (1 <= len(fractional_part) <= 2) or not fractional_part.isdigit():
            return False
    else:
        # No decimal point: just 1-12 digits
        if not (1 <= len(s) <= 12) or not s.isdigit():
            return False

    return True
