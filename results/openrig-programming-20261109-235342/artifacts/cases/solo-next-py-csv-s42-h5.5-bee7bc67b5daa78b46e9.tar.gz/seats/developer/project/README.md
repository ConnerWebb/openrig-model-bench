# CSV Aggregate Solution

This module implements `aggregate(path: str) -> dict[str, str]` that reads a UTF-8 CSV file and aggregates amounts by category.

## Requirements

- Header must be exactly `category,amount`
- Ignore completely blank records
- Non-blank records must have exactly two fields
- Category must not be empty after stripping whitespace
- Amount format: optional `+`, 1-12 digits, optional decimal point followed by 1-2 digits
- No exponents allowed
- Rejects NaN, infinity, negative values
- Uses exact decimal arithmetic (`decimal.Decimal`)
- Returns category keys sorted, totals formatted with exactly two decimal places

## Usage

```python
from solution import aggregate

result = aggregate("data.csv")
print(result)  # {'category1': '123.45', 'category2': '678.90'}
```

## Testing

Run tests with:
```bash
python3 test_solution.py
```
