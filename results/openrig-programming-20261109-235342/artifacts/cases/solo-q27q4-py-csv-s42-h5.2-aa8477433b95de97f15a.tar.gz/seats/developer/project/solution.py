"""Stream a UTF-8 CSV of (category, amount) rows into exact decimal totals.

Public API:
    aggregate(path: str) -> dict[str, str]

Contract (see TASK.txt):
- Header must be exactly ``category,amount``.
- Every non-blank record has exactly two fields.
- Category and amount are whitespace-stripped; category must be non-empty.
- Amount: optional ``+``, 1-12 decimal digits, optional ``.`` followed by
  1 or 2 digits.  Non-negative, finite, no exponent.
- Any malformed input raises ``ValueError``.
- Totals are accumulated with exact decimal arithmetic and formatted with
  exactly two decimal places; keys are sorted.
- The file is consumed as a stream (line by line); it is never read into
  memory whole just to parse it.
"""

from __future__ import annotations

import csv
import re
from decimal import Decimal

__all__ = ["aggregate"]

_AMOUNT_RE = re.compile(r"^\+?\d{1,12}(\.\d{1,2})?$")


def _parse_amount(raw: str) -> Decimal:
    """Validate and convert one amount field to an exact Decimal."""
    text = raw.strip()
    if not _AMOUNT_RE.match(text):
        raise ValueError(f"malformed amount: {raw!r}")
    return Decimal(text)


def _try_parse(line: str) -> list[str] | None:
    """Try to parse one CSV record from *line*.

    Returns the record list on success, or ``None`` if the line is an
    incomplete quoted field (i.e. the record spans multiple lines).
    Raises ``ValueError`` for a definite parse error.
    """
    try:
        record = next(csv.reader([line]))
    except (csv.Error, StopIteration):
        raise ValueError(f"malformed CSV record: {line!r}")
    if len(record) != 2:
        # Might be the first line of a multi-line quoted field; let the
        # caller decide whether to accumulate more lines.
        return None
    return record


def aggregate(path: str) -> dict[str, str]:
    """Aggregate a CSV file of (category, amount) rows into exact totals."""
    totals: dict[str, Decimal] = {}
    header_seen = False
    pending: list[str] | None = None  # accumulated lines of a multi-line record

    def _process(record: list[str]) -> None:
        nonlocal header_seen
        if not header_seen:
            header_seen = True
            if record != ["category", "amount"]:
                raise ValueError(f"bad header: {record!r}")
            return
        category = record[0].strip()
        if not category:
            raise ValueError("empty category")
        amount = _parse_amount(record[1])
        totals[category] = totals.get(category, Decimal(0)) + amount

    with open(path, "r", encoding="utf-8", newline="") as handle:
        for line in handle:
            if pending is not None:
                # Continuation of a multi-line quoted field.
                if line.strip() == "":
                    raise ValueError("blank line inside quoted field")
                pending.append(line)
                try:
                    record = next(csv.reader(pending))
                except (csv.Error, StopIteration):
                    raise ValueError(f"malformed CSV record: {pending!r}")
                if len(record) != 2:
                    raise ValueError(
                        f"expected exactly two fields, got {len(record)}: {record!r}"
                    )
                pending = None
                _process(record)
                continue

            if line.strip() == "":
                continue

            record = _try_parse(line)
            if record is not None:
                _process(record)
            else:
                # Incomplete record; start accumulating lines.
                pending = [line]

    if pending is not None:
        raise ValueError("unterminated quoted field at end of file")

    return {key: f"{value:.2f}" for key, value in sorted(totals.items())}
