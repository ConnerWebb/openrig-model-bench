# CSV category/amount aggregator

`solution.aggregate(path)` reads a UTF-8 CSV file as a stream and returns a
dict mapping each category to its exact decimal total, formatted with exactly
two decimal places, with keys sorted.

## Contract

- Header must be exactly `category,amount`.
- Completely blank records are ignored; every other record has exactly two fields.
- Category and amount are whitespace-stripped; category must be non-empty.
- Amount: optional `+`, 1-12 decimal digits, optional `.` followed by 1 or 2
  digits. Non-negative, finite, no exponent.
- Any malformed input raises `ValueError`.
- Totals use exact decimal arithmetic (`decimal.Decimal`).
- CSV quoted commas and embedded newlines are valid.
- The file is read line by line; it is never slurped into memory just to parse.

## Run

```
python3 -m unittest test_solution -v
```
