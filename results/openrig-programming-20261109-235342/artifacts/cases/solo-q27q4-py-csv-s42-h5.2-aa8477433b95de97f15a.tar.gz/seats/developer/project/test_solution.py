"""Tests for solution.aggregate.

Covers the public cases in PUBLIC_CASES.json plus a few extra edge cases
(whitespace stripping, optional ``+`` sign, blank lines, header-only file,
exact two-decimal formatting, and the 12-digit upper bound).
"""

import json
import pathlib
import tempfile
import unittest

import solution

CASES = json.loads(pathlib.Path(__file__).with_name("PUBLIC_CASES.json").read_text(encoding="utf-8"))


def _run(csv_text: str):
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d) / "input.csv"
        p.write_text(csv_text, encoding="utf-8")
        return solution.aggregate(str(p))


class PublicCases(unittest.TestCase):
    def test_public_cases(self):
        for i, case in enumerate(CASES):
            with self.subTest(case=i):
                csv_text = case["driver_input"]["csv"]
                expected = case["expected"]
                if "error" in expected:
                    # expected["error"] is a string like "ValueError"
                    exc_type = getattr(__builtins__ if isinstance(__builtins__, dict) else __builtins__, expected["error"], None)
                    if exc_type is None:
                        import builtins
                        exc_type = getattr(builtins, expected["error"], None)
                    if exc_type is None:
                        self.fail(f"unknown exception type: {expected['error']}")
                    with self.assertRaises(exc_type):
                        _run(csv_text)
                else:
                    self.assertEqual(_run(csv_text), expected["value"])


class ExtraCases(unittest.TestCase):
    def test_whitespace_stripped(self):
        self.assertEqual(_run("category,amount\n  food  ,  1.5  \n"), {"food": "1.50"})

    def test_optional_plus_sign(self):
        self.assertEqual(_run("category,amount\nx,+2\n"), {"x": "2.00"})

    def test_blank_lines_ignored(self):
        self.assertEqual(_run("category,amount\n\nx,1\n   \n"), {"x": "1.00"})

    def test_header_only(self):
        self.assertEqual(_run("category,amount\n"), {})

    def test_two_decimal_format(self):
        self.assertEqual(_run("category,amount\nx,1\n"), {"x": "1.00"})

    def test_twelve_digit_max(self):
        self.assertEqual(_run("category,amount\nx,999999999999\n"), {"x": "999999999999.00"})

    def test_thirteen_digit_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,10000000000000\n")

    def test_three_decimal_digits_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,1.001\n")

    def test_exponent_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,1e2\n")

    def test_negative_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,-1\n")

    def test_nan_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,NaN\n")

    def test_three_fields_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\nx,1,2\n")

    def test_empty_category_rejected(self):
        with self.assertRaises(ValueError):
            _run("category,amount\n,1\n")

    def test_bad_header_rejected(self):
        with self.assertRaises(ValueError):
            _run("wrong,amount\nx,1\n")

    def test_unterminated_quote_rejected(self):
        with self.assertRaises(ValueError):
            _run('category,amount\n"x,1\n')

    def test_quoted_comma_and_newline(self):
        self.assertEqual(
            _run('category,amount\n"a,b",1.25\n"two\nlines",0.75\n'),
            {"a,b": "1.25", "two\nlines": "0.75"},
        )

    def test_exact_decimal_accumulation(self):
        # 0.1 + 0.2 is exactly 0.3 in Decimal, not 0.30000000000000004.
        self.assertEqual(_run("category,amount\nx,0.1\nx,0.2\n"), {"x": "0.30"})


if __name__ == "__main__":
    unittest.main()
