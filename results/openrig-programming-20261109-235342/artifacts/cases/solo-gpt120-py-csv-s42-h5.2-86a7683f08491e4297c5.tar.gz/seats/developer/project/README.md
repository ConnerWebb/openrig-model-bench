# CSV Aggregator

This repository implements a function `aggregate(path: str) -> dict[str, str]` that reads a UTF‑8 CSV file containing two columns: `category` and `amount`. It validates the header, skips completely blank rows, trims whitespace, ensures categories are non‑empty, and checks that amounts conform to a strict format (optional leading `+`, 1‑12 digits, optional decimal point with 1‑2 digits, non‑negative, no exponent, and not NaN/Infinity). It uses `decimal.Decimal` for exact arithmetic, sums amounts per category, and returns a dictionary with categories sorted alphabetically and totals formatted to exactly two decimal places.

The implementation streams the file using Python's `csv` module and does not load the entire file into memory.

## Running Tests

```bash
python -m unittest test_solution.py
```

All public cases and additional edge cases are covered.
