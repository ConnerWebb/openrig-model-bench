import csv, decimal, itertools

def aggregate(path: str) -> dict[str, str]:
    # Use Decimal for exact arithmetic
    total = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError('empty file')
        if header != ['category', 'amount']:
            raise ValueError('invalid header')
        for row in reader:
            # skip completely blank records (no fields)
            if len(row) == 0:
                continue
            if len(row) != 2:
                raise ValueError('wrong number of fields')
            cat, amt = row[0].strip(), row[1].strip()
            if not cat:
                raise ValueError('empty category')
            # Validate amount format
            # optional leading +, digits 1-12, optional . with 1-2 digits
            if not amt:
                raise ValueError('empty amount')
            if amt[0] == '+':
                amt_body = amt[1:]
            else:
                amt_body = amt
            # split decimal
            parts = amt_body.split('.')
            if len(parts) == 1:
                int_part = parts[0]
                frac_part = ''
            elif len(parts) == 2:
                int_part, frac_part = parts
                if not (1 <= len(frac_part) <= 2):
                    raise ValueError('invalid fraction')
            else:
                raise ValueError('multiple dots')
            if not int_part.isdigit() or len(int_part) > 12:
                raise ValueError('invalid integer part')
            # No exponent, no negative sign (already checked)
            # Convert to Decimal
            try:
                d = decimal.Decimal(amt_body)
            except Exception:
                raise ValueError('invalid decimal')
            if d.is_nan() or d.is_infinite() or d < 0:
                raise ValueError('invalid amount value')
            # Quantize to two decimal places for consistency
            d = d.quantize(decimal.Decimal('0.01'))
            total[cat] = total.get(cat, decimal.Decimal('0')) + d
    # format output sorted keys
    return {k: f"{v:.2f}" for k, v in sorted(total.items())}
