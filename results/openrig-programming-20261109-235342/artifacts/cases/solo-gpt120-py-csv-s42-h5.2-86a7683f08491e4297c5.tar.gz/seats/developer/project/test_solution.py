import unittest, json, pathlib, subprocess, sys, os

class TestAggregate(unittest.TestCase):
    def run_case(self, case_file):
        # load expected from PUBLIC_CASES.json
        import json
        with open('PUBLIC_CASES.json','r',encoding='utf-8') as f:
            cases = json.load(f)
        case = next(c for c in cases if c['input_file'].endswith(case_file))
        import tempfile
        with tempfile.NamedTemporaryFile('w+', delete=False, encoding='utf-8') as tf:
            tf.write(case['api_input_csv'])
            tf_path = tf.name
        # run solution
        import importlib
        sol = importlib.import_module('solution')
        if 'error' in case['expected']:
            with self.assertRaises(ValueError):
                sol.aggregate(tf_path)
        else:
            result = sol.aggregate(tf_path)
            self.assertEqual(result, case['expected']['value'])
        # cleanup
        import os
        os.remove(tf_path)

    def test_case_00(self):
        self.run_case('case-00.csv')
    def test_case_01(self):
        self.run_case('case-01.csv')
    def test_case_02(self):
        self.run_case('case-02.csv')
    def test_case_03(self):
        self.run_case('case-03.csv')
    def test_case_04(self):
        self.run_case('case-04.csv')
    def test_case_05(self):
        self.run_case('case-05.csv')
    def test_case_06(self):
        self.run_case('case-06.csv')
    def test_case_07(self):
        self.run_case('case-07.csv')
    def test_case_08(self):
        self.run_case('case-08.csv')
    def test_case_09(self):
        self.run_case('case-09.csv')
    def test_case_10(self):
        self.run_case('case-10.csv')
    def test_case_11(self):
        self.run_case('case-11.csv')
    def test_case_12(self):
        self.run_case('case-12.csv')

if __name__ == '__main__':
    unittest.main()
