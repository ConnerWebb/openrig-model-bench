import unittest
import json
import copy
import tempfile
import os
import subprocess
import sys

class TestLedgerValidation(unittest.TestCase):
    def test_normalize_valid_records(self):
        from validation import normalize
        records = [{'id': ' a ', 'category': ' x ', 'cents': 10}]
        result = normalize(records)
        self.assertEqual(result, [{'id': 'a', 'category': 'x', 'cents': 10}])

    def test_normalize_invalid_id_empty(self):
        from validation import normalize
        records = [{'id': '', 'category': 'x', 'cents': 10}]
        with self.assertRaises(ValueError):
            normalize(records)

    def test_normalize_invalid_category_empty(self):
        from validation import normalize
        records = [{'id': 'x', 'category': '', 'cents': 10}]
        with self.assertRaises(ValueError):
            normalize(records)

    def test_normalize_invalid_cents_negative(self):
        from validation import normalize
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            normalize(records)

    def test_normalize_invalid_cents_bool(self):
        from validation import normalize
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            normalize(records)

    def test_normalize_invalid_extra_key(self):
        from validation import normalize
        records = [{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}]
        with self.assertRaises(ValueError):
            normalize(records)

    def test_normalize_invalid_missing_key(self):
        from validation import normalize
        records = [{'id': 'x', 'category': 'a'}]
        with self.assertRaises(ValueError):
            normalize(records)

    def test_normalize_non_dict_record(self):
        from validation import normalize
        records = ['not a dict']
        with self.assertRaises(ValueError):
            normalize(records)

    def test_deduplicate_preserves_first_occurrence(self):
        from storage import deduplicate
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'y', 'cents': 20},
            {'id': 'a', 'category': 'z', 'cents': 30}
        ]
        result = deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[0]['cents'], 10)

    def test_deduplicate_input_unchanged(self):
        from storage import deduplicate
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        original = copy.deepcopy(records)
        deduplicate(records)
        self.assertEqual(records, original)

    def test_process_empty_records(self):
        from ledger import process
        result = process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_process_basic(self):
        from ledger import process
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'x', 'cents': 20}
        ]
        result = process(records)
        self.assertEqual(result['events'], [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'x', 'cents': 20}
        ])
        self.assertEqual(result['totals'], {'x': 30})

    def test_process_minimum_cents(self):
        from ledger import process
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'x', 'cents': 15}
        ]
        result = process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 15)
        self.assertEqual(result['totals'], {'x': 15})

    def test_process_minimum_cents_bool_rejected(self):
        from ledger import process
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        with self.assertRaises(ValueError):
            process(records, minimum_cents=True)

    def test_process_minimum_cents_negative_rejected(self):
        from ledger import process
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        with self.assertRaises(ValueError):
            process(records, minimum_cents=-1)

    def test_process_totals_sorted(self):
        from ledger import process
        records = [
            {'id': 'a', 'category': 'z', 'cents': 10},
            {'id': 'b', 'category': 'a', 'cents': 20}
        ]
        result = process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'z'])

    def test_process_input_unchanged(self):
        from ledger import process
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        original = copy.deepcopy(records)
        process(records)
        self.assertEqual(records, original)

    def test_process_validation_failure(self):
        from ledger import process
        records = [{'id': 'a', 'category': 'x', 'cents': True}]
        with self.assertRaises(ValueError):
            process(records)

    def test_process_deduplication(self):
        from ledger import process
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': 20}
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 10)
        self.assertEqual(result['totals'], {'x': 10})

    def test_public_case_00(self):
        from ledger import process
        with open('/work/public-inputs/case-00.json') as f:
            data = json.load(f)
        result = process(data['records'])
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_01(self):
        from ledger import process
        with open('/work/public-inputs/case-01.json') as f:
            data = json.load(f)
        result = process(data['records'])
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_02(self):
        from ledger import process
        with open('/work/public-inputs/case-02.json') as f:
            data = json.load(f)
        result = process(data['records'])
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_03(self):
        from ledger import process
        with open('/work/public-inputs/case-03.json') as f:
            data = json.load(f)
        result = process(data['records'])
        self.assertIn('events', result)
        self.assertIn('totals', result)

    def test_public_case_04_invalid_cents_bool(self):
        from ledger import process
        with open('/work/public-inputs/case-04.json') as f:
            data = json.load(f)
        with self.assertRaises(ValueError):
            process(data['records'])

    def test_public_case_05_invalid_id_empty(self):
        from ledger import process
        with open('/work/public-inputs/case-05.json') as f:
            data = json.load(f)
        with self.assertRaises(ValueError):
            process(data['records'])

    def test_public_case_06_invalid_cents_negative(self):
        from ledger import process
        with open('/work/public-inputs/case-06.json') as f:
            data = json.load(f)
        with self.assertRaises(ValueError):
            process(data['records'])

    def test_public_case_07_invalid_extra_key(self):
        from ledger import process
        with open('/work/public-inputs/case-07.json') as f:
            data = json.load(f)
        with self.assertRaises(ValueError):
            process(data['records'])

class TestLedgerDriver(unittest.TestCase):
    def test_driver_integration(self):
        with open('/work/public-inputs/case-00.json') as f:
            data = json.load(f)
        with tempfile.TemporaryDirectory() as tmpdir:
            driver_path = os.path.join(tmpdir, 'driver.py')
            with open(driver_path, 'w') as f:
                f.write('''
import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import ledger as solution
 import copy
 original=copy.deepcopy(x['records']);a=solution.process(x['records'],minimum_cents=x.get('minimum',0));b=solution.process([],minimum_cents=0);print(json.dumps({'value':a,'empty':b,'input_unchanged':original==x['records']}))
except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
''')
            input_path = os.path.join(tmpdir, 'input.json')
            with open(input_path, 'w') as f:
                json.dump(data, f)
            cmd = [sys.executable, driver_path]
            with open(input_path) as inp:
                proc = subprocess.run(cmd, stdin=inp, capture_output=True, text=True, timeout=30)
            self.assertEqual(proc.returncode, 0, f"Driver failed: {proc.stderr}")
            out = json.loads(proc.stdout)
            self.assertIn('value', out)
            self.assertIn('empty', out)
            self.assertTrue(out['input_unchanged'])

if __name__ == '__main__':
    unittest.main()
