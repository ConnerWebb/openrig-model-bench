import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import ledger as solution
 import copy
 original=copy.deepcopy(x['records']);a=solution.process(x['records'],minimum_cents=x.get('minimum',0));b=solution.process([],minimum_cents=0);print(json.dumps({'value':a,'empty':b,'input_unchanged':original==x['records']}))

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
