def deduplicate(records):
    """
    Deduplicate records by first-occurrence id.
    
    Input records must already be validated (normalize must be called first).
    Returns a list of fresh copies, preserving input order and first id occurrence.
    Never mutates input.
    """
    seen = set()
    out = []
    for r in records:
        if r['id'] not in seen:
            seen.add(r['id'])
            out.append(dict(r))
    return out
