from validation import normalize
from storage import deduplicate

def process(records, *, minimum_cents=0):
    """
    Process records: validate, deduplicate, filter by minimum_cents, return totals.
    
    - Validates every record (including duplicates) via normalize.
    - Deduplicates by first-occurrence id via deduplicate.
    - Filters records with cents >= minimum_cents (nonnegative int, booleans invalid).
    - Returns {'events': [normalized records in input order], 'totals': {category: sum cents}}.
    - totals keys are sorted alphabetically.
    - Never mutates input or returns shared mutable data.
    - Raises ValueError on invalid records or invalid minimum_cents.
    """
    if type(minimum_cents) is bool or not isinstance(minimum_cents, int) or minimum_cents < 0:
        raise ValueError('minimum')
    normalized = normalize(records)
    deduped = deduplicate(normalized)
    events = [r for r in deduped if r['cents'] >= minimum_cents]
    totals = {}
    for r in events:
        totals[r['category']] = totals.get(r['category'], 0) + r['cents']
    return {'events': events, 'totals': dict(sorted(totals.items()))}
