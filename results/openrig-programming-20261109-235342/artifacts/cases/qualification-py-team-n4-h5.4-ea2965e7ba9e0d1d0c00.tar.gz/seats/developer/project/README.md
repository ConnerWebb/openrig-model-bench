# Ledger Toolkit

A Python toolkit for validating, normalizing, deduplicating, and aggregating record data.

## Modules

### validation.py

```python
def normalize(records) -> list
```
Validate and normalize a list of records.

Each record must be a dict with exactly keys:
- `id`: nonempty stripped string
- `category`: nonempty stripped string
- `cents`: nonnegative integer (booleans are invalid)

Returns a list of fresh normalized records with stripped `id` and `category`.
Raises `ValueError` on any invalid record.

### storage.py

```python
def deduplicate(records) -> list
```
Deduplicate records by first-occurrence id.

Input records must already be validated (call `normalize` first).
Returns a list of fresh copies, preserving input order and first id occurrence.
Never mutates input.

### ledger.py

```python
def process(records, *, minimum_cents=0) -> dict
```
Process records: validate, deduplicate, filter by minimum_cents, return totals.

- Validates every record (including duplicates) via `normalize`.
- Deduplicates by first-occurrence id via `deduplicate`.
- Filters records with `cents >= minimum_cents` (nonnegative int, booleans invalid).
- Returns `{'events': [normalized records in input order], 'totals': {category: sum cents}}`.
- `totals` keys are sorted alphabetically.
- Never mutates input or returns shared mutable data.
- Raises `ValueError` on invalid records or invalid `minimum_cents`.

## Usage

```python
from ledger import process

records = [
    {'id': ' 1 ', 'category': ' a ', 'cents': 10},
    {'id': ' 2 ', 'category': ' b ', 'cents': 20},
    {'id': ' 1 ', 'category': ' c ', 'cents': 30}
]

result = process(records)
# result = {
#   'events': [{'id': '1', 'category': 'a', 'cents': 10}, {'id': '2', 'category': 'b', 'cents': 20}],
#   'totals': {'a': 10, 'b': 20}
# }

result_filtered = process(records, minimum_cents=15)
# result_filtered = {
#   'events': [{'id': '2', 'category': 'b', 'cents': 20}],
#   'totals': {'b': 20}
# }
```

## Testing

Run tests with:
```bash
python3 -m unittest test_submission.py
```
