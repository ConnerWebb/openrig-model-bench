def normalize(records):
    """
    Validate and normalize a list of records.
    
    Each record must be a dict with exactly keys 'id', 'category', 'cents':
      - id: nonempty stripped string
      - category: nonempty stripped string
      - cents: nonnegative integer (booleans are invalid)
    
    Returns a list of fresh normalized records with stripped id/category.
    Raises ValueError on any invalid record.
    """
    out = []
    for r in records:
        if not isinstance(r, dict) or set(r) != {'id', 'category', 'cents'}:
            raise ValueError('record')
        rid = r['id']
        cat = r['category']
        cents = r['cents']
        if not isinstance(rid, str) or not rid.strip():
            raise ValueError('record')
        if not isinstance(cat, str) or not cat.strip():
            raise ValueError('record')
        if type(cents) is bool or not isinstance(cents, int) or cents < 0:
            raise ValueError('record')
        out.append({'id': rid.strip(), 'category': cat.strip(), 'cents': cents})
    return out
