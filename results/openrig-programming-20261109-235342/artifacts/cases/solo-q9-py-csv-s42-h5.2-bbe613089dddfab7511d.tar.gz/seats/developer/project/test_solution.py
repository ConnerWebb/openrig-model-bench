"""Tests for solution.py aggregate function."""

import unittest
import tempfile
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_case_00(self):
        csv_data = """category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {
                    "a,b": "599.14",
                    "food": "2262.01",
                    "rent": "2215.92",
                    "two\nlines": "1434.24",
                    "x\"quote": "1458.60",
                    "日本": "909.01"
                }
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_case_01(self):
        csv_data = """category,amount
rent,204.44
rent,965.51
"x""quote",464.96
"a,b",758.07
food,329.33
"a,b",273.11
"two
lines",38.36
food,127.88
rent,128.71
"a,b",182.35
"two
lines",626.01
"two
lines",741.38
"x""quote",469.53
"a,b",124.37
rent,397.36
"x""quote",283.13
rent,754.49
"two
lines",624.22
"x""quote",420.82
"a,b",124.22
日本,984.39
日本,817.87
"x""quote",338.00
日本,978.27
food,45.98
rent,290.01
"two
lines",427.32
日本,660.85
"x""quote",402.73
rent,353.84
rent,70.22
"two
lines",704.87
"two
lines",312.64
rent,788.02
food,277.54
日本,577.44
"a,b",612.46
"two
lines",339.11
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {
                    "a,b": "2074.58",
                    "food": "780.73",
                    "rent": "3952.60",
                    "two\nlines": "3813.91",
                    "x\"quote": "2379.17",
                    "日本": "4018.82"
                }
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_case_02(self):
        csv_data = """category,amount
"two
lines",701.11
日本,417.63
"x""quote",636.47
"x""quote",645.43
food,534.59
rent,595.15
"a,b",845.38
"x""quote",656.79
日本,380.85
日本,17.78
food,553.84
"two
lines",84.37
"a,b",325.24
"a,b",783.67
日本,198.80
"two
lines",889.26
"x""quote",727.84
"a,b",777.27
"two
lines",64.97
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {
                    "a,b": "2731.56",
                    "food": "1088.43",
                    "rent": "595.15",
                    "two\nlines": "1739.71",
                    "x\"quote": "2666.53",
                    "日本": "1015.06"
                }
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_case_03(self):
        csv_data = """category,amount
"two
lines",134.37
"x""quote",700.99
日本,826.90
"a,b",402.93
日本,720.86
"x""quote",405.45
日本,847.00
food,352.26
"two
lines",420.71
"two
lines",881.80
"a,b",476.84
"x""quote",137.81
"x""quote",589.82
"x""quote",615.63
food,975.70
"a,b",652.20
rent,631.30
日本,898.98
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {
                    "a,b": "1531.97",
                    "food": "1327.96",
                    "rent": "631.30",
                    "two\nlines": "1436.88",
                    "x\"quote": "2449.70",
                    "日本": "3293.74"
                }
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_case_04_error(self):
        csv_data = """wrong,amount
x,1
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_case_05_error(self):
        csv_data = """category,amount
x,1,2
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_case_06_error(self):
        csv_data = """category,amount
,1
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_case_07_error(self):
        csv_data = """category,amount
x,NaN
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_case_08_error(self):
        csv_data = """category,amount
"x,1
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_empty_csv(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write("")
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_single_row(self):
        csv_data = """category,amount
food,100.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {"food": "100.00"}
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_whitespace_stripping(self):
        csv_data = """category,amount
 food , 100.00 
food,200.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {"food": "300.00"}
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_plus_sign(self):
        csv_data = """category,amount
food,+100.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                result = aggregate(f.name)
                expected = {"food": "100.00"}
                self.assertEqual(result, expected)
            finally:
                os.unlink(f.name)
    
    def test_negative_amount_error(self):
        csv_data = """category,amount
food,-100.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_exponent_error(self):
        csv_data = """category,amount
food,1e2
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_data)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)


if __name__ == '__main__':
    unittest.main()
