# CSV Category Amount Aggregator

This module provides a function to aggregate amounts by category from CSV files.

## Usage

```python
from solution import aggregate

result = aggregate("path/to/input.csv")
# Returns: {"category1": "100.00", "category2": "200.00", ...}
```

## Requirements

- Python 3.14+ stdlib only
- Uses `decimal.Decimal` for exact arithmetic

## Input Format

- UTF-8 CSV file with header `category,amount`
- Each data row has exactly two fields
- Category: non-empty string (whitespace stripped)
- Amount: nonnegative decimal (optional `+` prefix, 1-12 integer digits, optional decimal point with 1-2 decimal digits)

## Error Handling

Raises `ValueError` for:
- Invalid header
- Wrong number of fields per row
- Empty category
- Negative amounts
- NaN or Infinity amounts
- Exponents in amount
- Malformed decimal numbers

## Output

Dictionary with category keys sorted alphabetically, values formatted to exactly 2 decimal places.
