"""Aggregate CSV category amounts using exact decimal arithmetic."""

import csv
from decimal import Decimal, InvalidOperation
from typing import Dict


def aggregate(path: str) -> Dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted,
    totals formatted with exactly two decimal places.
    """
    totals: Dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        # Strip whitespace from header
        header = [h.strip() for h in header]
        
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: {header}")
        
        # Process each row
        for row in reader:
            # Skip completely blank records
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Check that row has exactly 2 fields
            if len(row) != 2:
                raise ValueError(f"Row has {len(row)} fields, expected 2")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate and parse amount
            amount = _parse_amount(amount_str)
            
            # Accumulate
            totals[category] = totals.get(category, Decimal('0')) + amount
    
    # Return sorted keys with formatted totals
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}


def _parse_amount(amount_str: str) -> Decimal:
    """
    Parse amount string with optional +, 1–12 decimal digits,
    optional decimal point followed by 1 or 2 digits.
    Nonnegative, finite, no exponent.
    """
    if not amount_str:
        raise ValueError("Empty amount")
    
    # Check for exponent
    if 'e' in amount_str.lower():
        raise ValueError("Amount contains exponent")
    
    # Check for sign
    sign = 1
    if amount_str.startswith('+'):
        sign = 1
        amount_str = amount_str[1:]
    elif amount_str.startswith('-'):
        raise ValueError("Negative amount not allowed")
    
    if not amount_str:
        raise ValueError("Empty amount after sign")
    
    # Split into integer and decimal parts
    if '.' in amount_str:
        int_part, dec_part = amount_str.split('.', 1)
    else:
        int_part, dec_part = amount_str, ''
    
    # Validate integer part: 1-12 digits
    if not int_part:
        raise ValueError("Invalid integer part")
    if len(int_part) > 12:
        raise ValueError("Integer part too long")
    
    # Validate decimal part: 1-2 digits if present
    if dec_part:
        if len(dec_part) < 1 or len(dec_part) > 2:
            raise ValueError("Invalid decimal part")
    
    # Parse using Decimal
    try:
        amount = Decimal(amount_str)
    except InvalidOperation:
        raise ValueError(f"Invalid amount: {amount_str}")
    
    # Check for NaN or Infinity
    if amount.is_nan() or amount.is_infinite():
        raise ValueError(f"Invalid amount: {amount_str}")
    
    # Check nonnegative
    if amount < 0:
        raise ValueError("Negative amount")
    
    return amount
