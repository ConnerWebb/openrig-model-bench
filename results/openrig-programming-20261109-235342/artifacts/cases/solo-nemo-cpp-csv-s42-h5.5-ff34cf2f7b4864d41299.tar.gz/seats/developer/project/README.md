# Solution Overview

This project implements a header-only C++20 solution for aggregating CSV data according to the specified requirements. The core functionality is contained in `solution.hpp`, which provides the `aggregate` function that processes CSV input and returns a sorted map of category totals.

## Implementation Details

The solution consists of:
1. `solution.hpp` - Header-only implementation of the CSV parsing and aggregation logic
2. `tests/test_solution.cpp` - Unit tests using GoogleTest framework
3. `PUBLIC_DRIVER.cpp` - Driver program that interfaces with the solution

## Core Algorithm

The `aggregate` function:
1. Reads CSV input line by line without loading the entire input into memory
2. Parses header to verify it matches "category,amount"
3. Processes each record by:
   - Parsing quoted and unquoted fields correctly
   - Stripping whitespace from categories
   - Validating non-empty categories
   - Converting amount to int64 with overflow protection
   - Accumulating amounts per category
4. Returns a map with sorted keys

## Error Handling

The function throws `std::invalid_argument` for:
- Invalid header format
- Empty categories
- Malformed quoted fields
- Invalid amount values (NaN, non-numeric, overflow)
- Incorrect field counts

## Testing

The solution includes comprehensive tests covering:
- Basic functionality with quoted fields
- Error cases (invalid header, too many fields, empty category, etc.)
- Edge cases (overflow, trailing characters)

## Build and Run

The solution uses the provided `PUBLIC_DRIVER.cpp` which includes:
- Standard includes and helper functions
- JSON output formatting
- Exception handling
- Integration with the `aggregate` function

To run tests:
1. Compile with GoogleTest support
2. Execute the test suite
3. All tests should pass with valid implementations

## Public Input Cases

The solution processes the provided CSV test cases:
- case-00.csv through case-12.csv
- Each case includes expected output values for validation
- Error cases (case-04 through case-12) expect specific error conditions