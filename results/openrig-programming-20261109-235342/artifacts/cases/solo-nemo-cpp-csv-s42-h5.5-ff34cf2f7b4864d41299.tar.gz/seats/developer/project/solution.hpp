#pragma once
#include <map>
#include <string>
#include <istream>
#include <stdexcept>
#include <cstdint>
#include <algorithm>
#include <sstream>

// Helper to trim whitespace from both ends
static inline std::string trim(const std::string& str) {
    size_t start = str.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = str.find_last_not_of(" \t\r\n");
    return str.substr(start, end - start + 1);
}

// Helper to parse a single CSV field (handles quoted fields)
static inline std::string parse_field(std::istream& stream) {
    std::string field;
    char c;
    
    // Skip leading whitespace
    while (stream.peek() == ' ' || stream.peek() == '\t') {
        stream.get();
    }
    
    // Check for opening quote
    if (stream.peek() == '"') {
        stream.get(); // consume opening quote
        while (stream.get(c)) {
            if (c == '"') {
                // Check if it's an escaped quote
                if (stream.peek() == '"') {
                    stream.get(); // consume escaped quote
                    field += '"';
                } else {
                    // Closing quote
                    break;
                }
            } else {
                field += c;
            }
        }
    } else {
        // Unquoted field - read until comma or newline
        while (stream.get(c) && c != ',' && c != '\n' && c != '\r') {
            field += c;
        }
    }
    
    return field;
}

// Main aggregation function
inline std::map<std::string, std::int64_t> aggregate(std::istream& input) {
    std::map<std::string, std::int64_t> result;
    
    // Read header
    std::string header_line;
    if (!std::getline(input, header_line)) {
        throw std::invalid_argument("Empty input");
    }
    
    // Parse header fields
    std::istringstream header_stream(header_line);
    std::string category_header = parse_field(header_stream);
    std::string amount_header = parse_field(header_stream);
    
    if (category_header != "category" || amount_header != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Process each record
    std::string line;
    while (std::getline(input, line)) {
        if (line.empty()) continue;
        
        std::istringstream line_stream(line);
        std::string category = parse_field(line_stream);
        std::string amount_str = parse_field(line_stream);
        
        // Trim whitespace from category
        category = trim(category);
        
        // Validate category
        if (category.empty()) {
            throw std::invalid_argument("Empty category");
        }
        
        // Parse amount as int64
        try {
            // Check for overflow by attempting conversion
            size_t pos;
            std::int64_t amount = std::stoll(amount_str, &pos);
            if (pos != amount_str.size()) {
                throw std::invalid_argument("Trailing characters after number");
            }
            
            // Accumulate the amount
            result[category] += amount;
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount value");
        }
    }
    
    return result;
}