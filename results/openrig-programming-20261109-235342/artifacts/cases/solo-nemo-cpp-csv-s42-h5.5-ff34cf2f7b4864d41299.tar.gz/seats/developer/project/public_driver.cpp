#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <string>
#include <cctype>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cassert>
#include <iomanip>
#include <algorithm>
#include <vector>

// Helper function to parse CSV fields
static std::string parse_field(std::istream& stream) {
    std::string field;
    char c;
    
    // Skip leading whitespace
    while (stream.peek() == ' ' || stream.peek() == '\t') {
        stream.get();
    }
    
    // Check for opening quote
    if (stream.peek() == '"') {
        stream.get(); // consume opening quote
        while (stream.get(c)) {
            if (c == '"') {
                // Check if it's an escaped quote
                if (stream.peek() == '"') {
                    stream.get(); // consume escaped quote
                    field += '"';
                } else {
                    // Closing quote
                    break;
                }
            } else {
                field += c;
            }
        }
    } else {
        // Unquoted field - read until comma or newline
        while (stream.get(c) && c != ',' && c != '\n' && c != '\r') {
            field += c;
        }
    }
    
    return field;
}

// Helper to trim whitespace from both ends
static inline std::string trim(const std::string& str) {
    size_t start = str.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = str.find_last_not_of(" \t\r\n");
    return str.substr(start, end - start + 1);
}

// Main aggregation function
std::map<std::string, std::int64_t> aggregate(std::istream& input) {
    std::map<std::string, std::int64_t> result;
    
    // Read header
    std::string header_line;
    if (!std::getline(input, header_line)) {
        throw std::invalid_argument("Empty input");
    }
    
    // Parse header fields
    std::istringstream header_stream(header_line);
    std::string category_header = parse_field(header_stream);
    std::string amount_header = parse_field(header_stream);
    
    if (category_header != "category" || amount_header != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Process each record
    std::string line;
    while (std::getline(input, line)) {
        if (line.empty()) continue;
        
        std::istringstream line_stream(line);
        std::string category = parse_field(line_stream);
        std::string amount_str = parse_field(line_stream);
        
        // Trim whitespace from category
        category = trim(category);
        
        // Validate category
        if (category.empty()) {
            throw std::invalid_argument("Empty category");
        }
        
        // Parse amount as int64
        try {
            // Check for overflow by attempting conversion
            size_t pos;
            std::int64_t amount = std::stoll(amount_str, &pos);
            if (pos != amount_str.size()) {
                throw std::invalid_argument("Trailing characters after number");
            }
            
            // Accumulate the amount
            result[category] += amount;
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount value");
        }
    }
    
    return result;
}

// Helper function to parse CSV input and return result
static std::map<std::string, std::int64_t> process_csv(const std::string& csv_input) {
    std::istringstream input(csv_input);
    return aggregate(input);
}

// Helper function to format JSON output
static std::string format_json(const std::map<std::string, std::int64_t>& data) {
    std::string result = "{";
    bool first = true;
    for (const auto& pair : data) {
        if (!first) result += ",";
        result += "\"" + escape_json(pair.first) + "\":" + std::to_string(pair.second);
        first = false;
    }
    result += "}";
    return result;
}

// Helper function to escape JSON strings
static std::string escape_json(const std::string& str) {
    std::string result;
    for (char c : str) {
        switch (c) {
            case '"': result += "\\\""; break;
            case '\\': result += "\\\\"; break;
            case '\b': result += "\\b"; break;
            case '\f': result += "\\f"; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default: 
                if (static_cast<unsigned char>(c) < 0x20 || static_cast<unsigned char>(c) > 0x7f) {
                    // Handle Unicode characters
                    result += "\\u";
                    char buf[5];
                    snprintf(buf, sizeof(buf), "%04x", static_cast<unsigned int>(c));
                    std::string hex = buf;
                    for (char d : hex) {
                        result += d;
                    }
                } else {
                    result += c;
                }
        }
    }
    return result;
}

// Helper function to read CSV files
static std::string read_csv_file(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }
    
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// Main function
int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <csv_file>\n";
        return 1;
    }
    
    try {
        // Read CSV input
        std::string csv_input = read_csv_file(argv[1]);
        
        // Process CSV input
        auto result = aggregate(std::istringstream(csv_input));
        
        // Format and print JSON output
        std::cout << format_json(result) << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}