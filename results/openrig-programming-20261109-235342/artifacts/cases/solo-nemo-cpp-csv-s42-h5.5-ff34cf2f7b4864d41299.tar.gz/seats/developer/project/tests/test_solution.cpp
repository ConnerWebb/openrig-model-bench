#include <gtest/gtest.h>
#include <sstream>
#include <map>
#include <string>

// Function to parse CSV fields
static std::string parse_field(std::istream& stream) {
    std::string field;
    char c;
    
    // Skip leading whitespace
    while (stream.peek() == ' ' || stream.peek() == '\t') {
        stream.get();
    }
    
    // Check for opening quote
    if (stream.peek() == '"') {
        stream.get(); // consume opening quote
        while (stream.get(c)) {
            if (c == '"') {
                // Check if it's an escaped quote
                if (stream.peek() == '"') {
                    stream.get(); // consume escaped quote
                    field += '"';
                } else {
                    // Closing quote
                    break;
                }
            } else {
                field += c;
            }
        }
    } else {
        // Unquoted field - read until comma or newline
        while (stream.get(c) && c != ',' && c != '\n' && c != '\r') {
            field += c;
        }
    }
    
    return field;
}

// Helper to trim whitespace from both ends
static inline std::string trim(const std::string& str) {
    size_t start = str.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = str.find_last_not_of(" \t\r\n");
    return str.substr(start, end - start + 1);
}

// Main aggregation function
std::map<std::string, std::int64_t> aggregate(std::istream& input) {
    std::map<std::string, std::int64_t> result;
    
    // Read header
    std::string header_line;
    if (!std::getline(input, header_line)) {
        throw std::invalid_argument("Empty input");
    }
    
    // Parse header fields
    std::istringstream header_stream(header_line);
    std::string category_header = parse_field(header_stream);
    std::string amount_header = parse_field(header_stream);
    
    if (category_header != "category" || amount_header != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Process each record
    std::string line;
    while (std::getline(input, line)) {
        if (line.empty()) continue;
        
        std::istringstream line_stream(line);
        std::string category = parse_field(line_stream);
        std::string amount_str = parse_field(line_stream);
        
        // Trim whitespace from category
        category = trim(category);
        
        // Validate category
        if (category.empty()) {
            throw std::invalid_argument("Empty category");
        }
        
        // Parse amount as int64
        try {
            // Check for overflow by attempting conversion
            size_t pos;
            std::int64_t amount = std::stoll(amount_str, &pos);
            if (pos != amount_str.size()) {
                throw std::invalid_argument("Trailing characters after number");
            }
            
            // Accumulate the amount
            result[category] += amount;
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount value");
        }
    }
    
    return result;
}

// Helper function to parse CSV input and return result
static std::map<std::string, std::int64_t> process_csv(const std::string& csv_input) {
    std::istringstream input(csv_input);
    return aggregate(input);
}

// Helper function to format JSON output
static std::string format_json(const std::map<std::string, std::int64_t>& data) {
    std::string result = "{";
    bool first = true;
    for (const auto& pair : data) {
        if (!first) result += ",";
        result += "\"" + escape_json(pair.first) + "\":" + std::to_string(pair.second);
        first = false;
    }
    result += "}";
    return result;
}

// Helper function to escape JSON strings
static std::string escape_json(const std::string& str) {
    std::string result;
    for (char c : str) {
        switch (c) {
            case '"': result += "\\\""; break;
            case '\\': result += "\\\\"; break;
            case '\b': result += "\\b"; break;
            case '\f': result += "\\f"; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default: 
                if (static_cast<unsigned char>(c) < 0x20 || static_cast<unsigned char>(c) > 0x7f) {
                    // Handle Unicode characters
                    result += "\\u";
                    char buf[5];
                    snprintf(buf, sizeof(buf), "%04x", static_cast<unsigned int>(c));
                    std::string hex = buf;
                    for (char d : hex) {
                        result += d;
                    }
                } else {
                    result += c;
                }
        }
    }
    return result;
}

// Test fixture
class AggregationTest : public ::testing::Test {
protected:
    // Helper to run aggregation on a CSV string
    std::map<std::string, std::int64_t> run_aggregation(const std::string& csv_input) {
        std::istringstream input(csv_input);
        return aggregate(input);
    }
};

// Test case 0
TEST_F(AggregationTest, FixedCase0) {
    const std::string csv_input = "\"category,amount\\n\\\"x\\\"\\\"quote\\\",51268\\nfood,4725\\nrent,69177\\nrent,4517\\nfood,-3853\\n\\\"x\\\"\\\"quote\\\",-22826\\n\\\"x\\\"\\\"quote\\\",-4598\\n\\\"x\\\"\\\"quote\\\",-26830\\n日本,39039\\n\\\"a,b\\\",29914\\nrent,15786\\n日本,-8138\\nfood,15570\\n\\\"x\\\"\\\"quote\\\",-26030\\n\\\"two\\nlines\\\",54977\\n\\\"x\\\"\\\"quote\\\",-5124\\nrent,12112\\n\\\"two\\nlines\\\",28447\\nfood,57027\\nfood,2732\\\"";
    
    auto result = run_aggregation(csv_input);
    
    // Expected values
    std::map<std::string, std::int64_t> expected = {
        {"a,b", 29914},
        {"food", 76201},
        {"rent", 101592},
        {"two\nlines", 83424},
        {"x\"quote", -34140},
        {"日本", 30901}
    };
    
    // Check each expected value
    for (const auto& pair : expected) {
        auto it = result.find(pair.first);
        ASSERT_NE(it, result.end()) << "Category \"" << pair.first << "\" not found in result";
        EXPECT_EQ(it->second, pair.second) << "Category \"" << pair.first << "\" has unexpected value";
    }
}

// Test case 1
TEST_F(AggregationTest, FixedCase1) {
    const std::string csv_input = "\"category,amount\\nrent,-9556\\nrent,66551\\n\\\"x\\\"\\\"quote\\\",16496\\n\\\"a,b\\\",45807\\nfood,2933\\n\\\"a,b\\\",-2689\\n\\\"two\\nlines\\\",-26164\\nfood,-17212\\nrent,-17129\\n\\\"two\\nlines\\\",32601\\n\\\"two\\nlines\\\",44138\\n\\\"x\\\"\\\"quote\\\",16953\\n\\\"a,b\\\",-17563\\nrent,9736\\n\\\"x\\\"\\\"quote\\\",-1687\\nrent,45449\\n\\\"two\\nlines\\\",32422\\n\\\"x\\\"\\\"quote\\\",12082\\n\\\"a,b\\\",-17578\\n日本,68439\\n日本,51787\\n\\\"x\\\"\\\"quote\\\",3800\\n日本,67827\\nfood,-25402\\nrent,-999\\n\\\"two\\nlines\\\",12732\\n日本,36085\\n\\\"x\\\"\\\"quote\\\",10273\\nrent,5384\\nrent,-22978\\n\\\"two\\nlines\\\",40487\\n\\\"two\\nlines\\\",1264\\nrent,48802\\nfood,-2246\\n日本,27744\\n\\\"a,b\\\",31246\\n\\\"two\\nlines\\\",3911\\\"";
    
    auto result = run_aggregation(csv_input);
    
    // Expected values
    std::map<std::string, std::int64_t> expected = {
        {"a,b", 27458},
        {"food", -41927},
        {"rent", 125260},
        {"two\nlines", 141391},
        {"x\"quote", 57917},
        {"日本", 251882}
    };
    
    // Check each expected value
    for (const auto& pair : expected) {
        auto it = result.find(pair.first);
        ASSERT_NE(it, result.end()) << "Category \"" << pair.first << "\" not found in result";
        EXPECT_EQ(it->second, pair.second) << "Category \"" << pair.first << "\" has unexpected value";
    }
}

// Test case 2
TEST_F(AggregationTest, FixedCase2) {
    const std::string csv_input = "\"category,amount\\n\\\"two\\nlines\\\",40111\\n日本,11763\\n\\\"x\\\"\\\"quote\\\",33647\\n\\\"x\\\"\\\"quote\\\",34543\\nfood,23459\\nrent,29515\\n\\\"a,b\\\",54538\\n\\\"x\\\"\\\"quote\\\",35679\\n日本,8085\\n日本,-28222\\nfood,25384\\n\\\"two\\nlines\\\",-21563\\n\\\"a,b\\\",2524\\n\\\"a,b\\\",48367\\n日本,-10120\\n\\\"two\\nlines\\\",58926\\n\\\"x\\\"\\\"quote\\\",42784\\n\\\"a,b\\\",47727\\n\\\"two\\nlines\\\",-23503\\\"";
    
    auto result = run_aggregation(csv_input);
    
    // Expected values
    std::map<std::string, std::int64_t> expected = {
        {"a,b", 153156},
        {"food", 48843},
        {"rent", 29515},
        {"two\nlines", 53971},
        {"x\"quote", 146653},
        {"日本", -18494}
    };
    
    // Check each expected value
    for (const auto& pair : expected) {
        auto it = result.find(pair.first);
        ASSERT_NE(it, result.end()) << "Category \"" << pair.first << "\" not found in result";
        EXPECT_EQ(it->second, pair.second) << "Category \"" << pair.first << "\" has unexpected value";
    }
}

// Test case 3
TEST_F(AggregationTest, FixedCase3) {
    const std::string csv_input = "\"category,amount\\n\\\"two\\nlines\\\",-16563\\n日本,52690\\n\\\"x\\\"\\\"quote\\\",40099\\n\\\"x\\\"\\\"quote\\\",40099\\nfood,5226\\n\\\"two\\nlines\\\",12071\\n\\\"two\\nlines\\\",58180\\n\\\"a,b\\\",17684\\n\\\"x\\\"\\\"quote\\\",-16219\\n\\\"x\\\"\\\"quote\\\",28982\\n\\\"x\\\"\\\"quote\\\",31563\\nfood,67570\\n\\\"a,b\\\",35220\\nrent,33130\\n日本,59898\\\"";
    
    auto result = run_aggregation(csv_input);
    
    // Expected values
    std::map<std::string, std::int64_t> expected = {
        {"a,b", 63197},
        {"food", 72796},
        {"rent", 33130},
        {"two\nlines", 53688},
        {"x\"quote", 94970},
        {"日本", 209374}
    };
    
    // Check each expected value
    for (const auto& pair : expected) {
        auto it = result.find(pair.first);
        ASSERT_NE(it, result.end()) << "Category \"" << pair.first << "\" not found in result";
        EXPECT_EQ(it->second, pair.second) << "Category \"" << pair.first << "\" has unexpected value";
    }
}

// Test case 5
TEST_F(AggregationTest, FixedCase5) {
    const std::string csv_input = "\"category,amount\\nx,1,2\\n\"";
    
    EXPECT_THROW({
        run_aggregation(csv_input);
    }, std::invalid_argument);
}

// Test case 11
TEST_F(AggregationTest, FixedCase11) {
    const std::string csv_input = "\"category,amount\\nx,9223372036854775807\\nx,1\\n\"";
    
    EXPECT_THROW({
        run_aggregation(csv_input);
    }, std::invalid_argument);
}

// Test case 12
TEST_F(AggregationTest, FixedCase12) {
    const std::string csv_input = "\"category,amount\\nx,-9223372036854775808\\nx,-1\\n\"";
    
    EXPECT_THROW({
        run_aggregation(csv_input);
    }, std::invalid_argument);
}

// Helper function to escape JSON strings
static std::string escape_json(const std::string& str) {
    std::string result;
    for (char c : str) {
        switch (c) {
            case '"': result += "\\\""; break;
            case '\\': result += "\\\\"; break;
            case '\b': result += "\\b"; break;
            case '\f': result += "\\f"; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default: 
                if (static_cast<unsigned char>(c) < 0x20 || static_cast<unsigned char>(c) > 0x7f) {
                    // Handle Unicode characters
                    result += "\\u";
                    char buf[5];
                    snprintf(buf, sizeof(buf), "%04x", static_cast<unsigned int>(c));
                    std::string hex = buf;
                    for (char d : hex) {
                        result += d;
                    }
                } else {
                    result += c;
                }
        }
    }
    return result;
}

// main function for gtest
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}