#include "stats.hpp"
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <vector>
#include <string>
#include <iomanip>
#include <limits>

void test_empty_stats() {
    RunningStats rs;
    if (rs.count() != 0) throw std::runtime_error("empty count");
    try {
        rs.mean();
        throw std::runtime_error("mean empty should throw");
    } catch (const std::domain_error&) {}
    try {
        rs.variance();
        throw std::runtime_error("variance empty should throw");
    } catch (const std::domain_error&) {}
    try {
        rs.minimum();
        throw std::runtime_error("minimum empty should throw");
    } catch (const std::domain_error&) {}
    try {
        rs.maximum();
        throw std::runtime_error("maximum empty should throw");
    } catch (const std::domain_error&) {}
}

void test_single_value() {
    RunningStats rs;
    rs.add(42.0);
    if (rs.count() != 1) throw std::runtime_error("single count");
    if (rs.mean() != 42.0) throw std::runtime_error("single mean");
    if (rs.variance() != 0.0) throw std::runtime_error("single variance");
    if (rs.minimum() != 42.0) throw std::runtime_error("single min");
    if (rs.maximum() != 42.0) throw std::runtime_error("single max");
}

void test_nan_rejection() {
    RunningStats rs;
    try {
        rs.add(std::nan(""));
        throw std::runtime_error("nan should reject");
    } catch (const std::invalid_argument&) {}
    if (rs.count() != 0) throw std::runtime_error("nan changed state");
}

void test_inf_rejection() {
    RunningStats rs;
    try {
        rs.add(std::numeric_limits<double>::infinity());
        throw std::runtime_error("inf should reject");
    } catch (const std::invalid_argument&) {}
    try {
        rs.add(-std::numeric_limits<double>::infinity());
        throw std::runtime_error("-inf should reject");
    } catch (const std::invalid_argument&) {}
    if (rs.count() != 0) throw std::runtime_error("inf changed state");
}

void test_merge_empty() {
    RunningStats rs;
    rs.add(10.0);
    RunningStats empty;
    rs.merge(empty);
    if (rs.count() != 1) throw std::runtime_error("merge empty count");
    if (rs.mean() != 10.0) throw std::runtime_error("merge empty mean");
}

void test_merge_into_empty() {
    RunningStats rs;
    rs.add(20.0);
    RunningStats empty;
    empty.merge(rs);
    if (empty.count() != 1) throw std::runtime_error("merge into empty count");
    if (empty.mean() != 20.0) throw std::runtime_error("merge into empty mean");
}

void test_self_merge() {
    RunningStats rs;
    rs.add(10.0);
    rs.merge(rs);
    if (rs.count() != 2) throw std::runtime_error("self merge count");
    if (rs.mean() != 10.0) throw std::runtime_error("self merge mean");
    if (rs.variance() != 0.0) throw std::runtime_error("self merge variance");
}

void test_large_offset() {
    RunningStats rs;
    double base = 1e9;
    std::vector<double> vals = {base + 30.0, base + 58.0, base - 98.0, base - 33.0, base - 61.0,
                                base + 93.0, base - 49.0, base - 33.0, base - 78.0, base - 49.0};
    for (double v : vals) rs.add(v);
    double expected_mean = base + 1.428572;
    double actual_mean = rs.mean();
    double abs_err = std::abs(actual_mean - expected_mean);
    double rel_err = abs_err / expected_mean;
    if (abs_err > 1e-4 && rel_err > 1e-6) {
        std::ostringstream oss;
        oss << std::setprecision(17) << "mean err " << abs_err << " rel " << rel_err;
        throw std::runtime_error(oss.str());
    }
}

void test_merge_preserves_stats() {
    RunningStats a, b;
    a.add(1.0); a.add(2.0); a.add(3.0);
    b.add(4.0); b.add(5.0);
    a.merge(b);
    if (a.count() != 5) throw std::runtime_error("merge count");
    if (a.mean() != 3.0) throw std::runtime_error("merge mean");
    if (a.minimum() != 1.0) throw std::runtime_error("merge min");
    if (a.maximum() != 5.0) throw std::runtime_error("merge max");
}

void test_negative_values() {
    RunningStats rs;
    rs.add(-5.0); rs.add(5.0);
    if (rs.mean() != 0.0) throw std::runtime_error("neg mean");
    if (rs.minimum() != -5.0) throw std::runtime_error("neg min");
    if (rs.maximum() != 5.0) throw std::runtime_error("neg max");
}

int main() {
    try {
        test_empty_stats();
        test_single_value();
        test_nan_rejection();
        test_inf_rejection();
        test_merge_empty();
        test_merge_into_empty();
        test_self_merge();
        test_large_offset();
        test_merge_preserves_stats();
        test_negative_values();
        std::cout << "All tests passed" << std::endl;
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Test failed: " << e.what() << std::endl;
        return 1;
    }
}
