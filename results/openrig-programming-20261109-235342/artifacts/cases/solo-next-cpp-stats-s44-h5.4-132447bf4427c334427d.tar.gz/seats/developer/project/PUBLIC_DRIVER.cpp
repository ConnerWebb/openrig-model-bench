#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "stats.hpp"
std::string js(const std::string&s){std::ostringstream o;o<<'"';for(unsigned char c:s){if(c=='"'||c=='\\')o<<'\\'<<c;else if(c=='\n')o<<"\\n";else if(c=='\r')o<<"\\r";else if(c=='\t')o<<"\\t";else if(c<32)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)c<<std::dec;else o<<c;}o<<'"';return o.str();}
int main(){try{
int n,split,self;std::cin>>n>>split>>self;RunningStats a,b;for(int i=0;i<n;i++){std::string token;std::cin>>token;double x=std::stod(token);if(i<split)a.add(x);else b.add(x);}a.merge(b);if(self)a.merge(a);auto count=a.count();auto mean=a.mean();auto var=a.variance();auto minimum=a.minimum();auto maximum=a.maximum();std::cout<<std::setprecision(17)<<"{\"value\":["<<count<<','<<mean<<','<<var<<','<<minimum<<','<<maximum<<"]}";
}catch(const std::exception&e){std::cout<<"{\"error\":\"ValueError\"}";}catch(...){std::cout<<"{\"error\":\"ValueError\"}";}std::cout<<std::endl;}
