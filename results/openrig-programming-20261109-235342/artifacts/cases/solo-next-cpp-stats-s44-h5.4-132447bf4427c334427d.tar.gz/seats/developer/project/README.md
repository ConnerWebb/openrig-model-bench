# RunningStats

A C++20 library for computing running statistics using stable online algorithms.

## API

```cpp
class RunningStats {
public:
    void add(double x);              // Add a value (rejects NaN/infinity)
    void merge(const RunningStats&); // Merge another stats object
    std::uint64_t count() const;     // Number of values
    double mean() const;             // Mean (throws if empty)
    double variance() const;         // Population variance (throws if empty)
    double minimum() const;          // Minimum value (throws if empty)
    double maximum() const;          // Maximum value (throws if empty)
};
```

## Build

```bash
mkdir build && cd build
cmake .. && make
```

## Tests

Run `run_tests` to verify implementation against public cases and internal tests.
