# JobQueue

A thread-safe job queue implementation using SQLite for persistence and coordination.

## Features

- **Persistent storage**: Jobs survive process restarts
- **Atomic operations**: Claim operations are atomic, preventing duplicate claims
- **Lease-based claiming**: Jobs can be claimed with a lease expiration
- **Retry with max attempts**: Jobs are retried up to a configurable maximum
- **Simple API**: enqueue, claim, complete, fail, and status methods

## Usage

```python
from solution import JobQueue
import time

# Create a queue
queue = JobQueue("jobs.db", max_attempts=3)

# Enqueue a job
queue.enqueue("job1", {"data": "test"})

# Claim a job (returns None if no jobs available)
job = queue.claim("worker1", time.time(), lease=60.0)
if job:
    print(f"Processing job {job['key']} with payload {job['payload']}")

# Complete or fail the job
queue.complete("job1", "worker1")  # or queue.fail("job1", "worker1")

# Check job status
status = queue.status("job1")
print(f"State: {status['state']}, Attempts: {status['attempts']}")
```

## API

### `JobQueue(path, max_attempts=3)`

Create a new job queue.

- `path`: Path to the SQLite database file
- `max_attempts`: Maximum claim attempts before marking as failed (default: 3)

### `enqueue(key, payload) -> bool`

Add a job to the queue.

- Returns `True` if the job was enqueued
- Returns `False` if a job with this key already exists
- Raises `ValueError` if key is empty or payload is None

### `claim(worker, now, lease) -> dict | None`

Claim the oldest available job.

- Returns a dict with `key`, `payload`, and `attempts` if a job was claimed
- Returns `None` if no jobs are available
- Raises `ValueError` if worker is empty, lease <= 0, or now < 0

### `complete(key, worker) -> bool`

Mark a job as completed.

- Returns `True` if the job was completed
- Returns `False` if the job doesn't exist or worker doesn't match
- Raises `ValueError` if key or worker is empty

### `fail(key, worker) -> bool`

Mark a job as failed.

- If attempts < max_attempts, the job is requeued
- If attempts >= max_attempts, the job is marked as failed
- Returns `True` if the job was processed
- Returns `False` if the job doesn't exist or worker doesn't match
- Raises `ValueError` if key or worker is empty

### `status(key) -> dict | None`

Get the status of a job.

- Returns a dict with `state` and `attempts`
- Returns `None` if the job doesn't exist
- Raises `ValueError` if key is empty

## Job States

- `queued`: Job is waiting to be claimed
- `leased`: Job is currently claimed by a worker
- `done`: Job was successfully completed
- `failed`: Job failed after max_attempts

## Testing

Run the tests with:

```bash
python -m unittest test_solution
```
