"""JobQueue: SQLite-based job queue with enqueue, claim, complete, fail, and status methods."""

import json
import sqlite3
from typing import Optional, Dict, Any


class JobQueue:
    """A thread-safe job queue using SQLite for persistence and coordination."""

    def __init__(self, path: str, max_attempts: int = 3):
        """Initialize the job queue.

        Args:
            path: Path to the SQLite database file.
            max_attempts: Maximum number of claim attempts before marking as failed.

        Raises:
            ValueError: If max_attempts is not a positive integer.
        """
        if max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get a database connection with proper settings."""
        conn = sqlite3.connect(self.path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        """Initialize the database schema."""
        conn = self._get_connection()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'queued',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    owner TEXT,
                    lease_until REAL,
                    inserted_at REAL NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_state_owner ON jobs(state, owner)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_state_lease ON jobs(state, lease_until)")
            conn.commit()
        finally:
            conn.close()

    def enqueue(self, key: str, payload: Any) -> bool:
        """Add a job to the queue.

        Args:
            key: Unique job identifier.
            payload: JSON-compatible payload value.

        Returns:
            True if the job was enqueued, False if a job with this key already exists.

        Raises:
            ValueError: If key is empty.
        """
        if not key:
            raise ValueError("key must be non-empty")
        if payload is None:
            raise ValueError("payload must not be None")

        conn = self._get_connection()
        try:
            conn.execute(
                "INSERT INTO jobs (key, payload, state, attempts, inserted_at) VALUES (?, ?, 'queued', 0, ?)",
                (key, json.dumps(payload), __import__("time").time())
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            # Job with this key already exists
            conn.rollback()
            return False
        finally:
            conn.close()

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        """Claim the oldest available job.

        Args:
            worker: Worker identifier claiming the job.
            now: Current timestamp.
            lease: Lease duration in seconds.

        Returns:
            A dict with key, payload, and attempts if a job was claimed, or None.

        Raises:
            ValueError: If worker is empty, lease <= 0, or now is negative.
        """
        if not worker:
            raise ValueError("worker must be non-empty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        if now < 0:
            raise ValueError("now must be non-negative")

        conn = self._get_connection()
        try:
            # Use a transaction with immediate locking
            conn.execute("BEGIN IMMEDIATE")
            
            # Find the oldest job that is queued or has expired lease, with attempts < max_attempts
            cursor = conn.execute(
                """
                SELECT key, payload, attempts FROM jobs
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                  AND attempts < ?
                ORDER BY inserted_at ASC
                LIMIT 1
                """,
                (now, self.max_attempts)
            )
            row = cursor.fetchone()

            if row is None:
                conn.rollback()
                return None

            key = row["key"]
            payload = json.loads(row["payload"])
            attempts = row["attempts"]
            new_attempts = attempts + 1

            # Update the job to leased state
            lease_until = now + lease
            conn.execute(
                """
                UPDATE jobs
                SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
                WHERE key = ?
                """,
                (worker, lease_until, new_attempts, key)
            )
            conn.commit()

            # If this is the final attempt, mark as failed
            if new_attempts >= self.max_attempts:
                conn.execute("UPDATE jobs SET state = 'failed' WHERE key = ?", (key,))
                conn.commit()

            return {"key": key, "payload": payload, "attempts": new_attempts}
        finally:
            conn.close()

    def complete(self, key: str, worker: str) -> bool:
        """Mark a job as completed.

        Args:
            key: Job identifier.
            worker: Worker identifier that completed the job.

        Returns:
            True if the job was completed, False if the job doesn't exist or worker doesn't match.

        Raises:
            ValueError: If key or worker is empty.
        """
        if not key:
            raise ValueError("key must be non-empty")
        if not worker:
            raise ValueError("worker must be non-empty")

        conn = self._get_connection()
        try:
            # Check if job exists and is owned by this worker
            cursor = conn.execute(
                "SELECT state, owner FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()

            if row is None:
                return False

            if row["state"] != "leased" or row["owner"] != worker:
                return False

            conn.execute("UPDATE jobs SET state = 'done' WHERE key = ?", (key,))
            conn.commit()
            return True
        finally:
            conn.close()

    def fail(self, key: str, worker: str) -> bool:
        """Mark a job as failed and potentially requeue it.

        Args:
            key: Job identifier.
            worker: Worker identifier that failed the job.

        Returns:
            True if the job was processed, False if the job doesn't exist or worker doesn't match.

        Raises:
            ValueError: If key or worker is empty.
        """
        if not key:
            raise ValueError("key must be non-empty")
        if not worker:
            raise ValueError("worker must be non-empty")

        conn = self._get_connection()
        try:
            # Check if job exists and is owned by this worker
            cursor = conn.execute(
                "SELECT state, owner, attempts FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()

            if row is None:
                return False

            if row["state"] != "leased" or row["owner"] != worker:
                return False

            attempts = row["attempts"]

            if attempts >= self.max_attempts:
                # Mark as failed permanently
                conn.execute("UPDATE jobs SET state = 'failed' WHERE key = ?", (key,))
            else:
                # Requeue the job
                conn.execute(
                    "UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?",
                    (key,)
                )
            conn.commit()
            return True
        finally:
            conn.close()

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        """Get the status of a job.

        Args:
            key: Job identifier.

        Returns:
            A dict with state and attempts, or None if the job doesn't exist.

        Raises:
            ValueError: If key is empty.
        """
        if not key:
            raise ValueError("key must be non-empty")

        conn = self._get_connection()
        try:
            cursor = conn.execute(
                "SELECT state, attempts FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()

            if row is None:
                return None

            return {"state": row["state"], "attempts": row["attempts"]}
        finally:
            conn.close()
