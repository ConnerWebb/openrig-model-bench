"""Tests for JobQueue."""

import json
import os
import tempfile
import time
import unittest

from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    """Test cases for JobQueue."""

    def setUp(self):
        """Create a temporary database for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test.db")

    def tearDown(self):
        """Clean up temporary files."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_enqueue_new_job(self):
        """Test enqueueing a new job."""
        queue = JobQueue(self.db_path)
        result = queue.enqueue("job1", {"data": "test"})
        self.assertTrue(result)
        status = queue.status("job1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_enqueue_duplicate_key(self):
        """Test enqueueing a job with duplicate key."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        result = queue.enqueue("job1", {"data": "different"})
        self.assertFalse(result)

    def test_enqueue_empty_key_raises(self):
        """Test that empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.enqueue("", {"data": "test"})

    def test_claim_returns_job(self):
        """Test claiming a job returns the job data."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        result = queue.claim("worker1", time.time(), 60.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "job1")
        self.assertEqual(result["payload"], {"data": "test"})
        self.assertEqual(result["attempts"], 1)

    def test_claim_sets_state(self):
        """Test that claiming sets the state to leased."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        status = queue.status("job1")
        self.assertEqual(status["state"], "leased")

    def test_claim_no_jobs_available(self):
        """Test claiming when no jobs are available."""
        queue = JobQueue(self.db_path)
        result = queue.claim("worker1", time.time(), 60.0)
        self.assertIsNone(result)

    def test_claim_empty_worker_raises(self):
        """Test that empty worker raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("", time.time(), 60.0)

    def test_claim_negative_lease_raises(self):
        """Test that negative lease raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("worker1", time.time(), -1.0)

    def test_claim_zero_lease_raises(self):
        """Test that zero lease raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("worker1", time.time(), 0)

    def test_claim_negative_now_raises(self):
        """Test that negative now raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.claim("worker1", -1.0, 60.0)

    def test_complete_job(self):
        """Test completing a job."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        result = queue.complete("job1", "worker1")
        self.assertTrue(result)
        status = queue.status("job1")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        """Test completing with wrong worker."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        result = queue.complete("job1", "worker2")
        self.assertFalse(result)

    def test_complete_empty_key_raises(self):
        """Test that empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.complete("", "worker1")

    def test_complete_empty_worker_raises(self):
        """Test that empty worker raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.complete("job1", "")

    def test_fail_job_requeues(self):
        """Test failing a job requeues it."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        result = queue.fail("job1", "worker1")
        self.assertTrue(result)
        status = queue.status("job1")
        self.assertEqual(status["state"], "queued")

    def test_fail_job_exhausted_attempts(self):
        """Test failing when attempts exhausted marks as failed."""
        queue = JobQueue(self.db_path, max_attempts=2)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        queue.fail("job1", "worker1")
        queue.claim("worker1", time.time(), 60.0)
        result = queue.fail("job1", "worker1")
        self.assertTrue(result)
        status = queue.status("job1")
        self.assertEqual(status["state"], "failed")

    def test_fail_wrong_worker(self):
        """Test failing with wrong worker."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        result = queue.fail("job1", "worker2")
        self.assertFalse(result)

    def test_fail_empty_key_raises(self):
        """Test that empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.fail("", "worker1")

    def test_fail_empty_worker_raises(self):
        """Test that empty worker raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.fail("job1", "")

    def test_status_nonexistent_job(self):
        """Test status of nonexistent job."""
        queue = JobQueue(self.db_path)
        result = queue.status("nonexistent")
        self.assertIsNone(result)

    def test_status_empty_key_raises(self):
        """Test that empty key raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.status("")

    def test_claim_oldest_first(self):
        """Test that claim returns jobs in insertion order."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "first"})
        time.sleep(0.01)
        queue.enqueue("job2", {"data": "second"})
        result1 = queue.claim("worker1", time.time(), 60.0)
        self.assertEqual(result1["key"], "job1")
        result2 = queue.claim("worker2", time.time(), 60.0)
        self.assertEqual(result2["key"], "job2")

    def test_claim_expired_lease(self):
        """Test claiming a job with expired lease."""
        queue = JobQueue(self.db_path)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 1.0)
        time.sleep(0.1)
        result = queue.claim("worker2", time.time() + 2.0, 60.0)
        self.assertEqual(result["key"], "job1")
        self.assertEqual(result["attempts"], 2)

    def test_claim_max_attempts(self):
        """Test that jobs at max attempts are not claimed."""
        queue = JobQueue(self.db_path, max_attempts=2)
        queue.enqueue("job1", {"data": "test"})
        queue.claim("worker1", time.time(), 60.0)
        queue.fail("job1", "worker1")
        queue.claim("worker1", time.time(), 60.0)
        queue.fail("job1", "worker1")
        result = queue.claim("worker2", time.time(), 60.0)
        self.assertIsNone(result)

    def test_invalid_max_attempts_zero(self):
        """Test that zero max_attempts raises ValueError."""
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)

    def test_invalid_max_attempts_negative(self):
        """Test that negative max_attempts raises ValueError."""
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_payload_none_raises(self):
        """Test that None payload raises ValueError."""
        queue = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            queue.enqueue("job1", None)

    def test_claim_payload_complex(self):
        """Test claiming with complex payload."""
        queue = JobQueue(self.db_path)
        complex_payload = {"nested": {"data": [1, 2, 3]}, "bool": True, "null": None}
        queue.enqueue("job1", complex_payload)
        result = queue.claim("worker1", time.time(), 60.0)
        self.assertEqual(result["payload"], complex_payload)

    def test_multiple_queue_instances(self):
        """Test that multiple instances share the database."""
        queue1 = JobQueue(self.db_path)
        queue2 = JobQueue(self.db_path)
        queue1.enqueue("job1", {"data": "test"})
        result = queue2.claim("worker1", time.time(), 60.0)
        self.assertEqual(result["key"], "job1")


if __name__ == "__main__":
    unittest.main()
