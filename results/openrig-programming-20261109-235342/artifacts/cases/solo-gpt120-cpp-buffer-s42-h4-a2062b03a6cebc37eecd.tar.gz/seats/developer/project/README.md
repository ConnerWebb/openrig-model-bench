# Buffer Library

This repository contains a small, self‑contained C++20 `Buffer` class that satisfies the contract described in **TASK.txt**.

## Features
- Holds a contiguous array of `std::uint8_t` bytes.
- Default‑constructible with optional initial size.
- `size()` returns the current number of elements.
- Bounds‑checked `operator[]` (both mutable and const) throwing `std::out_of_range` on invalid access.
- `resize(newSize)` preserves existing data up to the smaller of old/new size and zero‑initialises any newly added bytes.
- Deep‑copy copy‑constructor and copy‑assignment.
- `noexcept` move constructor and move‑assignment; moved‑from objects become empty (size 0, null pointer).
- Safe self‑copy and self‑move.

## Implementation Details
The class manages its memory manually using `new[]`/`delete[]`. Helper functions ensure strong exception safety for copy‑assignment and `resize`. All public methods are `noexcept` where appropriate.

## Building & Testing
The project uses **GoogleTest** for unit tests.
```bash
# Compile
clang++ -std=c++20 -Wall -Wextra -O2 test_buffer.cpp -lgtest -lgtest_main -pthread -o test_buffer

# Run tests
./test_buffer
```
All tests should pass, confirming compliance with the required behaviour.
