#include "solution.hpp"
#include <cassert>
#include <iostream>

void test_default_and_size() {
    Buffer b;
    assert(b.size() == 0);
    Buffer c(5);
    assert(c.size() == 5);
    for (size_t i = 0; i < c.size(); ++i) assert(c[i] == 0);
}

void test_bounds() {
    Buffer b(3);
    b[0] = 1; // no throw
    bool caught = false;
    try { b[3]; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
    const Buffer cb(2);
    caught = false;
    try { cb[2]; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
}

void test_resize() {
    Buffer b;
    b.resize(3);
    assert(b.size() == 3);
    b[0]=10; b[1]=20; b[2]=30;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0]==10 && b[1]==20 && b[2]==30);
    assert(b[3]==0 && b[4]==0);
    b.resize(2);
    assert(b.size() == 2);
    assert(b[0]==10 && b[1]==20);
}

void test_copy() {
    Buffer orig(3);
    orig[0]=5; orig[1]=6; orig[2]=7;
    Buffer copy(orig);
    assert(copy.size() == orig.size());
    for (size_t i=0;i<orig.size();++i) assert(copy[i]==orig[i]);
    copy[0]=99; assert(copy[0]!=orig[0]);
    Buffer assign;
    assign = orig;
    assert(assign.size()==orig.size());
    assign[1]=88; assert(assign[1]!=orig[1]);
}

void test_move() {
    Buffer src(2);
    src[0]=11; src[1]=22;
    Buffer moved(std::move(src));
    assert(moved.size()==2);
    assert(src.size()==0);
    assert(moved[0]==11 && moved[1]==22);
    Buffer dst(1);
    dst = std::move(moved);
    assert(dst.size()==2);
    assert(moved.size()==0);
    assert(dst[0]==11 && dst[1]==22);
}

int main(){
    test_default_and_size();
    test_bounds();
    test_resize();
    test_copy();
    test_move();
    std::cout << "All tests passed\n";
    return 0;
}
