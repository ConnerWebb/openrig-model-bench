#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <utility>

/**
 * Simple resizable byte buffer.
 *
 * - Elements are `std::uint8_t`.
 * - Default constructed with optional size (default 0).
 * - `size()` returns current size.
 * - `operator[]` provides mutable and const access with bounds checking.
 *   Out‑of‑range access throws `std::out_of_range`.
 * - `resize(newSize)` changes the buffer size preserving the existing prefix
 *   and zero‑initialising any newly added bytes.
 * - Copy construction / copy assignment perform deep copies.
 * - Move construction / move assignment are `noexcept`, leaving the moved‑from
 *   object in a valid empty state (size 0, nullptr data).
 * - Self‑copy and self‑move are safe and preserve the original content.
 */
class Buffer {
    std::uint8_t* p_;
    std::size_t n_;

    // Helper to deallocate safely
    void destroy() noexcept {
        delete[] p_;
        p_ = nullptr;
        n_ = 0;
    }

public:
    // Constructors ----------------------------------------------------------
    Buffer(std::size_t n = 0) : p_(nullptr), n_(0) {
        if (n) {
            p_ = new std::uint8_t[n];
            std::fill_n(p_, n, static_cast<std::uint8_t>(0));
        }
        n_ = n;
    }

    // Copy constructor – deep copy
    Buffer(const Buffer& other) : p_(nullptr), n_(0) {
        if (other.n_) {
            p_ = new std::uint8_t[other.n_];
            std::copy(other.p_, other.p_ + other.n_, p_);
        }
        n_ = other.n_;
    }

    // Move constructor – noexcept
    Buffer(Buffer&& other) noexcept : p_(other.p_), n_(other.n_) {
        other.p_ = nullptr;
        other.n_ = 0;
    }

    // Destructor
    ~Buffer() {
        delete[] p_; // safe even if nullptr
    }

    // Assignment operators ---------------------------------------------------
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            // Allocate new memory first to provide strong exception guarantee
            std::uint8_t* newPtr = nullptr;
            if (other.n_) {
                newPtr = new std::uint8_t[other.n_];
                std::copy(other.p_, other.p_ + other.n_, newPtr);
            }
            // Release old memory
            delete[] p_;
            p_ = newPtr;
            n_ = other.n_;
        }
        return *this;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p_; // free current storage
            p_ = other.p_;
            n_ = other.n_;
            other.p_ = nullptr;
            other.n_ = 0;
        }
        return *this;
    }

    // Observers --------------------------------------------------------------
    std::size_t size() const noexcept { return n_; }

    // Element access with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n_) throw std::out_of_range("Buffer index out of range");
        return p_[i];
    }
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n_) throw std::out_of_range("Buffer index out of range");
        return p_[i];
    }

    // Modifiers --------------------------------------------------------------
    void resize(std::size_t newSize) {
        if (newSize == n_) return;
        std::uint8_t* newPtr = nullptr;
        if (newSize) {
            newPtr = new std::uint8_t[newSize];
            // Preserve existing prefix up to the smaller of old/new size
            std::size_t copyLen = std::min(n_, newSize);
            if (copyLen) {
                std::copy(p_, p_ + copyLen, newPtr);
            }
            // Zero‑initialize any newly added bytes
            if (newSize > n_) {
                std::fill(newPtr + n_, newPtr + newSize, static_cast<std::uint8_t>(0));
            }
        }
        delete[] p_;
        p_ = newPtr;
        n_ = newSize;
    }
};
