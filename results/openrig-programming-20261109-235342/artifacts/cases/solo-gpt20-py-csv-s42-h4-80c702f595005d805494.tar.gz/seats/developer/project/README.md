# solo-gpt20-py-csv-s42-h4

This repository implements the `aggregate` function required by the
`solo-gpt20-py-csv-s42-h4` assignment.

## Function

```python
aggregate(path: str) -> dict[str, str]
```

* Reads a UTF‑8 CSV file at *path*.
* Header must be exactly `category,amount`.
* Each non‑blank row must contain exactly two fields.
* Whitespace is stripped from both fields.
* `category` must not be empty.
* `amount` must match the pattern `+?[0-9]{1,12}(\.[0-9]{1,2})?` and be
  non‑negative.
* Aggregates amounts per category using `decimal.Decimal` for exact
  arithmetic.
* Returns a dictionary mapping category to the total amount formatted
  with exactly two decimal places.  Keys are sorted alphabetically.

The implementation streams the file and never loads the entire file into
memory.

## Tests

Run the tests with `pytest`:

```bash
pytest
```

The test suite covers normal operation, blank rows, whitespace handling,
invalid headers, malformed amounts, negative amounts, empty categories, and
key ordering.

## Usage

```python
import solution
print(solution.aggregate("data.csv"))
```

---

This project is self‑contained and uses only the Python standard library.
