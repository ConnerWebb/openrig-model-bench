"""Solution for solo-gpt20-py-csv-s42-h4.

The module exposes a single function:

    aggregate(path: str) -> dict[str, str]

which reads a UTF‑8 encoded CSV file at *path* and returns a mapping from
category to the total amount for that category.  The CSV must have a header
exactly ``category,amount``.  Each subsequent row must contain exactly two
fields.  Leading/trailing whitespace is stripped from both fields.  The
``category`` field must not be empty.  The ``amount`` field must represent a
non‑negative decimal number with an optional leading ``+`` sign, 1‑12 digits
before an optional decimal point, and 1‑2 digits after the decimal point.

The function uses :class:`decimal.Decimal` for exact arithmetic and returns
the totals formatted with exactly two decimal places.  The result dictionary
is sorted by the category key.

The implementation streams the file and never loads the entire file into
memory.
"""

from __future__ import annotations

import csv
from decimal import Decimal, InvalidOperation, getcontext
from pathlib import Path
from typing import Dict

# Set precision high enough for any reasonable sum of up to 12‑digit
# integers with two decimal places.
getcontext().prec = 28

# Regular expression for validating the amount string.
import re
_AMOUNT_RE = re.compile(r"^\+?(?:[0-9]{1,12})(?:\.[0-9]{1,2})?$")


def _validate_amount(amount_str: str) -> Decimal:
    """Validate *amount_str* and return a Decimal.

    Raises ValueError if the string does not match the required format or
    represents a negative number.
    """
    if not _AMOUNT_RE.match(amount_str):
        raise ValueError(f"Invalid amount format: {amount_str!r}")
    try:
        dec = Decimal(amount_str)
    except InvalidOperation as exc:  # pragma: no cover - defensive
        raise ValueError(f"Invalid decimal amount: {amount_str!r}") from exc
    if dec < 0:
        raise ValueError(f"Negative amount not allowed: {amount_str!r}")
    return dec


def aggregate(path: str) -> Dict[str, str]:
    """Aggregate amounts by category from a CSV file.

    Parameters
    ----------
    path:
        Path to a UTF‑8 encoded CSV file.

    Returns
    -------
    dict[str, str]
        Mapping from category to the total amount formatted with two
        decimal places.  The dictionary keys are sorted alphabetically.

    Raises
    ------
    ValueError
        If the file does not conform to the contract.
    """
    totals: Dict[str, Decimal] = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration as exc:  # pragma: no cover - empty file
            raise ValueError("CSV file is empty") from exc
        if header != ["category", "amount"]:
            raise ValueError("Header must be exactly 'category,amount'")
        for lineno, row in enumerate(reader, start=2):
            # Skip completely blank rows
            if not row or all(cell.strip() == "" for cell in row):
                continue
            if len(row) != 2:
                raise ValueError(f"Row {lineno} does not have exactly two fields")
            cat_raw, amt_raw = row
            cat = cat_raw.strip()
            amt = amt_raw.strip()
            if cat == "":
                raise ValueError(f"Row {lineno} has empty category")
            dec = _validate_amount(amt)
            totals[cat] = totals.get(cat, Decimal("0")) + dec
    # Format totals with exactly two decimal places
    formatted: Dict[str, str] = {
        cat: f"{totals[cat]:.2f}" for cat in sorted(totals)
    }
    return formatted


if __name__ == "__main__":  # pragma: no cover - manual usage
    import sys
    if len(sys.argv) != 2:
        sys.exit("Usage: python solution.py <csv-file>")
    print(aggregate(sys.argv[1]))
