import csv, os, tempfile
import solution
import unittest


def write_csv(content: str) -> str:
    tmp = tempfile.NamedTemporaryFile(delete=False, mode="w", encoding="utf-8", newline="")
    tmp.write(content)
    tmp.close()
    return tmp.name


class TestAggregate(unittest.TestCase):
    def test_basic_aggregation(self):
        csv_data = "category,amount\nfood,10.00\nfood,5.5\n" \
                    "transport,3.20\n"
        path = write_csv(csv_data)
        try:
            result = solution.aggregate(path)
            self.assertEqual(result, {"food": "15.50", "transport": "3.20"})
        finally:
            os.unlink(path)

    def test_blank_and_whitespace_rows(self):
        csv_data = "category,amount\n\n  ,  \n" \
                    "  food  ,  1.00  \n"
        path = write_csv(csv_data)
        try:
            result = solution.aggregate(path)
            self.assertEqual(result, {"food": "1.00"})
        finally:
            os.unlink(path)

    def test_invalid_header(self):
        csv_data = "cat,amt\nfoo,1.00\n"
        path = write_csv(csv_data)
        try:
            with self.assertRaises(ValueError):
                solution.aggregate(path)
        finally:
            os.unlink(path)

    def test_invalid_amount_format(self):
        csv_data = "category,amount\nfoo,1.234\n"
        path = write_csv(csv_data)
        try:
            with self.assertRaises(ValueError):
                solution.aggregate(path)
        finally:
            os.unlink(path)

    def test_negative_amount(self):
        csv_data = "category,amount\nfoo,-1.00\n"
        path = write_csv(csv_data)
        try:
            with self.assertRaises(ValueError):
                solution.aggregate(path)
        finally:
            os.unlink(path)

    def test_empty_category(self):
        csv_data = "category,amount\n,1.00\n"
        path = write_csv(csv_data)
        try:
            with self.assertRaises(ValueError):
                solution.aggregate(path)
        finally:
            os.unlink(path)

    def test_ordering(self):
        csv_data = "category,amount\nB,1.00\nA,2.00\n"
        path = write_csv(csv_data)
        try:
            result = solution.aggregate(path)
            self.assertEqual(list(result.keys()), ["A", "B"])
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
