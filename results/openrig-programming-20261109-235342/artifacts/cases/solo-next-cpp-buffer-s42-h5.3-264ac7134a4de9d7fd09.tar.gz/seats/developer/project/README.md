# Buffer Library

A C++20 RAII-based buffer class with deep-copy semantics, move support, and bounds-checked access.

## Features

- `Buffer(size_t n=0)`: Construct buffer of given size, zero-initialized
- `size() const noexcept`: Return current size
- `operator[](size_t)`: Mutable and const bounds-checked access (throws `std::out_of_range`)
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction and assignment
- Noexcept move construction and assignment
- Self-assignment and self-move preserve content
- RAII: no leaks, no double frees, no stale reads

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // 10 zero-initialized bytes
b[0] = 42;              // bounds-checked write
Buffer c = b;           // deep copy
Buffer d = std::move(c); // move (c becomes empty)
b.resize(20);           // preserve first 10 bytes, zero-fill rest
```

## Testing

Run `run_tests` to verify correctness under normal, ASan, UBSan, and TSan modes.
