# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, bounds-checked access, and safe resize functionality.

## Features

- **Deep Copy**: Copy constructor and copy assignment perform deep copies of the buffer contents.
- **Noexcept Move**: Move constructor and move assignment are noexcept and leave the moved-from buffer in a valid, reusable state with size 0.
- **Bounds Checking**: Both mutable and const `operator[]` throw `std::out_of_range` on invalid indices.
- **Safe Resize**: `resize()` preserves existing prefix data and zero-initializes new elements when growing.
- **RAII**: Automatic resource management with proper destructor using `delete[]`.

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of size `n`, zero-initialized.

### Destructor
```cpp
~Buffer();
```
Releases allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy semantics.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Noexcept move semantics. Moved-from buffer has size 0 and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
Bounds-checked element access. Throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes the buffer to `k` elements. Preserves prefix up to `min(old_size, k)`. New elements are zero-initialized when growing.

## Building

Compile with C++20 support:
```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

## Testing

Run the included test suite:
```bash
./test_buffer
```

All tests should pass with "All tests passed!" output.
