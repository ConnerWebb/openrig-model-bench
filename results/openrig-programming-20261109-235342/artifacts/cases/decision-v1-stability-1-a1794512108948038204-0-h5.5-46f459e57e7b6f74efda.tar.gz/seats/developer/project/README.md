# CSV Aggregation Solution

This project implements a CSV aggregation function that reads a CSV file with `category` and `amount` columns, aggregates amounts by category, and returns a dictionary with sorted keys and amounts formatted to exactly two decimal places.

## Features

- Parses CSV files with proper handling of:
  - Quoted fields containing commas
  - Embedded newlines in quoted fields
  - Escaped quotes within quoted fields
  - Unicode category names
  - Whitespace stripping
  - Optional plus signs in amounts
- Validates:
  - Header must be exactly `category,amount`
  - Each record must have exactly two fields
  - Category cannot be empty
  - Amount must be a valid decimal number
- Raises `ValueError` for invalid input
- Returns sorted dictionary with amounts formatted to 2 decimal places

## Usage

```python
from solution import aggregate

result = aggregate('data.csv')
# Returns: {'category1': '10.50', 'category2': '20.00', ...}
```

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```
