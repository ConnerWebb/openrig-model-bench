"""
CSV aggregator: reads UTF-8 CSV, validates header, accumulates amounts by category.
"""
import csv
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with totals formatted to 2 decimal places.
    Raises ValueError on any malformed input.
    """
    # Amount regex: optional +, 1-12 digits, optional decimal point with 1-2 digits
    # Must be nonnegative, finite, no exponent
    amount_pattern = re.compile(r'^\+?[0-9]{1,12}(\.[0-9]{1,2})?$')
    
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid header")
        
        for row in reader:
            # Skip completely blank records (empty list or all empty strings)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse and accumulate using Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check for non-finite (though regex should prevent this)
            if not amount.is_finite():
                raise ValueError("Amount must be finite")
            
            # Check nonnegative
            if amount < 0:
                raise ValueError("Amount must be nonnegative")
            
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly 2 decimal places, sorted by category
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
