"""
Unit tests for solution.py aggregate function.
"""
import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category accumulation."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nfood,5.25\nrent,100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '15.75', 'rent': '100.00'})
    
    def test_header_validation(self):
        """Test that invalid header raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,header\nx,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_format(self):
        """Test that invalid amount format raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_quoted_fields_with_commas(self):
        """Test handling of quoted fields containing commas."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_embedded_newlines(self):
        """Test handling of embedded newlines in quoted fields."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"two\nlines",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '50.00'})
    
    def test_escaped_quotes(self):
        """Test handling of escaped quotes in quoted fields."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.00\n\n\nfood,5.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '15.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_optional_plus_sign(self):
        """Test that optional + sign is accepted."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_wrong_field_count(self):
        """Test that records with wrong field count raise ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_sorted_output(self):
        """Test that output is sorted by category."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nzebra,10.00\napple,20.00\nbanana,30.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['apple', 'banana', 'zebra'])
    
    def test_two_decimal_places(self):
        """Test that output has exactly two decimal places."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00'})
    
    def test_empty_file(self):
        """Test that empty file raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unicode_categories(self):
        """Test handling of unicode category names."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Build CSV with ASCII comma (chr(44)) as field separator
            # Category is Japanese characters, amount is numeric
            lines = ['category' + chr(44) + 'amount', '日本' + chr(44) + '100.00']
            p.write_text(chr(10).join(lines) + chr(10), encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00'})


if __name__ == '__main__':
    unittest.main()
