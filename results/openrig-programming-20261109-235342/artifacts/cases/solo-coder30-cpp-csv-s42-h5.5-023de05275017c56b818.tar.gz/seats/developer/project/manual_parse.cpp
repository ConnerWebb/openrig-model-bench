#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>

int main() {
    // This is what the input looks like - a string with literal \n characters
    std::string input = "\"category,amount\n\\\"x\\\"\\\"quote\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\",-22826\n\\\"x\\\"\\\"quote\\\",-4598\n\\\"x\\\"\\\"quote\\\",-26830\n日本,39039\n\\\"a,b\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\",-26030\n\\\"two\nlines\\\",54977\n\\\"x\\\"\\\"quote\\\",-5124\nrent,12112\n\\\"two\nlines\\\",28447\nfood,57027\nfood,2732\n\"";
    
    std::cout << "Input length: " << input.length() << std::endl;
    
    // Let's manually parse this
    // First, find the first \n to get the header
    size_t pos = input.find('\n');
    if (pos == std::string::npos) {
        std::cout << "No newline found" << std::endl;
        return 1;
    }
    
    std::string header = input.substr(0, pos);
    std::cout << "Header: [" << header << "]" << std::endl;
    
    // Check if header is correct
    if (header != "\"category,amount") {
        std::cout << "Header doesn't match" << std::endl;
        return 1;
    }
    
    // Now process the rest of the input
    size_t start = pos + 1;  // Skip the \n
    int line_count = 0;
    
    while (start < input.length()) {
        // Find next \n
        pos = input.find('\n', start);
        if (pos == std::string::npos) {
            // Last line
            std::string line = input.substr(start);
            std::cout << "Last line: [" << line << "]" << std::endl;
            break;
        } else {
            std::string line = input.substr(start, pos - start);
            std::cout << "Line " << ++line_count << ": [" << line << "]" << std::endl;
            start = pos + 1;
        }
    }
    
    return 0;
}