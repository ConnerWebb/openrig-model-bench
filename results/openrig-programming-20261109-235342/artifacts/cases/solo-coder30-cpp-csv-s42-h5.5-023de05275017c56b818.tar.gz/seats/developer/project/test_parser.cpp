#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <iomanip>

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    std::string line;
    
    // Read header
    if (!std::getline(in, line)) {
        throw std::invalid_argument("Missing header");
    }
    
    // Parse header line - should be "category,amount"
    if (line != "category,amount") {
        throw std::invalid_argument("Wrong header");
    }
    
    // Process records - we need to read the rest of the input properly
    std::string content;
    std::getline(in, content, '\0');  // Read all remaining content
    
    // Now parse content line by line, but we need to handle the fact that
    // newlines are represented as literal 'n' characters in the input
    // This is a bit tricky - let's just parse by splitting on \n
    std::string::size_type pos = 0;
    std::string::size_type prev = 0;
    
    // First, let's see what we're dealing with
    std::cout << "Content length: " << content.length() << std::endl;
    std::cout << "Content (first 200 chars): [" << content.substr(0, 200) << "]" << std::endl;
    
    // Find all literal \n sequences and split on them
    while ((pos = content.find("\\n", prev)) != std::string::npos) {
        std::string record = content.substr(prev, pos - prev);
        std::cout << "Record: [" << record << "]" << std::endl;
        prev = pos + 2; // Skip past \n
    }
    
    // Handle the last record
    if (prev < content.length()) {
        std::string record = content.substr(prev);
        std::cout << "Last record: [" << record << "]" << std::endl;
    }
    
    return result;
}

int main() {
    try {
        std::string text; 
        std::cin >> std::quoted(text);
        std::istringstream in(text);
        auto out = aggregate(in);
        std::cout << "Success!" << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
    return 0;
}