#include <iostream>
#include <sstream>
#include <cassert>
#include "solution.hpp"

void test_basic_aggregation() {
    std::istringstream input("category,amount\nfood,100\nrent,200\nfood,50\n");
    auto result = aggregate(input);
    assert(result.size() == 2);
    assert(result["food"] == 150);
    assert(result["rent"] == 200);
    std::cout << "Basic aggregation test passed\n";
}

void test_quoted_fields() {
    std::istringstream input("category,amount\n\"a,b\",100\n\"x\"\"quote\",200\n");
    auto result = aggregate(input);
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["x\"quote"] == 200);
    std::cout << "Quoted fields test passed\n";
}

void test_multiline_fields() {
    std::istringstream input("category,amount\n\"line1\nline2\",100\n");
    auto result = aggregate(input);
    assert(result.size() == 1);
    assert(result["line1\nline2"] == 100);
    std::cout << "Multiline fields test passed\n";
}

void test_empty_lines() {
    std::istringstream input("category,amount\n\nfood,100\n\nrent,200\n\n");
    auto result = aggregate(input);
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "Empty lines test passed\n";
}

void test_strip_whitespace() {
    std::istringstream input("category,amount\n  food  ,  100  \n  rent\t\r,  200  \n");
    auto result = aggregate(input);
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "Whitespace stripping test passed\n";
}

void test_error_cases() {
    // Test wrong header
    try {
        std::istringstream input("wrong,amount\nx,1\n");
        aggregate(input);
        assert(false); // Should not reach here
    } catch (const std::invalid_argument&) {
        // Expected
    }
    
    // Test wrong field count
    try {
        std::istringstream input("category,amount,extra\nx,1,2\n");
        aggregate(input);
        assert(false); // Should not reach here
    } catch (const std::invalid_argument&) {
        // Expected
    }
    
    // Test empty category
    try {
        std::istringstream input("category,amount\n,1\n");
        aggregate(input);
        assert(false); // Should not reach here
    } catch (const std::invalid_argument&) {
        // Expected
    }
    
    // Test invalid amount
    try {
        std::istringstream input("category,amount\nx,NaN\n");
        aggregate(input);
        assert(false); // Should not reach here
    } catch (const std::invalid_argument&) {
        // Expected
    }
    
    // Test malformed quoting - this should be valid according to the test cases
    try {
        std::istringstream input("category,amount\n\"x,1\n");
        aggregate(input);
        assert(false); // Should not reach here
    } catch (const std::invalid_argument&) {
        // Expected - this is a malformed quote
    }
    
    std::cout << "Error cases test passed\n";
}

int main() {
    test_basic_aggregation();
    test_quoted_fields();
    test_multiline_fields();
    test_empty_lines();
    test_strip_whitespace();
    test_error_cases();
    std::cout << "All tests passed!\n";
    return 0;
}