#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

int main() {
    std::string text; 
    std::cin >> std::quoted(text);
    
    std::cout << "Raw text length: " << text.length() << std::endl;
    std::cout << "First 100 chars: [" << text.substr(0, 100) << "]" << std::endl;
    
    // Let's manually parse the first few lines to understand the structure
    std::istringstream in(text);
    std::string line;
    
    // Read first line (header)
    if (std::getline(in, line)) {
        std::cout << "First line: [" << line << "]" << std::endl;
        std::cout << "First line length: " << line.length() << std::endl;
    }
    
    // Read second line (first data)
    if (std::getline(in, line)) {
        std::cout << "Second line: [" << line << "]" << std::endl;
        std::cout << "Second line length: " << line.length() << std::endl;
    }
    
    return 0;
}