#include <iostream>
#include <sstream>
#include "solution.hpp"

int main() {
    std::istringstream input("category,amount\nfood,100\nrent,200\nfood,50\n");
    try {
        auto result = aggregate(input);
        std::cout << "Result size: " << result.size() << std::endl;
        for (const auto& pair : result) {
            std::cout << "Key: \"" << pair.first << "\", Value: " << pair.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
    }
    return 0;
}