#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file>" << std::endl;
        return 1;
    }
    
    std::ifstream file(argv[1]);
    if (!file.is_open()) {
        std::cerr << "Failed to open file" << std::endl;
        return 1;
    }
    
    // Read entire file content
    std::ostringstream content;
    content << file.rdbuf();
    std::string text = content.str();
    
    std::cout << "File content:" << std::endl;
    std::cout << text << std::endl;
    
    // Now parse it like the driver would
    std::istringstream in(text);
    std::string line;
    
    // Read header
    if (std::getline(in, line)) {
        std::cout << "Header line: [" << line << "]" << std::endl;
    }
    
    // Read first few data lines
    for (int i = 0; i < 5; i++) {
        if (std::getline(in, line)) {
            std::cout << "Data line " << i << ": [" << line << "]" << std::endl;
        }
    }
    
    return 0;
}