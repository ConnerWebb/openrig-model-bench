#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <iomanip>

// Simple test to understand the input format
int main() {
    // Test with a simple case
    std::string input = "\"category,amount\nfood,100\nrent,200\nfood,50\n\"";
    std::istringstream in(input);
    
    // Read the entire input as a quoted string (like the driver does)
    std::string text;
    std::cin >> std::quoted(text);
    std::cout << "Raw input: " << text << std::endl;
    
    // Now parse it
    std::istringstream stream(text);
    std::string line;
    
    // Read header
    std::getline(stream, line);
    std::cout << "Header: " << line << std::endl;
    
    // Read first data line
    std::getline(stream, line);
    std::cout << "First data line: " << line << std::endl;
    
    // Read second data line
    std::getline(stream, line);
    std::cout << "Second data line: " << line << std::endl;
    
    // Read third data line
    std::getline(stream, line);
    std::cout << "Third data line: " << line << std::endl;
    
    return 0;
}