# CSV Aggregator Solution

This is a C++ implementation of a CSV aggregator that parses category-amount pairs and returns the sum of amounts for each category.

## Features

- Parses CSV data with header "category,amount"
- Handles quoted fields that may contain commas, newlines, and escaped quotes
- Strips whitespace from fields
- Validates input and throws appropriate exceptions for malformed data
- Supports 64-bit signed integers for amounts
- Returns results sorted by category name
- Handles empty lines and ignores them
- Properly handles overflow detection

## Implementation Details

The solution implements a header-only `aggregate` function in `solution.hpp` that takes an `std::istream` and returns `std::map<std::string, std::int64_t>`.

### Parsing Logic

1. **Header Validation**: Ensures the header is exactly "category,amount"
2. **Field Parsing**: Handles both quoted and unquoted fields
3. **Quoted Fields**: Supports escaped double quotes within quoted fields
4. **Amount Parsing**: Uses `std::stoll` with overflow checking for 64-bit signed integers
5. **Error Handling**: Throws `std::invalid_argument` for malformed data

### Error Conditions

The implementation throws `std::invalid_argument` for:
- Wrong header
- Wrong field count
- Empty fields
- Invalid amount format (non-integer, decimals, exponents)
- Malformed quoting
- Integer overflow

## Usage

```cpp
#include "solution.hpp"
#include <iostream>
#include <sstream>

int main() {
    std::istringstream input("category,amount\nfood,100\nrent,200\n");
    auto result = aggregate(input);
    // Process result...
    return 0;
}
```

## Testing

The solution has been tested with the provided test cases including:
- Normal CSV data with various categories
- Quoted fields with commas and newlines
- Empty lines and whitespace handling
- Error conditions (malformed quoting, wrong headers, invalid amounts)