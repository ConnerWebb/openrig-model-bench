#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>

// Simple test to debug what's happening
int main() {
    // Read from stdin to simulate the exact input
    std::ostringstream buffer;
    buffer << std::cin.rdbuf();
    std::string full_input = buffer.str();
    
    std::cout << "Full input length: " << full_input.length() << std::endl;
    std::cout << "First 200 chars: [" << full_input.substr(0, 200) << "]" << std::endl;
    
    // Parse line by line
    std::istringstream input_stream(full_input);
    std::string line;
    
    // Read header
    if (std::getline(input_stream, line)) {
        std::cout << "Header line: [" << line << "]" << std::endl;
    }
    
    // Read first data line
    if (std::getline(input_stream, line)) {
        std::cout << "First data line: [" << line << "]" << std::endl;
        
        // Parse CSV line - find the first comma that's not inside quotes
        size_t comma_pos = 0;
        bool in_quotes = false;
        for (size_t i = 0; i < line.length(); ++i) {
            if (line[i] == '"') {
                in_quotes = !in_quotes;
            } else if (line[i] == ',' && !in_quotes) {
                comma_pos = i;
                break;
            }
        }
        
        std::cout << "Comma position: " << comma_pos << std::endl;
        
        if (comma_pos != 0) {
            std::string category = line.substr(0, comma_pos);
            std::string amount_str = line.substr(comma_pos + 1);
            std::cout << "Category: [" << category << "]" << std::endl;
            std::cout << "Amount: [" << amount_str << "]" << std::endl;
            
            // Try parsing amount
            try {
                std::int64_t amount = std::stoll(amount_str);
                std::cout << "Parsed amount: " << amount << std::endl;
            } catch (const std::exception& e) {
                std::cout << "Error parsing amount: " << e.what() << std::endl;
            }
        }
    }
    
    return 0;
}