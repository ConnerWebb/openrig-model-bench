#include <iostream>
#include <istream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <sstream>

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    std::string line;
    
    // Read header line
    if (!std::getline(in, line)) {
        throw std::invalid_argument("Missing header");
    }
    
    // Parse header line - should be "category,amount"
    if (line != "category,amount") {
        throw std::invalid_argument("Wrong header");
    }
    
    // Process records
    while (std::getline(in, line)) {
        // Skip empty lines
        if (line.empty()) {
            continue;
        }
        
        // Find the first comma that's not inside quotes
        size_t comma_pos = 0;
        bool in_quotes = false;
        for (size_t i = 0; i < line.length(); ++i) {
            if (line[i] == '"') {
                in_quotes = !in_quotes;
            } else if (line[i] == ',' && !in_quotes) {
                comma_pos = i;
                break;
            }
        }
        
        if (comma_pos == 0) {
            throw std::invalid_argument("Wrong field count");
        }
        
        std::string category = line.substr(0, comma_pos);
        std::string amount_str = line.substr(comma_pos + 1);
        
        // Handle quoted categories - remove surrounding quotes and unescape
        if (category.length() >= 2 && category[0] == '"' && category[category.length()-1] == '"') {
            category = category.substr(1, category.length() - 2);
            // Unescape double quotes (replace "" with ")
            size_t pos = 0;
            while ((pos = category.find("\"\"", pos)) != std::string::npos) {
                category.replace(pos, 2, "\"");
                pos++;
            }
        }
        
        // Check for empty category
        if (category.empty()) {
            throw std::invalid_argument("Empty field");
        }
        
        // Parse amount - use try-catch to handle invalid format
        std::int64_t amount;
        try {
            amount = std::stoll(amount_str);
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount format");
        }
        
        // Add to result
        result[category] += amount;
    }
    
    return result;
}