#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

int main() {
    // This is exactly what the driver does:
    // std::string text;std::cin>>std::quoted(text);std::istringstream in(text);auto out=aggregate(in);
    
    // Read the input as a quoted string
    std::string text;
    std::cin >> std::quoted(text);
    
    std::cout << "Raw text length: " << text.length() << std::endl;
    std::cout << "Raw text (as C string): [" << text.c_str() << "]" << std::endl;
    
    // Now parse it line by line
    std::istringstream in(text);
    std::string line;
    
    // Read header
    if (std::getline(in, line)) {
        std::cout << "Header line: [" << line << "]" << std::endl;
    }
    
    // Read first data line
    if (std::getline(in, line)) {
        std::cout << "First data line: [" << line << "]" << std::endl;
        
        // Parse CSV line - find the first comma that's not inside quotes
        size_t comma_pos = 0;
        bool in_quotes = false;
        for (size_t i = 0; i < line.length(); ++i) {
            if (line[i] == '"') {
                in_quotes = !in_quotes;
            } else if (line[i] == ',' && !in_quotes) {
                comma_pos = i;
                break;
            }
        }
        
        std::cout << "Comma position: " << comma_pos << std::endl;
        
        if (comma_pos != 0) {
            std::string category = line.substr(0, comma_pos);
            std::string amount_str = line.substr(comma_pos + 1);
            std::cout << "Category: [" << category << "]" << std::endl;
            std::cout << "Amount: [" << amount_str << "]" << std::endl;
            
            // Try parsing amount
            try {
                long long amount = std::stoll(amount_str);
                std::cout << "Parsed amount: " << amount << std::endl;
            } catch (const std::exception& e) {
                std::cout << "Error parsing amount: " << e.what() << std::endl;
            }
        }
    }
    
    return 0;
}