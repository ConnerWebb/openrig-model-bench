#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

int main() {
    std::string text; 
    std::cin >> std::quoted(text);
    
    std::cout << "Raw text length: " << text.length() << std::endl;
    std::cout << "Raw text (C string): [" << text.c_str() << "]" << std::endl;
    
    // Replace \n with actual newlines for display
    std::string display_text = text;
    size_t pos = 0;
    while ((pos = display_text.find("\\n", pos)) != std::string::npos) {
        display_text.replace(pos, 2, "\n");
        pos++;
    }
    
    std::cout << "Display text:" << std::endl << display_text << std::endl;
    
    // Now parse line by line
    std::istringstream in(text);
    std::string line;
    
    // Read header line
    if (std::getline(in, line)) {
        std::cout << "First line: [" << line << "]" << std::endl;
        // Replace \n with actual newlines for display
        std::string display_line = line;
        size_t pos = 0;
        while ((pos = display_line.find("\\n", pos)) != std::string::npos) {
            display_line.replace(pos, 2, "\n");
            pos++;
        }
        std::cout << "First line (display):" << std::endl << display_line << std::endl;
    }
    
    return 0;
}