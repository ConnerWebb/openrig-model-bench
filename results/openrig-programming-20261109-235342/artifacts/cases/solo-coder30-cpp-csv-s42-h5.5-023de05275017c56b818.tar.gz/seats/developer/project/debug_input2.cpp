#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <vector>

int main() {
    // This is what the driver does:
    // std::cin>>std::quoted(text);
    std::string text;
    std::cin >> std::quoted(text);
    
    std::cout << "Raw input (as C string): " << std::endl;
    std::cout << text << std::endl;
    
    // Let's manually parse it like the driver would
    std::istringstream in(text);
    std::string line;
    int line_num = 0;
    
    // Read the first line (header)
    if (std::getline(in, line)) {
        line_num++;
        std::cout << "Line " << line_num << ": [" << line << "]" << std::endl;
        std::cout << "Header check: " << (line == "category,amount" ? "PASS" : "FAIL") << std::endl;
    }
    
    // Read the rest of the lines
    while (std::getline(in, line)) {
        line_num++;
        std::cout << "Line " << line_num << ": [" << line << "]" << std::endl;
        if (line.empty()) continue;
        
        // Find first comma
        size_t comma_pos = line.find(',');
        if (comma_pos != std::string::npos) {
            std::string category = line.substr(0, comma_pos);
            std::string amount_str = line.substr(comma_pos + 1);
            std::cout << "  Category: [" << category << "], Amount: [" << amount_str << "]" << std::endl;
        }
    }
    
    return 0;
}