#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <iomanip>

// Simple CSV parser that handles quoted fields properly
std::vector<std::string> parse_csv_line(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool in_quotes = false;
    
    for (size_t i = 0; i < line.length(); ++i) {
        char c = line[i];
        if (c == '"') {
            if (in_quotes && i + 1 < line.length() && line[i + 1] == '"') {
                // Escaped quote
                field += '"';
                i++; // Skip next quote
            } else {
                // Toggle quote state
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            // End of field
            fields.push_back(field);
            field.clear();
        } else {
            // Regular character
            field += c;
        }
    }
    
    // Add last field
    fields.push_back(field);
    return fields;
}

int main() {
    // Read the entire input
    std::string input;
    std::getline(std::cin, input);
    
    std::cout << "Input length: " << input.length() << std::endl;
    std::cout << "Input (first 200 chars): [" << input.substr(0, 200) << "]" << std::endl;
    
    // Parse line by line
    std::istringstream input_stream(input);
    std::string line;
    
    int line_num = 0;
    while (std::getline(input_stream, line)) {
        std::cout << "Line " << line_num << ": [" << line << "]" << std::endl;
        
        // Parse this line as CSV
        auto fields = parse_csv_line(line);
        std::cout << "  Fields: ";
        for (size_t i = 0; i < fields.size(); ++i) {
            std::cout << "[" << fields[i] << "] ";
        }
        std::cout << std::endl;
        
        line_num++;
        if (line_num > 10) break;  // Just show first few lines
    }
    
    return 0;
}