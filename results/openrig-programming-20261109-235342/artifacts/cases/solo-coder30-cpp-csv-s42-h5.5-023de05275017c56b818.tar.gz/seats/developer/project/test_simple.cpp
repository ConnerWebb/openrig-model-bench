#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>

int main() {
    // Test with the exact input from case 0
    std::string input = "\"category,amount\n\\\"x\\\"\\\"quote\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\",-22826\n\\\"x\\\"\\\"quote\\\",-4598\n\\\"x\\\"\\\"quote\\\",-26830\n日本,39039\n\\\"a,b\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\",-26030\n\\\"two\nlines\\\",54977\n\\\"x\\\"\\\"quote\\\",-5124\nrent,12112\n\\\"two\nlines\\\",28447\nfood,57027\nfood,2732\n\"";
    
    std::istringstream in(input);
    
    // Read header
    std::string header;
    if (!std::getline(in, header)) {
        std::cout << "Failed to read header" << std::endl;
        return 1;
    }
    std::cout << "Header: [" << header << "]" << std::endl;
    
    if (header != "category,amount") {
        std::cout << "Wrong header" << std::endl;
        return 1;
    }
    
    // Read lines
    std::string line;
    int line_num = 0;
    while (std::getline(in, line)) {
        line_num++;
        std::cout << "Line " << line_num << ": [" << line << "]" << std::endl;
        if (line.empty()) {
            continue;
        }
        
        size_t comma_pos = line.find(',');
        if (comma_pos == std::string::npos) {
            std::cout << "No comma found" << std::endl;
            return 1;
        }
        
        std::string category = line.substr(0, comma_pos);
        std::string amount_str = line.substr(comma_pos + 1);
        
        std::cout << "Category: [" << category << "], Amount: [" << amount_str << "]" << std::endl;
        
        try {
            std::int64_t amount = std::stoll(amount_str);
            std::cout << "Parsed amount: " << amount << std::endl;
        } catch (const std::exception& e) {
            std::cout << "Exception parsing amount: " << e.what() << std::endl;
            return 1;
        }
    }
    
    return 0;
}