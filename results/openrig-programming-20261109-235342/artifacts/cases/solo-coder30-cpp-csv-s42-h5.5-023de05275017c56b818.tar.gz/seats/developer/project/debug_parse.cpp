#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>
#include <stdexcept>

int main() {
    // Read the entire input
    std::ostringstream buffer;
    buffer << std::cin.rdbuf();
    std::string full_input = buffer.str();
    
    std::cout << "Full input length: " << full_input.length() << std::endl;
    std::cout << "Full input (first 200 chars): " << full_input.substr(0, 200) << std::endl;
    
    // Parse line by line
    std::istringstream input_stream(full_input);
    std::string line;
    
    // Read header
    if (std::getline(input_stream, line)) {
        std::cout << "Header line: [" << line << "]" << std::endl;
    }
    
    // Read first few data lines
    for (int i = 0; i < 5; i++) {
        if (std::getline(input_stream, line)) {
            std::cout << "Data line " << (i+1) << ": [" << line << "]" << std::endl;
            
            // Try to parse
            size_t comma_pos = line.find(',');
            if (comma_pos != std::string::npos) {
                std::string category = line.substr(0, comma_pos);
                std::string amount_str = line.substr(comma_pos + 1);
                std::cout << "  Category: [" << category << "]" << std::endl;
                std::cout << "  Amount: [" << amount_str << "]" << std::endl;
                
                try {
                    std::int64_t amount = std::stoll(amount_str);
                    std::cout << "  Parsed amount: " << amount << std::endl;
                } catch (const std::exception& e) {
                    std::cout << "  ERROR parsing amount: " << e.what() << std::endl;
                }
            } else {
                std::cout << "  No comma found!" << std::endl;
            }
        }
    }
    
    return 0;
}