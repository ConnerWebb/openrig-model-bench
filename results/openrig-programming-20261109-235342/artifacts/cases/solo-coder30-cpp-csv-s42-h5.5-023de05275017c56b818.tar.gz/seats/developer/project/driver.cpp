#include <iostream>
#include <istream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <sstream>
#include <iomanip>
#include <vector>

// Simple CSV parser that handles quoted fields properly
std::vector<std::string> parse_csv_line(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool in_quotes = false;
    
    for (size_t i = 0; i < line.length(); ++i) {
        char c = line[i];
        if (c == '"') {
            if (in_quotes && i + 1 < line.length() && line[i + 1] == '"') {
                // Escaped quote
                field += '"';
                i++; // Skip next quote
            } else {
                // Toggle quote state
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            // End of field
            fields.push_back(field);
            field.clear();
        } else {
            // Regular character
            field += c;
        }
    }
    
    // Add last field
    fields.push_back(field);
    return fields;
}

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read the entire input as a string
    std::ostringstream buffer;
    buffer << in.rdbuf();
    std::string full_input = buffer.str();
    
    // Parse line by line
    std::istringstream input_stream(full_input);
    std::string line;
    
    // Read header
    if (!std::getline(input_stream, line)) {
        throw std::invalid_argument("Missing header");
    }
    
    // Parse header line
    auto header_fields = parse_csv_line(line);
    if (header_fields.size() != 2 || header_fields[0] != "category" || header_fields[1] != "amount") {
        throw std::invalid_argument("Wrong header");
    }
    
    // Process records
    while (std::getline(input_stream, line)) {
        // Skip empty lines
        if (line.empty()) {
            continue;
        }
        
        // Parse CSV line
        auto fields = parse_csv_line(line);
        if (fields.size() != 2) {
            throw std::invalid_argument("Wrong field count");
        }
        
        std::string category = fields[0];
        std::string amount_str = fields[1];
        
        // Check for empty category
        if (category.empty()) {
            throw std::invalid_argument("Empty field");
        }
        
        // Parse amount - use try-catch to handle invalid format
        std::int64_t amount;
        try {
            amount = std::stoll(amount_str);
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount format");
        }
        
        // Add to result
        result[category] += amount;
    }
    
    return result;
}

int main() {
    try {
        auto result = aggregate(std::cin);
        std::cout << "{";
        bool first = true;
        for (const auto& pair : result) {
            if (!first) std::cout << ",";
            std::cout << "\"" << pair.first << "\":" << pair.second;
            first = false;
        }
        std::cout << "}" << std::endl;
    } catch (const std::exception& e) {
        std::cout << "{\"error\":\"ValueError\"}" << std::endl;
    }
    return 0;
}