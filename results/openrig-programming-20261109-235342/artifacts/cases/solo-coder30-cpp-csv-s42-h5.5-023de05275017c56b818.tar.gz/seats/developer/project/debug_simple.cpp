#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>

int main() {
    std::string input = "\"category,amount\n\\\"x\\\"\\\"quote\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\",-22826\n\\\"x\\\"\\\"quote\\\",-4598\n\\\"x\\\"\\\"quote\\\",-26830\n日本,39039\n\\\"a,b\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\",-26030\n\\\"two\nlines\\\",54977\n\\\"x\\\"\\\"quote\\\",-5124\nrent,12112\n\\\"two\nlines\\\",28447\nfood,57027\nfood,2732\n\"";
    
    std::cout << "Input: [" << input << "]" << std::endl;
    
    std::istringstream input_stream(input);
    std::string line;
    
    // Read header
    std::getline(input_stream, line);
    std::cout << "Header line: [" << line << "]" << std::endl;
    
    // Read first data line
    std::getline(input_stream, line);
    std::cout << "First data line: [" << line << "]" << std::endl;
    
    // Parse it manually
    size_t comma_pos = line.find(',');
    if (comma_pos != std::string::npos) {
        std::string category = line.substr(0, comma_pos);
        std::string amount_str = line.substr(comma_pos + 1);
        std::cout << "Category: [" << category << "]" << std::endl;
        std::cout << "Amount: [" << amount_str << "]" << std::endl;
        
        // Check if category is quoted
        if (category.length() >= 2 && category[0] == '"' && category[category.length()-1] == '"') {
            std::cout << "Category is quoted" << std::endl;
            std::string unquoted = category.substr(1, category.length() - 2);
            std::cout << "Unquoted: [" << unquoted << "]" << std::endl;
            
            // Unescape double quotes
            size_t pos = 0;
            while ((pos = unquoted.find("\"\"", pos)) != std::string::npos) {
                unquoted.replace(pos, 2, "\"");
                pos++;
            }
            std::cout << "After unescaping: [" << unquoted << "]" << std::endl;
        }
    }
    
    return 0;
}