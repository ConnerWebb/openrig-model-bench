#include <iostream>
#include <istream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <sstream>

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read the header line
    std::string header_line;
    if (!std::getline(in, header_line)) {
        throw std::invalid_argument("Missing header");
    }
    
    // The header should be exactly "\"category,amount"
    if (header_line != "\"category,amount") {
        throw std::invalid_argument("Wrong header");
    }
    
    // Process records
    std::string line;
    while (std::getline(in, line)) {
        // Skip empty lines
        if (line.empty()) {
            continue;
        }
        
        // Find the first comma to separate category and amount
        size_t comma_pos = line.find(',');
        if (comma_pos == std::string::npos) {
            throw std::invalid_argument("Wrong field count");
        }
        
        std::string category = line.substr(0, comma_pos);
        std::string amount_str = line.substr(comma_pos + 1);
        
        // Handle quoted categories - remove surrounding quotes
        if (category.length() >= 2 && category[0] == '"' && category[category.length()-1] == '"') {
            category = category.substr(1, category.length() - 2);
            // Unescape double quotes (replace "" with ")
            size_t pos = 0;
            while ((pos = category.find("\"\"", pos)) != std::string::npos) {
                category.replace(pos, 2, "\"");
                pos++;
            }
        }
        
        // Check for empty category
        if (category.empty()) {
            throw std::invalid_argument("Empty field");
        }
        
        // Parse amount - use try-catch to handle invalid format
        std::int64_t amount;
        try {
            amount = std::stoll(amount_str);
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount format");
        }
        
        // Add to result
        result[category] += amount;
    }
    
    return result;
}

int main() {
    try {
        auto result = aggregate(std::cin);
        std::cout << "Success!" << std::endl;
        for (const auto& pair : result) {
            std::cout << pair.first << ": " << pair.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
    }
    return 0;
}