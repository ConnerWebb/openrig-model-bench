#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>
#include <stdexcept>

// Simple parsing function to debug
std::map<std::string, std::int64_t> simple_parse(const std::string& input) {
    std::map<std::string, std::int64_t> result;
    
    std::istringstream in(input);
    std::string header_line;
    if (!std::getline(in, header_line)) {
        throw std::invalid_argument("Missing header");
    }
    
    if (header_line != "category,amount") {
        throw std::invalid_argument("Wrong header");
    }
    
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty()) {
            continue;
        }
        
        std::cout << "Processing line: [" << line << "]" << std::endl;
        
        size_t comma_pos = line.find(',');
        if (comma_pos == std::string::npos) {
            throw std::invalid_argument("Wrong field count");
        }
        
        std::string category = line.substr(0, comma_pos);
        std::string amount_str = line.substr(comma_pos + 1);
        
        std::cout << "Category: [" << category << "], Amount: [" << amount_str << "]" << std::endl;
        
        // Check if amount_str is valid
        try {
            std::int64_t amount = std::stoll(amount_str);
            std::cout << "Parsed amount: " << amount << std::endl;
            result[category] += amount;
        } catch (const std::exception& e) {
            std::cout << "Exception parsing amount: " << e.what() << std::endl;
            throw;
        }
    }
    
    return result;
}

int main() {
    // Test with first case input
    std::string input = "\"category,amount\n\\\"x\\\"\\\"quote\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\",-22826\n\\\"x\\\"\\\"quote\\\",-4598\n\\\"x\\\"\\\"quote\\\",-26830\n日本,39039\n\\\"a,b\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\",-26030\n\\\"two\nlines\\\",54977\n\\\"x\\\"\\\"quote\\\",-5124\nrent,12112\n\\\"two\nlines\\\",28447\nfood,57027\nfood,2732\n\"";
    
    try {
        auto result = simple_parse(input);
        std::cout << "Success! Result size: " << result.size() << std::endl;
        for (const auto& pair : result) {
            std::cout << "Key: \"" << pair.first << "\", Value: " << pair.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
    }
    
    return 0;
}