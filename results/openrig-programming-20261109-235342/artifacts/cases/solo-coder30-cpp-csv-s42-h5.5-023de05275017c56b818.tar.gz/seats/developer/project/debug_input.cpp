#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cstdint>

int main() {
    // This is the exact input from case 0
    std::string input = "\"category,amount\n\\\"x\\\"\\\"quote\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\",-22826\n\\\"x\\\"\\\"quote\\\",-4598\n\\\"x\\\"\\\"quote\\\",-26830\n日本,39039\n\\\"a,b\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\",-26030\n\\\"two\nlines\\\",54977\n\\\"x\\\"\\\"quote\\\",-5124\nrent,12112\n\\\"two\nlines\\\",28447\nfood,57027\nfood,2732\n\"";
    
    std::cout << "Input length: " << input.length() << std::endl;
    std::cout << "Input (first 200 chars): " << input.substr(0, 200) << std::endl;
    
    // Parse line by line
    std::istringstream input_stream(input);
    std::string line;
    
    // Read header
    if (std::getline(input_stream, line)) {
        std::cout << "Header line: [" << line << "]" << std::endl;
        std::cout << "Header length: " << line.length() << std::endl;
    }
    
    // Read first few data lines
    for (int i = 0; i < 10; i++) {
        if (std::getline(input_stream, line)) {
            std::cout << "Data line " << (i+1) << ": [" << line << "]" << std::endl;
            std::cout << "Data line length: " << line.length() << std::endl;
            
            // Find comma
            size_t comma_pos = line.find(',');
            if (comma_pos != std::string::npos) {
                std::string category = line.substr(0, comma_pos);
                std::string amount_str = line.substr(comma_pos + 1);
                std::cout << "  Category: [" << category << "]" << std::endl;
                std::cout << "  Amount: [" << amount_str << "]" << std::endl;
                
                // Try to parse amount
                try {
                    std::int64_t amount = std::stoll(amount_str);
                    std::cout << "  Parsed amount: " << amount << std::endl;
                } catch (const std::exception& e) {
                    std::cout << "  ERROR parsing amount: " << e.what() << std::endl;
                }
            } else {
                std::cout << "  No comma found!" << std::endl;
            }
        }
    }
    
    return 0;
}