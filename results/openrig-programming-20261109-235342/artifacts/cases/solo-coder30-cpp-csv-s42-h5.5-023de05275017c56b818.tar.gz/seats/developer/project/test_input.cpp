#include <iostream>
#include <fstream>
#include <string>

int main() {
    // Let's create a test file with the exact input from case 0
    std::ofstream test_file("test_input.txt");
    test_file << "\"category,amount\n\\\"x\\\"\\\"quote\\\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\\\"x\\\"\\\"quote\\\",-22826\n\\\"x\\\"\\\"quote\\\",-4598\n\\\"x\\\"\\\"quote\\\",-26830\n日本,39039\n\\\"a,b\\\",29914\nrent,15786\n日本,-8138\nfood,15570\n\\\"x\\\"\\\"quote\\\",-26030\n\\\"two\nlines\\\",54977\n\\\"x\\\"\\\"quote\\\",-5124\nrent,12112\n\\\"two\nlines\\\",28447\nfood,57027\nfood,2732\n\"";
    test_file.close();
    
    // Now read it back
    std::ifstream in("test_input.txt");
    std::string line;
    int count = 0;
    while (std::getline(in, line)) {
        count++;
        std::cout << "Line " << count << ": [" << line << "]" << std::endl;
    }
    
    return 0;
}