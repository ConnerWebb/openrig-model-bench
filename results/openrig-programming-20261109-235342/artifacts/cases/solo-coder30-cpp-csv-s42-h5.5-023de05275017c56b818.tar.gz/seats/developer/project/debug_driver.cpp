#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
#include <map>
#include <cstdint>
#include <stdexcept>

// This is the exact function signature from the problem
std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    std::string line;
    
    // Read header
    if (!std::getline(in, line)) {
        throw std::invalid_argument("Missing header");
    }
    
    std::cout << "Header line: [" << line << "]" << std::endl;
    
    // Parse header line - should be "category,amount"
    if (line != "category,amount") {
        throw std::invalid_argument("Wrong header");
    }
    
    // Process records
    int record_count = 0;
    while (std::getline(in, line)) {
        record_count++;
        std::cout << "Record " << record_count << " line: [" << line << "]" << std::endl;
        
        // Skip empty lines
        if (line.empty()) {
            continue;
        }
        
        // Parse CSV line - find the first comma that's not inside quotes
        size_t comma_pos = 0;
        bool in_quotes = false;
        for (size_t i = 0; i < line.length(); ++i) {
            if (line[i] == '"') {
                in_quotes = !in_quotes;
            } else if (line[i] == ',' && !in_quotes) {
                comma_pos = i;
                break;
            }
        }
        
        std::cout << "Comma position: " << comma_pos << std::endl;
        
        if (comma_pos == 0) {
            throw std::invalid_argument("Wrong field count");
        }
        
        std::string category = line.substr(0, comma_pos);
        std::string amount_str = line.substr(comma_pos + 1);
        
        std::cout << "Category: [" << category << "]" << std::endl;
        std::cout << "Amount: [" << amount_str << "]" << std::endl;
        
        // Handle quoted categories - remove surrounding quotes and unescape
        if (category.length() >= 2 && category[0] == '"' && category[category.length()-1] == '"') {
            category = category.substr(1, category.length() - 2);
            // Unescape double quotes (replace "" with ")
            size_t pos = 0;
            while ((pos = category.find("\"\"", pos)) != std::string::npos) {
                category.replace(pos, 2, "\"");
                pos++;
            }
        }
        
        std::cout << "Unescaped category: [" << category << "]" << std::endl;
        
        // Check for empty category
        if (category.empty()) {
            throw std::invalid_argument("Empty field");
        }
        
        // Parse amount - use try-catch to handle invalid format
        std::int64_t amount;
        try {
            amount = std::stoll(amount_str);
            std::cout << "Parsed amount: " << amount << std::endl;
        } catch (const std::exception& e) {
            std::cout << "Error parsing amount: " << e.what() << std::endl;
            throw std::invalid_argument("Invalid amount format");
        }
        
        // Add to result
        result[category] += amount;
        std::cout << "Added to result. Current total for " << category << ": " << result[category] << std::endl;
    }
    
    return result;
}

int main() {
    try {
        std::string text; 
        std::cin >> std::quoted(text);
        std::cout << "Raw text: [" << text << "]" << std::endl;
        std::istringstream in(text);
        auto out = aggregate(in);
        std::cout << "Success!" << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
    return 0;
}