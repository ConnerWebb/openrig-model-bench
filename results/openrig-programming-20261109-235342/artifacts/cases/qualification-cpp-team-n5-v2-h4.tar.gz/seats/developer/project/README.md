# CSV Parser Module

This module provides a CSV parser with aggregation functionality.

## Function: `aggregate`

```cpp
std::map<std::string, std::int64_t> aggregate(std::istream& in)
```

Parses CSV input from the given stream and returns a map of category totals.

### CSV Format

- Header must be exactly `category,amount`
- Each row must have exactly two fields
- `category`: non-empty string (supports quoted fields with commas, newlines, and escaped quotes)
- `amount`: signed 64-bit integer (optional `+` or `-` prefix, no decimals/exponents)

### Features

- **Quoted fields**: Fields can be quoted with double quotes to include commas, newlines, or leading/trailing spaces
- **Escaped quotes**: Double quotes within quoted fields are escaped as `""`
- **Aggregation**: Values with the same category are summed
- **Sorted output**: The returned map has keys in sorted order

### Error Handling

Throws `std::invalid_argument` for:
- Wrong header format
- Wrong field count per row
- Empty category or amount
- Invalid number format (including exponents, decimals, NaN)
- Overflow during parsing or aggregation

## Usage Example

```cpp
#include "parser.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::istringstream input("category,amount\nfood,100\nrent,200\nfood,50\n");
    auto result = aggregate(input);
    
    for (const auto& [category, total] : result) {
        std::cout << category << ": " << total << "\n";
    }
    // Output:
    // food: 150
    // rent: 200
}
```
