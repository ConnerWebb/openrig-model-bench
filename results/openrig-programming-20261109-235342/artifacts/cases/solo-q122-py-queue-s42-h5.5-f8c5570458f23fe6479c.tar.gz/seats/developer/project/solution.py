import sqlite3
import json
import time

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT DEFAULT 'queued',
                attempts INTEGER DEFAULT 0,
                owner TEXT,
                lease_until REAL,
                inserted_at REAL DEFAULT (julianday('now'))
            )
        ''')
        conn.commit()
        conn.close()

    def _get_conn(self):
        conn = sqlite3.connect(self.path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def enqueue(self, key, payload):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        conn = self._get_conn()
        cursor = conn.cursor()
        # First unique key wins - check if key exists
        cursor.execute("SELECT key FROM jobs WHERE key = ?", (key,))
        if cursor.fetchone() is not None:
            conn.close()
            return False
        try:
            cursor.execute('''
                INSERT INTO jobs (key, payload, state, attempts, owner, lease_until)
                VALUES (?, ?, 'queued', 0, NULL, NULL)
            ''', (key, json.dumps(payload)))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            conn.close()
            return False
        finally:
            conn.close()

    def claim(self, worker, now, lease):
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")
        
        conn = self._get_conn()
        cursor = conn.cursor()
        
        # First, check for any jobs that have exceeded max_attempts and mark them as failed
        # This handles the case where a job was claimed at max_attempts and lease expired
        cursor.execute('''
            UPDATE jobs SET state = 'failed'
            WHERE state = 'leased' AND attempts >= ? AND lease_until <= ?
        ''', (self.max_attempts, now))
        conn.commit()
        
        # Use a subquery to atomically select and update the oldest eligible job
        # This ensures only one process can claim each job
        cursor.execute('''
            UPDATE jobs
            SET state = 'leased', owner = ?, lease_until = ?, attempts = attempts + 1
            WHERE key = (
                SELECT key FROM jobs
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                AND attempts < ?
                ORDER BY inserted_at ASC
                LIMIT 1
            )
            RETURNING key, payload, attempts
        ''', (worker, now + lease, now, self.max_attempts))
        
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return None
        
        key, payload_json, attempts = row
        
        # Check if this job has exceeded max_attempts after increment
        if attempts > self.max_attempts:
            # Mark as failed (this shouldn't happen due to the WHERE clause, but just in case)
            cursor.execute('''
                UPDATE jobs SET state = 'failed', owner = ?, lease_until = ?
                WHERE key = ?
            ''', (worker, now, key))
            conn.commit()
            conn.close()
            return None
        
        conn.commit()
        
        result = {
            "key": key,
            "payload": json.loads(payload_json),
            "attempts": attempts
        }
        conn.close()
        return result

    def complete(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = self._get_conn()
        cursor = conn.cursor()
        
        # Check if job exists and is leased to this worker
        cursor.execute('''
            SELECT state, owner FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return False
        
        state, owner = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # Mark as done
        cursor.execute('''
            UPDATE jobs SET state = 'done' WHERE key = ?
        ''', (key,))
        conn.commit()
        conn.close()
        return True

    def fail(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = self._get_conn()
        cursor = conn.cursor()
        
        # Check if job exists and is leased to this worker
        cursor.execute('''
            SELECT state, owner, attempts FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return False
        
        state, owner, attempts = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # Check if attempts exhausted
        if attempts >= self.max_attempts:
            # Mark as failed
            cursor.execute('''
                UPDATE jobs SET state = 'failed' WHERE key = ?
            ''', (key,))
        else:
            # Re-queue
            cursor.execute('''
                UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL
                WHERE key = ?
            ''', (key,))
        
        conn.commit()
        conn.close()
        return True

    def status(self, key):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        
        conn = self._get_conn()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT state, attempts FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        conn.close()
        
        if row is None:
            return None
        
        state, attempts = row
        return {"state": state, "attempts": attempts}
