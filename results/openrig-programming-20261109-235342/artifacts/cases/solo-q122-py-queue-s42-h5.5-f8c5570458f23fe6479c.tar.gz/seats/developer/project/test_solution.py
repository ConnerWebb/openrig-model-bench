import unittest
import tempfile
import os
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')

    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_enqueue_first_wins(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("key1", {"data": 1}))
        self.assertFalse(q.enqueue("key1", {"data": 2}))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_claim_basic(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        result = q.claim("worker1", 100.0, 5.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": 1})
        self.assertEqual(result["attempts"], 1)

    def test_claim_expired_lease(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        # Claim with lease until 50
        q.claim("worker1", 0.0, 50.0)
        # Try to claim at time 100 (lease expired)
        result = q.claim("worker2", 100.0, 5.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["attempts"], 2)

    def test_complete_success(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0.0, 5.0)
        self.assertTrue(q.complete("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0.0, 5.0)
        self.assertFalse(q.complete("key1", "wrong_worker"))

    def test_fail_requeue(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0.0, 5.0)
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 1)

    def test_fail_exhausted(self):
        q = JobQueue(self.db_path, max_attempts=2)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0.0, 5.0)  # attempts=1
        q.fail("key1", "worker1")  # back to queued
        q.claim("worker1", 0.0, 5.0)  # attempts=2
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "failed")

    def test_claim_no_available_jobs(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0.0, 5.0)
        result = q.claim("worker2", 0.0, 5.0)
        self.assertIsNone(result)

    def test_claim_no_available_jobs_expired(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0.0, 5.0)
        # Lease not expired yet
        result = q.claim("worker2", 3.0, 5.0)
        self.assertIsNone(result)

    def test_status_nonexistent(self):
        q = JobQueue(self.db_path)
        self.assertIsNone(q.status("nonexistent"))

    def test_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_invalid_key(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue("", {"data": 1})

    def test_invalid_worker(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim("", 0.0, 5.0)

    def test_invalid_lease(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim("worker", 0.0, 0)
        with self.assertRaises(ValueError):
            q.claim("worker", 0.0, -1)

    def test_oldest_first(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.enqueue("key2", {"data": 2})
        result = q.claim("worker1", 0.0, 5.0)
        self.assertEqual(result["key"], "key1")

    def test_claim_max_attempts_exceeded(self):
        q = JobQueue(self.db_path, max_attempts=1)
        q.enqueue("key1", {"data": 1})
        result = q.claim("worker1", 0.0, 5.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["attempts"], 1)
        # Lease hasn't expired yet, so can't claim
        result2 = q.claim("worker2", 0.0, 5.0)
        self.assertIsNone(result2)
        # Job is still leased
        status = q.status("key1")
        self.assertEqual(status["state"], "leased")
        # After lease expires, next claim should mark as failed
        result3 = q.claim("worker2", 10.0, 5.0)  # lease expired at 5.0
        self.assertIsNone(result3)
        status = q.status("key1")
        self.assertEqual(status["state"], "failed")

if __name__ == '__main__':
    unittest.main()
