# JobQueue Implementation

A SQLite-based job queue implementation with support for claiming, completing, and failing jobs.

## Features

- **Unique key enforcement**: First enqueue for a key wins
- **Atomic claiming**: Claims the oldest available job (queued or expired lease)
- **Lease management**: Jobs can be leased with a timeout
- **Retry logic**: Failed jobs re-queue until max_attempts is exhausted
- **Concurrent safety**: Multiple instances/processes can share the same database

## API

### JobQueue(path, max_attempts=3)

Initialize a job queue with the given SQLite database path and maximum retry attempts.

### Methods

- `enqueue(key, payload) -> bool`: Add a job. Returns True if first unique key, False otherwise.
- `claim(worker, now, lease) -> dict | None`: Claim oldest available job. Returns `{key, payload, attempts}` or None.
- `complete(key, worker) -> bool`: Mark job as done. Requires matching leased owner.
- `fail(key, worker) -> bool`: Fail job. Re-queues unless attempts exhausted (then marks as failed).
- `status(key) -> dict | None`: Get `{state, attempts}` for a job, or None if not found.

## State Transitions

- `queued` → `leased` (on claim)
- `leased` → `done` (on complete)
- `leased` → `queued` (on fail, if attempts remain)
- `leased` → `failed` (on fail, if attempts exhausted)
- `leased` → `queued` (when lease expires, available for re-claim)

## Validation

- `key`: non-empty string
- `worker`: non-empty string
- `lease`: positive number
- `max_attempts`: positive integer

Invalid arguments raise `ValueError`.
