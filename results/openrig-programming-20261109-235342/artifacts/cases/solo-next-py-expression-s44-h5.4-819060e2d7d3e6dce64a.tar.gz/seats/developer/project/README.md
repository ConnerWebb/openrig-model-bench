# Expression Evaluator

This module provides an expression evaluator that parses and evaluates arithmetic expressions with support for:
- Addition (`+`)
- Subtraction (`-`)
- Multiplication (`*`)
- Integer division (`//`)
- Parentheses for grouping
- Unary plus and minus

## Usage

```python
from solution import evaluate

result = evaluate("(-18 + 30) * 3 // (58)")  # Returns 0
```

## Constraints

- Maximum expression length: 4096 characters
- Maximum number length: 50 digits
- Maximum nesting depth: 100 levels
- Maximum value: 10^100

## Error Handling

The evaluator raises `ValueError` for:
- Empty expressions
- Input too long
- Numbers too long
- Leading zeros in numbers
- Invalid characters
- Missing closing parentheses
- Division by zero
- Values out of range
- Expression too deep
