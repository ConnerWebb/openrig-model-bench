import re
from typing import List, Tuple, Union

class ExpressionEvaluator:
    MAX_VALUE = 10**100
    MAX_DIGITS = 50
    MAX_DEPTH = 100
    MAX_LENGTH = 4096

    def evaluate(self, text: str) -> int:
        if not isinstance(text, str):
            raise ValueError("Input must be a string")
        if len(text) > self.MAX_LENGTH:
            raise ValueError("Input too long")
        if not text.strip():
            raise ValueError("Empty expression")

        tokens = self._tokenize(text)
        ast, depth = self._parse(tokens)
        if depth > self.MAX_DEPTH:
            raise ValueError("Expression too deep")
        return self._evaluate_ast(ast)

    def _tokenize(self, text: str) -> List[Tuple[str, str]]:
        tokens = []
        i = 0
        while i < len(text):
            c = text[i]
            if c.isspace():
                i += 1
                continue
            elif c in '+-*/()':
                tokens.append(('OP', c))
                i += 1
            elif c.isdigit():
                j = i
                while j < len(text) and text[j].isdigit():
                    j += 1
                num_str = text[i:j]
                if len(num_str) > self.MAX_DIGITS:
                    raise ValueError("Number too long")
                if len(num_str) > 1 and num_str[0] == '0':
                    raise ValueError("Leading zero in number")
                tokens.append(('NUM', num_str))
                i = j
            else:
                raise ValueError(f"Invalid character: {c}")
        return tokens

    def _parse(self, tokens: List[Tuple[str, str]]) -> Tuple[Union[int, Tuple], int]:
        self.tokens = tokens
        self.pos = 0
        return self._parse_expression(0)

    def _parse_expression(self, depth: int) -> Tuple[Union[int, Tuple], int]:
        return self._parse_additive(depth)

    def _parse_additive(self, depth: int) -> Tuple[Union[int, Tuple], int]:
        left, depth = self._parse_multiplicative(depth)
        while self._peek('OP') and self._current_op() in ('+', '-'):
            op = self._current_op()
            self._advance()
            right, depth = self._parse_multiplicative(depth)
            left = (op, left, right)
        return left, depth

    def _parse_multiplicative(self, depth: int) -> Tuple[Union[int, Tuple], int]:
        left, depth = self._parse_unary(depth)
        while True:
            if self._peek('OP') and self._current_op() == '/':
                # Check for //
                if self.pos + 1 < len(self.tokens) and self.tokens[self.pos + 1][1] == '/':
                    self._advance()  # skip first /
                    self._advance()  # skip second /
                    op = '//'
                else:
                    op = self._current_op()
                    self._advance()
                right, depth = self._parse_unary(depth)
                left = (op, left, right)
            elif self._peek('OP') and self._current_op() == '*':
                op = self._current_op()
                self._advance()
                right, depth = self._parse_unary(depth)
                left = (op, left, right)
            else:
                break
        return left, depth

    def _parse_unary(self, depth: int) -> Tuple[Union[int, Tuple], int]:
        if self._peek('OP') and self._current_op() in ('+', '-'):
            op = self._current_op()
            self._advance()
            operand, depth = self._parse_unary(depth)
            return (op, operand), depth
        return self._parse_primary(depth)

    def _parse_primary(self, depth: int) -> Tuple[Union[int, Tuple], int]:
        if self._peek('NUM'):
            val = int(self._current_token()[1])
            self._advance()
            return val, depth
        elif self._peek('OP') and self._current_op() == '(':
            self._advance()
            expr, depth = self._parse_expression(depth + 1)
            if not self._peek('OP') or self._current_op() != ')':
                raise ValueError(f"Missing closing parenthesis, current token: {self._current_token()}, pos: {self.pos}")
            self._advance()
            return expr, depth
        else:
            raise ValueError(f"Syntax error, current token: {self._current_token()}, pos: {self.pos}")

    def _evaluate_ast(self, node: Union[int, Tuple]) -> int:
        if isinstance(node, int):
            if abs(node) > self.MAX_VALUE:
                raise ValueError("Value out of range")
            return node

        op = node[0]
        if op in ('+', '-'):
            left = self._evaluate_ast(node[1])
            if len(node) == 3:
                right = self._evaluate_ast(node[2])
                if op == '+':
                    result = left + right
                else:
                    result = left - right
            else:
                if op == '+':
                    result = left
                else:
                    result = -left
        elif op in ('*', '//'):
            left = self._evaluate_ast(node[1])
            right = self._evaluate_ast(node[2])
            if op == '*':
                result = left * right
            else:
                if right == 0:
                    raise ValueError("Division by zero")
                result = left // right
        else:
            raise ValueError("Unknown operator")

        if abs(result) > self.MAX_VALUE:
            raise ValueError("Value out of range")
        return result

    def _peek(self, token_type: str) -> bool:
        return self.pos < len(self.tokens) and self.tokens[self.pos][0] == token_type

    def _current_token(self) -> Tuple[str, str]:
        if self.pos >= len(self.tokens):
            raise ValueError("Unexpected end of expression")
        return self.tokens[self.pos]

    def _current_op(self) -> str:
        return self.tokens[self.pos][1]

    def _advance(self) -> None:
        self.pos += 1


def evaluate(text: str) -> int:
    return ExpressionEvaluator().evaluate(text)
