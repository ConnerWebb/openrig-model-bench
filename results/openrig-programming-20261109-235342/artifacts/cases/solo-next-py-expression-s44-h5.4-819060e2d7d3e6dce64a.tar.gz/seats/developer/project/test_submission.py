import unittest
from solution import evaluate, ExpressionEvaluator


class TestExpressionEvaluator(unittest.TestCase):

    def test_basic_addition(self):
        self.assertEqual(evaluate("1 + 2"), 3)

    def test_basic_subtraction(self):
        self.assertEqual(evaluate("5 - 3"), 2)

    def test_basic_multiplication(self):
        self.assertEqual(evaluate("4 * 3"), 12)

    def test_basic_division(self):
        self.assertEqual(evaluate("10 // 3"), 3)

    def test_negative_numbers(self):
        self.assertEqual(evaluate("-5 + 3"), -2)

    def test_parentheses(self):
        self.assertEqual(evaluate("(1 + 2) * 3"), 9)

    def test_complex_expression(self):
        self.assertEqual(evaluate("(-18 + 30) * 3 // (58)"), 0)

    def test_unary_minus(self):
        self.assertEqual(evaluate("-1"), -1)

    def test_unary_plus(self):
        self.assertEqual(evaluate("+1"), 1)

    def test_nested_parentheses(self):
        self.assertEqual(evaluate("((1 + 2) * 3)"), 9)

    def test_left_associativity(self):
        # 10 - 5 - 2 = 3 (left to right)
        self.assertEqual(evaluate("10 - 5 - 2"), 3)

    def test_operator_precedence(self):
        # 2 + 3 * 4 = 14 (multiplication first)
        self.assertEqual(evaluate("2 + 3 * 4"), 14)

    def test_division_precedence(self):
        # 12 // 2 * 3 = 18 (left to right)
        self.assertEqual(evaluate("12 // 2 * 3"), 18)

    def test_large_numbers(self):
        self.assertEqual(evaluate("1000000 * 1000000"), 1000000000000)

    def test_negative_result(self):
        self.assertEqual(evaluate("5 - 10"), -5)

    def test_deeply_nested(self):
        # 50 levels should work
        expr = "(" * 50 + "1" + ")" * 50
        self.assertEqual(evaluate(expr), 1)

    def test_empty_expression(self):
        with self.assertRaises(ValueError):
            evaluate("")

    def test_division_by_zero(self):
        with self.assertRaises(ValueError):
            evaluate("1 // 0")

    def test_too_deep(self):
        # 120 levels should fail
        expr = "(" * 120 + "1" + ")" * 120
        with self.assertRaises(ValueError):
            evaluate(expr)

    def test_leading_zero(self):
        with self.assertRaises(ValueError):
            evaluate("01")

    def test_too_long_number(self):
        with self.assertRaises(ValueError):
            evaluate("1" * 51)

    def test_too_long_expression(self):
        with self.assertRaises(ValueError):
            evaluate("1 + " * 5000)

    def test_invalid_character(self):
        with self.assertRaises(ValueError):
            evaluate("1 @ 2")

    def test_missing_closing_paren(self):
        with self.assertRaises(ValueError):
            evaluate("(1 + 2")

    def test_very_deep_expression(self):
        # 100 levels should work
        expr = "(" * 100 + "1" + ")" * 100
        self.assertEqual(evaluate(expr), 1)


if __name__ == '__main__':
    unittest.main()
