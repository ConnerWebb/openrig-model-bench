# aggregate

Implementation of `aggregate(path: str) -> dict[str, str]` that reads a UTF-8 CSV file with header `category,amount`, accumulates amounts per category using exact decimal arithmetic, and returns category totals formatted with exactly two decimal places.

## Usage

```python
from solution import aggregate

result = aggregate("data.csv")
# result: {"category1": "123.45", "category2": "678.90"}
```

## Input rules

- Header must be exactly `category,amount`
- Blank lines are ignored
- Each non-blank record must have exactly two fields
- Category must not be empty (whitespace stripped)
- Amount format: optional `+`, 1–12 digits, optional decimal point followed by 1–2 digits
- No exponents, NaN, or infinity allowed
- CSV quoting (commas, embedded newlines, escaped quotes) is supported

## Output

- Keys are sorted alphabetically
- Values are strings with exactly two decimal places
