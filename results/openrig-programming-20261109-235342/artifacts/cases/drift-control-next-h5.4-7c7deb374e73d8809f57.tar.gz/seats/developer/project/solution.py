import csv
import re
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    totals = {}
    amount_pattern = re.compile(r'^\+?(?:\d{1,12}(?:\.\d{1,2})?|\d{1,12})$')

    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("Empty file")
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")

        for row in reader:
            if row is None:
                continue
            if len(row) == 0:
                continue
            if len(row) == 1 and row[0].strip() == '':
                continue
            if len(row) != 2:
                raise ValueError("Invalid row field count")

            category = row[0].strip()
            amount_str = row[1].strip()

            if not category:
                raise ValueError("Empty category")

            if not amount_pattern.match(amount_str):
                raise ValueError("Invalid amount format")

            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError("Invalid amount")

            if amount.is_nan() or amount.is_infinite():
                raise ValueError("Invalid amount")

            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount

    result = {}
    for cat in sorted(totals.keys()):
        result[cat] = format(totals[cat], '.2f')

    return result
