import unittest
import tempfile
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):

    def test_basic(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.50\nrent,200.25\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50", "rent": "200.25"})

    def test_sum(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nfood,100.50\nfood,99.50\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "200.00"})

    def test_empty_category(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n,100.50\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_wrong_header(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("wrong,amount\nx,1\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_extra_field(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,1,2\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_nan(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,NaN\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_unclosed_quote(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n\"x,1\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_quoted_comma(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"a,b",599.14\n')
            result = aggregate(p)
            self.assertEqual(result, {"a,b": "599.14"})

    def test_embedded_newline(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"two\nlines",849.77\n')
            result = aggregate(p)
            self.assertEqual(result, {"two\nlines": "849.77"})

    def test_quoted_quote(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"x""quote",812.68\n')
            result = aggregate(p)
            self.assertEqual(result, {"x\"quote": "812.68"})

    def test_blank_line(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n\nfood,100.50\n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50"})

    def test_whitespace(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n  food  ,  100.50  \n")
            result = aggregate(p)
            self.assertEqual(result, {"food": "100.50"})

    def test_positive_sign(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,+100.50\n")
            result = aggregate(p)
            self.assertEqual(result, {"x": "100.50"})

    def test_integer_amount(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,123\n")
            result = aggregate(p)
            self.assertEqual(result, {"x": "123.00"})

    def test_one_decimal(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,123.4\n")
            result = aggregate(p)
            self.assertEqual(result, {"x": "123.40"})

    def test_two_decimals(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,123.45\n")
            result = aggregate(p)
            self.assertEqual(result, {"x": "123.45"})

    def test_twelve_digits(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,123456789012\n")
            result = aggregate(p)
            self.assertEqual(result, {"x": "123456789012.00"})

    def test_exponent_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,1e5\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_thirteen_digits_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,1234567890123\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_three_decimals_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\nx,123.456\n")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_empty_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("")
            with self.assertRaises(ValueError):
                aggregate(p)

    def test_header_only(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n")
            result = aggregate(p)
            self.assertEqual(result, {})

    def test_unicode(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write("category,amount\n日本,690.39\n")
            result = aggregate(p)
            self.assertEqual(result, {"日本": "690.39"})

    def test_public_case_00(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'input.csv')
            with open(p, 'w', encoding='utf-8') as f:
                f.write('category,amount\n"x""quote",812.68\nfood,347.25\nrent,991.77\nrent,345.17\nfood,261.47\n"x""quote",71.74\n"x""quote",254.02\n"x""quote",31.70\n日本,690.39\n"a,b",599.14\nrent,457.86\n日本,218.62\nfood,455.70\n"x""quote",39.70\n"two\nlines",849.77\n"x""quote",248.76\nrent,421.12\n"two\nlines",584.47\nfood,870.27\nfood,327.32\n')
            result = aggregate(p)
            expected = {
                "a,b": "599.14",
                "food": "2262.01",
                "rent": "2215.92",
                "two\nlines": "1434.24",
                "x\"quote": "1458.60",
                "日本": "909.01"
            }
            self.assertEqual(result, expected)


if __name__ == '__main__':
    unittest.main()
