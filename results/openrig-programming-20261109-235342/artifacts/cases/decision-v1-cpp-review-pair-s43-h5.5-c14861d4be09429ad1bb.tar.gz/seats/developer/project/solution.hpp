#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <istream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <cctype>

namespace {

std::string trim_outer(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

class CSVParser {
public:
    CSVParser(std::istream& in) : stream_(in) {}

    std::map<std::string, std::int64_t> parse() {
        std::map<std::string, std::int64_t> result;

        // Read and validate header
        std::string header = read_physical_line();
        if (header.empty()) {
            throw std::invalid_argument("Empty input");
        }
        std::vector<std::string> fields = parse_csv_line(header);
        if (fields.size() != 2 || trim_outer(fields[0]) != "category" || trim_outer(fields[1]) != "amount") {
            throw std::invalid_argument("Invalid header");
        }

        // Process data rows
        while (true) {
            std::string line = read_physical_line();
            if (line.empty() && stream_.eof()) break;
            
            std::vector<std::string> row = parse_csv_line(line);
            if (row.empty()) continue; // Empty physical record

            if (row.size() != 2) {
                throw std::invalid_argument("Wrong field count");
            }

            std::string category = trim_outer(row[0]);
            std::string amount_str = trim_outer(row[1]);

            if (category.empty()) {
                throw std::invalid_argument("Empty category");
            }
            if (amount_str.empty()) {
                throw std::invalid_argument("Empty amount");
            }

            std::int64_t amount = parse_int64(amount_str);

            // Check for overflow in accumulation
            auto it = result.find(category);
            if (it != result.end()) {
                std::int64_t current = it->second;
                if ((amount > 0 && current > std::numeric_limits<std::int64_t>::max() - amount) ||
                    (amount < 0 && current < std::numeric_limits<std::int64_t>::min() - amount)) {
                    throw std::invalid_argument("Accumulation overflow");
                }
                it->second += amount;
            } else {
                result[category] = amount;
            }
        }

        return result;
    }

private:
    std::istream& stream_;

    // Read a physical line (up to newline)
    std::string read_physical_line() {
        std::string line;
        if (!std::getline(stream_, line)) {
            return "";
        }
        return line;
    }

    // Parse a CSV line, handling multi-line quoted fields
    std::vector<std::string> parse_csv_line(std::string line) {
        std::vector<std::string> fields;
        std::string field;
        bool in_quotes = false;
        size_t i = 0;

        while (true) {
            while (i <= line.size()) {
                if (i == line.size()) {
                    if (in_quotes) {
                        // Need to read more lines
                        std::string next_line = read_physical_line();
                        if (next_line.empty() && stream_.eof()) {
                            throw std::invalid_argument("Unclosed quote");
                        }
                        line = next_line;
                        i = 0;
                        field += '\n';  // Preserve the newline in the field value
                        break;
                    } else {
                        fields.push_back(field);
                        return fields;
                    }
                }

                char c = line[i];

                if (in_quotes) {
                    if (c == '"') {
                        if (i + 1 < line.size() && line[i + 1] == '"') {
                            // Escaped quote
                            field += '"';
                            i += 2;
                        } else {
                            // Closing quote
                            in_quotes = false;
                            ++i;
                        }
                    } else {
                        field += c;
                        ++i;
                    }
                } else {
                    if (c == '"') {
                        if (!field.empty()) {
                            throw std::invalid_argument("Quote in middle of field");
                        }
                        in_quotes = true;
                        ++i;
                    } else if (c == ',') {
                        fields.push_back(field);
                        field.clear();
                        ++i;
                    } else {
                        field += c;
                        ++i;
                    }
                }
            }
        }
    }

    std::int64_t parse_int64(const std::string& s) {
        if (s.empty()) {
            throw std::invalid_argument("Empty number");
        }

        size_t start = 0;
        bool negative = false;

        if (s[0] == '+') {
            start = 1;
        } else if (s[0] == '-') {
            negative = true;
            start = 1;
        }

        if (start >= s.size()) {
            throw std::invalid_argument("No digits");
        }

        // Check for invalid characters
        for (size_t i = start; i < s.size(); ++i) {
            if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
                throw std::invalid_argument("Invalid character in number");
            }
        }

        // Parse manually to detect overflow
        std::uint64_t value = 0;
        for (size_t i = start; i < s.size(); ++i) {
            int digit = s[i] - '0';
            if (value > std::numeric_limits<std::uint64_t>::max() / 10) {
                throw std::invalid_argument("Overflow");
            }
            value = value * 10 + digit;
        }

        if (negative) {
            if (value > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) + 1) {
                throw std::invalid_argument("Overflow");
            }
            return -static_cast<std::int64_t>(value);
        } else {
            if (value > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())) {
                throw std::invalid_argument("Overflow");
            }
            return static_cast<std::int64_t>(value);
        }
    }
};

} // anonymous namespace

inline std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    CSVParser parser(in);
    return parser.parse();
}

#endif // SOLUTION_HPP
