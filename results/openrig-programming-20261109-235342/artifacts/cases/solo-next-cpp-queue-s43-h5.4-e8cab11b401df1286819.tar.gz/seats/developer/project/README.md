# BoundedQueue

Thread-safe bounded blocking queue for C++20.

## API

```cpp
template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity); // throws std::invalid_argument if capacity == 0
    bool push(T value); // blocks while full, returns false after close
    std::optional<T> pop(); // blocks while empty/open, returns nullopt after close
    void close(); // idempotent, wakes all waiters
};
```

## Build & Test

```bash
clang++ -std=c++20 -pthread -o solution_test solution_test.cpp
./solution_test
```
