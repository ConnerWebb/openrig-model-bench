#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <queue>
#include <optional>
#include <stdexcept>
#include <atomic>
#include <algorithm>
#include <chrono>
#include <string>
#include <memory>
#include "solution.hpp"

// Simple test framework
bool test_passed = true;
void check(bool cond, const char* msg) {
    if (!cond) { std::cerr << "FAIL: " << msg << std::endl; test_passed = false; }
    else std::cerr << "PASS: " << msg << std::endl;
}

// Test 1: Basic push/pop
void test_basic() {
    BoundedQueue<int> q(3);
    check(q.push(1), "push 1");
    check(q.push(2), "push 2");
    check(q.push(3), "push 3");
    std::thread t([&]{ std::this_thread::sleep_for(std::chrono::milliseconds(50)); q.close(); });
    check(!q.push(4), "push 4 should fail after close");
    t.join();
    auto v1 = q.pop();
    check(v1.has_value() && *v1 == 1, "pop 1");
    auto v2 = q.pop();
    check(v2.has_value() && *v2 == 2, "pop 2");
    auto v3 = q.pop();
    check(v3.has_value() && *v3 == 3, "pop 3");
    check(!q.pop().has_value(), "pop empty");
}

// Test 2: Capacity zero throws
void test_zero_capacity() {
    bool threw = false;
    try { BoundedQueue<int> q(0); } catch (const std::invalid_argument&) { threw = true; }
    check(threw, "zero capacity throws");
}

// Test 3: Move-only types
void test_move_only() {
    BoundedQueue<std::unique_ptr<int>> q(2);
    q.push(std::make_unique<int>(42));
    q.push(std::make_unique<int>(99));
    auto v1 = q.pop();
    check(v1.has_value() && **v1 == 42, "move-only pop 1");
    auto v2 = q.pop();
    check(v2.has_value() && **v2 == 99, "move-only pop 2");
}

// Test 4: FIFO order
void test_fifo() {
    BoundedQueue<int> q(5);
    for (int i = 0; i < 10; ++i) q.push(i);
    for (int i = 0; i < 10; ++i) {
        auto v = q.pop();
        std::string msg = "FIFO order " + std::to_string(i);
        check(v.has_value() && *v == i, msg.c_str());
    }
}

// Test 5: Idempotent close
void test_idempotent_close() {
    BoundedQueue<int> q(3);
    q.close();
    q.close();
    check(!q.push(1), "push after close fails");
    check(!q.pop().has_value(), "pop empty after close");
}

int main() {
    test_basic();
    test_zero_capacity();
    test_move_only();
    test_fifo();
    test_idempotent_close();
    return test_passed ? 0 : 1;
}
