import unittest
import tempfile
import pathlib
import json
import os
import threading
import time
import subprocess
import sys

from solution import JobQueue


class TestJobQueueBasic(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_enqueue_new_key(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("key1", {"data": 123}))

    def test_enqueue_duplicate_key(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("key1", {"data": 123}))
        self.assertFalse(q.enqueue("key1", {"data": 456}))

    def test_claim_returns_job(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 123})
        result = q.claim("worker1", 0.0, 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": 123})
        self.assertEqual(result["attempts"], 1)

    def test_claim_returns_none_when_empty(self):
        q = JobQueue(self.db_path)
        result = q.claim("worker1", 0.0, 10.0)
        self.assertIsNone(result)

    def test_complete(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertTrue(q.complete("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertFalse(q.complete("key1", "wrong_worker"))

    def test_fail(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")

    def test_fail_exhausted(self):
        q = JobQueue(self.db_path, max_attempts=1)
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 10.0)
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "failed")

    def test_status_not_found(self):
        q = JobQueue(self.db_path)
        status = q.status("nonexistent")
        self.assertIsNone(status)

    def test_status_found(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 123})
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_invalid_key_empty(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue("", {"data": 123})

    def test_invalid_worker_empty(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim("", 0.0, 10.0)

    def test_invalid_lease_zero(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim("worker", 0.0, 0)

    def test_invalid_max_attempts_zero(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)

    def test_invalid_max_attempts_negative(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)


class TestJobQueueOrdering(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_claim_oldest_first(self):
        q = JobQueue(self.db_path)
        q.enqueue("first", {"data": 1})
        time.sleep(0.01)
        q.enqueue("second", {"data": 2})
        result = q.claim("worker", 0.0, 10.0)
        self.assertEqual(result["key"], "first")


class TestJobQueueLeaseExpiry(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_claim_expired_lease(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 123})
        q.claim("worker1", 0.0, 5.0)
        result = q.claim("worker2", 10.0, 10.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")


class TestJobQueueConcurrency(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_concurrent_enqueue(self):
        q1 = JobQueue(self.db_path)
        q2 = JobQueue(self.db_path)
        self.assertTrue(q1.enqueue("key1", {"data": 1}))
        self.assertFalse(q2.enqueue("key1", {"data": 2}))

    def test_concurrent_claim(self):
        n = 10
        for i in range(n):
            q = JobQueue(self.db_path)
            q.enqueue(f"key{i}", i)
        results = []
        threads = []
        for i in range(n):
            q = JobQueue(self.db_path)
            t = threading.Thread(target=lambda i=i: results.append(q.claim(f"worker{i}", 0.0, 10.0)))
            threads.append(t)
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(len([r for r in results if r is not None]), n)


class TestPublicCases(unittest.TestCase):
    def _run_case(self, case_path: str):
        with open(case_path) as f:
            case = json.load(f)
        with tempfile.TemporaryDirectory() as d:
            db_path = os.path.join(d, "q.db")
            q = JobQueue(db_path, case.get("max_attempts", 3))
            out = []
            for op in case.get("ops", []):
                method = getattr(q, op[0])
                try:
                    res = method(*op[1:])
                    out.append(res)
                except Exception as e:
                    out.append({"error": type(e).__name__})
            return out

    def test_case_00(self):
        result = self._run_case("/work/public-inputs/case-00.json")
        expected = [True, False, {"key": "a", "payload": {"v": 5304}, "attempts": 1}, False, True,
                    {"key": "a", "payload": {"v": 5304}, "attempts": 2}, True, {"state": "done", "attempts": 2}, None]
        self.assertEqual(result, expected)

    def test_case_01(self):
        result = self._run_case("/work/public-inputs/case-01.json")
        expected = [True, False, {"key": "a", "payload": {"v": 8330}, "attempts": 1}, False, True,
                    {"key": "a", "payload": {"v": 8330}, "attempts": 2}, True, {"state": "done", "attempts": 2}, None]
        self.assertEqual(result, expected)

    def test_case_02(self):
        result = self._run_case("/work/public-inputs/case-02.json")
        expected = [True, False, {"key": "a", "payload": {"v": 138}, "attempts": 1}, False, True,
                    {"key": "a", "payload": {"v": 138}, "attempts": 2}, True, {"state": "done", "attempts": 2}, None]
        self.assertEqual(result, expected)

    def test_case_03(self):
        result = self._run_case("/work/public-inputs/case-03.json")
        expected = [True, False, {"key": "a", "payload": {"v": 4340}, "attempts": 1}, False, True,
                    {"key": "a", "payload": {"v": 4340}, "attempts": 2}, True, {"state": "done", "attempts": 2}, None]
        self.assertEqual(result, expected)

    def test_case_04(self):
        result = self._run_case("/work/public-inputs/case-04.json")
        expected = [True, {"key": "x", "payload": 0, "attempts": 1}, None, {"state": "done", "attempts": 1}]
        self.assertEqual(result, expected)

    def test_case_05(self):
        case = json.load(open("/work/public-inputs/case-05.json"))
        with tempfile.TemporaryDirectory() as d:
            db_path = os.path.join(d, "q.db")
            q = JobQueue(db_path, case.get("max_attempts", 3))
            n = case.get("concurrent", 0)
            for i in range(n):
                q.enqueue(str(i), i)
            results = []
            threads = []

            def claim_func(i):
                other = JobQueue(db_path, case.get("max_attempts", 3))
                res = other.claim(f"worker{i}", 100.0, 10.0)
                if res:
                    results.append(res["key"])

            for i in range(n + 8):
                t = threading.Thread(target=claim_func, args=(i,))
                threads.append(t)
                t.start()
            for t in threads:
                t.join()
            self.assertEqual(len(results), n)

    def test_case_06_invalid_worker_empty(self):
        result = self._run_case("/work/public-inputs/case-06.json")
        self.assertEqual(len(result), 1)
        self.assertIn("error", result[0])

    def test_case_07_invalid_lease_zero(self):
        result = self._run_case("/work/public-inputs/case-07.json")
        self.assertEqual(len(result), 1)
        self.assertIn("error", result[0])


if __name__ == "__main__":
    unittest.main()
