# JobQueue Implementation

A thread-safe SQLite-backed job queue with claim/complete/fail semantics.

## API

```python
from solution import JobQueue

# Create queue
q = JobQueue(path="queue.db", max_attempts=3)

# Enqueue a job (first unique key wins)
success: bool = q.enqueue(key="job1", payload={"data": 123})

# Claim a job (oldest queued or expired lease)
job: dict | None = q.claim(worker="worker1", now=0.0, lease=10.0)
# Returns: {"key": str, "payload": any, "attempts": int} or None

# Mark job as done
success: bool = q.complete(key="job1", worker="worker1")

# Mark job as failed (requeue unless attempts exhausted)
success: bool = q.fail(key="job1", worker="worker1")

# Get job status
status: dict | None = q.status(key="job1")
# Returns: {"state": str, "attempts": int}
```

## States

- `queued`: waiting to be claimed
- `leased`: currently claimed by a worker
- `done`: completed successfully
- `failed`: exhausted max_attempts

## Validation

- `key` and `worker` must be non-empty strings
- `lease` must be positive
- `max_attempts` must be a positive integer

## Thread Safety

Uses SQLite WAL mode and a global lock to ensure consistency across threads and processes.
