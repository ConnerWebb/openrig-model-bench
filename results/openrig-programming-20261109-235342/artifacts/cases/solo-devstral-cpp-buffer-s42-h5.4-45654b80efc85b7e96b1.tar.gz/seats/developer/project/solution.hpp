#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <new>

class Buffer {
    std::uint8_t* p;
    std::size_t n;
    
public:
    // Constructor with default size 0
    explicit Buffer(std::size_t n = 0) noexcept : p(new std::uint8_t[n]), n(n) {}
    
    // Destructor
    ~Buffer() noexcept {
        delete[] p;
    }
    
    // Copy constructor - deep copy
    Buffer(const Buffer& other) : p(new std::uint8_t[other.n]), n(other.n) {
        std::copy(other.p, other.p + other.n, p);
    }
    
    // Move constructor - noexcept
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }
    
    // Copy assignment - deep copy
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = new std::uint8_t[other.n];
            std::copy(other.p, other.p + other.n, new_p);
            delete[] p;
            p = new_p;
            n = other.n;
        }
        return *this;
    }
    
    // Move assignment - noexcept
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }
    
    // Size getter
    std::size_t size() const noexcept {
        return n;
    }
    
    // Bounds-checked element access
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }
    
    // Bounds-checked const element access
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }
    
    // Resize - preserve prefix, zero-initialize new bytes
    void resize(std::size_t k) {
        if (k == n) return;
        
        std::uint8_t* new_p = new std::uint8_t[k];
        
        // Copy existing elements
        std::size_t copy_size = (k < n) ? k : n;
        std::copy(p, p + copy_size, new_p);
        
        // Zero-initialize new bytes
        if (k > n) {
            std::fill(new_p + n, new_p + k, 0);
        }
        
        delete[] p;
        p = new_p;
        n = k;
    }
    
    // Prevent copying through pointer
    std::uint8_t* data() noexcept {
        return p;
    }
    
    const std::uint8_t* data() const noexcept {
        return p;
    }
};
