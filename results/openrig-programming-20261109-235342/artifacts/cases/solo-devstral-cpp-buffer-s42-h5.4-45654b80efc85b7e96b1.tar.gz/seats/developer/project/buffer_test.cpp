#include "solution.hpp"
#include <iostream>
#include <stdexcept>

class BufferTest {
public:
    static int run() {
        int failed = 0;
        
        // Test 1: Default constructor
        {
            Buffer b;
            if (b.size() != 0u) {
                std::cerr << "Test 1 failed: Default constructor size" << std::endl;
                failed++;
            }
        }
        
        // Test 2: Constructor with size
        {
            Buffer b(10);
            if (b.size() != 10u) {
                std::cerr << "Test 2 failed: Constructor with size" << std::endl;
                failed++;
            }
        }
        
        // Test 3: Size getter
        {
            Buffer b(5);
            if (b.size() != 5u) {
                std::cerr << "Test 3 failed: Size getter" << std::endl;
                failed++;
            }
        }
        
        // Test 4: Element access
        {
            Buffer b(3);
            b[0] = 10;
            b[1] = 20;
            b[2] = 30;
            if (b[0] != 10u || b[1] != 20u || b[2] != 30u) {
                std::cerr << "Test 4 failed: Element access" << std::endl;
                failed++;
            }
        }
        
        // Test 5: Bounds checking
        {
            Buffer b(3);
            bool threw = false;
            try {
                b[3];
            } catch (const std::out_of_range&) {
                threw = true;
            }
            if (!threw) {
                std::cerr << "Test 5 failed: Bounds checking" << std::endl;
                failed++;
            }
        }
        
        // Test 6: Resize smaller
        {
            Buffer b(5);
            b[0] = 10; b[1] = 20; b[2] = 30; b[3] = 40; b[4] = 50;
            b.resize(3);
            if (b.size() != 3u || b[0] != 10u || b[1] != 20u || b[2] != 30u) {
                std::cerr << "Test 6 failed: Resize smaller" << std::endl;
                failed++;
            }
        }
        
        // Test 7: Resize larger
        {
            Buffer b(3);
            b[0] = 10; b[1] = 20; b[2] = 30;
            b.resize(5);
            if (b.size() != 5u || b[0] != 10u || b[1] != 20u || b[2] != 30u || b[3] != 0u || b[4] != 0u) {
                std::cerr << "Test 7 failed: Resize larger" << std::endl;
                failed++;
            }
        }
        
        // Test 8: Resize same
        {
            Buffer b(3);
            b[0] = 10; b[1] = 20; b[2] = 30;
            b.resize(3);
            if (b.size() != 3u || b[0] != 10u || b[1] != 20u || b[2] != 30u) {
                std::cerr << "Test 8 failed: Resize same" << std::endl;
                failed++;
            }
        }
        
        // Test 9: Copy constructor
        {
            Buffer b1(3);
            b1[0] = 10; b1[1] = 20; b1[2] = 30;
            Buffer b2 = b1;
            if (b2.size() != 3u || b2[0] != 10u || b2[1] != 20u || b2[2] != 30u) {
                std::cerr << "Test 9 failed: Copy constructor" << std::endl;
                failed++;
            }
            b2[0] = 100;
            if (b1[0] != 10u) {
                std::cerr << "Test 9 failed: Deep copy independence" << std::endl;
                failed++;
            }
        }
        
        // Test 10: Move constructor
        {
            Buffer b1(3);
            b1[0] = 10; b1[1] = 20; b1[2] = 30;
            Buffer b2 = std::move(b1);
            if (b2.size() != 3u || b2[0] != 10u || b2[1] != 20u || b2[2] != 30u) {
                std::cerr << "Test 10 failed: Move constructor" << std::endl;
                failed++;
            }
            if (b1.size() != 0u) {
                std::cerr << "Test 10 failed: Moved-from size" << std::endl;
                failed++;
            }
        }
        
        // Test 11: Copy assignment
        {
            Buffer b1(3);
            b1[0] = 10; b1[1] = 20; b1[2] = 30;
            Buffer b2(5);
            b2 = b1;
            if (b2.size() != 3u || b2[0] != 10u || b2[1] != 20u || b2[2] != 30u) {
                std::cerr << "Test 11 failed: Copy assignment" << std::endl;
                failed++;
            }
            b2[0] = 100;
            if (b1[0] != 10u) {
                std::cerr << "Test 11 failed: Deep copy independence" << std::endl;
                failed++;
            }
        }
        
        // Test 12: Move assignment
        {
            Buffer b1(3);
            b1[0] = 10; b1[1] = 20; b1[2] = 30;
            Buffer b2(5);
            b2 = std::move(b1);
            if (b2.size() != 3u || b2[0] != 10u || b2[1] != 20u || b2[2] != 30u) {
                std::cerr << "Test 12 failed: Move assignment" << std::endl;
                failed++;
            }
            if (b1.size() != 0u) {
                std::cerr << "Test 12 failed: Moved-from size" << std::endl;
                failed++;
            }
        }
        
        // Test 13: Self copy
        {
            Buffer b(3);
            b[0] = 10; b[1] = 20; b[2] = 30;
            b = b;
            if (b.size() != 3u || b[0] != 10u || b[1] != 20u || b[2] != 30u) {
                std::cerr << "Test 13 failed: Self copy" << std::endl;
                failed++;
            }
        }
        
        // Test 14: Self move
        {
            Buffer b(3);
            b[0] = 10; b[1] = 20; b[2] = 30;
            b = std::move(b);
            if (b.size() != 3u || b[0] != 10u || b[1] != 20u || b[2] != 30u) {
                std::cerr << "Test 14 failed: Self move" << std::endl;
                failed++;
            }
        }
        
        // Test 15: Moved-from buffer reusable
        {
            Buffer b1(3);
            b1[0] = 10; b1[1] = 20; b1[2] = 30;
            Buffer b2 = std::move(b1);
            b1 = Buffer(5);
            b1[0] = 10; b1[1] = 20; b1[2] = 30; b1[3] = 40; b1[4] = 50;
            if (b1.size() != 5u || b1[0] != 10u || b1[1] != 20u || b1[2] != 30u || b1[3] != 40u || b1[4] != 50u) {
                std::cerr << "Test 15 failed: Moved-from buffer reusable" << std::endl;
                failed++;
            }
        }
        
        // Test 16: Const access
        {
            Buffer b(3);
            b[0] = 5; b[1] = 10; b[2] = 15;
            const Buffer& cb = b;
            if (cb.size() != 3u || cb[0] != 5u || cb[1] != 10u || cb[2] != 15u) {
                std::cerr << "Test 16 failed: Const access" << std::endl;
                failed++;
            }
        }
        
        // Test 17: Deep copy independence
        {
            Buffer b1(3);
            b1[0] = 10; b1[1] = 20; b1[2] = 30;
            Buffer b2 = b1;
            b2[0] = 100;
            if (b1[0] != 10u || b2[0] != 100u) {
                std::cerr << "Test 17 failed: Deep copy independence" << std::endl;
                failed++;
            }
        }
        
        return failed;
    }
};

int main() {
    int failed = BufferTest::run();
    if (failed == 0) {
        std::cout << "All tests passed!" << std::endl;
        return 0;
    } else {
        std::cout << failed << " tests failed." << std::endl;
        return 1;
    }
}
