# Buffer Library

This is a C++20 implementation of a simple Buffer class for storing uint8_t elements.

## Features

- **Constructor**: `Buffer(size_t n = 0)` - creates a buffer with optional initial size
- **Size**: `size() const noexcept` - returns current buffer size
- **Element Access**: `operator[](size_t)` - bounds-checked access with std::out_of_range exception
- **Resize**: `resize(size_t)` - preserves existing prefix and zero-initializes new bytes
- **Deep Copy**: Copy constructor and assignment perform deep copies
- **Noexcept Move**: Move constructor and assignment are noexcept operations
- **RAII**: Proper resource management with no leaks or undefined behavior

## API

```cpp
#include "solution.hpp"

Buffer b;                        // Default constructor (size 0)
Buffer b2(10);                    // Constructor with size
b2[0] = 42;                     // Element access
b2.resize(20);                   // Resize (preserves first 10 bytes, zero-initializes new)
std::size_t s = b2.size();      // Get size

Buffer b3 = b2;                  // Deep copy
Buffer b4 = std::move(b2);       // Noexcept move (b2 becomes size 0)
```

## Requirements

- C++20 compatible compiler
- Standard library headers only

## Testing

The implementation includes comprehensive tests covering:
- Constructor behavior
- Size management
- Bounds checking
- Resize operations (grow, shrink, same size)
- Copy and move semantics
- Self-assignment
- Deep copy independence
- Const correctness

Run tests with: `run_tests`
