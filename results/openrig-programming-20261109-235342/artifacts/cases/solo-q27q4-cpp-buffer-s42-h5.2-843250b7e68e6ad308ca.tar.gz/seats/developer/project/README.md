# Buffer

A small C++20 RAII byte buffer (`solution.hpp`).

## API

- `Buffer(size_t n = 0)` — constructs a buffer of `n` zero-initialized `uint8_t` elements.
- `size() const noexcept` — returns the element count.
- `operator[](size_t i)` (mutable and const) — bounds-checked element access; throws
  `std::out_of_range` when `i >= size()`.
- `resize(size_t k)` — resizes the buffer, preserving the existing prefix and
  zero-initializing any new bytes.
- Deep-copy construction and copy assignment.
- `noexcept` move construction and move assignment; moved-from buffers have size 0 and
  are reusable.
- Self-copy and self-move preserve content.

## Implementation

Backed by `std::vector<std::uint8_t>`: RAII, no leaks or double frees, no stale reads,
no undefined behavior.

## Tests

`test_buffer.py` (stdlib `unittest`):

- Runs the fixed public driver (`PUBLIC_DRIVER.cpp`) against every case in
  `PUBLIC_CASES.json` and compares the JSON output.
- Exercises the full API contract: deep copy, move semantics, moved-from reuse,
  self-copy/self-move, bounds checking (mutable and const), resize grow/shrink,
  zero-initialization.

Run with `python3 test_buffer.py` (or the fixed `run_tests` harness).
