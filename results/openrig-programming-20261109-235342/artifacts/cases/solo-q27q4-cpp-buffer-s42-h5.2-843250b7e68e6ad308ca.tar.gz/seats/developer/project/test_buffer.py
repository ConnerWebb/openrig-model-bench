import json
import os
import subprocess
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
SOLUTION = os.path.join(HERE, "solution.hpp")
DRIVER = os.path.join(HERE, "PUBLIC_DRIVER.cpp")
CASES = os.path.join(HERE, "PUBLIC_CASES.json")


def run_driver(driver_input):
    with tempfile.TemporaryDirectory() as tmp:
        exe = os.path.join(tmp, "driver")
        src = os.path.join(tmp, "driver.cpp")
        with open(src, "w") as f:
            f.write('#include "solution.hpp"\n')
            with open(DRIVER) as d:
                f.write(d.read())
        subprocess.run(
            ["clang++", "-std=c++20", "-I", HERE, "-o", exe, src, "-fuse-ld=bfd"],
            check=True, capture_output=True, text=True,
        )
        out = subprocess.run([exe], input=driver_input, check=True,
                             capture_output=True, text=True).stdout
    return json.loads(out.strip().splitlines()[-1])


class TestBuffer(unittest.TestCase):
    def test_public_cases(self):
        with open(CASES) as f:
            cases = json.load(f)
        for i, case in enumerate(cases):
            with self.subTest(case=i):
                got = run_driver(case["driver_input"])
                self.assertEqual(got, case["expected"])

    def test_api_contract(self):
        code = r'''
#include <cassert>
#include <cstdint>
#include <stdexcept>
#include <type_traits>
#include "solution.hpp"
int main(){
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
    Buffer a(3);
    a[0]=1; a[1]=2; a[2]=3;
    Buffer b=a; b[0]=9;
    assert(a[0]==1 && a[1]==2 && a[2]==3);
    Buffer c=std::move(b);
    assert(c.size()==3 && c[0]==9 && c[1]==2 && c[2]==3);
    assert(b.size()==0);
    b.resize(2); b[0]=7; b[1]=8;
    assert(b.size()==2 && b[0]==7 && b[1]==8);
    Buffer d(5);
    d=d;
    assert(d.size()==5);
    Buffer e=std::move(d);
    assert(e.size()==5 && d.size()==0);
    bool caught=false;
    try { (void)e[5]; } catch (const std::out_of_range&) { caught=true; }
    assert(caught);
    const Buffer& ce=e;
    bool caught2=false;
    try { (void)ce[5]; } catch (const std::out_of_range&) { caught2=true; }
    assert(caught2);
    Buffer f(2); f[0]=10; f[1]=20;
    f.resize(1);
    assert(f.size()==1 && f[0]==10);
    f.resize(3);
    assert(f.size()==3 && f[1]==0 && f[2]==0);
    Buffer g;
    assert(g.size()==0);
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "api.cpp")
            exe = os.path.join(tmp, "api")
            with open(src, "w") as f:
                f.write(code)
            subprocess.run(
                ["clang++", "-std=c++20", "-I", HERE, "-o", exe, src, "-fuse-ld=bfd"],
                check=True, capture_output=True, text=True,
            )
            subprocess.run([exe], check=True, capture_output=True, text=True)


if __name__ == "__main__":
    unittest.main()
