#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <queue>
#include <optional>
#include <stdexcept>
#include <atomic>
#include <chrono>
#include <cassert>
#include "solution.hpp"

void test_basic_push_pop() {
    BoundedQueue<int> q(2);
    assert(q.push(1));
    assert(q.push(2));
    assert(!q.push(3)); // queue full
    assert(q.pop().value() == 1);
    assert(q.pop().value() == 2);
    assert(!q.pop().has_value());
}

void test_zero_capacity() {
    bool threw = false;
    try {
        BoundedQueue<int> q(0);
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
}

void test_close_idempotent() {
    BoundedQueue<int> q(2);
    q.close();
    q.close();
    assert(!q.push(1));
    assert(!q.pop().has_value());
}

void test_close_wakes_all() {
    BoundedQueue<int> q(1);
    std::atomic<bool> p1_blocked{true}, p2_blocked{true};
    std::thread p1([&] { p1_blocked = true; bool r = q.push(1); p1_blocked = !r; });
    std::thread p2([&] { p2_blocked = true; bool r = q.push(2); p2_blocked = !r; });
    while (p1_blocked || p2_blocked) std::this_thread::yield();
    q.close();
    p1.join();
    p2.join();
    assert(!p1_blocked);
    assert(!p2_blocked);
}

void test_move_only_type() {
    BoundedQueue<std::unique_ptr<int>> q(2);
    q.push(std::make_unique<int>(42));
    q.push(std::make_unique<int>(43));
    auto v1 = q.pop();
    auto v2 = q.pop();
    assert(v1 && **v1 == 42);
    assert(v2 && **v2 == 43);
}

void test_fifo_order() {
    BoundedQueue<int> q(5);
    for (int i = 0; i < 5; ++i) q.push(i);
    for (int i = 0; i < 5; ++i) {
        assert(q.pop().value() == i);
    }
}

void test_drain_after_close() {
    BoundedQueue<int> q(5);
    for (int i = 0; i < 5; ++i) q.push(i);
    q.close();
    for (int i = 0; i < 5; ++i) {
        assert(q.pop().has_value());
    }
    assert(!q.pop().has_value());
}

void test_producer_consumer() {
    BoundedQueue<int> q(3);
    std::vector<int> got;
    std::mutex m;
    std::thread consumer([&] {
        while (auto v = q.pop()) {
            std::lock_guard<std::mutex> lock(m);
            got.push_back(*v);
        }
    });
    std::thread producer([&] {
        for (int i = 0; i < 10; ++i) q.push(i);
        q.close();
    });
    producer.join();
    consumer.join();
    assert(got.size() == 10);
    std::sort(got.begin(), got.end());
    for (int i = 0; i < 10; ++i) assert(got[i] == i);
}

int main() {
    test_basic_push_pop();
    test_zero_capacity();
    test_close_idempotent();
    test_close_wakes_all();
    test_move_only_type();
    test_fifo_order();
    test_drain_after_close();
    test_producer_consumer();
    std::cout << "All tests passed." << std::endl;
    return 0;
}
