#ifndef BOUNDED_QUEUE_HPP
#define BOUNDED_QUEUE_HPP

#include <queue>
#include <mutex>
#include <condition_variable>
#include <optional>
#include <stdexcept>

template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity) : capacity_(capacity) {
        if (capacity_ == 0) {
            throw std::invalid_argument("capacity must be greater than zero");
        }
    }

    bool push(T value) {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_producers_.wait(lock, [this]() {
            return !is_full_() || closed_;
        });
        if (closed_) return false;
        queue_.push(std::move(value));
        cv_consumers_.notify_one();
        return true;
    }

    std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_consumers_.wait(lock, [this]() {
            return !queue_.empty() || closed_;
        });
        if (queue_.empty()) return std::nullopt;
        auto val = std::move(queue_.front());
        queue_.pop();
        cv_producers_.notify_one();
        return val;
    }

    void close() {
        std::unique_lock<std::mutex> lock(mutex_);
        if (closed_) return;
        closed_ = true;
        cv_producers_.notify_all();
        cv_consumers_.notify_all();
    }

private:
    bool is_full_() const {
        return queue_.size() >= capacity_;
    }

    size_t capacity_;
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable cv_producers_;
    std::condition_variable cv_consumers_;
    bool closed_ = false;
};

#endif
