# BoundedQueue

A thread-safe bounded blocking queue implementation in C++20.

## API

```cpp
template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity);
    bool push(T value);
    std::optional<T> pop();
    void close();
};
```

- `BoundedQueue(size_t capacity)`: Constructor. Throws `std::invalid_argument` if capacity is zero.
- `push(T value)`: Blocks while full until space is available or queue is closed. Returns `false` after close.
- `pop()`: Blocks while empty until data is available or queue is closed. Returns `std::nullopt` after close and empty.
- `close()`: Idempotent. Wakes all waiting producers and consumers.

## Thread Safety

The queue is fully thread-safe. Multiple producers and consumers may operate concurrently.

## Usage

```cpp
BoundedQueue<int> q(10);
q.push(42);
auto val = q.pop();
q.close();
```

## Build & Test

```bash
clang++ -std=c++20 -pthread solution_test.cpp -o solution_test && ./solution_test
```
