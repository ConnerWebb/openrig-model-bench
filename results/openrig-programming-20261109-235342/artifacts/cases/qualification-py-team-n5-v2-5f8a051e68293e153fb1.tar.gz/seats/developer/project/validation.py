def normalize(records):
    out = []
    for r in records:
        if not isinstance(r, dict) or set(r) != {'id', 'category', 'cents'}:
            raise ValueError('record')
        if not isinstance(r['id'], str) or not r['id'].strip():
            raise ValueError('record')
        if not isinstance(r['category'], str) or not r['category'].strip():
            raise ValueError('record')
        if type(r['cents']) is bool or not isinstance(r['cents'], int) or r['cents'] < 0:
            raise ValueError('record')
        out.append({'id': r['id'].strip(), 'category': r['category'].strip(), 'cents': r['cents']})
    return out
