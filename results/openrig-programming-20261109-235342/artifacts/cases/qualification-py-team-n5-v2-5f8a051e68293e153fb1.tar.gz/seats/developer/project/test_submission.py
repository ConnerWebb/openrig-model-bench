import unittest,validation
class ModuleCheck(unittest.TestCase):
 def test_normalize(self):
  x=[{'id':' a ','category':' b ','cents':2}];self.assertEqual(validation.normalize(x),[{'id':'a','category':'b','cents':2}]);self.assertEqual(x[0]['id'],' a ');self.assertEqual(validation.normalize([]),[])
 def test_normalize_empty_string_id(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'','category':'b','cents':1}])
 def test_normalize_whitespace_id(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'   ','category':'b','cents':1}])
 def test_normalize_empty_string_category(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'a','category':'','cents':1}])
 def test_normalize_whitespace_category(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'a','category':'   ','cents':1}])
 def test_normalize_negative_cents(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'a','category':'b','cents':-1}])
 def test_normalize_boolean_cents(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'a','category':'b','cents':True}])
 def test_normalize_missing_key(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'a','category':'b'}])
 def test_normalize_extra_key(self):
  with self.assertRaises(ValueError):validation.normalize([{'id':'a','category':'b','cents':1,'extra':2}])
 def test_normalize_preserves_duplicates(self):
  x=[{'id':'a','category':'b','cents':1},{'id':'a','category':'b','cents':1}];self.assertEqual(validation.normalize(x),x)
 def test_normalize_preserves_order(self):
  x=[{'id':'c','category':'b','cents':1},{'id':'a','category':'b','cents':1},{'id':'b','category':'b','cents':1}];self.assertEqual(validation.normalize(x),x)
 def test_normalize_whitespace_stripped(self):
  x=[{'id':' a ','category':' b ','cents':2}];self.assertEqual(validation.normalize(x),[{'id':'a','category':'b','cents':2}])
