# validation.py

## normalize(records)

Normalizes a list of record dictionaries.

**Interface:**
```python
def normalize(records) -> list[dict]
```

**Parameters:**
- `records`: List of dictionaries, each with exactly the keys `'id'`, `'category'`, and `'cents'`

**Validation rules:**
- Each record must be a dict with exactly the keys `'id'`, `'category'`, `'cents'`
- `id`: must be a non-empty string (whitespace is stripped)
- `category`: must be a non-empty string (whitespace is stripped)
- `cents`: must be a non-negative integer (boolean values are rejected)

**Behavior:**
- Returns a new list of normalized dictionaries
- Preserves duplicates and input order
- Does not mutate the input

**Raises:**
- `ValueError` if any record fails validation

# storage.py

## deduplicate(records)

Removes duplicate records by `id`, keeping first occurrence.

**Interface:**
```python
def deduplicate(records) -> list[dict]
```

# ledger.py

## process(records, *, minimum_cents=0)

Processes records through normalization, deduplication, filtering, and aggregation.

**Interface:**
```python
def process(records, *, minimum_cents=0) -> dict
```

**Returns:**
```python
{'events': list[dict], 'totals': dict[str, int]}
```
