"""
Tests for solution.py aggregate function.
"""
import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_simple_csv(self):
        """Test basic CSV with simple categories and amounts."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.00\nfood,5.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.00'})
    
    def test_quoted_fields_with_commas(self):
        """Test CSV with quoted fields containing commas."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n"c,d",200.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00', 'c,d': '200.00'})
    
    def test_quoted_fields_with_newlines(self):
        """Test CSV with quoted fields containing newlines."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"line1\nline2",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'line1\nline2': '50.00'})
    
    def test_quoted_quotes(self):
        """Test CSV with escaped quotes (double quotes)."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.00\n\n\nrent,20.00\n\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})
    
    def test_whitespace_stripped(self):
        """Test that whitespace is stripped from category and amount."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_integer_amount(self):
        """Test amount without decimal point."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,100\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '100.00'})
    
    def test_one_decimal_digit(self):
        """Test amount with one decimal digit."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.5\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_two_decimal_digits(self):
        """Test amount with two decimal digits."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.55\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.55'})
    
    def test_empty_category_raises(self):
        """Test that empty category raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_wrong_header_raises(self):
        """Test that wrong header raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,header\nfood,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_wrong_field_count_raises(self):
        """Test that wrong field count raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.00,extra\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_raises(self):
        """Test that invalid amount format raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_negative_amount_raises(self):
        """Test that negative amount raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,-10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_exponent_raises(self):
        """Test that exponent notation raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,1e2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote_raises(self):
        """Test that unclosed quote raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"unclosed,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_sorted_keys(self):
        """Test that result keys are sorted."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nzebra,1.00\napple,2.00\nbanana,3.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['apple', 'banana', 'zebra'])
    
    def test_exact_decimal_arithmetic(self):
        """Test that decimal arithmetic is exact (no floating point errors)."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # 0.1 + 0.2 should be exactly 0.30, not 0.30000000000000004
            p.write_text('category,amount\nfood,0.10\nfood,0.20\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '0.30'})
    
    def test_unicode_categories(self):
        """Test Unicode category names."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Use simple Unicode categories without commas
            p.write_text('category,amount\ncafé,100.00\nnaïve,50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'café': '100.00', 'naïve': '50.00'})
    
    def test_empty_file_raises(self):
        """Test that empty file raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only(self):
        """Test file with only header (no data rows)."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
