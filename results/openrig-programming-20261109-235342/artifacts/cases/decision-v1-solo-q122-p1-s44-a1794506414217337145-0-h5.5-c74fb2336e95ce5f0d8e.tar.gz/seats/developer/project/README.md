# CSV Aggregator

This module provides an `aggregate` function that reads a UTF-8 CSV file and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return dict with sorted keys and totals formatted to 2 decimal places.
    Raises ValueError on any malformed input.
    """
```

## Requirements

- Header must be exactly `category,amount` (case-sensitive, whitespace stripped)
- Each non-blank record must have exactly 2 fields
- Category must not be empty after stripping whitespace
- Amount format: optional `+`, 1-12 digits, optional decimal point with 1-2 digits
- Amounts must be nonnegative and finite (no exponent notation)
- CSV supports quoted fields with embedded commas and newlines
- Completely blank records are ignored
- Results are sorted by category key and formatted to 2 decimal places

## Usage

```python
from solution import aggregate

result = aggregate('input.csv')
print(result)  # {'food': '100.00', 'rent': '200.00'}
```

## Running Tests

```bash
python3 -m unittest test_solution.py
```

Or use the project's fixed runner:

```bash
run_tests
```
