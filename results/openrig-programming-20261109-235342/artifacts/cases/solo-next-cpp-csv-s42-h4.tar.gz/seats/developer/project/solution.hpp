#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <stdexcept>
#include <cstdint>
#include <cctype>
#include <vector>

namespace detail {

// Strip outer spaces/tabs/CR from a string
inline std::string strip(std::string s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    size_t end = s.size();
    while (end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\r')) {
        --end;
    }
    return s.substr(start, end - start);
}

// Parse a single CSV field from a string, handling quotes
// Returns the parsed field and updates pos to point after the field (or comma/newline)
// Throws std::invalid_argument on malformed quoting
inline std::string parse_csv_field(const std::string& input, size_t& pos) {
    if (pos >= input.size()) {
        return "";
    }
    
    char c = input[pos];
    
    if (c == '"') {
        // Quoted field
        ++pos;
        std::string result;
        while (pos < input.size()) {
            c = input[pos];
            if (c == '"') {
                // Check for escaped quote
                if (pos + 1 < input.size() && input[pos + 1] == '"') {
                    result += '"';
                    pos += 2;
                } else {
                    // End of quoted field
                    ++pos;
                    return result;
                }
            } else {
                result += c;
                ++pos;
            }
        }
        // Reached end of input inside quoted field - malformed
        throw std::invalid_argument("Unterminated quoted field");
    } else {
        // Unquoted field - read until comma or newline
        size_t start = pos;
        while (pos < input.size()) {
            c = input[pos];
            if (c == ',' || c == '\n') {
                break;
            }
            ++pos;
        }
        return input.substr(start, pos - start);
    }
}

// Parse a CSV line, handling quoted fields that may contain newlines
// Returns a vector of fields
inline std::vector<std::string> parse_csv_line(const std::string& input, size_t& pos) {
    std::vector<std::string> fields;
    
    while (pos < input.size()) {
        std::string field = parse_csv_field(input, pos);
        fields.push_back(field);
        
        if (pos >= input.size()) {
            break;
        }
        
        char c = input[pos];
        if (c == ',') {
            ++pos;  // skip comma, continue to next field
        } else if (c == '\n') {
            ++pos;  // skip newline, end of line
            break;
        }
    }
    
    return fields;
}

} // namespace detail

inline std::map<std::string, std::int64_t> aggregate(std::istream& input) {
    // Read entire stream into a string to handle embedded newlines in quoted fields
    std::string content;
    {
        std::string line;
        while (std::getline(input, line)) {
            content += line + "\n";
        }
    }
    
    std::map<std::string, std::int64_t> result;
    size_t pos = 0;
    
    // Parse header
    std::vector<std::string> header = detail::parse_csv_line(content, pos);
    if (header.size() != 2 || header[0] != "category" || header[1] != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Parse data rows
    while (pos < content.size()) {
        std::vector<std::string> fields = detail::parse_csv_line(content, pos);
        
        if (fields.empty()) {
            break;
        }
        
        if (fields.size() != 2) {
            throw std::invalid_argument("Expected 2 fields per row");
        }
        
        std::string category = detail::strip(fields[0]);
        std::string amount_str = detail::strip(fields[1]);
        
        if (category.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        // Parse the amount as int64
        size_t idx = 0;
        bool negative = false;
        
        if (amount_str[0] == '+') {
            idx = 1;
        } else if (amount_str[0] == '-') {
            negative = true;
            idx = 1;
        }
        
        if (idx >= amount_str.size()) {
            throw std::invalid_argument("Invalid amount: no digits");
        }
        
        // Check for valid digits only
        for (size_t i = idx; i < amount_str.size(); ++i) {
            if (!std::isdigit(static_cast<unsigned char>(amount_str[i]))) {
                throw std::invalid_argument("Invalid amount format");
            }
        }
        
        // Parse the number with overflow check
        std::int64_t value = 0;
        for (size_t i = idx; i < amount_str.size(); ++i) {
            int digit = amount_str[i] - '0';
            
            if (value > (std::numeric_limits<std::int64_t>::max() - digit) / 10) {
                throw std::invalid_argument("Amount overflow");
            }
            value = value * 10 + digit;
        }
        
        if (negative) {
            if (value == 9223372036854775808ULL) {
                value = std::numeric_limits<std::int64_t>::min();
            } else if (value > 9223372036854775807ULL) {
                throw std::invalid_argument("Amount overflow");
            } else {
                value = -value;
            }
        }
        
        // Add to result with overflow check
        auto it = result.find(category);
        if (it != result.end()) {
            if ((value > 0 && it->second > std::numeric_limits<std::int64_t>::max() - value) ||
                (value < 0 && it->second < std::numeric_limits<std::int64_t>::min() - value)) {
                throw std::invalid_argument("Accumulation overflow");
            }
            it->second += value;
        } else {
            result[category] = value;
        }
    }
    
    return result;
}

#endif // SOLUTION_HPP
