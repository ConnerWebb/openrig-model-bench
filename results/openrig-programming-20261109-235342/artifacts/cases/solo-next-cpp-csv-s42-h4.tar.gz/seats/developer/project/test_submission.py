import unittest
import subprocess
import sys

class TestSolution(unittest.TestCase):
    def test_compiles(self):
        # Verify the header compiles
        result = subprocess.run(
            ["clang++", "-std=c++20", "-fsyntax-only", "solution.hpp"],
            capture_output=True,
            text=True
        )
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")

if __name__ == "__main__":
    unittest.main()
