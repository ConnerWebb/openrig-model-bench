# CSV Aggregator

A header-only C++20 library for parsing and aggregating CSV data.

## Overview

This library provides a function `aggregate(std::istream&)` that parses CSV data and aggregates numeric values by category.

## Features

- **Header-only**: Single header file, no external dependencies
- **C++20**: Uses modern C++ features
- **Strict CSV parsing**: Handles quoted fields, escaped quotes, and embedded newlines
- **Input validation**: Rejects malformed input with `std::invalid_argument`
- **Overflow protection**: Detects integer overflow during parsing and aggregation
- **Sorted output**: Returns `std::map` with keys sorted alphabetically

## Usage

```cpp
#include "solution.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::string csv = R"(
category,amount
food,100
rent,500
food,50
)";
    
    std::istringstream iss(csv);
    auto result = aggregate(iss);
    
    for (const auto& [category, total] : result) {
        std::cout << category << ": " << total << std::endl;
    }
    
    return 0;
}
```

## CSV Format

The input must follow these rules:

1. **Header**: First line must be exactly `category,amount`
2. **Fields**: Each row must have exactly 2 fields
3. **Quoted fields**: Fields containing commas, newlines, or quotes must be enclosed in double quotes
4. **Escaped quotes**: Double quotes within quoted fields must be escaped as `""`
5. **Whitespace**: Outer spaces/tabs/CR are stripped from fields
6. **Numbers**: Amount must be a valid signed 64-bit integer

## Error Handling

The function throws `std::invalid_argument` for:

- Empty input
- Invalid header
- Wrong number of fields per row
- Empty category or amount fields
- Invalid number format
- Integer overflow during parsing or aggregation
- Unterminated quoted fields

## Example

Input:
```csv
category,amount
"x""quote",100
food,200
"two
lines",300
```

Output:
```cpp
{
  "food": 200,
  "two\nlines": 300,
  "x\"quote": 100
}
```

## Implementation Notes

- The entire input stream is read into memory to handle embedded newlines in quoted fields
- Aggregation uses `std::int64_t` for amounts
- Keys are stored in a `std::map` for automatic sorting
