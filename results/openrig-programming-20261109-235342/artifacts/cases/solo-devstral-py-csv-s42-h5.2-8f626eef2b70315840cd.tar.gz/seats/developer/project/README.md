# CSV Aggregator

This solution implements a CSV aggregator that reads a CSV file as a stream and aggregates amounts by category using exact decimal arithmetic.

## Features

- Reads CSV files as a stream (does not load entire file into memory)
- Handles CSV quoting and embedded newlines
- Validates header format (category,amount)
- Ignores blank records
- Strips whitespace from category and amount fields
- Validates category is not empty
- Validates amount format: optional +, 1-12 digits, optional decimal with 1-2 digits
- Uses exact decimal arithmetic for precision
- Returns sorted categories with totals formatted to 2 decimal places

## API

```python
from solution import aggregate

result = aggregate(path: str) -> dict[str, str]
```

## Implementation Details

- Uses Python's `csv` module for proper CSV parsing
- Uses `Decimal` for exact arithmetic
- Validates amount format before parsing to ensure correctness
- Handles edge cases like NaN, infinity, negative amounts, and exponents

## Testing

Run tests with:
```bash
python -m unittest test_solution -v
```

Or discover tests:
```bash
python -m unittest discover -s . -p 'test_*.py' -v
```
