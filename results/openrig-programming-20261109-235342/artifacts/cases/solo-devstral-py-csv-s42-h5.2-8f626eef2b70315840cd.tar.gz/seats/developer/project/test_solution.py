"""
Test cases for the CSV aggregator solution.
"""
import unittest
import tempfile
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for aggregate function."""
    
    def test_basic_case(self):
        """Test basic CSV aggregation."""
        csv_content = """category,amount
food,100.50
rent,200.75
food,50.25
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            result = aggregate(temp_path)
            self.assertEqual(result, {
                'food': '150.75',
                'rent': '200.75'
            })
        finally:
            os.unlink(temp_path)
    
    def test_quoted_fields(self):
        """Test CSV with quoted fields containing commas and newlines."""
        csv_content = """category,amount
"a,b",100.50
"two
lines",200.75
"x""quote",50.25
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            result = aggregate(temp_path)
            self.assertEqual(result, {
                'a,b': '100.50',
                'two\nlines': '200.75',
                'x"quote': '50.25'
            })
        finally:
            os.unlink(temp_path)
    
    def test_blank_records(self):
        """Test CSV with blank records."""
        csv_content = """category,amount
food,100.50

rent,200.75

food,50.25
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            result = aggregate(temp_path)
            self.assertEqual(result, {
                'food': '150.75',
                'rent': '200.75'
            })
        finally:
            os.unlink(temp_path)
    
    def test_invalid_header(self):
        """Test invalid header raises ValueError."""
        csv_content = """wrong,amount
food,100.50
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_invalid_row_length(self):
        """Test row with wrong number of fields raises ValueError."""
        csv_content = """category,amount
food,100.50,extra
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_empty_category(self):
        """Test empty category raises ValueError."""
        csv_content = """category,amount
,100.50
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_invalid_amount(self):
        """Test invalid amount format raises ValueError."""
        csv_content = """category,amount
food,abc
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_negative_amount(self):
        """Test negative amount raises ValueError."""
        csv_content = """category,amount
food,-100.50
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_nan_amount(self):
        """Test NaN amount raises ValueError."""
        csv_content = """category,amount
food,NaN
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_amount_with_exponent(self):
        """Test amount with exponent raises ValueError."""
        csv_content = """category,amount
food,1e10
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_amount_too_many_decimal_places(self):
        """Test amount with too many decimal places raises ValueError."""
        csv_content = """category,amount
food,100.123
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_amount_too_many_integer_digits(self):
        """Test amount with too many integer digits raises ValueError."""
        csv_content = """category,amount
food,1234567890123.45
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_unquoted_newline(self):
        """Test unquoted newline in amount raises ValueError."""
        csv_content = """category,amount
food,x,1
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            temp_path = f.name
        
        try:
            with self.assertRaises(ValueError):
                aggregate(temp_path)
        finally:
            os.unlink(temp_path)


if __name__ == '__main__':
    unittest.main()
