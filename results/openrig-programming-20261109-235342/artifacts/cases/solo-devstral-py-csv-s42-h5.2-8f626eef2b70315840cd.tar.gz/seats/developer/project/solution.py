"""
CSV Aggregator Solution

Implements aggregate(path: str) -> dict[str, str] that reads a CSV file
as a stream and aggregates amounts by category using exact decimal arithmetic.
"""
import csv
from decimal import Decimal, InvalidOperation, getcontext

# Set decimal precision to handle the maximum possible amount
getcontext().prec = 28


def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary with category keys sorted, values formatted to 2 decimal places
        
    Raises:
        ValueError: If CSV format is invalid or amounts are malformed
    """
    totals = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        # Read header
        try:
            header = next(reader)
        except StopIteration:
            # Empty file
            return {}
        
        # Validate header
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        for row in reader:
            # Skip blank records
            if not row:
                continue
            
            # Validate row has exactly 2 fields
            if len(row) != 2:
                raise ValueError("Row must have exactly 2 fields")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Validate category is not empty
            if not category:
                raise ValueError("Category cannot be empty")
            
            # Validate amount string format (optional +, 1-12 digits, optional decimal with 1-2 digits)
            # Remove leading + if present
            amount_str_clean = amount_str.lstrip('+')
            
            # Check for exponent (e or E)
            if 'e' in amount_str_clean.lower():
                raise ValueError("Invalid amount format")
            
            # Check format
            if '.' in amount_str_clean:
                integer_part, fractional_part = amount_str_clean.split('.', 1)
                # Integer part: 1-12 digits
                if not integer_part or len(integer_part) > 12:
                    raise ValueError("Invalid amount format")
                # Fractional part: 1-2 digits
                if not fractional_part or len(fractional_part) > 2:
                    raise ValueError("Invalid amount format")
            else:
                # No decimal point: 1-12 digits
                if not amount_str_clean or len(amount_str_clean) > 12:
                    raise ValueError("Invalid amount format")
            
            # Parse and validate amount
            try:
                amount = Decimal(amount_str)
                # Validate amount format: nonnegative, finite, no exponent
                if amount < 0:
                    raise ValueError("Amount must be nonnegative")
                if amount.is_nan() or amount.is_infinite():
                    raise ValueError("Amount must be finite")
            except InvalidOperation:
                raise ValueError("Invalid amount format")
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted categories with totals formatted to 2 decimal places
    return {k: format(totals[k], '.2f') for k in sorted(totals.keys())}
