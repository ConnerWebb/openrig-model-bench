import unittest
import tempfile
import os
from solution import aggregate

class TestAggregate(unittest.TestCase):
    
    def test_basic_functionality(self):
        # Test with a simple case
        csv_content = """category,amount
food,100.00
rent,200.00
food,50.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            expected = {"food": "150.00", "rent": "200.00"}
            self.assertEqual(result, expected)
            os.unlink(f.name)
    
    def test_sorted_keys(self):
        # Test that keys are sorted
        csv_content = """category,amount
zebra,100.00
apple,50.00
banana,75.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            expected_keys = ["apple", "banana", "zebra"]
            self.assertEqual(list(result.keys()), expected_keys)
            os.unlink(f.name)
    
    def test_decimal_precision(self):
        # Test with precise decimal values
        csv_content = """category,amount
test,0.1
test,0.2
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result["test"], "0.30")
            os.unlink(f.name)
    
    def test_empty_categories(self):
        # Test that empty categories raise ValueError
        csv_content = """category,amount
,100.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_invalid_header(self):
        # Test that wrong header raises ValueError
        csv_content = """wrong,amount
test,100.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_invalid_amount_format(self):
        # Test that invalid amount format raises ValueError
        csv_content = """category,amount
test,invalid
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_negative_amount(self):
        # Test that negative amounts raise ValueError
        csv_content = """category,amount
test,-100.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_blank_rows(self):
        # Test that blank rows are ignored
        csv_content = """category,amount

food,100.00

rent,200.00

"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            expected = {"food": "100.00", "rent": "200.00"}
            self.assertEqual(result, expected)
            os.unlink(f.name)
    
    def test_quoted_fields(self):
        # Test that quoted fields work correctly
        csv_content = """category,amount
"a,b",100.00
"two\nlines",200.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            expected = {"a,b": "100.00", "two\nlines": "200.00"}
            self.assertEqual(result, expected)
            os.unlink(f.name)

if __name__ == '__main__':
    unittest.main()