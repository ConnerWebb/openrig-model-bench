# CSV Aggregator Solution

This solution implements the `aggregate` function that reads a CSV file and aggregates amounts by category.

## Function Signature
```python
def aggregate(path: str) -> Dict[str, str]
```

## Requirements Met

1. **Read UTF-8 CSV as a stream** - Uses csv.reader for streaming parsing
2. **Header validation** - Requires exactly "category,amount" header
3. **Blank record handling** - Ignores completely blank records
4. **Field validation** - Ensures exactly two fields per record
5. **Whitespace handling** - Strips category whitespace, validates non-empty category
6. **Amount validation** - 
   - Optional + sign
   - 1-12 digits before decimal point
   - Optional decimal point followed by 1-2 digits
   - Non-negative and finite values
7. **Error handling** - Raises ValueError for all malformed inputs
8. **Exact decimal arithmetic** - Uses Python's Decimal for precise calculations
9. **Formatted output** - Returns totals with exactly 2 decimal places
10. **Sorted keys** - Returns categories in sorted order
11. **CSV quoting** - Handles quoted commas and embedded newlines correctly

## Implementation Details

- Uses `csv.reader` to properly handle CSV quoting and embedded newlines
- Validates amount format using regex-like checks and Decimal validation
- Accumulates using exact decimal arithmetic
- Formats results with `quantize(Decimal('0.01'))` for exactly 2 decimal places
- Sorts category keys alphabetically
- Handles edge cases like empty files, malformed headers, and invalid amounts

## Usage

```python
import solution

result = solution.aggregate('path/to/your/file.csv')
print(result)
```