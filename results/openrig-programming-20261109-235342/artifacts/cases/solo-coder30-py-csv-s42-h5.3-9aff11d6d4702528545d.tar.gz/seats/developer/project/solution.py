import csv
import decimal
from decimal import Decimal
from typing import Dict
import io

def aggregate(path: str) -> Dict[str, str]:
    """
    Aggregate CSV data by category, summing amounts with exact decimal arithmetic.
    
    Args:
        path: Path to UTF-8 CSV file with header 'category,amount'
        
    Returns:
        Dict[str, str] with category keys sorted and totals formatted to 2 decimal places
        
    Raises:
        ValueError: For malformed input
    """
    # Set decimal precision high enough for exact arithmetic
    decimal.getcontext().prec = 50
    
    # Dictionary to store totals
    totals = {}
    
    # Open file and parse CSV
    with open(path, 'r', encoding='utf-8', newline='') as f:
        # Use csv.reader to handle quoted commas and embedded newlines
        reader = csv.reader(f)
        
        # Read header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
            
        if header != ['category', 'amount']:
            raise ValueError("Header must be exactly 'category,amount'")
        
        # Process each row
        for row_num, row in enumerate(reader, start=2):  # Start at 2 since header is row 1
            # Skip completely blank rows
            if not any(row):
                continue
                
            # Each row must have exactly 2 fields
            if len(row) != 2:
                raise ValueError(f"Row {row_num} must have exactly 2 fields")
                
            category, amount_str = row
            
            # Strip whitespace from category
            category = category.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError(f"Row {row_num} has empty category")
                
            # Parse amount
            try:
                # Validate amount format using regex-like approach
                amount_str = amount_str.strip()
                if not amount_str:
                    raise ValueError(f"Row {row_num} has empty amount")
                    
                # Check for valid amount format: optional +, 1-12 digits, optional decimal point, 1-2 digits
                # This is a simplified validation - we'll use Decimal to validate
                amount = Decimal(amount_str)
                
                # Check if amount is non-negative and finite
                if amount < 0 or not amount.is_finite():
                    raise ValueError(f"Row {row_num} has invalid amount: {amount_str}")
                    
                # Check if amount has at most 12 digits before decimal and 2 after
                # Convert to string to check format
                amount_repr = str(amount)
                if 'e' in amount_repr.lower():
                    raise ValueError(f"Row {row_num} has invalid amount format: {amount_str}")
                    
                # Check if it has at most 12 digits before decimal point and 2 after
                if '.' in amount_repr:
                    before_decimal, after_decimal = amount_repr.split('.')
                    if len(before_decimal) > 12 or len(after_decimal) > 2:
                        raise ValueError(f"Row {row_num} has invalid amount format: {amount_str}")
                else:
                    if len(amount_repr) > 12:
                        raise ValueError(f"Row {row_num} has invalid amount format: {amount_str}")
                        
            except decimal.InvalidOperation:
                raise ValueError(f"Row {row_num} has invalid amount: {amount_str}")
            
            # Accumulate totals
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly 2 decimal places and return sorted
    result = {}
    for category in sorted(totals.keys()):
        # Use quantize to ensure exactly 2 decimal places
        formatted_amount = totals[category].quantize(Decimal('0.01'))
        result[category] = str(formatted_amount)
        
    return result