# Arithmetic Expression Evaluator

This module provides a safe arithmetic expression evaluator that supports:
- Addition (+), subtraction (-), multiplication (*), floor division (//)
- Parentheses for grouping
- Unary plus (+) and minus (-)
- Whitespace handling

## Features

- No use of `eval` or `exec`
- No external dependencies (stdlib only)
- Proper operator precedence
- Floor division following Python semantics for negatives
- Comprehensive validation:
  - Text length limit (4096 characters)
  - Integer token digit limit (50 digits)
  - Nesting depth limit (100 levels)
  - Intermediate value range check (|value| <= 10^100)
  - Leading zero rejection
  - Division by zero rejection
  - No floats, booleans, variables, or unsupported operators

## Usage

```python
from solution import evaluate

# Basic arithmetic
evaluate("1 + 2 * 3")  # Returns 7
evaluate("(1 + 2) * 3")  # Returns 9

# Floor division
evaluate("7 // 3")  # Returns 2
evaluate("-7 // 3")  # Returns -3 (Python floor division)

# Unary operators
evaluate("-5")  # Returns -5
evaluate("-(2 + 3)")  # Returns -5
```

## Error Handling

All validation errors raise `ValueError` with descriptive messages.

## Testing

Run tests with:
```bash
python -m unittest test_submission.py
```
