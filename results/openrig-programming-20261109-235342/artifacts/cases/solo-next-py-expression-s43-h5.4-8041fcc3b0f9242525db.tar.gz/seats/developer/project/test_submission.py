import unittest
from solution import evaluate

class TestEvaluate(unittest.TestCase):
    
    def test_basic_addition(self):
        self.assertEqual(evaluate("1 + 2"), 3)
        self.assertEqual(evaluate("10 + 20"), 30)
    
    def test_basic_subtraction(self):
        self.assertEqual(evaluate("5 - 3"), 2)
        self.assertEqual(evaluate("10 - 20"), -10)
    
    def test_basic_multiplication(self):
        self.assertEqual(evaluate("3 * 4"), 12)
        self.assertEqual(evaluate("-2 * 3"), -6)
    
    def test_basic_division(self):
        self.assertEqual(evaluate("10 // 3"), 3)
        self.assertEqual(evaluate("-10 // 3"), -4)
        self.assertEqual(evaluate("10 // -3"), -4)
        self.assertEqual(evaluate("-10 // -3"), 3)
    
    def test_precedence(self):
        self.assertEqual(evaluate("2 + 3 * 4"), 14)
        self.assertEqual(evaluate("2 * 3 + 4"), 10)
    
    def test_parentheses(self):
        self.assertEqual(evaluate("(2 + 3) * 4"), 20)
        self.assertEqual(evaluate("((2 + 3) * 4)"), 20)
    
    def test_unary_operators(self):
        self.assertEqual(evaluate("-5"), -5)
        self.assertEqual(evaluate("+5"), 5)
        self.assertEqual(evaluate("--5"), 5)
        self.assertEqual(evaluate("-(2 + 3)"), -5)
    
    def test_whitespace(self):
        self.assertEqual(evaluate("  1 + 2  "), 3)
        self.assertEqual(evaluate("  (  1 + 2 )  "), 3)
    
    def test_negative_numbers(self):
        self.assertEqual(evaluate("(-5)"), -5)
        self.assertEqual(evaluate("(-5) + 3"), -2)
    
    def test_large_numbers(self):
        self.assertEqual(evaluate("1000000000000000000 + 1"), 1000000000000000001)
    
    def test_empty_string(self):
        with self.assertRaises(ValueError):
            evaluate("")
    
    def test_invalid_operator(self):
        with self.assertRaises(ValueError):
            evaluate("1/2")
    
    def test_exponentiation(self):
        with self.assertRaises(ValueError):
            evaluate("2**3")
    
    def test_variable(self):
        with self.assertRaises(ValueError):
            evaluate("a+2")
    
    def test_import(self):
        with self.assertRaises(ValueError):
            evaluate("__import__(\"os\")")
    
    def test_division_by_zero(self):
        with self.assertRaises(ValueError):
            evaluate("1//0")
    
    def test_float(self):
        with self.assertRaises(ValueError):
            evaluate("1.0+2")
    
    def test_bool(self):
        with self.assertRaises(ValueError):
            evaluate("True")
    
    def test_leading_zero(self):
        with self.assertRaises(ValueError):
            evaluate("01")
    
    def test_too_many_digits(self):
        with self.assertRaises(ValueError):
            evaluate("10000000000000000000000000000000000000000000000000000")
    
    def test_deep_nesting(self):
        with self.assertRaises(ValueError):
            evaluate("((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((1))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))")
    
    def test_public_cases(self):
        self.assertEqual(evaluate("(-18 + 30) * 3 // (58)"), 0)
        self.assertEqual(evaluate("(-98 + -33) * 3 // (-61)"), 6)
        self.assertEqual(evaluate("(93 + -49) * 3 // (-33)"), -4)
        self.assertEqual(evaluate("(-78 + -49) * 3 // (31)"), -13)
        self.assertEqual(evaluate("(-86 + 52) * 3 // (-51)"), 2)
        self.assertEqual(evaluate("(29 + -94) * 3 // (77)"), -3)
        self.assertEqual(evaluate("(34 + -7) * 3 // (17)"), 4)
        self.assertEqual(evaluate("(94 + -67) * 3 // (-11)"), -8)

if __name__ == '__main__':
    unittest.main()
