import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import solution
 print(json.dumps({'value':solution.evaluate(x['text'])}))

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
