import re
from typing import List, Tuple, Union

class Tokenizer:
    """Tokenizes the input expression."""
    def __init__(self, text: str):
        self.text = text
        self.pos = 0
        self.tokens: List[Tuple[str, Union[int, str]]] = []
    
    def tokenize(self) -> List[Tuple[str, Union[int, str]]]:
        while self.pos < len(self.text):
            if self.text[self.pos].isspace():
                self.pos += 1
                continue
            
            if self.text[self.pos].isdigit():
                self._read_number()
            elif self.text[self.pos] in '+-':
                # Check if this is a unary operator
                is_unary = False
                if self.pos == 0:
                    is_unary = True
                else:
                    # Look back to see if previous token is an operator or opening paren
                    temp_pos = self.pos - 1
                    while temp_pos >= 0 and self.text[temp_pos].isspace():
                        temp_pos -= 1
                    if temp_pos < 0 or self.text[temp_pos] in '+-*/(':
                        is_unary = True
                
                if is_unary:
                    # This is a unary + or -
                    self.tokens.append(('OP', self.text[self.pos]))
                    self.pos += 1
                else:
                    self.tokens.append(('OP', self.text[self.pos]))
                    self.pos += 1
            elif self.text[self.pos] == '*':
                self.tokens.append(('OP', '*'))
                self.pos += 1
            elif self.text[self.pos] == '/':
                if self.pos + 1 < len(self.text) and self.text[self.pos + 1] == '/':
                    self.tokens.append(('OP', '//'))
                    self.pos += 2
                else:
                    raise ValueError("Unsupported operator /")
            elif self.text[self.pos] == '(':
                self.tokens.append(('OP', '('))
                self.pos += 1
            elif self.text[self.pos] == ')':
                self.tokens.append(('OP', ')'))
                self.pos += 1
            else:
                raise ValueError(f"Invalid character: {self.text[self.pos]}")
        
        return self.tokens
    
    def _read_number(self):
        start = self.pos
        while self.pos < len(self.text) and self.text[self.pos].isdigit():
            self.pos += 1
        
        num_str = self.text[start:self.pos]
        
        # Check for leading zeros (except for "0" itself)
        if len(num_str) > 1 and num_str[0] == '0':
            raise ValueError("Leading zero in integer")
        
        # Check for more than 50 digits
        if len(num_str) > 50:
            raise ValueError("Integer too large")
        
        num = int(num_str)
        self.tokens.append(('NUM', num))


class Parser:
    """Recursive descent parser for arithmetic expressions."""
    def __init__(self, tokens: List[Tuple[str, Union[int, str]]]):
        self.tokens = tokens
        self.pos = 0
        self.max_depth = 100
        self.current_depth = 0
    
    def parse(self) -> int:
        result = self._parse_expression()
        if self.pos < len(self.tokens):
            raise ValueError("Unexpected token")
        return result
    
    def _parse_expression(self) -> int:
        return self._parse_additive()
    
    def _parse_additive(self) -> int:
        left = self._parse_multiplicative()
        
        while self.pos < len(self.tokens) and self.tokens[self.pos] == ('OP', '+'):
            self.pos += 1
            right = self._parse_multiplicative()
            left = left + right
        
        while self.pos < len(self.tokens) and self.tokens[self.pos] == ('OP', '-'):
            self.pos += 1
            right = self._parse_multiplicative()
            left = left - right
        
        return left
    
    def _parse_multiplicative(self) -> int:
        left = self._parse_unary()
        
        while self.pos < len(self.tokens) and self.tokens[self.pos] == ('OP', '*'):
            self.pos += 1
            right = self._parse_unary()
            left = left * right
        
        while self.pos < len(self.tokens) and self.tokens[self.pos] == ('OP', '//'):
            self.pos += 1
            right = self._parse_unary()
            if right == 0:
                raise ValueError("Division by zero")
            # Python floor division for negatives
            left = left // right
        
        return left
    
    def _parse_unary(self) -> int:
        if self.pos < len(self.tokens) and self.tokens[self.pos] == ('OP', '+'):
            self.pos += 1
            return self._parse_unary()
        
        if self.pos < len(self.tokens) and self.tokens[self.pos] == ('OP', '-'):
            self.pos += 1
            return -self._parse_unary()
        
        return self._parse_primary()
    
    def _parse_primary(self) -> int:
        if self.pos >= len(self.tokens):
            raise ValueError("Unexpected end of expression")
        
        token = self.tokens[self.pos]
        
        if token[0] == 'NUM':
            self.pos += 1
            return token[1]
        
        if token == ('OP', '('):
            self.pos += 1
            self.current_depth += 1
            if self.current_depth > self.max_depth:
                raise ValueError("Maximum nesting depth exceeded")
            result = self._parse_expression()
            if self.pos >= len(self.tokens) or self.tokens[self.pos] != ('OP', ')'):
                raise ValueError("Missing closing parenthesis")
            self.pos += 1
            self.current_depth -= 1
            return result
        
        raise ValueError("Unexpected token")


def evaluate(text: str) -> int:
    """Evaluate an arithmetic expression and return the integer result."""
    # Check text length
    if len(text) > 4096:
        raise ValueError("Expression too long")
    
    # Empty string is invalid
    if not text or text.strip() == '':
        raise ValueError("Empty expression")
    
    # Tokenize
    tokenizer = Tokenizer(text)
    tokens = tokenizer.tokenize()
    
    if not tokens:
        raise ValueError("No tokens found")
    
    # Parse and evaluate
    parser = Parser(tokens)
    result = parser.parse()
    
    # Check for intermediate values exceeding 10**100
    if abs(result) > 10**100:
        raise ValueError("Result too large")
    
    return result
