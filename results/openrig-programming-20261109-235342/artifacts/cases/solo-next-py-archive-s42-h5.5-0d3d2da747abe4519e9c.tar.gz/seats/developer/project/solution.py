import os
import zipfile
import shutil


def extract_zip(archive_path, outdir):
    """
    Extract a ZIP archive into a NEW directory, returning sorted member file paths.
    Reject with ValueError before creating any output if:
    - outdir exists
    - any member is absolute
    - contains .. components
    - backslashes
    - drive-colon (e.g., C:)
    - duplicate normalized file/directory path
    - a symbolic link
    """
    # Validate outdir does not exist
    if os.path.exists(outdir):
        raise ValueError("Output directory already exists")

    # Read ZIP and validate all entries before extraction
    with zipfile.ZipFile(archive_path, 'r') as zf:
        # Get all names from the ZIP
        names = zf.namelist()

        # Validate each entry
        seen_paths = set()
        has_dir = set()  # paths that are directories (end with /)
        has_file = set()  # paths that are files (don't end with /)

        for name in names:
            # Check for symbolic links
            info = zf.getinfo(name)
            is_dir = name.endswith('/')
            if not is_dir and (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Symbolic link detected")

            # Normalize path for validation
            normalized = name.replace('\\', '/')

            # Check for backslashes (already replaced, but original had them)
            if '\\' in name:
                raise ValueError("Backslash in path")

            # Check for absolute path
            if normalized.startswith('/') or normalized.startswith('\\'):
                raise ValueError("Absolute path detected")

            # Check for drive colon (e.g., C:)
            if len(normalized) >= 2 and normalized[1] == ':' and normalized[0].isalpha():
                raise ValueError("Drive colon detected")

            # Check for .. components
            parts = normalized.split('/')
            for part in parts:
                if part == '..':
                    raise ValueError(".. component in path")

            # Normalize path (resolve . and .. if any, though .. already rejected)
            try:
                norm_path = os.path.normpath(normalized)
            except Exception:
                raise ValueError("Invalid path")

            # For directories, remove trailing slash for comparison
            if is_dir:
                norm_path = norm_path.rstrip('/')
                has_dir.add(norm_path)
            else:
                has_file.add(norm_path)

            # Check for exact duplicates
            if norm_path in seen_paths:
                raise ValueError("Duplicate path")
            seen_paths.add(norm_path)

        # Now check for conflicts between files and directories
        # A conflict occurs when:
        # 1. A path appears both as a file and directory
        # 2. A file path is a parent of another file path (e.g., "a" and "a/b")

        # Check for paths that are both files and directories
        for path in has_dir:
            if path in has_file:
                raise ValueError("Duplicate path")

        # Check for file-parent conflicts
        # If "a" is a file, then "a/b" cannot exist (because "a" is not a directory)
        for file_path in has_file:
            # Check if any other file is inside this file's path
            for other_file in has_file:
                if other_file != file_path and other_file.startswith(file_path + '/'):
                    raise ValueError("Conflicting paths")

        # Create output directory
        os.makedirs(outdir, exist_ok=True)

        # Extract all entries
        for name in names:
            info = zf.getinfo(name)
            is_dir = name.endswith('/')

            if is_dir:
                # Create directory
                dir_path = os.path.join(outdir, name.rstrip('/'))
                os.makedirs(dir_path, exist_ok=True)
            else:
                # Extract file
                file_path = os.path.join(outdir, name)
                # Ensure parent directory exists
                parent_dir = os.path.dirname(file_path)
                if parent_dir:
                    os.makedirs(parent_dir, exist_ok=True)
                # Write file content
                with zf.open(name) as src, open(file_path, 'wb') as dst:
                    dst.write(src.read())

    # Return sorted list of file paths (relative to outdir)
    result = []
    for root, dirs, files in os.walk(outdir):
        for f in files:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, outdir)
            result.append(rel_path)

    return sorted(result)
