# extract_zip Implementation

This project implements `extract_zip(archive_path, outdir) -> list[str]` which extracts a ZIP archive into a new directory and returns sorted member file paths.

## Validation Rules

The function raises `ValueError` before creating any output if:
- `outdir` already exists
- Any member path is absolute
- Any member contains `..` components
- Any member contains backslashes
- Any member contains a drive colon (e.g., `C:`)
- Duplicate normalized file/directory paths exist
- Any member is a symbolic link

## Usage

```python
from solution import extract_zip

# Extract a ZIP file
files = extract_zip('archive.zip', '/path/to/output')
print(files)  # ['file1.txt', 'folder/file2.txt']
```

## Tests

Run tests with:
```bash
python test_solution.py
```
