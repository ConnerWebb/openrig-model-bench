import unittest
import os
import tempfile
import zipfile
import shutil
from solution import extract_zip


class TestExtractZip(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_basic_extraction(self):
        # Create a test ZIP
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('folder/', '')
            zf.writestr('folder/a.txt', 'content a')
            zf.writestr('b.txt', 'content b')

        result = extract_zip(zip_path, out_dir)
        self.assertEqual(result, ['b.txt', 'folder/a.txt'])
        self.assertTrue(os.path.isfile(os.path.join(out_dir, 'b.txt')))
        self.assertTrue(os.path.isfile(os.path.join(out_dir, 'folder/a.txt')))

    def test_output_dir_exists_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')
        os.makedirs(out_dir)

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('file.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_absolute_path_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('/absolute/path.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_double_dot_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('../escape.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_backslash_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('bad\\path.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_drive_colon_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('C:bad.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_duplicate_paths_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('file.txt', 'content1')
            zf.writestr('file.txt', 'content2')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_directory_file_conflict_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a', 'content')  # file
            zf.writestr('a/b.txt', 'content')  # file in subdirectory - conflict!

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_symlink_raises(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            info = zipfile.ZipInfo('link')
            info.external_attr = (0o120777 << 16)
            zf.writestr(info, '/elsewhere')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, out_dir)

    def test_empty_zip_creates_empty_dir(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            pass

        result = extract_zip(zip_path, out_dir)
        self.assertEqual(result, [])
        self.assertTrue(os.path.isdir(out_dir))

    def test_utf8_content(self):
        zip_path = os.path.join(self.test_dir, 'test.zip')
        out_dir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('utf8.txt', 'hello 日本')

        result = extract_zip(zip_path, out_dir)
        self.assertEqual(result, ['utf8.txt'])
        with open(os.path.join(out_dir, 'utf8.txt'), 'r', encoding='utf-8') as f:
            self.assertEqual(f.read(), 'hello 日本')


if __name__ == '__main__':
    unittest.main()
