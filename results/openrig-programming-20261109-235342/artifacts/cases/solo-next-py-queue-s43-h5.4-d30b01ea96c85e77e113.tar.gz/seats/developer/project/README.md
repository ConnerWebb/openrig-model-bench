# JobQueue

A SQLite-backed job queue implementation with claim/complete/fail semantics.

## API

### `JobQueue(path, max_attempts=3)`

Create a new job queue using SQLite at `path`. `max_attempts` is the maximum number of claim attempts before a job is marked as failed.

### `enqueue(key, payload) -> bool`

Add a job with unique `key` and JSON-compatible `payload`. Returns `True` if inserted, `False` if key already exists.

### `claim(worker, now, lease) -> dict or None`

Atomically claim the oldest queued or leased job that has not exceeded `max_attempts`. Sets job state to `leased`, assigns `owner` and `lease_until`. Returns `{key, payload, attempts}` or `None` if no job available.

### `complete(key, worker) -> bool`

Mark a leased job as `done`. Requires matching `worker` owner.

### `fail(key, worker) -> bool`

Return a leased job to `queued` state (if attempts remain) or mark as `failed` (if attempts exhausted). Requires matching `worker` owner.

### `status(key) -> dict or None`

Return `{state, attempts}` for a job, or `None` if not found.

## Validation

- `key` and `worker` must be non-empty strings.
- `lease` must be positive.
- `max_attempts` must be a positive integer.
- Invalid arguments raise `ValueError`.

## Thread Safety

Uses SQLite WAL mode and a global lock to ensure safe concurrent access across threads and processes.
