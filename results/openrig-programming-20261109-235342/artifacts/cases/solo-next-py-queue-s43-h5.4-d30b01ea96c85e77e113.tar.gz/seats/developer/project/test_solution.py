import unittest
import tempfile
import os
import json
import time
import threading
import sqlite3

from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_enqueue_unique_key(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("key1", {"data": 1}))
        self.assertFalse(q.enqueue("key1", {"data": 2}))

    def test_claim_basic(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        result = q.claim("worker1", 0, 10)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": 1})
        self.assertEqual(result["attempts"], 1)

    def test_claim_no_available_jobs(self):
        q = JobQueue(self.db_path)
        result = q.claim("worker1", 0, 10)
        self.assertIsNone(result)

    def test_claim_leased_job_not_available(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 10)
        result = q.claim("worker2", 0, 10)
        self.assertIsNone(result)

    def test_claim_expired_lease(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 5)
        result = q.claim("worker2", 10, 10)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")

    def test_complete_success(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 10)
        self.assertTrue(q.complete("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 10)
        self.assertFalse(q.complete("key1", "worker2"))

    def test_fail_success(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 10)
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")

    def test_fail_exhausted_attempts(self):
        q = JobQueue(self.db_path, max_attempts=1)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 10)
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "failed")

    def test_status_not_found(self):
        q = JobQueue(self.db_path)
        status = q.status("nonexistent")
        self.assertIsNone(status)

    def test_invalid_arguments(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue("", {"data": 1})
        with self.assertRaises(ValueError):
            q.claim("", 0, 10)
        with self.assertRaises(ValueError):
            q.claim("worker", 0, 0)
        with self.assertRaises(ValueError):
            q.claim("worker", 0, -1)
        with self.assertRaises(ValueError):
            q.complete("", "worker")
        with self.assertRaises(ValueError):
            q.fail("", "worker")
        with self.assertRaises(ValueError):
            q.status("")
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_claim_oldest_first(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        time.sleep(0.01)
        q.enqueue("key2", {"data": 2})
        result = q.claim("worker1", 0, 10)
        self.assertEqual(result["key"], "key1")

    def test_multiple_workers_claim(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.enqueue("key2", {"data": 2})
        result1 = q.claim("worker1", 0, 10)
        result2 = q.claim("worker2", 0, 10)
        self.assertEqual(result1["key"], "key1")
        self.assertEqual(result2["key"], "key2")

    def test_status_after_claim(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 0, 10)
        status = q.status("key1")
        self.assertEqual(status["state"], "leased")
        self.assertEqual(status["attempts"], 1)

    def test_claim_attempts_increment(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        result1 = q.claim("worker1", 0, 10)
        self.assertEqual(result1["attempts"], 1)
        q.fail("key1", "worker1")
        result2 = q.claim("worker2", 0, 10)
        self.assertEqual(result2["attempts"], 2)

    def test_shared_database(self):
        db_path2 = os.path.join(self.tmpdir, "shared.db")
        q1 = JobQueue(db_path2)
        q2 = JobQueue(db_path2)
        q1.enqueue("key1", {"data": 1})
        result = q2.claim("worker1", 0, 10)
        self.assertEqual(result["key"], "key1")

    def test_concurrent_access(self):
        db_path2 = os.path.join(self.tmpdir, "concurrent.db")
        q = JobQueue(db_path2)
        for i in range(10):
            q.enqueue(f"key{i}", {"data": i})

        results = []
        lock = threading.Lock()

        def worker(wid):
            q = JobQueue(db_path2)
            for _ in range(2):
                r = q.claim(f"worker{wid}", 0, 10)
                if r:
                    with lock:
                        results.append(r["key"])
                    time.sleep(0.01)
                    q.complete(r["key"], f"worker{wid}")

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(results), 10)
        self.assertEqual(len(set(results)), 10)


if __name__ == "__main__":
    unittest.main()
