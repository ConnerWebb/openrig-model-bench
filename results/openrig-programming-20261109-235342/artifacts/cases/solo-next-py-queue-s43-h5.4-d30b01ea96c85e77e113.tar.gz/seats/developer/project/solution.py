import sqlite3
import json
import threading
import time
from typing import Optional, Dict, Any


class JobQueue:
    _lock = threading.Lock()

    def __init__(self, path: str, max_attempts: int = 3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self._path = path
        self._max_attempts = max_attempts
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(self._path, isolation_level=None)
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        with JobQueue._lock:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    owner TEXT,
                    lease_until REAL,
                    inserted_at REAL NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_state_lease ON jobs(state, lease_until, inserted_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_owner ON jobs(owner)")

    def enqueue(self, key: str, payload: Any) -> bool:
        if not isinstance(key, str) or not key:
            raise ValueError("key must be a non-empty string")
        payload_json = json.dumps(payload)
        with JobQueue._lock:
            conn = self._get_conn()
            try:
                conn.execute(
                    "INSERT INTO jobs (key, payload, state, attempts, inserted_at) VALUES (?, ?, 'queued', 0, ?)",
                    (key, payload_json, time.time())
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not isinstance(worker, str) or not worker:
            raise ValueError("worker must be a non-empty string")
        if lease <= 0:
            raise ValueError("lease must be positive")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute(
                """
                SELECT key, payload, attempts, state FROM jobs
                WHERE state IN ('queued', 'leased') AND attempts < ? AND (lease_until IS NULL OR lease_until <= ?)
                ORDER BY inserted_at ASC LIMIT 1
                """,
                (self._max_attempts, now)
            )
            row = cursor.fetchone()
            if row is None:
                return None
            key, payload_json, attempts, state = row
            payload = json.loads(payload_json)
            lease_until = now + lease
            new_attempts = attempts + 1
            conn.execute(
                "UPDATE jobs SET state='leased', owner=?, lease_until=?, attempts=? WHERE key=?",
                (worker, lease_until, new_attempts, key)
            )
            # If this was the last allowed attempt and the job was already leased, it becomes failed
            if state == 'leased' and new_attempts >= self._max_attempts:
                conn.execute("UPDATE jobs SET state='failed' WHERE key=?", (key,))
                return None
            return {"key": key, "payload": payload, "attempts": new_attempts}

    def complete(self, key: str, worker: str) -> bool:
        if not isinstance(key, str) or not key:
            raise ValueError("key must be a non-empty string")
        if not isinstance(worker, str) or not worker:
            raise ValueError("worker must be a non-empty string")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT owner FROM jobs WHERE key=? AND state='leased'", (key,))
            row = cursor.fetchone()
            if row is None or row[0] != worker:
                return False
            conn.execute("UPDATE jobs SET state='done' WHERE key=? AND state='leased' AND owner=?", (key, worker))
            return True

    def fail(self, key: str, worker: str) -> bool:
        if not isinstance(key, str) or not key:
            raise ValueError("key must be a non-empty string")
        if not isinstance(worker, str) or not worker:
            raise ValueError("worker must be a non-empty string")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT owner, attempts, state FROM jobs WHERE key=? AND state='leased'", (key,))
            row = cursor.fetchone()
            if row is None or row[0] != worker:
                return False
            owner, attempts, state = row
            if attempts >= self._max_attempts:
                conn.execute("UPDATE jobs SET state='failed' WHERE key=? AND state='leased' AND owner=?", (key, worker))
            else:
                conn.execute("UPDATE jobs SET state='queued', owner=NULL, lease_until=NULL WHERE key=? AND state='leased' AND owner=?", (key, worker))
            return True

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not isinstance(key, str) or not key:
            raise ValueError("key must be a non-empty string")
        with JobQueue._lock:
            conn = self._get_conn()
            cursor = conn.execute("SELECT state, attempts FROM jobs WHERE key=?", (key,))
            row = cursor.fetchone()
            if row is None:
                return None
            return {"state": row[0], "attempts": row[1]}
