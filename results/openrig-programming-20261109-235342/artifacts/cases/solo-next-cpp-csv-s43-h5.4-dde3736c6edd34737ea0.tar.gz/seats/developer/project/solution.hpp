#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <cctype>

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

bool is_digit(char c) {
    return c >= '0' && c <= '9';
}

bool is_sign(char c) {
    return c == '+' || c == '-';
}

bool is_valid_digit_sequence(const std::string& s, size_t start, size_t len) {
    if (len == 0) return false;
    size_t i = 0;
    if (start + i < s.size() && is_sign(s[start + i])) {
        ++i;
        if (i == len) return false; // sign only
    }
    if (start + i >= s.size()) return false;
    if (s[start + i] == '0' && len > i + 1) {
        // leading zero not allowed unless single zero
        return false;
    }
    for (; i < len; ++i) {
        if (!is_digit(s[start + i])) return false;
    }
    return true;
}

bool parse_int64(const std::string& s, std::int64_t& out) {
    std::string trimmed = trim(s);
    if (trimmed.empty()) return false;

    size_t i = 0;
    bool negative = false;
    if (trimmed[i] == '-') {
        negative = true;
        ++i;
    } else if (trimmed[i] == '+') {
        ++i;
    }

    if (i == trimmed.size()) return false;

    // No leading zeros unless single zero
    if (trimmed[i] == '0' && i + 1 < trimmed.size()) return false;

    // No exponent or decimal
    for (size_t j = i; j < trimmed.size(); ++j) {
        if (!is_digit(trimmed[j])) return false;
    }

    std::string digits = trimmed.substr(i);

    // Check overflow against INT64_MIN / INT64_MAX
    // For negative numbers, the range is -9223372036854775808 (INT64_MIN)
    // For positive numbers, the range is 9223372036854775807 (INT64_MAX)
    const std::string max_pos_str = "9223372036854775807"; // 2^63 - 1
    const std::string max_neg_abs_str = "9223372036854775808"; // 2^63

    if (negative) {
        if (digits.size() > max_neg_abs_str.size()) return false;
        if (digits.size() == max_neg_abs_str.size() && digits > max_neg_abs_str) return false;
    } else {
        if (digits.size() > max_pos_str.size()) return false;
        if (digits.size() == max_pos_str.size() && digits > max_pos_str) return false;
    }

    unsigned long long val = 0;
    unsigned long long limit = negative ? 9223372036854775808ULL : 9223372036854775807ULL;
    for (char c : digits) {
        if (val > (limit - (c - '0')) / 10) return false;
        val = val * 10 + (c - '0');
    }
    if (negative) {
        // val is in range [0, 9223372036854775808]
        // We need to convert to int64_t in range [-9223372036854775808, 0]
        if (val == 9223372036854775808ULL) {
            out = INT64_MIN;
        } else {
            out = -static_cast<std::int64_t>(val);
        }
    } else {
        out = static_cast<std::int64_t>(val);
    }
    return true;
}

struct CsvParser {
    std::istream& in;
    bool eof = false;
    int peek_char = -1;

    CsvParser(std::istream& is) : in(is) {
        fill_peek();
    }

    void fill_peek() {
        peek_char = in.peek();
        if (peek_char == EOF) {
            eof = true;
            peek_char = -1;
        }
    }

    int get() {
        int c = peek_char;
        in.get();
        fill_peek();
        return c;
    }

    bool is_eol(int c) {
        return c == '\n' || c == '\r';
    }

    bool is_whitespace(int c) {
        return c == ' ' || c == '\t';
    }

    std::string read_unquoted_field() {
        std::string result;
        while (!eof && !is_eol(peek_char) && peek_char != ',') {
            result += static_cast<char>(get());
        }
        return result;
    }

    std::string read_quoted_field() {
        std::string result;
        while (!eof) {
            int c = get();
            if (c == '"') {
                if (!eof && peek_char == '"') {
                    // Escaped quote
                    result += '"';
                    get();
                } else {
                    // End of quoted field
                    break;
                }
            } else if (c == '\n' || c == '\r') {
                // Embedded newline allowed in quoted field
                result += static_cast<char>(c);
            } else {
                result += static_cast<char>(c);
            }
        }
        return result;
    }

    std::string read_field() {
        if (eof) return "";
        if (peek_char == '"') {
            get(); // consume opening quote
            return read_quoted_field();
        } else {
            return read_unquoted_field();
        }
    }

    bool skip_eol() {
        if (eof) return false;
        if (peek_char == '\r') get();
        if (eof) return false;
        if (peek_char == '\n') get();
        return true;
    }

    bool has_more_lines() {
        // Skip empty lines
        while (!eof && (peek_char == '\n' || peek_char == '\r')) {
            skip_eol();
        }
        return !eof;
    }

    std::vector<std::string> read_line() {
        std::vector<std::string> fields;
        while (!eof) {
            std::string field = read_field();
            fields.push_back(field);
            if (eof || is_eol(peek_char)) break;
            if (peek_char == ',') get(); // consume comma
        }
        // Skip trailing EOL
        if (!eof && is_eol(peek_char)) {
            skip_eol();
        }
        return fields;
    }
};

} // namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    CsvParser parser(in);

    if (!parser.has_more_lines()) {
        throw std::invalid_argument("Empty input");
    }

    // Read header
    auto header = parser.read_line();
    if (header.size() != 2) {
        throw std::invalid_argument("Invalid header field count");
    }
    if (trim(header[0]) != "category" || trim(header[1]) != "amount") {
        throw std::invalid_argument("Invalid header");
    }

    if (!parser.has_more_lines()) {
        throw std::invalid_argument("No data rows");
    }

    std::map<std::string, std::int64_t> result;

    while (parser.has_more_lines()) {
        auto line = parser.read_line();
        if (line.size() != 2) {
            throw std::invalid_argument("Invalid field count in data row");
        }

        std::string category = trim(line[0]);
        std::string amount_str = trim(line[1]);

        if (category.empty()) {
            throw std::invalid_argument("Empty category");
        }
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount");
        }

        std::int64_t amount;
        if (!parse_int64(amount_str, amount)) {
            throw std::invalid_argument("Invalid amount");
        }

        // Check for overflow during addition
        if (amount > 0 && result[category] > INT64_MAX - amount) {
            throw std::invalid_argument("Integer overflow");
        }
        if (amount < 0 && result[category] < INT64_MIN - amount) {
            throw std::invalid_argument("Integer overflow");
        }
        result[category] += amount;
    }

    return result;
}

#endif // SOLUTION_HPP
