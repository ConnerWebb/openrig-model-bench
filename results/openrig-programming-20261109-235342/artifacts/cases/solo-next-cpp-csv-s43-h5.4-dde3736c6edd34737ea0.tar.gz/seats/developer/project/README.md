# CSV Aggregator

A C++ implementation of a CSV parser and aggregator for financial data.

## Features

- Parses CSV files with quoted fields, escaped quotes, and embedded newlines
- Validates integer amounts (int64_t range)
- Aggregates amounts by category
- Throws exceptions for invalid input or integer overflow

## Usage

```cpp
#include "solution.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    for (auto& [k,v] : result) {
        std::cout << k << ": " << v << std::endl;
    }
    return 0;
}
```

## Build

```bash
clang++ -std=c++20 -g -Wall -Wextra -o my_program my_program.cpp
```
