#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 2) throw std::runtime_error("test_basic size");
    if (result["food"] != 100) throw std::runtime_error("test_basic food");
    if (result["rent"] != 200) throw std::runtime_error("test_basic rent");
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nfood,30\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["food"] != -20) throw std::runtime_error("test_negative");
}

void test_quoted_comma() {
    std::string input = "category,amount\n\"a,b\",100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("test_quoted_comma size");
    if (result["a,b"] != 100) throw std::runtime_error("test_quoted_comma val");
}

void test_quoted_newline() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("test_quoted_newline size");
    if (result["two\nlines"] != 100) throw std::runtime_error("test_quoted_newline val");
}

void test_escaped_quote() {
    std::string input = "category,amount\n\"x\"\"quote\",100\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result.size() != 1) throw std::runtime_error("test_escaped_quote size");
    if (result["x\"quote"] != 100) throw std::runtime_error("test_escaped_quote val");
}

void test_header_wrong() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_header_wrong should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_wrong_field_count() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_wrong_field_count should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_empty_category should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_nan() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_nan should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_malformed_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_malformed_quote should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_exponent() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_exponent should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_overflow() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_overflow should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_max_int64() {
    std::string input = "category,amount\nx,9223372036854775807\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["x"] != 9223372036854775807LL) throw std::runtime_error("test_max_int64");
}

void test_negative_overflow() {
    std::string input = "category,amount\nx,-9223372036854775808\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["x"] != -9223372036854775807LL - 1) throw std::runtime_error("test_negative_overflow");
}

void test_positive_overflow() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("test_positive_overflow should throw");
    } catch (const std::invalid_argument&) {
        // expected
    }
}

void test_sign_only() {
    std::string input = "category,amount\nx,+1\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["x"] != 1) throw std::runtime_error("test_sign_only");
}

void test_whitespace_trim() {
    std::string input = "category,amount\n  food  ,  +100  \n";
    std::istringstream in(input);
    auto result = aggregate(in);
    if (result["food"] != 100) throw std::runtime_error("test_whitespace_trim");
}

int main() {
    test_basic();
    test_negative();
    test_quoted_comma();
    test_quoted_newline();
    test_escaped_quote();
    test_header_wrong();
    test_wrong_field_count();
    test_empty_category();
    test_nan();
    test_malformed_quote();
    test_exponent();
    test_overflow();
    test_max_int64();
    test_negative_overflow();
    test_positive_overflow();
    test_sign_only();
    test_whitespace_trim();
    std::cout << "All tests passed" << std::endl;
    return 0;
}
