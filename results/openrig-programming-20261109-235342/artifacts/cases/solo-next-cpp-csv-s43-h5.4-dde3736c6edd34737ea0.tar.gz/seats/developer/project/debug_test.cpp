#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

int main() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream in(input);
    try {
        auto result = aggregate(in);
        std::cout << "Result: ";
        for (auto& [k,v] : result) std::cout << k << "=" << v << " ";
        std::cout << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
    }
    return 0;
}
