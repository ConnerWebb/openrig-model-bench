import unittest
import io
import json
import os
import tempfile
import sys

# Import the C++ implementations via shared library or header-only tests
# Since we're testing C++ code, we'll compile and run a test binary

class TestParser(unittest.TestCase):
    def test_basic_aggregation(self):
        data = "category,amount\nfood,100\nrent,200\nfood,50"
        result = run_cpp_test("test_parser_basic", data)
        self.assertEqual(result, {"food": 150, "rent": 200})

    def test_empty_category_rejected(self):
        data = "category,amount\n,100"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_empty_category", data)

    def test_empty_amount_rejected(self):
        data = "category,amount\nfood,"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_empty_amount", data)

    def test_wrong_header_rejected(self):
        data = "wrong,amount\nfood,100"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_wrong_header", data)

    def test_wrong_column_count_rejected(self):
        data = "category,amount\nfood,100,extra"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_extra_column", data)

    def test_nan_rejected(self):
        data = "category,amount\nfood,Nan"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_nan", data)

    def test_exponent_rejected(self):
        data = "category,amount\nfood,1e2"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_exponent", data)

    def test_overflow_positive_rejected(self):
        data = "category,amount\nfood,9223372036854775808"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_overflow_pos", data)

    def test_overflow_accumulation_rejected(self):
        data = "category,amount\nfood,9223372036854775807\nfood,1"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_overflow_accum", data)

    def test_negative_overflow_rejected(self):
        data = "category,amount\nfood,-9223372036854775808\nfood,-1"
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_overflow_neg", data)

    def test_quoted_fields_with_commas(self):
        data = 'category,amount\n"a,b",100'
        result = run_cpp_test("test_parser_quoted_comma", data)
        self.assertEqual(result, {"a,b": 100})

    def test_quoted_fields_with_newlines(self):
        data = 'category,amount\n"a\\nb",100'
        result = run_cpp_test("test_parser_quoted_newline", data)
        self.assertIn("a\nb", result)

    def test_escaped_quotes_in_quoted_field(self):
        data = 'category,amount\n"a""b",100'
        result = run_cpp_test("test_parser_escaped_quote", data)
        self.assertEqual(result, {"a\"b": 100})

    def test_negative_amounts(self):
        data = "category,amount\nfood,100\nfood,-50"
        result = run_cpp_test("test_parser_negative", data)
        self.assertEqual(result, {"food": 50})

    def test_positive_sign(self):
        data = "category,amount\nfood,+100"
        result = run_cpp_test("test_parser_positive_sign", data)
        self.assertEqual(result, {"food": 100})

    def test_whitespace_trimming(self):
        data = "category,amount\n  food  ,  100  "
        result = run_cpp_test("test_parser_whitespace", data)
        self.assertEqual(result, {"food": 100})

    def test_unmatched_quote_rejected(self):
        data = 'category,amount\n"food,100'
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_unmatched_quote", data)

    def test_quote_in_middle_rejected(self):
        data = 'category,amount\nx"food,100'
        with self.assertRaises(ValueError):
            run_cpp_test("test_parser_quote_middle", data)

    def test_public_cases(self):
        # Load and run all public test cases
        with open("PUBLIC_CASES.json", "r") as f:
            cases = json.load(f)
        for case in cases:
            if "error" in case["expected"]:
                with self.subTest(input=case["driver_input"]):
                    with self.assertRaises(ValueError):
                        run_cpp_test_from_file("test_public_" + case["input_file"], case["driver_input"])
            else:
                with self.subTest(input=case["driver_input"]):
                    result = run_cpp_test_from_file("test_public_" + case["input_file"], case["driver_input"])
                    self.assertEqual(result, case["expected"]["value"])


class TestLruCache(unittest.TestCase):
    def test_basic_put_get(self):
        cache = run_cpp_cache_test("test_cache_basic", [
            ("put", 1, "one"),
            ("get", 1, None),
        ])
        self.assertEqual(cache["get_1"], "one")

    def test_eviction_lru(self):
        cache = run_cpp_cache_test("test_cache_eviction", [
            ("put", 1, "one"),
            ("put", 2, "two"),
            ("put", 1, "ONE"),  # Update makes 1 MRU
            ("put", 3, "three"),
        ])
        # With capacity 2, after putting 3, 2 should be evicted
        self.assertEqual(cache.get("get_1"), "ONE")
        self.assertNotIn("get_2", cache)

    def test_get_makes_mru(self):
        cache = run_cpp_cache_test("test_cache_get_mru", [
            ("put", 1, "one"),
            ("put", 2, "two"),
            ("get", 1, None),  # Access 1, makes it MRU
            ("put", 3, "three"),  # Should evict 2, not 1
        ])
        self.assertEqual(cache.get("get_1"), "one")
        self.assertNotIn("get_2", cache)

    def test_erase(self):
        cache = run_cpp_cache_test("test_cache_erase", [
            ("put", 1, "one"),
            ("erase", 1, None),
            ("get", 1, None),
        ])
        self.assertNotIn("get_1", cache)

    def test_erase_missing_returns_false(self):
        cache = run_cpp_cache_test("test_cache_erase_missing", [
            ("erase", 1, None),
        ])
        # erase on missing key should return false

    def test_capacity_zero(self):
        cache = run_cpp_cache_test("test_cache_zero_cap", [
            ("put", 1, "one"),
            ("get", 1, None),
        ])
        # With capacity 0, nothing should be stored
        self.assertNotIn("get_1", cache)

    def test_snapshot_order(self):
        cache = run_cpp_cache_test("test_cache_snapshot", [
            ("put", 1, "one"),
            ("put", 2, "two"),
            ("get", 1, None),
            ("snapshot", None, None),
        ])
        # Snapshot should return items in MRU order: 1, 2
        snapshot = cache.get("snapshot")
        if snapshot:
            self.assertEqual(snapshot[0][0], 1)
            self.assertEqual(snapshot[1][0], 2)


class TestRunningStats(unittest.TestCase):
    def test_single_value(self):
        stats = run_cpp_stats_test("test_stats_single", [
            ("add", 5.0, None),
        ])
        self.assertEqual(stats["count"], 1)
        self.assertEqual(stats["mean"], 5.0)
        self.assertEqual(stats["minimum"], 5.0)
        self.assertEqual(stats["maximum"], 5.0)

    def test_multiple_values(self):
        stats = run_cpp_stats_test("test_stats_multiple", [
            ("add", 1.0, None),
            ("add", 2.0, None),
            ("add", 3.0, None),
        ])
        self.assertEqual(stats["count"], 3)
        self.assertEqual(stats["mean"], 2.0)

    def test_empty_throws(self):
        stats = run_cpp_stats_test("test_stats_empty", [])
        with self.assertRaises(Exception):
            _ = stats["mean"]
        with self.assertRaises(Exception):
            _ = stats["variance"]
        with self.assertRaises(Exception):
            _ = stats["minimum"]
        with self.assertRaises(Exception):
            _ = stats["maximum"]

    def test_nan_rejected(self):
        stats = run_cpp_stats_test("test_stats_nan", [
            ("add", float('nan'), None),
        ])
        # Should not accept NaN

    def test_infinity_rejected(self):
        stats = run_cpp_stats_test("test_stats_inf", [
            ("add", float('inf'), None),
        ])
        # Should not accept infinity

    def test_merge_empty(self):
        stats = run_cpp_stats_test("test_stats_merge_empty", [
            ("add", 1.0, None),
            ("merge_empty", None, None),
        ])
        # Merging empty should be no-op
        self.assertEqual(stats["count"], 1)

    def test_merge_copies(self):
        stats = run_cpp_stats_test("test_stats_merge_copies", [
            ("add", 1.0, None),
            ("add", 2.0, None),
            ("merge_into_empty", None, None),
        ])
        # Merging into empty should copy
        self.assertEqual(stats["count"], 2)

    def test_self_merge(self):
        stats = run_cpp_stats_test("test_stats_self_merge", [
            ("add", 1.0, None),
            ("add", 2.0, None),
            ("self_merge", None, None),
        ])
        # Self-merge should double count without changing mean/variance
        self.assertEqual(stats["count"], 4)
        self.assertEqual(stats["mean"], 1.5)


def run_cpp_test(test_name, input_data):
    """Compile and run a C++ test, returning the result as a dict."""
    test_code = f'''
#include <iostream>
#include <sstream>
#include "parser.hpp"
#include "cache.hpp"
#include "stats.hpp"

int main() {{
    std::istringstream in("{input_data.replace(chr(10), "\\n").replace(chr(13), "\\r").replace('"', '\\"')}");
    try {{
        auto result = aggregate(in);
        for (const auto& [k, v] : result) {{
            std::cout << k << ":" << v << " ";
        }}
    }} catch (const std::exception& e) {{
        std::cout << "ERROR:" << e.what();
        return 1;
    }}
    return 0;
}}
'''
    return run_cpp_compiled(test_name, test_code, parse_result=True)


def run_cpp_test_from_file(test_name, driver_input):
    """Run a test from driver input format."""
    # Extract the CSV data from driver_input format
    parts = driver_input.split('"', 2)
    if len(parts) >= 2:
        csv_data = parts[1]
    else:
        csv_data = driver_input
    
    test_code = f'''
#include <iostream>
#include <sstream>
#include "parser.hpp"
#include "cache.hpp"
#include "stats.hpp"

int main() {{
    std::istringstream in("{csv_data.replace(chr(10), "\\n").replace(chr(13), "\\r").replace('"', '\\"')}");
    try {{
        auto result = aggregate(in);
        for (const auto& [k, v] : result) {{
            std::cout << k << ":" << v << " ";
        }}
    }} catch (const std::exception& e) {{
        std::cout << "ERROR:" << e.what();
        return 1;
    }}
    return 0;
}}
'''
    return run_cpp_compiled(test_name, test_code, parse_result=True)


def run_cpp_cache_test(test_name, operations):
    """Run a cache test with given operations."""
    ops_code = ""
    for op in operations:
        if op[0] == "put":
            ops_code += f'cache.put({op[1]}, "{op[2]}");\n'
        elif op[0] == "get":
            ops_code += f'std::string out_{op[1]}; bool got_{op[1]} = cache.get({op[1]}, out_{op[1]});\n'
            ops_code += f'std::cout << "get_{op[1]}:" << (got_{op[1]} ? out_{op[1]} : "MISS") << " ";\n'
        elif op[0] == "erase":
            ops_code += f'bool erased_{op[1]} = cache.erase({op[1]});\n'
        elif op[0] == "snapshot":
            ops_code += 'auto snap = cache.snapshot();\n'
            ops_code += 'for (const auto& p : snap) std::cout << p.first << ":" << p.second << " ";\n'
    
    test_code = f'''
#include <iostream>
#include "cache.hpp"

int main() {{
    LruCache cache(2);
{ops_code}
    return 0;
}}
'''
    return run_cpp_compiled(test_name, test_code, parse_result=True)


def run_cpp_stats_test(test_name, operations):
    """Run a stats test with given operations."""
    ops_code = ""
    for op in operations:
        if op[0] == "add":
            ops_code += f'stats.add({op[1]});\n'
        elif op[0] == "merge_empty":
            ops_code += 'RunningStats empty;\nstats.merge(empty);\n'
        elif op[0] == "merge_into_empty":
            ops_code += 'RunningStats empty;\nempty.merge(stats);\nstats = empty;\n'
        elif op[0] == "self_merge":
            ops_code += 'stats.merge(stats);\n'
    
    test_code = f'''
#include <iostream>
#include "stats.hpp"

int main() {{
    RunningStats stats;
{ops_code}
    std::cout << "count:" << stats.count() << " ";
    std::cout << "mean:" << stats.mean() << " ";
    std::cout << "variance:" << stats.variance() << " ";
    std::cout << "minimum:" << stats.minimum() << " ";
    std::cout << "maximum:" << stats.maximum() << " ";
    return 0;
}}
'''
    return run_cpp_compiled(test_name, test_code, parse_result=True)


def run_cpp_compiled(test_name, source, parse_result=False):
    """Compile and run C++ code, returning result."""
    import subprocess
    import tempfile
    
    with tempfile.TemporaryDirectory() as tmpdir:
        cpp_path = os.path.join(tmpdir, f"{test_name}.cpp")
        exe_path = os.path.join(tmpdir, test_name)
        
        with open(cpp_path, "w") as f:
            f.write(source)
        
        # Compile with clang++ -fuse-ld=bfd -std=c++20
        try:
            result = subprocess.run(
                ["clang++", "-fuse-ld=bfd", "-std=c++20", "-o", exe_path, cpp_path],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                raise RuntimeError(f"Compilation failed: {result.stderr}")
            
            run_result = subprocess.run(
                [exe_path],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if parse_result:
                output = run_result.stdout.strip()
                if output.startswith("ERROR:"):
                    raise ValueError(output[6:])
                
                result_dict = {}
                for part in output.split():
                    if ":" in part:
                        k, v = part.split(":", 1)
                        if k in ["count", "mean", "variance", "minimum", "maximum"]:
                            result_dict[k] = float(v) if "." in v else int(v)
                        elif k == "get":
                            result_dict[f"get_{v}"] = v
                        else:
                            try:
                                result_dict[k] = int(v)
                            except ValueError:
                                result_dict[k] = v
                
                return result_dict if result_dict else output
            return run_result.returncode == 0
        except subprocess.TimeoutExpired:
            raise RuntimeError("Test timed out")


if __name__ == "__main__":
    unittest.main()
