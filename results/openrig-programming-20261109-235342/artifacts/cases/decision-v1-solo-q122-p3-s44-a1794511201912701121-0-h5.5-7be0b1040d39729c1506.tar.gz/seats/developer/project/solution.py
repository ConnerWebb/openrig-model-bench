"""
CSV aggregator: reads UTF-8 CSV, validates header, accumulates amounts by category.
"""
import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return dict with sorted keys and values formatted to 2 decimal places.
    Raises ValueError on any malformed input.
    """
    # Amount pattern: optional +, 1-12 digits, optional decimal point with 1-2 digits
    # Nonnegative, finite, no exponent
    amount_pattern = re.compile(r'^\+?\d{1,12}(\.\d{1,2})?$')

    totals: dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8', newline='') as f:
        # Read header line by line to validate
        reader = csv.reader(f)
        
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        # Header must be exactly ['category', 'amount']
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid header")

        for row in reader:
            # Skip completely blank records (empty or all whitespace)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every non-blank record must have exactly 2 fields
            if len(row) != 2:
                raise ValueError("Record must have exactly 2 fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse and accumulate using Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check for nonnegative (amount >= 0)
            if amount < 0:
                raise ValueError("Negative amount not allowed")
            
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount

    # Return sorted keys with values formatted to exactly 2 decimal places
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
