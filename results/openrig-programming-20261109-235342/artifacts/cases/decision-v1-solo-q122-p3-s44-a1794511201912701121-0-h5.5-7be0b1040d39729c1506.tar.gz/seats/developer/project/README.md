# CSV Aggregator

This module provides a function to aggregate CSV data by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and accumulate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary with sorted category keys and totals formatted to 2 decimal places
        
    Raises:
        ValueError: If the CSV is malformed (invalid header, wrong field count,
                   empty category, invalid amount format, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank record must have exactly 2 fields
- **Category**: Non-empty after stripping whitespace
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits
  - Optional decimal point followed by 1-2 digits
  - Nonnegative, finite, no exponent notation

## Features

- Stream-based CSV parsing (doesn't load entire file into memory)
- Proper handling of quoted fields with embedded commas and newlines
- Exact decimal arithmetic using Python's `decimal` module
- Unicode support for category names
- Strict validation with descriptive error messages

## Example

```python
from solution import aggregate

result = aggregate('data.csv')
# Returns: {'food': '1234.56', 'rent': '2000.00', ...}
```

## Running Tests

```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
