"""
Unit tests for solution.py aggregate function.
"""
import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_simple_csv(self):
        """Test basic CSV with simple categories and amounts."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,10.50\nbar,20.25\nfoo,5.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'bar': '20.25', 'foo': '15.50'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  foo  ,  10.50  \nbar,20.25\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'bar': '20.25', 'foo': '10.50'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n"c,d",200.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00', 'c,d': '200.00'})
    
    def test_quoted_fields_with_newlines(self):
        """Test quoted fields containing newlines."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"line1\nline2",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'line1\nline2': '100.00'})
    
    def test_quoted_quotes(self):
        """Test quoted fields with escaped quotes (double quotes)."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,10.00\n\nbar,20.00\n   \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'bar': '20.00', 'foo': '10.00'})
    
    def test_invalid_header_wrong_name(self):
        """Test that wrong header names raise ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,amount\nfoo,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_wrong_count(self):
        """Test that wrong number of header fields raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount,extra\nfoo,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_wrong_field_count(self):
        """Test that records with wrong field count raise ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,10.00,extra\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category_raises(self):
        """Test that empty category raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test that NaN amount raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_exponent(self):
        """Test that exponent notation raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,1e2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_negative(self):
        """Test that negative amount raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,-10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_valid_positive_sign(self):
        """Test that positive sign is allowed."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfoo,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'foo': '10.50'})
    
    def test_decimal_places_formatting(self):
        """Test that amounts are formatted to exactly 2 decimal places."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Test with valid amounts: integer, 1 decimal, 2 decimals
            p.write_text('category,amount\nfoo,10\nbar,20.5\nbaz,30.55\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'bar': '20.50', 'baz': '30.55', 'foo': '10.00'})
    
    def test_unicode_categories(self):
        """Test that unicode categories work correctly."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Use quoted unicode categories to avoid any parsing issues
            p.write_text('category,amount\n"日本",100.00\n"한국",200.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00', '한국': '200.00'})
    
    def test_accumulation_exact_decimal(self):
        """Test that accumulation uses exact decimal arithmetic."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # 0.1 + 0.2 should be exactly 0.3, not 0.30000000000000004
            p.write_text('category,amount\nfoo,0.1\nfoo,0.2\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'foo': '0.30'})
    
    def test_empty_file_raises(self):
        """Test that empty file raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only(self):
        """Test that header-only file returns empty dict."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
