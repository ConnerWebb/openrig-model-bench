"""CSV aggregator with exact decimal arithmetic."""
import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted category keys with totals formatted to exactly 2 decimal places.
    Raises ValueError for malformed input.
    """
    # Amount regex: optional +, 1-12 digits, optional decimal point with 1-2 digits
    # Must be nonnegative, finite, no exponent
    amount_pattern = re.compile(r'^\+?\d{1,12}(\.\d{1,2})?$')
    
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        # Read header first
        header_line = f.readline()
        if not header_line:
            raise ValueError("Empty file")
        
        # Parse header - must be exactly "category,amount"
        # Use csv reader to handle potential quoting in header
        header_reader = csv.reader(StringIO(header_line))
        try:
            header = next(header_reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly 'category,amount'")
        
        # Now read the rest of the file with csv reader
        reader = csv.reader(f)
        
        for row in reader:
            # Skip completely blank records (empty row or all empty fields)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError("Record must have exactly two fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse as Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted by category, formatted to exactly 2 decimal places
    result = {}
    for key in sorted(totals.keys()):
        # Format with exactly 2 decimal places
        result[key] = f"{totals[key]:.2f}"
    
    return result
