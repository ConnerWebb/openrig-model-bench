# CSV Aggregator

A Python module that aggregates CSV data by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]
```

Reads a UTF-8 CSV file and returns a dictionary mapping categories to their summed amounts.

### Input Format

- Header must be exactly `category,amount`
- Each data row must have exactly two fields
- Blank rows are ignored
- Quoted fields may contain commas, newlines, and escaped quotes (`""`)
- Amounts: optional `+`, 1-12 digits, optional decimal point with 1-2 digits

### Output Format

- Dictionary with category keys sorted alphabetically
- Values formatted to exactly 2 decimal places

### Error Handling

Raises `ValueError` for:
- Missing or incorrect header
- Empty category
- Invalid amount format (NaN, exponent, too many digits, etc.)
- Wrong number of fields in a non-blank row
- Malformed CSV (unterminated quotes, etc.)

## Usage

```python
from solution import aggregate

result = aggregate('data.csv')
print(result)  # {'food': '123.45', 'rent': '678.90'}
```

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
