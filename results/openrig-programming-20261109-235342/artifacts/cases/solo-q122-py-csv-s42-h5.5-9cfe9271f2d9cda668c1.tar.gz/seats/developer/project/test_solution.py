"""Tests for solution.py aggregate function."""
import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,10.00\nfood,20.00\nrent,50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '30.00', 'rent': '50.00'})

    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n  food  ,  10.00  \n  rent  ,  20.00  ', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})

    def test_quoted_fields_with_commas(self):
        """Test handling of quoted fields containing commas."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"a,b",100.00\n"a,b",50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '150.00'})

    def test_embedded_newlines(self):
        """Test handling of embedded newlines in quoted fields."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"two\nlines",100.00\n"two\nlines",50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '150.00'})

    def test_quoted_quotes(self):
        """Test handling of escaped quotes in quoted fields."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"x""quote",100.00\n"x""quote",50.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '150.00'})

    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,10.00\n\nrent,20.00\n\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})

    def test_empty_category_raises(self):
        """Test that empty category raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n,10.00', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_wrong_header_raises(self):
        """Test that wrong header raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('wrong,amount\nx,10.00', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_wrong_field_count_raises(self):
        """Test that wrong field count raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,1,2', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_invalid_amount_raises(self):
        """Test that invalid amount format raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nx,NaN', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_unterminated_quote_raises(self):
        """Test that unterminated quote raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\n"x,1', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_amount_with_plus_sign(self):
        """Test amount with optional plus sign."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,+10.00\nfood,+20.50', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '30.50'})

    def test_amount_decimal_places(self):
        """Test amounts with 1 or 2 decimal places."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,10.5\nfood,20.25', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '30.75'})

    def test_unicode_categories(self):
        """Test unicode category names."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            # Use bytes to ensure correct comma character
            content = b'category,amount\n\xE6\x97\xA5\xE6\x9C\xAC,100.00\n\xE6\x97\xA5\xE6\x9C\xAC,50.00\n'
            p.write_bytes(content)
            result = aggregate(str(p))
            # Expected key is 日本 (UTF-8: E6 97 A5 E6 9C AC)
            self.assertEqual(result, {'日本': '150.00'})

    def test_sorted_output(self):
        """Test that output is sorted by category."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nzebra,10.00\napple,20.00\nmango,30.00', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])

    def test_exact_decimal_arithmetic(self):
        """Test that decimal arithmetic is exact (no floating point errors)."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            # 0.1 + 0.2 should be exactly 0.3, not 0.30000000000000004
            p.write_text('category,amount\nfood,0.1\nfood,0.2', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '0.30'})

    def test_large_amounts(self):
        """Test large amounts with up to 12 digits."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('category,amount\nfood,999999999999.99', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '999999999999.99'})

    def test_empty_file_raises(self):
        """Test that empty file raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))


if __name__ == '__main__':
    unittest.main()
