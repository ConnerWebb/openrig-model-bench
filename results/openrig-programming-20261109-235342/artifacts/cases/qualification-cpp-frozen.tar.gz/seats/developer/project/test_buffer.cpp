#include "solution.hpp"
#include <cassert>
#include <iostream>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 42;
    a[1] = 100;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 42);
    assert(b[1] == 100);
    // Verify deep copy: modifying b doesn't affect a
    b[0] = 99;
    assert(a[0] == 42);
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(3);
    a[0] = 10;
    Buffer b(5);
    b = a;
    assert(b.size() == 3);
    assert(b[0] == 10);
    // Verify deep copy
    b[0] = 99;
    assert(a[0] == 10);
    std::cout << "test_copy_assignment passed\n";
}

void test_self_copy() {
    Buffer a(4);
    a[0] = 55;
    a = a;
    assert(a.size() == 4);
    assert(a[0] == 55);
    std::cout << "test_self_copy passed\n";
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 77;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    assert(b.size() == 5);
    assert(b[0] == 77);
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer a(3);
    a[0] = 88;
    Buffer b(5);
    b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 3);
    assert(b[0] == 88);
    std::cout << "test_move_assignment passed\n";
}

void test_self_move() {
    Buffer a(4);
    a[0] = 99;
    a = std::move(a);
    assert(a.size() == 4);
    assert(a[0] == 99);
    std::cout << "test_self_move passed\n";
}

void test_bounds_checking() {
    Buffer b(5);
    try {
        b[5] = 1;  // out of bounds
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    try {
        b.at(5);  // out of bounds
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "test_bounds_checking passed\n";
}

void test_resize_grow() {
    Buffer b(3);
    b[0] = 10;
    b.resize(6);
    assert(b.size() == 6);
    assert(b[0] == 10);
    assert(b[3] == 0);
    assert(b[5] == 0);
    std::cout << "test_resize_grow passed\n";
}

void test_resize_shrink() {
    Buffer b(10);
    b[0] = 42;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 42);
    std::cout << "test_resize_shrink passed\n";
}

void test_resize_to_zero() {
    Buffer b(5);
    b.resize(0);
    assert(b.size() == 0);
    std::cout << "test_resize_to_zero passed\n";
}

void test_moved_from_reuse() {
    Buffer a(5);
    a[0] = 100;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    // Reuse the moved-from buffer
    a = Buffer(3);
    a[0] = 200;
    assert(a.size() == 3);
    assert(a[0] == 200);
    std::cout << "test_moved_from_reuse passed\n";
}

void test_const_operator_bracket() {
    const Buffer b(3);
    b[0];  // Should compile
    std::cout << "test_const_operator_bracket passed\n";
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible<Buffer>::value, "Move constructor should be noexcept");
    static_assert(std::is_nothrow_move_assignable<Buffer>::value, "Move assignment should be noexcept");
    std::cout << "test_noexcept_move passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy();
    test_move_constructor();
    test_move_assignment();
    test_self_move();
    test_bounds_checking();
    test_resize_grow();
    test_resize_shrink();
    test_resize_to_zero();
    test_moved_from_reuse();
    test_const_operator_bracket();
    test_noexcept_move();
    
    std::cout << "\nAll tests passed!\n";
    return 0;
}
