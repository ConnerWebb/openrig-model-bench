# Buffer Library

A C++20 RAII buffer class with deep copy semantics, move support, and bounds checking.

## Features

- **RAII**: Automatic memory management via `std::vector<uint8_t>`
- **Deep copy**: Copy constructor and assignment create independent copies
- **Noexcept move**: Move operations are marked `noexcept`
- **Bounds checking**: `operator[]` and `at()` throw `std::out_of_range` on invalid indices
- **Resize**: `resize()` preserves prefix and zero-initializes new bytes

## Usage

```cpp
#include "solution.hpp"

// Create a buffer of 10 zero-initialized bytes
Buffer buf(10);

// Access elements
buf[0] = 42;

// Deep copy
Buffer copy = buf;

// Move
Buffer moved(std::move(buf));
assert(buf.size() == 0);  // moved-from buffer is empty but reusable

// Resize (preserves prefix, zero-initializes new bytes)
buf.resize(20);

// Bounds checking throws on invalid indices
try {
    buf.at(100) = 1;  // throws std::out_of_range
} catch (const std::out_of_range& e) {
    // Handle error
}
```

## Building and Testing

```bash
# Compile with Clang C++20
clang++ -fuse-ld=bfd -std=c++20 -pthread -I. test_buffer.cpp -o test_buffer

# Run tests
./test_buffer
```

## API Reference

### `Buffer(size_t n = 0)`
Constructs a buffer with `n` zero-initialized bytes.

### `size() const noexcept`
Returns the buffer size.

### `operator[](size_t i) -> uint8_t&`
### `operator[](size_t i) const -> const uint8_t&`
Access element at index `i` with bounds checking.

### `at(size_t i) -> uint8_t&`
### `at(size_t i) const -> const uint8_t&`
Access element at index `i` with bounds checking (throws `std::out_of_range` on invalid index).

### `resize(size_t n)`
Resizes the buffer. Preserves existing bytes, zero-initializes new bytes.
