"""
CSV Aggregator

This module provides a function to aggregate CSV data by category.
"""
import csv
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.
    
    The CSV must have exactly two columns: 'category' and 'amount'.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary with categories as keys and formatted amounts as values.
        Categories are sorted alphabetically.
        
    Raises:
        ValueError: If the CSV format is invalid or amounts are malformed
    """
    totals = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        # Read header
        try:
            header = next(reader)
        except StopIteration:
            # Empty file
            return {}
        
        # Validate header
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        # Process each row
        for row in reader:
            # Skip completely blank rows
            if not row:
                continue
            
            # Validate row has exactly 2 fields
            if len(row) != 2:
                raise ValueError("Row must have exactly 2 fields")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Validate category is not empty
            if not category:
                raise ValueError("Category cannot be empty")
            
            # Parse amount
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Validate amount format (nonnegative, finite, no exponent)
            # Check NaN and infinite before comparisons
            if amount.is_nan():
                raise ValueError(f"Invalid amount: {amount_str}")
            if amount.is_infinite():
                raise ValueError(f"Invalid amount: {amount_str}")
            if amount < 0:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Validate amount string format (optional +, 1-12 digits, optional decimal with 1-2 digits)
            if not _is_valid_amount_string(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly 2 decimal places
    result = {cat: total.quantize(Decimal('0.01')) for cat, total in sorted(totals.items())}
    return {cat: str(total) for cat, total in result.items()}


def _is_valid_amount_string(s: str) -> bool:
    """
    Validate amount string format.
    
    Format: optional +, 1-12 decimal digits, optional decimal point followed by 1 or 2 digits.
    No exponent allowed.
    """
    # Remove optional leading +
    if s.startswith('+'):
        s = s[1:]
    
    # Split by decimal point
    parts = s.split('.')
    
    # Must have 1 or 2 parts
    if len(parts) > 2:
        return False
    
    integer_part = parts[0]
    fractional_part = parts[1] if len(parts) == 2 else ''
    
    # Integer part: 1-12 digits
    if not integer_part or len(integer_part) > 12:
        return False
    if not integer_part.isdigit():
        return False
    
    # Fractional part: 1 or 2 digits
    if fractional_part:
        if len(fractional_part) not in (1, 2):
            return False
        if not fractional_part.isdigit():
            return False
    
    return True
