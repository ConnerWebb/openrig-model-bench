"""
Test cases for the CSV aggregator.
"""
import unittest
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for aggregate function."""

    def test_basic_aggregation(self):
        """Test basic aggregation with multiple categories."""
        result = aggregate('public-inputs/case-00.csv')
        self.assertEqual(result, {
            'a,b': '599.14',
            'food': '2262.01',
            'rent': '2215.92',
            'two\nlines': '1434.24',
            'x"quote': '1458.60',
            '日本': '909.01'
        })

    def test_quoted_fields(self):
        """Test CSV with quoted fields containing commas and newlines."""
        result = aggregate('public-inputs/case-00.csv')
        self.assertEqual(result, {
            'a,b': '599.14',
            'food': '2262.01',
            'rent': '2215.92',
            'two\nlines': '1434.24',
            'x"quote': '1458.60',
            '日本': '909.01'
        })

    def test_unicode_categories(self):
        """Test Unicode category names."""
        result = aggregate('public-inputs/case-00.csv')
        self.assertEqual(result, {
            'a,b': '599.14',
            'food': '2262.01',
            'rent': '2215.92',
            'two\nlines': '1434.24',
            'x"quote': '1458.60',
            '日本': '909.01'
        })

    def test_blank_lines(self):
        """Test that blank lines are ignored."""
        result = aggregate('public-inputs/case-00.csv')
        self.assertEqual(result, {
            'a,b': '599.14',
            'food': '2262.01',
            'rent': '2215.92',
            'two\nlines': '1434.24',
            'x"quote': '1458.60',
            '日本': '909.01'
        })

    def test_invalid_header(self):
        """Test that invalid header raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-04.csv')

    def test_invalid_row_length(self):
        """Test that rows with wrong number of fields raise ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-05.csv')

    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-06.csv')

    def test_invalid_amount(self):
        """Test that invalid amount raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-08.csv')

    def test_exponent_amount(self):
        """Test that exponent in amount raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-09.csv')

    def test_amount_with_too_many_decimal_places(self):
        """Test that amount with more than 2 decimal places raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-10.csv')

    def test_amount_with_no_decimal_places(self):
        """Test that amount with no decimal places raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-11.csv')

    def test_amount_with_one_decimal_place(self):
        """Test that amount with one decimal place raises ValueError."""
        with self.assertRaises(ValueError):
            aggregate('public-inputs/case-12.csv')

    def test_amount_with_two_decimal_places(self):
        """Test that amount with two decimal places is valid."""
        result = aggregate('public-inputs/case-00.csv')
        self.assertIn('food', result)
        self.assertEqual(result['food'], '2262.01')

    def test_amount_with_leading_plus(self):
        """Test that amount with leading + is valid."""
        result = aggregate('case-13.csv')
        self.assertEqual(result, {'food': '100.50'})

    def test_empty_file(self):
        """Test that empty file returns empty dict."""
        result = aggregate('case-14.csv')
        self.assertEqual(result, {})

    def test_only_header(self):
        """Test that file with only header returns empty dict."""
        result = aggregate('case-15.csv')
        self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
