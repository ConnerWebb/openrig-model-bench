# CSV Aggregator

This solution implements a CSV aggregator that reads a CSV file and sums amounts by category.

## Solution Overview

The `aggregate` function in `solution.py`:
- Reads a UTF-8 CSV file as a stream
- Validates the header is exactly "category,amount"
- Ignores blank records
- Validates each record has exactly two fields
- Strips whitespace from category and amount
- Validates category is not empty
- Validates amount format: optional +, 1-12 digits, optional decimal point with 1 or 2 digits
- Uses exact decimal arithmetic for accumulation
- Returns totals formatted with exactly two decimal places
- Returns category keys sorted alphabetically

## Requirements

- Python 3.14
- No external dependencies (uses only stdlib)

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

Or use the provided `run_tests` command.

## Test Coverage

The test suite includes:
- Basic aggregation with multiple categories
- CSV with quoted fields containing commas and newlines
- Unicode category names
- Blank lines handling
- Various error cases:
  - Invalid header
  - Rows with wrong number of fields
  - Empty category
  - Invalid amount formats
  - Exponent in amount
  - Amount with too many decimal places
  - Amount with no decimal places
  - Amount with one decimal place
  - Amount with two decimal places
  - Amount with leading plus
  - Empty file
  - File with only header

## Implementation Details

The solution uses Python's `csv` module to properly handle quoted fields and embedded newlines. It validates the amount format using regular expressions and performs decimal arithmetic using Python's `decimal` module for exact precision.
