#!/usr/bin/env python3
import csv
import sys

def simple_aggregate(filename):
    totals = {}
    
    with open(filename, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        for row in reader:
            if not row or len(row) != 2:
                continue
                
            category, amount_str = row
            if category not in totals:
                totals[category] = 0
            totals[category] += float(amount_str)
                
    return {k: f'{v:.2f}' for k, v in totals.items()}

if __name__ == '__main__':
    result = simple_aggregate('public-inputs/case-00.csv')
    print('Keys:', sorted(result.keys()))
    print('x\"quote value:', result.get('x\"quote', 'NOT FOUND'))