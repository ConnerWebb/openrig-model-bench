#!/usr/bin/env python3
import tempfile
import os
import sys
sys.path.insert(0, '.')

from solution import aggregate

# This is the exact test case from test_solution.py
expected = {
    "a,b": "599.14",
    "food": "2262.01",
    "rent": "2215.92",
    "two\nlines": "1434.24",
    "x\"quote": "1458.60",
    "日本": "909.01"
}

# Create the exact same CSV content as in the test file
csv_content = '''category,amount
"x"quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x"quote",71.74
"x"quote",254.02
"x"quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x"quote",39.70
"two
lines",849.77
"x"quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
'''

print("CSV content:")
print(repr(csv_content))
print()

with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
    f.write(csv_content)
    temp_path = f.name

try:
    result = aggregate(temp_path)
    print("Actual result:")
    for key in sorted(result.keys()):
        print(f"  {repr(key)}: {result[key]}")
    
    print()
    print("Expected result:")
    for key in sorted(expected.keys()):
        print(f"  {repr(key)}: {expected[key]}")
    
    print()
    print("Match:", result == expected)
    
    if result != expected:
        print("\nDifferences:")
        all_keys = set(result.keys()) | set(expected.keys())
        for key in sorted(all_keys):
            if key not in result:
                print(f"  Missing in result: {repr(key)}")
            elif key not in expected:
                print(f"  Extra in result: {repr(key)}")
            elif result[key] != expected[key]:
                print(f"  Different value for {repr(key)}: got {repr(result[key])}, expected {repr(expected[key])}")
    
finally:
    os.unlink(temp_path)