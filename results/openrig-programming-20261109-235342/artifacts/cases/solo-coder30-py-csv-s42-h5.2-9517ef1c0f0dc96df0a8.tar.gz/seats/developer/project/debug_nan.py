import decimal
from decimal import Decimal

# Test what happens with NaN
try:
    d = Decimal('NaN')
    print(f"Decimal('NaN') = {d}")
    print(f"d.is_finite() = {d.is_finite()}")
    print(f"d < 0 = {d < 0}")
except Exception as e:
    print(f"Error: {e}")
    print(f"Error type: {type(e)}")

# Test what happens with invalid string
try:
    d = Decimal('invalid')
    print(f"Decimal('invalid') = {d}")
except Exception as e:
    print(f"Error with invalid: {e}")
    print(f"Error type: {type(e)}")