#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, '.')

# Import the function directly like the test does
from solution import aggregate

# Test with the actual file
try:
    result = aggregate('public-inputs/case-00.csv')
    print("SUCCESS - Result:")
    for k in sorted(result.keys()):
        print(f"  {repr(k)}: {result[k]}")
        
    expected = {
        'a,b': '599.14',
        'food': '2262.01',
        'rent': '2215.92',
        'two\nlines': '1434.24',
        'x"quote': '1458.60',
        '日本': '909.01'
    }
    
    print("\nExpected:")
    for k in sorted(expected.keys()):
        print(f"  {repr(k)}: {expected[k]}")
        
    print(f"\nMatch: {result == expected}")
    
    if result != expected:
        print("\nKeys difference:")
        result_keys = set(result.keys())
        expected_keys = set(expected.keys())
        print(f"Only in result: {result_keys - expected_keys}")
        print(f"Only in expected: {expected_keys - result_keys}")
        
except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()