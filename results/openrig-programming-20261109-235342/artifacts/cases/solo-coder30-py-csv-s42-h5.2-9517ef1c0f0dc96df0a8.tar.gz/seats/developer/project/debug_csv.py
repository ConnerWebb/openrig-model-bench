import csv
import tempfile
import os

# Test CSV parsing
csv_content = '''category,amount
"x"quote",812.68
food,347.25
'''

with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
    f.write(csv_content)
    temp_path = f.name

try:
    with open(temp_path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f, skipinitialspace=True)
        header = next(reader)
        print(f"Header: {header}")
        for row in reader:
            print(f"Row: {row}")
            print(f"Category: '{row[0]}'")
            print(f"Category repr: {repr(row[0])}")
finally:
    os.unlink(temp_path)