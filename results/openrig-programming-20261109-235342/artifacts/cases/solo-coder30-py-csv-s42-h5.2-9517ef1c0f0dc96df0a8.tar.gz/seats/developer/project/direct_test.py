import csv
import tempfile
import os
from solution import aggregate

# Test with the exact content from case-00.csv
csv_content = '''category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
'''

with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
    f.write(csv_content)
    temp_path = f.name

try:
    result = aggregate(temp_path)
    print("Result:")
    for k, v in result.items():
        print(f"  '{k}': '{v}'")
    print()
    
    # Check specifically for the problematic key
    if 'x"quote' in result:
        print(f"Found 'x\"quote': {result['x\"quote']}")
    else:
        print("Key 'x\"quote' not found")
        
    if 'xquote"' in result:
        print(f"Found 'xquote\"': {result['xquote\"']}")
    else:
        print("Key 'xquote\"' not found")
        
finally:
    os.unlink(temp_path)