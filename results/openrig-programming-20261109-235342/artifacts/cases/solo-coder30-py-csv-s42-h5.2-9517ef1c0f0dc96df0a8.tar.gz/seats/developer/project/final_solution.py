import csv
import decimal
from decimal import Decimal

def aggregate(filename):
    totals = {}
    
    with open(filename, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        # Validate header
        if header != ['category', 'amount']:
            raise ValueError('Invalid header')
            
        for row_num, row in enumerate(reader, start=2):
            # Skip empty rows
            if not any(row):
                continue
                
            # Validate row structure
            if len(row) != 2:
                raise ValueError(f'Row {row_num} has {len(row)} fields, expected 2')
                
            category, amount_str = row
            
            # Validate category is not empty
            if not category:
                raise ValueError('Empty category')
                
            # Parse amount
            try:
                amount = Decimal(amount_str)
            except decimal.InvalidOperation:
                raise ValueError(f'Invalid amount in row {row_num}: {amount_str}')
            
            # Check for NaN immediately after parsing
            if amount.is_nan():
                raise ValueError('NaN amount')
                
            # Validate amount constraints
            if amount < 0:
                raise ValueError('Negative amount')
            if amount > 1000000:
                raise ValueError('Amount too large')
            if 'e' in amount_str.lower():
                raise ValueError('Scientific notation not allowed')
                
            # Validate decimal precision (at most 2 decimal places)
            if '.' in amount_str:
                decimal_places = len(amount_str.split('.')[1])
                if decimal_places > 2:
                    raise ValueError(f'Amount in row {row_num} has more than 2 decimal places')
                
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
                
    # Convert to strings with 2 decimal places
    return {category: str(amount) for category, amount in totals.items()}