#!/usr/bin/env python3
import csv
import sys

# Let me trace exactly what's happening in the CSV parsing
def debug_aggregate(filename):
    print(f"=== DEBUGGING {filename} ===")
    
    totals = {}
    
    with open(filename, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        print(f"Header: {header}")
        
        # Validate header
        if header != ['category', 'amount']:
            raise ValueError('Invalid header')
            
        for i, row in enumerate(reader):
            print(f"Row {i}: {row}")
            if not row or len(row) != 2:
                continue
                
            category, amount_str = row
            print(f"  Category: {repr(category)}")
            print(f"  Amount: {repr(amount_str)}")
            
            # Validate category is not empty
            if not category:
                raise ValueError('Empty category')
                
            # Accumulate
            if category in totals:
                totals[category] += float(amount_str)
            else:
                totals[category] = float(amount_str)
                
    # Convert to strings with 2 decimal places
    result = {category: f'{amount:.2f}' for category, amount in totals.items()}
    print(f"Final result keys: {sorted(result.keys())}")
    return result

# Test with the exact same file as the test
import tempfile
import os

# Read the actual file content
with open('public-inputs/case-00.csv', 'r') as f:
    content = f.read()

print("Raw file content:")
print(repr(content))
print()

# Create temp file like the test does
with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
    f.write(content)
    temp_path = f.name

try:
    result = debug_aggregate(temp_path)
    print("\n=== FINAL RESULT ===")
    for key in sorted(result.keys()):
        print(f"  {repr(key)}: {result[key]}")
finally:
    os.unlink(temp_path)