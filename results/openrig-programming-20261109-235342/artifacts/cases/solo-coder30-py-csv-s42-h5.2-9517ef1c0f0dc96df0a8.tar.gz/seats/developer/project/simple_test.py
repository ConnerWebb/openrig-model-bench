#!/usr/bin/env python3
import csv

def aggregate(filename):
    totals = {}
    
    with open(filename, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        # Validate header
        if header != ['category', 'amount']:
            raise ValueError('Invalid header')
            
        for row in reader:
            # Skip empty rows
            if not row or len(row) != 2:
                continue
                
            category, amount_str = row
            
            # Validate category is not empty
            if not category:
                raise ValueError('Empty category')
                
            # Accumulate
            if category in totals:
                totals[category] += float(amount_str)
            else:
                totals[category] = float(amount_str)
                
    # Convert to strings with 2 decimal places
    return {category: f'{amount:.2f}' for category, amount in totals.items()}

# Test with the exact same file as the test
import tempfile
import os

# Read the actual file content
with open('public-inputs/case-00.csv', 'r') as f:
    content = f.read()

# Create temp file like the test does
with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
    f.write(content)
    temp_path = f.name

try:
    result = aggregate(temp_path)
    print("SUCCESS - Result:")
    for key in sorted(result.keys()):
        print(f"  {repr(key)}: {result[key]}")
finally:
    os.unlink(temp_path)