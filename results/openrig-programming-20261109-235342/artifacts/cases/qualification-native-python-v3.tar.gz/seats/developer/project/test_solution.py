"""Tests for solution.py aggregate function."""

import os
import tempfile
import unittest

from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def _write_csv(self, content: str) -> str:
        """Helper to write CSV content to a temp file."""
        fd, path = tempfile.mkstemp(suffix='.csv')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(content)
        return path

    def test_basic_aggregation(self):
        """Test basic aggregation with simple categories."""
        csv_content = """category,amount
food,100.50
rent,500.00
food,50.25"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '150.75', 'rent': '500.00'})
        finally:
            os.unlink(path)

    def test_header_validation(self):
        """Test that invalid headers raise ValueError."""
        csv_content = """cat,amount
food,100"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_blank_records_ignored(self):
        """Test that blank records are ignored."""
        csv_content = """category,amount
food,100.00

rent,200.00

food,50.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '150.00', 'rent': '200.00'})
        finally:
            os.unlink(path)

    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = """category,amount
  food  ,  100.50  """
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.50'})
        finally:
            os.unlink(path)

    def test_empty_category_rejected(self):
        """Test that empty category raises ValueError."""
        csv_content = """category,amount
,100.00"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_amount_with_plus_sign(self):
        """Test that amounts with + sign are accepted."""
        csv_content = """category,amount
food,+100.50"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.50'})
        finally:
            os.unlink(path)

    def test_amount_validation_digits(self):
        """Test amount digit validation."""
        # 12 digits should work
        csv_content = """category,amount
food,123456789012"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '123456789012.00'})
        finally:
            os.unlink(path)

        # 13 digits should fail
        csv_content = """category,amount
food,1234567890123"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_amount_validation_decimal_places(self):
        """Test amount decimal places validation."""
        # 1 decimal place should work
        csv_content = """category,amount
food,100.5"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.50'})
        finally:
            os.unlink(path)

        # 2 decimal places should work
        csv_content = """category,amount
food,100.55"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.55'})
        finally:
            os.unlink(path)

        # 3 decimal places should fail
        csv_content = """category,amount
food,100.555"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_empty_amount_rejected(self):
        """Test that empty amount raises ValueError."""
        csv_content = """category,amount
food,"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_csv_quoted_commas(self):
        """Test CSV with quoted fields containing commas."""
        csv_content = """category,amount
"a,b",100.00
food,200.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'a,b': '100.00', 'food': '200.00'})
        finally:
            os.unlink(path)

    def test_csv_embedded_newlines(self):
        """Test CSV with embedded newlines in quoted fields."""
        csv_content = """category,amount
"two
lines",100.00
food,200.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '200.00', 'two\nlines': '100.00'})
        finally:
            os.unlink(path)

    def test_csv_quoted_quotes(self):
        """Test CSV with escaped quotes in fields."""
        csv_content = """category,amount
"x""quote",100.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'x"quote': '100.00'})
        finally:
            os.unlink(path)

    def test_unicode_categories(self):
        """Test that Unicode categories are supported."""
        csv_content = """category,amount
日本,100.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'日本': '100.00'})
        finally:
            os.unlink(path)

    def test_sorted_output(self):
        """Test that output keys are sorted."""
        csv_content = """category,amount
zebra,100.00
apple,200.00
mango,150.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            keys = list(result.keys())
            self.assertEqual(keys, ['apple', 'mango', 'zebra'])
        finally:
            os.unlink(path)

    def test_decimal_precision(self):
        """Test that decimal arithmetic is used for precision."""
        csv_content = """category,amount
food,0.01
food,0.02"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '0.03'})
        finally:
            os.unlink(path)

    def test_empty_file_rejected(self):
        """Test that empty file raises ValueError."""
        fd, path = tempfile.mkstemp(suffix='.csv')
        os.close(fd)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_only_header(self):
        """Test file with only header returns empty dict."""
        csv_content = """category,amount"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {})
        finally:
            os.unlink(path)

    def test_invalid_row_field_count(self):
        """Test that rows with wrong field count raise ValueError."""
        csv_content = """category,amount
food,100.00,extra"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_negative_amount_rejected(self):
        """Test that negative amounts are rejected."""
        csv_content = """category,amount
food,-100.00"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_amount_with_exponent_rejected(self):
        """Test that scientific notation is rejected."""
        csv_content = """category,amount
food,1e5"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_multiple_rows_same_category(self):
        """Test aggregation across multiple rows with same category."""
        csv_content = """category,amount
food,100.00
food,200.00
food,300.00"""
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '600.00'})
        finally:
            os.unlink(path)

    def test_whitespace_only_category_rejected(self):
        """Test that whitespace-only category is rejected."""
        csv_content = """category,amount
   ,100.00"""
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)


if __name__ == '__main__':
    unittest.main()
