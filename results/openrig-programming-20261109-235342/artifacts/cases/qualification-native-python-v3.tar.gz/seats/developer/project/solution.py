"""CSV aggregation module for category totals."""

import csv
import io
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary with category keys sorted, values formatted to 2 decimal places
        
    Raises:
        ValueError: For any malformed input
    """
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: expected 'category,amount', got '{','.join(header)}'")
        
        for row in reader:
            # Skip blank records (entire row is empty or whitespace)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every non-blank record must have exactly 2 fields
            if len(row) != 2:
                raise ValueError(f"Invalid row: expected 2 fields, got {len(row)}")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate and parse amount
            amount = _parse_amount(amount_str)
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted keys with totals formatted to 2 decimal places
    return {k: f"{totals[k]:.2f}" for k in sorted(totals.keys())}


def _parse_amount(amount_str: str) -> Decimal:
    """
    Parse an amount string using exact decimal arithmetic.
    
    Format: optional +, 1-12 digits, optional decimal point followed by 1-2 digits.
    
    Args:
        amount_str: The amount string to parse
        
    Returns:
        Decimal value
        
    Raises:
        ValueError: If the format is invalid
    """
    if not amount_str:
        raise ValueError("Empty amount")
    
    # Check for invalid characters (only digits, optional +, optional decimal point)
    for char in amount_str:
        if char not in '+0123456789.':
            raise ValueError(f"Invalid character in amount: '{char}'")
    
    # Check for multiple + signs
    plus_count = amount_str.count('+')
    if plus_count > 1:
        raise ValueError("Multiple + signs in amount")
    
    # Check for multiple decimal points
    decimal_count = amount_str.count('.')
    if decimal_count > 1:
        raise ValueError("Multiple decimal points in amount")
    
    # Remove optional + sign for validation
    amount_clean = amount_str.lstrip('+')
    
    if not amount_clean:
        raise ValueError("Empty amount after removing +")
    
    # Split into integer and decimal parts
    if '.' in amount_clean:
        int_part, dec_part = amount_clean.split('.')
        
        # Integer part: 1-12 digits
        if not int_part:
            raise ValueError("Empty integer part")
        if len(int_part) > 12:
            raise ValueError("Integer part exceeds 12 digits")
        if not int_part.isdigit():
            raise ValueError("Invalid integer part")
        
        # Decimal part: 1-2 digits
        if not dec_part:
            raise ValueError("Empty decimal part")
        if len(dec_part) > 2:
            raise ValueError("Decimal part exceeds 2 digits")
        if not dec_part.isdigit():
            raise ValueError("Invalid decimal part")
    else:
        # No decimal point: just integer part, 1-12 digits
        if len(amount_clean) > 12:
            raise ValueError("Amount exceeds 12 digits")
        if not amount_clean.isdigit():
            raise ValueError("Invalid amount")
    
    # Convert to Decimal
    try:
        return Decimal(amount_str)
    except InvalidOperation:
        raise ValueError(f"Invalid amount: '{amount_str}'")
