# CSV Aggregation Module

This module provides a function to aggregate numeric amounts from CSV files by category.

## Usage

```python
from solution import aggregate

# Aggregate amounts from a CSV file
result = aggregate("data.csv")
print(result)  # {'category1': '1234.56', 'category2': '789.01'}
```

## CSV Format

The input CSV must have:
- Header row: `category,amount`
- UTF-8 encoding
- Exactly two fields per non-blank row: category and amount

### Amount Format

Amounts must follow this format:
- Optional `+` prefix
- 1-12 decimal digits for the integer part
- Optional decimal point followed by 1-2 decimal digits

Examples of valid amounts: `100`, `+50.5`, `123456789012`, `0.99`

## Error Handling

The function raises `ValueError` for:
- Empty files
- Invalid header (must be exactly `category,amount`)
- Empty categories
- Invalid amount format
- Rows with wrong number of fields
- Negative amounts
- Scientific notation

## Implementation Details

- Uses Python's `decimal` module for exact arithmetic
- Handles CSV quoting, commas in fields, and embedded newlines
- Returns results with keys sorted alphabetically
- All totals formatted to exactly 2 decimal places
