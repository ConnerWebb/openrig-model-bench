#include "stats.hpp"
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <vector>
#include <iomanip>
#include <limits>

static bool almost_equal(double a, double b, double abs_tol = 1e-4, double rel_tol = 1e-6) {
    if (a == b) return true;
    double diff = std::abs(a - b);
    if (diff <= abs_tol) return true;
    double max_abs = std::max(std::abs(a), std::abs(b));
    return diff <= max_abs * rel_tol;
}

static void test_empty_stats() {
    RunningStats rs;
    if (rs.count() != 0) throw std::runtime_error("empty count should be 0");
    bool threw = false;
    try { rs.mean(); } catch (const std::domain_error&) { threw = true; }
    if (!threw) throw std::runtime_error("mean() on empty should throw");
    threw = false;
    try { rs.variance(); } catch (const std::domain_error&) { threw = true; }
    if (!threw) throw std::runtime_error("variance() on empty should throw");
    threw = false;
    try { rs.minimum(); } catch (const std::domain_error&) { threw = true; }
    if (!threw) throw std::runtime_error("minimum() on empty should throw");
    threw = false;
    try { rs.maximum(); } catch (const std::domain_error&) { threw = true; }
    if (!threw) throw std::runtime_error("maximum() on empty should throw");
}

static void test_single_value() {
    RunningStats rs;
    rs.add(42.0);
    if (rs.count() != 1) throw std::runtime_error("count should be 1");
    if (!almost_equal(rs.mean(), 42.0)) throw std::runtime_error("mean should be 42");
    if (!almost_equal(rs.variance(), 0.0)) throw std::runtime_error("variance should be 0");
    if (!almost_equal(rs.minimum(), 42.0)) throw std::runtime_error("min should be 42");
    if (!almost_equal(rs.maximum(), 42.0)) throw std::runtime_error("max should be 42");
}

static void test_multiple_values() {
    RunningStats rs;
    rs.add(1.0);
    rs.add(2.0);
    rs.add(3.0);
    if (rs.count() != 3) throw std::runtime_error("count should be 3");
    if (!almost_equal(rs.mean(), 2.0)) throw std::runtime_error("mean should be 2");
    if (!almost_equal(rs.variance(), 2.0/3.0)) throw std::runtime_error("variance should be 2/3");
    if (!almost_equal(rs.minimum(), 1.0)) throw std::runtime_error("min should be 1");
    if (!almost_equal(rs.maximum(), 3.0)) throw std::runtime_error("max should be 3");
}

static void test_merge_empty() {
    RunningStats a, b;
    a.merge(b);
    if (a.count() != 0) throw std::runtime_error("merge empty into empty should stay empty");
    b.add(1.0);
    a.merge(b);
    if (a.count() != 1) throw std::runtime_error("merge non-empty into empty should copy");
    if (!almost_equal(a.mean(), 1.0)) throw std::runtime_error("mean after merge should be 1");
}

static void test_merge_nonempty() {
    RunningStats a, b;
    a.add(1.0);
    a.add(2.0);
    b.add(3.0);
    b.add(4.0);
    a.merge(b);
    if (a.count() != 4) throw std::runtime_error("count should be 4");
    if (!almost_equal(a.mean(), 2.5)) throw std::runtime_error("mean should be 2.5");
    if (!almost_equal(a.minimum(), 1.0)) throw std::runtime_error("min should be 1");
    if (!almost_equal(a.maximum(), 4.0)) throw std::runtime_error("max should be 4");
}

static void test_self_merge() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    double orig_mean = rs.mean();
    double orig_var = rs.variance();
    rs.merge(rs);
    if (rs.count() != 4) throw std::runtime_error("count after self-merge should be 4");
    if (!almost_equal(rs.mean(), orig_mean)) throw std::runtime_error("mean after self-merge should not change");
    if (!almost_equal(rs.variance(), orig_var)) throw std::runtime_error("variance after self-merge should not change");
}

static void test_nan_rejection() {
    RunningStats rs;
    bool threw = false;
    try { rs.add(std::numeric_limits<double>::quiet_NaN()); } catch (const std::invalid_argument&) { threw = true; }
    if (!threw) throw std::runtime_error("add(NaN) should throw");
    if (rs.count() != 0) throw std::runtime_error("state should not change after NaN");
}

static void test_inf_rejection() {
    RunningStats rs;
    bool threw = false;
    try { rs.add(std::numeric_limits<double>::infinity()); } catch (const std::invalid_argument&) { threw = true; }
    if (!threw) throw std::runtime_error("add(inf) should throw");
    if (rs.count() != 0) throw std::runtime_error("state should not change after inf");
}

static void test_large_values() {
    RunningStats rs;
    double base = 1e9;
    rs.add(base + 1.0);
    rs.add(base + 2.0);
    rs.add(base + 3.0);
    if (!almost_equal(rs.mean(), base + 2.0)) throw std::runtime_error("mean with large values should be accurate");
    if (!almost_equal(rs.variance(), 2.0/3.0)) throw std::runtime_error("variance with large values should be accurate");
}

static void test_merge_preserves_min_max() {
    RunningStats a, b;
    a.add(1.0);
    a.add(10.0);
    b.add(5.0);
    b.add(15.0);
    a.merge(b);
    if (!almost_equal(a.minimum(), 1.0)) throw std::runtime_error("min should be 1");
    if (!almost_equal(a.maximum(), 15.0)) throw std::runtime_error("max should be 15");
}

static void run_all_tests() {
    test_empty_stats();
    test_single_value();
    test_multiple_values();
    test_merge_empty();
    test_merge_nonempty();
    test_self_merge();
    test_nan_rejection();
    test_inf_rejection();
    test_large_values();
    test_merge_preserves_min_max();
    std::cout << "All tests passed.\n";
}

int main() {
    try {
        run_all_tests();
    } catch (const std::exception& e) {
        std::cerr << "Test failed: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
