# RunningStats

A C++20 library for computing running statistics using stable online algorithms.

## Features

- Add values one at a time with `add(double)`
- Merge two `RunningStats` instances with `merge(const RunningStats&)`
- Query statistics: `count()`, `mean()`, `variance()`, `minimum()`, `maximum()`

## Usage

```cpp
#include "stats.hpp"

RunningStats rs;
rs.add(1.0);
rs.add(2.0);
rs.add(3.0);

std::cout << "Count: " << rs.count() << "\n";
std::cout << "Mean: " << rs.mean() << "\n";
std::cout << "Variance: " << rs.variance() << "\n";
std::cout << "Min: " << rs.minimum() << "\n";
std::cout << "Max: " << rs.maximum() << "\n";
```

## Error handling

- `add(double)` throws `std::invalid_argument` for NaN or infinity.
- `mean()`, `variance()`, `minimum()`, `maximum()` throw `std::domain_error` if called on an empty instance.

## Building

```bash
mkdir build && cd build
cmake .. && make
```
