#include "stats.hpp"
#include <cmath>
#include <limits>

void RunningStats::add(double x) {
    if (std::isnan(x) || std::isinf(x)) {
        throw std::invalid_argument("NaN or infinity not allowed");
    }
    if (!has_value) {
        min_val = x;
        max_val = x;
        has_value = true;
    } else {
        if (x < min_val) min_val = x;
        if (x > max_val) max_val = x;
    }
    ++n;
    sum += x;
    sum_sq += x * x;
}

void RunningStats::merge(const RunningStats& other) {
    if (other.n == 0) {
        return;
    }
    if (n == 0) {
        n = other.n;
        sum = other.sum;
        sum_sq = other.sum_sq;
        min_val = other.min_val;
        max_val = other.max_val;
        has_value = other.has_value;
        return;
    }
    n += other.n;
    sum += other.sum;
    sum_sq += other.sum_sq;
    if (other.min_val < min_val) min_val = other.min_val;
    if (other.max_val > max_val) max_val = other.max_val;
}

std::uint64_t RunningStats::count() const {
    return n;
}

double RunningStats::mean() const {
    if (n == 0) {
        throw std::domain_error("mean of empty RunningStats");
    }
    return sum / n;
}

double RunningStats::variance() const {
    if (n == 0) {
        throw std::domain_error("variance of empty RunningStats");
    }
    double m = mean();
    return sum_sq / n - m * m;
}

double RunningStats::minimum() const {
    if (!has_value) {
        throw std::domain_error("minimum of empty RunningStats");
    }
    return min_val;
}

double RunningStats::maximum() const {
    if (!has_value) {
        throw std::domain_error("maximum of empty RunningStats");
    }
    return max_val;
}
