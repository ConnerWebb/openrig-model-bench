#pragma once
#include <cstdint>
#include <stdexcept>

class RunningStats {
public:
    void add(double x);
    void merge(const RunningStats& other);
    std::uint64_t count() const;
    double mean() const;
    double variance() const;
    double minimum() const;
    double maximum() const;

private:
    std::uint64_t n = 0;
    double sum = 0.0;
    double sum_sq = 0.0;
    double min_val = 0.0;
    double max_val = 0.0;
    bool has_value = false;
};
