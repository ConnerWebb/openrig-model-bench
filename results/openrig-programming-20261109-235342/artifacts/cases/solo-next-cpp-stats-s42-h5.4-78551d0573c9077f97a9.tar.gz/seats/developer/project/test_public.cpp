#include "stats.hpp"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <limits>
#include <cassert>

static bool almost_equal(double a, double b, double abs_tol = 1e-4, double rel_tol = 1e-6) {
    if (a == b) return true;
    double diff = std::abs(a - b);
    if (diff <= abs_tol) return true;
    double max_abs = std::max(std::abs(a), std::abs(b));
    return diff <= max_abs * rel_tol;
}

static void test_case(const std::string& input_line, const std::vector<double>& expected) {
    std::istringstream iss(input_line);
    int n, split, self;
    iss >> n >> split >> self;
    RunningStats a, b;
    for (int i = 0; i < n; ++i) {
        std::string token;
        iss >> token;
        double x = std::stod(token);
        if (i < split) a.add(x);
        else b.add(x);
    }
    a.merge(b);
    if (self) a.merge(a);
    assert(almost_equal(a.count(), expected[0]));
    assert(almost_equal(a.mean(), expected[1]));
    assert(almost_equal(a.variance(), expected[2]));
    assert(almost_equal(a.minimum(), expected[3]));
    assert(almost_equal(a.maximum(), expected[4]));
}

static void test_nan_rejection() {
    RunningStats rs;
    bool threw = false;
    try { rs.add(std::numeric_limits<double>::quiet_NaN()); } catch (const std::invalid_argument&) { threw = true; }
    assert(threw && rs.count() == 0);
}

static void test_inf_rejection() {
    RunningStats rs;
    bool threw = false;
    try { rs.add(std::numeric_limits<double>::infinity()); } catch (const std::invalid_argument&) { threw = true; }
    assert(threw && rs.count() == 0);
}

static void test_empty_error() {
    RunningStats rs;
    bool threw = false;
    try { rs.mean(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
    threw = false;
    try { rs.variance(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
    threw = false;
    try { rs.minimum(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
    threw = false;
    try { rs.maximum(); } catch (const std::domain_error&) { threw = true; }
    assert(threw);
}

static void test_merge_empty() {
    RunningStats a, b;
    a.merge(b);
    assert(a.count() == 0);
    b.add(1.0);
    a.merge(b);
    assert(a.count() == 1);
    assert(almost_equal(a.mean(), 1.0));
}

static void test_self_merge() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    double orig_mean = rs.mean();
    double orig_var = rs.variance();
    rs.merge(rs);
    assert(rs.count() == 4);
    assert(almost_equal(rs.mean(), orig_mean));
    assert(almost_equal(rs.variance(), orig_var));
}

int main() {
    test_case("42 9 0 1000000030.0 1000000058.0 999999902.0 999999967.0 999999939.0 1000000093.0 999999951.0 999999967.0 999999922.0 999999951.0 1000000031.0 999999914.0 1000000052.0 999999949.0 1000000029.0 999999906.0 1000000077.0 1000000034.0 999999993.0 1000000017.0 999999994.0 999999933.0 999999989.0 1000000065.0 999999942.0 999999909.0 999999989.0 1000000055.0 999999907.0 999999999.0 1000000065.0 1000000049.0 999999948.0 999999938.0 999999982.0 1000000011.0 1000000014.0 999999924.0 1000000069.0 999999905.0 999999963.0 1000000054.0",
              {42, 999999990.1428572, 3446.598639455782, 999999902.0, 1000000094.0});
    test_case("20 15 1 999999963.0 1000000088.0 1000000031.0 999999990.0 999999976.0 1000000048.0 999999904.0 999999964.0 999999989.0 999999953.0 1000000000.0 999999907.0 999999917.0 999999924.0 999999963.0 999999925.0 999999975.0 999999935.0 1000000006.0 1000000022.0",
              {40, 999999974.0, 2302.7, 999999904.0, 1000000088.0});
    test_case("73 1 0 1000000052.0 999999991.0 999999975.0 999999924.0 999999952.0 999999977.0 1000000059.0 999999955.0 999999941.0 1000000047.0 1000000012.0 1000000021.0 1000000039.0 999999982.0 999999966.0 999999924.0 1000000072.0 1000000092.0 1000000091.0 1000000059.0 1000000095.0 1000000059.0 999999966.0 1000000079.0 1000000091.0 999999906.0 999999908.0 999999948.0 999999956.0 1000000020.0 999999983.0 1000000079.0 1000000029.0 1000000029.0 999999978.0 999999962.0 999999969.0 999999936.0 999999913.0 1000000027.0 1000000037.0 1000000019.0 999999961.0 999999932.0 1000000053.0 999999923.0 999999954.0 1000000060.0 1000000012.0 999999971.0 1000000019.0 1000000008.0 999999966.0 999999979.0 999999996.0 1000000036.0 1000000084.0 999999981.0 1000000059.0 1000000024.0 1000000040.0 1000000026.0 999999901.0 1000000004.0 999999955.0 1000000016.0 999999977.0 1000000065.0 1000000045.0 1000000028.0 1000000072.0 999999974.0 1000000075.0",
              {73, 1000000004.3287672, 2769.6179395759054, 999999901.0, 1000000095.0});
    test_case("7 2 1 1000000008.0 1000000008.0 999999916.0 999999982.0 999999963.0 999999987.0 1000000053.0",
              {14, 999999988.1428572, 1552.9795918367347, 999999916.0, 1000000053.0});
    test_nan_rejection();
    test_inf_rejection();
    test_empty_error();
    test_merge_empty();
    test_self_merge();
    std::cout << "All public tests passed.\n";
    return 0;
}
