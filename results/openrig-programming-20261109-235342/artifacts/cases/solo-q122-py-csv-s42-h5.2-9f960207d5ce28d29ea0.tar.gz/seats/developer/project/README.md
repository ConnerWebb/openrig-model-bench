# CSV Aggregation Solution

This module provides an `aggregate` function that reads a UTF-8 CSV file and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted categories with totals formatted to 2 decimal places.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to formatted totals (2 decimal places)
        
    Raises:
        ValueError: If the CSV is malformed (invalid header, wrong field count,
                   empty category, invalid amount format, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank record must have exactly two fields
- **Category**: Whitespace is stripped; must not be empty after stripping
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits before the decimal point
  - Optional decimal point followed by 1-2 decimal digits
  - No exponent notation, no `NaN`, no negative values
- **Quoted fields**: Standard CSV quoting rules apply (embedded commas, newlines, escaped quotes)
- **Blank records**: Completely blank lines are ignored

## Example

```python
>>> aggregate('data.csv')
{'a,b': '599.14', 'food': '2262.01', 'rent': '2215.92'}
```

## Running Tests

```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
