"""Tests for solution.py aggregate function."""
import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.25\nfood,5.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.25'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_quoted_fields_with_newlines(self):
        """Test quoted fields containing newlines."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"line1\nline2",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'line1\nline2': '50.00'})
    
    def test_empty_category_rejected(self):
        """Test that empty category raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_rejected(self):
        """Test that invalid header raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,header\nx,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_wrong_field_count_rejected(self):
        """Test that wrong field count raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.00,extra\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_format_rejected(self):
        """Test that invalid amount format raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_with_plus_sign(self):
        """Test amount with optional plus sign."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.50'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.00\n\ny,20.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.00', 'y': '20.00'})
    
    def test_sorted_output(self):
        """Test that output keys are sorted."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nz,1.00\na,2.00\nm,3.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['a', 'm', 'z'])
    
    def test_two_decimal_places(self):
        """Test that amounts are formatted to exactly 2 decimal places."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.00'})
    
    def test_unicode_categories(self):
        """Test unicode category names."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n日本,100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00'})
    
    def test_amount_with_one_decimal_digit(self):
        """Test amount with one decimal digit."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.5\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.50'})
    
    def test_amount_with_two_decimal_digits(self):
        """Test amount with two decimal digits."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.55\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '10.55'})
    
    def test_amount_with_many_digits(self):
        """Test amount with up to 12 digits before decimal."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,123456789012.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '123456789012.00'})
    
    def test_amount_too_many_digits_rejected(self):
        """Test that amount with more than 12 digits is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1234567890123.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_with_three_decimal_digits_rejected(self):
        """Test that amount with 3 decimal digits is rejected."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,10.123\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file_rejected(self):
        """Test that empty file raises ValueError."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only_file(self):
        """Test file with only header returns empty dict."""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
