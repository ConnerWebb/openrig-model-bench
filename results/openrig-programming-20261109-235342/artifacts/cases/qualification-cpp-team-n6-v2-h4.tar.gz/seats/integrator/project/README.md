# C++20 Local Analytics Toolkit

A header-only C++20 analytics toolkit with three modules:

- **parser.hpp**: CSV parsing with `aggregate(std::istream&)` - parses `category,amount` CSV with quoted fields, returns sorted `std::map<std::string,int64_t>` of category totals
- **cache.hpp**: LRU cache `LruCache` with O(1) get/put/erase operations
- **stats.hpp**: Running statistics `RunningStats` with online mean/variance/minimum/maximum computation

## Usage

```cpp
#include "solution.hpp"  // Umbrella header including all modules
```

See individual module headers for API details.
