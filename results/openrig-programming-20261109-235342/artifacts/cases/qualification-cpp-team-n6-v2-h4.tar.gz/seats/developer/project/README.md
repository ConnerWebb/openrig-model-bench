# CSV Aggregator

Header-only C++20 CSV parser that aggregates amounts by category.

## Usage

```cpp
#include "parser.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::stringstream ss(R"(category,amount
food,100
rent,200
food,50)");
    auto result = aggregate(ss);
    for (const auto& [k, v] : result) {
        std::cout << k << ": " << v << "\n";
    }
}
```

## Features

- Parses CSV with header `category,amount`
- Handles quoted fields with embedded commas, newlines, and escaped quotes
- Strips whitespace from fields
- Aggregates amounts per category
- Returns sorted map of results
- Throws `std::invalid_argument` on malformed input or overflow
