import unittest
import subprocess
import tempfile
import os

class ModuleCheck(unittest.TestCase):
    def test_parser(self):
        code = '''
#include "/work/parser.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::stringstream ss("category,amount\\nfood,100\\nrent,200\\n");
    auto result = aggregate(ss);
    std::cout << result["food"] << " " << result["rent"] << std::endl;
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            cpp = os.path.join(tmpdir, "test.cpp")
            exe = os.path.join(tmpdir, "test")
            with open(cpp, "w") as f:
                f.write(code)
            subprocess.run(["clang++", "-fuse-ld=bfd", "-std=c++20", "-o", exe, cpp], check=True, capture_output=True)
            result = subprocess.run([exe], capture_output=True, text=True, cwd=tmpdir)
            self.assertEqual(result.stdout.strip(), "100 200")

if __name__ == "__main__":
    unittest.main()
