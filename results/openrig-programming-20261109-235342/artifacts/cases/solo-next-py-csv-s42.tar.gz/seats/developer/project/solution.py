"""CSV aggregation module."""

import csv
import io
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.

    Header must be exactly 'category,amount'.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits.
    Reject all malformed input with ValueError.
    Return category keys sorted, totals formatted with exactly two decimal places.
    """
    totals: dict[str, Decimal] = {}

    with open(path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)

        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")

        if header != ["category", "amount"]:
            raise ValueError("Header must be exactly 'category,amount'")

        for row in reader:
            # Check for blank records (completely empty or only whitespace)
            if not row or all(cell.strip() == "" for cell in row):
                continue

            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Record must have exactly two fields: {row}")

            category, amount_str = row

            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()

            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")

            # Validate and parse amount
            amount = _parse_amount(amount_str)

            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount

    # Return sorted keys with totals formatted to exactly two decimal places
    return {k: f"{totals[k]:.2f}" for k in sorted(totals.keys())}


def _parse_amount(amount_str: str) -> Decimal:
    """
    Parse an amount string.

    Format: optional +, 1-12 decimal digits, optional decimal point followed by 1-2 digits.
    Must be nonnegative, finite, no exponent.
    """
    if not amount_str:
        raise ValueError("Amount is empty")

    # Check for exponent (not allowed)
    if "e" in amount_str.lower():
        raise ValueError(f"Invalid amount format: {amount_str}")

    # Validate format with regex-like checks
    # Optional +, then 1-12 digits, optionally followed by . and 1-2 digits
    parts = amount_str.split(".")

    if len(parts) > 2:
        raise ValueError(f"Invalid amount format: {amount_str}")

    int_part = parts[0]
    frac_part = parts[1] if len(parts) == 2 else ""

    # Check for + sign
    if int_part.startswith("+"):
        int_part = int_part[1:]

    # Integer part: 1-12 digits
    if not int_part:
        raise ValueError(f"Invalid amount format: {amount_str}")
    if len(int_part) > 12:
        raise ValueError(f"Invalid amount format: {amount_str}")
    if not int_part.isdigit():
        raise ValueError(f"Invalid amount format: {amount_str}")

    # Fractional part: if present, 1-2 digits
    if frac_part:
        if len(frac_part) > 2:
            raise ValueError(f"Invalid amount format: {amount_str}")
        if not frac_part.isdigit():
            raise ValueError(f"Invalid amount format: {amount_str}")

    # Parse as Decimal
    try:
        value = Decimal(amount_str)
    except InvalidOperation:
        raise ValueError(f"Invalid amount format: {amount_str}")

    # Check for infinity (should not happen with Decimal from valid string, but be safe)
    if not value.is_finite():
        raise ValueError(f"Amount must be finite: {amount_str}")

    # Check for negative (should not happen with our format, but be safe)
    if value < 0:
        raise ValueError(f"Amount must be nonnegative: {amount_str}")

    return value
