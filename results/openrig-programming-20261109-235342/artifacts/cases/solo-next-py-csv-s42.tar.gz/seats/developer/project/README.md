# CSV Aggregation

This module provides a function to aggregate amounts from a CSV file by category.

## Usage

```python
from solution import aggregate

result = aggregate("data.csv")
print(result)
# {'category1': '123.45', 'category2': '678.90'}
```

## CSV Format

- Header must be exactly `category,amount`
- Blank records are ignored
- Each non-blank record must have exactly two fields
- Category and amount are stripped of whitespace
- Category must not be empty
- Amount format: optional `+`, 1-12 decimal digits, optional decimal point followed by 1-2 digits
- No negative values or exponents allowed
- Quoted commas and embedded newlines in fields are supported (standard CSV quoting)

## Error Handling

- Empty CSV file raises `ValueError`
- Header mismatch raises `ValueError`
- Empty category raises `ValueError`
- Invalid amount format raises `ValueError`
- Negative amount raises `ValueError`
- Exponent in amount raises `ValueError`
- Wrong number of fields raises `ValueError`

## Testing

Run tests with:

```bash
python -m unittest test_solution
```
