"""Tests for solution.py aggregate function."""

import csv
import os
import tempfile
import unittest

from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for aggregate function."""

    def _write_csv(self, content: str) -> str:
        """Write CSV content to a temporary file and return its path."""
        fd, path = tempfile.mkstemp(suffix=".csv")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)
            return path
        except Exception:
            os.unlink(path)
            raise

    def test_basic_aggregation(self) -> None:
        """Test basic aggregation with simple categories."""
        csv_content = "category,amount\nfood,100.50\nrent,200.25\nfood,50.25"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["food"], "150.75")
            self.assertEqual(result["rent"], "200.25")
        finally:
            os.unlink(path)

    def test_whitespace_stripping(self) -> None:
        """Test that whitespace is stripped from category and amount."""
        csv_content = "category,amount\n  food  ,  100.50  "
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["food"], "100.50")
        finally:
            os.unlink(path)

    def test_empty_category_rejected(self) -> None:
        """Test that empty category is rejected."""
        csv_content = "category,amount\n,100.50"
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_blank_records_ignored(self) -> None:
        """Test that blank records are ignored."""
        csv_content = "category,amount\nfood,100.50\n\n\nrent,200.25"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["food"], "100.50")
            self.assertEqual(result["rent"], "200.25")
        finally:
            os.unlink(path)

    def test_quoted_comma_in_category(self) -> None:
        """Test that quoted commas in category are handled correctly."""
        csv_content = 'category,amount\n"a,b",100.50'
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["a,b"], "100.50")
        finally:
            os.unlink(path)

    def test_embedded_newline_in_category(self) -> None:
        """Test that embedded newlines in category are handled correctly."""
        csv_content = 'category,amount\n"two\nlines",100.50'
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["two\nlines"], "100.50")
        finally:
            os.unlink(path)

    def test_quoted_quotes_in_category(self) -> None:
        """Test that quoted quotes in category are handled correctly."""
        csv_content = 'category,amount\n"x""quote",100.50'
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result['x"quote'], "100.50")
        finally:
            os.unlink(path)

    def test_positive_sign_allowed(self) -> None:
        """Test that + sign in amount is allowed."""
        csv_content = "category,amount\nfood,+100.50"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["food"], "100.50")
        finally:
            os.unlink(path)

    def test_amount_decimal_places(self) -> None:
        """Test amount with 1-2 decimal places."""
        csv_content = "category,amount\nfood,100.5"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["food"], "100.50")
        finally:
            os.unlink(path)

    def test_amount_no_decimal_point(self) -> None:
        """Test amount without decimal point."""
        csv_content = "category,amount\nfood,100"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["food"], "100.00")
        finally:
            os.unlink(path)

    def test_header_mismatch_rejected(self) -> None:
        """Test that header mismatch is rejected."""
        csv_content = "cat,amount\nfood,100.50"
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_empty_csv_rejected(self) -> None:
        """Test that empty CSV is rejected."""
        path = self._write_csv("")
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_header_only(self) -> None:
        """Test CSV with only header."""
        path = self._write_csv("category,amount")
        try:
            result = aggregate(path)
            self.assertEqual(result, {})
        finally:
            os.unlink(path)

    def test_invalid_amount_format_rejected(self) -> None:
        """Test that invalid amount format is rejected."""
        csv_content = "category,amount\nfood,100.500"  # 3 decimal places
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_amount_with_exponent_rejected(self) -> None:
        """Test that amount with exponent is rejected."""
        csv_content = "category,amount\nfood,1e5"
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_negative_amount_rejected(self) -> None:
        """Test that negative amount is rejected."""
        csv_content = "category,amount\nfood,-100.50"
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_too_many_fields_rejected(self) -> None:
        """Test that records with more than 2 fields are rejected."""
        csv_content = "category,amount\nfood,100.50,extra"
        path = self._write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_unicode_category(self) -> None:
        """Test that Unicode categories are handled correctly."""
        csv_content = "category,amount\n日本,100.50"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result["日本"], "100.50")
        finally:
            os.unlink(path)

    def test_sorted_keys(self) -> None:
        """Test that keys are returned sorted."""
        csv_content = "category,amount\nzebra,100.50\napple,50.25\nmango,75.00"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            keys = list(result.keys())
            self.assertEqual(keys, sorted(keys))
        finally:
            os.unlink(path)

    def test_public_case_1(self) -> None:
        """Test first public case."""
        csv_content = "category,amount\n\"x\"\"quote\",812.68\nfood,347.25\nrent,991.77\nrent,345.17\nfood,261.47\n\"x\"\"quote\",71.74\n\"x\"\"quote\",254.02\n\"x\"\"quote\",31.70\n日本,690.39\n\"a,b\",599.14\nrent,457.86\n日本,218.62\nfood,455.70\n\"x\"\"quote\",39.70\n\"two\nlines\",849.77\n\"x\"\"quote\",248.76\nrent,421.12\n\"two\nlines\",584.47\nfood,870.27\nfood,327.32"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            expected = {
                "a,b": "599.14",
                "food": "2262.01",
                "rent": "2215.92",
                "two\nlines": "1434.24",
                'x"quote': "1458.60",
                "日本": "909.01",
            }
            self.assertEqual(result, expected)
        finally:
            os.unlink(path)

    def test_public_case_2(self) -> None:
        """Test second public case."""
        csv_content = "category,amount\nrent,204.44\nrent,965.51\n\"x\"\"quote\",464.96\n\"a,b\",758.07\nfood,329.33\n\"a,b\",273.11\n\"two\nlines\",38.36\nfood,127.88\nrent,128.71\n\"a,b\",182.35\n\"two\nlines\",626.01\n\"two\nlines\",741.38\n\"x\"\"quote\",469.53\n\"a,b\",124.37\nrent,397.36\n\"x\"\"quote\",283.13\nrent,754.49\n\"two\nlines\",624.22\n\"x\"\"quote\",420.82\n\"a,b\",124.22\n日本,984.39\n日本,817.87\n\"x\"\"quote\",338.00\n日本,978.27\nfood,45.98\nrent,290.01\n\"two\nlines\",427.32\n日本,660.85\n\"x\"\"quote\",402.73\nrent,353.84\nrent,70.22\n\"two\nlines\",704.87\n\"two\nlines\",312.64\nrent,788.02\nfood,277.54\n日本,577.44\n\"a,b\",612.46\n\"two\nlines\",339.11"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            expected = {
                "a,b": "2074.58",
                "food": "780.73",
                "rent": "3952.60",
                "two\nlines": "3813.91",
                'x"quote': "2379.17",
                "日本": "4018.82",
            }
            self.assertEqual(result, expected)
        finally:
            os.unlink(path)

    def test_public_case_3(self) -> None:
        """Test third public case."""
        csv_content = "category,amount\n\"two\nlines\",701.11\n日本,417.63\n\"x\"\"quote\",636.47\n\"x\"\"quote\",645.43\nfood,534.59\nrent,595.15\n\"a,b\",845.38\n\"x\"\"quote\",656.79\n日本,380.85\n日本,17.78\nfood,553.84\n\"two\nlines\",84.37\n\"a,b\",325.24\n\"a,b\",783.67\n日本,198.80\n\"two\nlines\",889.26\n\"x\"\"quote\",727.84\n\"a,b\",777.27\n\"two\nlines\",64.97"
        path = self._write_csv(csv_content)
        try:
            result = aggregate(path)
            expected = {
                "a,b": "2731.56",
                "food": "1088.43",
                "rent": "595.15",
                "two\nlines": "1739.71",
                'x"quote': "2666.53",
                "日本": "1015.06",
            }
            self.assertEqual(result, expected)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
