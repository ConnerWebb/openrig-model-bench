# Buffer Library

A C++20 buffer implementation with deep-copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **RAII-based**: Automatic resource management with proper destructor
- **Deep copy**: Copy constructor and assignment perform deep copies
- **Noexcept moves**: Move operations are noexcept and leave moved-from buffers in a reusable state (size 0)
- **Bounds checking**: `operator[]` throws `std::out_of_range` on invalid indices
- **Resize with preservation**: `resize()` preserves existing prefix and zero-initializes new elements

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized.

### Destructor
```cpp
~Buffer();
```
Frees the underlying memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy semantics.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Noexcept move operations. Moved-from buffer has size 0 and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
Bounds-checked access. Throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes the buffer to `k` bytes, preserving the prefix and zero-initializing new bytes.

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

## Running Public Tests

```bash
clang++ -std=c++20 -fuse-ld=bfd -o driver PUBLIC_DRIVER.cpp
./driver < public-inputs/case-00.json
```
