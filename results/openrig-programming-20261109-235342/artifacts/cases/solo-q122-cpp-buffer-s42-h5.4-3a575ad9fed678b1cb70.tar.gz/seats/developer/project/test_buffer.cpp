#include <iostream>
#include <cassert>
#include <stdexcept>
#include <type_traits>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    a[0] = 99;
    assert(b[0] == 10);  // Deep copy verified
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 10);
    a[0] = 99;
    assert(b[0] == 10);  // Deep copy verified
    std::cout << "test_copy_assignment passed\n";
}

void test_move_constructor() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>, "Move constructor must be noexcept");
    Buffer a(5);
    a[0] = 10;
    std::size_t old_size = a.size();
    Buffer b(std::move(a));
    assert(b.size() == old_size);
    assert(b[0] == 10);
    assert(a.size() == 0);  // Moved-from buffer has size 0
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    static_assert(std::is_nothrow_move_assignable_v<Buffer>, "Move assignment must be noexcept");
    Buffer a(5);
    a[0] = 10;
    Buffer b(3);
    std::size_t old_size = a.size();
    b = std::move(a);
    assert(b.size() == old_size);
    assert(b[0] == 10);
    assert(a.size() == 0);  // Moved-from buffer has size 0
    std::cout << "test_move_assignment passed\n";
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 10;
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 10);
    std::cout << "test_self_copy passed\n";
}

void test_self_move() {
    Buffer a(5);
    a[0] = 10;
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 10);
    std::cout << "test_self_move passed\n";
}

void test_bounds_check() {
    Buffer a(5);
    bool caught = false;
    try {
        (void)a[5];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    caught = false;
    try {
        (void)a[100];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    std::cout << "test_bounds_check passed\n";
}

void test_resize_preserve_prefix() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    a.resize(10);
    assert(a.size() == 10);
    assert(a[0] == 1);
    assert(a[4] == 5);
    assert(a[5] == 0);
    assert(a[9] == 0);
    std::cout << "test_resize_preserve_prefix passed\n";
}

void test_resize_shrink() {
    Buffer a(10);
    a[0] = 1;
    a[5] = 5;
    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[4] == 0);  // Was not set
    std::cout << "test_resize_shrink passed\n";
}

void test_resize_zero_init() {
    Buffer a(0);
    a.resize(5);
    assert(a.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(a[i] == 0);
    }
    std::cout << "test_resize_zero_init passed\n";
}

void test_moved_from_reusable() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    a.resize(3);
    assert(a.size() == 3);
    a[0] = 100;
    assert(a[0] == 100);
    std::cout << "test_moved_from_reusable passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_self_copy();
    test_self_move();
    test_bounds_check();
    test_resize_preserve_prefix();
    test_resize_shrink();
    test_resize_zero_init();
    test_moved_from_reusable();
    std::cout << "All tests passed!\n";
    return 0;
}
