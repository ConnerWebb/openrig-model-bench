#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <utility>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Constructor
    Buffer(std::size_t n = 0) : p(n > 0 ? new std::uint8_t[n]{} : nullptr), n(n) {}

    // Destructor
    ~Buffer() {
        delete[] p;
    }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p(other.n > 0 ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (p && other.p) {
            for (std::size_t i = 0; i < n; ++i) {
                p[i] = other.p[i];
            }
        }
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] p;
            n = other.n;
            p = n > 0 ? new std::uint8_t[n] : nullptr;
            if (p && other.p) {
                for (std::size_t i = 0; i < n; ++i) {
                    p[i] = other.p[i];
                }
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Size accessor
    std::size_t size() const noexcept {
        return n;
    }

    // Mutable operator[] with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const operator[] with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize: preserve prefix, zero-initialize new bytes
    void resize(std::size_t k) {
        if (k == n) {
            return;
        }
        std::uint8_t* new_p = k > 0 ? new std::uint8_t[k]{} : nullptr;
        if (p && new_p) {
            std::size_t copy_len = n < k ? n : k;
            for (std::size_t i = 0; i < copy_len; ++i) {
                new_p[i] = p[i];
            }
        }
        delete[] p;
        p = new_p;
        n = k;
    }
};
