"""Unit tests for ledger processing."""
import unittest
import copy
import ledger


class TestLedgerProcess(unittest.TestCase):
    """Tests for ledger.process function."""

    def test_empty_input(self):
        """process([]) returns empty events and totals."""
        result = ledger.process([])
        self.assertEqual(result['events'], [])
        self.assertEqual(result['totals'], {})

    def test_single_valid_record(self):
        """Single valid record is returned with correct totals."""
        records = [{'id': 'x', 'category': 'a', 'cents': 100}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0], {'id': 'x', 'category': 'a', 'cents': 100})
        self.assertEqual(result['totals'], {'a': 100})

    def test_whitespace_stripping(self):
        """Whitespace is stripped from id and category."""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 50}]
        result = ledger.process(records)
        self.assertEqual(result['events'][0]['id'], 'x')
        self.assertEqual(result['events'][0]['category'], 'a')

    def test_duplicate_id_first_wins(self):
        """First occurrence of an id wins; duplicates are ignored."""
        records = [
            {'id': 'x', 'category': 'a', 'cents': 100},
            {'id': 'x', 'category': 'b', 'cents': 200}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'a')
        self.assertEqual(result['totals'], {'a': 100})

    def test_minimum_cents_filter(self):
        """Records below minimum_cents are excluded."""
        records = [
            {'id': 'x', 'category': 'a', 'cents': 50},
            {'id': 'y', 'category': 'b', 'cents': 150}
        ]
        result = ledger.process(records, minimum_cents=100)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'y')
        self.assertEqual(result['totals'], {'b': 150})

    def test_minimum_cents_zero_default(self):
        """minimum_cents defaults to 0."""
        records = [{'id': 'x', 'category': 'a', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['totals'], {'a': 0})

    def test_totals_sorted(self):
        """Totals keys are sorted alphabetically."""
        records = [
            {'id': 'x', 'category': 'c', 'cents': 1},
            {'id': 'y', 'category': 'a', 'cents': 2},
            {'id': 'z', 'category': 'b', 'cents': 3}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_input_not_mutated(self):
        """Original records are not mutated."""
        records = [{'id': 'x', 'category': ' a ', 'cents': 100}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_boolean_cents_invalid(self):
        """Boolean values for cents raise ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_negative_cents_invalid(self):
        """Negative cents raise ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_empty_id_invalid(self):
        """Empty or whitespace-only id raises ValueError."""
        records = [{'id': '', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_extra_fields_invalid(self):
        """Records with extra fields raise ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_minimum_cents_nonnegative_required(self):
        """Negative minimum_cents raises ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)

    def test_minimum_cents_boolean_rejected(self):
        """Boolean minimum_cents raises ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)


if __name__ == '__main__':
    unittest.main()
