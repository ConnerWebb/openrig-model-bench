"""Implementation module for ledger processing."""
import copy


def _is_valid_cents(value):
    """Check if cents is a nonnegative integer (excluding booleans)."""
    if isinstance(value, bool):
        return False
    if not isinstance(value, int):
        return False
    return value >= 0


def _validate_record(record):
    """Validate a single record and return a normalized copy."""
    if not isinstance(record, dict):
        raise ValueError("Record must be a dict")
    if 'id' not in record or 'category' not in record or 'cents' not in record:
        raise ValueError("Record must have id, category, and cents fields")
    if len(record) != 3:
        raise ValueError("Record must have exactly id, category, and cents fields")

    rec_id = record['id']
    if not isinstance(rec_id, str) or rec_id.strip() == '':
        raise ValueError("id must be a nonempty stripped string")

    category = record['category']
    if not isinstance(category, str) or category.strip() == '':
        raise ValueError("category must be a nonempty stripped string")

    cents = record['cents']
    if not _is_valid_cents(cents):
        raise ValueError("cents must be a nonnegative integer")

    return {
        'id': rec_id.strip(),
        'category': category.strip(),
        'cents': cents
    }


def process(records, minimum_cents=0):
    """Process records and return events and totals."""
    if not isinstance(minimum_cents, int) or isinstance(minimum_cents, bool) or minimum_cents < 0:
        raise ValueError("minimum_cents must be a nonnegative integer")

    if not isinstance(records, list):
        raise ValueError("records must be a list")

    seen_ids = set()
    events = []
    totals = {}

    for record in records:
        normalized = _validate_record(record)

        if normalized['id'] in seen_ids:
            continue
        seen_ids.add(normalized['id'])

        if normalized['cents'] < minimum_cents:
            continue

        events.append(copy.deepcopy(normalized))

        cat = normalized['category']
        totals[cat] = totals.get(cat, 0) + normalized['cents']

    sorted_totals = dict(sorted(totals.items()))

    return {'events': events, 'totals': sorted_totals}
