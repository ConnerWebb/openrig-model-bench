# Ledger Processing Module

This project provides a ledger processing module with validation, deduplication, and aggregation.

## Files

- `ledger.py` - Public facade exposing `process(records, minimum_cents=0)`
- `engine.py` - Implementation with validation and business logic
- `test_ledger.py` - Unit tests using `unittest`
- `PUBLIC_DRIVER.py` - Public test driver for grading

## API

### `process(records, minimum_cents=0)`

Processes a list of records and returns:

```python
{
    'events': [
        {'id': 'stripped_id', 'category': 'stripped_category', 'cents': int},
        ...
    ],
    'totals': {
        'category': sum_cents,
        ...
    }
}
```

- `events`: List of unique records (first occurrence wins) filtered by `minimum_cents`, in input order.
- `totals`: Dictionary of category sums with keys sorted alphabetically.

## Validation Rules

- Each record must be a dict with exactly three keys: `id`, `category`, `cents`.
- `id`: nonempty stripped string.
- `category`: nonempty stripped string.
- `cents`: nonnegative integer (booleans are invalid).
- `minimum_cents`: nonnegative integer (booleans are invalid).

Invalid input raises `ValueError`.

## Running Tests

```bash
python3 test_ledger.py
```

## Public Driver

Run with:

```bash
python3 PUBLIC_DRIVER.py < public-inputs/case-XX.json
```
