# Expression Evaluator

This project implements an integer arithmetic expression evaluator that supports:
- Basic operations: `+`, `-`, `*`, `//` (floor division)
- Parentheses for grouping
- Unary `+` and `-` operators
- Whitespace handling

## Features

- Parses expressions with proper operator precedence
- Handles negative numbers with unary minus
- Uses Python floor division for all division operations
- Validates input for:
  - Empty expressions
  - Unsupported syntax (e.g., `/`, `**`)
  - Variable names
  - Floats and booleans
  - Division by zero
  - Text length > 4096
  - Integer tokens with > 50 digits
  - Nesting/depth > 100
  - Intermediate values with abs(value) > 10^100

## Usage

```python
from solution import evaluate

# Basic arithmetic
result = evaluate("1 + 2 * 3")  # Returns 7

# Parentheses
result = evaluate("(1 + 2) * 3")  # Returns 9

# Negative numbers
result = evaluate("-5 + 3")  # Returns -2

# Floor division
result = evaluate("7 // 3")  # Returns 2
result = evaluate("-7 // 3")  # Returns -3 (Python floor division)

# Error handling
try:
    result = evaluate("1/2")  # Raises ValueError (unsupported operator)
except ValueError as e:
    print(f"Error: {e}")
```

## Implementation Details

The evaluator uses a recursive descent parser with the following grammar:
- Expression: additive expression
- Additive: multiplicative followed by zero or more (`+` or `-`) multiplicative
- Multiplicative: unary followed by zero or more (`*` or `//`) unary
- Unary: (`+` or `-`) unary or primary
- Primary: number or parenthesized expression

The AST is evaluated recursively with proper handling of unary vs binary operators based on node arity.
