import unittest
from solution import evaluate, ExpressionEvaluator


class TestExpressionEvaluator(unittest.TestCase):
    """Test cases for the expression evaluator."""

    def test_basic_addition(self):
        """Test basic addition."""
        self.assertEqual(evaluate("1 + 2"), 3)
        self.assertEqual(evaluate("10 + 20"), 30)

    def test_basic_subtraction(self):
        """Test basic subtraction."""
        self.assertEqual(evaluate("5 - 3"), 2)
        self.assertEqual(evaluate("10 - 20"), -10)

    def test_basic_multiplication(self):
        """Test basic multiplication."""
        self.assertEqual(evaluate("3 * 4"), 12)
        self.assertEqual(evaluate("-3 * 4"), -12)

    def test_basic_division(self):
        """Test floor division."""
        self.assertEqual(evaluate("7 // 3"), 2)
        self.assertEqual(evaluate("6 // 3"), 2)
        self.assertEqual(evaluate("-7 // 3"), -3)  # Python floor division

    def test_precedence(self):
        """Test operator precedence."""
        self.assertEqual(evaluate("1 + 2 * 3"), 7)
        self.assertEqual(evaluate("10 - 2 * 3"), 4)
        self.assertEqual(evaluate("8 // 2 + 3"), 7)

    def test_parentheses(self):
        """Test parentheses for grouping."""
        self.assertEqual(evaluate("(1 + 2) * 3"), 9)
        self.assertEqual(evaluate("10 - (2 + 3)"), 5)

    def test_unary_minus(self):
        """Test unary minus."""
        self.assertEqual(evaluate("-5"), -5)
        self.assertEqual(evaluate("--5"), 5)
        self.assertEqual(evaluate("-(2 + 3)"), -5)

    def test_unary_plus(self):
        """Test unary plus."""
        self.assertEqual(evaluate("+5"), 5)
        self.assertEqual(evaluate("++5"), 5)
        self.assertEqual(evaluate("+(2 + 3)"), 5)

    def test_negative_numbers(self):
        """Test negative numbers in expressions."""
        self.assertEqual(evaluate("-5 + 3"), -2)
        self.assertEqual(evaluate("5 + -3"), 2)
        self.assertEqual(evaluate("-5 + -3"), -8)

    def test_whitespace(self):
        """Test whitespace handling."""
        self.assertEqual(evaluate("1 + 2"), 3)
        self.assertEqual(evaluate("  1  +  2  "), 3)
        self.assertEqual(evaluate("\t1\n+\t2\n"), 3)

    def test_complex_expressions(self):
        """Test complex expressions."""
        self.assertEqual(evaluate("(-18 + 30) * 3 // (58)"), 0)
        self.assertEqual(evaluate("(-98 + -33) * 3 // (-61)"), 6)
        self.assertEqual(evaluate("(93 + -49) * 3 // (-33)"), -4)
        self.assertEqual(evaluate("(-78 + -49) * 3 // (31)"), -13)
        self.assertEqual(evaluate("(-86 + 52) * 3 // (-51)"), 2)
        self.assertEqual(evaluate("(29 + -94) * 3 // (77)"), -3)
        self.assertEqual(evaluate("(34 + -7) * 3 // (17)"), 4)
        self.assertEqual(evaluate("(94 + -67) * 3 // (-11)"), -8)

    def test_empty_expression(self):
        """Test empty expression raises ValueError."""
        with self.assertRaises(ValueError):
            evaluate("")

    def test_invalid_operator(self):
        """Test invalid operators raise ValueError."""
        with self.assertRaises(ValueError):
            evaluate("1/2")  # Division not supported
        with self.assertRaises(ValueError):
            evaluate("2**3")  # Exponentiation not supported

    def test_variable_name(self):
        """Test variable names raise ValueError."""
        with self.assertRaises(ValueError):
            evaluate("a + 2")
        with self.assertRaises(ValueError):
            evaluate("x")

    def test_float(self):
        """Test floats raise ValueError."""
        with self.assertRaises(ValueError):
            evaluate("1.5")
        with self.assertRaises(ValueError):
            evaluate("1.0 + 2")

    def test_boolean(self):
        """Test booleans raise ValueError."""
        with self.assertRaises(ValueError):
            evaluate("True")
        with self.assertRaises(ValueError):
            evaluate("False")

    def test_division_by_zero(self):
        """Test division by zero raises ValueError."""
        with self.assertRaises(ValueError):
            evaluate("1 // 0")
        with self.assertRaises(ValueError):
            evaluate("0 // 0")

    def test_large_numbers(self):
        """Test large numbers within bounds."""
        # MAX_TOKEN_DIGITS is 50, so 49 digits should be valid
        large = "1" + "0" * 48  # 10**48, 49 digits
        self.assertEqual(evaluate(large), 10**48)

        # 51 digits should raise ValueError (too many)
        with self.assertRaises(ValueError):
            evaluate("1" + "0" * 50)  # 51 digits

    def test_deep_nesting(self):
        """Test deep nesting."""
        # 100 levels should be valid
        expr = "(" * 100 + "1" + ")" * 100
        self.assertEqual(evaluate(expr), 1)

        # 101 levels should raise ValueError
        expr = "(" * 101 + "1" + ")" * 101
        with self.assertRaises(ValueError):
            evaluate(expr)

    def test_long_expression(self):
        """Test long expressions."""
        # 4096 characters should be valid
        expr = "1+" * 1000 + "1"  # 2001 characters, well under limit
        self.assertLess(len(expr), 4096)
        self.assertEqual(evaluate(expr), 1001)

        # 4097 characters should raise ValueError
        expr = "1+" * 2048 + "1"  # 4097 characters
        self.assertGreaterEqual(len(expr), 4097)
        with self.assertRaises(ValueError):
            evaluate(expr)

    def test_leading_zeros(self):
        """Test leading zeros may be rejected."""
        # Leading zeros are optional to reject
        # If accepted, they should parse correctly
        try:
            result = evaluate("007")
            self.assertEqual(result, 7)
        except ValueError:
            # Leading zeros are rejected, which is allowed
            pass

    def test_zero(self):
        """Test zero."""
        self.assertEqual(evaluate("0"), 0)
        self.assertEqual(evaluate("0 + 0"), 0)
        self.assertEqual(evaluate("0 * 100"), 0)

    def test_negative_division(self):
        """Test floor division with negative numbers."""
        self.assertEqual(evaluate("-7 // 3"), -3)  # Python floor division
        self.assertEqual(evaluate("7 // -3"), -3)  # Python floor division
        self.assertEqual(evaluate("-7 // -3"), 2)  # Python floor division

    def test_multiple_unary_operators(self):
        """Test multiple unary operators."""
        self.assertEqual(evaluate("---5"), -5)  # -(-(-5)) = -5
        self.assertEqual(evaluate("----5"), 5)  # -(-(-(-5))) = 5
        self.assertEqual(evaluate("+-+5"), -5)  # +(-(+(5))) = -5
        self.assertEqual(evaluate("-+-(2 + 3)"), 5)  # -(+(-(2+3))) = -(+(-5)) = -(-5) = 5


if __name__ == "__main__":
    unittest.main()
