import re
import sys
from typing import List, Tuple, Union

class ExpressionEvaluator:
    MAX_DEPTH = 100
    MAX_VALUE = 10**100
    MAX_TOKEN_DIGITS = 50
    MAX_LENGTH = 4096

    def evaluate(self, text: str) -> int:
        if not isinstance(text, str):
            raise ValueError("Input must be a string")
        if len(text) > self.MAX_LENGTH:
            raise ValueError("Input too long")
        if not text.strip():
            raise ValueError("Empty expression")

        tokens = self._tokenize(text)
        if not tokens:
            raise ValueError("No valid tokens")

        ast, pos = self._parse_expr(tokens, 0, 0)
        if pos < len(tokens):
            raise ValueError("Unexpected token")

        # Increase recursion limit for deeply nested expressions
        sys.setrecursionlimit(max(sys.getrecursionlimit(), 5000))

        result = self._eval_ast(ast)
        if abs(result) > self.MAX_VALUE:
            raise ValueError("Result too large")
        return result

    def _tokenize(self, text: str) -> List[Tuple[str, str]]:
        tokens = []
        i = 0
        while i < len(text):
            c = text[i]
            if c.isspace():
                i += 1
                continue
            elif c in '+-()':
                tokens.append((c, c))
                i += 1
            elif c == '/' and i + 1 < len(text) and text[i+1] == '/':
                tokens.append(('//', '//'))
                i += 2
            elif c == '*':
                tokens.append(('*', '*'))
                i += 1
            elif c.isdigit():
                j = i
                while j < len(text) and text[j].isdigit():
                    j += 1
                token = text[i:j]
                if len(token) > self.MAX_TOKEN_DIGITS:
                    raise ValueError("Token too long")
                if len(token) > 1 and token[0] == '0':
                    raise ValueError("Leading zero")
                tokens.append(('NUM', token))
                i = j
            else:
                raise ValueError(f"Invalid character: {c}")
        return tokens

    def _parse_expr(self, tokens: List[Tuple[str, str]], pos: int, depth: int) -> Tuple[Union[int, Tuple], int]:
        if depth > self.MAX_DEPTH:
            raise ValueError("Expression too deep")
        return self._parse_additive(tokens, pos, depth)

    def _parse_additive(self, tokens: List[Tuple[str, str]], pos: int, depth: int) -> Tuple[Union[int, Tuple], int]:
        if depth > self.MAX_DEPTH:
            raise ValueError("Expression too deep")
        left, pos = self._parse_multiplicative(tokens, pos, depth)
        while pos < len(tokens) and tokens[pos][0] in ('+', '-'):
            op = tokens[pos][1]
            pos += 1
            right, pos = self._parse_multiplicative(tokens, pos, depth + 1)
            left = (op, left, right)
        return left, pos

    def _parse_multiplicative(self, tokens: List[Tuple[str, str]], pos: int, depth: int) -> Tuple[Union[int, Tuple], int]:
        if depth > self.MAX_DEPTH:
            raise ValueError("Expression too deep")
        left, pos = self._parse_unary(tokens, pos, depth)
        while pos < len(tokens) and tokens[pos][0] in ('*', '//'):
            op = tokens[pos][1]
            pos += 1
            right, pos = self._parse_unary(tokens, pos, depth + 1)
            left = (op, left, right)
        return left, pos

    def _parse_unary(self, tokens: List[Tuple[str, str]], pos: int, depth: int) -> Tuple[Union[int, Tuple], int]:
        if depth > self.MAX_DEPTH:
            raise ValueError("Expression too deep")
        # Handle unary + and - only when they appear at start or after operator/(
        if pos < len(tokens) and tokens[pos][0] in ('+', '-'):
            op = tokens[pos][1]
            pos += 1
            operand, pos = self._parse_unary(tokens, pos, depth + 1)
            # Return a special marker for unary minus/plus
            return (op, operand), pos
        return self._parse_primary(tokens, pos, depth)

    def _parse_primary(self, tokens: List[Tuple[str, str]], pos: int, depth: int) -> Tuple[Union[int, Tuple], int]:
        if depth > self.MAX_DEPTH:
            raise ValueError("Expression too deep")
        if pos >= len(tokens):
            raise ValueError("Unexpected end of input")
        token = tokens[pos]
        if token[0] == 'NUM':
            return int(token[1]), pos + 1
        elif token[0] == '(':
            pos += 1
            expr, pos = self._parse_expr(tokens, pos, depth + 1)
            if pos >= len(tokens) or tokens[pos][0] != ')':
                raise ValueError("Missing closing parenthesis")
            return expr, pos + 1
        else:
            raise ValueError(f"Unexpected token: {token[0]}")

    def _eval_ast(self, node: Union[int, Tuple]) -> int:
        if isinstance(node, int):
            if abs(node) > self.MAX_VALUE:
                raise ValueError("Value too large")
            return node

        op = node[0]
        # Unary operators have 2 elements: (op, operand)
        # Binary operators have 3 elements: (op, left, right)
        if len(node) == 2:
            # Unary operator (+ or -)
            operand = self._eval_ast(node[1])
            if abs(operand) > self.MAX_VALUE:
                raise ValueError("Value too large")
            if op == '+':
                result = operand
            else:
                result = -operand
            if abs(result) > self.MAX_VALUE:
                raise ValueError("Value too large")
            return result

        # Binary operator
        left = self._eval_ast(node[1])
        right = self._eval_ast(node[2])
        if abs(left) > self.MAX_VALUE or abs(right) > self.MAX_VALUE:
            raise ValueError("Value too large")
        if op == '+':
            result = left + right
        elif op == '-':
            result = left - right
        elif op == '*':
            result = left * right
        elif op == '//':
            if right == 0:
                raise ValueError("Division by zero")
            result = left // right
        if abs(result) > self.MAX_VALUE:
            raise ValueError("Value too large")
        return result


def evaluate(text: str) -> int:
    evaluator = ExpressionEvaluator()
    return evaluator.evaluate(text)
