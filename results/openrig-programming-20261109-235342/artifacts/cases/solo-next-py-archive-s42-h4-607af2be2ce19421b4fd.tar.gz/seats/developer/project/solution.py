"""ZIP extraction utility with security validation."""

import os
import zipfile
from pathlib import Path


def extract_zip(archive_path: str, outdir: str) -> list[str]:
    """
    Extract a ZIP archive into a NEW directory, returning sorted member file paths.

    Args:
        archive_path: Path to the ZIP file
        outdir: Output directory path (must not exist)

    Returns:
        Sorted list of extracted file paths (relative to outdir)

    Raises:
        ValueError: If validation fails or any security check fails
    """
    # Validate outdir doesn't exist
    if os.path.exists(outdir):
        raise ValueError(f"Output directory already exists: {outdir}")

    # Validate archive exists
    if not os.path.isfile(archive_path):
        raise ValueError(f"Archive not found: {archive_path}")

    try:
        with zipfile.ZipFile(archive_path, 'r') as zf:
            # First pass: validate all entries before any extraction
            normalized_paths = set()
            directory_paths = set()  # Track which paths are directories
            members = zf.infolist()

            for member in members:
                name = member.filename

                # Reject absolute paths
                if os.path.isabs(name):
                    raise ValueError(f"Absolute path not allowed: {name}")

                # Reject backslashes
                if '\\' in name:
                    raise ValueError(f"Backslash not allowed: {name}")

                # Reject drive colon (Windows drive letters)
                if ':' in name:
                    raise ValueError(f"Drive colon not allowed: {name}")

                # Normalize path and check for .. components
                normalized = os.path.normpath(name)
                if normalized.startswith('..') or normalized.startswith(os.sep):
                    raise ValueError(f"Path traversal not allowed: {name}")

                # Check for symbolic links (check raw flags)
                # In zipfile, symlinks have mode 0o120000 (S_IFLNK) in external_attr >> 16
                import stat
                mode = member.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ValueError(f"Symbolic links not allowed: {name}")

                # Check for duplicates and conflicting paths
                # A conflict occurs when one path is a file and another would be inside it
                # We track which paths are directories (end with / in original or are parents)
                is_dir = name.endswith('/') or normalized.endswith('/')
                
                for existing in normalized_paths:
                    # Check if existing is a parent of normalized (e.g., existing="a", normalized="a/b")
                    if normalized.startswith(existing + '/'):
                        # existing is a parent - check if existing is a directory
                        if existing not in directory_paths:
                            raise ValueError(f"Conflicting paths not allowed: {name} and {existing}")
                    # Check if normalized is a parent of existing (e.g., normalized="a", existing="a/b")
                    if existing.startswith(normalized + '/'):
                        if normalized not in directory_paths:
                            raise ValueError(f"Conflicting paths not allowed: {name} and {existing}")
                
                if normalized in normalized_paths:
                    raise ValueError(f"Duplicate path not allowed: {name}")

                normalized_paths.add(normalized)
                if is_dir:
                    directory_paths.add(normalized)

            # Create output directory
            os.makedirs(outdir, exist_ok=True)

            # Second pass: extract all entries
            extracted_paths = []
            for member in members:
                name = member.filename
                normalized = os.path.normpath(name)

                # Skip directory entries (they're implicit)
                # Check both original name and normalized (normpath removes trailing /)
                if normalized.endswith('/') or name.endswith('/'):
                    continue

                # Construct the full path
                full_path = os.path.join(outdir, normalized)

                # Ensure the path is still within outdir (security check)
                real_outdir = os.path.realpath(outdir)
                real_full_path = os.path.realpath(full_path)
                if not real_full_path.startswith(real_outdir + os.sep) and real_full_path != real_outdir:
                    raise ValueError(f"Path traversal detected: {name}")

                # Create parent directories if needed
                parent_dir = os.path.dirname(full_path)
                if parent_dir:
                    os.makedirs(parent_dir, exist_ok=True)

                # Extract the file
                with zf.open(member) as source, open(full_path, 'wb') as target:
                    target.write(source.read())

                # Record the relative path
                extracted_paths.append(normalized)

            # Return sorted list of extracted file paths
            return sorted(extracted_paths)

    except (zipfile.BadZipFile, zipfile.BadZipFile):
        # Malformed ZIP - no output
        return []
    except ValueError:
        raise
    except Exception:
        # Other errors - no output
        return []


if __name__ == '__main__':
    # Simple test
    import tempfile
    import shutil

    # Create a test ZIP
    with tempfile.TemporaryDirectory() as tmpdir:
        archive = os.path.join(tmpdir, 'test.zip')
        outdir = os.path.join(tmpdir, 'extracted')

        # Create test files
        os.makedirs(os.path.join(tmpdir, 'source'))
        with open(os.path.join(tmpdir, 'source', 'a.txt'), 'w') as f:
            f.write('hello')
        with open(os.path.join(tmpdir, 'source', 'b.txt'), 'w') as f:
            f.write('world')

        # Create ZIP
        with zipfile.ZipFile(archive, 'w') as zf:
            zf.write(os.path.join(tmpdir, 'source', 'a.txt'), 'a.txt')
            zf.write(os.path.join(tmpdir, 'source', 'b.txt'), 'b.txt')

        # Extract
        result = extract_zip(archive, outdir)
        print(f"Extracted: {result}")
