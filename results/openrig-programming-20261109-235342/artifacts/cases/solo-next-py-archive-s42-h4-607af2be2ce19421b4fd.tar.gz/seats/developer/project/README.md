# ZIP Extraction Utility

A secure ZIP archive extraction utility with comprehensive validation.

## Features

- **Security-first design**: Validates all paths before extraction
- **Path traversal protection**: Rejects `..` components, absolute paths, and backslashes
- **Symbolic link rejection**: Prevents symlink-based attacks
- **Duplicate detection**: Ensures no duplicate or conflicting paths
- **UTF-8 support**: Preserves Unicode content
- **Nested directory support**: Handles complex directory structures

## Installation

No external dependencies required. Uses Python 3.14 stdlib only.

## Usage

```python
from solution import extract_zip

# Extract a ZIP file
files = extract_zip('archive.zip', 'output_directory')
print(files)  # ['file1.txt', 'folder/file2.txt']
```

## API

### `extract_zip(archive_path: str, outdir: str) -> list[str]`

Extract a ZIP archive into a new directory.

**Parameters:**
- `archive_path`: Path to the ZIP file
- `outdir`: Output directory path (must not exist)

**Returns:**
- Sorted list of extracted file paths (relative to outdir)

**Raises:**
- `ValueError`: If validation fails or any security check fails
  - Output directory already exists
  - Absolute paths in archive
  - Path traversal attempts (`..`)
  - Backslashes in paths
  - Drive colon in paths
  - Duplicate paths
  - Symbolic links

## Validation Rules

The function rejects archives containing:

1. **Absolute paths**: `/etc/passwd`, `C:\windows\...`
2. **Path traversal**: `../etc/passwd`, `folder/../secret`
3. **Backslashes**: `folder\file.txt`
4. **Drive colons**: `C:file.txt`
5. **Duplicate paths**: Same path appearing multiple times
6. **Conflicting paths**: `file.txt` and `file.txt/...`
7. **Symbolic links**: Any symlink entries

## Testing

Run tests with pytest:

```bash
pytest test_solution.py -v
```

## License

Public domain / CC0
