"""Tests for extract_zip function."""

import os
import tempfile
import zipfile
import unittest
from solution import extract_zip


class TestExtractZip(unittest.TestCase):
    """Test cases for extract_zip function."""

    def create_test_zip(self, entries, temp_dir):
        """Create a test ZIP file from entry definitions."""
        archive_path = os.path.join(temp_dir, 'test.zip')
        with zipfile.ZipFile(archive_path, 'w') as zf:
            for entry in entries:
                name = entry['name']
                if entry.get('symlink'):
                    info = zipfile.ZipInfo(name)
                    # Set symlink mode: S_IFLNK | 0o777
                    info.external_attr = (0o120777) << 16
                    # The symlink target is stored as the file content
                    zf.writestr(info, entry.get('text', ''))
                elif 'text' in entry:
                    zf.writestr(name, entry['text'])
                else:
                    zf.writestr(name, '')
        return archive_path

    def test_basic_extraction(self):
        """Test basic ZIP extraction with multiple files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('folder/a.txt', '5304')
                zf.writestr('b.txt', 'hello 日本')

            result = extract_zip(archive, outdir)
            self.assertEqual(result, ['b.txt', 'folder/a.txt'])

            self.assertEqual(open(os.path.join(outdir, 'b.txt')).read(), 'hello 日本')
            self.assertEqual(open(os.path.join(outdir, 'folder/a.txt')).read(), '5304')

    def test_empty_zip(self):
        """Test extraction of empty ZIP."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                pass

            result = extract_zip(archive, outdir)
            self.assertEqual(result, [])
            self.assertTrue(os.path.isdir(outdir))

    def test_output_dir_exists(self):
        """Test that existing output directory raises ValueError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')
            os.makedirs(outdir)

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('a.txt', 'test')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_absolute_path_rejected(self):
        """Test that absolute paths are rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('/absolute', 'x')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_drive_colon_rejected(self):
        """Test that drive colon paths are rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('C:bad', 'x')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_backslash_rejected(self):
        """Test that backslashes are rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('a\\b', 'x')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_path_traversal_rejected(self):
        """Test that path traversal with .. is rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('../x', 'x')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_duplicate_paths_rejected(self):
        """Test that duplicate paths are rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('a', 'x')
                zf.writestr('a', 'x')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_conflicting_paths_rejected(self):
        """Test that conflicting paths (a and a/b) are rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('a', 'x')
                zf.writestr('a/b', 'x')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_symlink_rejected(self):
        """Test that symbolic links are rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                info = zipfile.ZipInfo('link')
                # Set symlink mode: S_IFLNK | 0o777
                info.external_attr = (0o120777) << 16
                # The symlink target is stored as the file content
                zf.writestr(info, '/elsewhere')

            with self.assertRaises(ValueError):
                extract_zip(archive, outdir)

    def test_nested_directories(self):
        """Test extraction with nested directory structure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('a/b/c/d.txt', 'content')

            result = extract_zip(archive, outdir)
            self.assertEqual(result, ['a/b/c/d.txt'])
            self.assertEqual(open(os.path.join(outdir, 'a/b/c/d.txt')).read(), 'content')

    def test_directory_entries(self):
        """Test that directory entries are handled correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('folder/', '')
                zf.writestr('folder/file.txt', 'content')

            result = extract_zip(archive, outdir)
            self.assertIn('folder/file.txt', result)
            self.assertTrue(os.path.isdir(os.path.join(outdir, 'folder')))

    def test_malformed_zip(self):
        """Test handling of malformed ZIP files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            with open(archive, 'w') as f:
                f.write('not a zip file')

            result = extract_zip(archive, outdir)
            self.assertEqual(result, [])
            self.assertFalse(os.path.exists(outdir))

    def test_utf8_content(self):
        """Test UTF-8 content preservation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            archive = os.path.join(tmpdir, 'test.zip')
            outdir = os.path.join(tmpdir, 'extracted')

            content = 'hello 日本 🌍'
            with zipfile.ZipFile(archive, 'w') as zf:
                zf.writestr('utf8.txt', content)

            result = extract_zip(archive, outdir)
            self.assertEqual(result, ['utf8.txt'])
            self.assertEqual(open(os.path.join(outdir, 'utf8.txt'), encoding='utf-8').read(), content)


if __name__ == '__main__':
    unittest.main()
