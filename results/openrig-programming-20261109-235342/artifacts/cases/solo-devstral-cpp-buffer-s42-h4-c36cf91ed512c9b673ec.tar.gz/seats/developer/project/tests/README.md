# Buffer Library Tests

These tests verify the Buffer class implementation against the contract in TASK.txt.

## Test Cases

### Basic Construction and Access
- Default constructor creates zero-initialized buffer
- Constructor with size creates zero-initialized buffer of that size
- size() returns correct size
- operator[] provides bounds-checked access

### Copy Semantics
- Copy constructor creates independent copy
- Copy assignment creates independent copy
- Self-copy assignment preserves content

### Move Semantics
- Move constructor transfers ownership (noexcept)
- Move assignment transfers ownership (noexcept)
- Self-move assignment preserves content
- Moved-from buffer has size 0 and is reusable

### Resize Operations
- resize() preserves prefix when shrinking
- resize() zero-initializes new bytes when expanding
- resize() to same size is no-op

### Error Handling
- operator[] throws std::out_of_range on invalid access

### Memory Safety
- No memory leaks
- No double frees
- No undefined behavior
