#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>

class Buffer {
    std::uint8_t* p;
    std::size_t n;
    
public:
    // Default constructor
    Buffer(std::size_t n = 0) : p(new std::uint8_t[n]), n(n) {
        // Zero-initialize the buffer
        std::fill(p, p + n, 0);
    }
    
    // Destructor
    ~Buffer() {
        delete[] p;
    }
    
    // Copy constructor
    Buffer(const Buffer& other) : p(new std::uint8_t[other.n]), n(other.n) {
        std::copy(other.p, other.p + other.n, p);
    }
    
    // Move constructor
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }
    
    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = new std::uint8_t[other.n];
            std::copy(other.p, other.p + other.n, new_p);
            delete[] p;
            p = new_p;
            n = other.n;
        }
        return *this;
    }
    
    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }
    
    // Size getter
    std::size_t size() const noexcept {
        return n;
    }
    
    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }
    
    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }
    
    // Resize the buffer
    void resize(std::size_t k) {
        if (k == n) return;
        
        std::uint8_t* new_p = new std::uint8_t[k];
        std::size_t copy_size = std::min(n, k);
        std::copy(p, p + copy_size, new_p);
        
        // Zero-initialize new bytes
        if (k > n) {
            std::fill(new_p + n, new_p + k, 0);
        }
        
        delete[] p;
        p = new_p;
        n = k;
    }
    
    // Self-copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = new std::uint8_t[other.n];
            std::copy(other.p, other.p + other.n, new_p);
            delete[] p;
            p = new_p;
            n = other.n;
        }
        return *this;
    }
    
    // Self-move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }
};