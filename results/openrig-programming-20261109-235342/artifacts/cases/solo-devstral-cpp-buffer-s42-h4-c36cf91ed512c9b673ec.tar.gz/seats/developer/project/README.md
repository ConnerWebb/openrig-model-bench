# Buffer Library

This Buffer class implements a simple byte buffer with the following features:

## Constructor
- `Buffer(size_t n = 0)`: Creates a buffer of size n, zero-initialized

## Methods
- `size() const noexcept`: Returns the current buffer size
- `operator[](size_t)`: Bounds-checked element access (both mutable and const versions)
- `resize(size_t)`: Resizes the buffer, preserving the prefix and zero-initializing new bytes

## Special Member Functions
- Copy constructor: Deep copy
- Move constructor: Transfer ownership (noexcept)
- Copy assignment: Deep copy
- Move assignment: Transfer ownership (noexcept)

## Behavior
- After move operations, the moved-from buffer has size 0 and is reusable
- Self-assignment preserves content
- No memory leaks, double frees, or undefined behavior
- Uses RAII for resource management

## Implementation Details
- Elements are stored as uint8_t
- Standard containers are used for memory management
- Bounds checking throws std::out_of_range on invalid access
