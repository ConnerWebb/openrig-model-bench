#include "solution.hpp"
#include <iostream>
#include <stdexcept>

int main() {
    // Test 1: Default constructor
    {
        Buffer b;
        if (b.size() != 0) {
            std::cerr << "Test 1 failed: default constructor size" << std::endl;
            return 1;
        }
    }

    // Test 2: Constructor with size
    {
        Buffer b(10);
        if (b.size() != 10) {
            std::cerr << "Test 2 failed: constructor size" << std::endl;
            return 1;
        }
        for (std::size_t i = 0; i < 10; ++i) {
            if (b[i] != 0) {
                std::cerr << "Test 2 failed: zero initialization at position " << i << std::endl;
                return 1;
            }
        }
    }

    // Test 3: Copy constructor
    {
        Buffer a(5);
        a[0] = 10;
        a[1] = 20;
        a[2] = 30;
        
        Buffer b(a);
        if (b.size() != 5 || b[0] != 10 || b[1] != 20 || b[2] != 30 || b[3] != 0 || b[4] != 0) {
            std::cerr << "Test 3 failed: copy constructor" << std::endl;
            return 1;
        }
    }

    // Test 4: Move constructor
    {
        Buffer a(5);
        a[0] = 10;
        a[1] = 20;
        
        Buffer b(std::move(a));
        if (b.size() != 5 || b[0] != 10 || b[1] != 20 || a.size() != 0) {
            std::cerr << "Test 4 failed: move constructor" << std::endl;
            return 1;
        }
    }

    // Test 5: Copy assignment
    {
        Buffer a(5);
        a[0] = 10;
        a[1] = 20;
        
        Buffer b(3);
        b = a;
        
        if (b.size() != 5 || b[0] != 10 || b[1] != 20) {
            std::cerr << "Test 5 failed: copy assignment" << std::endl;
            return 1;
        }
    }

    // Test 6: Move assignment
    {
        Buffer a(5);
        a[0] = 10;
        a[1] = 20;
        
        Buffer b(3);
        b = std::move(a);
        
        if (b.size() != 5 || b[0] != 10 || b[1] != 20 || a.size() != 0) {
            std::cerr << "Test 6 failed: move assignment" << std::endl;
            return 1;
        }
    }

    // Test 7: Self copy assignment
    {
        Buffer a(5);
        a[0] = 10;
        a[1] = 20;
        
        a = a;
        
        if (a.size() != 5 || a[0] != 10 || a[1] != 20) {
            std::cerr << "Test 7 failed: self copy assignment" << std::endl;
            return 1;
        }
    }

    // Test 8: Self move assignment
    {
        Buffer a(5);
        a[0] = 10;
        a[1] = 20;
        
        a = std::move(a);
        
        if (a.size() != 5 || a[0] != 10 || a[1] != 20) {
            std::cerr << "Test 8 failed: self move assignment" << std::endl;
            return 1;
        }
    }

    // Test 9: Resize larger
    {
        Buffer b(5);
        b[0] = 10;
        b[1] = 20;
        b[2] = 30;
        
        b.resize(10);
        
        if (b.size() != 10 || b[0] != 10 || b[1] != 20 || b[2] != 30) {
            std::cerr << "Test 9 failed: resize larger" << std::endl;
            return 1;
        }
        for (std::size_t i = 3; i < 10; ++i) {
            if (b[i] != 0) {
                std::cerr << "Test 9 failed: zero initialization at position " << i << std::endl;
                return 1;
            }
        }
    }

    // Test 10: Resize smaller
    {
        Buffer b(10);
        b[0] = 10;
        b[1] = 20;
        b[2] = 30;
        b[5] = 50;
        
        b.resize(5);
        
        if (b.size() != 5 || b[0] != 10 || b[1] != 20 || b[2] != 30) {
            std::cerr << "Test 10 failed: resize smaller" << std::endl;
            return 1;
        }
    }

    // Test 11: Resize same
    {
        Buffer b(5);
        b[0] = 10;
        b[1] = 20;
        
        b.resize(5);
        
        if (b.size() != 5 || b[0] != 10 || b[1] != 20) {
            std::cerr << "Test 11 failed: resize same" << std::endl;
            return 1;
        }
    }

    // Test 12: Bounds checking
    {
        Buffer b(5);
        
        try {
            (void)b[0];
            (void)b[4];
        } catch (...) {
            std::cerr << "Test 12 failed: valid access threw exception" << std::endl;
            return 1;
        }
        
        try {
            (void)b[5];
            std::cerr << "Test 12 failed: out of bounds access did not throw" << std::endl;
            return 1;
        } catch (const std::out_of_range&) {
            // Expected
        } catch (...) {
            std::cerr << "Test 12 failed: wrong exception type" << std::endl;
            return 1;
        }
    }

    // Test 13: Const access
    {
        const Buffer b(5);
        if (b.size() != 5) {
            std::cerr << "Test 13 failed: const size" << std::endl;
            return 1;
        }
        try {
            (void)b[0];
        } catch (...) {
            std::cerr << "Test 13 failed: const access threw exception" << std::endl;
            return 1;
        }
        try {
            (void)b[5];
            std::cerr << "Test 13 failed: const out of bounds did not throw" << std::endl;
            return 1;
        } catch (const std::out_of_range&) {
            // Expected
        } catch (...) {
            std::cerr << "Test 13 failed: wrong exception type" << std::endl;
            return 1;
        }
    }

    std::cout << "All tests passed!" << std::endl;
    return 0;
}
