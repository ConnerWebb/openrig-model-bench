# Buffer Library Implementation

## Overview

This is a C++20 implementation of a `Buffer` class that manages a dynamic array of `uint8_t` elements. The implementation follows RAII principles and provides comprehensive copy/move semantics.

## Features

- **RAII Management**: Automatic memory management with proper constructors and destructors
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for invalid indices
- **Copy Semantics**: Deep copy construction and assignment
- **Move Semantics**: Noexcept move construction and assignment
- **Resizing**: `resize()` preserves existing data and zero-initializes new elements
- **Self-Assignment**: Proper handling of self-copy and self-move operations

## API

### Constructors

```cpp
Buffer() : Buffer(0)  // Default constructor
Buffer(std::size_t n)  // Constructor with size
```

### Member Functions

```cpp
std::size_t size() const noexcept  // Get buffer size
void resize(std::size_t k)  // Resize buffer, preserving prefix
```

### Operators

```cpp
uint8_t& operator[](std::size_t i)  // Mutable access with bounds checking
const uint8_t& operator[](std::size_t i) const  // Const access with bounds checking
Buffer& operator=(const Buffer& other)  // Copy assignment
Buffer& operator=(Buffer&& other) noexcept  // Move assignment
```

## Implementation Details

- Memory is managed using `new[]` and `delete[]`
- All elements are zero-initialized upon construction
- Move operations leave the source buffer in a valid but empty state
- Self-assignment is properly handled to avoid issues

## Testing

The implementation includes comprehensive tests covering:
- Default and parameterized construction
- Copy and move semantics
- Self-assignment scenarios
- Bounds checking
- Resizing operations
- Const-correctness

Run tests with:
```bash
./run_tests
```

## Requirements

- C++20 compliant compiler
- Standard library support for `<stdexcept>`, `<algorithm>`, and `<utility>`
