"""Tests for solution.aggregate function."""

import tempfile
import unittest
from pathlib import Path
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def _write_csv(self, content: str) -> str:
        """Helper to write CSV content to a temp file and return its path."""
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', suffix='.csv', delete=False) as f:
            f.write(content)
            return f.name

    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        csv_content = "category,amount\nfood,100.00\nfood,50.00\nrent,200.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "150.00", "rent": "200.00"})

    def test_sorted_keys(self):
        """Test that keys are sorted alphabetically."""
        csv_content = "category,amount\nzebra,10.00\napple,20.00\nmango,30.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(list(result.keys()), ["apple", "mango", "zebra"])

    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = "category,amount\n  food  ,  100.00  \n  rent  ,  200.00  \n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00", "rent": "200.00"})

    def test_blank_lines_ignored(self):
        """Test that blank lines are ignored."""
        csv_content = "category,amount\nfood,100.00\n\nrent,200.00\n\n\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00", "rent": "200.00"})

    def test_quoted_fields_with_comma(self):
        """Test quoted fields containing commas."""
        csv_content = 'category,amount\n"a,b",100.00\n"a,b",50.00\n'
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"a,b": "150.00"})

    def test_quoted_fields_with_newline(self):
        """Test quoted fields containing newlines."""
        csv_content = 'category,amount\n"two\nlines",100.00\n"two\nlines",50.00\n'
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"two\nlines": "150.00"})

    def test_quoted_double_quotes(self):
        """Test quoted fields with escaped double quotes."""
        csv_content = 'category,amount\n"x""quote",100.00\n"x""quote",50.00\n'
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {'x"quote': "150.00"})

    def test_optional_plus_sign(self):
        """Test amount with optional + sign."""
        csv_content = "category,amount\nfood,+100.00\nfood,+50.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "150.00"})

    def test_integer_amount(self):
        """Test integer amounts (no decimal point)."""
        csv_content = "category,amount\nfood,100\nfood,50\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "150.00"})

    def test_one_decimal_digit(self):
        """Test amount with one decimal digit."""
        csv_content = "category,amount\nfood,100.5\nfood,50.5\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "151.00"})

    def test_two_decimal_digits(self):
        """Test amount with two decimal digits."""
        csv_content = "category,amount\nfood,100.55\nfood,50.55\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "151.10"})

    def test_empty_category_raises_error(self):
        """Test that empty category raises ValueError."""
        csv_content = "category,amount\n,100.00\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_invalid_header_raises_error(self):
        """Test that invalid header raises ValueError."""
        csv_content = "wrong,amount\nfood,100.00\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_wrong_field_count_raises_error(self):
        """Test that wrong number of fields raises ValueError."""
        csv_content = "category,amount\nfood,100.00,extra\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_nan_raises_error(self):
        """Test that NaN amount raises ValueError."""
        csv_content = "category,amount\nfood,NaN\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_negative_raises_error(self):
        """Test that negative amount raises ValueError."""
        csv_content = "category,amount\nfood,-100.00\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_exponent_raises_error(self):
        """Test that exponent in amount raises ValueError."""
        csv_content = "category,amount\nfood,1e10\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_too_many_decimal_digits_raises_error(self):
        """Test that more than 2 decimal digits raises ValueError."""
        csv_content = "category,amount\nfood,100.123\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_too_long_integer_raises_error(self):
        """Test that more than 12 integer digits raises ValueError."""
        csv_content = "category,amount\nfood,1234567890123\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_empty_amount_raises_error(self):
        """Test that empty amount raises ValueError."""
        csv_content = "category,amount\nfood,\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_decimal_without_digits_raises_error(self):
        """Test that decimal point without digits raises ValueError."""
        csv_content = "category,amount\nfood,100.\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_unicode_categories(self):
        """Test Unicode category names."""
        csv_content = "category,amount\n日本,100.00\n日本,50.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"日本": "150.00"})

    def test_exact_decimal_arithmetic(self):
        """Test exact decimal arithmetic (no floating point errors)."""
        csv_content = "category,amount\nfood,0.1\nfood,0.2\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "0.30"})

    def test_empty_csv_raises_error(self):
        """Test that empty CSV raises ValueError."""
        csv_content = ""
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_header_only(self):
        """Test CSV with only header (no data rows)."""
        csv_content = "category,amount\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {})


if __name__ == "__main__":
    unittest.main()
