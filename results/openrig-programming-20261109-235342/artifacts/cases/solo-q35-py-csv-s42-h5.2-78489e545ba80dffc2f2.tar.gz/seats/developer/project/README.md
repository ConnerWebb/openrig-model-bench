# CSV Category Amount Aggregator

A Python module that aggregates CSV amounts by category using exact decimal arithmetic.

## Usage

```python
from solution import aggregate

result = aggregate("path/to/file.csv")
# Returns dict[str, str] with category keys sorted and totals formatted to 2 decimal places
```

## Input Format

The CSV file must have:
- Header: exactly `category,amount`
- Data rows with exactly two fields: category and amount
- UTF-8 encoding

### Amount Format

- Optional leading `+` sign
- 1-12 decimal digits for integer part
- Optional decimal point followed by 1-2 digits
- Non-negative, finite values only
- No scientific notation (exponents)

### Examples

```csv
category,amount
food,100.00
food,+50.5
rent,200
"a,b",150.00
"two
lines",75.50
"x""quote",100.00
```

## Output

Returns a dictionary with:
- Keys: category names (stripped of whitespace), sorted alphabetically
- Values: totals formatted with exactly two decimal places (e.g., "150.00")

## Error Handling

Raises `ValueError` for:
- Invalid header (not exactly `category,amount`)
- Wrong number of fields in a row
- Empty category
- Invalid amount format (NaN, negative, exponent, too many decimal digits, etc.)
- Empty CSV file

## Implementation Details

- Uses Python's `csv` module for proper CSV parsing (handles quoted fields, embedded newlines, escaped quotes)
- Uses `decimal.Decimal` for exact arithmetic (no floating point errors)
- Streams the file line by line (does not load entire file into memory)
- Handles UTF-8 encoding

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```
