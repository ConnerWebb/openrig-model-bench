"""CSV category amount aggregator with exact decimal arithmetic."""

import csv
from decimal import Decimal, InvalidOperation
from collections import defaultdict


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted,
    totals formatted with exactly two decimal places.
    """
    totals: defaultdict[str, Decimal] = defaultdict(Decimal)
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        # Strip whitespace from header fields
        header = [h.strip() for h in header]
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: expected 'category,amount', got '{','.join(header)}'")
        
        # Process data rows
        for row in reader:
            # Skip completely blank records (empty list or all empty strings)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Expected 2 fields, got {len(row)}: {row}")
            
            category, amount = row[0].strip(), row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate and parse amount
            try:
                decimal_amount = _parse_amount(amount)
            except ValueError as e:
                raise ValueError(f"Invalid amount '{amount}': {e}")
            
            totals[category] += decimal_amount
    
    # Format results with exactly two decimal places, sorted by key
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}


def _parse_amount(amount: str) -> Decimal:
    """
    Parse amount with format: optional +, 1–12 decimal digits,
    optional decimal point followed by 1 or 2 digits; nonnegative, finite, no exponent.
    """
    if not amount:
        raise ValueError("Empty amount")
    
    # Check for exponent (scientific notation)
    if 'e' in amount.lower():
        raise ValueError("Exponent not allowed")
    
    # Check for NaN or Inf
    if amount.lower() in ('nan', 'inf', '+inf', '-inf', '+nan', '-nan'):
        raise ValueError("NaN or Inf not allowed")
    
    # Remove optional leading +
    if amount.startswith('+'):
        amount = amount[1:]
    
    # Must be non-negative (no leading -)
    if amount.startswith('-'):
        raise ValueError("Negative amounts not allowed")
    
    # Validate format: digits with optional decimal point and 1-2 digits after
    parts = amount.split('.')
    if len(parts) > 2:
        raise ValueError("Too many decimal points")
    
    integer_part = parts[0]
    fractional_part = parts[1] if len(parts) == 2 else None
    
    # Integer part: 1-12 digits
    if not integer_part:
        raise ValueError("Integer part required")
    if not integer_part.isdigit():
        raise ValueError(f"Invalid integer part: {integer_part}")
    if len(integer_part) > 12:
        raise ValueError(f"Integer part too long: {len(integer_part)} digits (max 12)")
    
    # Fractional part: 1-2 digits if present
    if fractional_part is not None:
        if not fractional_part:
            raise ValueError("Decimal point requires digits after it")
        if not fractional_part.isdigit():
            raise ValueError(f"Invalid fractional part: {fractional_part}")
        if len(fractional_part) > 2:
            raise ValueError(f"Fractional part too long: {len(fractional_part)} digits (max 2)")
    
    try:
        return Decimal(amount)
    except InvalidOperation:
        raise ValueError(f"Invalid amount format: {amount}")
