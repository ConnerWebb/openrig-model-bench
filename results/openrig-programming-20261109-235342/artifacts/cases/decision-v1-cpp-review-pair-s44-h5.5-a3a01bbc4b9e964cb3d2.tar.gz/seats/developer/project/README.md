# CSV Aggregator

This project implements a CSV parser and aggregator for category/amount data.

## Features

- Parses CSV files with "category,amount" header
- Handles quoted fields with embedded commas and newlines
- Supports negative numbers and optional plus signs
- Trims whitespace from fields
- Aggregates amounts by category
- Validates input format and handles errors appropriately
- Supports int64 range values with overflow detection

## API

### `aggregate(std::istream& in)`

Reads a CSV stream and returns a map of category to aggregated amounts.

**Input Format:**
- Header line: `category,amount`
- Data lines: `<category>,<amount>`
- Empty lines are ignored
- Quoted fields are supported

**Output:**
- `std::map<std::string, std::int64_t>` with aggregated amounts per category

**Errors:**
- Throws `std::invalid_argument` for invalid input (wrong header, wrong field count, invalid amounts, overflow, etc.)

## Building

```bash
clang++ -std=c++20 -o test_solution test_solution.cpp
./test_solution
```

## Testing

Run the test suite:
```bash
./test_solution
```

Or use the project test runner:
```bash
run_tests
```
