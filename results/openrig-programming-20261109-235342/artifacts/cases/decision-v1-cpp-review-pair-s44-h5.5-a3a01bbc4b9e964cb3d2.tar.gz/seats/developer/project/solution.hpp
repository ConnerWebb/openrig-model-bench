#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <cctype>
#include <limits>

namespace {

// Trim leading and trailing spaces, tabs, and CR
std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse a single CSV field from the stream, handling quotes
// Returns the field content (unquoted, with escaped quotes resolved)
// The separator (comma, newline, CR, or EOF) is left in the stream or consumed
std::string parseField(std::istream& in, char& separator) {
    separator = '\0';
    std::string field;
    
    if (in.eof()) {
        separator = '\0';
        return "";
    }
    
    int c_int = in.get();
    if (c_int == EOF) {
        separator = '\0';
        return "";
    }
    char c = static_cast<char>(c_int);
    
    if (c == '"') {
        // Quoted field
        while (true) {
            c_int = in.get();
            if (c_int == EOF) {
                throw std::invalid_argument("Unterminated quoted field");
            }
            c = static_cast<char>(c_int);
            if (c == '"') {
                // Check for escaped quote
                c_int = in.get();
                if (c_int == EOF) {
                    // End of input after closing quote - field ends, separator is EOF
                    separator = '\0';
                    break;
                }
                char next = static_cast<char>(c_int);
                if (next == '"') {
                    // Escaped quote
                    field += '"';
                } else {
                    // End of quoted field
                    // The next char is the separator (comma, newline, CR, or EOF)
                    if (next == ',') {
                        separator = ',';
                    } else if (next == '\n') {
                        separator = '\n';
                    } else if (next == '\r') {
                        separator = '\r';
                        // Check for \r\n
                        if (!in.eof() && in.peek() == '\n') {
                            in.get(); // consume the \n
                        }
                    } else if (in.eof()) {
                        separator = '\0';
                    } else {
                        // Invalid: character after closing quote must be comma, newline, or EOF
                        throw std::invalid_argument("Invalid character after quoted field");
                    }
                    break;
                }
            } else {
                field += c;
            }
        }
    } else {
        // Unquoted field - read until comma or newline
        while (true) {
            field += c;
            c_int = in.get();
            if (c_int == EOF) {
                separator = '\0';
                break;
            }
            c = static_cast<char>(c_int);
            if (c == ',') {
                separator = ',';
                break;
            } else if (c == '\n') {
                separator = '\n';
                break;
            } else if (c == '\r') {
                separator = '\r';
                // Check for \r\n
                if (!in.eof() && in.peek() == '\n') {
                    in.get(); // consume the \n
                }
                break;
            }
        }
    }
    
    return field;
}

// Parse a line/record from the stream
// Returns true if a record was read (including empty lines), false if end of input
// Fields are trimmed. For empty lines, fields will be empty.
bool parseRecord(std::istream& in, std::vector<std::string>& fields) {
    fields.clear();
    
    // Check if we're at EOF
    if (in.eof()) {
        return false;
    }
    
    // Check if next char is newline (empty line) or EOF
    int peek_int = in.peek();
    if (peek_int == EOF) {
        return false;
    }
    char peek = static_cast<char>(peek_int);
    if (peek == '\n') {
        in.get(); // consume newline
        return true; // empty line, but still a "record"
    }
    if (peek == '\r') {
        in.get(); // consume CR
        if (!in.eof() && in.peek() == '\n') {
            in.get(); // consume \n
        }
        return true; // empty line, but still a "record"
    }
    
    // Read fields until end of record
    while (true) {
        char separator;
        std::string field = parseField(in, separator);
        fields.push_back(trim(field));
        
        if (separator == '\0') {
            // EOF - record ends
            return !fields.empty();
        } else if (separator == '\n' || separator == '\r') {
            // End of record
            return true;
        } else {
            // Comma - continue to next field
            continue;
        }
    }
}

// Parse int64_t from string, handling optional + or - prefix
// Throws on overflow or invalid format
int64_t parseInt64(const std::string& s) {
    if (s.empty()) {
        throw std::invalid_argument("Empty amount field");
    }
    
    size_t start = 0;
    bool negative = false;
    
    if (s[0] == '+') {
        start = 1;
    } else if (s[0] == '-') {
        negative = true;
        start = 1;
    }
    
    if (start >= s.size()) {
        throw std::invalid_argument("Amount has no digits");
    }
    
    // Check all remaining chars are digits
    for (size_t i = start; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("Amount contains non-digit characters");
        }
    }
    
    // Parse the number, checking for overflow
    const uint64_t INT64_MAX_ABS = 9223372036854775807ULL;
    const uint64_t INT64_MIN_ABS = 9223372036854775808ULL;
    
    // Convert string to uint64 with overflow check
    uint64_t value = 0;
    for (size_t i = start; i < s.size(); ++i) {
        int digit = s[i] - '0';
        if (value > (UINT64_MAX - digit) / 10) {
            throw std::invalid_argument("Amount overflow");
        }
        value = value * 10 + digit;
    }
    
    // Now check against int64 bounds
    if (negative) {
        if (value > INT64_MIN_ABS) {
            throw std::invalid_argument("Amount underflow");
        }
        // Special case: -9223372036854775808
        if (value == INT64_MIN_ABS) {
            return std::numeric_limits<int64_t>::min();
        }
        return -static_cast<int64_t>(value);
    } else {
        if (value > INT64_MAX_ABS) {
            throw std::invalid_argument("Amount overflow");
        }
        return static_cast<int64_t>(value);
    }
}

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    std::vector<std::string> fields;
    
    // Read and validate header
    if (!parseRecord(in, fields)) {
        throw std::invalid_argument("Empty input");
    }
    
    if (fields.size() != 2) {
        throw std::invalid_argument("Header must have exactly 2 fields");
    }
    
    if (fields[0] != "category" || fields[1] != "amount") {
        throw std::invalid_argument("Header must be exactly 'category,amount'");
    }
    
    // Read data records
    while (parseRecord(in, fields)) {
        if (fields.empty()) {
            continue; // empty record
        }
        
        // Debug: print fields
        // for (size_t i = 0; i < fields.size(); ++i) {
        //     std::cerr << "Field " << i << "='" << fields[i] << "'\n";
        // }
        
        if (fields.size() != 2) {
            throw std::invalid_argument("Each record must have exactly 2 fields");
        }
        
        const std::string& category = fields[0];
        const std::string& amountStr = fields[1];
        
        if (category.empty()) {
            throw std::invalid_argument("Category cannot be empty");
        }
        
        if (amountStr.empty()) {
            throw std::invalid_argument("Amount cannot be empty");
        }
        
        int64_t amount = parseInt64(amountStr);
        
        // Check for overflow in accumulation
        auto it = result.find(category);
        if (it != result.end()) {
            // Check if adding amount would overflow
            int64_t current = it->second;
            const int64_t MAX_VAL = std::numeric_limits<int64_t>::max();
            const int64_t MIN_VAL = std::numeric_limits<int64_t>::min();
            if (amount > 0 && current > MAX_VAL - amount) {
                throw std::invalid_argument("Accumulation overflow");
            }
            if (amount < 0 && current < MIN_VAL - amount) {
                throw std::invalid_argument("Accumulation underflow");
            }
            it->second = current + amount;
        } else {
            result[category] = amount;
        }
    }
    
    return result;
}

#endif // SOLUTION_HPP
