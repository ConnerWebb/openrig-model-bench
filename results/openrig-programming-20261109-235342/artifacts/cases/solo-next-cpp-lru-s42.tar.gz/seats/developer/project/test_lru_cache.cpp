#include "solution.hpp"
#include <cassert>
#include <iostream>
#include <string>

void test_basic_put_get() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string out;
    assert(cache.get(1, out) == true);
    assert(out == "one");
    
    assert(cache.get(2, out) == true);
    assert(out == "two");
    
    assert(cache.get(3, out) == true);
    assert(out == "three");
    
    std::cout << "test_basic_put_get passed\n";
}

void test_eviction_lru() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    // Access key 1 to make it MRU
    std::string out;
    cache.get(1, out);
    
    // Add key 4, should evict key 2 (LRU)
    cache.put(4, "four");
    
    assert(cache.size() == 3);
    assert(cache.get(2, out) == false);  // Evicted
    assert(cache.get(1, out) == true);
    assert(cache.get(3, out) == true);
    assert(cache.get(4, out) == true);
    
    std::cout << "test_eviction_lru passed\n";
}

void test_update_does_not_evict() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    // Update existing key
    cache.put(2, "two-updated");
    
    assert(cache.size() == 3);
    std::string out;
    assert(cache.get(2, out) == true);
    assert(out == "two-updated");
    
    std::cout << "test_update_does_not_evict passed\n";
}

void test_snapshot_order() {
    LruCache<int, std::string> cache(4);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    // Access 1 to make it MRU
    std::string out;
    cache.get(1, out);
    
    auto snap = cache.snapshot();
    
    // Order should be: 1 (MRU), 3, 2 (LRU)
    assert(snap.size() == 3);
    assert(snap[0].first == 1 && snap[0].second == "one");
    assert(snap[1].first == 3 && snap[1].second == "three");
    assert(snap[2].first == 2 && snap[2].second == "two");
    
    std::cout << "test_snapshot_order passed\n";
}

void test_erase() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    assert(cache.erase(2) == true);
    assert(cache.size() == 2);
    
    std::string out;
    assert(cache.erase(2) == false);  // Already erased
    assert(cache.get(2, out) == false);
    
    std::cout << "test_erase passed\n";
}

void test_capacity_zero() {
    LruCache<int, std::string> cache(0);
    
    cache.put(1, "one");
    assert(cache.size() == 0);
    
    std::string out;
    assert(cache.get(1, out) == false);
    
    std::cout << "test_capacity_zero passed\n";
}

void test_get_miss_leaves_out_unchanged() {
    LruCache<int, std::string> cache(3);
    
    std::string out = "original";
    assert(cache.get(999, out) == false);
    assert(out == "original");  // Should remain unchanged
    
    std::cout << "test_get_miss_leaves_out_unchanged passed\n";
}

void test_mru_on_put() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    // Put new key, should evict 1 (LRU)
    cache.put(4, "four");
    
    std::string out;
    assert(cache.get(1, out) == false);  // Evicted
    assert(cache.get(2, out) == true);   // 2 is now LRU
    
    // Put 2 again, makes it MRU
    cache.put(2, "two-updated");
    
    // Put 5, should evict 3 (now LRU)
    cache.put(5, "five");
    
    assert(cache.get(3, out) == false);  // Evicted
    assert(cache.get(2, out) == true);   // Still there
    
    std::cout << "test_mru_on_put passed\n";
}

int main() {
    test_basic_put_get();
    test_eviction_lru();
    test_update_does_not_evict();
    test_snapshot_order();
    test_erase();
    test_capacity_zero();
    test_get_miss_leaves_out_unchanged();
    test_mru_on_put();
    
    std::cout << "\nAll tests passed!\n";
    return 0;
}
