#ifndef LRU_CACHE_HPP
#define LRU_CACHE_HPP

#include <cstddef>
#include <list>
#include <string>
#include <unordered_map>
#include <vector>
#include <utility>

template <typename Key, typename Value>
class LruCache {
public:
    explicit LruCache(size_t capacity) : capacity_(capacity) {}

    void put(const Key& key, const Value& value) {
        if (capacity_ == 0) {
            return;  // Cannot store anything
        }
        
        auto it = cache_.find(key);
        if (it != cache_.end()) {
            // Key exists, update value and move to front
            it->second.value = value;
            access_order_.splice(access_order_.begin(), access_order_, it->second.iter);
            return;
        }

        // Key doesn't exist, check if we need to evict
        if (cache_.size() >= capacity_) {
            // Evict LRU (back of list)
            Key evict_key = access_order_.back();
            access_order_.pop_back();
            cache_.erase(evict_key);
        }

        // Insert new key at front
        access_order_.push_front(key);
        cache_[key] = {value, access_order_.begin()};
    }

    bool get(const Key& key, Value& out) {
        auto it = cache_.find(key);
        if (it == cache_.end()) {
            return false;
        }

        // Move to front (most recently used)
        access_order_.splice(access_order_.begin(), access_order_, it->second.iter);
        out = it->second.value;
        return true;
    }

    bool erase(const Key& key) {
        auto it = cache_.find(key);
        if (it == cache_.end()) {
            return false;
        }

        // Remove from access order
        access_order_.erase(it->second.iter);
        cache_.erase(it);
        return true;
    }

    size_t size() const {
        return cache_.size();
    }

    std::vector<std::pair<Key, Value>> snapshot() const {
        std::vector<std::pair<Key, Value>> result;
        result.reserve(access_order_.size());
        
        for (const auto& key : access_order_) {
            auto it = cache_.find(key);
            if (it != cache_.end()) {
                result.emplace_back(key, it->second.value);
            }
        }
        
        return result;
    }

private:
    size_t capacity_;
    std::list<Key> access_order_;  // Front = MRU, Back = LRU
    struct Node {
        Value value;
        typename std::list<Key>::iterator iter;
    };
    std::unordered_map<Key, Node> cache_;
};

// Deduction guide for C++17 CTAD
LruCache(size_t) -> LruCache<int, std::string>;

#endif // LRU_CACHE_HPP
