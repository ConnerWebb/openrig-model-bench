# LRU Cache Implementation

A C++20 implementation of a Least Recently Used (LRU) cache with O(1) average time complexity for get, put, and erase operations.

## Features

- **O(1) average complexity**: Uses hash map for lookups and doubly-linked list for ordering
- **C++20 standard**: Modern C++ with RAII patterns
- **Template-based**: Works with any key and value types
- **Snapshot support**: Returns items in MRU-to-LRU order
- **Proper eviction**: LRU item evicted on overflow, updates don't trigger eviction

## API

```cpp
template <typename Key, typename Value>
class LruCache {
public:
    explicit LruCache(size_t capacity);
    
    // Insert or update a key-value pair
    void put(const Key& key, const Value& value);
    
    // Get value by key, returns false if not found
    bool get(const Key& key, Value& out);
    
    // Remove a key, returns false if not found
    bool erase(const Key& key);
    
    // Current number of items
    size_t size() const;
    
    // Get all items in MRU-to-LRU order
    std::vector<std::pair<Key, Value>> snapshot() const;
};
```

## Usage Example

```cpp
#include "solution.hpp"
#include <iostream>

int main() {
    LruCache<int, std::string> cache(3);
    
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    
    std::string value;
    if (cache.get(1, value)) {
        std::cout << "Got: " << value << std::endl;
    }
    
    cache.put(4, "four");  // Evicts key 2 (LRU)
    
    for (const auto& [key, value] : cache.snapshot()) {
        std::cout << key << ": " << value << std::endl;
    }
    
    return 0;
}
```

## Building and Testing

```bash
# Compile tests
clang++ -std=c++20 -fuse-ld=bfd -o test_lru_cache test_lru_cache.cpp

# Run tests
./test_lru_cache
```

## Implementation Details

- **Access order**: Doubly-linked list with front = MRU, back = LRU
- **Lookup**: Hash map from key to {value, iterator in list}
- **Eviction**: Remove from back of list and hash map
- **MRU update**: Move accessed/updated item to front of list
