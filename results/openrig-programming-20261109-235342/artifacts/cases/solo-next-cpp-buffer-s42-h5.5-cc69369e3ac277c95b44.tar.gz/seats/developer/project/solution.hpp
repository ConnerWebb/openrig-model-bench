#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <memory>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    explicit Buffer(std::size_t n = 0) noexcept : p(n ? new std::uint8_t[n] : nullptr), n(n) {
        if (p) {
            std::fill(p, p + n, 0);
        }
    }

    ~Buffer() noexcept {
        delete[] p;
    }

    Buffer(const Buffer& other) : p(other.n ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (p && other.p) {
            std::copy(other.p, other.p + n, p);
        }
    }

    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            Buffer tmp(other);
            std::swap(p, tmp.p);
            std::swap(n, tmp.n);
        }
        return *this;
    }

    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    std::size_t size() const noexcept {
        return n;
    }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    std::uint8_t operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    void resize(std::size_t k) {
        if (k == n) return;
        std::uint8_t* newp = k ? new std::uint8_t[k] : nullptr;
        if (newp) {
            std::fill(newp, newp + k, 0);
        }
        if (p) {
            std::size_t copy = (n < k) ? n : k;
            if (newp && p && copy > 0) {
                std::copy(p, p + copy, newp);
            }
            delete[] p;
        }
        p = newp;
        n = k;
    }
};
