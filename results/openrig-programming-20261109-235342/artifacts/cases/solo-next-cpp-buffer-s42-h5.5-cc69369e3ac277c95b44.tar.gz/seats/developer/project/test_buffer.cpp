#include <iostream>
#include <cassert>
#include <stdexcept>
#include <vector>
#include "solution.hpp"

void test_default_construct() {
    Buffer b;
    assert(b.size() == 0);
}

void test_construct_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
}

void test_copy_construct() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(a);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_copy_assignment() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b;
    b = a;
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_move_construct() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(std::move(a));
    assert(a.size() == 0);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_move_assignment() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b;
    b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_self_copy() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    a = a;
    assert(a.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(a[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_self_move() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    a = std::move(a);
    assert(a.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(a[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_bounds_check() {
    Buffer b(5);
    try {
        b[5] = 0;
        assert(false);
    } catch (const std::out_of_range&) {
    }
}

void test_const_bounds_check() {
    const Buffer b(5);
    try {
        (void)b[5];
        assert(false);
    } catch (const std::out_of_range&) {
    }
}

void test_resize_grow() {
    Buffer a(3);
    a[0] = 1; a[1] = 2; a[2] = 3;
    a.resize(6);
    assert(a.size() == 6);
    assert(a[0] == 1); assert(a[1] == 2); assert(a[2] == 3);
    assert(a[3] == 0); assert(a[4] == 0); assert(a[5] == 0);
}

void test_resize_shrink() {
    Buffer a(6);
    for (std::size_t i = 0; i < 6; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    a.resize(3);
    assert(a.size() == 3);
    for (std::size_t i = 0; i < 3; ++i) {
        assert(a[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_resize_same() {
    Buffer a(5);
    a.resize(5);
    assert(a.size() == 5);
}

void test_resize_empty_to_nonempty() {
    Buffer a;
    a.resize(4);
    assert(a.size() == 4);
    for (std::size_t i = 0; i < 4; ++i) {
        assert(a[i] == 0);
    }
}

void test_resize_nonempty_to_empty() {
    Buffer a(4);
    for (std::size_t i = 0; i < 4; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    a.resize(0);
    assert(a.size() == 0);
}

void test_deep_copy_independence() {
    Buffer a(3);
    for (std::size_t i = 0; i < 3; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b(a);
    b[0] = 100;
    assert(a[0] == 1);
}

void test_move_reusability() {
    Buffer a(5);
    for (std::size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<std::uint8_t>(i + 1);
    }
    Buffer b;
    b = std::move(a);
    assert(a.size() == 0);
    a = Buffer(3);
    assert(a.size() == 3);
    for (std::size_t i = 0; i < 3; ++i) {
        assert(a[i] == 0);
    }
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

int main() {
    test_default_construct();
    test_construct_size();
    test_copy_construct();
    test_copy_assignment();
    test_move_construct();
    test_move_assignment();
    test_self_copy();
    test_self_move();
    test_bounds_check();
    test_const_bounds_check();
    test_resize_grow();
    test_resize_shrink();
    test_resize_same();
    test_resize_empty_to_nonempty();
    test_resize_nonempty_to_empty();
    test_deep_copy_independence();
    test_move_reusability();
    test_noexcept_move();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
