# Buffer Library

A C++20 RAII buffer class with deep-copy semantics, move semantics, and bounds-checked access.

## Features

- `Buffer(size_t n=0)`: Construct with given size, zero-initialized
- `size() const noexcept`: Return current size
- `operator[](size_t)`: Mutable and const bounds-checked access
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction and assignment
- Noexcept move construction and assignment
- Self-assignment and self-move preserve content
- RAII: no leaks, no double-frees, no stale reads

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // 10 zero-initialized bytes
b[0] = 42;              // mutable access
Buffer c = b;           // deep copy
Buffer d = std::move(c); // move (c becomes empty, reusable)
b.resize(20);           // grow, new bytes zero-initialized
```

## Testing

Compile and run tests:
```bash
clang++ -std=c++20 -Wall -Wextra -Wpedantic -Wno-self-assign-overloaded -Wno-self-move -o test_buffer test_buffer.cpp && ./test_buffer
```

Run public driver:
```bash
clang++ -std=c++20 -Wall -Wextra -Wpedantic -Wno-self-assign-overloaded -Wno-self-move -o driver PUBLIC_DRIVER.cpp && echo "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97" | ./driver
```
