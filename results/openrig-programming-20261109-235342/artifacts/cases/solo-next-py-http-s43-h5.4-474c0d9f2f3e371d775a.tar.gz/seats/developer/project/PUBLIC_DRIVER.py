import sys,json,tempfile,pathlib,traceback
sys.path.insert(0,'/work')
x=json.load(sys.stdin)
try:
 import solution
 import http.server,threading
 calls=[];routes=x['routes'];counts={}
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*a):pass
  def do_GET(self):
   calls.append(self.path);n=counts.get(self.path,0);counts[self.path]=n+1;route=routes.get(self.path,{'status':404});statuses=route.get('statuses',[route.get('status',200)]);status=statuses[min(n,len(statuses)-1)];self.send_response(status);self.end_headers();self.wfile.write(route.get('raw',json.dumps(route.get('body',{}))).encode())
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  result=solution.fetch_pages('http://127.0.0.1:'+str(server.server_port)+'/a',x.get('retries',2),.3);print(json.dumps({'value':result,'calls':calls}))
 finally:server.shutdown();server.server_close()

except Exception as e:
 print(json.dumps({'error':type(e).__name__}))
