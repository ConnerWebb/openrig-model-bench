# fetch_pages Implementation

This project implements `fetch_pages(url, retries=2, timeout=1.0)` as specified.

## API

```python
def fetch_pages(url, retries=2, timeout=1.0) -> list:
    """
    Fetch JSON pages over HTTP using Python stdlib.
    
    Args:
        url: Initial HTTP URL to fetch.
        retries: Number of retry attempts for transient errors (429, 500, 502, 503, 504).
        timeout: Request timeout in seconds.
    
    Returns:
        List of integers from all pages in order.
    
    Raises:
        ValueError: For invalid inputs, cross-origin URLs, circular references,
                    invalid JSON, non-HTTP URLs, or unrecoverable errors.
    """
```

## Validation Rules

- `retries` must be a non-negative integer
- `timeout` must be a positive number
- `url` must be a valid HTTP/HTTPS URL
- Each page must be a JSON object with:
  - `items`: list of integers (booleans are not integers)
  - `next`: absolute URL, relative URL starting with `/`, or `null`
- Relative `next` URLs are resolved against the origin
- Cross-origin URLs are rejected
- Circular references are rejected
- Only status codes 429, 500, 502, 503, 504 trigger retries

## Running Tests

```bash
python3 -m unittest test_solution.py
```
