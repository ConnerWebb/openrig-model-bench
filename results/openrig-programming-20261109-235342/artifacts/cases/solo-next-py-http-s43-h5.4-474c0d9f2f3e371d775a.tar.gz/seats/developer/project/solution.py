import json
import urllib.request
import urllib.error
import urllib.parse
import os


def fetch_pages(url, retries=2, timeout=1.0):
    if not isinstance(retries, int) or retries < 0:
        raise ValueError("retries must be a non-negative integer")
    if not isinstance(timeout, (int, float)) or timeout <= 0:
        raise ValueError("timeout must be a positive number")

    if not isinstance(url, str) or not url.lower().startswith("http"):
        raise ValueError("url must be a valid HTTP URL")

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("url must be a valid HTTP URL")

    origin = f"{parsed.scheme}://{parsed.netloc}"
    visited = set()
    all_items = []

    current_url = url
    attempt_count = 0

    while current_url:
        if current_url in visited:
            raise ValueError("detected circular reference in pages")
        visited.add(current_url)

        parsed_current = urllib.parse.urlparse(current_url)
        if f"{parsed_current.scheme}://{parsed_current.netloc}" != origin:
            raise ValueError("cross-origin URL not allowed")

        last_error = None
        for attempt in range(retries + 1):
            try:
                req = urllib.request.Request(current_url, method="GET")
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    body = response.read().decode("utf-8")
                    data = json.loads(body)

                if not isinstance(data, dict):
                    raise ValueError("JSON must be an object")

                if "items" not in data:
                    raise ValueError("JSON must contain 'items' field")
                items = data.get("items")
                if not isinstance(items, list):
                    raise ValueError("'items' must be a list")
                for item in items:
                    if isinstance(item, bool) or not isinstance(item, int):
                        raise ValueError("'items' must contain only integers")

                if "next" not in data:
                    raise ValueError("JSON must contain 'next' field")
                next_url = data.get("next")
                if next_url is not None:
                    if not isinstance(next_url, str):
                        raise ValueError("'next' must be a string or null")
                    if next_url.startswith("/"):
                        next_url = f"{origin}{next_url}"
                    elif not next_url.lower().startswith("http"):
                        raise ValueError("relative 'next' URL must start with '/'")

                all_items.extend(items)
                current_url = next_url
                attempt_count = 0
                break

            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 504):
                    last_error = e
                    if attempt == retries:
                        raise ValueError(f"HTTP error {e.code} after {retries} retries")
                else:
                    raise ValueError(f"HTTP error {e.code}")
            except urllib.error.URLError as e:
                raise ValueError(f"URL error: {e.reason}")
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON")
            except Exception as e:
                raise ValueError(str(e))
        else:
            if last_error:
                raise last_error
            raise ValueError("Failed to fetch page")

    return all_items
