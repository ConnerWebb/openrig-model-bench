import unittest
import json
import http.server
import threading
import urllib.parse
import time


class TestFetchPages(unittest.TestCase):

    def _start_server(self, routes):
        calls = []
        counts = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                n = counts.get(self.path, 0)
                counts[self.path] = n + 1
                route = routes.get(self.path, {'status': 404})
                statuses = route.get('statuses', [route.get('status', 200)])
                status = statuses[min(n, len(statuses) - 1)]
                self.send_response(status)
                self.end_headers()
                if 'raw' in route:
                    self.wfile.write(route['raw'].encode())
                else:
                    self.wfile.write(json.dumps(route.get('body', {})).encode())

        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server, f"http://127.0.0.1:{server.server_port}", calls

    def test_basic_two_pages(self):
        routes = {
            "/a": {
                "statuses": [200],
                "body": {
                    "items": [-18, 30, 58, -98, -33],
                    "next": "/b"
                }
            },
            "/b": {
                "body": {
                    "items": [-61, 93, -49],
                    "next": None
                }
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            result = fetch_pages(f"{base_url}/a")
            self.assertEqual(result, [-18, 30, 58, -98, -33, -61, 93, -49])
            self.assertEqual(calls, ["/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_retry_on_503(self):
        routes = {
            "/a": {
                "statuses": [503, 200],
                "body": {
                    "items": [-33, -78, -49, 31, -86],
                    "next": "/b"
                }
            },
            "/b": {
                "body": {
                    "items": [52, -51, 29],
                    "next": None
                }
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            result = fetch_pages(f"{base_url}/a", retries=2)
            self.assertEqual(result, [-33, -78, -49, 31, -86, 52, -51, 29])
            self.assertEqual(calls, ["/a", "/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_invalid_retries_negative(self):
        from solution import fetch_pages
        with self.assertRaises(ValueError):
            fetch_pages("http://example.com", retries=-1)

    def test_invalid_timeout_zero(self):
        from solution import fetch_pages
        with self.assertRaises(ValueError):
            fetch_pages("http://example.com", timeout=0)

    def test_invalid_timeout_negative(self):
        from solution import fetch_pages
        with self.assertRaises(ValueError):
            fetch_pages("http://example.com", timeout=-1.5)

    def test_non_http_url(self):
        from solution import fetch_pages
        with self.assertRaises(ValueError):
            fetch_pages("ftp://example.com")

    def test_items_with_bool_rejected(self):
        routes = {
            "/a": {
                "body": {
                    "items": [True],
                    "next": None
                }
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_cross_origin_rejected(self):
        routes = {
            "/a": {
                "body": {
                    "items": [],
                    "next": "http://example.invalid/x"
                }
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_circular_reference_rejected(self):
        routes = {
            "/a": {
                "body": {
                    "items": [],
                    "next": "/a"
                }
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_404_error(self):
        routes = {
            "/a": {
                "status": 404
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_exhausted_retries(self):
        routes = {
            "/a": {
                "statuses": [503]
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a", retries=2)
        finally:
            server.shutdown()
            server.server_close()

    def test_invalid_json(self):
        routes = {
            "/a": {
                "raw": "bad-json"
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_missing_next_field(self):
        routes = {
            "/a": {
                "body": {
                    "items": []
                }
            }
        }
        server, base_url, calls = self._start_server(routes)
        try:
            from solution import fetch_pages
            with self.assertRaises(ValueError):
                fetch_pages(f"{base_url}/a")
        finally:
            server.shutdown()
            server.server_close()


if __name__ == '__main__':
    unittest.main()
