# JobQueue

SQLite-backed job queue with enqueue, claim, complete, fail, and status operations.

## API

```python
from solution import JobQueue

q = JobQueue(path, max_attempts=3)
q.enqueue(key, payload) -> bool
q.claim(worker, now, lease) -> dict or None
q.complete(key, worker) -> bool
q.fail(key, worker) -> bool
q.status(key) -> dict or None
```

## Usage

```python
q = JobQueue("jobs.db")
q.enqueue("task1", {"data": "value"})
claim = q.claim("worker1", 0, 60)
if claim:
    # process job
    q.complete(claim["key"], "worker1")
```
