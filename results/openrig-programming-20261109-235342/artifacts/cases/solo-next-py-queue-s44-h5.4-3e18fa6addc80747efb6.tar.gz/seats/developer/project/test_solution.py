import unittest
import tempfile
import os
import json
import threading
import time
from solution import JobQueue


class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_enqueue_first_wins(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("a", {"v": 1}))
        self.assertFalse(q.enqueue("a", {"v": 2}))

    def test_claim_basic(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", {"v": 1})
        claim = q.claim("w", 0, 10)
        self.assertIsNotNone(claim)
        self.assertEqual(claim["key"], "a")
        self.assertEqual(claim["payload"], {"v": 1})
        self.assertEqual(claim["attempts"], 1)

    def test_claim_returns_none_when_no_jobs(self):
        q = JobQueue(self.db_path)
        self.assertIsNone(q.claim("w", 0, 10))

    def test_claim_respects_lease(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 10)
        self.assertIsNone(q.claim("w2", 5, 10))

    def test_claim_respects_max_attempts(self):
        q = JobQueue(self.db_path, max_attempts=2)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 10)
        q.fail("a", "w")
        q.claim("w", 1, 10)
        self.assertIsNone(q.claim("w", 2, 10))

    def test_complete(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 10)
        self.assertTrue(q.complete("a", "w"))
        status = q.status("a")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 10)
        self.assertFalse(q.complete("a", "wrong"))

    def test_fail_and_requeue(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 10)
        self.assertTrue(q.fail("a", "w"))
        claim = q.claim("w2", 1, 10)
        self.assertIsNotNone(claim)
        self.assertEqual(claim["attempts"], 2)

    def test_fail_exhausted(self):
        q = JobQueue(self.db_path, max_attempts=2)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 10)
        q.fail("a", "w")
        q.claim("w", 1, 10)
        self.assertTrue(q.fail("a", "w"))
        status = q.status("a")
        self.assertEqual(status["state"], "failed")

    def test_status(self):
        q = JobQueue(self.db_path)
        self.assertIsNone(q.status("nonexistent"))
        q.enqueue("a", {"v": 1})
        status = q.status("a")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_invalid_args(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue("", {"v": 1})
        with self.assertRaises(ValueError):
            q.claim("", 0, 10)
        with self.assertRaises(ValueError):
            q.claim("w", 0, 0)
        with self.assertRaises(ValueError):
            q.claim("w", 0, -1)
        with self.assertRaises(ValueError):
            q.complete("", "w")
        with self.assertRaises(ValueError):
            q.fail("", "w")
        with self.assertRaises(ValueError):
            q.status("")
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_multiple_jobs_order(self):
        q = JobQueue(self.db_path)
        q.enqueue("b", {"v": 2})
        q.enqueue("a", {"v": 1})
        claim1 = q.claim("w", 0, 10)
        claim2 = q.claim("w", 1, 10)
        self.assertEqual(claim1["key"], "a")
        self.assertEqual(claim2["key"], "b")

    def test_concurrent_access(self):
        q = JobQueue(self.db_path)
        for i in range(10):
            q.enqueue(str(i), i)
        results = []
        lock = threading.Lock()

        def worker():
            q_local = JobQueue(self.db_path)
            for _ in range(2):
                claim = q_local.claim("worker", 0, 100)
                if claim:
                    with lock:
                        results.append(claim["key"])

        threads = [threading.Thread(target=worker) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(results), 10)
        self.assertEqual(len(set(results)), 10)


if __name__ == "__main__":
    unittest.main()
