# C++ Binary Encoding/Decoding Solution

This project implements a binary serialization format for `Record` structures with the following specifications:

## Format

- **Magic bytes**: ASCII "OGC1" (4 bytes)
- **Count**: uint32 in little-endian (4 bytes)
- **Records**: For each record:
  - `id`: uint32 in little-endian (4 bytes)
  - `name_length`: uint16 in little-endian (2 bytes)
  - `name`: raw bytes (name_length bytes)
  - `value`: int64 in little-endian two's-complement (8 bytes)

## Constraints

- Maximum record count: 10,000
- Maximum name length: 1,024 bytes
- IDs must be unique
- No trailing bytes allowed

## Usage

```cpp
#include "solution.hpp"

// Encode
std::vector<Record> records = {{0, "test", 12345}};
auto encoded = encode(records);

// Decode
auto decoded = decode(encoded);
```

## Error Handling

Throws `std::exception` for:
- Invalid magic bytes
- Count exceeds 10,000
- Name length exceeds 1,024 bytes
- Duplicate IDs
- Truncated data
- Trailing bytes

## Building and Testing

```bash
clang++ -std=c++20 -fuse-ld=bfd test_solution.cpp -o test_solution
./test_solution
```
