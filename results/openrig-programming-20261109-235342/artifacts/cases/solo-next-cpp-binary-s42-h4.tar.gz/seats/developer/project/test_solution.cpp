#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <sstream>

void test_empty() {
    std::vector<Record> empty;
    auto encoded = encode(empty);
    auto decoded = decode(encoded);
    assert(decoded.empty());
    std::cout << "test_empty passed" << std::endl;
}

void test_single_record() {
    std::vector<Record> records = {{0, "test", 12345}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert(decoded.size() == 1);
    assert(decoded[0].id == 0);
    assert(decoded[0].name == "test");
    assert(decoded[0].value == 12345);
    std::cout << "test_single_record passed" << std::endl;
}

void test_multiple_records() {
    std::vector<Record> records = {
        {0, "0", 68856894251056856},
        {1, "b c0", -233957124999232821},
        {2, "日本0", -232942477253485299}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert(decoded.size() == 3);
    assert(decoded[0].id == 0 && decoded[0].name == "0" && decoded[0].value == 68856894251056856);
    assert(decoded[1].id == 1 && decoded[1].name == "b c0" && decoded[1].value == -233957124999232821);
    assert(decoded[2].id == 2 && decoded[2].name == "日本0" && decoded[2].value == -232942477253485299);
    std::cout << "test_multiple_records passed" << std::endl;
}

void test_negative_values() {
    std::vector<Record> records = {
        {0, "a", -1},
        {1, "b", -100},
        {2, "c", -9223372036854775807LL}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert(decoded.size() == 3);
    assert(decoded[0].value == -1);
    assert(decoded[1].value == -100);
    assert(decoded[2].value == -9223372036854775807LL);
    std::cout << "test_negative_values passed" << std::endl;
}

void test_max_name_length() {
    std::string name(1024, 'x');
    std::vector<Record> records = {{0, name, 0}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert(decoded[0].name.size() == 1024);
    std::cout << "test_max_name_length passed" << std::endl;
}

void test_invalid_magic() {
    try {
        std::vector<uint8_t> data = {'X', 'G', 'C', '1', 0, 0, 0, 0};
        decode(data);
        assert(false && "Should have thrown");
    } catch (const std::exception&) {
        std::cout << "test_invalid_magic passed" << std::endl;
    }
}

void test_trailing_bytes() {
    try {
        std::vector<Record> records = {{0, "a", 1}};
        auto encoded = encode(records);
        encoded.push_back(0); // Add trailing byte
        decode(encoded);
        assert(false && "Should have thrown");
    } catch (const std::exception&) {
        std::cout << "test_trailing_bytes passed" << std::endl;
    }
}

void test_duplicate_ids() {
    try {
        std::vector<Record> records = {{0, "a", 1}, {0, "b", 2}};
        encode(records);
        assert(false && "Should have thrown");
    } catch (const std::exception&) {
        std::cout << "test_duplicate_ids passed" << std::endl;
    }
}

void test_count_overflow() {
    try {
        std::vector<Record> records;
        for (uint32_t i = 0; i <= 10000; ++i) {
            records.push_back({i, std::to_string(i), i});
        }
        encode(records);
        assert(false && "Should have thrown");
    } catch (const std::exception&) {
        std::cout << "test_count_overflow passed" << std::endl;
    }
}

void test_name_length_overflow() {
    try {
        std::string name(1025, 'x');
        std::vector<Record> records = {{0, name, 0}};
        encode(records);
        assert(false && "Should have thrown");
    } catch (const std::exception&) {
        std::cout << "test_name_length_overflow passed" << std::endl;
    }
}

void test_truncated_data() {
    try {
        std::vector<uint8_t> data = {'O', 'G', 'C', '1', 1, 0, 0, 0, 0, 0}; // count=1 but missing rest
        decode(data);
        assert(false && "Should have thrown");
    } catch (const std::exception&) {
        std::cout << "test_truncated_data passed" << std::endl;
    }
}

void test_roundtrip() {
    std::vector<Record> original = {
        {0, "0", 68856894251056856},
        {1, "b c0", -233957124999232821},
        {2, "日本0", -232942477253485299},
        {3, "0", 955139844676822483},
        {4, "b c0", -982883216065862986},
        {5, "日本0", -1013209677606831142},
        {6, "x\"y0", 328776324058667354},
        {7, "x\"y0", -1264979447955638},
        {8, "0", -433595158558128308},
        {9, "b c0", 220906017986201192}
    };
    auto encoded = encode(original);
    auto decoded = decode(encoded);
    assert(decoded.size() == original.size());
    for (size_t i = 0; i < original.size(); ++i) {
        assert(decoded[i].id == original[i].id);
        assert(decoded[i].name == original[i].name);
        assert(decoded[i].value == original[i].value);
    }
    std::cout << "test_roundtrip passed" << std::endl;
}

int main() {
    test_empty();
    test_single_record();
    test_multiple_records();
    test_negative_values();
    test_max_name_length();
    test_invalid_magic();
    test_trailing_bytes();
    test_duplicate_ids();
    test_count_overflow();
    test_name_length_overflow();
    test_truncated_data();
    test_roundtrip();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
