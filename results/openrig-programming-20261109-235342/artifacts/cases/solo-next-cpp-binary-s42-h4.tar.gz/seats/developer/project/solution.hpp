#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <cstdint>
#include <string>
#include <vector>
#include <span>
#include <stdexcept>
#include <cstring>
#include <algorithm>

struct Record {
    uint32_t id;
    std::string name;
    int64_t value;
};

inline std::vector<uint8_t> encode(const std::vector<Record>& records) {
    // Validate count constraint
    if (records.size() > 10000) {
        throw std::runtime_error("Record count exceeds maximum of 10000");
    }
    
    // Check for duplicate IDs
    std::vector<uint32_t> ids;
    ids.reserve(records.size());
    for (const auto& r : records) {
        ids.push_back(r.id);
    }
    std::sort(ids.begin(), ids.end());
    auto last = std::unique(ids.begin(), ids.end());
    if (last != ids.end()) {
        throw std::runtime_error("Duplicate record IDs found");
    }
    
    // Calculate total size
    size_t total_size = 8; // 4 bytes magic + 4 bytes count
    for (const auto& r : records) {
        if (r.name.size() > 1024) {
            throw std::runtime_error("Name length exceeds maximum of 1024 bytes");
        }
        total_size += 4 + 2 + r.name.size() + 8; // id + name_len + name + value
    }
    
    std::vector<uint8_t> output;
    output.reserve(total_size);
    
    // Write magic "OGC1"
    output.push_back('O');
    output.push_back('G');
    output.push_back('C');
    output.push_back('1');
    
    // Write count (little-endian uint32)
    uint32_t count = static_cast<uint32_t>(records.size());
    output.push_back(count & 0xFF);
    output.push_back((count >> 8) & 0xFF);
    output.push_back((count >> 16) & 0xFF);
    output.push_back((count >> 24) & 0xFF);
    
    // Write each record
    for (const auto& r : records) {
        // id (little-endian uint32)
        output.push_back(r.id & 0xFF);
        output.push_back((r.id >> 8) & 0xFF);
        output.push_back((r.id >> 16) & 0xFF);
        output.push_back((r.id >> 24) & 0xFF);
        
        // name length (little-endian uint16)
        uint16_t name_len = static_cast<uint16_t>(r.name.size());
        output.push_back(name_len & 0xFF);
        output.push_back((name_len >> 8) & 0xFF);
        
        // name bytes
        output.insert(output.end(), r.name.begin(), r.name.end());
        
        // value (little-endian int64)
        uint64_t uvalue = static_cast<uint64_t>(r.value);
        output.push_back(uvalue & 0xFF);
        output.push_back((uvalue >> 8) & 0xFF);
        output.push_back((uvalue >> 16) & 0xFF);
        output.push_back((uvalue >> 24) & 0xFF);
        output.push_back((uvalue >> 32) & 0xFF);
        output.push_back((uvalue >> 40) & 0xFF);
        output.push_back((uvalue >> 48) & 0xFF);
        output.push_back((uvalue >> 56) & 0xFF);
    }
    
    return output;
}

inline std::vector<Record> decode(std::span<const uint8_t> data) {
    // Check minimum size for header
    if (data.size() < 8) {
        throw std::runtime_error("Data too short for header");
    }
    
    // Check magic "OGC1"
    if (data[0] != 'O' || data[1] != 'G' || data[2] != 'C' || data[3] != '1') {
        throw std::runtime_error("Invalid magic bytes");
    }
    
    // Read count (little-endian uint32)
    uint32_t count = static_cast<uint32_t>(data[4]) |
                     (static_cast<uint32_t>(data[5]) << 8) |
                     (static_cast<uint32_t>(data[6]) << 16) |
                     (static_cast<uint32_t>(data[7]) << 24);
    
    // Validate count
    if (count > 10000) {
        throw std::runtime_error("Record count exceeds maximum of 10000");
    }
    
    // Check for truncation
    size_t min_expected = 8 + count * (4 + 2 + 8); // header + min record size
    if (data.size() < min_expected) {
        throw std::runtime_error("Data truncated");
    }
    
    std::vector<Record> records;
    records.reserve(count);
    
    std::vector<uint32_t> seen_ids;
    seen_ids.reserve(count);
    
    size_t offset = 8;
    for (uint32_t i = 0; i < count; ++i) {
        // Check remaining data before each record
        if (offset + 4 + 2 > data.size()) {
            throw std::runtime_error("Data truncated while reading record");
        }
        
        // Read id (little-endian uint32)
        uint32_t id = static_cast<uint32_t>(data[offset]) |
                      (static_cast<uint32_t>(data[offset + 1]) << 8) |
                      (static_cast<uint32_t>(data[offset + 2]) << 16) |
                      (static_cast<uint32_t>(data[offset + 3]) << 24);
        offset += 4;
        
        // Check for duplicate ID
        for (uint32_t seen_id : seen_ids) {
            if (seen_id == id) {
                throw std::runtime_error("Duplicate record ID found");
            }
        }
        seen_ids.push_back(id);
        
        // Read name length (little-endian uint16)
        if (offset + 2 > data.size()) {
            throw std::runtime_error("Data truncated while reading name length");
        }
        uint16_t name_len = static_cast<uint16_t>(data[offset]) |
                            (static_cast<uint16_t>(data[offset + 1]) << 8);
        offset += 2;
        
        // Validate name length
        if (name_len > 1024) {
            throw std::runtime_error("Name length exceeds maximum of 1024 bytes");
        }
        
        // Read name bytes
        if (offset + name_len > data.size()) {
            throw std::runtime_error("Data truncated while reading name");
        }
        std::string name(reinterpret_cast<const char*>(data.data() + offset), name_len);
        offset += name_len;
        
        // Read value (little-endian int64)
        if (offset + 8 > data.size()) {
            throw std::runtime_error("Data truncated while reading value");
        }
        uint64_t uvalue = static_cast<uint64_t>(data[offset]) |
                          (static_cast<uint64_t>(data[offset + 1]) << 8) |
                          (static_cast<uint64_t>(data[offset + 2]) << 16) |
                          (static_cast<uint64_t>(data[offset + 3]) << 24) |
                          (static_cast<uint64_t>(data[offset + 4]) << 32) |
                          (static_cast<uint64_t>(data[offset + 5]) << 40) |
                          (static_cast<uint64_t>(data[offset + 6]) << 48) |
                          (static_cast<uint64_t>(data[offset + 7]) << 56);
        int64_t value = static_cast<int64_t>(uvalue);
        offset += 8;
        
        records.push_back({id, name, value});
    }
    
    // Check for trailing bytes
    if (offset < data.size()) {
        throw std::runtime_error("Trailing bytes detected");
    }
    
    return records;
}

#endif // SOLUTION_HPP
