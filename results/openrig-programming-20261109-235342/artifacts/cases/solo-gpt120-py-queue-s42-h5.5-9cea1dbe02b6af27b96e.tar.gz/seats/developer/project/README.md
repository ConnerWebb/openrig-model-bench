# JobQueue

This repository implements a simple persistent job queue backed by SQLite.

## Overview

`JobQueue(path, max_attempts=3)` creates (or opens) a SQLite database at `path`.
Each job has a unique `key` and a JSON‑serialisable `payload`.

The queue supports:
- **enqueue(key, payload)** – add a new job; duplicate keys are ignored.
- **claim(worker, now, lease)** – atomically fetch the oldest pending job, mark it as leased to `worker` for `lease` seconds, and increment its attempt count. Returns the job data or `None`.
- **complete(key, worker)** – mark a leased job as done (must be owned by the worker).
- **fail(key, worker)** – indicate failure; the job is re‑queued unless it has reached `max_attempts`, after which it becomes `failed`.
- **status(key)** – retrieve the current state (`queued`, `leased`, `done`, `failed`) and attempt count.

All operations are thread‑safe and safe across multiple processes because they use SQLite transactions with a global lock.

## Design decisions

- **SQLite** provides durability without external services.
- Jobs are stored in a single table with indexes for quick selection.
- The `claim` method uses a deterministic ordering (`rowid`) to ensure FIFO behaviour.
- Attempts are capped by `max_attempts`; exceeding this moves the job to the `failed` state.
- Payloads are stored as compact JSON strings.

## Usage example

```python
from solution import JobQueue
import time

q = JobQueue('jobs.db', max_attempts=3)
q.enqueue('job1', {'task': 'process', 'value': 42})

now = time.time()
job = q.claim('worker-A', now, lease=30)
if job:
    # do work with job['payload']
    success = True
    if success:
        q.complete(job['key'], 'worker-A')
    else:
        q.fail(job['key'], 'worker-A')
```

## Testing

Run the bundled unit tests with:

```bash
python -m unittest test_solution.py
```

All tests should pass, confirming correct behaviour for enqueuing, claiming, completing, failing, and error handling.
