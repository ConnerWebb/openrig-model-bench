import os
import time
import unittest
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.db_path = 'test_jobs.db'
        # ensure clean
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        self.q = JobQueue(self.db_path, max_attempts=2)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_enqueue_and_status(self):
        self.assertTrue(self.q.enqueue('a', {'x': 1}))
        # duplicate should be ignored
        self.assertFalse(self.q.enqueue('a', {'x': 2}))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)

    def test_claim_and_complete(self):
        self.q.enqueue('b', 123)
        now = time.time()
        claim = self.q.claim('worker1', now, lease=5)
        self.assertIsNotNone(claim)
        self.assertEqual(claim['key'], 'b')
        self.assertEqual(claim['payload'], 123)
        self.assertEqual(claim['attempts'], 1)
        # status should be leased
        self.assertEqual(self.q.status('b')['state'], 'leased')
        # complete
        self.assertTrue(self.q.complete('b', 'worker1'))
        self.assertEqual(self.q.status('b')['state'], 'done')

    def test_fail_and_retry(self):
        self.q.enqueue('c', 'data')
        now = time.time()
        claim = self.q.claim('w', now, lease=1)
        self.assertIsNotNone(claim)
        # first fail, should go back to queued (attempts=1 < max_attempts=2)
        self.assertTrue(self.q.fail('c', 'w'))
        self.assertEqual(self.q.status('c')['state'], 'queued')
        # claim again
        claim2 = self.q.claim('w', now+2, lease=1)
        self.assertIsNotNone(claim2)
        self.assertEqual(claim2['attempts'], 2)
        # second fail should mark as failed
        self.assertTrue(self.q.fail('c', 'w'))
        self.assertEqual(self.q.status('c')['state'], 'failed')

    def test_invalid_arguments(self):
        with self.assertRaises(ValueError):
            JobQueue('x.db', max_attempts=0)
        self.q.enqueue('d', None)
        with self.assertRaises(ValueError):
            self.q.claim('', time.time(), 1)
        with self.assertRaises(ValueError):
            self.q.claim('w', time.time(), 0)
        with self.assertRaises(ValueError):
            self.q.complete('', 'w')
        with self.assertRaises(ValueError):
            self.q.fail('d', '')
        with self.assertRaises(ValueError):
            self.q.status('')

if __name__ == '__main__':
    unittest.main()
