import json
import sqlite3
import threading
import os
from typing import Any, Dict, Optional

_DB_LOCK = threading.Lock()

def _init_db(conn: sqlite3.Connection, max_attempts: int) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
            key TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            state TEXT NOT NULL,
            attempts INTEGER NOT NULL,
            owner TEXT,
            lease_until REAL,
            max_attempts INTEGER NOT NULL
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_state_lease ON jobs (state, lease_until, attempts)")
    conn.commit()

class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self.max_attempts = max_attempts
        if not os.path.isabs(path):
            path = os.path.join('/tmp', os.path.basename(path))
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        self.path = path
        self.conn = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        with _DB_LOCK:
            _init_db(self.conn, max_attempts)

    def enqueue(self, key: str, payload: Any) -> bool:
        if not key:
            raise ValueError("key must be non‑empty")
        payload_str = json.dumps(payload, separators=(',', ':'))
        with _DB_LOCK:
            cur = self.conn.cursor()
            try:
                cur.execute(
                    "INSERT INTO jobs (key, payload, state, attempts, max_attempts) VALUES (?,?,?,?,?)",
                    (key, payload_str, 'queued', 0, self.max_attempts),
                )
                self.conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False

    def _finalize_expired(self, now: float) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            UPDATE jobs SET state = 'failed', lease_until = NULL
            WHERE state = 'leased' AND attempts >= max_attempts AND lease_until <= ?
            """,
            (now,)
        )
        self.conn.commit()

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not worker:
            raise ValueError("worker must be non‑empty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        with _DB_LOCK:
            self._finalize_expired(now)
            cur = self.conn.cursor()
            cur.execute(
                """
                SELECT key, payload, attempts FROM jobs
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                  AND attempts < max_attempts
                ORDER BY rowid ASC LIMIT 1
                """,
                (now,)
            )
            row = cur.fetchone()
            if not row:
                return None
            key, payload_str, attempts = row
            new_attempts = attempts + 1
            lease_until = now + lease
            cur.execute(
                """
                UPDATE jobs SET state = 'leased', attempts = ?, owner = ?, lease_until = ?
                WHERE key = ? AND attempts = ?
                """,
                (new_attempts, worker, lease_until, key, attempts)
            )
            if cur.rowcount != 1:
                self.conn.commit()
                return self.claim(worker, now, lease)
            self.conn.commit()
            return {"key": key, "payload": json.loads(payload_str), "attempts": new_attempts}

    def complete(self, key: str, worker: str) -> bool:
        if not key or not worker:
            raise ValueError("key and worker must be non‑empty")
        with _DB_LOCK:
            cur = self.conn.cursor()
            cur.execute(
                """
                UPDATE jobs SET state = 'done', owner = ?, lease_until = NULL
                WHERE key = ? AND state = 'leased' AND owner = ?
                """,
                (worker, key, worker),
            )
            self.conn.commit()
            return cur.rowcount == 1

    def fail(self, key: str, worker: str) -> bool:
        if not key or not worker:
            raise ValueError("key and worker must be non‑empty")
        with _DB_LOCK:
            cur = self.conn.cursor()
            cur.execute(
                "SELECT attempts, max_attempts FROM jobs WHERE key = ?",
                (key,)
            )
            row = cur.fetchone()
            if not row:
                return False
            attempts, max_attempts = row
            if attempts >= max_attempts:
                cur.execute(
                    "UPDATE jobs SET state = 'failed', owner = ?, lease_until = NULL WHERE key = ?",
                    (worker, key),
                )
            else:
                cur.execute(
                    "UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?",
                    (key,),
                )
            self.conn.commit()
            return True

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not key:
            raise ValueError("key must be non‑empty")
        with _DB_LOCK:
            cur = self.conn.cursor()
            cur.execute("SELECT state, attempts FROM jobs WHERE key = ?", (key,))
            row = cur.fetchone()
            if not row:
                return None
            state, attempts = row
            return {"state": state, "attempts": attempts}

    def __del__(self):
        try:
            self.conn.close()
        except Exception:
            pass
