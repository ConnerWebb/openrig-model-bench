#pragma once
#include <vector>
#include <string>
#include <cstdint>
#include <span>

struct Record {
    uint32_t id;
    std::string name;
    int64_t value;
};

std::vector<uint8_t> encode(const std::vector<Record>& records);
std::vector<Record> decode(std::span<const uint8_t> bytes);