# Record Encoding/Decoding Solution

This implementation provides functions to encode and decode Record objects according to the specified format.

## Format Specification

The encoded data follows this structure:
- Magic number: "OGC1" (4 bytes)
- Record count: 4-byte little-endian integer
- For each record:
  - ID: 4-byte little-endian integer
  - Name length: 2-byte little-endian integer
  - Name bytes: variable length
  - Value: 8-byte little-endian two's complement integer

## Functions

### encode
Converts a vector of Record objects into a byte vector.

### decode
Converts a byte vector back into a vector of Record objects.

## Error Handling

The implementation throws `std::runtime_error` for:
- Invalid magic number
- Truncated data
- Too many records ( > 10000)
- Name too long ( > 1024 bytes)
- Trailing bytes