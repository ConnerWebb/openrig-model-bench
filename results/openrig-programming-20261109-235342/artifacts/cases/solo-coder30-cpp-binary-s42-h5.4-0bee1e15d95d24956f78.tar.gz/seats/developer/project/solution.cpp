#include "solution.hpp"
#include <stdexcept>
#include <algorithm>
#include <cstring>

std::vector<uint8_t> encode(const std::vector<Record>& records) {
    // Validate input
    if (records.size() > 10000) {
        throw std::runtime_error("Too many records");
    }
    
    std::vector<uint8_t> result;
    
    // Add magic number "OGC1"
    result.insert(result.end(), {'O', 'G', 'C', '1'});
    
    // Add record count (little-endian)
    uint32_t count = static_cast<uint32_t>(records.size());
    result.push_back(count & 0xFF);
    result.push_back((count >> 8) & 0xFF);
    result.push_back((count >> 16) & 0xFF);
    result.push_back((count >> 24) & 0xFF);
    
    // Add each record
    for (const auto& record : records) {
        // Add ID (little-endian)
        result.push_back(record.id & 0xFF);
        result.push_back((record.id >> 8) & 0xFF);
        result.push_back((record.id >> 16) & 0xFF);
        result.push_back((record.id >> 24) & 0xFF);
        
        // Add name length (little-endian)
        uint16_t name_len = static_cast<uint16_t>(record.name.length());
        result.push_back(name_len & 0xFF);
        result.push_back((name_len >> 8) & 0xFF);
        
        // Add name bytes
        result.insert(result.end(), record.name.begin(), record.name.end());
        
        // Add value (little-endian)
        result.push_back(record.value & 0xFF);
        result.push_back((record.value >> 8) & 0xFF);
        result.push_back((record.value >> 16) & 0xFF);
        result.push_back((record.value >> 24) & 0xFF);
        result.push_back((record.value >> 32) & 0xFF);
        result.push_back((record.value >> 40) & 0xFF);
        result.push_back((record.value >> 48) & 0xFF);
        result.push_back((record.value >> 56) & 0xFF);
    }
    
    return result;
}

std::vector<Record> decode(std::span<const uint8_t> bytes) {
    if (bytes.size() < 8) {
        throw std::runtime_error("Truncated data");
    }
    
    // Check magic number
    if (bytes[0] != 'O' || bytes[1] != 'G' || bytes[2] != 'C' || bytes[3] != '1') {
        throw std::runtime_error("Bad magic");
    }
    
    // Read record count
    uint32_t count = bytes[4] | (bytes[5] << 8) | (bytes[6] << 16) | (bytes[7] << 24);
    
    if (count > 10000) {
        throw std::runtime_error("Too many records");
    }
    
    std::vector<Record> records;
    size_t pos = 8;
    
    for (uint32_t i = 0; i < count; ++i) {
        if (pos + 4 > bytes.size()) {
            throw std::runtime_error("Truncated data");
        }
        
        // Read ID
        uint32_t id = bytes[pos] | (bytes[pos + 1] << 8) | (bytes[pos + 2] << 16) | (bytes[pos + 3] << 24);
        pos += 4;
        
        // Read name length
        if (pos + 2 > bytes.size()) {
            throw std::runtime_error("Truncated data");
        }
        uint16_t name_len = bytes[pos] | (bytes[pos + 1] << 8);
        pos += 2;
        
        // Check name length
        if (name_len > 1024) {
            throw std::runtime_error("Name too long");
        }
        
        // Read name bytes
        if (pos + name_len > bytes.size()) {
            throw std::runtime_error("Truncated data");
        }
        std::string name(bytes.begin() + pos, bytes.begin() + pos + name_len);
        pos += name_len;
        
        // Read value
        if (pos + 8 > bytes.size()) {
            throw std::runtime_error("Truncated data");
        }
        int64_t value = bytes[pos] | 
                       (static_cast<int64_t>(bytes[pos + 1]) << 8) |
                       (static_cast<int64_t>(bytes[pos + 2]) << 16) |
                       (static_cast<int64_t>(bytes[pos + 3]) << 24) |
                       (static_cast<int64_t>(bytes[pos + 4]) << 32) |
                       (static_cast<int64_t>(bytes[pos + 5]) << 40) |
                       (static_cast<int64_t>(bytes[pos + 6]) << 48) |
                       (static_cast<int64_t>(bytes[pos + 7]) << 56);
        pos += 8;
        
        records.push_back({id, name, value});
    }
    
    // Check for trailing bytes
    if (pos != bytes.size()) {
        throw std::runtime_error("Trailing bytes");
    }
    
    return records;
}