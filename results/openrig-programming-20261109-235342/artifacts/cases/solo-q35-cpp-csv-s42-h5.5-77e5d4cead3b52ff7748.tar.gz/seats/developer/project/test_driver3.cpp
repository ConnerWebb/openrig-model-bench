#include <iostream>
#include <sstream>
#include <string>
#include "solution.hpp"

int main() {
    // The actual input from case 0
    std::string input = R"(category,amount
"x""quote",51268
food,4725
rent,69177
rent,4517
food,-3853
"x""quote",-22826
"x""quote",-4598
"x""quote",-26830
日本，39039
"a,b",29914
rent,15786
日本，-8138
food,15570
"x""quote",-26030
"two
lines",54977
"x""quote",-5124
rent,12112
"two
lines",28447
food,57027
food,2732)";
    
    std::istringstream in(input);
    
    // Read character by character to see what we get
    char c;
    int count = 0;
    while (in.get(c)) {
        if (c == '\n') {
            std::cout << "\\n";
        } else if (c == '"') {
            std::cout << "\"";
        } else {
            std::cout << c;
        }
        count++;
        if (count > 200) {
            std::cout << "... (truncated)\n";
            break;
        }
    }
    std::cout << "\n\n";
    
    try {
        auto result = aggregate(in);
        std::cout << "Success:\n";
        for (const auto& [k, v] : result) {
            std::cout << "  " << k << ": " << v << "\n";
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
    }
    
    return 0;
}
