#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>

int main() {
    // Test with escaped quote: "say ""hello""",100
    std::string input = "category,amount\n\"say \"\"hello\"\"\",100";
    std::istringstream iss(input);
    
    std::string currentRecord;
    bool inQuotes = false;
    bool lastWasQuote = false;
    
    char c;
    while (iss.get(c)) {
        std::cout << "Read char '" << c << "' (char " << (int)c << "), inQuotes=" << inQuotes << ", lastWasQuote=" << lastWasQuote << ", currentRecord=[" << currentRecord << "]\n";
        
        if (c == '"') {
            if (inQuotes && lastWasQuote) {
                // Escaped quote - add one quote and reset lastWasQuote
                currentRecord += '"';
                lastWasQuote = false;
            } else if (inQuotes) {
                // End of quoted section
                inQuotes = false;
                currentRecord += '"';
                lastWasQuote = true;
            } else {
                // Start of quoted section
                inQuotes = true;
                currentRecord += '"';
                lastWasQuote = true;
            }
        } else if (c == '\n') {
            if (inQuotes) {
                currentRecord += '\n';
                lastWasQuote = false;
            } else {
                std::cout << "  -> Flushing record: [" << currentRecord << "]\n";
                currentRecord.clear();
                lastWasQuote = false;
            }
        } else if (c == '\r') {
            // Skip CR
            lastWasQuote = false;
        } else {
            currentRecord += c;
            lastWasQuote = false;
        }
    }
    
    if (!currentRecord.empty()) {
        std::cout << "  -> Flushing final record: [" << currentRecord << "]\n";
    }
    
    return 0;
}
