#include <iostream>
#include <sstream>
#include <string>
#include "solution.hpp"

int main() {
    // The actual input from case 0
    std::string input = R"(category,amount
"x""quote",51268
food,4725)";
    
    std::istringstream in(input);
    
    // Read character by character to see what we get
    char c;
    std::string currentRecord;
    bool inQuotes = false;
    int count = 0;
    
    while (in.get(c)) {
        if (c == '"') {
            if (inQuotes) {
                if (in.peek() == '"') {
                    in.get(c);
                    currentRecord += '"';
                } else {
                    inQuotes = false;
                    currentRecord += '"';
                }
            } else {
                inQuotes = true;
                currentRecord += '"';
            }
        } else if (c == '\n') {
            if (inQuotes) {
                currentRecord += '\n';
            } else {
                std::cout << "Record: [" << currentRecord << "]\n";
                if (currentRecord == "category,amount") {
                    std::cout << "  -> Header matched!\n";
                } else {
                    std::cout << "  -> Header mismatch! Expected [category,amount]\n";
                }
                currentRecord.clear();
            }
        } else if (c == '\r') {
            // Skip
        } else {
            currentRecord += c;
        }
        count++;
        if (count > 50) break;
    }
    
    if (!currentRecord.empty()) {
        std::cout << "Final record: [" << currentRecord << "]\n";
    }
    
    return 0;
}
