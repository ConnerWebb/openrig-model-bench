#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>

int main() {
    std::string input = "category,amount\n\"two\nlines\",100";
    std::istringstream iss(input);
    
    std::string currentRecord;
    bool inQuotes = false;
    
    char c;
    while (iss.get(c)) {
        std::cout << "Read char '" << c << "' (char " << (int)c << "), inQuotes=" << inQuotes << ", currentRecord=[" << currentRecord << "]\n";
        
        if (c == '"') {
            if (inQuotes) {
                if (!currentRecord.empty() && currentRecord.back() == '"') {
                    currentRecord += '"';
                } else {
                    inQuotes = false;
                    currentRecord += '"';
                }
            } else {
                inQuotes = true;
                currentRecord += '"';
            }
        } else if (c == '\n') {
            if (inQuotes) {
                currentRecord += '\n';
            } else {
                std::cout << "  -> Flushing record: [" << currentRecord << "]\n";
                currentRecord.clear();
            }
        } else if (c == '\r') {
            // Skip CR
        } else {
            currentRecord += c;
        }
    }
    
    if (!currentRecord.empty()) {
        std::cout << "  -> Flushing final record: [" << currentRecord << "]\n";
    }
    
    return 0;
}
