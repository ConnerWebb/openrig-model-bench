#include <iostream>
#include <sstream>
#include <string>
#include "solution.hpp"

int main() {
    // Simulate what the driver does
    std::string input = R"(category,amount
"x""quote",51268
food,4725)";
    
    std::istringstream in(input);
    
    // Read character by character to see what we get
    char c;
    int count = 0;
    while (in.get(c) && count < 50) {
        if (c == '\n') {
            std::cout << "\\n";
        } else if (c == '"') {
            std::cout << "\"";
        } else {
            std::cout << c;
        }
        count++;
    }
    std::cout << "\n\n";
    
    try {
        auto result = aggregate(in);
        std::cout << "Success:\n";
        for (const auto& [k, v] : result) {
            std::cout << "  " << k << ": " << v << "\n";
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
    }
    
    return 0;
}
