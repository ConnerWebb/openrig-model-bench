#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <string>
#include <map>
#include <istream>
#include <stdexcept>
#include <cstdint>
#include <cctype>

namespace {

// Parse a single CSV field from a stream
// Returns the parsed field value
// Sets field_eof to true if end of input is reached
std::string parse_field(std::istream& in, bool& field_eof) {
    std::string result;
    char c;
    
    // Check for EOF
    if (!in.get(c)) {
        field_eof = true;
        return result;
    }
    
    // Check for quoted field
    if (c == '"') {
        while (in.get(c)) {
            if (c == '"') {
                // Check for escaped quote (double quote)
                if (in.peek() == '"') {
                    in.get(c);
                    result += '"';
                } else {
                    // End of quoted field
                    return result;
                }
            } else {
                result += c;
            }
        }
        field_eof = true;
        throw std::invalid_argument("Unterminated quoted field");
    } else {
        // Unquoted field
        result += c;
        while (in.get(c) && c != ',' && c != '\n' && c != '\r') {
            result += c;
        }
        // Handle CR/LF - consume the \r if followed by \n
        if (c == '\r' && in.peek() == '\n') {
            in.get(c);
        }
        return result;
    }
}

// Strip leading/trailing spaces and tabs from a field
std::string strip_field(const std::string& field) {
    size_t start = 0;
    size_t end = field.size();
    
    while (start < end && (field[start] == ' ' || field[start] == '\t')) {
        start++;
    }
    while (end > start && (field[end - 1] == ' ' || field[end - 1] == '\t')) {
        end--;
    }
    
    return field.substr(start, end - start);
}

// Parse a signed int64 from a string
std::int64_t parse_int64(const std::string& str) {
    if (str.empty()) {
        throw std::invalid_argument("Empty field");
    }
    
    size_t start = 0;
    bool negative = false;
    
    if (str[start] == '+') {
        start++;
    } else if (str[start] == '-') {
        negative = true;
        start++;
    }
    
    if (start >= str.size()) {
        throw std::invalid_argument("Invalid number format");
    }
    
    // Check for non-digit characters
    for (size_t i = start; i < str.size(); i++) {
        if (!std::isdigit(static_cast<unsigned char>(str[i]))) {
            throw std::invalid_argument("Invalid number format");
        }
    }
    
    // Parse the number with overflow checking
    std::int64_t result = 0;
    for (size_t i = start; i < str.size(); i++) {
        int digit = str[i] - '0';
        
        // Check for overflow before multiplying
        if (negative) {
            if (result < (std::int64_t(-1) - digit) / 10) {
                throw std::overflow_error("Integer overflow");
            }
            result = result * 10 + digit;
        } else {
            if (result > (std::int64_t(-1) - 1 - digit) / 10) {
                throw std::overflow_error("Integer overflow");
            }
            result = result * 10 + digit;
        }
    }
    
    if (negative) {
        result = -result;
    }
    
    return result;
}

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read and parse header
    std::string line;
    char c;
    
    // Read header line character by character
    while (in.get(c)) {
        if (c == '\n' || c == '\r') {
            break;
        }
        line += c;
    }
    
    // Handle CR/LF
    if (c == '\r' && in.peek() == '\n') {
        in.get(c);
    }
    
    // Strip and validate header
    line = strip_field(line);
    if (line != "category,amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Parse data rows
    bool eof = false;
    while (!eof) {
        std::string category;
        std::string amount_str;
        
        // Read category
        bool field_eof = false;
        std::string field = parse_field(in, field_eof);
        if (field_eof && field.empty()) {
            break;
        }
        category = strip_field(field);
        
        // Check for empty category
        if (category.empty()) {
            throw std::invalid_argument("Empty category");
        }
        
        // Read amount
        field_eof = false;
        field = parse_field(in, field_eof);
        amount_str = strip_field(field);
        
        // Check for empty amount
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount");
        }
        
        // Parse amount
        std::int64_t amount = parse_int64(amount_str);
        
        // Accumulate
        result[category] += amount;
        
        // Read newline
        if (in.get(c) && c != '\n' && c != '\r') {
            // Not a newline, might be end of file or malformed
            if (c == '\r' && in.peek() == '\n') {
                in.get(c);
            }
        }
        
        // Check for EOF
        if (in.eof()) {
            eof = true;
        }
    }
    
    return result;
}

#endif // SOLUTION_HPP
