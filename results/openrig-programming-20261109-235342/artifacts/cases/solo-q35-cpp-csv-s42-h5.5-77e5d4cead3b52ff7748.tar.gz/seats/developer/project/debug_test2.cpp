#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>

std::vector<std::string> parseLine(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool inQuotes = false;
    size_t i = 0;
    
    while (i < line.size()) {
        char c = line[i];
        
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < line.size() && line[i + 1] == '"') {
                    field += '"';
                    i += 2;
                } else {
                    inQuotes = false;
                    i++;
                }
            } else {
                field += c;
                i++;
            }
        } else {
            if (c == '"') {
                inQuotes = true;
                i++;
            } else if (c == ',') {
                fields.push_back(field);
                field.clear();
                i++;
            } else {
                field += c;
                i++;
            }
        }
    }
    
    if (inQuotes) {
        throw std::invalid_argument("Unterminated quote");
    }
    
    fields.push_back(field);
    return fields;
}

int main() {
    // Test case: "two\nlines",100
    std::string test = "\"two\nlines\",100";
    std::cout << "Input: [" << test << "]\n";
    std::cout << "Size: " << test.size() << "\n";
    for (size_t i = 0; i < test.size(); i++) {
        std::cout << "  [" << i << "] = '" << test[i] << "' (char " << (int)test[i] << ")\n";
    }
    
    auto fields = parseLine(test);
    std::cout << "Parsed: " << fields.size() << " fields\n";
    for (size_t i = 0; i < fields.size(); i++) {
        std::cout << "  [" << i << "] = [" << fields[i] << "]\n";
    }
    
    return 0;
}
