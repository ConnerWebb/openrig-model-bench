#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <iomanip>
#include "solution.hpp"

int main() {
    // Read the actual input file
    std::ifstream in("public-inputs/case-00.csv");
    std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    in.close();
    
    std::cout << "File content (first 100 chars):\n";
    for (size_t i = 0; i < std::min((size_t)100, content.size()); i++) {
        char c = content[i];
        if (c == '\n') std::cout << "\\n";
        else if (c == '"') std::cout << "\"";
        else std::cout << c;
    }
    std::cout << "\n\n";
    
    // The driver reads with std::quoted, so the input must be a quoted string
    // Let's simulate that by wrapping the content in quotes
    std::string quoted = "\"" + content + "\"";
    
    std::istringstream in2(quoted);
    std::string text;
    in2 >> std::quoted(text);
    
    std::cout << "After std::quoted (first 100 chars):\n";
    for (size_t i = 0; i < std::min((size_t)100, text.size()); i++) {
        char c = text[i];
        if (c == '\n') std::cout << "\\n";
        else if (c == '"') std::cout << "\"";
        else std::cout << c;
    }
    std::cout << "\n\n";
    
    // Now parse
    std::istringstream in3(text);
    try {
        auto result = aggregate(in3);
        std::cout << "Success:\n";
        for (const auto& [k, v] : result) {
            std::cout << "  " << k << ": " << v << "\n";
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
    }
    
    return 0;
}
