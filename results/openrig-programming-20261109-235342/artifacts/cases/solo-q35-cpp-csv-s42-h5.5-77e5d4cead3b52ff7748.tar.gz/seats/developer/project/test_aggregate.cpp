#include "solution.hpp"
#include <sstream>
#include <iostream>
#include <cassert>

void test_basic() {
    std::string input = "category,amount\nA,10\nB,20\nA,5";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A"] == 15);
    assert(result["B"] == 20);
    std::cout << "test_basic passed\n";
}

void test_negative() {
    std::string input = "category,amount\nA,-10\nB,+20\nA,5";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A"] == -5);
    assert(result["B"] == 20);
    std::cout << "test_negative passed\n";
}

void test_quoted_field() {
    std::string input = "category,amount\n\"A,with,commas\",10\nB,20";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A,with,commas"] == 10);
    assert(result["B"] == 20);
    std::cout << "test_quoted_field passed\n";
}

void test_escaped_quote() {
    std::string input = "category,amount\n\"A\"\"quote\",10\nB,20";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A\"quote"] == 10);
    assert(result["B"] == 20);
    std::cout << "test_escaped_quote passed\n";
}

void test_multiline_quoted() {
    std::string input = "category,amount\n\"A\nB\",10\nC,20";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A\nB"] == 10);
    assert(result["C"] == 20);
    std::cout << "test_multiline_quoted passed\n";
}

void test_spaces() {
    std::string input = "category,amount\n  A  ,  10  \nB,20";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A"] == 10);
    assert(result["B"] == 20);
    std::cout << "test_spaces passed\n";
}

void test_empty_record() {
    std::string input = "category,amount\nA,10\n\nB,20";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["A"] == 10);
    assert(result["B"] == 20);
    std::cout << "test_empty_record passed\n";
}

void test_invalid_header() {
    std::string input = "wrong,header\nA,10";
    std::istringstream in(input);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_header passed\n";
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,10\nB,20";
    std::istringstream in(input);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category passed\n";
    }
}

void test_empty_amount() {
    std::string input = "category,amount\nA,\nB,20";
    std::istringstream in(input);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_amount passed\n";
    }
}

void test_invalid_number() {
    std::string input = "category,amount\nA,abc\nB,20";
    std::istringstream in(input);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_number passed\n";
    }
}

void test_overflow() {
    std::string input = "category,amount\nA,999999999999999999999999999999\nB,20";
    std::istringstream in(input);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::overflow_error&) {
        std::cout << "test_overflow passed\n";
    }
}

void test_just_header() {
    std::string input = "category,amount";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.empty());
    std::cout << "test_just_header passed\n";
}

void test_single_entry() {
    std::string input = "category,amount\nA,10";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 1);
    assert(result["A"] == 10);
    std::cout << "test_single_entry passed\n";
}

void test_sorted_keys() {
    std::string input = "category,amount\nZ,10\nA,20\nM,30";
    std::istringstream in(input);
    auto result = aggregate(in);
    auto it = result.begin();
    assert(it->first == "A");
    assert(it->second == 20);
    it++;
    assert(it->first == "M");
    assert(it->second == 30);
    it++;
    assert(it->first == "Z");
    assert(it->second == 10);
    std::cout << "test_sorted_keys passed\n";
}

void test_unicode() {
    std::string input = "category,amount\n日本，39039\n日本，-8138";
    std::istringstream in(input);
    auto result = aggregate(in);
    assert(result.size() == 1);
    assert(result["日本"] == 30901);
    std::cout << "test_unicode passed\n";
}

int main() {
    test_basic();
    test_negative();
    test_quoted_field();
    test_escaped_quote();
    test_multiline_quoted();
    test_spaces();
    test_empty_record();
    test_invalid_header();
    test_empty_category();
    test_empty_amount();
    test_invalid_number();
    test_overflow();
    test_just_header();
    test_single_entry();
    test_sorted_keys();
    test_unicode();
    std::cout << "All tests passed!\n";
    return 0;
}
