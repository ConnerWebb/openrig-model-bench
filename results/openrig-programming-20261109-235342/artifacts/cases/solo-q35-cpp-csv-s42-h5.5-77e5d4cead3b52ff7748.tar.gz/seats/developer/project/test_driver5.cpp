#include <iostream>
#include <sstream>
#include <string>
#include "solution.hpp"

int main() {
    // The actual input from case 0
    std::string input = R"(category,amount
"x""quote",51268
food,4725)";
    
    std::istringstream in(input);
    
    // Read character by character to see what we get
    char c;
    std::string currentRecord;
    bool inQuotes = false;
    int count = 0;
    
    while (in.get(c)) {
        std::cout << "Read '" << c << "' (char " << (int)c << "), inQuotes=" << inQuotes << ", currentRecord=[" << currentRecord << "]\n";
        
        if (c == '"') {
            if (inQuotes) {
                if (in.peek() == '"') {
                    in.get(c);
                    currentRecord += '"';
                    std::cout << "  -> Escaped quote, added one quote\n";
                } else {
                    inQuotes = false;
                    currentRecord += '"';
                    std::cout << "  -> End of quoted section\n";
                }
            } else {
                inQuotes = true;
                currentRecord += '"';
                std::cout << "  -> Start of quoted section\n";
            }
        } else if (c == '\n') {
            if (inQuotes) {
                currentRecord += '\n';
                std::cout << "  -> Newline inside quotes\n";
            } else {
                std::cout << "  -> Flushing record: [" << currentRecord << "]\n";
                currentRecord.clear();
            }
        } else if (c == '\r') {
            std::cout << "  -> Skipping CR\n";
        } else {
            currentRecord += c;
        }
        count++;
        if (count > 50) break;
    }
    
    if (!currentRecord.empty()) {
        std::cout << "Final record: [" << currentRecord << "]\n";
    }
    
    return 0;
}
