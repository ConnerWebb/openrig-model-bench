#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <iomanip>
#include "solution.hpp"

int main() {
    // Read the actual input file
    std::ifstream in("public-inputs/case-00.csv");
    std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    in.close();
    
    std::cout << "File content:\n";
    for (char c : content) {
        if (c == '\n') std::cout << "\\n";
        else if (c == '"') std::cout << "\"";
        else std::cout << c;
    }
    std::cout << "\n\n";
    
    // Wrap in quotes like the driver does (since the file content is the quoted string)
    std::string quoted = "\"" + content + "\"";
    
    std::istringstream in2(quoted);
    std::string text;
    in2 >> std::quoted(text);
    
    std::cout << "After std::quoted:\n";
    for (char c : text) {
        if (c == '\n') std::cout << "\\n";
        else if (c == '"') std::cout << "\"";
        else std::cout << c;
    }
    std::cout << "\n\n";
    
    // Now parse
    std::istringstream in3(text);
    try {
        auto result = aggregate(in3);
        std::cout << "Success:\n";
        for (const auto& [k, v] : result) {
            std::cout << "  " << k << ": " << v << "\n";
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
    }
    
    return 0;
}
