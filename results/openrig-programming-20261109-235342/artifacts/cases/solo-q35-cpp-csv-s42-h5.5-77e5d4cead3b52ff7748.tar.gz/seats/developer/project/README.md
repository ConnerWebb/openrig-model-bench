# CSV Aggregation Solution

## Overview

This is a header-only C++20 solution that parses CSV data and aggregates numeric values by category.

## API

```cpp
std::map<std::string, std::int64_t> aggregate(std::istream& in);
```

Parses CSV input from the given stream and returns a map of category names to aggregated amounts.

## Input Format

The input must be a CSV with the following format:
- Header line: `category,amount`
- Data rows: `<category>,<amount>`

### Field Rules

1. **Header**: Must be exactly `category,amount` (case-sensitive)
2. **Category**: Non-empty string, may contain spaces/tabs which are stripped
3. **Amount**: Signed base10 int64 integer with optional `+` or `-` prefix
4. **Quoted fields**: Fields enclosed in double quotes can contain:
   - Commas
   - Newlines
   - Escaped double quotes (represented as `""`)
5. **Empty records**: Physical records with no fields are ignored
6. **Whitespace**: Leading/trailing spaces and tabs are stripped from fields

### Error Handling

The function throws `std::invalid_argument` for:
- Invalid header format
- Empty category field
- Empty amount field
- Invalid number format (non-digit characters in amount)
- Malformed quoting (unterminated quoted field)

The function throws `std::overflow_error` for:
- Integer overflow during parsing
- Integer overflow during accumulation

## Output

Returns a `std::map<std::string, std::int64_t>` where:
- Keys are category names (sorted alphabetically)
- Values are the sum of all amounts for that category

## Usage Example

```cpp
#include "solution.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::string input = R"("category,amount
Food,100
Transport,50
Food,25
Transport,-10")";
    
    std::istringstream in(input);
    auto result = aggregate(in);
    
    for (const auto& [category, amount] : result) {
        std::cout << category << ": " << amount << "\n";
    }
    
    // Output:
    // Food: 125
    // Transport: 40
}
```

## Testing

Run the tests with:
```bash
clang++ -std=c++20 -o test_aggregate test_aggregate.cpp
./test_aggregate
```

## Implementation Notes

- The solution is header-only and can be included in any C++20 project
- It processes input stream incrementally without loading all data into memory
- Uses standard C++20 features for type safety and error handling
