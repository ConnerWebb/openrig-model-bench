#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>

std::vector<std::string> parseLine(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool inQuotes = false;
    size_t i = 0;
    
    while (i < line.size()) {
        char c = line[i];
        
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < line.size() && line[i + 1] == '"') {
                    field += '"';
                    i += 2;
                } else {
                    inQuotes = false;
                    i++;
                }
            } else {
                field += c;
                i++;
            }
        } else {
            if (c == '"') {
                inQuotes = true;
                i++;
            } else if (c == ',') {
                fields.push_back(field);
                field.clear();
                i++;
            } else {
                field += c;
                i++;
            }
        }
    }
    
    if (inQuotes) {
        throw std::invalid_argument("Unterminated quote");
    }
    
    fields.push_back(field);
    return fields;
}

int main() {
    std::string test1 = "food,100";
    auto f1 = parseLine(test1);
    std::cout << "Test 1: " << f1.size() << " fields\n";
    
    std::string test2 = "\"a,b\",100";
    auto f2 = parseLine(test2);
    std::cout << "Test 2: " << f2.size() << " fields\n";
    
    std::string test3 = "\"two\nlines\",100";
    auto f3 = parseLine(test3);
    std::cout << "Test 3: " << f3.size() << " fields\n";
    
    return 0;
}
