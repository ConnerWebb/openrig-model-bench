#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>

int main() {
    // The input from case 0 (JSON escaped)
    std::string input = "\"category,amount\\n\\\"x\\\"\\\"quote\\\",51268\\nfood,4725\\nrent,69177\\nrent,4517\\nfood,-3853\\n\\\"x\\\"\\\"quote\\\",-22826\\n\\\"x\\\"\\\"quote\\\",-4598\\n\\\"x\\\"\\\"quote\\\",-26830\\n日本，39039\\n\\\"a,b\\\",29914\\nrent,15786\\n日本，-8138\\nfood,15570\\n\\\"x\\\"\\\"quote\\\",-26030\\n\\\"two\\nlines\\\",54977\\n\\\"x\\\"\\\"quote\\\",-5124\\nrent,12112\\n\\\"two\\nlines\\\",28447\\nfood,57027\\nfood,2732\"";
    
    std::cout << "Input (JSON escaped):\n" << input << "\n\n";
    
    // Decode the JSON string
    std::string decoded;
    bool inEscape = false;
    for (size_t i = 0; i < input.size(); i++) {
        char c = input[i];
        if (inEscape) {
            if (c == 'n') decoded += '\n';
            else if (c == 't') decoded += '\t';
            else if (c == 'r') decoded += '\r';
            else if (c == '\\') decoded += '\\';
            else if (c == '"') decoded += '"';
            else decoded += c;
            inEscape = false;
        } else if (c == '\\') {
            inEscape = true;
        } else {
            decoded += c;
        }
    }
    
    std::cout << "Decoded:\n";
    for (char c : decoded) {
        if (c == '\n') std::cout << "\\n";
        else if (c == '"') std::cout << "\"";
        else std::cout << c;
    }
    std::cout << "\n\n";
    
    // Now simulate what the driver does
    std::istringstream in(decoded);
    std::string text;
    in >> std::quoted(text);
    
    std::cout << "After std::quoted:\n";
    for (char c : text) {
        if (c == '\n') std::cout << "\\n";
        else if (c == '"') std::cout << "\"";
        else std::cout << c;
    }
    std::cout << "\n\n";
    
    return 0;
}
