#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>

int main() {
    // Test with escaped quote: "say ""hello""",100
    std::string input = "category,amount\n\"say \"\"hello\"\"\",100";
    std::istringstream iss(input);
    
    std::string currentRecord;
    bool inQuotes = false;
    
    char c;
    while (iss.get(c)) {
        std::cout << "Read char '" << c << "' (char " << (int)c << "), inQuotes=" << inQuotes << ", currentRecord=[" << currentRecord << "]\n";
        
        if (c == '"') {
            if (inQuotes) {
                // Check if this is an escaped quote by looking at the next character
                // We need to peek ahead
                char nextC;
                if (iss.peek() == '"') {
                    iss.get(nextC); // consume the second quote
                    currentRecord += '"'; // add one quote to the field
                    std::cout << "  -> Escaped quote detected\n";
                } else {
                    // End of quoted section
                    inQuotes = false;
                    currentRecord += '"';
                    std::cout << "  -> End of quoted section\n";
                }
            } else {
                // Start of quoted section
                inQuotes = true;
                currentRecord += '"';
                std::cout << "  -> Start of quoted section\n";
            }
        } else if (c == '\n') {
            if (inQuotes) {
                currentRecord += '\n';
            } else {
                std::cout << "  -> Flushing record: [" << currentRecord << "]\n";
                currentRecord.clear();
            }
        } else if (c == '\r') {
            // Skip CR
        } else {
            currentRecord += c;
        }
    }
    
    if (!currentRecord.empty()) {
        std::cout << "  -> Flushing final record: [" << currentRecord << "]\n";
    }
    
    return 0;
}
