#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

class TestAggregate : public std::exception {
public:
    const char* what() const noexcept override {
        return "TestAggregate";
    }
};

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_basic passed\n";
}

void test_negative() {
    std::string input = "category,amount\nfood,-100\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == -100);
    assert(result["rent"] == 200);
    std::cout << "test_negative passed\n";
}

void test_accumulate() {
    std::string input = "category,amount\nfood,100\nfood,50\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == 150);
    assert(result["rent"] == 200);
    std::cout << "test_accumulate passed\n";
}

void test_quoted_field() {
    std::string input = "category,amount\n\"x\"\"quote\",100\nfood,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["x\"quote"] == 100);
    assert(result["food"] == 200);
    std::cout << "test_quoted_field passed\n";
}

void test_quoted_with_comma() {
    std::string input = "category,amount\n\"a,b\",100\nfood,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["food"] == 200);
    std::cout << "test_quoted_with_comma passed\n";
}

void test_quoted_with_newline() {
    std::string input = "category,amount\n\"two\nlines\",100\nfood,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["two\nlines"] == 100);
    assert(result["food"] == 200);
    std::cout << "test_quoted_with_newline passed\n";
}

void test_spaces() {
    std::string input = "category,amount\n  food  ,  100  \n  rent  ,  200  \n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_spaces passed\n";
}

void test_plus_sign() {
    std::string input = "category,amount\nfood,+100\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_plus_sign passed\n";
}

void test_invalid_header() {
    std::string input = "wrong,header\nfood,100\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("Expected exception");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_header passed\n";
        return;
    }
    throw std::runtime_error("Expected exception");
}

void test_empty_category() {
    std::string input = "category,amount\n,100\nfood,200\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("Expected exception");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category passed\n";
        return;
    }
    throw std::runtime_error("Expected exception");
}

void test_empty_amount() {
    std::string input = "category,amount\nfood,\nrent,200\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("Expected exception");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_amount passed\n";
        return;
    }
    throw std::runtime_error("Expected exception");
}

void test_overflow() {
    std::string input = "category,amount\nfood,999999999999999999999\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("Expected exception");
    } catch (const std::overflow_error&) {
        std::cout << "test_overflow passed\n";
        return;
    }
    throw std::runtime_error("Expected exception");
}

void test_unicode() {
    std::string input = "category,amount\n日本，100\nfood,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["日本"] == 100);
    assert(result["food"] == 200);
    std::cout << "test_unicode passed\n";
}

void test_empty_physical_record() {
    std::string input = "category,amount\nfood,100\n\nrent,200\n";
    std::istringstream in(input);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_empty_physical_record passed\n";
}

void test_malformed_quoting() {
    std::string input = "category,amount\n\"unclosed,100\nfood,200\n";
    std::istringstream in(input);
    try {
        aggregate(in);
        throw std::runtime_error("Expected exception");
    } catch (const std::invalid_argument&) {
        std::cout << "test_malformed_quoting passed\n";
        return;
    }
    throw std::runtime_error("Expected exception");
}

int main() {
    test_basic();
    test_negative();
    test_accumulate();
    test_quoted_field();
    test_quoted_with_comma();
    test_quoted_with_newline();
    test_spaces();
    test_plus_sign();
    test_invalid_header();
    test_empty_category();
    test_empty_amount();
    test_overflow();
    test_unicode();
    test_empty_physical_record();
    test_malformed_quoting();
    
    std::cout << "All tests passed!\n";
    return 0;
}
