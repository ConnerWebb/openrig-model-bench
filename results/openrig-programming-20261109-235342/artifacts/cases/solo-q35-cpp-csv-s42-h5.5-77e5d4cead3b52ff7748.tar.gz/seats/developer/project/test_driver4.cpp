#include <iostream>
#include <sstream>
#include <string>
#include "solution.hpp"

int main() {
    // The actual input from case 0
    std::string input = R"(category,amount
"x""quote",51268
food,4725)";
    
    std::istringstream in(input);
    
    // Read character by character to see what we get
    char c;
    std::string currentRecord;
    bool inQuotes = false;
    
    while (in.get(c)) {
        if (c == '"') {
            if (inQuotes) {
                if (in.peek() == '"') {
                    in.get(c);
                    currentRecord += '"';
                } else {
                    inQuotes = false;
                    currentRecord += '"';
                }
            } else {
                inQuotes = true;
                currentRecord += '"';
            }
        } else if (c == '\n') {
            if (inQuotes) {
                currentRecord += '\n';
            } else {
                std::cout << "Record: [" << currentRecord << "]\n";
                currentRecord.clear();
            }
        } else if (c == '\r') {
            // Skip
        } else {
            currentRecord += c;
        }
    }
    
    if (!currentRecord.empty()) {
        std::cout << "Final record: [" << currentRecord << "]\n";
    }
    
    return 0;
}
