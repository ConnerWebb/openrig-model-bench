#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <memory>
#include <algorithm>

class Buffer {
public:
    using value_type = std::uint8_t;
    using size_type = std::size_t;

private:
    std::unique_ptr<std::uint8_t[]> p_;
    size_type n_;

public:
    constexpr Buffer() noexcept : p_(nullptr), n_(0) {}

    explicit Buffer(size_type n) noexcept : p_(nullptr), n_(0) {
        if (n == 0) {
            p_.reset(new std::uint8_t[1]);
            n_ = 0;
        } else {
            p_.reset(new std::uint8_t[n]);
            n_ = n;
            std::fill(p_.get(), p_.get() + n_, 0);
        }
    }

    Buffer(const Buffer& other) noexcept {
        n_ = other.n_;
        if (n_ == 0) {
            p_.reset(new std::uint8_t[1]);
        } else {
            p_.reset(new std::uint8_t[n_]);
            std::copy(other.p_.get(), other.p_.get() + n_, p_.get());
        }
    }

    Buffer(Buffer&& other) noexcept : p_(std::move(other.p_)), n_(other.n_) {
        other.n_ = 0;
        other.p_.reset();
    }

    ~Buffer() noexcept = default;

    Buffer& operator=(const Buffer& other) noexcept {
        if (this != &other) {
            n_ = other.n_;
            if (n_ == 0) {
                p_.reset(new std::uint8_t[1]);
            } else {
                p_.reset(new std::uint8_t[n_]);
                std::copy(other.p_.get(), other.p_.get() + n_, p_.get());
            }
        }
        return *this;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            p_.reset(new std::uint8_t[other.n_]);
            if (other.n_ > 0) {
                std::copy(other.p_.get(), other.p_.get() + other.n_, p_.get());
            }
            n_ = other.n_;
            other.n_ = 0;
            other.p_.reset();
        }
        return *this;
    }

    size_type size() const noexcept { return n_; }

    bool empty() const noexcept { return n_ == 0; }

    value_type& operator[](size_type i) {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    const value_type& operator[](size_type i) const {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    value_type at(size_type i) const {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    value_type& at(size_type i) {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    void resize(size_type n) noexcept {
        if (n < n_) {
            // Shrink: keep prefix, zero-initialize new bytes (which don't exist)
            n_ = n;
        } else {
            // Grow: preserve prefix, zero-initialize new bytes
            std::unique_ptr<std::uint8_t[]> old_p = std::move(p_);
            p_.reset(new std::uint8_t[n]);
            std::copy(old_p.get(), old_p.get() + n_, p_.get());
            std::fill(p_.get() + n_, p_.get() + n, 0);
            n_ = n;
        }
    }

    void clear() noexcept {
        p_.reset(new std::uint8_t[1]);
        n_ = 0;
    }

    bool operator==(const Buffer& other) const noexcept {
        if (n_ != other.n_) return false;
        return std::equal(p_.get(), p_.get() + n_, other.p_.get());
    }

    bool operator!=(const Buffer& other) const noexcept {
        return !(*this == other);
    }
};
