#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

class BufferTest {
public:
    void test_default_constructor() {
        Buffer buf;
        if (buf.size() != 0) {
            std::cerr << "FAIL: default constructor size should be 0" << std::endl;
            exit(1);
        }
        std::cout << "PASS: default constructor" << std::endl;
    }

    void test_size_constructor() {
        Buffer buf(5);
        if (buf.size() != 5) {
            std::cerr << "FAIL: size constructor size should be 5" << std::endl;
            exit(1);
        }
        std::cout << "PASS: size constructor" << std::endl;
    }

    void test_resize_grow() {
        Buffer buf(3);
        buf[0] = 1;
        buf[1] = 2;
        buf[2] = 3;
        buf.resize(5);
        if (buf.size() != 5) {
            std::cerr << "FAIL: resize grow size should be 5" << std::endl;
            exit(1);
        }
        if (buf[0] != 1 || buf[1] != 2 || buf[2] != 3) {
            std::cerr << "FAIL: resize grow should preserve prefix" << std::endl;
            exit(1);
        }
        if (buf[3] != 0 || buf[4] != 0) {
            std::cerr << "FAIL: resize grow should zero-initialize new bytes" << std::endl;
            exit(1);
        }
        std::cout << "PASS: resize grow" << std::endl;
    }

    void test_resize_shrink() {
        Buffer buf(5);
        buf[0] = 1;
        buf[1] = 2;
        buf[2] = 3;
        buf[3] = 4;
        buf[4] = 5;
        buf.resize(3);
        if (buf.size() != 3) {
            std::cerr << "FAIL: resize shrink size should be 3" << std::endl;
            exit(1);
        }
        if (buf[0] != 1 || buf[1] != 2 || buf[2] != 3) {
            std::cerr << "FAIL: resize shrink should preserve prefix" << std::endl;
            exit(1);
        }
        std::cout << "PASS: resize shrink" << std::endl;
    }

    void test_copy_constructor() {
        Buffer buf1(5);
        buf1[0] = 1;
        buf1[1] = 2;
        buf1[2] = 3;
        buf1[3] = 4;
        buf1[4] = 5;
        Buffer buf2(buf1);
        if (buf2.size() != 5) {
            std::cerr << "FAIL: copy constructor size should be 5" << std::endl;
            exit(1);
        }
        for (size_t i = 0; i < 5; i++) {
            if (buf2[i] != buf1[i]) {
                std::cerr << "FAIL: copy constructor should copy content" << std::endl;
                exit(1);
            }
        }
        std::cout << "PASS: copy constructor" << std::endl;
    }

    void test_copy_assignment() {
        Buffer buf1(5);
        buf1[0] = 1;
        buf1[1] = 2;
        Buffer buf2(3);
        buf2 = buf1;
        if (buf2.size() != 5) {
            std::cerr << "FAIL: copy assignment size should be 5" << std::endl;
            exit(1);
        }
        for (size_t i = 0; i < 5; i++) {
            if (buf2[i] != buf1[i]) {
                std::cerr << "FAIL: copy assignment should copy content" << std::endl;
                exit(1);
            }
        }
        std::cout << "PASS: copy assignment" << std::endl;
    }

    void test_move_constructor() {
        Buffer buf1(5);
        buf1[0] = 1;
        buf1[1] = 2;
        buf1[2] = 3;
        buf1[3] = 4;
        buf1[4] = 5;
        Buffer buf2(std::move(buf1));
        if (buf2.size() != 5) {
            std::cerr << "FAIL: move constructor size should be 5" << std::endl;
            exit(1);
        }
        for (size_t i = 0; i < 5; i++) {
            if (buf2[i] != 1 && buf2[i] != 2 && buf2[i] != 3 && buf2[i] != 4 && buf2[i] != 5) {
                std::cerr << "FAIL: move constructor should move content" << std::endl;
                exit(1);
            }
        }
        std::cout << "PASS: move constructor" << std::endl;
    }

    void test_move_assignment() {
        Buffer buf1(5);
        buf1[0] = 1;
        buf1[1] = 2;
        buf1[2] = 3;
        buf1[3] = 4;
        buf1[4] = 5;
        Buffer buf2(3);
        buf2 = std::move(buf1);
        if (buf2.size() != 5) {
            std::cerr << "FAIL: move assignment size should be 5" << std::endl;
            exit(1);
        }
        for (size_t i = 0; i < 5; i++) {
            if (buf2[i] != 1 && buf2[i] != 2 && buf2[i] != 3 && buf2[i] != 4 && buf2[i] != 5) {
                std::cerr << "FAIL: move assignment should move content" << std::endl;
                exit(1);
            }
        }
        std::cout << "PASS: move assignment" << std::endl;
    }

    void test_move_from_is_valid() {
        Buffer buf1(5);
        buf1[0] = 1;
        buf1[1] = 2;
        Buffer buf2(std::move(buf1));
        if (buf2.size() != 5) {
            std::cerr << "FAIL: moved-to buffer should have content" << std::endl;
            exit(1);
        }
        // Moved-from buffer should be valid (size 0)
        if (buf1.size() != 0) {
            std::cerr << "FAIL: moved-from buffer should have size 0" << std::endl;
            exit(1);
        }
        std::cout << "PASS: move from is valid" << std::endl;
    }

    void test_self_copy() {
        Buffer buf(5);
        buf[0] = 1;
        buf = buf;
        if (buf.size() != 5) {
            std::cerr << "FAIL: self copy size should be 5" << std::endl;
            exit(1);
        }
        if (buf[0] != 1) {
            std::cerr << "FAIL: self copy should preserve content" << std::endl;
            exit(1);
        }
        std::cout << "PASS: self copy" << std::endl;
    }

    void test_self_move() {
        Buffer buf(5);
        buf[0] = 1;
        buf = std::move(buf);
        if (buf.size() != 5) {
            std::cerr << "FAIL: self move size should be 5" << std::endl;
            exit(1);
        }
        if (buf[0] != 1) {
            std::cerr << "FAIL: self move should preserve content" << std::endl;
            exit(1);
        }
        std::cout << "PASS: self move" << std::endl;
    }

    void test_bounds_check_read() {
        Buffer buf(3);
        try {
            buf[3];
            std::cerr << "FAIL: should throw out_of_range for read out of bounds" << std::endl;
            exit(1);
        } catch (const std::out_of_range&) {
            std::cout << "PASS: bounds check read" << std::endl;
        }
    }

    void test_bounds_check_write() {
        Buffer buf(3);
        try {
            buf[3] = 1;
            std::cerr << "FAIL: should throw out_of_range for write out of bounds" << std::endl;
            exit(1);
        } catch (const std::out_of_range&) {
            std::cout << "PASS: bounds check write" << std::endl;
        }
    }

    void test_empty() {
        Buffer buf;
        if (!buf.empty()) {
            std::cerr << "FAIL: empty buffer should return true" << std::endl;
            exit(1);
        }
        Buffer buf2(5);
        if (buf2.empty()) {
            std::cerr << "FAIL: non-empty buffer should return false" << std::endl;
            exit(1);
        }
        std::cout << "PASS: empty" << std::endl;
    }

    void test_at_read() {
        Buffer buf(3);
        buf[0] = 1;
        if (buf.at(0) != 1) {
            std::cerr << "FAIL: at read should return correct value" << std::endl;
            exit(1);
        }
        try {
            buf.at(3);
            std::cerr << "FAIL: at read should throw out_of_range" << std::endl;
            exit(1);
        } catch (const std::out_of_range&) {
            std::cout << "PASS: at read bounds check" << std::endl;
        }
    }

    void test_at_write() {
        Buffer buf(3);
        try {
            buf.at(3) = 1;
            std::cerr << "FAIL: at write should throw out_of_range" << std::endl;
            exit(1);
        } catch (const std::out_of_range&) {
            std::cout << "PASS: at write bounds check" << std::endl;
        }
    }

    void test_clear() {
        Buffer buf(5);
        buf[0] = 1;
        buf.clear();
        if (buf.size() != 0) {
            std::cerr << "FAIL: clear should set size to 0" << std::endl;
            exit(1);
        }
        std::cout << "PASS: clear" << std::endl;
    }

    void test_equality() {
        Buffer buf1(5);
        buf1[0] = 1;
        buf1[1] = 2;
        Buffer buf2(5);
        buf2[0] = 1;
        buf2[1] = 2;
        if (!(buf1 == buf2)) {
            std::cerr << "FAIL: equal buffers should compare equal" << std::endl;
            exit(1);
        }
        Buffer buf3(5);
        buf3[0] = 1;
        buf3[1] = 3;
        if (buf1 == buf3) {
            std::cerr << "FAIL: unequal buffers should not compare equal" << std::endl;
            exit(1);
        }
        std::cout << "PASS: equality" << std::endl;
    }

    void test_nothrow_move_constructible() {
        static_assert(std::is_nothrow_move_constructible_v<Buffer>);
        std::cout << "PASS: nothrow move constructible" << std::endl;
    }

    void test_nothrow_move_assignable() {
        static_assert(std::is_nothrow_move_assignable_v<Buffer>);
        std::cout << "PASS: nothrow move assignable" << std::endl;
    }

    void test_resize_noexcept() {
        static_assert(noexcept(Buffer{}.resize(0)));
        std::cout << "PASS: resize is noexcept" << std::endl;
    }

    void run_all_tests() {
        test_default_constructor();
        test_size_constructor();
        test_resize_grow();
        test_resize_shrink();
        test_copy_constructor();
        test_copy_assignment();
        test_move_constructor();
        test_move_assignment();
        test_move_from_is_valid();
        test_self_copy();
        test_self_move();
        test_bounds_check_read();
        test_bounds_check_write();
        test_empty();
        test_at_read();
        test_at_write();
        test_clear();
        test_equality();
        test_nothrow_move_constructible();
        test_nothrow_move_assignable();
        test_resize_noexcept();
        std::cout << "\nAll tests passed!" << std::endl;
    }
};

int main() {
    BufferTest test;
    test.run_all_tests();
    return 0;
}
