# Buffer Library

A C++20 RAII-based buffer implementation with bounds-checked access.

## Features

- **RAII Design**: Uses `std::unique_ptr` for automatic memory management, preventing leaks and double-frees.
- **Bounds-checked Access**: `operator[]` throws `std::out_of_range` on invalid indices.
- **Resize**: Preserves prefix content and zero-initializes new bytes.
- **Deep Copy**: Construction and assignment perform deep copies of data.
- **Noexcept Moves**: Move operations are noexcept and leave moved-from objects in valid state (size 0, reusable).
- **Self-Copy/Self-Move**: Assignment/move from self is safe and preserves content.

## Usage

```cpp
#include "solution.hpp"

Buffer buf(10);           // Create buffer of size 10 (zero-initialized)
buf[0] = 42;              // Bounds-checked access
buf.resize(20);           // Grow buffer, new bytes zero-initialized
buf = Buffer{5, {1,2,3,4,5}};  // Assignment with copy
auto moved = std::move(buf);  // Move semantics
```

## API

### Constructors
- `Buffer()` - Default constructor (size 0)
- `Buffer(size_t n)` - Construct with size n, zero-initialized

### Destructor
- `~Buffer()` - RAII cleanup via unique_ptr

### Copy Operations
- `Buffer(const Buffer&)` - Deep copy constructor
- `Buffer& operator=(const Buffer&)` - Deep copy assignment

### Move Operations
- `Buffer(Buffer&&)` - Move constructor (noexcept)
- `Buffer& operator=(Buffer&&)` - Move assignment (noexcept)

### Access
- `size_type size() const noexcept` - Return size
- `value_type& operator[](size_type)` - Mutable bounds-checked access
- `const value_type& operator[](size_type) const` - Const bounds-checked access
- `value_type at(size_type)` - Alternative with throws on out of range

### Resize
- `void resize(size_type n) noexcept` - Resize buffer, preserving prefix and zero-initializing new bytes

### Clear
- `void clear() noexcept` - Reset to size 0

### Comparison
- `bool operator==(const Buffer&) const` - Equality comparison
- `bool operator!=(const Buffer&) const` - Inequality comparison

## Implementation Notes

- Memory is managed via `std::unique_ptr<std::uint8_t[]>`
- All new allocations are zero-initialized
- Move operations leave the source in a valid but unspecified state (size 0)
- Self-assignment and self-move are handled correctly
- No undefined behavior, no leaks, no double-frees
