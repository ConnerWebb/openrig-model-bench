"""HTTP page fetching with pagination support."""

import json
import os
import socket
import ssl
import urllib.parse
import urllib.request
import urllib.error


def _is_http_url(url):
    """Check if URL uses HTTP or HTTPS scheme."""
    parsed = urllib.parse.urlparse(url)
    return parsed.scheme in ('http', 'https')


def _is_same_origin(url1, url2):
    """Check if two URLs have the same origin (scheme + host + port)."""
    parsed1 = urllib.parse.urlparse(url1)
    parsed2 = urllib.parse.urlparse(url2)
    
    # Normalize ports
    port1 = parsed1.port
    if port1 is None:
        port1 = 443 if parsed1.scheme == 'https' else 80
    
    port2 = parsed2.port
    if port2 is None:
        port2 = 443 if parsed2.scheme == 'https' else 80
    
    return (parsed1.scheme == parsed2.scheme and
            parsed1.hostname == parsed2.hostname and
            port1 == port2)


def _resolve_relative_url(base_url, relative_url):
    """Resolve a relative URL against a base URL."""
    return urllib.parse.urljoin(base_url, relative_url)


def _fetch_page(url, timeout):
    """Fetch a single page and return (items, next_url)."""
    try:
        req = urllib.request.Request(url, method='GET')
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = response.read().decode('utf-8')
            data = json.loads(body)
            
            # Validate schema
            if not isinstance(data, dict):
                raise ValueError("JSON must be an object")
            if 'items' not in data:
                raise ValueError("Missing 'items' field")
            if 'next' not in data:
                raise ValueError("Missing 'next' field")
            
            items = data['items']
            if not isinstance(items, list):
                raise ValueError("'items' must be a list")
            
            # Validate each item is an integer (not bool)
            for item in items:
                if isinstance(item, bool) or not isinstance(item, int):
                    raise ValueError("'items' must contain only integers")
            
            next_url = data['next']
            if next_url is not None and not isinstance(next_url, str):
                raise ValueError("'next' must be a string or null")
            
            return items, next_url
            
    except json.JSONDecodeError:
        raise ValueError("Invalid JSON")
    except urllib.error.HTTPError as e:
        raise ValueError(f"HTTP error: {e.code}")
    except urllib.error.URLError as e:
        raise ValueError(f"URL error: {e.reason}")
    except socket.timeout:
        raise ValueError("Request timed out")
    except Exception as e:
        raise ValueError(f"Request failed: {e}")


def fetch_pages(url, retries=2, timeout=1.0):
    """
    Fetch JSON pages over HTTP using Python stdlib.
    
    Each page is an object with 'items' (list of integers) and 'next' 
    (same-origin absolute URL, relative URL, or null).
    
    Args:
        url: Initial HTTP/HTTPS URL to fetch
        retries: Number of retry attempts for transient errors (default 2)
        timeout: Request timeout in seconds (default 1.0)
    
    Returns:
        List of all items from all pages in order
    
    Raises:
        ValueError: For invalid URLs, cross-origin, invalid JSON/schema,
                   or after exhausting retries on transient errors
    """
    # Validate parameters
    if not isinstance(retries, int) or retries < 0:
        raise ValueError("retries must be a non-negative integer")
    if not isinstance(timeout, (int, float)) or timeout <= 0:
        raise ValueError("timeout must be a positive number")
    
    # Validate initial URL is HTTP
    if not _is_http_url(url):
        raise ValueError("Initial URL must use HTTP or HTTPS scheme")
    
    all_items = []
    visited_urls = set()
    current_url = url
    
    while current_url is not None:
        # Check for repeated URLs
        if current_url in visited_urls:
            raise ValueError(f"Repeated page URL: {current_url}")
        visited_urls.add(current_url)
        
        # Fetch with retries for transient errors
        last_error = None
        for attempt in range(retries + 1):
            try:
                items, next_url = _fetch_page(current_url, timeout)
                all_items.extend(items)
                
                # Resolve relative URLs
                if next_url is not None:
                    if urllib.parse.urlparse(next_url).scheme == '' and not next_url.startswith('//'):
                        next_url = _resolve_relative_url(current_url, next_url)
                    
                    # Validate same origin
                    if not _is_same_origin(current_url, next_url):
                        raise ValueError(f"Cross-origin redirect: {next_url}")
                
                current_url = next_url
                break
                
            except ValueError as e:
                error_str = str(e)
                # Check if this is a transient error (429, 500, 502, 503, 504)
                is_transient = False
                if 'HTTP error:' in error_str:
                    code = int(error_str.split(':')[1].strip())
                    is_transient = code in (429, 500, 502, 503, 504)
                
                if is_transient and attempt < retries:
                    last_error = e
                    continue
                else:
                    raise
        
        if current_url is not None and current_url in visited_urls:
            raise ValueError(f"Repeated page URL: {current_url}")
    
    return all_items
