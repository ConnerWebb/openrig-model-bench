# HTTP Page Fetcher

A Python library for fetching paginated JSON data over HTTP using only the Python standard library.

## Installation

No external dependencies required. Uses Python 3.14 stdlib only.

## Usage

```python
from solution import fetch_pages

# Basic usage
items = fetch_pages('https://api.example.com/pages')

# With custom retries and timeout
items = fetch_pages('https://api.example.com/pages', retries=3, timeout=2.0)
```

## API

### `fetch_pages(url, retries=2, timeout=1.0) -> list`

Fetch JSON pages over HTTP and return all items in order.

**Parameters:**
- `url`: Initial HTTP/HTTPS URL to fetch
- `retries`: Number of retry attempts for transient errors (429, 500, 502, 503, 504). Default: 2
- `timeout`: Request timeout in seconds. Default: 1.0

**Returns:**
- List of all items from all pages in order

**Raises:**
- `ValueError`: For invalid URLs, cross-origin redirects, invalid JSON/schema, or after exhausting retries

## Response Format

Each page should be a JSON object with:
- `items`: List of integers
- `next`: Same-origin absolute URL, relative URL, or null

## Error Handling

- Non-HTTP initial URLs raise `ValueError`
- Cross-origin redirects raise `ValueError`
- Repeated page URLs raise `ValueError`
- Invalid JSON raises `ValueError`
- Missing required fields (`items`, `next`) raise `ValueError`
- Invalid schema (wrong types) raises `ValueError`
- Transient errors (429, 500, 502, 503, 504) are retried up to `retries` times
- Other HTTP/network failures raise `ValueError`

## Running Tests

```bash
python -m unittest test_solution
```
