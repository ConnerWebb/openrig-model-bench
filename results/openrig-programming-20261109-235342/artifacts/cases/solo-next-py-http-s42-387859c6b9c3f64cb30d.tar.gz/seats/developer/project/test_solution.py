"""Tests for solution.py fetch_pages function."""

import json
import socket
import threading
import unittest
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse

from solution import fetch_pages


class MockHTTPHandler(BaseHTTPRequestHandler):
    """HTTP handler for testing with configurable responses."""
    
    def __init__(self, routes, *args, **kwargs):
        self.routes = routes
        super().__init__(*args, **kwargs)
    
    def log_message(self, format, *args):
        pass  # Suppress logging
    
    def do_GET(self):
        path = self.path
        if path not in self.routes:
            self.send_response(404)
            self.end_headers()
            return
        
        route = self.routes[path]
        statuses = route.get('statuses', [200])
        body = route.get('body', {})
        
        if statuses:
            status = statuses.pop(0)
        else:
            status = 200
        
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(body).encode('utf-8'))


class TestFetchPages(unittest.TestCase):
    """Test cases for fetch_pages function."""
    
    def setUp(self):
        self.server = None
        self.thread = None
        self.base_url = None
    
    def tearDown(self):
        if self.server:
            self.server.shutdown()
        if self.thread:
            self.thread.join(timeout=1)
    
    def start_server(self, routes):
        """Start a test HTTP server with given routes."""
        handler = lambda *args: MockHTTPHandler(routes, *args)
        self.server = HTTPServer(('127.0.0.1', 0), handler)
        self.port = self.server.server_address[1]
        self.base_url = f'http://127.0.0.1:{self.port}'
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.daemon = True
        self.thread.start()
    
    def test_basic_pagination(self):
        """Test basic pagination with two pages."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [-18, 30, 58, -98, -33],
                    'next': '/b'
                }
            },
            '/b': {
                'body': {
                    'items': [-61, 93, -49],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        result = fetch_pages(f'{self.base_url}/a')
        expected = [-18, 30, 58, -98, -33, -61, 93, -49]
        self.assertEqual(result, expected)
    
    def test_retry_on_503(self):
        """Test retry on 503 status code."""
        routes = {
            '/a': {
                'statuses': [503, 200],
                'body': {
                    'items': [-33, -78, -49, 31, -86],
                    'next': '/b'
                }
            },
            '/b': {
                'body': {
                    'items': [52, -51, 29],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        result = fetch_pages(f'{self.base_url}/a', retries=2)
        expected = [-33, -78, -49, 31, -86, 52, -51, 29]
        self.assertEqual(result, expected)
    
    def test_retry_exhausted_raises_valueerror(self):
        """Test that exhausted retries raise ValueError."""
        routes = {
            '/a': {
                'statuses': [503, 503, 503, 503],
                'body': {
                    'items': [1, 2, 3],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a', retries=2)
    
    def test_invalid_initial_url(self):
        """Test that non-HTTP initial URL raises ValueError."""
        with self.assertRaises(ValueError):
            fetch_pages('ftp://example.com')
    
    def test_relative_url_resolution(self):
        """Test relative URL resolution."""
        routes = {
            '/api/v1/page1': {
                'statuses': [200],
                'body': {
                    'items': [1, 2, 3],
                    'next': '/api/v1/page2'
                }
            },
            '/api/v1/page2': {
                'body': {
                    'items': [4, 5, 6],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        result = fetch_pages(f'{self.base_url}/api/v1/page1')
        expected = [1, 2, 3, 4, 5, 6]
        self.assertEqual(result, expected)
    
    def test_cross_origin_rejected(self):
        """Test that cross-origin URLs are rejected."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [1, 2, 3],
                    'next': 'http://other-host.com/b'
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_repeated_url_raises_valueerror(self):
        """Test that repeated URLs raise ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [1, 2, 3],
                    'next': '/a'
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_invalid_json_raises_valueerror(self):
        """Test that invalid JSON raises ValueError."""
        class InvalidJSONHandler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass
            
            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(b'not valid json')
        
        handler = lambda *args: InvalidJSONHandler(*args)
        self.server = HTTPServer(('127.0.0.1', 0), handler)
        self.port = self.server.server_address[1]
        self.base_url = f'http://127.0.0.1:{self.port}'
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.daemon = True
        self.thread.start()
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_missing_items_field(self):
        """Test that missing items field raises ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_missing_next_field(self):
        """Test that missing next field raises ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [1, 2, 3]
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_items_not_list(self):
        """Test that items not being a list raises ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': 123,
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_items_contains_bool(self):
        """Test that items containing bool raises ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [True, False],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_negative_retries_raises_valueerror(self):
        """Test that negative retries raises ValueError."""
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a', retries=-1)
    
    def test_zero_timeout_raises_valueerror(self):
        """Test that zero timeout raises ValueError."""
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a', timeout=0)
    
    def test_negative_timeout_raises_valueerror(self):
        """Test that negative timeout raises ValueError."""
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a', timeout=-1.0)
    
    def test_empty_items_list(self):
        """Test that empty items list is valid."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [],
                    'next': '/b'
                }
            },
            '/b': {
                'body': {
                    'items': [1, 2, 3],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        result = fetch_pages(f'{self.base_url}/a')
        expected = [1, 2, 3]
        self.assertEqual(result, expected)
    
    def test_single_page_no_next(self):
        """Test single page with no next URL."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [1, 2, 3],
                    'next': None
                }
            }
        }
        self.start_server(routes)
        
        result = fetch_pages(f'{self.base_url}/a')
        expected = [1, 2, 3]
        self.assertEqual(result, expected)
    
    def test_json_not_object(self):
        """Test that JSON not being an object raises ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': [1, 2, 3]
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')
    
    def test_next_not_string_or_null(self):
        """Test that next not being string or null raises ValueError."""
        routes = {
            '/a': {
                'statuses': [200],
                'body': {
                    'items': [1, 2, 3],
                    'next': 123
                }
            }
        }
        self.start_server(routes)
        
        with self.assertRaises(ValueError):
            fetch_pages(f'{self.base_url}/a')


if __name__ == '__main__':
    unittest.main()
