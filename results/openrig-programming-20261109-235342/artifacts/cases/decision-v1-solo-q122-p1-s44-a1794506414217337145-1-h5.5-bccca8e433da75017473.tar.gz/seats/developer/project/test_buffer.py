import unittest
import subprocess
import json
import sys

class TestBuffer(unittest.TestCase):
    def run_cpp_test(self, input_data):
        """Run the C++ driver with given input and return parsed JSON output."""
        result = subprocess.run(
            ['./driver'],
            input=input_data,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return {"error": "RuntimeError"}
        try:
            return json.loads(result.stdout.strip())
        except json.JSONDecodeError:
            return {"error": "ParseError"}

    def test_case_00(self):
        """Test case from public-inputs/case-00.json"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        result = self.run_cpp_test(input_data)
        self.assertNotIn("error", result)
        self.assertEqual(result["moved_size"], 0)
        self.assertTrue(result["bounds"])
        # Check copy has first element XORed with 255
        self.assertEqual(result["copy"][0], 4 ^ 255)  # 251
        self.assertEqual(len(result["copy"]), 20)
        # Check value has original data + zeros for resize
        self.assertEqual(result["value"][:20], [4, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97])
        self.assertEqual(len(result["value"]), 65)

    def test_case_01(self):
        """Test case from public-inputs/case-01.json"""
        input_data = "9 41 223 228 49 10 127 75 79 126 181"
        result = self.run_cpp_test(input_data)
        self.assertNotIn("error", result)
        self.assertEqual(result["moved_size"], 0)
        self.assertTrue(result["bounds"])
        self.assertEqual(result["copy"][0], 223 ^ 255)  # 32
        self.assertEqual(len(result["copy"]), 9)
        self.assertEqual(len(result["value"]), 41)

    def test_case_02(self):
        """Test case from public-inputs/case-02.json"""
        input_data = "19 74 8 128 179 106 201 14 35 49 127 50 151 71 212 244 252 183 151 48 104"
        result = self.run_cpp_test(input_data)
        self.assertNotIn("error", result)
        self.assertEqual(result["moved_size"], 0)
        self.assertTrue(result["bounds"])
        self.assertEqual(result["copy"][0], 8 ^ 255)  # 247
        self.assertEqual(len(result["copy"]), 19)
        self.assertEqual(len(result["value"]), 74)

    def test_case_03(self):
        """Test case from public-inputs/case-03.json"""
        input_data = "19 79 110 82 225 243 164 133 48 132 12 17 96 113 241 166 157 124 138 72 27"
        result = self.run_cpp_test(input_data)
        self.assertNotIn("error", result)
        self.assertEqual(result["moved_size"], 0)
        self.assertTrue(result["bounds"])
        self.assertEqual(result["copy"][0], 110 ^ 255)  # 145
        self.assertEqual(len(result["copy"]), 19)
        self.assertEqual(len(result["value"]), 79)

    def test_empty_buffer(self):
        """Test empty buffer construction and operations."""
        input_data = "0 5"
        result = self.run_cpp_test(input_data)
        self.assertNotIn("error", result)
        self.assertEqual(result["value"], [0, 0, 0, 0, 0])
        self.assertEqual(result["moved_size"], 0)
        self.assertEqual(result["copy"], [])

    def test_move_from_empty(self):
        """Test moving from empty buffer."""
        input_data = "0 0"
        result = self.run_cpp_test(input_data)
        self.assertNotIn("error", result)
        self.assertEqual(result["moved_size"], 0)

if __name__ == '__main__':
    unittest.main()
