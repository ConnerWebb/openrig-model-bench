# Buffer Library

A C++20 buffer implementation with deep-copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep-copy construction/assignment**: Each copy owns its own memory
- **Noexcept move operations**: Efficient transfers with moved-from buffers having size 0
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Safe resize**: Preserves existing data, zero-initializes new elements
- **RAII**: Automatic resource management, no leaks or double frees

## API

```cpp
class Buffer {
    Buffer(std::size_t n = 0);                    // Construct with n zero-initialized bytes
    ~Buffer();                                    // Destructor

    Buffer(const Buffer& other);                  // Deep copy constructor
    Buffer& operator=(const Buffer& other);       // Deep copy assignment

    Buffer(Buffer&& other) noexcept;              // Move constructor (noexcept)
    Buffer& operator=(Buffer&& other) noexcept;   // Move assignment (noexcept)

    std::size_t size() const noexcept;            // Return buffer size

    std::uint8_t& operator[](std::size_t i);      // Mutable access with bounds check
    const std::uint8_t& operator[](std::size_t i) const;  // Const access with bounds check

    void resize(std::size_t k);                   // Resize, preserving prefix
};
```

## Behavior Details

- **Moved-from buffers**: Have size 0 and can be reused (assigned to or resized)
- **Self-copy/self-move**: Preserve content correctly
- **Bounds checking**: Accessing index >= size throws `std::out_of_range`
- **Resize**: If growing, new bytes are zero-initialized; if shrinking, prefix is preserved

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -O2 -o driver PUBLIC_DRIVER.cpp
```

## Testing

Run the test suite:
```bash
python3 test_buffer.py
```

Or use the framework's `run_tests` command.

## Requirements

- C++20 compiler (Clang 22 tested)
- Python 3.14+ for tests (stdlib only, no pytest)
