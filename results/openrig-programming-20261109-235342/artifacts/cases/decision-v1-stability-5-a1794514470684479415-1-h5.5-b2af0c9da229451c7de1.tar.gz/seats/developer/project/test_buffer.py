import unittest
import subprocess
import json
import sys

class TestBuffer(unittest.TestCase):
    def run_cpp_driver(self, input_data):
        """Run the C++ driver with given input and return parsed JSON output."""
        result = subprocess.run(
            ['g++', '-std=c++20', '-o', '/tmp/buffer_test', 'PUBLIC_DRIVER.cpp'],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            self.fail(f"Compilation failed: {result.stderr}")
        
        proc = subprocess.run(
            ['/tmp/buffer_test'],
            input=input_data,
            capture_output=True, text=True
        )
        if proc.returncode != 0:
            self.fail(f"Runtime error: {proc.stderr}")
        
        return json.loads(proc.stdout.strip())

    def test_case_00(self):
        """Test case from public-inputs/case-00.json"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        result = self.run_cpp_driver(input_data)
        
        self.assertIn("value", result)
        self.assertIn("moved_size", result)
        self.assertIn("copy", result)
        self.assertIn("bounds", result)
        
        # Check bounds exception is thrown
        self.assertTrue(result["bounds"])
        
        # Check moved_size is 0 (moved-from buffer has size 0)
        self.assertEqual(result["moved_size"], 0)
        
        # Check copy has the modified first byte (255 ^ 4 = 251)
        self.assertEqual(result["copy"][0], 251)
        self.assertEqual(len(result["copy"]), 20)

    def test_case_01(self):
        """Test case from public-inputs/case-01.json"""
        input_data = "9 41 223 228 49 10 127 75 79 126 181"
        result = self.run_cpp_driver(input_data)
        
        self.assertIn("value", result)
        self.assertIn("moved_size", result)
        self.assertIn("copy", result)
        self.assertIn("bounds", result)
        
        # Check bounds exception is thrown
        self.assertTrue(result["bounds"])
        
        # Check moved_size is 0
        self.assertEqual(result["moved_size"], 0)
        
        # Check copy has the modified first byte (255 ^ 223 = 32)
        self.assertEqual(result["copy"][0], 32)
        self.assertEqual(len(result["copy"]), 9)

    def test_case_02(self):
        """Test case from public-inputs/case-02.json"""
        input_data = "19 74 8 128 179 106 201 14 35 49 127 50 151 71 212 244 252 183 151 48 104"
        result = self.run_cpp_driver(input_data)
        
        self.assertIn("value", result)
        self.assertIn("moved_size", result)
        self.assertIn("copy", result)
        self.assertIn("bounds", result)
        
        # Check bounds exception is thrown
        self.assertTrue(result["bounds"])
        
        # Check moved_size is 0
        self.assertEqual(result["moved_size"], 0)
        
        # Check copy has the modified first byte (255 ^ 8 = 247)
        self.assertEqual(result["copy"][0], 247)
        self.assertEqual(len(result["copy"]), 19)

    def test_case_03(self):
        """Test case from public-inputs/case-03.json"""
        input_data = "19 79 110 82 225 243 164 133 48 132 12 17 96 113 241 166 157 124 138 72 27"
        result = self.run_cpp_driver(input_data)
        
        self.assertIn("value", result)
        self.assertIn("moved_size", result)
        self.assertIn("copy", result)
        self.assertIn("bounds", result)
        
        # Check bounds exception is thrown
        self.assertTrue(result["bounds"])
        
        # Check moved_size is 0
        self.assertEqual(result["moved_size"], 0)
        
        # Check copy has the modified first byte (255 ^ 110 = 145)
        self.assertEqual(result["copy"][0], 145)
        self.assertEqual(len(result["copy"]), 19)

    def test_empty_buffer(self):
        """Test empty buffer construction and operations."""
        input_data = "0 10"
        result = self.run_cpp_driver(input_data)
        
        # Initial size 0, then resize to 10, so value has 10 zeros
        self.assertEqual(result["value"], [0] * 10)
        self.assertEqual(result["moved_size"], 0)
        self.assertEqual(result["copy"], [])
        self.assertTrue(result["bounds"])

    def test_resize_preserves_prefix(self):
        """Test that resize preserves existing data."""
        # This is tested implicitly through the driver which resizes
        input_data = "5 10 1 2 3 4 5 6 7 8 9 10"
        result = self.run_cpp_driver(input_data)
        
        # First 5 values should be preserved
        self.assertEqual(result["value"][:5], [1, 2, 3, 4, 5])
        # New values should be zero
        self.assertEqual(result["value"][5:], [0, 0, 0, 0, 0])

if __name__ == '__main__':
    unittest.main()
