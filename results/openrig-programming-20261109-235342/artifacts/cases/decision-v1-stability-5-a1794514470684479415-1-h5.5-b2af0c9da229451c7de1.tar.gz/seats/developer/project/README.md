# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep Copy**: Copy construction and assignment perform deep copies of buffer contents
- **Noexcept Move**: Move construction and assignment are noexcept and leave the source in a valid, empty state
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for out-of-bounds access
- **Resize**: Preserves existing data and zero-initializes new elements
- **RAII**: Automatic resource management with proper destructor

## API

```cpp
class Buffer {
public:
    // Constructor: creates buffer of size n (zero-initialized)
    Buffer(std::size_t n = 0);
    
    // Destructor
    ~Buffer();
    
    // Copy constructor (deep copy)
    Buffer(const Buffer& other);
    
    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other);
    
    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept;
    
    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept;
    
    // Size accessor
    std::size_t size() const noexcept;
    
    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i);
    
    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const;
    
    // Resize: preserves prefix, zero-initializes new elements
    void resize(std::size_t k);
};
```

## Usage

```cpp
#include "solution.hpp"

// Create buffer
Buffer buf(10);

// Access elements (throws if out of bounds)
buf[0] = 42;

// Copy (deep copy)
Buffer copy = buf;

// Move (noexcept, source becomes empty)
Buffer moved = std::move(buf);

// Resize
buf.resize(20);  // Preserves first 10 elements, adds 10 zeros
```

## Testing

Run tests with:
```bash
python3 test_buffer.py
```

Or use the provided test runner:
```bash
run_tests
```

## Build Requirements

- C++20 compiler (tested with Clang 22)
- Python 3.14+ for tests
