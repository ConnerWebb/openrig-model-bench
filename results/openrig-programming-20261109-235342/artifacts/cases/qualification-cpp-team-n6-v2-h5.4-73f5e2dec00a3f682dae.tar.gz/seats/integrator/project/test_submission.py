import unittest
import tempfile
import pathlib
import subprocess
import json
import os


class TestAnalyticsToolkit(unittest.TestCase):
    """Test the C++ analytics toolkit via CLI driver."""

    def _compile_driver(self, tmpdir):
        """Compile a driver that exercises all three modules."""
        driver_code = r'''
#include "solution.hpp"
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <iomanip>

int main(int argc, char** argv) {
    if (argc < 2) return 1;
    std::string mode = argv[1];
    
    if (mode == "aggregate") {
        if (argc < 3) return 1;
        std::ifstream f(argv[2]);
        auto result = aggregate(f);
        std::cout << "{";
        bool first = true;
        for (const auto& kv : result) {
            if (!first) std::cout << ",";
            std::cout << "\"" << kv.first << "\":" << kv.second;
            first = false;
        }
        std::cout << "}" << std::endl;
        return 0;
    }
    
    if (mode == "cache") {
        LruCache cache(2);
        cache.put(1, "one");
        cache.put(2, "two");
        std::string out;
        bool got1 = cache.get(1, out);
        bool got2 = cache.get(2, out);
        bool got3 = cache.get(3, out);
        std::cout << "get1:" << got1 << ",get2:" << got2 << ",get3:" << got3 << std::endl;
        auto snap = cache.snapshot();
        std::cout << "snap:";
        for (const auto& p : snap) {
            std::cout << p.first << ":" << p.second << ",";
        }
        std::cout << std::endl;
        return 0;
    }
    
    if (mode == "stats") {
        RunningStats stats;
        stats.add(10.0);
        stats.add(20.0);
        stats.add(30.0);
        std::cout << "count:" << stats.count() << std::endl;
        std::cout << "mean:" << std::fixed << std::setprecision(6) << stats.mean() << std::endl;
        std::cout << "var:" << std::fixed << std::setprecision(6) << stats.variance() << std::endl;
        std::cout << "min:" << std::fixed << std::setprecision(6) << stats.minimum() << std::endl;
        std::cout << "max:" << std::fixed << std::setprecision(6) << stats.maximum() << std::endl;
        return 0;
    }
    
    return 1;
}
'''
        driver_path = tmpdir / "driver.cpp"
        driver_path.write_text(driver_code)
        exe_path = tmpdir / "driver"
        result = subprocess.run(
            ["clang++", "-fuse-ld=bfd", "-std=c++20", "-I/work", str(driver_path), "-o", str(exe_path)],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise RuntimeError(f"Compilation failed: {result.stderr}")
        return exe_path

    def test_aggregate_basic(self):
        """Test basic aggregation."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            # Create a simple CSV
            csv_path = tmpdir / "test.csv"
            csv_path.write_text("category,amount\nfood,100\nrent,200\n")
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertEqual(result.returncode, 0)
            self.assertIn('"food":100', result.stdout)
            self.assertIn('"rent":200', result.stdout)

    def test_aggregate_quoted_fields(self):
        """Test CSV with quoted fields containing commas and newlines."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            # Create CSV with quoted fields
            csv_path = tmpdir / "test.csv"
            csv_path.write_text('category,amount\n"a,b",50\n"two\nlines",100\n')
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertEqual(result.returncode, 0)
            self.assertIn('"a,b":50', result.stdout)
            self.assertIn('"two', result.stdout)  # newline in key

    def test_aggregate_negative_values(self):
        """Test aggregation with negative values."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            csv_path = tmpdir / "test.csv"
            csv_path.write_text("category,amount\nfood,100\nfood,-50\n")
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertEqual(result.returncode, 0)
            self.assertIn('"food":50', result.stdout)

    def test_aggregate_overflow(self):
        """Test that overflow raises an error."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            csv_path = tmpdir / "test.csv"
            # This should overflow: 9223372036854775807 + 1
            csv_path.write_text("category,amount\nx,9223372036854775807\nx,1\n")
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertNotEqual(result.returncode, 0)

    def test_aggregate_invalid_header(self):
        """Test rejection of wrong header."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            csv_path = tmpdir / "test.csv"
            csv_path.write_text("wrong,amount\nx,1\n")
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertNotEqual(result.returncode, 0)

    def test_aggregate_nan(self):
        """Test rejection of NaN in amount."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            csv_path = tmpdir / "test.csv"
            csv_path.write_text("category,amount\nx,NaN\n")
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertNotEqual(result.returncode, 0)

    def test_aggregate_exponent(self):
        """Test rejection of exponent notation."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            csv_path = tmpdir / "test.csv"
            csv_path.write_text("category,amount\nx,1e2\n")
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertNotEqual(result.returncode, 0)

    def test_aggregate_malformed_quote(self):
        """Test rejection of malformed quoting."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            csv_path = tmpdir / "test.csv"
            csv_path.write_text('category,amount\n"x,1\n')
            
            result = subprocess.run(
                [str(exe), "aggregate", str(csv_path)],
                capture_output=True,
                text=True
            )
            self.assertNotEqual(result.returncode, 0)

    def test_cache_basic(self):
        """Test basic LRU cache operations."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            result = subprocess.run(
                [str(exe), "cache"],
                capture_output=True,
                text=True
            )
            self.assertEqual(result.returncode, 0)
            self.assertIn("get1:1", result.stdout)  # key 1 should be found
            self.assertIn("get2:1", result.stdout)  # key 2 should be found
            self.assertIn("get3:0", result.stdout)  # key 3 should not be found

    def test_cache_eviction(self):
        """Test LRU cache eviction policy."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            # Create a test that exercises eviction
            test_code = r'''
#include "solution.hpp"
#include <iostream>

int main() {
    LruCache cache(2);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");  // should evict key 1
    std::string out;
    bool got1 = cache.get(1, out);  // should fail
    bool got2 = cache.get(2, out);  // should succeed
    bool got3 = cache.get(3, out);  // should succeed
    std::cout << "evict1:" << got1 << ",evict2:" << got2 << ",evict3:" << got3 << std::endl;
    return 0;
}
'''
            driver_path = tmpdir / "evict_test.cpp"
            driver_path.write_text(test_code)
            exe_path = tmpdir / "evict_test"
            subprocess.run(
                ["clang++", "-fuse-ld=bfd", "-std=c++20", "-I/work", str(driver_path), "-o", str(exe_path)],
                capture_output=True,
                check=True
            )
            
            result = subprocess.run([str(exe_path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)
            self.assertIn("evict1:0", result.stdout)  # key 1 evicted
            self.assertIn("evict2:1", result.stdout)  # key 2 still there
            self.assertIn("evict3:1", result.stdout)  # key 3 there

    def test_stats_basic(self):
        """Test basic RunningStats operations."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            result = subprocess.run(
                [str(exe), "stats"],
                capture_output=True,
                text=True
            )
            self.assertEqual(result.returncode, 0)
            self.assertIn("count:3", result.stdout)
            self.assertIn("mean:20.000000", result.stdout)  # (10+20+30)/3 = 20

    def test_stats_empty(self):
        """Test that empty stats throw domain_error."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            
            test_code = r'''
#include "solution.hpp"
#include <iostream>

int main() {
    RunningStats stats;
    try {
        stats.mean();
        return 1;  // should not reach here
    } catch (const std::domain_error&) {
        return 0;
    }
}
'''
            driver_path = tmpdir / "empty_test.cpp"
            driver_path.write_text(test_code)
            exe_path = tmpdir / "empty_test"
            subprocess.run(
                ["clang++", "-fuse-ld=bfd", "-std=c++20", "-I/work", str(driver_path), "-o", str(exe_path)],
                capture_output=True,
                check=True
            )
            
            result = subprocess.run([str(exe_path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)

    def test_stats_nan_rejection(self):
        """Test that NaN is rejected."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            
            test_code = r'''
#include "solution.hpp"
#include <iostream>

int main() {
    RunningStats stats;
    try {
        stats.add(NAN);
        return 1;  // should not reach here
    } catch (const std::invalid_argument&) {
        return 0;
    }
}
'''
            driver_path = tmpdir / "nan_test.cpp"
            driver_path.write_text(test_code)
            exe_path = tmpdir / "nan_test"
            subprocess.run(
                ["clang++", "-fuse-ld=bfd", "-std=c++20", "-I/work", str(driver_path), "-o", str(exe_path)],
                capture_output=True,
                check=True
            )
            
            result = subprocess.run([str(exe_path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)

    def test_stats_merge(self):
        """Test RunningStats merge operation."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            
            test_code = r'''
#include "solution.hpp"
#include <iostream>
#include <cmath>
#include <cfloat>

int main() {
    RunningStats stats1, stats2;
    stats1.add(10.0);
    stats1.add(20.0);
    stats2.add(30.0);
    stats2.add(40.0);
    stats1.merge(stats2);
    
    bool ok = (stats1.count() == 4) &&
              (std::abs(stats1.mean() - 25.0) < 1e-9) &&
              (std::abs(stats1.minimum() - 10.0) < 1e-9) &&
              (std::abs(stats1.maximum() - 40.0) < 1e-9);
    return ok ? 0 : 1;
}
'''
            driver_path = tmpdir / "merge_test.cpp"
            driver_path.write_text(test_code)
            exe_path = tmpdir / "merge_test"
            subprocess.run(
                ["clang++", "-fuse-ld=bfd", "-std=c++20", "-I/work", str(driver_path), "-o", str(exe_path)],
                capture_output=True,
                check=True
            )
            
            result = subprocess.run([str(exe_path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)

    def test_public_cases(self):
        """Test against public cases from PUBLIC_CASES.json."""
        with tempfile.TemporaryDirectory() as d:
            tmpdir = pathlib.Path(d)
            exe = self._compile_driver(tmpdir)
            
            # Load public cases
            cases_path = pathlib.Path("/work/PUBLIC_CASES.json")
            with open(cases_path) as f:
                cases = json.load(f)
            
            for case in cases[:3]:  # Test first 3 cases (aggregation cases)
                driver_input = case["driver_input"]
                expected = case["expected"]
                
                # Extract CSV from driver_input format: "0 \"csv_content\""
                # The content is JSON-escaped, so we need to parse it
                import ast
                # driver_input is like: 0 "csv content with escaped chars"
                # Split on first space to get the mode, then extract the quoted string
                parts = driver_input.split(" ", 1)
                if len(parts) < 2:
                    continue
                csv_json = parts[1]  # This is the JSON string including quotes
                # Parse the JSON string to get actual CSV content
                try:
                    csv_content = ast.literal_eval(csv_json)
                except:
                    continue
                
                csv_path = tmpdir / "test.csv"
                csv_path.write_text(csv_content)
                
                result = subprocess.run(
                    [str(exe), "aggregate", str(csv_path)],
                    capture_output=True,
                    text=True
                )
                
                if "error" in expected:
                    self.assertNotEqual(result.returncode, 0, f"Case should fail: {case['input_file']}")
                else:
                    self.assertEqual(result.returncode, 0, f"Case should succeed: {case['input_file']}")
                    # Check expected values
                    for key, value in expected["value"].items():
                        self.assertIn(f'"{key}":{value}', result.stdout, f"Missing {key}:{value} in {case['input_file']}")


if __name__ == "__main__":
    unittest.main()
