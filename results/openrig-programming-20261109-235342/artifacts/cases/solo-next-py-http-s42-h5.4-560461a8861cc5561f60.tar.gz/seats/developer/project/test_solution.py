import unittest
import json
import http.server
import threading
import urllib.parse
import time
import urllib.request
import urllib.error

import solution


class TestFetchPages(unittest.TestCase):

    def test_basic_pagination(self):
        routes = {
            "/a": {
                "statuses": [200],
                "body": {
                    "items": [-18, 30, 58, -98, -33],
                    "next": "/b"
                }
            },
            "/b": {
                "body": {
                    "items": [-61, 93, -49],
                    "next": None
                }
            }
        }
        calls = []
        counts = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                n = counts.get(self.path, 0)
                counts[self.path] = n + 1
                route = routes.get(self.path, {"status": 404})
                statuses = route.get("statuses", [route.get("status", 200)])
                status = statuses[min(n, len(statuses) - 1)]
                self.send_response(status)
                self.end_headers()
                self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            result = solution.fetch_pages(f"http://127.0.0.1:{port}/a")
            self.assertEqual(result, [-18, 30, 58, -98, -33, -61, 93, -49])
            self.assertEqual(calls, ["/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_retry_on_503(self):
        routes = {
            "/a": {
                "statuses": [503, 200],
                "body": {
                    "items": [-33, -78, -49, 31, -86],
                    "next": "/b"
                }
            },
            "/b": {
                "body": {
                    "items": [52, -51, 29],
                    "next": None
                }
            }
        }
        calls = []
        counts = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                n = counts.get(self.path, 0)
                counts[self.path] = n + 1
                route = routes.get(self.path, {"status": 404})
                statuses = route.get("statuses", [route.get("status", 200)])
                status = statuses[min(n, len(statuses) - 1)]
                self.send_response(status)
                self.end_headers()
                self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            result = solution.fetch_pages(f"http://127.0.0.1:{port}/a", retries=2)
            self.assertEqual(result, [-33, -78, -49, 31, -86, 52, -51, 29])
            self.assertEqual(calls, ["/a", "/a", "/b"])
        finally:
            server.shutdown()
            server.server_close()

    def test_validation_retries_negative(self):
        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", retries=-1)

    def test_validation_timeout_zero(self):
        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", timeout=0)

    def test_validation_timeout_negative(self):
        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", timeout=-1.0)

    def test_validation_url_non_http(self):
        with self.assertRaises(ValueError):
            solution.fetch_pages("ftp://example.com")

    def test_validation_url_not_string(self):
        with self.assertRaises(ValueError):
            solution.fetch_pages(123)

    def test_cross_origin_rejected(self):
        routes = {
            "/a": {
                "statuses": [200],
                "body": {
                    "items": [1, 2, 3],
                    "next": "http://other.com/b"
                }
            }
        }
        calls = []

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                route = routes.get(self.path, {"status": 404})
                self.send_response(route.get("statuses", [200])[0])
                self.end_headers()
                self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_loop_detected(self):
        routes = {
            "/a": {
                "statuses": [200],
                "body": {
                    "items": [1],
                    "next": "/b"
                }
            },
            "/b": {
                "body": {
                    "items": [2],
                    "next": "/a"
                }
            }
        }
        calls = []

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                route = routes.get(self.path, {"status": 404})
                self.send_response(route.get("statuses", [200])[0])
                self.end_headers()
                self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_invalid_json(self):
        routes = {
            "/a": {
                "statuses": [200],
                "raw": "not json"
            }
        }

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                route = routes.get(self.path, {"status": 404})
                self.send_response(route.get("statuses", [200])[0])
                self.end_headers()
                self.wfile.write(route.get("raw", "not json").encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_items_with_bool_rejected(self):
        routes = {
            "/a": {
                "statuses": [200],
                "body": {
                    "items": [True, False],
                    "next": None
                }
            }
        }

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                route = routes.get(self.path, {"status": 404})
                self.send_response(route.get("statuses", [200])[0])
                self.end_headers()
                self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            with self.assertRaises(ValueError):
                solution.fetch_pages(f"http://127.0.0.1:{port}/a")
        finally:
            server.shutdown()
            server.server_close()

    def test_relative_url_resolution(self):
        routes = {
            "/path/a": {
                "statuses": [200],
                "body": {
                    "items": [1, 2],
                    "next": "/path/b"
                }
            },
            "/path/b": {
                "body": {
                    "items": [3, 4],
                    "next": None
                }
            }
        }
        calls = []

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                calls.append(self.path)
                route = routes.get(self.path, {"status": 404})
                self.send_response(route.get("statuses", [200])[0])
                self.end_headers()
                self.wfile.write(json.dumps(route.get("body", {})).encode())

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        time.sleep(0.1)

        try:
            port = server.server_port
            result = solution.fetch_pages(f"http://127.0.0.1:{port}/path/a")
            self.assertEqual(result, [1, 2, 3, 4])
            self.assertEqual(calls, ["/path/a", "/path/b"])
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
