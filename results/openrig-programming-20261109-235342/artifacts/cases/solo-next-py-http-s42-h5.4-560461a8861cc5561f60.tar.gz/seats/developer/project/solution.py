import json
import urllib.request
import urllib.error
import urllib.parse


def fetch_pages(url, retries=2, timeout=1.0):
    if not isinstance(retries, int) or retries < 0:
        raise ValueError("retries must be a non-negative integer")
    if not isinstance(timeout, (int, float)) or timeout <= 0:
        raise ValueError("timeout must be a positive number")

    if not isinstance(url, str) or not url.startswith("http"):
        raise ValueError("url must be a string starting with http")

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("url must use http or https scheme")

    origin = f"{parsed.scheme}://{parsed.netloc}"
    visited = set()
    all_items = []

    current_url = url
    attempts_remaining = retries + 1

    while current_url:
        if current_url in visited:
            raise ValueError("detected a loop in pagination")
        visited.add(current_url)

        parsed_current = urllib.parse.urlparse(current_url)
        if f"{parsed_current.scheme}://{parsed_current.netloc}" != origin:
            raise ValueError("cross-origin URL not allowed")

        attempt = 0
        last_status = None
        while attempt < attempts_remaining:
            try:
                req = urllib.request.Request(current_url, method="GET")
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    body = resp.read().decode("utf-8")
                    data = json.loads(body)

                    if not isinstance(data, dict):
                        raise ValueError("JSON must be an object")

                    if "items" not in data:
                        raise ValueError("missing 'items' field")
                    items = data["items"]
                    if not isinstance(items, list):
                        raise ValueError("'items' must be a list")
                    for item in items:
                        if isinstance(item, bool) or not isinstance(item, int):
                            raise ValueError("items must be integers only")

                    if "next" not in data:
                        raise ValueError("missing 'next' field")
                    next_url = data["next"]
                    if next_url is not None and not isinstance(next_url, str):
                        raise ValueError("'next' must be a string or null")

                    if next_url is not None:
                        if next_url.startswith("/"):
                            next_url = f"{origin}{next_url}"
                        elif not next_url.startswith(("http://", "https://")):
                            base_parsed = urllib.parse.urlparse(current_url)
                            base_path = base_parsed.path
                            if base_path.endswith("/"):
                                base_path = base_path[:-1]
                            next_url = f"{origin}{base_path}/{next_url}"

                        parsed_next = urllib.parse.urlparse(next_url)
                        if f"{parsed_next.scheme}://{parsed_next.netloc}" != origin:
                            raise ValueError("cross-origin URL not allowed")

                    all_items.extend(items)
                    current_url = next_url
                    attempts_remaining = retries + 1
                    break

            except urllib.error.HTTPError as e:
                last_status = e.code
                if e.code in (429, 500, 502, 503, 504):
                    attempt += 1
                    if attempt >= attempts_remaining:
                        raise ValueError(f"HTTP error {e.code} after retries")
                else:
                    raise ValueError(f"HTTP error {e.code}")
            except urllib.error.URLError as e:
                raise ValueError(f"URL error: {e.reason}")
            except json.JSONDecodeError:
                raise ValueError("invalid JSON")
            except Exception as e:
                raise ValueError(f"request failed: {e}")

        if attempt >= attempts_remaining:
            raise ValueError(f"failed to fetch page after retries")

    return all_items
