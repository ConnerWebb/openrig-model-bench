# fetch_pages Implementation

This project implements `fetch_pages(url, retries=2, timeout=1.0) -> list` as specified.

## API

```python
def fetch_pages(url, retries=2, timeout=1.0) -> list:
    """
    Fetch JSON pages over HTTP using Python stdlib.

    Each page is an object with:
      - items: list of integers (bool is not an integer here)
      - next: same-origin absolute URL, relative URL, or null

    Returns a flat list of items in order across pages.

    Raises ValueError for:
      - Invalid retries (<0) or timeout (<=0)
      - Non-HTTP initial URL
      - Cross-origin URLs
      - Repeated page URLs (loops)
      - Invalid schema or JSON
      - HTTP errors (except 429/500/502/503/504, which are retried)
      - Network failures
    """
```

## Usage

```python
from solution import fetch_pages

items = fetch_pages("http://example.com/api?page=1", retries=3, timeout=2.0)
print(items)
```

## Tests

Run tests with:

```bash
python -m unittest test_solution.py
```

## Implementation Notes

- Uses only Python stdlib (`urllib.request`, `urllib.parse`, `json`, etc.)
- Resolves relative `next` URLs against the current origin
- Retries only on status codes 429, 500, 502, 503, 504
- Validates all inputs strictly per spec
