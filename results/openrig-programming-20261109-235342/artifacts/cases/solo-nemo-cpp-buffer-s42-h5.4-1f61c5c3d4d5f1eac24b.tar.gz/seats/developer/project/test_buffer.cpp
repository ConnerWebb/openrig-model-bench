#include <cassert>
#include <cstdint>
#include <stdexcept>
#include <algorithm>

// Forward declare the Buffer class (same as solution.hpp)
class Buffer {
    std::uint8_t* p;
    std::size_t n;

    void validate_index(std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("index is out of range");
        }
    }

public:
    Buffer(std::size_t n = 0) : p(nullptr), n(n) {
        if (n > 0) {
            p = new std::uint8_t[n]();
        } else {
            p = nullptr;
        }
    }

    Buffer(const Buffer& other) : p(nullptr), n(other.n) {
        if (n > 0) {
            p = new std::uint8_t[n];
            std::copy(other.p, other.p + n, p);
        }
    }

    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] p;
            n = other.n;
            if (n > 0) {
                p = new std::uint8_t[n];
                std::copy(other.p, other.p + n, p);
            } else {
                p = nullptr;
            }
        }
        return *this;
    }

    Buffer(Buffer&& other) noexcept
        : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    ~Buffer() {
        delete[] p;
    }

    std::size_t size() const noexcept {
        return n;
    }

    std::uint8_t& operator[](std::size_t i) {
        validate_index(i);
        return p[i];
    }

    const std::uint8_t& operator[](std::size_t i) const {
        validate_index(i);
        return p[i];
    }

    void resize(std::size_t k) {
        if (k == n) return;
        if (k < n) {
            n = k;
        } else {
            std::uint8_t* new_p = new std::uint8_t[k]();
            std::copy(p, p + n, new_p);
            delete[] p;
            p = new_p;
            n = k;
        }
    }
};

// Simple test macro
#define ASSERT_EQ(a, b) assert((a) == (b))
#define ASSERT_TRUE(expr) assert((expr))
#define ASSERT_FALSE(expr) assert(!(expr))
#define EXPECT_THROW(stmt, ex) \
    do { \
        bool _thrown = false; \
        try { stmt; } catch (const ex&) { _thrown = true; } \
        catch (...) { /* ignore other exceptions */ } \
        assert(_thrown && "Expected " #ex " to be thrown"); \
    } while (0)

// Test default construction
void test_default_construction() {
    Buffer buf;
    assert(buf.size() == 0u);
}

// Test construction with size
void test_construction_with_size() {
    Buffer buf(5);
    assert(buf.size() == 5u);
    // Check zero-initialization
    for (std::size_t i = 0; i < buf.size(); ++i) {
        assert(buf[i] == 0);
    }
}

// Test copy construction
void test_copy_construction() {
    Buffer buf1(3);
    buf1[0] = 10;
    buf1[1] = 20;
    buf1[2] = 30;

    Buffer buf2(buf1);  // Copy construct

    assert(buf2.size() == 3u);
    assert(buf2.p != buf1.p);   // Different memory
    assert(buf2[0] == 10u);
    assert(buf2[1] == 20u);
    assert(buf2[2] == 30u);

    // Modifying copy does not affect original
    buf2[0] = 99;
    assert(buf1[0] == 10u);
}

// Test copy assignment
void test_copy_assignment() {
    Buffer buf1(2);
    buf1[0] = 5;
    buf1[1] = 6;

    Buffer buf2(3);
    buf2[0] = 7;
    buf2[1] = 8;
    buf2[2] = 9;

    buf2 = buf1;  // Copy assign

    assert(buf2.size() == 2u);
    assert(buf2[0] == 5u);
    assert(buf2[1] == 6u);
    assert(buf2.p != buf1.p);  // Deep copy
}

// Test move construction
void test_move_construction() {
    Buffer buf1(3);
    buf1[0] = 10;
    buf1[1] = 20;
    buf1[2] = 30;

    Buffer buf2(std::move(buf1));  // Move construct

    assert(buf2.size() == 3u);
    assert(buf2[0] == 10u);
    assert(buf2[1] == 20u);
    assert(buf2[2] == 30u);

    // Source should be empty after move
    assert(buf1.size() == 0u);
}

// Test move assignment
void test_move_assignment() {
    Buffer buf1(2);
    buf1[0] = 5;
    buf1[1] = 6;

    Buffer buf2(3);
    buf2[0] = 7;
    buf2[1] = 8;
    buf2[2] = 9;

    buf2 = std::move(buf1);  // Move assign

    assert(buf2.size() == 2u);
    assert(buf2[0] == 5u);
    assert(buf2[1] == 6u);

    assert(buf1.size() == 0u);
}

// Test resize growth
void test_resize_growth() {
    Buffer buf(2);
    buf[0] = 1;
    buf[1] = 2;

    buf.resize(4);  // Should grow to size 4, zero-initialize new bytes

    assert(buf.size() == 4u);
    assert(buf[0] == 1u);
    assert(buf[1] == 2u);
    assert(buf[2] == 0u);
    assert(buf[3] == 0u);
}

// Test resize shrink
void test_resize_shrink() {
    Buffer buf(5);
    for (std::size_t i = 0; i < buf.size(); ++i) {
        buf[i] = static_cast<uint8_t>(i + 1);
    }

    buf.resize(3);  // Shrink to size 3

    assert(buf.size() == 3u);
    assert(buf[0] == 1u);
    assert(buf[1] == 2u);
    assert(buf[2] == 3u);
}

// Test bounds checking
void test_bounds_checking() {
    Buffer buf(2);
    buf[0] = 10;
    buf[1] = 20;

    // Test mutable bounds check
    try {
        buf[2] = 30;
        assert(false && "Expected out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }

    // Test const bounds check
    const Buffer& const_buf = buf;
    try {
        const_buf[2];
        assert(false && "Expected out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

// Test moved-from buffer resize
void test_moved_from_resize() {
    Buffer buf1(2);
    buf1[0] = 5;
    buf1[1] = 6;

    Buffer buf2 = std::move(buf1);  // Move construct

    assert(buf1.size() == 0u);

    // Now resize the moved-from buffer (should be safe)
    buf1.resize(3);  // Should work without UB
    assert(buf1.size() == 3u);
    assert(buf1[0] == 0);
    assert(buf1[1] == 0);
    assert(buf1[2] == 0);
}

// Test self-assignment (copy)
void test_self_copy_assignment() {
    Buffer buf(2);
    buf[0] = 1;
    buf[1] = 2;

    Buffer buf2(3);
    buf2[0] = 3;
    buf2[1] = 4;
    buf2[2] = 5;

    buf2 = buf2;  // Self-assignment

    assert(buf2.size() == 3u);
    assert(buf2[0] == 3u);
    assert(buf2[1] == 4u);
    assert(buf2[2] == 5u);
}

// Test self-move assignment
void test_self_move_assignment() {
    Buffer buf(2);
    buf[0] = 1;
    buf[1] = 2;

    Buffer buf2(3);
    buf2[0] = 3;
    buf2[1] = 4;
    buf2[2] = 5;

    buf2 = std::move(buf2);  // Self-move

    assert(buf2.size() == 3u);
    assert(buf2[0] == 3u);
    assert(buf2[1] == 4u);
    assert(buf2[2] == 5u);
}

// Run all tests
int main() {
    test_default_construction();
    test_construction_with_size();
    test_copy_construction();
    test_copy_assignment();
    test_move_construction();
    test_move_assignment();
    test_resize_growth();
    test_resize_shrink();
    test_bounds_checking();
    test_moved_from_resize();
    test_self_copy_assignment();
    test_self_move_assignment();
    return 0;
}