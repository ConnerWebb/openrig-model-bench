#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

    // Private helper to validate index
    void validate_index(std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("index is out of range");
        }
    }

public:
    // Default constructor: creates an empty buffer (size 0)
    Buffer(std::size_t n = 0) : p(nullptr), n(n) {
        if (n > 0) {
            p = new std::uint8_t[n](); // Zero-initialized
        } else {
            p = nullptr;
        }
    }

    // Copy constructor: deep copy with its own storage
    Buffer(const Buffer& other) : p(nullptr), n(other.n) {
        if (n > 0) {
            p = new std::uint8_t[n];
            std::copy(other.p, other.p + n, p);
        }
    }

    // Copy assignment: deep copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            // Clean up existing resources
            delete[] p;
            n = other.n;
            if (n > 0) {
                p = new std::uint8_t[n];
                std::copy(other.p, other.p + n, p);
            } else {
                p = nullptr;
            }
        }
        return *this;
    }

    // Move constructor: steals resources, leaves other in valid but empty state
    Buffer(Buffer&& other) noexcept
        : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment: steals resources, leaves other in valid but empty state
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Destructor: clean up allocated memory
    ~Buffer() {
        delete[] p;
    }

    // Getter: returns size of buffer
    std::size_t size() const noexcept {
        return n;
    }

    // Mutable operator[]: returns reference with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        validate_index(i);
        return p[i];
    }

    // Const operator[]: returns const reference with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        validate_index(i);
        return p[i];
    }

    // Resize: preserves prefix, zero-initializes new bytes
    void resize(std::size_t k) {
        if (k == n) return;
        if (k < n) {
            // Truncate: just adjust size, no reallocation needed
            n = k;
        } else {
            // Grow: allocate new storage
            std::uint8_t* new_p = new std::uint8_t[k]();
            std::copy(p, p + n, new_p);
            delete[] p;
            p = new_p;
            n = k;
        }
    }
};