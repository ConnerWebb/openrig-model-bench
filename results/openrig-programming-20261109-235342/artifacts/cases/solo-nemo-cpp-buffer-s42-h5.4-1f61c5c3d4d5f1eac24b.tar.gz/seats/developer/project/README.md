# Buffer Library

This library provides a custom `Buffer` class that mimics the behavior of a dynamically-sized array of bytes (`uint8_t`). It supports:

- Construction with optional initial size (default 0)
- Copy and move semantics (deep copy on copy, resource stealing on move)
- Resizing with zero-initialization of new bytes
- Bounds-checked `operator[]` (both mutable and const)
- Proper RAII cleanup (no memory leaks, double frees, or stale reads)
- `size()` method returning current size

## Key Requirements Met

- **Deep Copy**: Copy constructor and copy assignment perform deep copies with independent storage.
- **Move Semantics**: Move constructor and move assignment transfer ownership and leave the source in a valid empty state.
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for out-of-bounds access.
- **Resize Behavior**: `resize()` preserves existing data and zero-initializes new bytes.
- **No Leaks/Undefined Behavior**: All allocations are properly cleaned up in the destructor; no double deletes.
- **Standard Compliance**: Uses only standard library components (`<cstdint>`, `<cstddef>`, `<stdexcept>`, `<algorithm>`).

## Usage Example

```cpp
Buffer buf(5);           // Create buffer of size 5, zero-initialized
buf[0] = 42;             // Set element
std::size_t s = buf.size(); // Get size
```

## Testing

Tests are implemented in `test_buffer.cpp` using `unittest.TestCase` (Python) and C++ standalone test binaries. Run with `run_tests` to verify all checks.