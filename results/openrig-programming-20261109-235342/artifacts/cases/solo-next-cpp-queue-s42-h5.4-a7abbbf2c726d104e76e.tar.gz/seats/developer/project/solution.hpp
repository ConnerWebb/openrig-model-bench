#ifndef BOUNDED_QUEUE_HPP
#define BOUNDED_QUEUE_HPP

#include <queue>
#include <mutex>
#include <condition_variable>
#include <optional>
#include <stdexcept>
#include <type_traits>

template <class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity) : capacity_(capacity) {
        if (capacity_ == 0) {
            throw std::invalid_argument("capacity must be > 0");
        }
    }

    bool push(T value) {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_not_full_.wait(lock, [this] { return is_closed_ || queue_.size() < capacity_; });
        if (is_closed_) return false;
        queue_.push(std::move(value));
        cv_not_empty_.notify_one();
        return true;
    }

    std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_not_empty_.wait(lock, [this] { return !queue_.empty() || is_closed_; });
        if (queue_.empty()) return std::nullopt;
        T result = std::move(queue_.front());
        queue_.pop();
        cv_not_full_.notify_one();
        return result;
    }

    void close() {
        std::unique_lock<std::mutex> lock(mutex_);
        if (is_closed_) return;
        is_closed_ = true;
        cv_not_full_.notify_all();
        cv_not_empty_.notify_all();
    }

private:
    size_t capacity_;
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable cv_not_full_;
    std::condition_variable cv_not_empty_;
    bool is_closed_ = false;
};

#endif
