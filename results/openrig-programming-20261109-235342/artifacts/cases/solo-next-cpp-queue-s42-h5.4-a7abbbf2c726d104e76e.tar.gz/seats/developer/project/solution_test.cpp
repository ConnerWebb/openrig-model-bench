#include "solution.hpp"
#include <thread>
#include <vector>
#include <cassert>
#include <atomic>

void test_basic_push_pop() {
    BoundedQueue<int> q(2);
    assert(q.push(1));
    assert(q.push(2));
    // Do not test blocking push; use close to avoid deadlock
    q.close();
    auto v1 = q.pop();
    assert(v1.has_value() && *v1 == 1);
    auto v2 = q.pop();
    assert(v2.has_value() && *v2 == 2);
    assert(!q.pop().has_value());
}

void test_zero_capacity() {
    bool threw = false;
    try {
        BoundedQueue<int> q(0);
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
}

void test_close_wakes_all() {
    BoundedQueue<int> q(1);
    std::atomic<bool> p1_blocked{false}, p2_blocked{false};
    std::thread t1([&] { p1_blocked=true; q.push(1); });
    std::thread t2([&] { p2_blocked=true; q.push(2); });
    while (!p1_blocked.load() || !p2_blocked.load()) std::this_thread::yield();
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    q.close();
    t1.join();
    t2.join();
    auto v = q.pop();
    assert(v.has_value());
}

void test_move_only_type() {
    BoundedQueue<std::unique_ptr<int>> q(2);
    q.push(std::make_unique<int>(42));
    auto v = q.pop();
    assert(v.has_value() && *v && **v == 42);
}

void test_close_idempotent() {
    BoundedQueue<int> q(2);
    q.close();
    q.close();
    assert(!q.push(1));
}

void test_producer_consumer() {
    BoundedQueue<int> q(10);
    std::vector<int> got;
    std::mutex m;

    std::thread consumer([&] {
        while (auto v = q.pop()) {
            std::lock_guard<std::mutex> lock(m);
            got.push_back(*v);
        }
    });

    std::thread producer([&] {
        for (int i = 0; i < 100; ++i) {
            q.push(i);
        }
    });

    producer.join();
    q.close();
    consumer.join();

    assert(got.size() == 100);
}

int main() {
    test_basic_push_pop();
    test_zero_capacity();
    test_close_wakes_all();
    test_move_only_type();
    test_close_idempotent();
    test_producer_consumer();
    return 0;
}
