# BoundedQueue

Thread-safe bounded blocking queue for C++20.

## API

```cpp
template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity); // throws if capacity == 0
    bool push(T value); // blocks while full, returns false after close
    std::optional<T> pop(); // blocks while empty/open, nullopt after drain
    void close(); // idempotent, wakes all waiters
};
```

## Build & Test

```bash
clang++ -std=c++20 -pthread -o solution_test solution_test.cpp
./solution_test
```

## Usage

```cpp
#include "solution.hpp"
BoundedQueue<int> q(10);
q.push(42);
auto v = q.pop(); // std::optional<int>
```
