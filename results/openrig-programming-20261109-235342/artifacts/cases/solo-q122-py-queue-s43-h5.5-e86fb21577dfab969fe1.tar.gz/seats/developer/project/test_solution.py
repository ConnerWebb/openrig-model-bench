import unittest
import tempfile
import pathlib
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = str(pathlib.Path(self.temp_dir) / 'q.db')
        self.q = JobQueue(self.db_path, max_attempts=3)

    def test_enqueue_first_wins(self):
        self.assertTrue(self.q.enqueue('a', {'v': 5304}))
        self.assertFalse(self.q.enqueue('a', 'ignored'))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)

    def test_claim_basic(self):
        self.q.enqueue('a', {'v': 5304})
        result = self.q.claim('w', 0, 5)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['payload'], {'v': 5304})
        self.assertEqual(result['attempts'], 1)

    def test_claim_no_available_jobs(self):
        result = self.q.claim('w', 0, 5)
        self.assertIsNone(result)

    def test_complete_wrong_worker(self):
        self.q.enqueue('a', {'v': 5304})
        self.q.claim('w', 0, 5)
        self.assertFalse(self.q.complete('a', 'wrong'))

    def test_fail_and_reclaim(self):
        self.q.enqueue('a', {'v': 5304})
        self.q.claim('w', 0, 5)
        self.assertTrue(self.q.fail('a', 'w'))
        result = self.q.claim('w2', 1, 5)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['attempts'], 2)

    def test_complete_success(self):
        self.q.enqueue('a', {'v': 5304})
        self.q.claim('w', 0, 5)
        self.q.fail('a', 'w')
        result = self.q.claim('w2', 1, 5)
        self.assertTrue(self.q.complete('a', 'w2'))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'done')
        self.assertEqual(status['attempts'], 2)

    def test_claim_after_complete_returns_none(self):
        self.q.enqueue('a', {'v': 5304})
        self.q.claim('w', 0, 5)
        self.q.complete('a', 'w')
        result = self.q.claim('w3', 100, 5)
        self.assertIsNone(result)

    def test_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_invalid_worker(self):
        with self.assertRaises(ValueError):
            self.q.claim('', 0, 5)

    def test_invalid_key(self):
        with self.assertRaises(ValueError):
            self.q.enqueue('', 'payload')

    def test_invalid_lease(self):
        with self.assertRaises(ValueError):
            self.q.claim('w', 0, 0)
        with self.assertRaises(ValueError):
            self.q.claim('w', 0, -1)

    def test_expired_job_becomes_failed(self):
        import tempfile
        import os
        # With max_attempts=1, an expired job should be marked failed
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        try:
            q = JobQueue(db_path, max_attempts=1)
            q.enqueue('a', {'v': 5304})
            # Claim it
            q.claim('w', 0, 5)
            # Let it expire (now > lease_until)
            result = q.claim('w2', 100, 5)  # now=100, lease_until was 5, attempts=1 >= max_attempts=1
            # The expired job should be marked failed, so w2 gets nothing
            self.assertIsNone(result)
            status = q.status('a')
            self.assertEqual(status['state'], 'failed')
        finally:
            os.unlink(db_path)

    def test_fail_exhausted_attempts(self):
        self.q.enqueue('a', {'v': 5304})
        # Exhaust attempts
        self.q.claim('w1', 0, 5)
        self.q.fail('a', 'w1')
        self.q.claim('w2', 1, 5)
        self.q.fail('a', 'w2')
        self.q.claim('w3', 2, 5)
        # Now attempts=3, which equals max_attempts
        self.q.fail('a', 'w3')
        status = self.q.status('a')
        self.assertEqual(status['state'], 'failed')

    def test_status_nonexistent(self):
        self.assertIsNone(self.q.status('nonexistent'))

    def test_claim_oldest_first(self):
        self.q.enqueue('first', {'id': 1})
        self.q.enqueue('second', {'id': 2})
        result = self.q.claim('w', 0, 5)
        self.assertEqual(result['key'], 'first')

    def test_claim_leased_expired_job(self):
        import tempfile
        import os
        # With max_attempts=1, an expired job should be marked failed
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        try:
            q = JobQueue(db_path, max_attempts=1)
            q.enqueue('a', {'v': 5304})
            # Claim with lease_until=5
            q.claim('w', 0, 5)
            # Now try to claim at time 10 (expired)
            result = q.claim('w2', 10, 5)
            # The expired job should be marked failed (attempts=1 >= max_attempts=1), so w2 gets nothing
            self.assertIsNone(result)
        finally:
            os.unlink(db_path)

if __name__ == '__main__':
    unittest.main()
