# JobQueue Implementation

A SQLite-backed job queue implementation supporting concurrent access with lease-based claiming.

## Features

- **Unique key enforcement**: First enqueue for a key wins
- **Lease-based claiming**: Workers claim jobs with a time-bound lease
- **Automatic failure handling**: Expired leases and exhausted attempts mark jobs as failed
- **Concurrent safe**: Multiple instances/processes can share the same database
- **No duplicate claims**: Atomic operations prevent lost/duplicate live claims

## API

```python
class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3)
    def enqueue(self, key: str, payload: Any) -> bool
    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict]
    def complete(self, key: str, worker: str) -> bool
    def fail(self, key: str, worker: str) -> bool
    def status(self, key: str) -> Optional[Dict]
```

### Methods

- **enqueue(key, payload)**: Add a job. Returns `True` if first unique key, `False` otherwise.
- **claim(worker, now, lease)**: Atomically claim the oldest eligible job. Returns `{key, payload, attempts}` or `None`.
- **complete(key, worker)**: Mark job as done. Requires matching leased owner.
- **fail(key, worker)**: Requeue or mark failed if attempts exhausted. Requires matching leased owner.
- **status(key)**: Return `{state, attempts}` or `None` if key doesn't exist.

### States

- `queued`: Available for claiming
- `leased`: Currently claimed by a worker
- `done`: Successfully completed
- `failed`: Exhausted attempts or expired

## Validation

- `max_attempts` must be positive
- `lease` must be positive
- `worker` and `key` must be nonempty
- Invalid arguments raise `ValueError`

## Testing

Run tests with:
```bash
python3 -m unittest test_solution.py
```

Or use the framework runner:
```bash
run_tests
```
