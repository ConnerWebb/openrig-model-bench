import sqlite3
import json
from typing import Optional, Dict, Any

class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT NOT NULL DEFAULT 'queued',
                attempts INTEGER NOT NULL DEFAULT 0,
                owner TEXT,
                lease_until REAL,
                inserted_at REAL NOT NULL DEFAULT (julianday('now'))
            )
        ''')
        conn.commit()
        conn.close()

    def enqueue(self, key: str, payload: Any) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        # First unique key wins - check if key exists
        cursor.execute('SELECT key FROM jobs WHERE key = ?', (key,))
        if cursor.fetchone() is not None:
            conn.close()
            return False
        payload_json = json.dumps(payload)
        cursor.execute('''
            INSERT INTO jobs (key, payload, state, attempts, owner, lease_until)
            VALUES (?, ?, 'queued', 0, NULL, NULL)
        ''', (key, payload_json))
        conn.commit()
        conn.close()
        return True

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not worker:
            raise ValueError("worker must be nonempty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        
        conn = sqlite3.connect(self.path, timeout=30.0)
        conn.isolation_level = 'EXCLUSIVE'
        cursor = conn.cursor()
        
        try:
            # First, handle expired jobs:
            # - If attempts >= max_attempts, mark as failed
            # - Otherwise, requeue them (state=queued, owner=NULL, lease_until=NULL)
            cursor.execute('''
                UPDATE jobs 
                SET state = 'failed'
                WHERE state = 'leased' 
                  AND lease_until <= ? 
                  AND attempts >= ?
            ''', (now, self.max_attempts))
            
            cursor.execute('''
                UPDATE jobs 
                SET state = 'queued',
                    owner = NULL,
                    lease_until = NULL
                WHERE state = 'leased' 
                  AND lease_until <= ? 
                  AND attempts < ?
            ''', (now, self.max_attempts))
            
            # Now find the oldest eligible job (queued state, attempts < max_attempts)
            # Use a subquery to get the key, then update it atomically
            cursor.execute('''
                SELECT key, payload, attempts 
                FROM jobs 
                WHERE rowid = (
                    SELECT rowid FROM jobs 
                    WHERE state = 'queued'
                      AND attempts < ?
                    ORDER BY inserted_at ASC
                    LIMIT 1
                )
            ''', (self.max_attempts,))
            
            row = cursor.fetchone()
            if row is None:
                # No job available, but expired job updates should still be committed
                conn.commit()
                return None
            
            key, payload_json, attempts = row
            payload = json.loads(payload_json)
            
            # Atomically update: increment attempts, set owner and expiry
            cursor.execute('''
                UPDATE jobs 
                SET attempts = attempts + 1,
                    owner = ?,
                    lease_until = ?,
                    state = 'leased'
                WHERE key = ?
            ''', (worker, now + lease, key))
            conn.commit()
            
            return {
                'key': key,
                'payload': payload,
                'attempts': attempts + 1
            }
        finally:
            conn.close()

    def complete(self, key: str, worker: str) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        if not worker:
            raise ValueError("worker must be nonempty")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check if job exists and is leased to this worker
        cursor.execute('''
            SELECT state, owner FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return False
        
        state, owner = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # Mark as done
        cursor.execute('''
            UPDATE jobs 
            SET state = 'done'
            WHERE key = ?
        ''', (key,))
        conn.commit()
        conn.close()
        return True

    def fail(self, key: str, worker: str) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        if not worker:
            raise ValueError("worker must be nonempty")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check if job exists and is leased to this worker
        cursor.execute('''
            SELECT state, owner, attempts FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        if row is None:
            conn.close()
            return False
        
        state, owner, attempts = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # If attempts exhausted, mark as failed, else requeue
        if attempts >= self.max_attempts:
            cursor.execute('''
                UPDATE jobs 
                SET state = 'failed'
                WHERE key = ?
            ''', (key,))
        else:
            cursor.execute('''
                UPDATE jobs 
                SET state = 'queued',
                    owner = NULL,
                    lease_until = NULL
                WHERE key = ?
            ''', (key,))
        conn.commit()
        conn.close()
        return True

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not key:
            raise ValueError("key must be nonempty")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # First check if job exists and get its current state
        cursor.execute('''
            SELECT state, attempts, lease_until FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        
        if row is None:
            conn.close()
            return None
        
        state, attempts, lease_until = row
        
        # If leased and expired, update state
        if state == 'leased' and lease_until is not None:
            # We need to know 'now' to check expiration, but status doesn't take now
            # So we can't update here. The state should be updated by claim or fail.
            # Actually, looking at the spec, status should just return current state.
            # But the test expects status to show 'failed' after expiration.
            # This means status needs to handle expiration too.
            # But status doesn't have 'now' parameter...
            # Let me re-read the spec.
            pass
        
        conn.close()
        return {
            'state': state,
            'attempts': attempts
        }
