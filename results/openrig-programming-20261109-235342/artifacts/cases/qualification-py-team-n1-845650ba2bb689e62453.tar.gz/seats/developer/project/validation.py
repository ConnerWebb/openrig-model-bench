def normalize(records):
    """Validate and normalize records. Returns fresh copies.
    
    Each record must have: id (nonempty stripped str), 
    category (nonempty stripped str), cents (int >= 0, not bool).
    """
    out = []
    for r in records:
        if not isinstance(r, dict):
            raise ValueError('record')
        if set(r.keys()) != {'id', 'category', 'cents'}:
            raise ValueError('record')
        if not isinstance(r['id'], str) or isinstance(r['id'], bool):
            raise ValueError('record')
        if not r['id'].strip():
            raise ValueError('record')
        if not isinstance(r['category'], str) or isinstance(r['category'], bool):
            raise ValueError('record')
        if not r['category'].strip():
            raise ValueError('record')
        if not isinstance(r['cents'], int) or isinstance(r['cents'], bool) or r['cents'] < 0:
            raise ValueError('record')
        out.append({
            'id': r['id'].strip(),
            'category': r['category'].strip(),
            'cents': r['cents']
        })
    return out
