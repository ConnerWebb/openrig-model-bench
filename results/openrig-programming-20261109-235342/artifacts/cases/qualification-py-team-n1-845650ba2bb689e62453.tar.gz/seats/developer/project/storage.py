def deduplicate(records):
    """Remove duplicate ids, keeping first occurrence. Returns fresh copies.
    
    Input must already be validated. Returns a new list with only the first
    occurrence of each id, preserving input order.
    """
    seen = set()
    out = []
    for r in records:
        if r['id'] not in seen:
            seen.add(r['id'])
            out.append(dict(r))
    return out
