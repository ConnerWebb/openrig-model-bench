from validation import normalize
from storage import deduplicate

def process(records, *, minimum_cents=0):
    """Process records and return events with totals.
    
    Args:
        records: List of record dicts with id, category, cents
        minimum_cents: Optional filter for minimum cents value (int >= 0, not bool)
    
    Returns:
        {'events': [normalized records], 'totals': {category: sum cents}}
    
    Raises:
        ValueError: If any record is invalid or minimum_cents is invalid
    """
    # Validate minimum_cents parameter
    if not isinstance(minimum_cents, int) or isinstance(minimum_cents, bool) or minimum_cents < 0:
        raise ValueError('minimum')
    
    # Validate and normalize all records (preserves duplicates)
    normalized = normalize(records)
    
    # Deduplicate (first occurrence wins)
    deduplicated = deduplicate(normalized)
    
    # Apply minimum_cents filter
    events = [r for r in deduplicated if r['cents'] >= minimum_cents]
    
    # Calculate totals with sorted keys
    totals = {}
    for r in events:
        totals[r['category']] = totals.get(r['category'], 0) + r['cents']
    
    return {'events': events, 'totals': dict(sorted(totals.items()))}
