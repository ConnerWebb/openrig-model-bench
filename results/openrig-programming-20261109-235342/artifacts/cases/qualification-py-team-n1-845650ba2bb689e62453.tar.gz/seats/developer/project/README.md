# Ledger Toolkit

A Python library for processing ledger records with validation, deduplication, and aggregation.

## Modules

### validation.py
- `normalize(records)` - Validates and normalizes records, returning fresh copies
  - Validates: id (nonempty stripped str), category (nonempty stripped str), cents (int >= 0, not bool)
  - Raises ValueError for invalid records
  - Preserves duplicates (deduplication handled by storage.py)

### storage.py
- `deduplicate(records)` - Removes duplicate ids, keeping first occurrence
  - Input must already be validated
  - Returns fresh copies
  - First occurrence of each id wins, preserving input order

### ledger.py
- `process(records, *, minimum_cents=0)` - Main API for processing records
  - Validates all records
  - Deduplicates by first occurrence of id
  - Filters by minimum_cents (default 0)
  - Returns `{'events': [normalized records], 'totals': {category: sum cents}}`
  - Totals keys are sorted alphabetically

## Usage

```python
from ledger import process

records = [
    {'id': 'item1', 'category': 'food', 'cents': 100},
    {'id': 'item2', 'category': 'transport', 'cents': 250},
    {'id': 'item1', 'category': 'food', 'cents': 150},  # duplicate id, ignored
]

result = process(records)
# result = {
#     'events': [
#         {'id': 'item1', 'category': 'food', 'cents': 100},
#         {'id': 'item2', 'category': 'transport', 'cents': 250}
#     ],
#     'totals': {'food': 100, 'transport': 250}
# }
```

## Validation Rules

- `id`: must be a non-empty string (after stripping)
- `category`: must be a non-empty string (after stripping)
- `cents`: must be an integer >= 0 (booleans are rejected)
- `minimum_cents`: must be an integer >= 0 (booleans are rejected)

## Properties

- Never mutates input data
- Returns fresh copies on every call
- No hidden global state
- State is not retained between calls
