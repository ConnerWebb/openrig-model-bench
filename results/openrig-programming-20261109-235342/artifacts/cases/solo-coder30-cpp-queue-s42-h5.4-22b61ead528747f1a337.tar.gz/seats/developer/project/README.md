# BoundedQueue Implementation

This is a thread-safe bounded queue implementation in C++20 that satisfies all the requirements specified in the task.

## Features

- **Template-based**: Works with any type T
- **Thread-safe**: Uses mutexes and condition variables for synchronization
- **Bounded**: Enforces a maximum capacity
- **Move-only support**: Supports move-only types like `std::unique_ptr`
- **Proper blocking**: `push()` blocks when full, `pop()` blocks when empty
- **Graceful shutdown**: `close()` method allows clean shutdown
- **FIFO order**: Maintains insertion order
- **Idempotent close**: Calling `close()` multiple times is safe

## API

```cpp
template<class T>
class BoundedQueue {
public:
    // Constructor - throws std::invalid_argument if capacity is zero
    explicit BoundedQueue(std::size_t capacity);
    
    // Push an element - blocks if queue is full, returns false after close()
    bool push(T value);
    
    // Pop an element - blocks if queue is empty, returns nullopt after close()
    std::optional<T> pop();
    
    // Close the queue - wakes all waiting producers/consumers
    void close();
};
```

## Requirements Met

1. ✅ Template class `BoundedQueue<T>`
2. ✅ Explicit constructor with capacity parameter
3. ✅ `bool push(T value)` - returns false when queue is closed
4. ✅ `std::optional<T> pop()` - returns nullopt when closed and empty
5. ✅ `void close()` - idempotent, wakes all waiting threads
6. ✅ Capacity zero throws `std::invalid_argument`
7. ✅ Push blocks while full, returns false after close
8. ✅ Pop blocks while empty/open, drains values after close, then returns nullopt
9. ✅ FIFO ordering
10. ✅ Supports move-only T
11. ✅ Thread-safe
12. ✅ Releases resources on clean shutdown
13. ✅ Callers close then join before destruction

## Usage Example

```cpp
BoundedQueue<int> q(10);
q.push(42);
auto value = q.pop();
q.close();
```