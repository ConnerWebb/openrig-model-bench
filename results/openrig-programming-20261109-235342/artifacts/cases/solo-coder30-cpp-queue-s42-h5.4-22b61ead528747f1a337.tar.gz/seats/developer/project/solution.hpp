#pragma once

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <optional>
#include <queue>
#include <stdexcept>
#include <thread>
#include <type_traits>

template<class T>
class BoundedQueue {
private:
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable not_empty_;
    std::condition_variable not_full_;
    std::atomic<bool> closed_;
    std::size_t capacity_;

public:
    explicit BoundedQueue(std::size_t capacity) : closed_(false), capacity_(capacity) {
        if (capacity == 0) {
            throw std::invalid_argument("Capacity must be greater than zero");
        }
    }

    bool push(T value) {
        std::unique_lock<std::mutex> lock(mutex_);
        
        // Wait until there's space or the queue is closed
        not_full_.wait(lock, [this] { 
            return queue_.size() < capacity_ || closed_.load(); 
        });
        
        // If closed, return false
        if (closed_.load()) {
            return false;
        }
        
        queue_.push(std::move(value));
        not_empty_.notify_one();
        return true;
    }

    std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        
        // Wait until there's an item or the queue is closed
        not_empty_.wait(lock, [this] { 
            return !queue_.empty() || closed_.load(); 
        });
        
        // If queue is empty and closed, return nullopt
        if (queue_.empty() && closed_.load()) {
            return std::nullopt;
        }
        
        // If queue is empty but not closed, this shouldn't happen
        if (queue_.empty()) {
            return std::nullopt;
        }
        
        T value = std::move(queue_.front());
        queue_.pop();
        not_full_.notify_one();
        return value;
    }

    void close() {
        closed_.store(true);
        not_empty_.notify_all();
        not_full_.notify_all();
    }
};