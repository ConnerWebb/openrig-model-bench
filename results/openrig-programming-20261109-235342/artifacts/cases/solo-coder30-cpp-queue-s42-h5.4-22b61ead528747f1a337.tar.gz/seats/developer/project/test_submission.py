import unittest
import threading
import time
import sys
from solution import BoundedQueue

class TestBoundedQueue(unittest.TestCase):
    def test_basic_push_pop(self):
        queue = BoundedQueue(2)
        self.assertTrue(queue.push(1))
        self.assertTrue(queue.push(2))
        self.assertEqual(queue.pop(), 1)
        self.assertEqual(queue.pop(), 2)
        
    def test_blocking_push(self):
        queue = BoundedQueue(1)
        # Fill the queue
        queue.push(1)
        # This should block until something is popped
        start_time = time.time()
        # We'll test this by running in a separate thread
        result = [None]
        def push_task():
            result[0] = queue.push(2)
        thread = threading.Thread(target=push_task)
        thread.start()
        time.sleep(0.1)  # Give it time to block
        queue.pop()  # This should unblock the push
        thread.join()
        self.assertTrue(result[0])
        
    def test_close_wakes_waiters(self):
        queue = BoundedQueue(1)
        queue.push(1)
        # This should block
        result = [None]
        def push_task():
            result[0] = queue.push(2)
        thread = threading.Thread(target=push_task)
        thread.start()
        time.sleep(0.1)
        queue.close()  # This should wake up the push
        thread.join()
        self.assertFalse(result[0])  # Should return false when closed

if __name__ == '__main__':
    unittest.main()
