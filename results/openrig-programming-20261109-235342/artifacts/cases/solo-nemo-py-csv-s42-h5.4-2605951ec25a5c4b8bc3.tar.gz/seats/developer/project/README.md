# CSV Aggregator Solution

This project implements a CSV file aggregator that processes rows of data and computes totals per category with strict validation.

## Implementation Details

- Reads CSV files with `category` and `amount` columns
- Validates category (non-empty) and amount (proper numeric format)
- Supports positive/negative numbers, decimal values with 1-2 digits precision
- Rejects invalid formats including:
  - Missing or empty category
  - Missing or empty amount
  - Amount with exponent notation
  - Amount with more than 2 decimal places
  - Invalid characters in amount
- Aggregates amounts by category and returns formatted results with exactly 2 decimal places

## Validation Rules

1. Category must be non-empty and contain only valid characters
2. Amount must be a valid numeric string with no exponent
3. Decimal amounts must have exactly 1 or 2 digits after the decimal point
4. Invalid formats raise ValueError with descriptive messages
5. Empty files with header only are handled gracefully

## Usage

The solution provides a function `aggregate(csv_path: str) -> Dict[str, str]` that processes CSV files according to the specifications.