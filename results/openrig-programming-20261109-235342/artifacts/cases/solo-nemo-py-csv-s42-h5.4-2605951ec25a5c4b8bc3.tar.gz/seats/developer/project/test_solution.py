import unittest
import tempfile
import os
from solution import aggregate

class TestAggregate(unittest.TestCase):
    def test_valid_csv(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nfood,10.5\\nfood,5.25\\n')
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {'food': '15.75'})

    def test_invalid_category(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\n,5.0\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_invalid_header(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('badheader\\nrow\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_invalid_amount_format(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nx,1e2\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_exponent_amount_rejected(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nx,1e2\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_negative_amount_rejected(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nx,-1\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_too_many_decimal_places(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nx,1.123\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_large_number_handling(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nx,1000000000000\\n')
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)

    def test_valid_amounts(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\nfood,1.5\\nfood,2.25\\n')
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {'food': '3.75'})

    def test_empty_csv(self):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('category,amount\\n')
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {})

if __name__ == '__main__':
    unittest.main()