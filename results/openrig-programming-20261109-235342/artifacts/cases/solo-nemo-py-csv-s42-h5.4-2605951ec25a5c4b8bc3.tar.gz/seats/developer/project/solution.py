from decimal import Decimal, InvalidOperation
import csv
from typing import Dict

def aggregate(csv_path: str) -> Dict[str, str]:
    totals = {}
    with open(csv_path, newline='') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError("Invalid CSV format")
        for row_num, row in enumerate(reader, start=2):
            if 'category' not in row or 'amount' not in row:
                raise ValueError("Invalid CSV format")
            category = row['category']
            amount_str = row['amount']
            if not category or not category.strip():
                raise ValueError("Invalid category")
            if not amount_str or not amount_str.strip():
                raise ValueError("Invalid amount")
            # Check for exponent
            if 'e' in amount_str.lower():
                raise ValueError(f"Invalid amount format in row {row_num}: {amount_str}")
            # Parse and validate
            try:
                Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount format in row {row_num}: {amount_str}")
            # Check decimal places if present
            if '.' in amount_str:
                int_part, frac_part = amount_str.split('.')
                if len(frac_part) not in (1, 2):
                    raise ValueError(f"Invalid decimal part length in row {row_num}")
            totals[category] = totals.get(category, Decimal(0)) + Decimal(amount_str)
    
    # Format results with exactly two decimal places
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}