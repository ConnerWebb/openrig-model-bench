#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include <cmath>
#include "stats.hpp"

int main() {
    int passed = 0;
    int failed = 0;

    // Test 1: BasicAdd
    {
        RunningStats rs;
        rs.add(1.0);
        rs.add(2.0);
        rs.add(3.0);
        if (rs.count() == 3 && 
            std::abs(rs.mean() - 2.0) < 1e-9 && 
            std::abs(rs.variance() - (2.0/3.0)) < 1e-9 &&
            std::abs(rs.minimum() - 1.0) < 1e-9 &&
            std::abs(rs.maximum() - 3.0) < 1e-9) {
            passed++;
        } else {
            failed++;
            std::cerr << "Test BasicAdd failed\n";
        }
    }

    // Test 2: EmptyStatsThrow
    {
        RunningStats rs;
        bool caught = true;
        try { rs.mean(); caught = false; } catch(const std::domain_error&) {}
        try { rs.variance(); caught = false; } catch(const std::domain_error&) {}
        try { rs.minimum(); caught = false; } catch(const std::domain_error&) {}
        try { rs.maximum(); caught = false; } catch(const std::domain_error&) {}
        if (caught) passed++; else failed++;
    }

    // Test 3: RejectNaN
    {
        RunningStats rs;
        bool caught = true;
        try { rs.add(std::nan("")); } catch(const std::invalid_argument&) {}
        if (rs.count() == 0 && caught) passed++; else failed++;
    }

    // Test 4: RejectInfinity
    {
        RunningStats rs;
        bool caught = true;
        try { rs.add(std::numeric_limits<double>::infinity()); } catch(const std::invalid_argument&) {}
        if (rs.count() == 0 && caught) passed++; else failed++;
    }

    // Test 5: MergeEmptyNoOp
    {
        RunningStats rs;
        rs.add(1.0);
        rs.add(2.0);
        RunningStats empty;
        rs.merge(empty);
        if (rs.count() == 2 && std::abs(rs.mean() - 1.5) < 1e-9) passed++; else failed++;
    }

    // Test 6: MergeIntoEmpty
    {
        RunningStats rs1;
        RunningStats rs2;
        rs2.add(1.0);
        rs2.add(2.0);
        rs1.merge(rs2);
        if (rs1.count() == 2 && std::abs(rs1.mean() - 1.5) < 1e-9) passed++; else failed++;
    }

    // Test 7: SelfMerge
    {
        RunningStats rs;
        rs.add(1.0);
        rs.add(2.0);
        rs.merge(rs);
        if (rs.count() == 4 && std::abs(rs.mean() - 1.5) < 1e-9 && std::abs(rs.variance() - 0.25) < 1e-9) passed++; else failed++;
    }

    // Test 8: LargeValues
    {
        RunningStats rs;
        for (int i = 0; i < 42; i++) {
            rs.add(1e9 + i);
        }
        double m = rs.mean();
        double v = rs.variance();
        if (rs.count() == 42 && 
            std::abs(m - (1e9 + 20.5)) < 1e-4 &&
            std::abs(v - 147.91666666666666) < 1e-4) passed++; else failed++;
    }

    std::cout << "Passed: " << passed << ", Failed: " << failed << std::endl;
    return failed > 0 ? 1 : 0;
}
