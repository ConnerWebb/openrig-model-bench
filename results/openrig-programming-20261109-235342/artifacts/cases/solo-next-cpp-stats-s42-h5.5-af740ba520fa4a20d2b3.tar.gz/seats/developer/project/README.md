# RunningStats C++ Library

A C++20 library implementing a numerically stable running statistics calculator using online algorithms.

## Features

- Add values one at a time with `add(double)`
- Merge two `RunningStats` instances with `merge(const RunningStats&)`
- Query statistics: `count()`, `mean()`, `variance()`, `minimum()`, `maximum()`
- Rejects NaN and infinity with `std::invalid_argument`
- Throws `std::domain_error` for empty stats queries
- Numerically stable for large values (offset ~1e9)

## API

```cpp
class RunningStats {
public:
    void add(double x);                    // Add a value (rejects NaN/infinity)
    void merge(const RunningStats& other); // Merge another stats instance
    std::uint64_t count() const;           // Number of values
    double mean() const;                   // Population mean
    double variance() const;               // Population variance
    double minimum() const;                // Minimum value
    double maximum() const;                // Maximum value
};
```

## Building

```bash
mkdir build && cd build
cmake .. -DCMAKE_CXX_FLAGS="-std=c++20 -fuse-ld=bfd"
make
```

## Testing

```bash
cd build
ctest
```
