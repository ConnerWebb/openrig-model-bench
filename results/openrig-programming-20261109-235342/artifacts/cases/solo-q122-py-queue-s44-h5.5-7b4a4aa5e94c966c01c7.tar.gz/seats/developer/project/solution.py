import sqlite3
import json
import time

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()
    
    def _init_db(self):
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT NOT NULL DEFAULT 'queued',
                attempts INTEGER NOT NULL DEFAULT 0,
                owner TEXT,
                lease_until REAL,
                inserted_at REAL NOT NULL DEFAULT (strftime('%s', 'now'))
            )
        ''')
        conn.commit()
        conn.close()
    
    def enqueue(self, key, payload):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        # First unique key wins - check if key exists
        cursor.execute('SELECT key FROM jobs WHERE key = ?', (key,))
        if cursor.fetchone() is not None:
            conn.close()
            return False
        payload_json = json.dumps(payload)
        cursor.execute('''
            INSERT INTO jobs (key, payload, state, attempts, inserted_at)
            VALUES (?, ?, 'queued', 0, ?)
        ''', (key, payload_json, time.time()))
        conn.commit()
        conn.close()
        return True
    
    def claim(self, worker, now, lease):
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # First, mark expired final-attempt jobs as failed (commit this separately)
        cursor.execute('''
            UPDATE jobs SET state = 'failed'
            WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?
        ''', (now, self.max_attempts))
        conn.commit()
        
        # Now start a new transaction to claim a job
        cursor.execute('BEGIN IMMEDIATE')
        
        # Find oldest queued or expired leased job with attempts < max_attempts
        cursor.execute('''
            SELECT key, payload, attempts, inserted_at
            FROM jobs
            WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
              AND attempts < ?
            ORDER BY inserted_at ASC
            LIMIT 1
        ''', (now, self.max_attempts))
        
        row = cursor.fetchone()
        if row is None:
            conn.rollback()
            conn.close()
            return None
        
        key, payload_json, attempts, _ = row
        new_attempts = attempts + 1
        lease_until = now + lease
        
        cursor.execute('''
            UPDATE jobs
            SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
            WHERE key = ?
        ''', (worker, lease_until, new_attempts, key))
        
        conn.commit()
        conn.close()
        
        return {
            'key': key,
            'payload': json.loads(payload_json),
            'attempts': new_attempts
        }
    
    def complete(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check if job is leased to this worker
        cursor.execute('''
            SELECT state, owner FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        
        if row is None:
            conn.close()
            return False
        
        state, owner = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        cursor.execute('''
            UPDATE jobs SET state = 'done' WHERE key = ?
        ''', (key,))
        
        conn.commit()
        conn.close()
        return True
    
    def fail(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        # Check if job is leased to this worker
        cursor.execute('''
            SELECT state, owner, attempts FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        
        if row is None:
            conn.close()
            return False
        
        state, owner, attempts = row
        if state != 'leased' or owner != worker:
            conn.close()
            return False
        
        # If attempts exhausted, mark as failed, else requeue
        if attempts >= self.max_attempts:
            cursor.execute('''
                UPDATE jobs SET state = 'failed' WHERE key = ?
            ''', (key,))
        else:
            cursor.execute('''
                UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?
            ''', (key,))
        
        conn.commit()
        conn.close()
        return True
    
    def status(self, key):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT state, attempts FROM jobs WHERE key = ?
        ''', (key,))
        row = cursor.fetchone()
        
        conn.close()
        
        if row is None:
            return None
        
        state, attempts = row
        return {'state': state, 'attempts': attempts}
