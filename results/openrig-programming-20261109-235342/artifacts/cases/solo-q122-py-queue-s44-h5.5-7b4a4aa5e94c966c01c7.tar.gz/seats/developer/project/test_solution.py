import unittest
import tempfile
import pathlib
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = str(pathlib.Path(self.temp_dir) / 'test.db')
        self.q = JobQueue(self.db_path, max_attempts=3)
    
    def test_enqueue_first_wins(self):
        self.assertTrue(self.q.enqueue('key1', {'data': 1}))
        self.assertFalse(self.q.enqueue('key1', {'data': 2}))
        status = self.q.status('key1')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)
    
    def test_claim_basic(self):
        self.q.enqueue('a', {'v': 5304})
        result = self.q.claim('w', 0, 5)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['payload'], {'v': 5304})
        self.assertEqual(result['attempts'], 1)
    
    def test_claim_no_available_jobs(self):
        result = self.q.claim('w', 0, 5)
        self.assertIsNone(result)
    
    def test_claim_expired_leased_job(self):
        self.q.enqueue('a', {'v': 1})
        # Manually set a leased job with expired lease
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        conn.execute("UPDATE jobs SET state='leased', owner='w', lease_until=0, attempts=1 WHERE key='a'")
        conn.commit()
        conn.close()
        
        # Now claim should pick it up since lease is expired
        result = self.q.claim('w2', 10, 5)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['attempts'], 2)
    
    def test_complete_success(self):
        self.q.enqueue('a', {'v': 1})
        self.q.claim('w', 0, 5)
        self.assertTrue(self.q.complete('a', 'w'))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'done')
    
    def test_complete_wrong_worker(self):
        self.q.enqueue('a', {'v': 1})
        self.q.claim('w', 0, 5)
        self.assertFalse(self.q.complete('a', 'wrong'))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'leased')
    
    def test_fail_requeue(self):
        self.q.enqueue('a', {'v': 1})
        self.q.claim('w', 0, 5)
        self.assertTrue(self.q.fail('a', 'w'))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 1)
    
    def test_fail_exhausted_attempts(self):
        self.q = JobQueue(self.db_path, max_attempts=2)
        self.q.enqueue('a', {'v': 1})
        self.q.claim('w', 0, 5)  # attempts=1
        self.q.fail('a', 'w')     # back to queued, attempts=1
        self.q.claim('w', 1, 5)   # attempts=2
        self.assertTrue(self.q.fail('a', 'w'))  # should become failed
        status = self.q.status('a')
        self.assertEqual(status['state'], 'failed')
    
    def test_status_nonexistent(self):
        self.assertIsNone(self.q.status('nonexistent'))
    
    def test_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)
    
    def test_invalid_key(self):
        with self.assertRaises(ValueError):
            self.q.enqueue('', {'data': 1})
    
    def test_invalid_worker(self):
        with self.assertRaises(ValueError):
            self.q.claim('', 0, 5)
    
    def test_invalid_lease(self):
        with self.assertRaises(ValueError):
            self.q.claim('w', 0, 0)
        with self.assertRaises(ValueError):
            self.q.claim('w', 0, -1)

if __name__ == '__main__':
    unittest.main()
