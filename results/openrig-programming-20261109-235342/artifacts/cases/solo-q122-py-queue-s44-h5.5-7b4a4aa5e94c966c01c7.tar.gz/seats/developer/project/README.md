# JobQueue Implementation

A SQLite-based job queue implementation with support for claiming, completing, and failing jobs.

## Features

- **Enqueue**: Add jobs with unique keys (first insertion wins)
- **Claim**: Atomically claim the oldest available job (queued or expired leased)
- **Complete**: Mark a leased job as done
- **Fail**: Requeue a job or mark as failed if max attempts exceeded
- **Status**: Query job state and attempt count

## API

```python
class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3)
    def enqueue(self, key: str, payload: any) -> bool
    def claim(self, worker: str, now: float, lease: float) -> dict | None
    def complete(self, key: str, worker: str) -> bool
    def fail(self, key: str, worker: str) -> bool
    def status(self, key: str) -> dict | None
```

## State Machine

- **queued**: Initial state, available for claiming
- **leased**: Job claimed by a worker, has lease_until timestamp
- **done**: Job completed successfully
- **failed**: Job exhausted all attempts

## Concurrency

Multiple instances/processes can share the same database. The implementation uses SQLite's atomic operations to prevent lost or duplicate claims.

## Running Tests

```bash
python -m unittest test_solution.py
```
