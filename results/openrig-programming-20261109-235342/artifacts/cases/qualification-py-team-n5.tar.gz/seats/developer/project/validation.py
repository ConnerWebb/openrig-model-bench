def normalize(records):
    out = []
    for r in records:
        if not isinstance(r, dict) or set(r) != {'id', 'category', 'cents', 'rejected'} or not isinstance(r['id'], str) or not r['id'].strip() or not isinstance(r['category'], str) or not r['category'].strip() or type(r['cents']) != int or r['cents'] < 0 or type(r['rejected']) != bool:
            raise ValueError('record')
        out.append({'id': r['id'].strip(), 'category': r['category'].strip(), 'cents': r['cents'], 'rejected': r['rejected']})
    return out
