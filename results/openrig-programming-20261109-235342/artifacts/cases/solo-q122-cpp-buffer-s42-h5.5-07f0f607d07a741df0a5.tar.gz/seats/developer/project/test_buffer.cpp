#include <iostream>
#include <cassert>
#include <stdexcept>
#include <cstdint>
#include <cstddef>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    Buffer b(a);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == a[i]);
    }
    
    // Modify copy, original unchanged
    b[0] = 99;
    assert(a[0] == 1);
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == a[i]);
    }
    
    // Modify copy, original unchanged
    b[0] = 99;
    assert(a[0] == 1);
    std::cout << "test_copy_assignment passed\n";
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    Buffer b(std::move(a));
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == (i + 1));
    }
    assert(a.size() == 0);
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    Buffer b(3);
    b = std::move(a);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == (i + 1));
    }
    assert(a.size() == 0);
    std::cout << "test_move_assignment passed\n";
}

void test_move_noexcept() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>, "Move constructor should be noexcept");
    static_assert(std::is_nothrow_move_assignable_v<Buffer>, "Move assignment should be noexcept");
    std::cout << "test_move_noexcept passed\n";
}

void test_bounds_check() {
    Buffer b(5);
    try {
        (void)b[5];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    try {
        (void)b[100];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    // Const version
    const Buffer cb(5);
    try {
        (void)cb[5];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "test_bounds_check passed\n";
}

void test_resize_expand() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
    std::cout << "test_resize_expand passed\n";
}

void test_resize_shrink() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    std::cout << "test_resize_shrink passed\n";
}

void test_resize_same_size() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    std::cout << "test_resize_same_size passed\n";
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
    std::cout << "test_self_copy passed\n";
}

void test_self_move() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
    std::cout << "test_self_move passed\n";
}

void test_moved_from_reusable() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    Buffer b(std::move(a));
    assert(a.size() == 0);
    
    // Reuse moved-from buffer
    a.resize(3);
    assert(a.size() == 3);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    assert(a[0] == 10);
    assert(a[1] == 20);
    assert(a[2] == 30);
    std::cout << "test_moved_from_reusable passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_move_noexcept();
    test_bounds_check();
    test_resize_expand();
    test_resize_shrink();
    test_resize_same_size();
    test_self_copy();
    test_self_move();
    test_moved_from_reusable();
    
    std::cout << "All tests passed!\n";
    return 0;
}
