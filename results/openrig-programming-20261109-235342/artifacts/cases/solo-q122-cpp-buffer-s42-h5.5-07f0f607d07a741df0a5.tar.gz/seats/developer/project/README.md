# Buffer Library

A C++20 buffer implementation with RAII, deep copy semantics, and noexcept move operations.

## Features

- **RAII**: Automatic resource management with proper destructor
- **Deep Copy**: Copy constructor and assignment perform deep copies
- **Noexcept Move**: Move operations are noexcept and leave moved-from objects in a valid, reusable state (size 0)
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for out-of-bounds access
- **Resize**: Preserves prefix content and zero-initializes new elements

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized.

### Destructor
```cpp
~Buffer();
```
Releases allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy semantics.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Noexcept move semantics. Moved-from buffer has size 0 and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
Bounds-checked element access. Throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes buffer to `k` bytes, preserving existing prefix and zero-initializing new bytes.

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

## Testing

Run the provided test suite:
```bash
./test_buffer
```

All tests verify:
- Default and sized construction
- Deep copy semantics
- Noexcept move semantics
- Bounds checking
- Resize behavior (expand, shrink, same size)
- Self-copy and self-move safety
- Moved-from buffer reusability
