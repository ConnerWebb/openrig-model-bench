"""Tests for solution.py evaluate() function."""

import unittest
from solution import evaluate, ExpressionError


class TestEvaluate(unittest.TestCase):
    """Test cases for evaluate()."""

    def test_simple_addition(self):
        self.assertEqual(evaluate("1 + 2"), 3)
        self.assertEqual(evaluate("10 + 20"), 30)

    def test_simple_subtraction(self):
        self.assertEqual(evaluate("5 - 3"), 2)
        self.assertEqual(evaluate("10 - 20"), -10)

    def test_simple_multiplication(self):
        self.assertEqual(evaluate("3 * 4"), 12)
        self.assertEqual(evaluate("6 * 7"), 42)

    def test_simple_division(self):
        self.assertEqual(evaluate("10 // 3"), 3)
        self.assertEqual(evaluate("9 // 3"), 3)

    def test_precedence(self):
        self.assertEqual(evaluate("2 + 3 * 4"), 14)
        self.assertEqual(evaluate("10 - 2 * 3"), 4)

    def test_parentheses(self):
        self.assertEqual(evaluate("(2 + 3) * 4"), 20)
        self.assertEqual(evaluate("2 * (3 + 4)"), 14)

    def test_unary_plus(self):
        self.assertEqual(evaluate("+5"), 5)
        self.assertEqual(evaluate("+(2 + 3)"), 5)

    def test_unary_minus(self):
        self.assertEqual(evaluate("-5"), -5)
        self.assertEqual(evaluate("-(2 + 3)"), -5)

    def test_negative_numbers(self):
        self.assertEqual(evaluate("-5 + 3"), -2)
        self.assertEqual(evaluate("5 + -3"), 2)

    def test_floor_division_with_negatives(self):
        # Python floor division: -7 // 3 = -3 (not -2)
        self.assertEqual(evaluate("-7 // 3"), -3)
        self.assertEqual(evaluate("7 // -3"), -3)
        self.assertEqual(evaluate("-7 // -3"), 2)

    def test_whitespace(self):
        self.assertEqual(evaluate("  1 + 2  "), 3)
        self.assertEqual(evaluate("  (  1 + 2 )  "), 3)

    def test_public_cases(self):
        self.assertEqual(evaluate("(-18 + 30) * 3 // (58)"), 0)
        self.assertEqual(evaluate("(-98 + -33) * 3 // (-61)"), 6)
        self.assertEqual(evaluate("(93 + -49) * 3 // (-33)"), -4)

    def test_chained_operations(self):
        self.assertEqual(evaluate("1 + 2 + 3 + 4"), 10)
        self.assertEqual(evaluate("100 - 50 - 25"), 25)

    def test_nested_parentheses(self):
        self.assertEqual(evaluate("((1 + 2))"), 3)
        self.assertEqual(evaluate("(((1 + 2) * 3))"), 9)

    def test_large_numbers(self):
        self.assertEqual(evaluate("1000000000000000000000000000000 * 2"), 2 * 10**30)

    def test_complex_expression(self):
        self.assertEqual(evaluate("(1 + 2) * (3 + 4) - 5"), 16)

    def test_division_by_zero(self):
        with self.assertRaises(ValueError):
            evaluate("1 // 0")
        with self.assertRaises(ValueError):
            evaluate("5 / 0")  # / is not supported, but // 0 should fail

    def test_unmatched_parentheses(self):
        with self.assertRaises(ValueError):
            evaluate("(1 + 2")
        with self.assertRaises(ValueError):
            evaluate("1 + 2)")

    def test_invalid_characters(self):
        with self.assertRaises(ValueError):
            evaluate("1 + a")
        with self.assertRaises(ValueError):
            evaluate("1 + 2.5")

    def test_leading_zeros(self):
        with self.assertRaises(ValueError):
            evaluate("01 + 2")
        with self.assertRaises(ValueError):
            evaluate("007")

    def test_zero_is_valid(self):
        self.assertEqual(evaluate("0"), 0)
        self.assertEqual(evaluate("0 + 0"), 0)

    def test_length_limit(self):
        with self.assertRaises(ValueError):
            evaluate("1" * 4097)

    def test_token_too_long(self):
        with self.assertRaises(ValueError):
            evaluate("1" * 51)

    def test_deep_nesting(self):
        # Test that depth > 100 raises
        expr = "(" * 101 + "1" + ")" * 101
        with self.assertRaises(ValueError):
            evaluate(expr)

    def test_result_magnitude_limit(self):
        # Result magnitude > 10**100 should raise
        expr = "10**101"
        with self.assertRaises(ValueError):
            evaluate(expr)


if __name__ == "__main__":
    unittest.main()
