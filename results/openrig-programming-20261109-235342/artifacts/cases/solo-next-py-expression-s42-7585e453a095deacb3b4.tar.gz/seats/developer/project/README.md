# Integer Arithmetic Expression Evaluator

This module provides an `evaluate(text: str) -> int` function that evaluates integer arithmetic expressions.

## Supported Features

- **Operators**: `+`, `-`, `*`, `//` (addition, subtraction, multiplication, floor division)
- **Precedence**: Standard mathematical precedence (parentheses > unary +/- > * // > + -)
- **Parentheses**: For grouping subexpressions
- **Unary operators**: `+` and `-` prefix operators
- **Whitespace**: Allowed anywhere

## Constraints

The evaluator enforces the following constraints:

1. Input text length must not exceed 4096 characters
2. Integer tokens must not exceed 50 digits
3. Expression nesting depth must not exceed 100
4. Intermediate and final result magnitudes must not exceed 10^100
5. Division by zero raises an error
6. Leading zeros in integer tokens are rejected (except "0" itself)
7. No floats, booleans, variables, or external functions allowed

## Floor Division

The evaluator uses Python's floor division semantics:
- `-7 // 3 = -3` (not -2)
- `7 // -3 = -3`
- `-7 // -3 = 2`

## Usage

```python
from solution import evaluate

# Basic operations
evaluate("1 + 2")        # 3
evaluate("10 - 3")       # 7
evaluate("4 * 5")        # 20
evaluate("10 // 3")      # 3

# Precedence
evaluate("2 + 3 * 4")    # 14 (not 20)

# Parentheses
evaluate("(2 + 3) * 4")  # 20

# Unary operators
evaluate("-5")           # -5
evaluate("+(2 + 3)")     # 5

# Negative numbers
evaluate("-7 // 3")      # -3
```

## Error Handling

All errors raise `ValueError` (via `ExpressionError`):

- `ExpressionError`: Invalid syntax, unsupported characters, unmatched parentheses
- `ValueError`: Result magnitude too large

## Testing

Run tests with:
```bash
python3 -m unittest test_solution
```
