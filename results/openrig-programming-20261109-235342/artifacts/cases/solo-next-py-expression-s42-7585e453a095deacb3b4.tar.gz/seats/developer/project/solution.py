"""Integer arithmetic expression evaluator.

Supports +, -, *, //, parentheses, unary +/- with normal precedence.
Follows Python floor division semantics for negatives.
"""

import re
from typing import List, Tuple, Union


class ExpressionError(ValueError):
    """Raised for invalid expressions."""
    pass


def _raise_error(msg: str) -> None:
    """Raise ValueError for public API."""
    raise ValueError(msg)


class Tokenizer:
    """Tokenizes an arithmetic expression."""

    TOKEN_PATTERN = re.compile(
        r'(\d+)|'
        r'(\+)|'
        r'(-)|'
        r'(\*)|'
        r'(//)|'
        r'(\()|'
        r'(\))|'
        r'(\s+)'
    )

    def __init__(self, text: str):
        if len(text) > 4096:
            _raise_error("Input text too long")
        self.text = text
        self.pos = 0
        self.tokens: List[Tuple[str, int, int]] = []  # (type, value, start_pos)

    def tokenize(self) -> List[Tuple[str, Union[int, str], int]]:
        """Return list of (token_type, value, start_position)."""
        while self.pos < len(self.text):
            match = self.TOKEN_PATTERN.match(self.text, self.pos)
            if not match:
                _raise_error(f"Unexpected character at position {self.pos}")
            self.pos = match.end()
            # Check which group matched
            if match.group(1):  # integer
                token = match.group(1)
                # Check for leading zeros (except "0" itself)
                if len(token) > 1 and token[0] == '0':
                    _raise_error("Leading zero in integer")
                # Check digit count
                if len(token) > 50:
                    _raise_error("Integer token too long")
                self.tokens.append(('INT', int(token), match.start()))
            elif match.group(2):  # +
                self.tokens.append(('PLUS', '+', match.start()))
            elif match.group(3):  # -
                self.tokens.append(('MINUS', '-', match.start()))
            elif match.group(4):  # *
                self.tokens.append(('STAR', '*', match.start()))
            elif match.group(5):  # //
                self.tokens.append(('DIV', '//', match.start()))
            elif match.group(6):  # (
                self.tokens.append(('LPAREN', '(', match.start()))
            elif match.group(7):  # )
                self.tokens.append(('RPAREN', ')', match.start()))
            # match.group(8) is whitespace - skip it
        return self.tokens


class Parser:
    """Recursive descent parser for arithmetic expressions."""

    def __init__(self, tokens: List[Tuple[str, Union[int, str], int]]):
        self.tokens = tokens
        self.pos = 0
        self.max_depth = 0
        self.current_depth = 0

    def peek(self) -> Tuple[str, Union[int, str], int]:
        """Return current token or raise if at end."""
        if self.pos >= len(self.tokens):
            _raise_error("Unexpected end of expression")
        return self.tokens[self.pos]

    def consume(self, expected_type: str = None) -> Tuple[str, Union[int, str], int]:
        """Consume and return current token."""
        token = self.peek()
        if expected_type and token[0] != expected_type:
            _raise_error(f"Expected {expected_type}, got {token[0]}")
        self.pos += 1
        return token

    def parse(self) -> int:
        """Parse and evaluate the expression."""
        result = self.parse_expr()
        if self.pos < len(self.tokens):
            _raise_error(f"Unexpected token after expression: {self.tokens[self.pos][0]}")
        return result

    def parse_expr(self) -> int:
        """Parse addition and subtraction (lowest precedence)."""
        result = self.parse_term()
        while self.pos < len(self.tokens):
            token = self.peek()
            if token[0] == 'PLUS':
                self.consume()
                result = result + self.parse_term()
            elif token[0] == 'MINUS':
                self.consume()
                result = result - self.parse_term()
            else:
                break
        return result

    def parse_term(self) -> int:
        """Parse multiplication and division."""
        result = self.parse_unary()
        while self.pos < len(self.tokens):
            token = self.peek()
            if token[0] == 'STAR':
                self.consume()
                result = result * self.parse_unary()
            elif token[0] == 'DIV':
                self.consume()
                divisor = self.parse_unary()
                if divisor == 0:
                    _raise_error("Division by zero")
                # Python floor division for negatives
                result = result // divisor
            else:
                break
        return result

    def parse_unary(self) -> int:
        """Parse unary + and -."""
        token = self.peek()
        if token[0] == 'PLUS':
            self.consume()
            return +self.parse_unary()
        elif token[0] == 'MINUS':
            self.consume()
            return -self.parse_unary()
        return self.parse_primary()

    def parse_primary(self) -> int:
        """Parse integers and parenthesized expressions."""
        token = self.peek()
        if token[0] == 'INT':
            self.consume()
            return token[1]
        elif token[0] == 'LPAREN':
            self.current_depth += 1
            self.max_depth = max(self.max_depth, self.current_depth)
            if self.current_depth > 100:
                _raise_error("Expression too deeply nested")
            self.consume()
            result = self.parse_expr()
            if self.peek()[0] != 'RPAREN':
                _raise_error("Missing closing parenthesis")
            self.consume()
            self.current_depth -= 1
            return result
        else:
            _raise_error(f"Unexpected token: {token[0]}")


def evaluate(text: str) -> int:
    """Evaluate an integer arithmetic expression.

    Args:
        text: The expression to evaluate.

    Returns:
        The integer result of the expression.

    Raises:
        ValueError: For invalid expressions or violations of constraints.
    """
    tokenizer = Tokenizer(text)
    tokens = tokenizer.tokenize()

    parser = Parser(tokens)
    result = parser.parse()

    # Check result magnitude
    if abs(result) > 10**100:
        _raise_error("Result magnitude too large")

    return result
