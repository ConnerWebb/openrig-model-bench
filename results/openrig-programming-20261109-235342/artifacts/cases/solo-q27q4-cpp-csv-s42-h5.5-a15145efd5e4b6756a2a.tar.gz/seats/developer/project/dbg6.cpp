#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    // Test various record formats
    auto test = [](const std::string& rec) {
        std::string f0, f1;
        try {
            parse_record(rec, f0, f1);
            std::cout << "[" << rec << "] -> [" << f0 << "] [" << f1 << "]\n";
        } catch(const std::exception& e) {
            std::cout << "[" << rec << "] EXC: " << e.what() << "\n";
        }
    };
    test("\"x\"\"q\",9");
    test("\"x\"\"q\" ,9");
    test("\"x\"\"quote\",51268");
    test("\"a,b\",7");
    test("a,7");
    test("\"a\",7");
    test("a,\"7\"");
    test("\"a\",\"7\"");
    test("\"a\" ,\"7\"");
    test("\"a\" ,7");
    test("a ,\"7\"");
    test("a ,7");
    return 0;
}
