#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    std::istringstream in("category,amount\n\"a,b\",7\n");
    try { auto g = aggregate(in); std::cout << "OK " << g.size() << "\n"; }
    catch(const std::exception& e){ std::cout << "EXC: " << e.what() << "\n"; }
    // Manual parse_record test
    std::string f0, f1;
    try {
        parse_record("\"a,b\",7", f0, f1);
        std::cout << "PR OK: [" << f0 << "] [" << f1 << "]\n";
    } catch(const std::exception& e){ std::cout << "PR EXC: " << e.what() << "\n"; }
    return 0;
}
