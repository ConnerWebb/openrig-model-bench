#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    std::string rec = "category,amount";
    std::string f0, f1;
    parse_record(rec, f0, f1);
    std::cout << "hdr: [" << f0 << "] [" << f1 << "]\n";
    rec = "\"a,b\",7";
    parse_record(rec, f0, f1);
    std::cout << "row: [" << f0 << "] [" << f1 << "]\n";
    // Now simulate the full aggregate loop
    std::istringstream in("category,amount\n\"a,b\",7\n");
    std::string line, rec2;
    bool in_quotes = false;
    while (std::getline(in, line)) {
        std::cout << "LINE: [" << line << "] inq=" << in_quotes << "\n";
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (!line.empty() && line.front() == '"') in_quotes = !in_quotes;
        std::cout << "  after: inq=" << in_quotes << "\n";
        if (in_quotes) { rec2 += line; rec2 += '\n'; continue; }
        if (rec2.empty()) {
            if (!line.empty()) {
                std::cout << "  PROCESS: [" << line << "]\n";
                std::string a, b;
                parse_record(line, a, b);
                std::cout << "  -> [" << a << "] [" << b << "]\n";
            }
        } else {
            rec2 += line;
            std::cout << "  PROCESS rec: [" << rec2 << "]\n";
            std::string a, b;
            parse_record(rec2, a, b);
            std::cout << "  -> [" << a << "] [" << b << "]\n";
            rec2.clear();
        }
    }
    return 0;
}
