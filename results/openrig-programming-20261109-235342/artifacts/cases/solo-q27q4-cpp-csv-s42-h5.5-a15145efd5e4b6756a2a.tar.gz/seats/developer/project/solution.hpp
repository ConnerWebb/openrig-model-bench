// solution.hpp — header-only CSV aggregation (C++20)
//
// aggregate(std::istream&) parses a CSV with header "category,amount" and
// returns a std::map<std::string, std::int64_t> of summed amounts per
// category.  Quoted fields may contain commas, newlines and escaped double
// quotes.  Malformed input throws std::invalid_argument.

#pragma once
#include <algorithm>
#include <cstdint>
#include <istream>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>

namespace {

inline bool is_blank(char c) { return c == ' ' || c == '\t' || c == '\r'; }

inline std::string strip(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && is_blank(s[b])) ++b;
    while (e > b && is_blank(s[e - 1])) --e;
    return s.substr(b, e - b);
}

// Parse a signed base-10 int64.  No whitespace, decimals or exponents.
inline std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty amount");
    size_t i = 0;
    bool neg = false;
    if (s[0] == '+' || s[0] == '-') { neg = (s[0] == '-'); i = 1; }
    if (i >= s.size()) throw std::invalid_argument("bad amount");
    for (size_t k = i; k < s.size(); ++k)
        if (s[k] < '0' || s[k] > '9') throw std::invalid_argument("bad amount");
    // Accumulate as negative so INT64_MIN is representable.
    std::int64_t v = 0;
    for (size_t k = i; k < s.size(); ++k) {
        int d = s[k] - '0';
        if (v < -922337203685477580LL) throw std::invalid_argument("overflow");
        if (v < -9223372036854775807LL / 10) throw std::invalid_argument("overflow");
        v = v * 10 - d;
    }
    if (neg) {
        if (v < -9223372036854775807LL - 1) throw std::invalid_argument("overflow");
        return v;
    }
    if (v > 9223372036854775807LL) throw std::invalid_argument("overflow");
    return -v;
}

// Parse one logical record into exactly 2 fields.
// Handles quoted fields with embedded commas, newlines, escaped quotes.
// Whitespace between fields (after comma, before/after closing quote) is
// tolerated and stripped.
inline void parse_record(const std::string& rec, std::string& f0, std::string& f1) {
    size_t n = rec.size(), i = 0;
    auto skip_ws = [&]() { while (i < n && is_blank(rec[i])) ++i; };
    auto parse_field = [&](std::string& out) {
        out.clear();
        skip_ws();
        if (i < n && rec[i] == '"') {
            ++i;
            for (;;) {
                if (i >= n) throw std::invalid_argument("unterminated quote");
                char c = rec[i++];
                if (c == '"') {
                    if (i < n && rec[i] == '"') { out.push_back('"'); ++i; }
                    else break;
                } else out.push_back(c);
            }
        } else {
            while (i < n && rec[i] != ',') out.push_back(rec[i++]);
        }
    };
    parse_field(f0);
    skip_ws();
    if (i >= n) throw std::invalid_argument("missing field");
    if (rec[i] != ',') throw std::invalid_argument("bad record");
    ++i;
    parse_field(f1);
    skip_ws();
    if (i != n) throw std::invalid_argument("extra field");
}

// Count unescaped double-quotes in a line (a quote followed by another quote
// is an escaped pair and does not toggle state).
inline int count_unescaped_quotes(const std::string& line) {
    int cnt = 0;
    for (size_t i = 0; i < line.size(); ++i) {
        if (line[i] == '"') {
            ++cnt;
            if (i + 1 < line.size() && line[i + 1] == '"') ++i; // skip escaped pair
        }
    }
    return cnt;
}

} // namespace

inline std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::string line, rec;
    bool in_quotes = false;
    bool header_done = false;
    std::map<std::string, std::int64_t> out;

    auto process = [&](const std::string& r) {
        std::string f0, f1;
        parse_record(r, f0, f1);
        f0 = strip(f0);
        f1 = strip(f1);
        if (!header_done) {
            header_done = true;
            if (f0 != "category" || f1 != "amount")
                throw std::invalid_argument("bad header");
            return;
        }
        if (f0.empty()) throw std::invalid_argument("empty category");
        std::int64_t v = parse_int64(f1);
        auto& slot = out[f0];
        if ((v > 0 && slot > 0 && v > (std::numeric_limits<std::int64_t>::max)() - slot) ||
            (v < 0 && slot < 0 && v < (std::numeric_limits<std::int64_t>::min)() - slot))
            throw std::invalid_argument("accumulation overflow");
        slot += v;
    };

    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (count_unescaped_quotes(line) % 2 == 1) in_quotes = !in_quotes;
        if (in_quotes) { rec += line; rec += '\n'; continue; }
        if (rec.empty()) {
            if (!line.empty() &&
                !std::all_of(line.begin(), line.end(), [](char c) { return is_blank(c); }))
                process(line);
        } else {
            rec += line;
            process(rec);
            rec.clear();
        }
    }
    if (!rec.empty()) { process(rec); rec.clear(); }
    if (!header_done) throw std::invalid_argument("missing header");
    return out;
}
