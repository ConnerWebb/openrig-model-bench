#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    std::string rec = "\"x\"\"q\",9";
    std::string f0, f1;
    parse_record(rec, f0, f1);
    std::cout << "PR: [" << f0 << "] [" << f1 << "]\n";
    // Test with a space after closing quote
    rec = "\"x\"\"q\" ,9";
    parse_record(rec, f0, f1);
    std::cout << "PR2: [" << f0 << "] [" << f1 << "]\n";
    // Test: what does the driver actually send?
    // The driver wraps the CSV in quotes and escapes inner quotes.
    // So the actual CSV text for "x""q" is: "x""q"
    // Let me check: does the CSV have a space after the closing quote?
    // Looking at case-00.csv: "x""quote",51268  (no space)
    // So the record is: "x""quote",51268
    // parse_record should give f0=x"quote, f1=51268
    rec = "\"x\"\"quote\",51268";
    parse_record(rec, f0, f1);
    std::cout << "PR3: [" << f0 << "] [" << f1 << "]\n";
    return 0;
}
