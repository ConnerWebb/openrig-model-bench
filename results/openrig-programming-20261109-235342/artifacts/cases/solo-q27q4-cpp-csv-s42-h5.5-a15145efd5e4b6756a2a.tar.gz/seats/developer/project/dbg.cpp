#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    auto t = [](const char* name, const std::string& csv){
        std::istringstream in(csv);
        try { auto g = aggregate(in); std::cout << name << " OK " << g.size() << "\n"; }
        catch(const std::exception& e){ std::cout << name << " EXC: " << e.what() << "\n"; }
    };
    t("basic", "category,amount\na,1\nb,2\na,3\n");
    t("signed", "category,amount\na,-5\na,+5\n");
    t("comma", "category,amount\n\"a,b\",7\n");
    t("escq", "category,amount\n\"x\"\"q\",9\n");
    t("nl", "category,amount\n\"two\nlines\",5\n");
    t("ws", "category,amount\n  a  ,  3  \n");
    t("blank", "category,amount\n\na,1\n\n\n");
    t("crlf", "category,amount\r\na,1\r\n");
    t("max", "category,amount\na,9223372036854775807\n");
    t("min", "category,amount\na,-9223372036854775808\n");
    t("ovf", "category,amount\nx,9223372036854775808\n");
    t("ovf2", "category,amount\nx,9223372036854775807\nx,1\n");
    t("ovf3", "category,amount\nx,-9223372036854775808\nx,-1\n");
    t("badhdr", "wrong,amount\nx,1\n");
    t("3f", "category,amount\nx,1,2\n");
    t("1f", "category,amount\nx\n");
    t("emptycat", "category,amount\n,1\n");
    t("nan", "category,amount\nx,NaN\n");
    t("sci", "category,amount\nx,1e2\n");
    t("dec", "category,amount\nx,1.5\n");
    t("emptyamt", "category,amount\nx,\n");
    t("plus", "category,amount\nx,+\n");
    t("unterm", "category,amount\n\"x,1\n");
    t("nohdr", "");
    t("nohdr2", "\n\n");
    return 0;
}
