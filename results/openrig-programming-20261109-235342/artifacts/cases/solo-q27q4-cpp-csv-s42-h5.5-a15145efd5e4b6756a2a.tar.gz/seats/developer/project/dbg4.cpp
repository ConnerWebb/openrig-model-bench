#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    std::string line = "\"a,b\",7";
    bool in_quotes = false;
    if (!line.empty() && line.front() == '"') in_quotes = !in_quotes;
    std::cout << "after front check: inq=" << in_quotes << "\n";
    // Now count quotes
    int count = 0;
    for (char c : line) if (c == '"') count++;
    std::cout << "total quotes: " << count << "\n";
    // Simulate the actual loop logic
    in_quotes = false;
    if (!line.empty() && line.front() == '"') in_quotes = !in_quotes;
    std::cout << "loop sim: inq=" << in_quotes << "\n";
    // The issue: the line starts with " but the quote is part of a quoted field
    // The front-of-line check is wrong. We need to count ALL quotes.
    // Let's verify: "a,b",7 has 4 quotes (even) -> should NOT be in quotes
    // But the front check says in_quotes=true because line starts with "
    // This is the bug!
    return 0;
}
