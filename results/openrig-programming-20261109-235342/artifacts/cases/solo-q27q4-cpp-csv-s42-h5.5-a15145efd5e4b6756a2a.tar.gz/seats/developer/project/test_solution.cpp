// Standalone test for solution.hpp (C++20).
#include "solution.hpp"
#include <iostream>
#include <sstream>
#include <stdexcept>

static int failures = 0;

static void expect_value(const std::string& csv,
                         const std::map<std::string, std::int64_t>& want) {
    std::istringstream in(csv);
    try {
        auto got = aggregate(in);
        if (got != want) {
            ++failures;
            std::cerr << "FAIL value: got " << got.size() << " entries\n";
        }
    } catch (const std::exception& e) {
        ++failures;
        std::cerr << "FAIL unexpected exception: " << e.what() << "\n";
    }
}

static void expect_error(const std::string& csv) {
    std::istringstream in(csv);
    try {
        auto got = aggregate(in);
        ++failures;
        std::cerr << "FAIL expected error, got " << got.size() << " entries\n";
    } catch (const std::exception&) {
        // ok
    }
}

int main() {
    // Basic aggregation.
    expect_value("category,amount\na,1\nb,2\na,3\n",
                 {{"a", 4}, {"b", 2}});

    // Negative and signed values.
    expect_value("category,amount\na,-5\na,+5\n", {{"a", 0}});

    // Quoted category with comma.
    expect_value("category,amount\n\"a,b\",7\n", {{"a,b", 7}});

    // Quoted category with escaped quote.
    expect_value("category,amount\n\"x\"\"q\",9\n", {{"x\"q", 9}});

    // Quoted category with embedded newline.
    expect_value("category,amount\n\"two\nlines\",5\n", {{"two\nlines", 5}});

    // Whitespace stripping around fields.
    expect_value("category,amount\n  a  ,  3  \n", {{"a", 3}});

    // Empty physical records ignored.
    expect_value("category,amount\n\na,1\n\n\n", {{"a", 1}});

    // CRLF line endings.
    expect_value("category,amount\r\na,1\r\n", {{"a", 1}});

    // Boundary int64 values.
    expect_value("category,amount\na,9223372036854775807\n",
                 {{"a", 9223372036854775807LL}});
    expect_value("category,amount\na,-9223372036854775808\n",
                 {{"a", (std::int64_t)(-(std::int64_t)9223372036854775807LL) - 1}});

    // Errors: bad header.
    expect_error("wrong,amount\nx,1\n");
    // Errors: wrong field count.
    expect_error("category,amount\nx,1,2\n");
    expect_error("category,amount\nx\n");
    // Errors: empty category.
    expect_error("category,amount\n,1\n");
    // Errors: bad amount.
    expect_error("category,amount\nx,NaN\n");
    expect_error("category,amount\nx,1e2\n");
    expect_error("category,amount\nx,1.5\n");
    expect_error("category,amount\nx,\n");
    expect_error("category,amount\nx,+\n");
    // Errors: overflow in parsing.
    expect_error("category,amount\nx,9223372036854775808\n");
    expect_error("category,amount\nx,-9223372036854775809\n");
    // Errors: accumulation overflow.
    expect_error("category,amount\nx,9223372036854775807\nx,1\n");
    expect_error("category,amount\nx,-9223372036854775808\nx,-1\n");
    // Errors: unterminated quote.
    expect_error("category,amount\n\"x,1\n");
    // Errors: missing header.
    expect_error("");
    expect_error("\n\n");

    if (failures == 0) {
        std::cout << "ALL TESTS PASSED\n";
        return 0;
    }
    std::cerr << failures << " test(s) failed\n";
    return 1;
}
