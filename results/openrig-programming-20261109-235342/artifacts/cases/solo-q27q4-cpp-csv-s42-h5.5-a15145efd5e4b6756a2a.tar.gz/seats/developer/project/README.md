# CSV Aggregation (C++20, header-only)

## Overview

`solution.hpp` provides a single function:

```cpp
std::map<std::string, std::int64_t> aggregate(std::istream& in);
```

It parses a CSV stream with the exact header `category,amount` and returns a
map from category to the sum of its amounts. Keys are returned in sorted
order (guaranteed by `std::map`).

## CSV grammar

- **Header**: the first non-empty logical record must be exactly
  `category,amount` (after stripping outer spaces/tabs/CR from each field).
- **Fields**: exactly two per record.
- **Quoting**: a field may be wrapped in double quotes. Inside a quoted
  field, commas, newlines, and doubled double-quotes (`""` → `"`) are
  allowed. An unterminated quote is an error.
- **Whitespace**: outer spaces, tabs, and CR are stripped from each field.
- **Empty records**: physical lines that are entirely blank are ignored.
- **Amount**: a signed base-10 `int64` integer. Optional leading `+` or `-`,
  then one or more digits. No decimals, exponents, or internal whitespace.
- **Category**: non-empty after stripping.

## Errors

The following conditions raise `std::invalid_argument` (any `std::exception`
is treated as an error by the driver):

- Wrong or missing header.
- Wrong field count (not exactly 2).
- Empty category.
- Malformed amount (non-digit, empty, `+`/`-` alone, decimals, exponents).
- Overflow while parsing an amount.
- Overflow while accumulating a category's total.
- Unterminated quoted field.

## Streaming

The parser reads the stream line by line and only buffers a logical record
while a quoted field spans multiple lines. It does not load the entire input
into memory.

## Build & test

```bash
clang++ -std=c++20 -O2 -fuse-ld=bfd test_solution.cpp -o test_solution
./test_solution
```

The public driver (`PUBLIC_DRIVER.cpp`) reads a quoted CSV string from stdin,
calls `aggregate`, and prints the result as JSON.
