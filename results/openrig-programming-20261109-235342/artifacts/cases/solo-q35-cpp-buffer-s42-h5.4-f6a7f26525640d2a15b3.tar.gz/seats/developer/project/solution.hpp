#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <stdexcept>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Default constructor
    Buffer(std::size_t n = 0) : p(n ? new std::uint8_t[n] : nullptr), n(n) {}

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p(other.n ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (p && other.p) {
            std::memcpy(p, other.p, n);
        }
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = other.n ? new std::uint8_t[other.n] : nullptr;
            delete[] p;
            p = new_p;
            n = other.n;
            if (p && other.p) {
                std::memcpy(p, other.p, n);
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Destructor
    ~Buffer() {
        delete[] p;
    }

    // Size
    std::size_t size() const noexcept {
        return n;
    }

    // Mutable operator[] with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const operator[] with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize with prefix preservation and zero-initialization
    void resize(std::size_t k) {
        if (k == n) return;
        
        std::uint8_t* new_p = k ? new std::uint8_t[k] : nullptr;
        
        if (p && k > 0) {
            std::size_t copy_len = (k < n) ? k : n;
            std::memcpy(new_p, p, copy_len);
        }
        
        // Zero-initialize new bytes if expanding
        if (k > n && new_p) {
            std::memset(new_p + n, 0, k - n);
        }
        
        delete[] p;
        p = new_p;
        n = k;
    }
};
