#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <cstring>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (size_t i = 0; i < 10; ++i) {
        b[i] = static_cast<uint8_t>(i);
    }
    for (size_t i = 0; i < 10; ++i) {
        assert(b[i] == static_cast<uint8_t>(i));
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i * 10);
    }
    Buffer b(a);
    assert(b.size() == 5);
    for (size_t i = 0; i < 5; ++i) {
        assert(b[i] == a[i]);
    }
    // Modify original, copy should be unchanged
    a[0] = 99;
    assert(b[0] != a[0]);
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i * 10);
    }
    Buffer b;
    b = a;
    assert(b.size() == 5);
    for (size_t i = 0; i < 5; ++i) {
        assert(b[i] == a[i]);
    }
    a[0] = 99;
    assert(b[0] != a[0]);
    std::cout << "test_copy_assignment passed\n";
}

void test_self_copy() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i);
    }
    a = a;
    assert(a.size() == 5);
    for (size_t i = 0; i < 5; ++i) {
        assert(a[i] == static_cast<uint8_t>(i));
    }
    std::cout << "test_self_copy passed\n";
}

void test_move_constructor() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i);
    }
    Buffer b(std::move(a));
    assert(b.size() == 5);
    for (size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<uint8_t>(i));
    }
    assert(a.size() == 0);
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i);
    }
    Buffer b;
    b = std::move(a);
    assert(b.size() == 5);
    for (size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<uint8_t>(i));
    }
    assert(a.size() == 0);
    std::cout << "test_move_assignment passed\n";
}

void test_self_move() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i);
    }
    a = std::move(a);
    assert(a.size() == 5);
    for (size_t i = 0; i < 5; ++i) {
        assert(a[i] == static_cast<uint8_t>(i));
    }
    std::cout << "test_self_move passed\n";
}

void test_resize_expand() {
    Buffer a(3);
    for (size_t i = 0; i < 3; ++i) {
        a[i] = static_cast<uint8_t>(i);
    }
    a.resize(5);
    assert(a.size() == 5);
    for (size_t i = 0; i < 3; ++i) {
        assert(a[i] == static_cast<uint8_t>(i));
    }
    assert(a[3] == 0);
    assert(a[4] == 0);
    std::cout << "test_resize_expand passed\n";
}

void test_resize_shrink() {
    Buffer a(5);
    for (size_t i = 0; i < 5; ++i) {
        a[i] = static_cast<uint8_t>(i);
    }
    a.resize(3);
    assert(a.size() == 3);
    for (size_t i = 0; i < 3; ++i) {
        assert(a[i] == static_cast<uint8_t>(i));
    }
    std::cout << "test_resize_shrink passed\n";
}

void test_bounds_check_mutable() {
    Buffer a(5);
    bool caught = false;
    try {
        (void)a[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    std::cout << "test_bounds_check_mutable passed\n";
}

void test_bounds_check_const() {
    const Buffer a(5);
    bool caught = false;
    try {
        (void)a[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    std::cout << "test_bounds_check_const passed\n";
}

void test_empty_buffer_resize() {
    Buffer a(0);
    a.resize(3);
    assert(a.size() == 3);
    for (size_t i = 0; i < 3; ++i) {
        assert(a[i] == 0);
    }
    std::cout << "test_empty_buffer_resize passed\n";
}

void test_noexcept_properties() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>, "Buffer must be nothrow move constructible");
    static_assert(std::is_nothrow_move_assignable_v<Buffer>, "Buffer must be nothrow move assignable");
    std::cout << "test_noexcept_properties passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy();
    test_move_constructor();
    test_move_assignment();
    test_self_move();
    test_resize_expand();
    test_resize_shrink();
    test_bounds_check_mutable();
    test_bounds_check_const();
    test_empty_buffer_resize();
    test_noexcept_properties();
    std::cout << "All tests passed!\n";
    return 0;
}
