# Buffer Library

A C++20 RAII buffer class for managing dynamically allocated arrays of `uint8_t` elements.

## Features

- **RAII management**: Automatic memory management with proper cleanup
- **Deep copy semantics**: Copy constructor and assignment operator perform deep copies
- **Move semantics**: Nothrow move constructor and assignment for efficient transfers
- **Bounds checking**: Both mutable and const `operator[]` throw `std::out_of_range` on invalid indices
- **Safe resizing**: `resize()` preserves existing data and zero-initializes new bytes
- **Self-assignment/self-move safe**: Handles self-copy and self-move operations correctly

## Interface

```cpp
class Buffer {
public:
    // Default constructor (empty buffer)
    Buffer(std::size_t n = 0);

    // Copy constructor (deep copy)
    Buffer(const Buffer& other);

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other);

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept;

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept;

    // Destructor
    ~Buffer();

    // Size query
    std::size_t size() const noexcept;

    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i);

    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const;

    // Resize with prefix preservation and zero-initialization
    void resize(std::size_t k);
};
```

## Usage Example

```cpp
#include "solution.hpp"
#include <iostream>

int main() {
    // Create buffer of size 5
    Buffer b(5);
    
    // Fill with values
    for (size_t i = 0; i < 5; ++i) {
        b[i] = static_cast<uint8_t>(i * 10);
    }
    
    // Copy buffer
    Buffer c = b;
    
    // Move buffer
    Buffer d = std::move(b);
    
    // Resize (expands with zero-initialization)
    d.resize(10);
    
    // Access with bounds checking
    try {
        uint8_t val = d[100]; // throws std::out_of_range
    } catch (const std::out_of_range& e) {
        std::cout << "Caught: " << e.what() << std::endl;
    }
    
    return 0;
}
```

## Testing

Run the tests with:
```bash
clang++ -std=c++20 -Wall -Wextra -o Buffer_test Buffer_test.cpp
./Buffer_test
```

The test suite covers:
- Default and sized construction
- Copy construction and assignment
- Move construction and assignment
- Self-assignment and self-move
- Resize operations (expand and shrink)
- Bounds checking for mutable and const access
- Nothrow move semantics
- Empty buffer handling

## Compliance

- C++20 standard
- RAII pattern for memory safety
- No memory leaks, double frees, or stale reads
- Proper exception safety for bounds violations
- No undefined behavior
