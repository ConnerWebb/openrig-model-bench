#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
}

void test_size_constructor() {
    Buffer b(10);
    assert(b.size() == 10);
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 10; a[1] = 20; a[2] = 30; a[3] = 40; a[4] = 50;
    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
    assert(b[3] == 40);
    assert(b[4] == 50);
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    assert(a.size() == 0);
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    Buffer b(3);
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    assert(b[4] == 5);
    assert(a.size() == 0);
}

void test_self_move() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 4);
    assert(a[4] == 5);
}

void test_resize_expand() {
    Buffer a(3);
    a[0] = 1; a[1] = 2; a[2] = 3;
    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 0);
    assert(a[4] == 0);
}

void test_resize_shrink() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
}

void test_resize_to_zero() {
    Buffer a(5);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4; a[4] = 5;
    a.resize(0);
    assert(a.size() == 0);
}

void test_bounds_check_mutable() {
    Buffer a(3);
    try {
        (void)a[3];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_bounds_check_const() {
    const Buffer a(3);
    try {
        (void)a[3];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

int main() {
    test_default_constructor();
    test_size_constructor();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy();
    test_move_constructor();
    test_move_assignment();
    test_self_move();
    test_resize_expand();
    test_resize_shrink();
    test_resize_to_zero();
    test_bounds_check_mutable();
    test_bounds_check_const();
    test_noexcept_move();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
