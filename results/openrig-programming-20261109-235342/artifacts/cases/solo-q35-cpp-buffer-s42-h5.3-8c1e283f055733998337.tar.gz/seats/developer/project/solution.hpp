#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Default constructor
    Buffer(std::size_t n = 0) : p(n > 0 ? new std::uint8_t[n] : nullptr), n(n) {}

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p(other.n > 0 ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (n > 0) {
            std::copy(other.p, other.p + n, p);
        }
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = other.n > 0 ? new std::uint8_t[other.n] : nullptr;
            delete[] p;
            p = new_p;
            n = other.n;
            if (n > 0) {
                std::copy(other.p, other.p + n, p);
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Destructor
    ~Buffer() {
        delete[] p;
    }

    // Size
    std::size_t size() const noexcept {
        return n;
    }

    // Mutable operator[] with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const operator[] with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize with prefix preservation and zero-initialization
    void resize(std::size_t k) {
        if (k == n) return;
        if (k == 0) {
            delete[] p;
            p = nullptr;
            n = 0;
            return;
        }
        std::uint8_t* new_p = new std::uint8_t[k];
        std::size_t copy_len = (k < n) ? k : n;
        if (copy_len > 0) {
            std::copy(p, p + copy_len, new_p);
        }
        // Zero-initialize new bytes
        for (std::size_t i = copy_len; i < k; ++i) {
            new_p[i] = 0;
        }
        delete[] p;
        p = new_p;
        n = k;
    }
};
