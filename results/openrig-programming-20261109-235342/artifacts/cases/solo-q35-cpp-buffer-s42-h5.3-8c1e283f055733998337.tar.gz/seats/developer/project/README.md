# Buffer Library

A C++20 RAII buffer class for managing dynamically allocated `uint8_t` arrays.

## Features

- **RAII**: Automatic memory management with constructor/destructor
- **Deep copy**: Copy constructor and assignment operator perform deep copies
- **Move semantics**: Noexcept move constructor and assignment operator
- **Bounds checking**: `operator[]` throws `std::out_of_range` for out-of-bounds access
- **Resize with preservation**: `resize()` preserves existing data and zero-initializes new bytes
- **Self-assignment safe**: Handles self-copy and self-move correctly
- **Empty buffer support**: Default constructor creates an empty buffer

## API

```cpp
class Buffer {
public:
    // Default constructor (empty buffer)
    Buffer(std::size_t n = 0);

    // Copy constructor (deep copy)
    Buffer(const Buffer& other);

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other);

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept;

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept;

    // Destructor
    ~Buffer();

    // Size
    std::size_t size() const noexcept;

    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i);

    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const;

    // Resize with prefix preservation and zero-initialization
    void resize(std::size_t k);
};
```

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // Create buffer of size 10
b[0] = 42;             // Set element (bounds checked)
Buffer c = b;          // Deep copy
Buffer d = std::move(b); // Move (b is now empty)
b.resize(20);          // Resize, preserving first 10 bytes, zero-filling new bytes
```

## Testing

Run the tests with:
```bash
clang++ -std=c++20 -o test solution_test.cpp solution.hpp
./test
```

## Compliance

- C++20 standard
- No memory leaks, double frees, or undefined behavior
- No stale reads
- Move operations are noexcept
- Self-assignment and self-move are handled correctly
