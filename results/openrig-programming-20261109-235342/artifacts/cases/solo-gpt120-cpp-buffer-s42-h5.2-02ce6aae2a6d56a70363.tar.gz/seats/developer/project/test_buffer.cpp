#include <cassert>
#include <iostream>
#include "solution.hpp"

int main() {
    // Default construction
    {
        Buffer buf;
        assert(buf.size() == 0);
        try { buf[0]; assert(false); } catch (const std::out_of_range&) {}
    }
    // Construction and access
    {
        Buffer buf(5);
        assert(buf.size() == 5);
        for (size_t i = 0; i < buf.size(); ++i) assert(buf[i] == 0);
        for (size_t i = 0; i < buf.size(); ++i) buf[i] = static_cast<std::uint8_t>(i+1);
        for (size_t i = 0; i < buf.size(); ++i) assert(buf[i] == static_cast<std::uint8_t>(i+1));
        try { buf[5]; assert(false); } catch (const std::out_of_range&) {}
    }
    // Copy construction
    {
        Buffer a(3);
        a[0]=10; a[1]=20; a[2]=30;
        Buffer b = a;
        assert(b.size()==3 && b[0]==10 && b[1]==20 && b[2]==30);
        b[1]=99; assert(a[1]==20);
    }
    // Copy assignment
    {
        Buffer a(2); a[0]=5;a[1]=6;
        Buffer b(4);
        b = a;
        assert(b.size()==2 && b[0]==5 && b[1]==6);
    }
    // Move construction
    {
        Buffer src(2); src[0]=7; src[1]=8;
        Buffer dst = std::move(src);
        assert(dst.size()==2 && dst[0]==7 && dst[1]==8);
        assert(src.size()==0);
        try { src[0]; assert(false); } catch (const std::out_of_range&) {}
    }
    // Move assignment
    {
        Buffer src(3); src[0]=1;src[1]=2;src[2]=3;
        Buffer dst(1);
        dst = std::move(src);
        assert(dst.size()==3 && dst[0]==1 && dst[1]==2 && dst[2]==3);
        assert(src.size()==0);
    }
    // Resize shrink
    {
        Buffer buf(4);
        for (size_t i=0;i<4;++i) buf[i]=static_cast<std::uint8_t>(i+1);
        buf.resize(2);
        assert(buf.size()==2 && buf[0]==1 && buf[1]==2);
        try { buf[2]; assert(false); } catch (const std::out_of_range&) {}
    }
    // Resize grow
    {
        Buffer buf(2); buf[0]=10; buf[1]=20;
        buf.resize(5);
        assert(buf.size()==5 && buf[0]==10 && buf[1]==20);
        assert(buf[2]==0 && buf[3]==0 && buf[4]==0);
    }
    // Self copy assignment
    {
        Buffer buf(3); buf[0]=1;buf[1]=2;buf[2]=3;
        buf = buf;
        assert(buf.size()==3 && buf[0]==1 && buf[1]==2 && buf[2]==3);
    }
    // Self move assignment
    {
        Buffer buf(2); buf[0]=4;buf[1]=5;
        buf = std::move(buf);
        assert(buf.size()==2 && buf[0]==4 && buf[1]==5);
    }
    std::cout << "All tests passed" << std::endl;
    return 0;
}
