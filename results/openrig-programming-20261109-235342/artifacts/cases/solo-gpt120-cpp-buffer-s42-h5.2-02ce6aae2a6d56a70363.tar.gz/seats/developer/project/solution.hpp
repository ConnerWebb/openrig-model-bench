#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <memory>

/**
 * Simple resizable byte buffer.
 *
 * - Elements are `std::uint8_t`.
 * - Provides size(), operator[] with bounds checking (throws std::out_of_range).
 * - Supports deep copy construction/assignment.
 * - Move construction/assignment are noexcept and leave the moved‑from object in a valid empty state.
 * - resize() preserves existing prefix, zero‑initialises any newly added bytes and never shrinks the allocated memory below the new size.
 */
class Buffer {
    std::unique_ptr<std::uint8_t[]> data_; // owned storage
    std::size_t size_ = 0;                  // number of valid bytes

public:
    // ---------------------------------------------------------------------
    // Constructors / Destructor
    // ---------------------------------------------------------------------
    explicit Buffer(std::size_t n = 0) : data_(n ? new std::uint8_t[n] : nullptr), size_(n) {
        // Zero‑initialise the buffer as a sensible default.
        if (data_) std::fill_n(data_.get(), n, static_cast<std::uint8_t>(0));
    }

    // Deep‑copy constructor
    Buffer(const Buffer& other) : data_(other.size_ ? new std::uint8_t[other.size_] : nullptr), size_(other.size_) {
        if (data_) std::copy_n(other.data_.get(), other.size_, data_.get());
    }

    // Deep‑copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            Buffer tmp(other);          // copy‑and‑swap idiom
            swap(tmp);
        }
        return *this;
    }

    // Move constructor – noexcept
    Buffer(Buffer&& other) noexcept : data_(std::move(other.data_)), size_(other.size_) {
        other.size_ = 0;
    }

    // Move assignment – noexcept
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            data_ = std::move(other.data_);
            size_ = other.size_;
            other.size_ = 0;
        }
        return *this;
    }

    ~Buffer() = default; // unique_ptr handles deletion

    // ---------------------------------------------------------------------
    // Observers
    // ---------------------------------------------------------------------
    std::size_t size() const noexcept { return size_; }

    // Non‑const element access with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= size_) throw std::out_of_range("Buffer index out of range");
        return data_[i];
    }

    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= size_) throw std::out_of_range("Buffer index out of range");
        return data_[i];
    }

    // ---------------------------------------------------------------------
    // Mutators
    // ---------------------------------------------------------------------
    /**
     * Resize the buffer to `newSize`.
     *   * Existing bytes up to min(oldSize, newSize) are preserved.
     *   * If the buffer grows, the new region is zero‑initialised.
     */
    void resize(std::size_t newSize) {
        if (newSize == size_) return;
        std::unique_ptr<std::uint8_t[]> newData(newSize ? new std::uint8_t[newSize] : nullptr);
        if (newData) {
            // Preserve prefix
            std::size_t copyCount = std::min(size_, newSize);
            if (copyCount) std::copy_n(data_.get(), copyCount, newData.get());
            // Zero initialise any newly added bytes
            if (newSize > size_) std::fill_n(newData.get() + size_, newSize - size_, static_cast<std::uint8_t>(0));
        }
        data_ = std::move(newData);
        size_ = newSize;
    }

    // Swap helper for copy‑and‑swap
    void swap(Buffer& other) noexcept {
        using std::swap;
        swap(data_, other.data_);
        swap(size_, other.size_);
    }
};

// Enable ADL swap
inline void swap(Buffer& a, Buffer& b) noexcept { a.swap(b); }
