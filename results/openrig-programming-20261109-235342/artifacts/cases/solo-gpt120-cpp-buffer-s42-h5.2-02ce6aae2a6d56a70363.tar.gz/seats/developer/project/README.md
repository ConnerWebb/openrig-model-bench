# Buffer Library

This repository contains a small, self‑contained C++20 implementation of a dynamic byte buffer (`Buffer`).

## Features
- Stores raw bytes (`std::uint8_t`).
- Provides `size()`, bounds‑checked `operator[]` (both const and mutable).
- Deep copy construction and assignment.
- noexcept move construction/assignment; moved‑from objects become empty.
- `resize()` preserves existing data, zero‑initialises any newly added bytes, and correctly shrinks.
- No memory leaks – uses `std::unique_ptr` for RAII.

## Files
- `solution.hpp` – implementation of the `Buffer` class.
- `test_buffer.cpp` – unit tests using GoogleTest (provided by the execution environment).

## Building & Testing
The environment compiles with Clang 22 in C++20 mode. To run the tests:
```
run_tests
```
The harness will compile `test_buffer.cpp` against `solution.hpp` and execute the tests. All tests must pass.

## Usage Example
```cpp
#include "solution.hpp"
#include <iostream>

int main() {
    Buffer buf(4);
    for (size_t i = 0; i < buf.size(); ++i) buf[i] = static_cast<std::uint8_t>(i);
    buf.resize(6); // new bytes are zero
    for (size_t i = 0; i < buf.size(); ++i) std::cout << (int)buf[i] << ' ';
    // Output: 0 1 2 3 0 0
}
```
