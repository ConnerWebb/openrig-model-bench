# Buffer Library

This repository provides a simple `Buffer` class implemented in C++20.

## Features
- Dynamic byte storage (`uint8_t`).
- Safe element access with bounds checking (`std::out_of_range`).
- Deep copy semantics and noexcept move semantics.
- `resize` preserves existing data, zero‑initialises newly allocated bytes, and correctly handles shrinking.
- RAII based memory management without leaks.

## Usage
```cpp
#include "solution.hpp"

Buffer buf(10);          // creates a buffer of 10 zero‑initialised bytes
buf[0] = 42;             // safe access, throws if out of range
buf.resize(15);          // grows, new bytes are zero‑initialised

Buffer copy = buf;       // deep copy
Buffer moved = std::move(buf); // noexcept move, `buf` becomes empty
```

## Building & Testing
The project uses a single source file `test_buffer.cpp` with a `main` function that runs a suite of assertions.
```bash
clang++ -std=c++20 -Wall -Wextra -O2 test_buffer.cpp -o test_buffer
./test_buffer   # exits silently if all tests pass
```

All tests are self‑contained and use only the C++ standard library.

## Implementation Details
- Memory is allocated with `new[]` and freed with `delete[]`.
- Copy constructor/assignment perform deep copies.
- Move constructor/assignment are marked `noexcept` and leave the source in a valid empty state.
- `operator[]` provides both mutable and const overloads with range checks.
- `resize` allocates new storage, copies the minimum of old and new sizes, zero‑fills any newly added region, then frees the old storage.

## License
Public domain – use freely.
