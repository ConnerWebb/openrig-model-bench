#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <utility>

class Buffer {
    std::uint8_t* p_;
    std::size_t n_;
public:
    // Constructors
    Buffer(std::size_t n = 0) : p_(n ? new std::uint8_t[n] : nullptr), n_(n) {
        // zero-initialize allocated memory
        if (p_) std::fill_n(p_, n_, 0);
    }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p_(other.n_ ? new std::uint8_t[other.n_] : nullptr), n_(other.n_) {
        if (p_) std::copy(other.p_, other.p_ + n_, p_);
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            Buffer tmp(other); // copy-swap idiom
            swap(tmp);
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p_(other.p_), n_(other.n_) {
        other.p_ = nullptr;
        other.n_ = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p_;
            p_ = other.p_;
            n_ = other.n_;
            other.p_ = nullptr;
            other.n_ = 0;
        }
        return *this;
    }

    // Destructor
    ~Buffer() {
        delete[] p_;
    }

    // Size accessor
    std::size_t size() const noexcept { return n_; }

    // Element access with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n_) throw std::out_of_range("Buffer index out of range");
        return p_[i];
    }
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n_) throw std::out_of_range("Buffer index out of range");
        return p_[i];
    }

    // Resize preserving existing data and zero-initializing new bytes
    void resize(std::size_t k) {
        if (k == n_) return;
        std::uint8_t* newp = k ? new std::uint8_t[k] : nullptr;
        if (newp) {
            // copy the minimum of old and new sizes
            std::size_t copy_len = std::min(n_, k);
            if (copy_len) std::copy(p_, p_ + copy_len, newp);
            // zero-initialize any newly added region
            if (k > n_) std::fill(newp + n_, newp + k, 0);
        }
        delete[] p_;
        p_ = newp;
        n_ = k;
    }

    // Swap helper
    void swap(Buffer& other) noexcept {
        using std::swap;
        swap(p_, other.p_);
        swap(n_, other.n_);
    }
};

