#include "solution.hpp"
#include <stdexcept>
#include <cstddef>
#include <cstdint>
#include <cassert>

int main(){
    // Test default construction
    Buffer b0;
    assert(b0.size() == 0);

    // Test construction with size and zero init
    Buffer b5(5);
    assert(b5.size() == 5);
    for(std::size_t i=0;i<5;++i) assert(b5[i]==0);

    // Test element write and read
    for(std::size_t i=0;i<5;++i) b5[i] = static_cast<std::uint8_t>(i+1);
    for(std::size_t i=0;i<5;++i) assert(b5[i]==static_cast<std::uint8_t>(i+1));

    // Test bounds checking
    bool caught = false;
    try { b5[5]; } catch(const std::out_of_range&) { caught = true; }
    assert(caught);

    // Test resize larger preserving data and zero init new part
    b5.resize(8);
    assert(b5.size() == 8);
    for(std::size_t i=0;i<5;++i) assert(b5[i]==static_cast<std::uint8_t>(i+1));
    for(std::size_t i=5;i<8;++i) assert(b5[i]==0);

    // Test resize smaller preserving prefix
    b5.resize(3);
    assert(b5.size() == 3);
    for(std::size_t i=0;i<3;++i) assert(b5[i]==static_cast<std::uint8_t>(i+1));

    // Test copy construction
    Buffer bCopy(b5);
    assert(bCopy.size() == b5.size());
    for(std::size_t i=0;i<bCopy.size();++i) assert(bCopy[i]==b5[i]);
    bCopy[0] = 99;
    assert(bCopy[0]==99 && b5[0]!=99);

    // Test copy assignment
    Buffer bAssign;
    bAssign = b5;
    assert(bAssign.size() == b5.size());
    for(std::size_t i=0;i<bAssign.size();++i) assert(bAssign[i]==b5[i]);

    // Test move construction
    Buffer bMoveSrc(4);
    for(std::size_t i=0;i<4;++i) bMoveSrc[i]=static_cast<std::uint8_t>(i+10);
    Buffer bMove(std::move(bMoveSrc));
    assert(bMove.size() == 4);
    for(std::size_t i=0;i<4;++i) assert(bMove[i]==static_cast<std::uint8_t>(i+10));
    assert(bMoveSrc.size() == 0);

    // Test move assignment
    Buffer bMoveAssign;
    bMoveAssign = std::move(bMove);
    assert(bMoveAssign.size() == 4);
    for(std::size_t i=0;i<4;++i) assert(bMoveAssign[i]==static_cast<std::uint8_t>(i+10));
    assert(bMove.size() == 0);

    // Self copy assignment should not corrupt
    Buffer selfCopy(2);
    selfCopy = selfCopy;
    assert(selfCopy.size() == 2);

    // Self move assignment should leave object valid (size 0 after move)
    Buffer selfMove(2);
    selfMove = std::move(selfMove);
    // After self-move, we consider it valid but unspecified; ensure no crash and size is either 0 or original
    assert(selfMove.size() == 0 || selfMove.size() == 2);

    return 0;
}
