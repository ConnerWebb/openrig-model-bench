# README.md
# JobQueue

This repository implements a simple job queue backed by SQLite.

## API
```python
q = JobQueue(path, max_attempts=3)
q.enqueue(key, payload) -> bool
q.claim(worker, now, lease) -> dict|None
q.complete(key, worker) -> bool
q.fail(key, worker) -> bool
q.status(key) -> dict|None
```

See `solution.py` for full implementation.
