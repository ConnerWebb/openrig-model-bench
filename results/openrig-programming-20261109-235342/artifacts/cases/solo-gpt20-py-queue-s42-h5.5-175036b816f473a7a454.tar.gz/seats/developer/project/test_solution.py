import unittest
import os
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.db = os.path.join('test.db')
        if os.path.exists(self.db):
            os.remove(self.db)
        self.q = JobQueue(self.db, max_attempts=2)

    def test_enqueue_and_status(self):
        self.assertTrue(self.q.enqueue('a', {'x':1}))
        self.assertFalse(self.q.enqueue('a', {'x':2}))
        status = self.q.status('a')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)

    def test_claim_and_complete(self):
        self.q.enqueue('b', 42)
        claim = self.q.claim('w', 0, 10)
        self.assertIsNotNone(claim)
        self.assertEqual(claim['key'], 'b')
        self.assertEqual(claim['payload'], 42)
        self.assertEqual(claim['attempts'], 1)
        self.assertTrue(self.q.complete('b', 'w'))
        self.assertEqual(self.q.status('b')['state'], 'done')

    def test_claim_expired(self):
        self.q.enqueue('c', 'x')
        self.q.claim('w', 0, 5)
        # advance time beyond lease
        claim = self.q.claim('other', 6, 5)
        self.assertIsNone(claim)
        status = self.q.status('c')
        self.assertEqual(status['state'], 'queued')

    def test_fail_and_retry(self):
        self.q.enqueue('d', 'y')
        self.q.claim('w', 0, 5)
        self.assertTrue(self.q.fail('d', 'w'))
        status = self.q.status('d')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 1)
        # second fail reaches max_attempts
        self.q.claim('w', 10, 5)
        self.assertTrue(self.q.fail('d', 'w'))
        self.assertEqual(self.q.status('d')['state'], 'failed')

    def test_invalid_args(self):
        with self.assertRaises(ValueError):
            self.q.enqueue('', 1)
        with self.assertRaises(ValueError):
            self.q.enqueue('e', set())
        with self.assertRaises(ValueError):
            self.q.claim('', 0, 5)
        with self.assertRaises(ValueError):
            self.q.complete('e', '')
        with self.assertRaises(ValueError):
            self.q.fail('e', '')
        with self.assertRaises(ValueError):
            self.q.status('')

if __name__ == '__main__':
    unittest.main()
