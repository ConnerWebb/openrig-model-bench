import json, sqlite3, os

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(path, str) or not path:
            raise ValueError("path must be non-empty string")
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be positive integer")
        self.path = os.path.abspath(path)
        self.max_attempts = max_attempts
        self._ensure_db()

    def _ensure_db(self):
        os.makedirs(os.path.dirname(self.path) or '.', exist_ok=True)
        conn = sqlite3.connect(self.path, timeout=30)
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT,
                attempts INTEGER,
                owner TEXT,
                lease_until REAL
            );
            """
        )
        conn.commit()
        conn.close()

    def enqueue(self, key, payload):
        if not key or not isinstance(key, str):
            raise ValueError("key must be non-empty string")
        try:
            json.dumps(payload)
        except Exception:
            raise ValueError("payload must be JSON serializable")
        conn = sqlite3.connect(self.path, timeout=30)
        cur = conn.cursor()
        try:
            cur.execute(
                "INSERT INTO jobs (key,payload,state,attempts,owner,lease_until) VALUES (?,?,?,?,?,?)",
                (key, json.dumps(payload), 'queued', 0, None, None),
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()

    def claim(self, worker, now, lease):
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be non-empty string")
        if not isinstance(now, (int, float)):
            raise ValueError("now must be timestamp")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be positive number")
        conn = sqlite3.connect(self.path, timeout=30, isolation_level='EXCLUSIVE')
        cur = conn.cursor()
        cur.execute(
            "SELECT key,payload,attempts FROM jobs WHERE (state='queued' OR (state='leased' AND lease_until<?)) AND attempts<? ORDER BY rowid ASC LIMIT 1",
            (now, self.max_attempts),
        )
        row = cur.fetchone()
        if not row:
            conn.close()
            return None
        key, payload_json, attempts = row
        new_attempts = attempts + 1
        lease_until = now + lease
        cur.execute(
            "UPDATE jobs SET state='leased', attempts=?, owner=?, lease_until=? WHERE key=?",
            (new_attempts, worker, lease_until, key),
        )
        conn.commit()
        conn.close()
        return {'key': key, 'payload': json.loads(payload_json), 'attempts': new_attempts}

    def complete(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be non-empty string")
        conn = sqlite3.connect(self.path, timeout=30, isolation_level='EXCLUSIVE')
        cur = conn.cursor()
        cur.execute("SELECT owner FROM jobs WHERE key=?", (key,))
        row = cur.fetchone()
        if not row or row[0] != worker:
            conn.close()
            return False
        cur.execute("UPDATE jobs SET state='done', owner=NULL, lease_until=NULL WHERE key=?", (key,))
        conn.commit()
        conn.close()
        return True

    def fail(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be non-empty string")
        conn = sqlite3.connect(self.path, timeout=30, isolation_level='EXCLUSIVE')
        cur = conn.cursor()
        cur.execute("SELECT owner, attempts FROM jobs WHERE key=?", (key,))
        row = cur.fetchone()
        if not row or row[0] != worker:
            conn.close()
            return False
        attempts = row[1]
        if attempts >= self.max_attempts:
            cur.execute("UPDATE jobs SET state='failed', owner=NULL, lease_until=NULL WHERE key=?", (key,))
        else:
            cur.execute("UPDATE jobs SET state='queued', owner=NULL, lease_until=NULL WHERE key=?", (key,))
        conn.commit()
        conn.close()
        return True

    def status(self, key):
        if not key or not isinstance(key, str):
            raise ValueError("key must be non-empty string")
        conn = sqlite3.connect(self.path, timeout=30)
        cur = conn.cursor()
        cur.execute("SELECT state, attempts FROM jobs WHERE key=?", (key,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        state, attempts = row
        return {'state': state, 'attempts': attempts}
