import unittest
import json
import copy
import ledger

class TestLedger(unittest.TestCase):
    def load_cases(self):
        with open('/work/PUBLIC_CASES.json', 'r') as f:
            return json.load(f)
    
    def test_basic_normalization(self):
        """Test basic record normalization with whitespace stripping"""
        records = [{'id': ' 8 ', 'category': ' c ', 'cents': 1}]
        result = ledger.process(records)
        self.assertEqual(result['events'], [{'id': '8', 'category': 'c', 'cents': 1}])
        self.assertEqual(result['totals'], {'c': 1})
    
    def test_deduplication_first_wins(self):
        """Test that first occurrence of an id wins"""
        records = [
            {'id': '3', 'category': 'b', 'cents': 11},
            {'id': '3', 'category': 'c', 'cents': 7}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'b')
        self.assertEqual(result['events'][0]['cents'], 11)
    
    def test_multiple_categories_totals(self):
        """Test totals calculation across multiple categories"""
        records = [
            {'id': '4', 'category': 'a', 'cents': 96},
            {'id': '3', 'category': 'b', 'cents': 11},
            {'id': '8', 'category': 'c', 'cents': 1}
        ]
        result = ledger.process(records)
        self.assertEqual(result['totals'], {'a': 96, 'b': 11, 'c': 1})
    
    def test_totals_sorted_keys(self):
        """Test that totals keys are sorted"""
        records = [
            {'id': 'c', 'category': 'c', 'cents': 1},
            {'id': 'a', 'category': 'a', 'cents': 1},
            {'id': 'b', 'category': 'b', 'cents': 1}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])
    
    def test_empty_input(self):
        """Test empty input returns empty result"""
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})
    
    def test_minimum_cents_filter(self):
        """Test minimum_cents filter"""
        records = [
            {'id': '1', 'category': 'a', 'cents': 5},
            {'id': '2', 'category': 'a', 'cents': 15},
            {'id': '3', 'category': 'a', 'cents': 25}
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['cents'], 15)
        self.assertEqual(result['events'][1]['cents'], 25)
        self.assertEqual(result['totals'], {'a': 40})
    
    def test_input_not_mutated(self):
        """Test that input records are not mutated"""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)
    
    def test_invalid_record_missing_field(self):
        """Test validation rejects record with missing field"""
        records = [{'id': 'x', 'category': 'a'}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_extra_field(self):
        """Test validation rejects record with extra field"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_empty_id(self):
        """Test validation rejects empty id"""
        records = [{'id': '', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_negative_cents(self):
        """Test validation rejects negative cents"""
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_boolean_cents(self):
        """Test validation rejects boolean cents"""
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_non_string_id(self):
        """Test validation rejects non-string id"""
        records = [{'id': 123, 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_non_string_category(self):
        """Test validation rejects non-string category"""
        records = [{'id': 'x', 'category': 123, 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_record_non_int_cents(self):
        """Test validation rejects non-int cents"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1.5}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_invalid_minimum_cents_negative(self):
        """Test validation rejects negative minimum_cents"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)
    
    def test_invalid_minimum_cents_boolean(self):
        """Test validation rejects boolean minimum_cents"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)
    
    def test_full_case_from_public(self):
        """Test the first full case from PUBLIC_CASES.json"""
        records = [
            {'id': ' 8 ', 'category': ' c ', 'cents': 1},
            {'id': ' 4 ', 'category': ' a ', 'cents': 96},
            {'id': ' 3 ', 'category': ' b ', 'cents': 11},
            {'id': ' 3 ', 'category': ' c ', 'cents': 7},
            {'id': ' 9 ', 'category': ' a ', 'cents': 64},
            {'id': ' 0 ', 'category': ' c ', 'cents': 67},
            {'id': ' 5 ', 'category': ' b ', 'cents': 97},
            {'id': ' 2 ', 'category': ' b ', 'cents': 82},
            {'id': ' 2 ', 'category': ' a ', 'cents': 44},
            {'id': ' 9 ', 'category': ' a ', 'cents': 49},
            {'id': ' 9 ', 'category': ' a ', 'cents': 19},
            {'id': ' 5 ', 'category': ' b ', 'cents': 57},
            {'id': ' 1 ', 'category': ' c ', 'cents': 2},
            {'id': ' 3 ', 'category': ' c ', 'cents': 18},
            {'id': ' 2 ', 'category': ' a ', 'cents': 94},
            {'id': ' 8 ', 'category': ' b ', 'cents': 38},
            {'id': ' 9 ', 'category': ' a ', 'cents': 32},
            {'id': ' 5 ', 'category': ' a ', 'cents': 50},
            {'id': ' 0 ', 'category': ' a ', 'cents': 12},
            {'id': ' 3 ', 'category': ' a ', 'cents': 37},
            {'id': ' 2 ', 'category': ' b ', 'cents': 61},
            {'id': ' 7 ', 'category': ' c ', 'cents': 76},
            {'id': ' 5 ', 'category': ' b ', 'cents': 12},
            {'id': ' 1 ', 'category': ' c ', 'cents': 2}
        ]
        result = ledger.process(records)
        # After normalization and deduplication
        # id '8' first: category 'c', cents 1
        # id '4' first: category 'a', cents 96
        # id '3' first: category 'b', cents 11
        # id '9' first: category 'a', cents 64
        # id '0' first: category 'c', cents 67
        # id '5' first: category 'b', cents 97
        # id '2' first: category 'b', cents 82
        # id '1' first: category 'c', cents 2
        # id '7' first: category 'c', cents 76
        expected_events = [
            {'id': '8', 'category': 'c', 'cents': 1},
            {'id': '4', 'category': 'a', 'cents': 96},
            {'id': '3', 'category': 'b', 'cents': 11},
            {'id': '9', 'category': 'a', 'cents': 64},
            {'id': '0', 'category': 'c', 'cents': 67},
            {'id': '5', 'category': 'b', 'cents': 97},
            {'id': '2', 'category': 'b', 'cents': 82},
            {'id': '1', 'category': 'c', 'cents': 2},
            {'id': '7', 'category': 'c', 'cents': 76}
        ]
        self.assertEqual(result['events'], expected_events)
        # Totals: a=96+64=160, b=11+97+82=190, c=1+67+2+76=146
        self.assertEqual(result['totals'], {'a': 160, 'b': 190, 'c': 146})
    
    def test_minimum_cents_with_filtering(self):
        """Test minimum_cents with actual filtering"""
        records = [
            {'id': '1', 'category': 'a', 'cents': 5},
            {'id': '2', 'category': 'a', 'cents': 15}
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 15)
        self.assertEqual(result['totals'], {'a': 15})
    
    def test_deduplication_preserves_order(self):
        """Test that deduplication preserves input order for first occurrences"""
        records = [
            {'id': 'c', 'category': 'c', 'cents': 1},
            {'id': 'a', 'category': 'a', 'cents': 1},
            {'id': 'b', 'category': 'b', 'cents': 1},
            {'id': 'c', 'category': 'x', 'cents': 99}
        ]
        result = ledger.process(records)
        self.assertEqual([r['id'] for r in result['events']], ['c', 'a', 'b'])
    
    def test_whitespace_only_id_invalid(self):
        """Test that whitespace-only id is invalid"""
        records = [{'id': '   ', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_whitespace_only_category_invalid(self):
        """Test that whitespace-only category is invalid"""
        records = [{'id': 'x', 'category': '   ', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_zero_cents_valid(self):
        """Test that zero cents is valid"""
        records = [{'id': 'x', 'category': 'a', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(result['events'], [{'id': 'x', 'category': 'a', 'cents': 0}])
        self.assertEqual(result['totals'], {'a': 0})
    
    def test_minimum_cents_zero_default(self):
        """Test that minimum_cents=0 is the default"""
        records = [{'id': 'x', 'category': 'a', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
    
    def test_minimum_cents_filter_removes_all(self):
        """Test minimum_cents filter that removes all records"""
        records = [
            {'id': '1', 'category': 'a', 'cents': 5},
            {'id': '2', 'category': 'a', 'cents': 10}
        ]
        result = ledger.process(records, minimum_cents=100)
        self.assertEqual(result, {'events': [], 'totals': {}})
