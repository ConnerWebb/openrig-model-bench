#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <stdexcept>
#include <cstdint>
#include <cctype>

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty integer string");
    size_t idx = 0;
    if (s[0] == '+' || s[0] == '-') idx = 1;
    if (idx >= s.size()) throw std::invalid_argument("no digits");
    if (s[idx] == '0' && idx + 1 < s.size() && std::isdigit(static_cast<unsigned char>(s[idx + 1]))) {
        throw std::invalid_argument("leading zero");
    }
    for (size_t i = idx; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("non-digit in integer");
        }
    }
    if (s[0] == '-') {
        if (s.size() == 2 && s[1] == '0') return 0;
        if (s.size() > 19) throw std::invalid_argument("overflow");
        if (s.size() == 19) {
            std::string limit = "9223372036854775808";
            if (s.substr(1) > limit) throw std::invalid_argument("overflow");
        }
        std::string abs_str = s.substr(1);
        std::int64_t abs_val = std::stoll(abs_str);
        if (abs_val == 0) return 0;
        return -abs_val;
    } else {
        if (s.size() > 19) throw std::invalid_argument("overflow");
        if (s.size() == 19) {
            std::string limit = "9223372036854775807";
            if (s > limit) throw std::invalid_argument("overflow");
        }
        return std::stoll(s);
    }
}

struct CsvParser {
    std::istream& in;
    int next_char = -1;
    bool eof = false;

    CsvParser(std::istream& i) : in(i) { read_char(); }

    void read_char() {
        int c = in.get();
        if (c == EOF) {
            eof = true;
            next_char = -1;
        } else {
            next_char = c;
        }
    }

    void skip_crlf() {
        if (next_char == '\r') read_char();
        if (next_char == '\n') read_char();
    }

    bool is_eof() const { return eof && next_char == -1; }

    std::string parse_field() {
        std::string result;
        if (next_char == '"') {
            read_char();
            while (!eof && next_char != '"') {
                if (next_char == '\r' || next_char == '\n') {
                    throw std::invalid_argument("newline in quoted field");
                }
                if (next_char == '"') {
                    read_char();
                    if (next_char == '"') {
                        result += '"';
                        read_char();
                    } else {
                        break;
                    }
                } else {
                    result += static_cast<char>(next_char);
                    read_char();
                }
            }
            if (eof) throw std::invalid_argument("unclosed quote");
            read_char();
        } else {
            while (!eof && next_char != ',' && next_char != '\r' && next_char != '\n') {
                result += static_cast<char>(next_char);
                read_char();
            }
        }
        return result;
    }

    bool parse_line(std::string& category, std::string& amount_str) {
        category = parse_field();
        if (eof || next_char == '\r' || next_char == '\n') {
            throw std::invalid_argument("missing amount field");
        }
        if (next_char == ',') read_char();
        amount_str = parse_field();
        return true;
    }
};

}

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    CsvParser parser(in);

    std::string line_category, line_amount;
    parser.skip_crlf();

    if (parser.is_eof()) {
        return {};
    }

    line_category = parser.parse_field();
    if (parser.next_char != ',') {
        throw std::invalid_argument("header missing comma");
    }
    parser.read_char();
    line_amount = parser.parse_field();

    if (line_category != "category" || line_amount != "amount") {
        throw std::invalid_argument("wrong header");
    }

    parser.skip_crlf();

    std::map<std::string, std::int64_t> result;

    while (!parser.is_eof()) {
        if (parser.next_char == '\r' || parser.next_char == '\n') {
            parser.skip_crlf();
            continue;
        }

        std::string category = parser.parse_field();

        if (parser.next_char != ',') {
            throw std::invalid_argument("missing comma before amount");
        }
        parser.read_char();

        std::string amount_str = parser.parse_field();

        category = trim(category);
        amount_str = trim(amount_str);

        if (category.empty()) {
            throw std::invalid_argument("empty category");
        }
        if (amount_str.empty()) {
            throw std::invalid_argument("empty amount");
        }

        std::int64_t amount_val = parse_int64(amount_str);

        result[category] += amount_val;

        if (parser.is_eof()) break;
        if (parser.next_char == '\r' || parser.next_char == '\n') {
            parser.skip_crlf();
        }
    }

    return result;
}

#endif
