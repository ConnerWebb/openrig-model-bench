#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nfood,30\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["food"] == -20);
}

void test_quotes() {
    std::string input = "category,amount\n\"x\"\"quote\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["x\"quote"] == 100);
}

void test_multiline() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
}

void test_comma_in_quotes() {
    std::string input = "category,amount\n\"a,b\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["a,b"] == 100);
}

void test_wrong_header() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_extra_field() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_nan() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_unclosed_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_exponent() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_overflow_positive() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_overflow_negative() {
    std::string input = "category,amount\nx,-9223372036854775809\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_max_int64() {
    std::string input = "category,amount\nx,9223372036854775807\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["x"] == 9223372036854775807LL);
}

void test_min_int64() {
    std::string input = "category,amount\nx,-9223372036854775808\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["x"] == -9223372036854775807LL - 1);
}

void test_positive_sign() {
    std::string input = "category,amount\nx,+100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["x"] == 100);
}

void test_empty_input() {
    std::string input = "";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.empty());
}

void test_only_header() {
    std::string input = "category,amount\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.empty());
}

void test_whitespace_trim() {
    std::string input = "category,amount\n  food  ,  100  \n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["food"] == 100);
}

void test_japanese() {
    std::string input = "category,amount\n日本,100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["日本"] == 100);
}

void test_accumulation_overflow() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_negative_accumulation_overflow() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

int main() {
    test_basic();
    test_negative();
    test_quotes();
    test_multiline();
    test_comma_in_quotes();
    test_wrong_header();
    test_extra_field();
    test_empty_category();
    test_nan();
    test_unclosed_quote();
    test_exponent();
    test_overflow_positive();
    test_overflow_negative();
    test_max_int64();
    test_min_int64();
    test_positive_sign();
    test_empty_input();
    test_only_header();
    test_whitespace_trim();
    test_japanese();
    test_accumulation_overflow();
    test_negative_accumulation_overflow();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
