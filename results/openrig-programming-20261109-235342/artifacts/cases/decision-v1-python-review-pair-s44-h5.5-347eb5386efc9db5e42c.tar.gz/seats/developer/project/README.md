# JobQueue

A SQLite-based job queue implementation that supports concurrent access across multiple processes.

## Features

- **Thread-safe and process-safe**: Uses SQLite's built-in locking mechanisms with WAL mode for concurrent access
- **Atomic claim operations**: Uses `BEGIN IMMEDIATE` transactions to ensure only one worker can claim a job at a time
- **Lease management**: Jobs can be leased with a timeout, and expired leases are handled automatically
- **Retry logic**: Jobs can be retried up to `max_attempts` times before being marked as failed
- **First-come-first-served**: Jobs are claimed in order of insertion

## API

### JobQueue(path, max_attempts=3)

Initialize a job queue with the given database path and maximum number of attempts per job.

**Parameters:**
- `path`: Path to the SQLite database file
- `max_attempts`: Maximum number of times a job can be attempted (default: 3)

**Raises:**
- `ValueError`: If `max_attempts` is not a positive integer

### enqueue(key, payload) -> bool

Add a new job to the queue. The first call with a given key wins.

**Parameters:**
- `key`: Unique identifier for the job (must be non-empty)
- `payload`: JSON-serializable data for the job

**Returns:**
- `True` if the job was added, `False` if a job with the same key already exists

**Raises:**
- `ValueError`: If `key` is empty

### claim(worker, now, lease) -> dict or None

Claim the oldest available job for processing.

**Parameters:**
- `worker`: Identifier of the worker claiming the job (must be non-empty)
- `now`: Current timestamp
- `lease`: Lease duration in seconds (must be positive)

**Returns:**
- A dictionary with `key`, `payload`, and `attempts` if a job was claimed
- `None` if no jobs are available

**Raises:**
- `ValueError`: If `worker` is empty or `lease` is not positive

**Behavior:**
- Atomically selects the oldest queued job or leased job with expired lease
- Increments the attempt counter
- Sets the owner and lease expiry
- If a job has exceeded `max_attempts` and its lease has expired, it is marked as failed

### complete(key, worker) -> bool

Mark a job as completed.

**Parameters:**
- `key`: Job identifier
- `worker`: Worker that claimed the job

**Returns:**
- `True` if the job was successfully marked as done
- `False` if the job doesn't exist or the worker doesn't own it

### fail(key, worker) -> bool

Mark a job as failed or requeue it for another attempt.

**Parameters:**
- `key`: Job identifier
- `worker`: Worker that claimed the job

**Returns:**
- `True` if the job was successfully updated
- `False` if the job doesn't exist or the worker doesn't own it

**Behavior:**
- If attempts have been exhausted, the job is marked as failed
- Otherwise, the job is requeued for another attempt

### status(key) -> dict or None

Get the current status of a job.

**Parameters:**
- `key`: Job identifier

**Returns:**
- A dictionary with `state` and `attempts` if the job exists
- `None` if the job doesn't exist

## State Machine

Jobs can be in one of the following states:
- `queued`: Available for claiming
- `leased`: Currently being processed by a worker
- `done`: Successfully completed
- `failed`: Exhausted all attempts or explicitly failed

## Concurrency

The implementation uses SQLite's WAL (Write-Ahead Logging) mode and `BEGIN IMMEDIATE` transactions to ensure:
- No lost or duplicate live claims across multiple processes
- Atomic claim operations
- Proper handling of concurrent access

## Testing

Run the test suite with:
```bash
python -m unittest test_solution.py
```
