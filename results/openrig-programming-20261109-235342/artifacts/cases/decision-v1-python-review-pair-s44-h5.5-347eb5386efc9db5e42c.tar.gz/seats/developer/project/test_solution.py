import unittest
import tempfile
import pathlib
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = str(pathlib.Path(self.temp_dir.name) / 'q.db')
        self.q = JobQueue(self.db_path, max_attempts=3)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_enqueue_first_wins(self):
        self.assertTrue(self.q.enqueue("key1", {"data": 1}))
        self.assertFalse(self.q.enqueue("key1", {"data": 2}))
        status = self.q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_claim_basic(self):
        self.q.enqueue("a", {"v": 5304})
        result = self.q.claim("w", 0, 5)
        self.assertEqual(result["key"], "a")
        self.assertEqual(result["payload"], {"v": 5304})
        self.assertEqual(result["attempts"], 1)

    def test_claim_no_available_jobs(self):
        result = self.q.claim("w", 0, 5)
        self.assertIsNone(result)

    def test_claim_expired_lease(self):
        self.q.enqueue("a", {"v": 1})
        # Claim with lease until time 5
        self.q.claim("w", 0, 5)
        # Try to claim again at time 10 (lease expired)
        result = self.q.claim("w2", 10, 5)
        self.assertEqual(result["key"], "a")
        self.assertEqual(result["attempts"], 2)

    def test_complete_success(self):
        self.q.enqueue("a", {"v": 1})
        self.q.claim("w", 0, 5)
        self.assertTrue(self.q.complete("a", "w"))
        status = self.q.status("a")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        self.q.enqueue("a", {"v": 1})
        self.q.claim("w", 0, 5)
        self.assertFalse(self.q.complete("a", "wrong"))

    def test_fail_requeues(self):
        self.q.enqueue("a", {"v": 1})
        self.q.claim("w", 0, 5)
        self.assertTrue(self.q.fail("a", "w"))
        status = self.q.status("a")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 1)

    def test_fail_exhausted_attempts(self):
        q = JobQueue(self.db_path, max_attempts=2)
        q.enqueue("a", {"v": 1})
        q.claim("w", 0, 5)
        q.fail("a", "w")
        q.claim("w2", 1, 5)
        # Now attempts = 2, which equals max_attempts
        self.assertTrue(q.fail("a", "w2"))
        status = q.status("a")
        self.assertEqual(status["state"], "failed")

    def test_status_nonexistent(self):
        self.assertIsNone(self.q.status("nonexistent"))

    def test_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_invalid_key(self):
        with self.assertRaises(ValueError):
            self.q.enqueue("", {"data": 1})

    def test_invalid_worker(self):
        with self.assertRaises(ValueError):
            self.q.claim("", 0, 5)

    def test_invalid_lease(self):
        with self.assertRaises(ValueError):
            self.q.claim("w", 0, 0)
        with self.assertRaises(ValueError):
            self.q.claim("w", 0, -1)

    def test_claim_oldest_first(self):
        self.q.enqueue("first", {"v": 1})
        self.q.enqueue("second", {"v": 2})
        result = self.q.claim("w", 0, 5)
        self.assertEqual(result["key"], "first")

    def test_complete_nonexistent(self):
        self.assertFalse(self.q.complete("nonexistent", "w"))

    def test_fail_nonexistent(self):
        self.assertFalse(self.q.fail("nonexistent", "w"))

    def test_fail_wrong_worker(self):
        self.q.enqueue("a", {"v": 1})
        self.q.claim("w", 0, 5)
        self.assertFalse(self.q.fail("a", "wrong"))

    def test_enqueue_payload_types(self):
        self.assertTrue(self.q.enqueue("str_key", "string_value"))
        self.assertTrue(self.q.enqueue("int_key", 42))
        self.assertTrue(self.q.enqueue("list_key", [1, 2, 3]))
        self.assertTrue(self.q.enqueue("dict_key", {"nested": {"key": "value"}}))
        self.assertTrue(self.q.enqueue("null_key", None))

    def test_claim_after_fail(self):
        self.q.enqueue("a", {"v": 1})
        self.q.claim("w", 0, 5)
        self.q.fail("a", "w")
        result = self.q.claim("w2", 1, 5)
        self.assertEqual(result["key"], "a")
        self.assertEqual(result["attempts"], 2)

    def test_claim_no_duplicate_live_claims(self):
        self.q.enqueue("a", {"v": 1})
        r1 = self.q.claim("w1", 0, 100)
        r2 = self.q.claim("w2", 0, 100)
        self.assertEqual(r1["key"], "a")
        self.assertIsNone(r2)

if __name__ == '__main__':
    unittest.main()
