import sqlite3
import json
import threading
import os

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self.path = path
        self.max_attempts = max_attempts
        self._local_lock = threading.Lock()
        self._init_db()

    def _get_conn(self):
        """Get a connection with proper settings for concurrent access."""
        conn = sqlite3.connect(self.path, timeout=30.0, isolation_level=None)
        conn.execute("PRAGMA busy_timeout = 30000")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        return conn

    def _init_db(self):
        conn = self._get_conn()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT,
                    state TEXT NOT NULL DEFAULT 'queued',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    owner TEXT,
                    lease_until REAL,
                    inserted_at REAL NOT NULL DEFAULT (julianday('now'))
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_available ON jobs(state, attempts, inserted_at)")
        finally:
            conn.close()

    def enqueue(self, key, payload):
        if not key:
            raise ValueError("key must be nonempty")
        
        conn = self._get_conn()
        try:
            cur = conn.execute(
                "INSERT OR IGNORE INTO jobs (key, payload, state, attempts) VALUES (?, ?, 'queued', 0)",
                (key, json.dumps(payload))
            )
            return cur.rowcount > 0
        finally:
            conn.close()

    def claim(self, worker, now, lease):
        if not worker:
            raise ValueError("worker must be nonempty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        
        conn = self._get_conn()
        try:
            # Start an exclusive transaction to ensure atomicity
            conn.execute("BEGIN IMMEDIATE")
            
            try:
                # First, mark any exhausted leased jobs as failed
                conn.execute("""
                    UPDATE jobs SET state = 'failed'
                    WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?
                """, (now, self.max_attempts))
                
                # Find the oldest available job
                cur = conn.execute("""
                    SELECT key, payload, attempts FROM jobs
                    WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                    AND attempts < ?
                    ORDER BY inserted_at ASC
                    LIMIT 1
                """, (now, self.max_attempts))
                
                row = cur.fetchone()
                
                if row is None:
                    conn.execute("COMMIT")
                    return None
                
                key, payload_json, attempts = row
                new_attempts = attempts + 1
                lease_until = now + lease
                
                # Atomically claim this specific job (only if still available)
                cur = conn.execute("""
                    UPDATE jobs 
                    SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
                    WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                    AND attempts = ?
                """, (worker, lease_until, new_attempts, key, now, attempts))
                
                if cur.rowcount == 0:
                    # Job was claimed by another process between select and update
                    conn.execute("COMMIT")
                    return None
                
                conn.execute("COMMIT")
                
                return {
                    "key": key,
                    "payload": json.loads(payload_json),
                    "attempts": new_attempts
                }
            except Exception:
                conn.execute("ROLLBACK")
                raise
        finally:
            conn.close()

    def complete(self, key, worker):
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        
        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            try:
                cur = conn.execute("""
                    SELECT state, owner FROM jobs WHERE key = ?
                """, (key,))
                row = cur.fetchone()
                
                if row is None:
                    conn.execute("ROLLBACK")
                    return False
                
                state, owner = row
                if state != 'leased' or owner != worker:
                    conn.execute("ROLLBACK")
                    return False
                
                conn.execute("""
                    UPDATE jobs SET state = 'done' WHERE key = ?
                """, (key,))
                conn.execute("COMMIT")
                return True
            except Exception:
                conn.execute("ROLLBACK")
                raise
        finally:
            conn.close()

    def fail(self, key, worker):
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        
        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            try:
                cur = conn.execute("""
                    SELECT state, owner, attempts FROM jobs WHERE key = ?
                """, (key,))
                row = cur.fetchone()
                
                if row is None:
                    conn.execute("ROLLBACK")
                    return False
                
                state, owner, attempts = row
                if state != 'leased' or owner != worker:
                    conn.execute("ROLLBACK")
                    return False
                
                if attempts >= self.max_attempts:
                    conn.execute("""
                        UPDATE jobs SET state = 'failed' WHERE key = ?
                    """, (key,))
                else:
                    conn.execute("""
                        UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?
                    """, (key,))
                conn.execute("COMMIT")
                return True
            except Exception:
                conn.execute("ROLLBACK")
                raise
        finally:
            conn.close()

    def status(self, key):
        conn = self._get_conn()
        try:
            cur = conn.execute("""
                SELECT state, attempts FROM jobs WHERE key = ?
            """, (key,))
            row = cur.fetchone()
            
            if row is None:
                return None
            
            state, attempts = row
            return {"state": state, "attempts": attempts}
        finally:
            conn.close()
