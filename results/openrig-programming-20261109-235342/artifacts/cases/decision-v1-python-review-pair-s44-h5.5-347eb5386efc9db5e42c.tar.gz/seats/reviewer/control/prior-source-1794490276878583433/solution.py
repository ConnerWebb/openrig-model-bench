import sqlite3
import json
import threading

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self.path = path
        self.max_attempts = max_attempts
        self._lock = threading.Lock()
        self._init_db()

    def _init_db(self):
        with self._lock:
            conn = sqlite3.connect(self.path)
            try:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS jobs (
                        key TEXT PRIMARY KEY,
                        payload TEXT,
                        state TEXT NOT NULL DEFAULT 'queued',
                        attempts INTEGER NOT NULL DEFAULT 0,
                        owner TEXT,
                        lease_until REAL,
                        inserted_at REAL NOT NULL DEFAULT (julianday('now'))
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_state_owner ON jobs(state, owner, lease_until, inserted_at)")
                conn.commit()
            finally:
                conn.close()

    def enqueue(self, key, payload):
        if not key:
            raise ValueError("key must be nonempty")
        with self._lock:
            conn = sqlite3.connect(self.path)
            try:
                cur = conn.execute(
                    "INSERT OR IGNORE INTO jobs (key, payload, state, attempts) VALUES (?, ?, 'queued', 0)",
                    (key, json.dumps(payload))
                )
                conn.commit()
                return cur.rowcount > 0
            finally:
                conn.close()

    def claim(self, worker, now, lease):
        if not worker:
            raise ValueError("worker must be nonempty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        
        with self._lock:
            conn = sqlite3.connect(self.path, timeout=30.0)
            conn.execute("PRAGMA busy_timeout = 30000")
            conn.execute("PRAGMA journal_mode = WAL")
            try:
                # First, check for any jobs that have exceeded max_attempts and are leased (expired)
                # These should be marked as failed
                conn.execute("""
                    UPDATE jobs SET state = 'failed'
                    WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?
                """, (now, self.max_attempts))
                conn.commit()

                # Find the oldest available job
                cur = conn.execute("""
                    SELECT key, payload, attempts FROM jobs
                    WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                    AND attempts < ?
                    ORDER BY inserted_at ASC
                    LIMIT 1
                """, (now, self.max_attempts))
                row = cur.fetchone()
                
                if row is None:
                    return None
                
                key, payload_json, attempts = row
                new_attempts = attempts + 1
                lease_until = now + lease
                
                # Atomically claim this specific job (only if still available)
                cur = conn.execute("""
                    UPDATE jobs SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
                    WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                    AND attempts = ?
                """, (worker, lease_until, new_attempts, key, now, attempts))
                
                if cur.rowcount == 0:
                    # Job was claimed by another process between select and update
                    return None
                
                conn.commit()
                
                return {
                    "key": key,
                    "payload": json.loads(payload_json),
                    "attempts": new_attempts
                }
            finally:
                conn.close()

    def complete(self, key, worker):
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        
        with self._lock:
            conn = sqlite3.connect(self.path)
            try:
                cur = conn.execute("""
                    SELECT state, owner FROM jobs WHERE key = ?
                """, (key,))
                row = cur.fetchone()
                
                if row is None:
                    return False
                
                state, owner = row
                if state != 'leased' or owner != worker:
                    return False
                
                conn.execute("""
                    UPDATE jobs SET state = 'done' WHERE key = ?
                """, (key,))
                conn.commit()
                return True
            finally:
                conn.close()

    def fail(self, key, worker):
        if not key or not worker:
            raise ValueError("key and worker must be nonempty")
        
        with self._lock:
            conn = sqlite3.connect(self.path)
            try:
                cur = conn.execute("""
                    SELECT state, owner, attempts FROM jobs WHERE key = ?
                """, (key,))
                row = cur.fetchone()
                
                if row is None:
                    return False
                
                state, owner, attempts = row
                if state != 'leased' or owner != worker:
                    return False
                
                if attempts >= self.max_attempts:
                    conn.execute("""
                        UPDATE jobs SET state = 'failed' WHERE key = ?
                    """, (key,))
                else:
                    conn.execute("""
                        UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?
                    """, (key,))
                conn.commit()
                return True
            finally:
                conn.close()

    def status(self, key):
        with self._lock:
            conn = sqlite3.connect(self.path)
            try:
                cur = conn.execute("""
                    SELECT state, attempts FROM jobs WHERE key = ?
                """, (key,))
                row = cur.fetchone()
                
                if row is None:
                    return None
                
                state, attempts = row
                return {"state": state, "attempts": attempts}
            finally:
                conn.close()
