# JobQueue Implementation

A SQLite-backed job queue implementation in Python with support for:
- Enqueueing jobs with unique keys (first insert wins)
- Claiming jobs by workers with lease expiration
- Completing or failing jobs
- Automatic handling of exhausted attempts (jobs become failed)
- Thread-safe operations

## API

### JobQueue(path, max_attempts=3)

Initialize a job queue backed by SQLite at the given path.

**Parameters:**
- `path`: File path for the SQLite database
- `max_attempts`: Maximum number of attempts before a job is marked as failed (default: 3)

**Raises:**
- `ValueError`: If `max_attempts` is not a positive integer

### Methods

#### enqueue(key, payload) -> bool
Enqueue a job with the given key and payload. First unique key wins.

- Returns `True` if the job was enqueued
- Returns `False` if a job with the same key already exists

**Raises:**
- `ValueError`: If `key` is empty

#### claim(worker, now, lease) -> dict or None
Atomically claim the oldest available job (queued or expired leased).

- `worker`: The worker claiming the job (non-empty string)
- `now`: Current timestamp for lease calculations
- `lease`: Lease duration in seconds (must be positive)

**Returns:**
- `None` if no jobs are available
- `{"key": str, "payload": any, "attempts": int}` on success

**Raises:**
- `ValueError`: If `worker` is empty or `lease` is not positive

#### complete(key, worker) -> bool
Mark a leased job as complete.

- Returns `True` if the job was successfully completed
- Returns `False` if the job doesn't exist, isn't leased, or the worker doesn't own it

#### fail(key, worker) -> bool
Fail a leased job. If attempts are exhausted, the job becomes failed; otherwise it's requeued.

- Returns `True` if the job was successfully processed
- Returns `False` if the job doesn't exist, isn't leased, or the worker doesn't own it

#### status(key) -> dict or None
Get the status of a job.

- Returns `None` if the job doesn't exist
- Returns `{"state": str, "attempts": int}` where state is one of: queued, leased, done, failed

## State Machine

1. **queued**: Initial state after enqueue
2. **leased**: After being claimed by a worker
3. **done**: After successful completion
4. **failed**: After exhausting all attempts

## Concurrency

The implementation uses SQLite's transaction isolation and a threading lock to ensure:
- No lost or duplicate live claims
- Atomic state transitions
- Safe concurrent access from multiple processes/threads

## Testing

Run tests with:
```bash
python3 -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
