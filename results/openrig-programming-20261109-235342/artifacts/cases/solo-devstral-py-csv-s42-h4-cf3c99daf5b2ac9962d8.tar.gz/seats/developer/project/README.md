# CSV Aggregator

This project implements a CSV aggregator that reads a CSV file and aggregates amounts by category.

## Solution

The `solution.py` file contains the `aggregate` function which:

1. Reads a CSV file as a stream
2. Validates the header is exactly `category,amount`
3. Processes each row, skipping completely blank rows
4. Validates each row has exactly 2 fields
5. Strips whitespace from category and amount
6. Validates category is not empty
7. Parses amount using Decimal for exact arithmetic
8. Validates amount is nonnegative and finite
9. Accumulates totals using exact decimal arithmetic
10. Returns sorted categories with amounts formatted to 2 decimal places

## Testing

Run the tests using:

```bash
run_tests
```

The tests include:
- Basic aggregation
- Empty file handling
- Whitespace handling
- Decimal precision
- Quoted fields
- Embedded newlines
- Blank rows
- Various error cases

## Public Cases

The `PUBLIC_CASES.json` file contains public test cases that are used to verify the implementation.

## Implementation Notes

- The solution uses Python's built-in `csv` module for proper CSV parsing
- Decimal arithmetic is used for exact precision
- All validation is performed according to the specification
- The function raises `ValueError` for any invalid input
