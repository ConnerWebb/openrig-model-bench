import unittest
import os
import tempfile
from solution import aggregate


class TestAggregate(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        for f in os.listdir(self.test_dir):
            os.remove(os.path.join(self.test_dir, f))
        os.rmdir(self.test_dir)
    
    def test_basic_aggregation(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,100.50\nfood,200.75\nrent,300.25\n")
        
        result = aggregate(csv_path)
        self.assertEqual(result, {"food": "301.25", "rent": "300.25"})
    
    def test_empty_file(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("")
        
        result = aggregate(csv_path)
        self.assertEqual(result, {})
    
    def test_whitespace_handling(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\n  food  ,  100.50  \n  rent  ,  200.75  \n")
        
        result = aggregate(csv_path)
        self.assertEqual(result, {"food": "100.50", "rent": "200.75"})
    
    def test_decimal_precision(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,100.123\nfood,200.456\n")
        
        result = aggregate(csv_path)
        self.assertEqual(result, {"food": "300.58"})
    
    def test_quoted_fields(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write('category,amount\n"food",100.50\n"rent",200.75\n')
        
        result = aggregate(csv_path)
        self.assertEqual(result, {"food": "100.50", "rent": "200.75"})
    
    def test_embedded_newlines(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write('category,amount\n"food\\nwith\\nnewlines",100.50\n"rent",200.75\n')
        
        result = aggregate(csv_path)
        self.assertEqual(result, {"food\nwith\nnewlines": "100.50", "rent": "200.75"})
    
    def test_blank_rows(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,100.50\n\nrent,200.75\n\n")
        
        result = aggregate(csv_path)
        self.assertEqual(result, {"food": "100.50", "rent": "200.75"})
    
    def test_invalid_header(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("wrong,amount\nfood,100.50\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_invalid_row_format(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,100.50,extra\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_empty_category(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\n,100.50\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_invalid_amount(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,abc\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_negative_amount(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,-100.50\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_infinite_amount(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,inf\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_nan_amount(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,NaN\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)
    
    def test_scientific_notation(self):
        csv_path = os.path.join(self.test_dir, "test.csv")
        with open(csv_path, 'w') as f:
            f.write("category,amount\nfood,1e2\n")
        
        with self.assertRaises(ValueError):
            aggregate(csv_path)


if __name__ == '__main__':
    unittest.main()
