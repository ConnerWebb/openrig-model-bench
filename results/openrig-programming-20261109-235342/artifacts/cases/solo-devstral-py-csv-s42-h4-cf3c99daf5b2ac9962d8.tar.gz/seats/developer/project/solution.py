import csv
import re
from decimal import Decimal, InvalidOperation
from typing import Dict


def aggregate(path: str) -> Dict[str, str]:
    """
    Read a CSV file and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary with categories as keys and formatted amounts as values
        
    Raises:
        ValueError: If the CSV format is invalid or amounts are malformed
    """
    totals = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        # Read header
        try:
            headers = next(reader)
        except StopIteration:
            # Empty file
            return {}
        
        # Validate header
        if headers != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        # Process each row
        for row in reader:
            # Skip completely blank rows
            if not row:
                continue
            
            # Validate row has exactly 2 fields
            if len(row) != 2:
                raise ValueError("Invalid row format")
            
            category, amount_str = row
            
            # Strip whitespace from category
            category = category.strip()
            
            # Validate category is not empty
            if not category:
                raise ValueError("Empty category")
            
            # Strip whitespace from amount
            amount_str = amount_str.strip()
            
            # Validate amount format - must have 1-12 digits before decimal, optional decimal with 1-2 digits
            if not re.match(r'^\+?\d{1,12}(\.\d{1,2})?$', amount_str):
                raise ValueError("Invalid amount format")
            
            # Parse amount using Decimal
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError("Invalid amount format")
            
            # Validate amount is nonnegative and finite
            if amount < 0 or amount.is_infinite():
                raise ValueError("Invalid amount value")
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted categories with formatted amounts
    return {k: f"{v:.2f}" for k, v in sorted(totals.items())}
