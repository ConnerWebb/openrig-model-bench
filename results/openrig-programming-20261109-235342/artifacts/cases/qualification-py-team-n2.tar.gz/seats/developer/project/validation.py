def normalize(records):
    """
    Validate and normalize records.
    
    Args:
        records: List of record dicts with keys 'id', 'category', 'cents'
        
    Returns:
        List of fresh normalized record dicts with stripped strings
        
    Raises:
        ValueError: If any record is invalid
    """
    out = []
    for r in records:
        if not isinstance(r, dict):
            raise ValueError('record')
        if set(r.keys()) != {'id', 'category', 'cents'}:
            raise ValueError('record')
        if not isinstance(r['id'], str) or not r['id'].strip():
            raise ValueError('record')
        if not isinstance(r['category'], str) or not r['category'].strip():
            raise ValueError('record')
        if type(r['cents']) is not int or r['cents'] < 0:
            raise ValueError('record')
        out.append({
            'id': r['id'].strip(),
            'category': r['category'].strip(),
            'cents': r['cents']
        })
    return out
