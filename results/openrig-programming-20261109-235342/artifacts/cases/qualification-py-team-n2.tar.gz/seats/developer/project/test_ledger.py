import unittest
import copy
import ledger
from validation import normalize
from storage import deduplicate


class TestNormalize(unittest.TestCase):
    def test_valid_record(self):
        r = {'id': ' x ', 'category': ' a ', 'cents': 5}
        result = normalize([r])
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])
    
    def test_preserves_duplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = normalize(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[1]['id'], 'a')
    
    def test_non_dict_raises(self):
        with self.assertRaises(ValueError):
            normalize(['not a dict'])
    
    def test_wrong_keys_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x'}])
    
    def test_empty_id_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': '', 'category': 'x', 'cents': 1}])
    
    def test_whitespace_only_id_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': '   ', 'category': 'x', 'cents': 1}])
    
    def test_empty_category_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': '', 'cents': 1}])
    
    def test_whitespace_only_category_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': '   ', 'cents': 1}])
    
    def test_negative_cents_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x', 'cents': -1}])
    
    def test_float_cents_raises(self):
        with self.assertRaises(ValueError):
            normalize([{'id': 'a', 'category': 'x', 'cents': 1.5}])
    
    def test_input_not_mutated(self):
        r = {'id': ' x ', 'category': ' a ', 'cents': 5}
        original = copy.deepcopy(r)
        normalize([r])
        self.assertEqual(r, original)


class TestDeduplicate(unittest.TestCase):
    def test_no_duplicates(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'b', 'category': 'y', 'cents': 2}
        ]
        result = deduplicate(records)
        self.assertEqual(len(result), 2)
    
    def test_keeps_first_occurrence(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = deduplicate(records)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['category'], 'x')
    
    def test_fresh_copies(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = deduplicate(records)
        result[0]['category'] = 'y'
        self.assertEqual(records[0]['category'], 'x')
    
    def test_empty_input(self):
        result = deduplicate([])
        self.assertEqual(result, [])
    
    def test_input_not_mutated(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        original = copy.deepcopy(records)
        deduplicate(records)
        self.assertEqual(records, original)


class TestProcess(unittest.TestCase):
    def test_basic_process(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = ledger.process(r)
        self.assertEqual(result['events'], [{'id': 'x', 'category': 'a', 'cents': 5}])
        self.assertEqual(result['totals'], {'a': 5})
    
    def test_empty_input(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})
    
    def test_deduplication(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'x')
    
    def test_minimum_cents_filter(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'y', 'cents': 10},
            {'id': 'c', 'category': 'z', 'cents': 15}
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['totals'], {'y': 10, 'z': 15})
    
    def test_minimum_cents_default_zero(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
    
    def test_minimum_cents_negative_raises(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)
    
    def test_minimum_cents_float_raises(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=1.5)
    
    def test_totals_sorted(self):
        records = [
            {'id': 'c', 'category': 'z', 'cents': 1},
            {'id': 'b', 'category': 'y', 'cents': 1},
            {'id': 'a', 'category': 'x', 'cents': 1}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['x', 'y', 'z'])
    
    def test_input_not_mutated(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = copy.deepcopy(r)
        ledger.process(r)
        self.assertEqual(r, original)
    
    def test_returns_fresh_data(self):
        r = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result1 = ledger.process(r)
        result2 = ledger.process(r)
        result1['events'][0]['category'] = 'y'
        result1['totals']['y'] = 999
        result3 = ledger.process(r)
        self.assertEqual(result3['events'][0]['category'], 'x')
    
    def test_validation_error_in_process(self):
        with self.assertRaises(ValueError):
            ledger.process([{'id': '', 'category': 'x', 'cents': 1}])


class TestIntegration(unittest.TestCase):
    def test_public_case_1(self):
        # From PUBLIC_CASES.json
        records = [
            {'id': ' 8 ', 'category': ' c ', 'cents': 1},
            {'id': ' 4 ', 'category': ' a ', 'cents': 96},
            {'id': ' 3 ', 'category': ' b ', 'cents': 11},
            {'id': ' 3 ', 'category': ' c ', 'cents': 7},
            {'id': ' 9 ', 'category': ' a ', 'cents': 64},
            {'id': ' 0 ', 'category': ' c ', 'cents': 67},
            {'id': ' 5 ', 'category': ' b ', 'cents': 97},
            {'id': ' 2 ', 'category': ' b ', 'cents': 82},
            {'id': ' 2 ', 'category': ' a ', 'cents': 44},
            {'id': ' 9 ', 'category': ' a ', 'cents': 49},
            {'id': ' 9 ', 'category': ' a ', 'cents': 19},
            {'id': ' 5 ', 'category': ' b ', 'cents': 57},
            {'id': ' 1 ', 'category': ' c ', 'cents': 2},
            {'id': ' 3 ', 'category': ' c ', 'cents': 18},
            {'id': ' 2 ', 'category': ' a ', 'cents': 94},
            {'id': ' 8 ', 'category': ' b ', 'cents': 38},
            {'id': ' 9 ', 'category': ' a ', 'cents': 32},
            {'id': ' 5 ', 'category': ' a ', 'cents': 50},
            {'id': ' 0 ', 'category': ' a ', 'cents': 12},
            {'id': ' 3 ', 'category': ' a ', 'cents': 37},
            {'id': ' 2 ', 'category': ' b ', 'cents': 61},
            {'id': ' 7 ', 'category': ' c ', 'cents': 76},
            {'id': ' 5 ', 'category': ' b ', 'cents': 12},
            {'id': ' 3 ', 'category': ' b ', 'cents': 79},
            {'id': ' 3 ', 'category': ' a ', 'cents': 73}
        ]
        result = ledger.process(records, minimum_cents=10)
        
        expected_events = [
            {'id': '4', 'category': 'a', 'cents': 96},
            {'id': '3', 'category': 'b', 'cents': 11},
            {'id': '9', 'category': 'a', 'cents': 64},
            {'id': '0', 'category': 'c', 'cents': 67},
            {'id': '5', 'category': 'b', 'cents': 97},
            {'id': '2', 'category': 'b', 'cents': 82},
            {'id': '7', 'category': 'c', 'cents': 76}
        ]
        self.assertEqual(result['events'], expected_events)
        self.assertEqual(result['totals'], {'a': 160, 'b': 190, 'c': 143})
    
    def test_input_unchanged_after_process(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)


if __name__ == '__main__':
    unittest.main()
