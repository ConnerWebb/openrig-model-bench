def deduplicate(records):
    """
    Remove duplicate records by id, keeping first occurrence.
    
    Args:
        records: List of validated record dicts
        
    Returns:
        List of fresh record copies, deduplicated by id
    """
    seen = set()
    out = []
    for r in records:
        if r['id'] not in seen:
            seen.add(r['id'])
            out.append(dict(r))
    return out
