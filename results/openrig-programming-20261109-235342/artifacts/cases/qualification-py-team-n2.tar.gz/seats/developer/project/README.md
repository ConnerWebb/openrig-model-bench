# Ledger Toolkit

A Python library for processing ledger records with validation, deduplication, and aggregation.

## Modules

### validation.py
- `normalize(records)` - Validates and normalizes records, stripping whitespace from id and category fields. Preserves duplicates.

### storage.py
- `deduplicate(records)` - Removes duplicate records by id, keeping the first occurrence. Returns fresh copies.

### ledger.py
- `process(records, *, minimum_cents=0)` - Main API. Processes records through normalization, deduplication, filtering, and aggregation.

## Usage

```python
from ledger import process

records = [
    {'id': 'item1', 'category': 'food', 'cents': 500},
    {'id': 'item2', 'category': 'transport', 'cents': 200},
    {'id': 'item1', 'category': 'food', 'cents': 600},  # duplicate id
]

result = process(records)
# Returns:
# {
#   'events': [
#     {'id': 'item1', 'category': 'food', 'cents': 500},
#     {'id': 'item2', 'category': 'transport', 'cents': 200}
#   ],
#   'totals': {'food': 500, 'transport': 200}
# }
```

## Filtering

Use `minimum_cents` to filter records:

```python
result = process(records, minimum_cents=300)
# Only includes records with cents >= 300
```

## Validation

Records must have:
- `id`: non-empty stripped string
- `category`: non-empty stripped string
- `cents`: integer >= 0

Invalid records raise `ValueError`.

## Properties

- Never mutates input
- Returns fresh data (no shared mutable references)
- First occurrence of duplicate ids is kept
- Totals keys are sorted alphabetically
