from validation import normalize
from storage import deduplicate


def process(records, *, minimum_cents=0):
    """
    Process records through normalization, deduplication, and filtering.
    
    Args:
        records: List of record dicts with keys 'id', 'category', 'cents'
        minimum_cents: Optional keyword-only filter (nonnegative int, default 0)
        
    Returns:
        {'events': [normalized records], 'totals': {category: sum cents}}
        with totals keys sorted
        
    Raises:
        ValueError: If minimum_cents is invalid or any record is invalid
    """
    if type(minimum_cents) is not int or minimum_cents < 0:
        raise ValueError('minimum')
    
    # Normalize all records (validates and strips)
    normalized = normalize(records)
    
    # Deduplicate (keeps first occurrence)
    deduped = deduplicate(normalized)
    
    # Filter by minimum_cents
    events = [r for r in deduped if r['cents'] >= minimum_cents]
    
    # Calculate totals with sorted keys
    totals = {}
    for r in events:
        totals[r['category']] = totals.get(r['category'], 0) + r['cents']
    
    return {'events': events, 'totals': dict(sorted(totals.items()))}
