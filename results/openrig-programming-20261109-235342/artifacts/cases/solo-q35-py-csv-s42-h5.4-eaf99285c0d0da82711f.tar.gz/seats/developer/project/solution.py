"""CSV category aggregation with exact decimal arithmetic."""

import csv
from decimal import Decimal, InvalidOperation
from typing import Dict


def aggregate(path: str) -> Dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted,
    totals formatted with exactly two decimal places.
    """
    totals: Dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Invalid header: must be exactly 'category,amount'")
        
        for row in reader:
            # Skip completely blank records (empty list from csv reader)
            if not row:
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Record must have exactly two fields, got {len(row)}")
            
            category, amount_str = row[0], row[1]
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate and parse amount
            try:
                amount = _parse_amount(amount_str)
            except ValueError:
                raise
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format totals with exactly two decimal places and sort keys
    result: Dict[str, str] = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result


def _parse_amount(s: str) -> Decimal:
    """
    Parse amount with format: optional +, 1–12 decimal digits,
    optional decimal point followed by 1 or 2 digits.
    Nonnegative, finite, no exponent.
    """
    if not s:
        raise ValueError("Empty amount")
    
    # Check for exponent (reject)
    if 'e' in s.lower():
        raise ValueError("Exponent not allowed")
    
    # Check for NaN, Inf, etc.
    if s.lower() in ('nan', 'inf', '+inf', '-inf', '+nan', '-nan'):
        raise ValueError("Non-finite value not allowed")
    
    # Strip optional leading +
    if s.startswith('+'):
        s = s[1:]
    
    if not s:
        raise ValueError("Empty amount after stripping +")
    
    # Validate format: digits with optional decimal point and 1-2 digits after
    parts = s.split('.')
    
    if len(parts) > 2:
        raise ValueError("Too many decimal points")
    
    integer_part = parts[0]
    fractional_part = parts[1] if len(parts) == 2 else None
    
    # Integer part: 1-12 digits
    if not integer_part:
        raise ValueError("Integer part required")
    if not integer_part.isdigit():
        raise ValueError("Invalid integer part")
    if len(integer_part) > 12:
        raise ValueError("Integer part exceeds 12 digits")
    
    # Fractional part: optional, but if present must be 1-2 digits
    if fractional_part is not None:
        if not fractional_part:
            raise ValueError("Decimal point requires digits after it")
        if not fractional_part.isdigit():
            raise ValueError("Invalid fractional part")
        if len(fractional_part) > 2:
            raise ValueError("Fractional part exceeds 2 digits")
    
    # Parse as Decimal for exact arithmetic
    try:
        return Decimal(s)
    except InvalidOperation:
        raise ValueError("Invalid amount format")
