"""Tests for solution.aggregate."""

import tempfile
import unittest
from pathlib import Path
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def _write_csv(self, content: str) -> str:
        """Write CSV content to a temp file and return its path."""
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', suffix='.csv', delete=False) as f:
            f.write(content)
            return f.name

    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        csv_content = "category,amount\nfood,100.00\nrent,200.00\nfood,50.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "150.00", "rent": "200.00"})

    def test_sorted_keys(self):
        """Test that keys are sorted alphabetically."""
        csv_content = "category,amount\nzebra,1.00\napple,2.00\nmango,3.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(list(result.keys()), ["apple", "mango", "zebra"])

    def test_quoted_fields_with_comma(self):
        """Test quoted fields containing commas."""
        csv_content = 'category,amount\n"a,b",100.00\n"a,b",50.00\n'
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"a,b": "150.00"})

    def test_quoted_fields_with_newline(self):
        """Test quoted fields containing newlines."""
        csv_content = 'category,amount\n"two\nlines",100.00\n"two\nlines",50.00\n'
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"two\nlines": "150.00"})

    def test_quoted_double_quotes(self):
        """Test quoted fields with escaped double quotes."""
        csv_content = 'category,amount\n"x""quote",100.00\n"x""quote",50.00\n'
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"x\"quote": "150.00"})

    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = "category,amount\n  food  ,  100.00  \n  rent  ,  200.00  \n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00", "rent": "200.00"})

    def test_optional_plus_sign(self):
        """Test amount with optional + sign."""
        csv_content = "category,amount\nfood,+100.00\nrent,+200.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00", "rent": "200.00"})

    def test_integer_amounts(self):
        """Test integer amounts without decimal point."""
        csv_content = "category,amount\nfood,100\nrent,200\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00", "rent": "200.00"})

    def test_one_decimal_digit(self):
        """Test amount with one decimal digit."""
        csv_content = "category,amount\nfood,100.5\nrent,200.7\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.50", "rent": "200.70"})

    def test_two_decimal_digits(self):
        """Test amount with two decimal digits."""
        csv_content = "category,amount\nfood,100.55\nrent,200.77\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.55", "rent": "200.77"})

    def test_empty_category_rejected(self):
        """Test that empty category raises ValueError."""
        csv_content = "category,amount\n,100.00\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_wrong_header_rejected(self):
        """Test that wrong header raises ValueError."""
        csv_content = "wrong,amount\nx,1\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_too_many_fields_rejected(self):
        """Test that record with too many fields raises ValueError."""
        csv_content = "category,amount\nx,1,2\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_nan_rejected(self):
        """Test that NaN amount raises ValueError."""
        csv_content = "category,amount\nx,NaN\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_invalid_quoted_field(self):
        """Test that invalid quoted field raises ValueError."""
        csv_content = 'category,amount\n"x,1\n'
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_empty_file_rejected(self):
        """Test that empty file raises ValueError."""
        csv_content = ""
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_header_only(self):
        """Test file with only header."""
        csv_content = "category,amount\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {})

    def test_blank_lines_ignored(self):
        """Test that blank lines are ignored."""
        csv_content = "category,amount\n\nfood,100.00\n\nrent,200.00\n\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "100.00", "rent": "200.00"})

    def test_unicode_categories(self):
        """Test unicode categories."""
        csv_content = "category,amount\n日本,100.00\n中国,200.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"中国": "200.00", "日本": "100.00"})

    def test_amount_with_12_digits(self):
        """Test amount with exactly 12 digits in integer part."""
        csv_content = "category,amount\nfood,123456789012.00\n"
        path = self._write_csv(csv_content)
        result = aggregate(path)
        self.assertEqual(result, {"food": "123456789012.00"})

    def test_amount_with_13_digits_rejected(self):
        """Test that amount with more than 12 digits raises ValueError."""
        csv_content = "category,amount\nfood,1234567890123.00\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_amount_with_3_decimal_digits_rejected(self):
        """Test that amount with more than 2 decimal digits raises ValueError."""
        csv_content = "category,amount\nfood,100.123\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_amount_with_exponent_rejected(self):
        """Test that amount with exponent raises ValueError."""
        csv_content = "category,amount\nfood,1e10\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_amount_with_inf_rejected(self):
        """Test that amount with Inf raises ValueError."""
        csv_content = "category,amount\nfood,inf\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_negative_amount_rejected(self):
        """Test that negative amount raises ValueError."""
        csv_content = "category,amount\nfood,-100.00\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_decimal_point_without_digits_rejected(self):
        """Test that decimal point without digits raises ValueError."""
        csv_content = "category,amount\nfood,100.\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)

    def test_only_decimal_point_rejected(self):
        """Test that only decimal point raises ValueError."""
        csv_content = "category,amount\nfood,.\n"
        path = self._write_csv(csv_content)
        with self.assertRaises(ValueError):
            aggregate(path)


if __name__ == '__main__':
    unittest.main()
