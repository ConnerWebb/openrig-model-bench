# CSV Category Aggregation

A Python module that aggregates CSV data by category using exact decimal arithmetic.

## Function

```python
def aggregate(path: str) -> dict[str, str]
```

Reads a UTF-8 CSV file as a stream and returns a dictionary mapping categories to their aggregated totals.

## Input Format

- **Header**: Must be exactly `category,amount` (case-sensitive)
- **Records**: Each non-blank record must have exactly two fields
- **Category**: Stripped whitespace, must not be empty
- **Amount**: Optional `+` sign, 1-12 decimal digits, optional decimal point followed by 1-2 digits
  - Nonnegative, finite values only
  - No exponents allowed
  - Examples: `100`, `100.0`, `100.00`, `+100.55`

## Output Format

- Returns a dictionary with category keys sorted alphabetically
- Values are formatted as strings with exactly two decimal places
- Uses exact decimal arithmetic for accumulation (no floating-point errors)

## Error Handling

Raises `ValueError` for:
- Invalid header (not exactly `category,amount`)
- Records with wrong number of fields
- Empty category
- Invalid amount format (wrong digit count, too many decimal places, exponents, NaN, Inf, negative values)
- Malformed quoted fields
- Empty files

## Usage

```python
from solution import aggregate

result = aggregate("data.csv")
# Returns: {"category1": "100.00", "category2": "200.00"}
```

## CSV Features Supported

- Quoted fields with embedded commas: `"a,b"`
- Quoted fields with embedded newlines: `"two\nlines"`
- Escaped double quotes: `"x""quote"` becomes `x"quote`
- Unicode characters: `日本`, `中国`, etc.
- Blank lines (ignored)

## Testing

Run tests with:
```bash
python3 solution_test.py
```

Tests cover:
- Basic aggregation
- Sorted keys
- Quoted fields (commas, newlines, escaped quotes)
- Whitespace stripping
- Amount format validation
- Error cases (empty category, wrong header, invalid amounts, etc.)
