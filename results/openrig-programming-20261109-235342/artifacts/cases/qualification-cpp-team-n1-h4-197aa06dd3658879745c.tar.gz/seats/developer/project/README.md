# Local Analytics Toolkit

A header-only C++20 analytics toolkit with CSV parsing, LRU caching, and running statistics.

## Components

### parser.hpp

CSV parser with `aggregate(std::istream&)` function that:
- Parses CSV with header `category,amount`
- Handles quoted fields with escaped quotes, commas, and newlines
- Strips whitespace from fields
- Returns sorted `std::map<std::string, std::int64_t>` of category totals
- Validates input and throws `std::invalid_argument` for malformed data

### cache.hpp

`LruCache` class with:
- `put(int key, std::string value)` - insert/update (makes key MRU)
- `get(int key, std::string& out)` - retrieve (makes key MRU)
- `erase(int key)` - remove key
- `size()` - current capacity
- `snapshot()` - ordered vector (MRU first)
- O(1) average operations using list + hash map
- Capacity 0 stores nothing

### stats.hpp

`RunningStats` class with:
- `add(double)` - accumulate value (rejects NaN/infinity)
- `merge(const RunningStats&)` - combine statistics
- `count()` - number of values
- `mean()` - average
- `variance()` - population variance
- `minimum()` / `maximum()` - range
- Uses stable online algorithms for numerical accuracy

### solution.hpp

Umbrella header including all three modules.

## Usage

```cpp
#include "solution.hpp"

// Parse CSV and aggregate
std::istringstream csv("category,amount\nfood,100\nrent,500\nfood,50");
auto totals = aggregate(csv);  // {"food": 150, "rent": 500}

// LRU cache
LruCache cache(2);
cache.put(1, "first");
cache.put(2, "second");
std::string out;
cache.get(1, out);  // out = "first", key 1 now MRU
cache.put(3, "third");  // evicts key 2

// Running statistics
RunningStats stats;
stats.add(10.0);
stats.add(20.0);
stats.add(30.0);
double mean = stats.mean();     // 20.0
double var = stats.variance();  // 66.666...
```

## Requirements

- C++20 compatible compiler (Clang 14+, GCC 10+)
- Standard library support
