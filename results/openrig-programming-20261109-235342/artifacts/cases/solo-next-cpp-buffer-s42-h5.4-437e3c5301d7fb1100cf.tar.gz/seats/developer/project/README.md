# Buffer Library

A RAII-compliant C++20 buffer class with deep-copy semantics, move support, and bounds-checked access.

## Features

- `Buffer(size_t n=0)`: Construct buffer of given size, zero-initialized
- `size() const noexcept`: Return current size
- `operator[](size_t)`: Mutable and const bounds-checked access (throws `std::out_of_range`)
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction and assignment
- Noexcept move construction and assignment
- Self-assignment/move safety
- RAII: no leaks, no double-frees, no stale reads

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // 10 zero-initialized bytes
b[0] = 42;              // mutable access
Buffer c = b;           // deep copy
Buffer d = std::move(c); // move (c is now empty)
b.resize(20);           // grow, new bytes zero-initialized
```

## Testing

Run `run_tests` to verify against public and private test cases.
