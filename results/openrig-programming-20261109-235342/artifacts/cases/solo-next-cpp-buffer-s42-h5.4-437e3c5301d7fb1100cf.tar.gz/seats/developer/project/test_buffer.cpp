#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

void test_default_construct() {
    Buffer b;
    if (b.size() != 0) {
        std::cout << "FAIL: default construct size" << std::endl;
        exit(1);
    }
}

void test_construct_size() {
    Buffer b(10);
    if (b.size() != 10) {
        std::cout << "FAIL: construct size" << std::endl;
        exit(1);
    }
    for (std::size_t i = 0; i < b.size(); ++i) {
        if (b[i] != 0) {
            std::cout << "FAIL: construct size init" << std::endl;
            exit(1);
        }
    }
}

void test_copy() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    Buffer b = a;
    if (b.size() != 5) {
        std::cout << "FAIL: copy size" << std::endl;
        exit(1);
    }
    if (b[0] != 1 || b[1] != 2 || b[2] != 3) {
        std::cout << "FAIL: copy values" << std::endl;
        exit(1);
    }
    b[0] = 100;
    if (a[0] != 1) {
        std::cout << "FAIL: copy deep" << std::endl;
        exit(1);
    }
}

void test_move() {
    Buffer a(5);
    a[0] = 42;
    Buffer b = std::move(a);
    if (b.size() != 5) {
        std::cout << "FAIL: move size" << std::endl;
        exit(1);
    }
    if (a.size() != 0) {
        std::cout << "FAIL: moved-from size" << std::endl;
        exit(1);
    }
    if (b[0] != 42) {
        std::cout << "FAIL: move values" << std::endl;
        exit(1);
    }
}

void test_self_copy() {
    Buffer a(3);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer tmp = a;
    a = tmp;
    if (a.size() != 3) {
        std::cout << "FAIL: self copy size" << std::endl;
        exit(1);
    }
    if (a[0] != 10 || a[1] != 20 || a[2] != 30) {
        std::cout << "FAIL: self copy values" << std::endl;
        exit(1);
    }
}

void test_self_move() {
    Buffer a(3);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    Buffer tmp = std::move(a);
    a = std::move(tmp);
    if (a.size() != 3) {
        std::cout << "FAIL: self move size" << std::endl;
        exit(1);
    }
    if (a[0] != 10 || a[1] != 20 || a[2] != 30) {
        std::cout << "FAIL: self move values" << std::endl;
        exit(1);
    }
}

void test_resize_grow() {
    Buffer a(3);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a.resize(6);
    if (a.size() != 6) {
        std::cout << "FAIL: resize grow size" << std::endl;
        exit(1);
    }
    if (a[0] != 1 || a[1] != 2 || a[2] != 3) {
        std::cout << "FAIL: resize grow values" << std::endl;
        exit(1);
    }
    if (a[3] != 0 || a[4] != 0 || a[5] != 0) {
        std::cout << "FAIL: resize grow new init" << std::endl;
        exit(1);
    }
}

void test_resize_shrink() {
    Buffer a(6);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    a[5] = 6;
    a.resize(3);
    if (a.size() != 3) {
        std::cout << "FAIL: resize shrink size" << std::endl;
        exit(1);
    }
    if (a[0] != 1 || a[1] != 2 || a[2] != 3) {
        std::cout << "FAIL: resize shrink values" << std::endl;
        exit(1);
    }
}

void test_bounds() {
    Buffer a(3);
    bool caught = false;
    try {
        (void)a[3];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    if (!caught) {
        std::cout << "FAIL: bounds check" << std::endl;
        exit(1);
    }
}

void test_const_bounds() {
    Buffer a(3);
    const Buffer& ca = a;
    bool caught = false;
    try {
        (void)ca[3];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    if (!caught) {
        std::cout << "FAIL: const bounds check" << std::endl;
        exit(1);
    }
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>, "move construct not noexcept");
    static_assert(std::is_nothrow_move_assignable_v<Buffer>, "move assign not noexcept");
}

void test_raii() {
    std::vector<Buffer> v;
    for (int i = 0; i < 100; ++i) {
        v.emplace_back(i);
    }
}

int main() {
    test_default_construct();
    test_construct_size();
    test_copy();
    test_move();
    test_self_copy();
    test_self_move();
    test_resize_grow();
    test_resize_shrink();
    test_bounds();
    test_const_bounds();
    test_noexcept_move();
    test_raii();
    std::cout << "All tests passed" << std::endl;
    return 0;
}
