# LRU Cache Implementation

This project provides a C++20 implementation of an LRU (Least Recently Used) cache.

## API

- `LruCache(size_t capacity)`: Constructor with maximum capacity.
- `void put(int key, std::string value)`: Insert or update a key-value pair. Makes key most recently used.
- `bool get(int key, std::string& out)`: Retrieve value by key. Makes key most recently used. Returns false if not found.
- `bool erase(int key)`: Remove a key. Returns true if key existed.
- `size_t size() const`: Return current number of items.
- `std::vector<std::pair<int, std::string>> snapshot() const`: Return items from MRU to LRU order.

## Build and Run

```bash
clang++ -std=c++20 -Wall -Wextra -Wpedantic solution_test.cpp -o solution_test
./solution_test
```

## Testing

Run the driver with input:

```bash
echo '5 30 S P 4 "x96" P 4 "x25" S S S S E 2 G 2 P 5 "日本3" E 9 P 2 "two words55" E 1 P 3 "日本18" P 3 "日本65" G 4 S G 5 P 6 "x8" P 3 "x37" P 6 "two words63" S G 4 P 3 "two words79" P 2 "日本56" E 8 G 4 P 9 "日本33" P 0 "x28" E 5' | clang++ -std=c++20 -Wall -Wextra -Wpedantic -x c++ - -o driver <<'EOF'
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"
std::string js(const std::string&s){std::ostringstream o;o<<'"';for(unsigned char c:s){if(c=='"'||c=='\\')o<<'\\'<<c;else if(c=='\n')o<<"\\n";else if(c=='\r')o<<"\\r";else if(c=='\t')o<<"\\t";else if(c<32)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)c<<std::dec;else o<<c;}o<<'"';return o.str();}
int main(){try{
int cap,n;std::cin>>cap>>n;LruCache q(cap);std::cout<<"{\"value\":[";for(int i=0;i<n;i++){if(i)std::cout<<',';char op;int k;std::cin>>op;if(op=='P'){std::string v;std::cin>>k>>std::quoted(v);q.put(k,v);std::cout<<"null";}else if(op=='G'){std::cin>>k;std::string v="UNCHANGED";bool ok=q.get(k,v);std::cout<<"["<<(ok?"true":"false")<<','<<js(v)<<']';}else if(op=='E'){std::cin>>k;std::cout<<(q.erase(k)?"true":"false");}else if(op=='S'){std::cout<<'[';bool first=true;for(auto&[a,b]:q.snapshot()){if(!first)std::cout<<',';first=false;std::cout<<'['<<a<<','<<js(b)<<']';}std::cout<<']';}else throw std::invalid_argument("op");}std::cout<<"],\"size\":"<<q.size()<<'}';
}catch(const std::exception&e){std::cout<<"{\"error\":\"ValueError\"}";}catch(...){std::cout<<"{\"error\":\"ValueError\"}";}std::cout<<std::endl;}
EOF
./driver
```
