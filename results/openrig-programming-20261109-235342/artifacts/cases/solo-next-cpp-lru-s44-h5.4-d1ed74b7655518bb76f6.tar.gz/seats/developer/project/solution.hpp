#pragma once

#include <list>
#include <unordered_map>
#include <vector>
#include <utility>

class LruCache {
public:
    explicit LruCache(size_t capacity) : capacity_(capacity) {}

    void put(int key, std::string value) {
        if (capacity_ == 0) return;
        auto it = map_.find(key);
        if (it != map_.end()) {
            it->second.value = std::move(value);
            it->second.iter->second = it->second.value;
            list_.splice(list_.begin(), list_, it->second.iter);
            return;
        }
        if (list_.size() >= capacity_) {
            auto last = list_.back();
            map_.erase(last.first);
            list_.pop_back();
        }
        list_.emplace_front(key, std::move(value));
        map_[key] = {list_.begin(), list_.front().second};
    }

    bool get(int key, std::string& out) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }
        list_.splice(list_.begin(), list_, it->second.iter);
        out = it->second.value;
        return true;
    }

    bool erase(int key) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }
        list_.erase(it->second.iter);
        map_.erase(it);
        return true;
    }

    size_t size() const {
        return list_.size();
    }

    std::vector<std::pair<int, std::string>> snapshot() const {
        std::vector<std::pair<int, std::string>> result;
        for (const auto& item : list_) {
            result.emplace_back(item.first, item.second);
        }
        return result;
    }

private:
    size_t capacity_;
    std::list<std::pair<int, std::string>> list_;
    struct Node {
        typename std::list<std::pair<int, std::string>>::iterator iter;
        std::string value;
    };
    std::unordered_map<int, Node> map_;
};
