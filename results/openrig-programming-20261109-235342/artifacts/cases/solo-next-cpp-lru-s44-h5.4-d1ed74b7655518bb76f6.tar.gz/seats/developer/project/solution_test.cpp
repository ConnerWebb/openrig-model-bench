#include <iostream>
#include <cassert>
#include "solution.hpp"

void test_basic_put_get() {
    LruCache cache(2);
    cache.put(1, "one");
    cache.put(2, "two");
    std::string out;
    assert(cache.get(1, out) && out == "one");
    assert(cache.get(2, out) && out == "two");
    assert(!cache.get(3, out));
}

void test_lru_eviction() {
    LruCache cache(2);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three"); // evicts key 1
    std::string out;
    assert(!cache.get(1, out));
    assert(cache.get(2, out) && out == "two");
    assert(cache.get(3, out) && out == "three");
}

void test_update_does_not_evict() {
    LruCache cache(2);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(1, "ONE"); // update, no eviction
    std::string out;
    assert(cache.get(1, out) && out == "ONE");
    assert(cache.get(2, out) && out == "two");
    assert(cache.size() == 2);
}

void test_erase() {
    LruCache cache(2);
    cache.put(1, "one");
    cache.put(2, "two");
    assert(cache.erase(1));
    std::string out;
    assert(!cache.get(1, out));
    assert(cache.get(2, out) && out == "two");
    assert(!cache.erase(1)); // already gone
}

void test_snapshot_order() {
    LruCache cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    auto snap = cache.snapshot();
    assert(snap.size() == 3);
    assert(snap[0].first == 3 && snap[0].second == "three");
    assert(snap[1].first == 2 && snap[1].second == "two");
    assert(snap[2].first == 1 && snap[2].second == "one");
}

void test_snapshot_get_updates_order() {
    LruCache cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    std::string out;
    cache.get(1, out); // move 1 to front
    auto snap = cache.snapshot();
    assert(snap[0].first == 1 && snap[0].second == "one");
    assert(snap[1].first == 3 && snap[1].second == "three");
    assert(snap[2].first == 2 && snap[2].second == "two");
}

void test_capacity_zero() {
    LruCache cache(0);
    cache.put(1, "one");
    assert(cache.size() == 0);
    std::string out;
    assert(!cache.get(1, out));
}

void test_put_updates_mru() {
    LruCache cache(3);
    cache.put(1, "one");
    cache.put(2, "two");
    cache.put(3, "three");
    cache.put(2, "TWO"); // move 2 to front
    auto snap = cache.snapshot();
    assert(snap[0].first == 2 && snap[0].second == "TWO");
    assert(snap[1].first == 3 && snap[1].second == "three");
    assert(snap[2].first == 1 && snap[2].second == "one");
}

int main() {
    test_basic_put_get();
    test_lru_eviction();
    test_update_does_not_evict();
    test_erase();
    test_snapshot_order();
    test_snapshot_get_updates_order();
    test_capacity_zero();
    test_put_updates_mru();
    std::cout << "All tests passed." << std::endl;
    return 0;
}
