# Solo GPT120 C++ CSV Aggregator

## Overview
Implements a header‑only `aggregate(std::istream&)` that reads a CSV stream with the exact header `category,amount`. It parses quoted fields, trims whitespace, validates the format, and returns a `std::map<std::string, std::int64_t>` with summed amounts per category.

## Requirements
- C++20
- No external dependencies (header‑only)
- Throws `std::invalid_argument` for any malformed input or overflow.

## Usage
```cpp
#include <sstream>
#include "solution.hpp"

int main(){
    std::istringstream in("category,amount\nfood,10\nfood,-5\n");
    auto result = aggregate(in);
    // result["food"] == 5
}
```

The driver (`PUBLIC_DRIVER.cpp`) reads the whole stdin as a quoted string, feeds it to `aggregate`, and prints JSON.
