#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include "solution.hpp"

int main(){
    // Simple test
    {
        std::istringstream in("category,amount\nfood,10\nfood,5\ntravel,-3\n");
        auto res = aggregate(in);
        if(res.size()!=2 || res.at("food")!=15 || res.at("travel")!=-3){
            std::cerr<<"Simple test failed"<<std::endl;return 1;
        }
    }
    // Quoted fields and error handling
    {
        bool threw=false;
        try{
            std::istringstream bad("category,amount\n\"a,b\",+7\n\"c\"\n,2\n");
            aggregate(bad);
        }catch(const std::invalid_argument&){threw=true;}
        if(!threw){std::cerr<<"Quoted error test failed"<<std::endl;return 1;}
    }
    // Overflow test
    {
        std::ostringstream big;
        big<<"category,amount\n";
        big<<"x,"<<std::numeric_limits<std::int64_t>::max()<<"\n";
        big<<"x,1\n";
        std::istringstream in(big.str());
        bool threw=false;
        try{aggregate(in);}catch(const std::invalid_argument&){threw=true;}
        if(!threw){std::cerr<<"Overflow test failed"<<std::endl;return 1;}
    }
    std::cout<<"All tests passed"<<std::endl;
    return 0;
}
