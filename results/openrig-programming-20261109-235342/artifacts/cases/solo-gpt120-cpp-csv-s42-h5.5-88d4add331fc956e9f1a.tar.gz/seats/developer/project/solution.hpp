#pragma once
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <cctype>

// Helper: trim whitespace from both ends
static std::string trim(const std::string &s){
    size_t start=0; while(start<s.size() && std::isspace(static_cast<unsigned char>(s[start]))) ++start;
    size_t end=s.size(); while(end>start && std::isspace(static_cast<unsigned char>(s[end-1]))) --end;
    return s.substr(start,end-start);
}

// Helper: parse int64, throws on invalid
static std::int64_t parse_int64(const std::string &s){
    std::size_t idx=0; long long val=0;
    try{
        val = std::stoll(s,&idx,10);
    }catch(...){
        throw std::invalid_argument("invalid integer");
    }
    if(idx!=s.size()) throw std::invalid_argument("trailing chars");
    return static_cast<std::int64_t>(val);
}

// Parse a single CSV line into fields respecting quotes and escaped quotes.
static std::vector<std::string> split_csv_line(const std::string &line){
    std::vector<std::string> fields;
    std::string cur;
    bool in_quotes=false;
    for(size_t i=0;i<line.size();++i){
        char c=line[i];
        if(c=='"'){
            if(in_quotes && i+1<line.size() && line[i+1]=='"'){
                cur.push_back('"');
                ++i; // skip escaped quote
            }else{
                in_quotes=!in_quotes;
            }
        }else if(c==',' && !in_quotes){
            fields.push_back(cur);
            cur.clear();
        }else{
            cur.push_back(c);
        }
    }
    fields.push_back(cur);
    return fields;
}

// Main aggregation function
static std::map<std::string, std::int64_t> aggregate(std::istream &in){
    // Read whole input (driver may wrap in quotes)
    std::string data((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    // Remove surrounding quotes if present
    if(data.size()>=2 && data.front()=='"' && data.back()=='"'){
        data = data.substr(1, data.size()-2);
    }
    // Unescape \" sequences (driver may escape quotes)
    std::string unescaped;
    for(size_t i=0;i<data.size();++i){
        if(data[i]=='\\' && i+1<data.size() && data[i+1]=='"'){
            unescaped.push_back('"');
            ++i;
        }else{
            unescaped.push_back(data[i]);
        }
    }
    // Split into lines handling CR
    std::vector<std::string> lines;
    std::string cur;
    for(char c: unescaped){
        if(c=='\r') continue;
        if(c=='\n'){
            lines.push_back(cur);
            cur.clear();
        }else{
            cur.push_back(c);
        }
    }
    if(!cur.empty()) lines.push_back(cur);
    // Find header
    size_t idx=0;
    while(idx<lines.size() && trim(lines[idx]).empty()) ++idx;
    if(idx==lines.size()) throw std::invalid_argument("missing header");
    auto header_fields = split_csv_line(lines[idx]);
    if(header_fields.size()!=2) throw std::invalid_argument("header count");
    if(trim(header_fields[0])!="category" || trim(header_fields[1])!="amount")
        throw std::invalid_argument("invalid header");
    ++idx;
    std::map<std::string, std::int64_t> result;
    for(;idx<lines.size();++idx){
        std::string line = trim(lines[idx]);
        if(line.empty()) continue;
        auto fields = split_csv_line(line);
        if(fields.size()!=2) throw std::invalid_argument("row count");
        std::string cat = trim(fields[0]);
        if(cat.empty()) throw std::invalid_argument("empty category");
        std::int64_t amt = parse_int64(fields[1]);
        auto it = result.find(cat);
        if(it==result.end()) result.emplace(cat, amt);
        else {
            std::int64_t cur = it->second;
            if((amt>0 && cur > std::numeric_limits<std::int64_t>::max() - amt) ||
               (amt<0 && cur < std::numeric_limits<std::int64_t>::min() - amt))
                throw std::invalid_argument("overflow aggregation");
            it->second = cur + amt;
        }
    }
    return result;
}

