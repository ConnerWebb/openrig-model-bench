# Buffer Implementation

This project implements a `Buffer` class in C++ that provides a dynamically resizable array of bytes with bounds checking and proper memory management.

## Features

- **Dynamic Resizing**: The buffer can be resized up or down, preserving existing data and zero-initializing new elements
- **Bounds Checking**: Accessing elements out of bounds throws `std::out_of_range` exception
- **Copy Semantics**: Deep copy on copy construction and copy assignment
- **Move Semantics**: Noexcept move construction and move assignment
- **Zero Initialization**: All elements are zero-initialized on construction and resize

## API

### Constructor
```cpp
Buffer(std::size_t n = 0)
```
Creates a buffer of size `n`, zero-initialized.

### Size
```cpp
std::size_t size() const noexcept
```
Returns the current size of the buffer.

### Element Access
```cpp
uint8_t& operator[](std::size_t index)
const uint8_t& operator[](std::size_t index) const
```
Access elements with bounds checking. Throws `std::out_of_range` if index is out of bounds.

### Resize
```cpp
void resize(std::size_t k)
```
Resizes the buffer to size `k`. Preserves existing elements and zero-initializes new ones.

### Copy and Move
- Copy constructor and copy assignment perform deep copies
- Move constructor and move assignment are noexcept and transfer ownership

## Implementation Details

- Uses raw pointers for storage (for educational purposes)
- Properly handles self-assignment cases
- Volatile assignments are deleted to prevent unsafe operations
- Move operations leave the source in a valid but empty state

## Testing

The implementation includes comprehensive tests covering:
- Default and parameterized construction
- Bounds checking
- Resize operations (both smaller and larger)
- Copy and move semantics
- Self-assignment cases
- Const correctness

Run tests with: `./run_tests`
