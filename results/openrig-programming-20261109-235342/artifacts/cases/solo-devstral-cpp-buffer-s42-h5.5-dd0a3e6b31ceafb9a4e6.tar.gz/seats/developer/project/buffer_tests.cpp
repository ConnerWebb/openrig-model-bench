#include "solution.hpp"
#include <iostream>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    if (b.size() != 0) {
        std::cerr << "FAIL: Default constructor should create size 0 buffer" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Default constructor" << std::endl;
}

void test_constructor_with_size() {
    Buffer b(10);
    if (b.size() != 10) {
        std::cerr << "FAIL: Constructor should create buffer of requested size" << std::endl;
        exit(1);
    }
    for (std::size_t i = 0; i < 10; ++i) {
        if (b[i] != 0) {
            std::cerr << "FAIL: Buffer should be zero-initialized at position " << i << std::endl;
            exit(1);
        }
    }
    std::cout << "PASS: Constructor with size" << std::endl;
}

void test_bounds_checking() {
    Buffer b(5);
    try {
        b[0];
        b[4];
    } catch (...) {
        std::cerr << "FAIL: Valid indices should not throw" << std::endl;
        exit(1);
    }
    try {
        b[5];
        std::cerr << "FAIL: Out of bounds access should throw" << std::endl;
        exit(1);
    } catch (const std::out_of_range&) {
        // Expected
    }
    try {
        b[10];
        std::cerr << "FAIL: Out of bounds access should throw" << std::endl;
        exit(1);
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "PASS: Bounds checking" << std::endl;
}

void test_resize_smaller() {
    Buffer b(10);
    b[0] = 1;
    b[4] = 2;
    b[9] = 3;
    
    b.resize(5);
    if (b.size() != 5) {
        std::cerr << "FAIL: Resize should change size" << std::endl;
        exit(1);
    }
    if (b[0] != 1 || b[4] != 2) {
        std::cerr << "FAIL: Resize should preserve prefix" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Resize smaller" << std::endl;
}

void test_resize_larger() {
    Buffer b(5);
    b[0] = 1;
    b[4] = 2;
    
    b.resize(10);
    if (b.size() != 10) {
        std::cerr << "FAIL: Resize should change size" << std::endl;
        exit(1);
    }
    if (b[0] != 1 || b[4] != 2) {
        std::cerr << "FAIL: Resize should preserve prefix" << std::endl;
        exit(1);
    }
    for (std::size_t i = 5; i < 10; ++i) {
        if (b[i] != 0) {
            std::cerr << "FAIL: New elements should be zero-initialized at position " << i << std::endl;
            exit(1);
        }
    }
    std::cout << "PASS: Resize larger" << std::endl;
}

void test_copy_constructor() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2 = b1;
    if (b2.size() != 5 || b2[0] != 1 || b2[4] != 2) {
        std::cerr << "FAIL: Copy constructor should create identical copy" << std::endl;
        exit(1);
    }
    
    // Modify b2 and ensure b1 is unaffected
    b2[0] = 99;
    if (b1[0] != 1) {
        std::cerr << "FAIL: Copy should be independent" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Copy constructor" << std::endl;
}

void test_move_constructor() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2 = std::move(b1);
    if (b2.size() != 5 || b2[0] != 1 || b2[4] != 2) {
        std::cerr << "FAIL: Move constructor should transfer ownership" << std::endl;
        exit(1);
    }
    
    // b1 should be in valid but empty state
    if (b1.size() != 0) {
        std::cerr << "FAIL: Moved-from buffer should have size 0" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Move constructor" << std::endl;
}

void test_copy_assignment() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2(3);
    b2 = b1;
    if (b2.size() != 5 || b2[0] != 1 || b2[4] != 2) {
        std::cerr << "FAIL: Copy assignment should create identical copy" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Copy assignment" << std::endl;
}

void test_move_assignment() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2(3);
    b2 = std::move(b1);
    if (b2.size() != 5 || b2[0] != 1 || b2[4] != 2) {
        std::cerr << "FAIL: Move assignment should transfer ownership" << std::endl;
        exit(1);
    }
    
    // b1 should be in valid but empty state
    if (b1.size() != 0) {
        std::cerr << "FAIL: Moved-from buffer should have size 0" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Move assignment" << std::endl;
}

void test_self_copy() {
    Buffer b(5);
    b[0] = 1;
    b[4] = 2;
    
    b = b;
    if (b.size() != 5 || b[0] != 1 || b[4] != 2) {
        std::cerr << "FAIL: Self-copy should preserve content" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Self-copy" << std::endl;
}

void test_self_move() {
    Buffer b(5);
    b[0] = 1;
    b[4] = 2;
    
    b = std::move(b);
    if (b.size() != 5 || b[0] != 1 || b[4] != 2) {
        std::cerr << "FAIL: Self-move should preserve content" << std::endl;
        exit(1);
    }
    std::cout << "PASS: Self-move" << std::endl;
}

void test_const_access() {
    const Buffer b(5);
    if (b.size() != 5) {
        std::cerr << "FAIL: Const buffer should report correct size" << std::endl;
        exit(1);
    }
    try {
        b[0];
    } catch (...) {
        std::cerr << "FAIL: Valid const access should not throw" << std::endl;
        exit(1);
    }
    try {
        b[5];
        std::cerr << "FAIL: Out of bounds const access should throw" << std::endl;
        exit(1);
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "PASS: Const access" << std::endl;
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_bounds_checking();
    test_resize_smaller();
    test_resize_larger();
    test_copy_constructor();
    test_move_constructor();
    test_copy_assignment();
    test_move_assignment();
    test_self_copy();
    test_self_move();
    test_const_access();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
