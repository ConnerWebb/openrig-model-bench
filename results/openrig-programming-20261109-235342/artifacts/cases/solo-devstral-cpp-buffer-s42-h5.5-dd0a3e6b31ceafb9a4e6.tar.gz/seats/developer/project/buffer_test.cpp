#include "solution.hpp"
#include <cassert>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
}

void test_bounds_checking() {
    Buffer b(5);
    assert(b[0] == 0);
    assert(b[4] == 0);
    try {
        auto val = b[5];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
    try {
        auto val = b[10];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_resize_smaller() {
    Buffer b(10);
    b[0] = 1;
    b[5] = 2;
    b[9] = 3;
    
    b.resize(6);
    assert(b.size() == 6);
    assert(b[0] == 1);
    assert(b[5] == 2);
}

void test_resize_larger() {
    Buffer b(5);
    b[0] = 1;
    b[4] = 2;
    
    b.resize(10);
    assert(b.size() == 10);
    assert(b[0] == 1);
    assert(b[4] == 2);
    for (std::size_t i = 5; i < 10; ++i) {
        assert(b[i] == 0);
    }
}

void test_copy_constructor() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2 = b1;
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[4] == 2);
    
    // Modify b2 and ensure b1 is unaffected
    b2[0] = 99;
    assert(b1[0] == 1);
}

void test_move_constructor() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2 = std::move(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[4] == 2);
    
    // b1 should be in valid but empty state
    assert(b1.size() == 0);
}

void test_copy_assignment() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2(3);
    b2 = b1;
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[4] == 2);
}

void test_move_assignment() {
    Buffer b1(5);
    b1[0] = 1;
    b1[4] = 2;
    
    Buffer b2(3);
    b2 = std::move(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[4] == 2);
    
    // b1 should be in valid but empty state
    assert(b1.size() == 0);
}

void test_self_copy() {
    Buffer b(5);
    b[0] = 1;
    b[4] = 2;
    
    b = b;
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[4] == 2);
}

void test_self_move() {
    Buffer b(5);
    b[0] = 1;
    b[4] = 2;
    
    b = std::move(b);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[4] == 2);
}

void test_const_access() {
    const Buffer b(5);
    assert(b.size() == 5);
    assert(b[0] == 0);
    try {
        auto val = b[5];
        assert(false && "Should have thrown");
    } catch (const std::out_of_range&) {
        // Expected
    }
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_bounds_checking();
    test_resize_smaller();
    test_resize_larger();
    test_copy_constructor();
    test_move_constructor();
    test_copy_assignment();
    test_move_assignment();
    test_self_copy();
    test_self_move();
    test_const_access();
    return 0;
}
