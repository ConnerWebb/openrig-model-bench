#include "solution.hpp"
#include <iostream>

int main() {
    Buffer b(10);
    b[0] = 1;
    b[5] = 2;
    b[9] = 3;
    
    std::cout << "Before resize:" << std::endl;
    for (std::size_t i = 0; i < 10; ++i) {
        std::cout << (int)b[i] << " ";
    }
    std::cout << std::endl;
    
    b.resize(5);
    
    std::cout << "After resize to 5:" << std::endl;
    for (std::size_t i = 0; i < b.size(); ++i) {
        std::cout << (int)b[i] << " ";
    }
    std::cout << std::endl;
    
    return 0;
}
