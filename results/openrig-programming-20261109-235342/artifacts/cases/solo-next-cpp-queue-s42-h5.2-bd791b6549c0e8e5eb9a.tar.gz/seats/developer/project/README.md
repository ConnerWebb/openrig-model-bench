# BoundedQueue Implementation

A thread-safe, blocking bounded queue implementation in C++20.

## Features

- **Thread-safe**: Uses mutex and condition variables for synchronization
- **Blocking operations**: `push()` blocks when full, `pop()` blocks when empty
- **Graceful shutdown**: `close()` wakes all waiting threads and allows draining
- **FIFO ordering**: Elements are returned in the order they were pushed
- **Move-only support**: Works with move-only types like `std::unique_ptr`

## API

```cpp
template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity);  // Throws std::invalid_argument if capacity is 0
    bool push(T value);                       // Returns false after close
    std::optional<T> pop();                   // Returns nullopt after close and queue is empty
    void close();                             // Idempotent, wakes all waiters
};
```

## Usage

```cpp
#include "solution.hpp"

BoundedQueue<int> q(10);

// Producer
q.push(42);

// Consumer
auto value = q.pop();
if (value) {
    std::cout << *value << std::endl;
}

// Shutdown
q.close();
```

## Testing

```bash
clang++ -std=c++20 -pthread -O2 -o solution_test solution_test.cpp
./solution_test
```

## Implementation Notes

- Uses `std::mutex` and `std::condition_variable` for thread synchronization
- Condition variables are used to block producers when full and consumers when empty
- `close()` sets a flag and notifies all waiting threads
- After close, `push()` returns `false` and `pop()` drains the queue then returns `std::nullopt`
