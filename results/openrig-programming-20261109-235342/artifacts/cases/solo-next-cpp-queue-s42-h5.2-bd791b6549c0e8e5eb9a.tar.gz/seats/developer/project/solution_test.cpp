#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <optional>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <stdexcept>
#include <algorithm>
#include <numeric>
#include <memory>
#include <atomic>

// Include the solution header
#include "solution.hpp"

// Test utilities
bool test_basic_operations() {
    BoundedQueue<int> q(3);
    
    // Test push and pop
    if (!q.push(1)) return false;
    if (!q.push(2)) return false;
    if (!q.push(3)) return false;
    
    // Queue should be full now
    if (q.push(4) != false) return false; // Should block and return false after close
    
    auto v1 = q.pop();
    auto v2 = q.pop();
    auto v3 = q.pop();
    
    if (!v1 || *v1 != 1) return false;
    if (!v2 || *v2 != 2) return false;
    if (!v3 || *v3 != 3) return false;
    
    // Queue should be empty now
    if (q.pop().has_value()) return false;
    
    return true;
}

bool test_zero_capacity() {
    try {
        BoundedQueue<int> q(0);
        return false; // Should have thrown
    } catch (const std::invalid_argument&) {
        return true;
    } catch (...) {
        return false;
    }
}

bool test_close_wakes_waiters() {
    BoundedQueue<int> q(1);
    std::atomic<bool> pusher_blocked = false;
    std::atomic<bool> popper_blocked = false;
    std::atomic<bool> pusher_done = false;
    std::atomic<bool> popper_done = false;
    
    std::thread pusher([&]() {
        q.push(1); // Fill the queue
        pusher_blocked = true;
        q.push(2); // Should block
        pusher_done = true;
    });
    
    std::thread popper([&]() {
        while (!popper_blocked.load()) std::this_thread::yield();
        q.close(); // Close while pusher is blocked
        popper_done = true;
    });
    
    while (!pusher_blocked.load()) std::this_thread::yield();
    popper.join();
    pusher.join();
    
    return pusher_done && popper_done;
}

bool test_fifo_order() {
    BoundedQueue<int> q(10);
    
    for (int i = 0; i < 100; ++i) {
        q.push(i);
    }
    
    for (int i = 0; i < 100; ++i) {
        auto v = q.pop();
        if (!v || *v != i) return false;
    }
    
    return true;
}

bool test_move_only_type() {
    BoundedQueue<std::unique_ptr<int>> q(5);
    
    q.push(std::make_unique<int>(42));
    q.push(std::make_unique<int>(84));
    
    auto v1 = q.pop();
    auto v2 = q.pop();
    
    if (!v1 || !v2) return false;
    if (*v1->get() != 42) return false;
    if (*v2->get() != 84) return false;
    
    return true;
}

bool test_close_idempotent() {
    BoundedQueue<int> q(5);
    
    q.close();
    q.close();
    q.close();
    
    // After close, push should return false
    if (q.push(1) != false) return false;
    
    return true;
}

bool test_producer_consumer() {
    BoundedQueue<int> q(10);
    std::vector<int> produced;
    std::vector<int> consumed;
    std::mutex produced_mutex, consumed_mutex;
    std::atomic<bool> done = false;
    
    std::thread producer([&]() {
        for (int i = 0; i < 100; ++i) {
            q.push(i);
            std::lock_guard<std::mutex> lock(produced_mutex);
            produced.push_back(i);
        }
        done = true;
    });
    
    std::thread consumer([&]() {
        while (!done || !q.pop().has_value()) {
            auto v = q.pop();
            if (v.has_value()) {
                std::lock_guard<std::mutex> lock(consumed_mutex);
                consumed.push_back(*v);
            }
        }
    });
    
    producer.join();
    q.close();
    consumer.join();
    
    std::sort(consumed.begin(), consumed.end());
    
    for (int i = 0; i < 100; ++i) {
        if (std::count(consumed.begin(), consumed.end(), i) != 1) return false;
    }
    
    return true;
}

bool test_drain_after_close() {
    BoundedQueue<int> q(10);
    
    for (int i = 0; i < 5; ++i) {
        q.push(i);
    }
    
    q.close();
    
    for (int i = 0; i < 5; ++i) {
        auto v = q.pop();
        if (!v || *v != i) return false;
    }
    
    // After draining, should return nullopt
    if (q.pop().has_value()) return false;
    
    return true;
}

bool test_multiple_producers() {
    BoundedQueue<int> q(10);
    std::vector<int> produced;
    std::mutex produced_mutex;
    std::atomic<bool> done = false;
    
    std::vector<std::thread> producers;
    for (int p = 0; p < 5; ++p) {
        producers.emplace_back([&]() {
            for (int i = 0; i < 20; ++i) {
                q.push(i);
                std::lock_guard<std::mutex> lock(produced_mutex);
                produced.push_back(i);
            }
        });
    }
    
    for (auto& t : producers) t.join();
    
    q.close();
    
    std::vector<int> consumed;
    while (auto v = q.pop()) {
        consumed.push_back(*v);
    }
    
    std::sort(consumed.begin(), consumed.end());
    std::sort(produced.begin(), produced.end());
    
    return consumed == produced;
}

bool test_multiple_consumers() {
    BoundedQueue<int> q(10);
    std::vector<int> consumed;
    std::mutex consumed_mutex;
    std::atomic<bool> producers_done = false;
    
    std::thread producer([&]() {
        for (int i = 0; i < 100; ++i) {
            q.push(i);
        }
        producers_done = true;
    });
    
    std::vector<std::thread> consumers;
    for (int c = 0; c < 5; ++c) {
        consumers.emplace_back([&]() {
            while (!producers_done || !q.pop().has_value()) {
                auto v = q.pop();
                if (v.has_value()) {
                    std::lock_guard<std::mutex> lock(consumed_mutex);
                    consumed.push_back(*v);
                }
            }
        });
    }
    
    producer.join();
    q.close();
    
    for (auto& t : consumers) t.join();
    
    std::sort(consumed.begin(), consumed.end());
    
    for (int i = 0; i < 100; ++i) {
        if (std::count(consumed.begin(), consumed.end(), i) != 1) return false;
    }
    
    return true;
}

int main() {
    int passed = 0;
    int total = 0;
    
    auto run_test = [&](const char* name, bool (*test)()) {
        ++total;
        try {
            if (test()) {
                std::cout << "PASS: " << name << std::endl;
                ++passed;
            } else {
                std::cout << "FAIL: " << name << std::endl;
            }
        } catch (...) {
            std::cout << "ERROR: " << name << std::endl;
        }
    };
    
    run_test("basic_operations", test_basic_operations);
    run_test("zero_capacity", test_zero_capacity);
    run_test("close_wakes_waiters", test_close_wakes_waiters);
    run_test("fifo_order", test_fifo_order);
    run_test("move_only_type", test_move_only_type);
    run_test("close_idempotent", test_close_idempotent);
    run_test("producer_consumer", test_producer_consumer);
    run_test("drain_after_close", test_drain_after_close);
    run_test("multiple_producers", test_multiple_producers);
    run_test("multiple_consumers", test_multiple_consumers);
    
    std::cout << "\nResults: " << passed << "/" << total << " tests passed" << std::endl;
    
    return passed == total ? 0 : 1;
}
