# CSV Aggregator

This module provides a function to aggregate CSV data by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to total amounts (formatted with 2 decimal places)
        Keys are sorted alphabetically.
        
    Raises:
        ValueError: If the CSV is malformed (wrong header, invalid amounts, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank record must have exactly two fields
- **Category**: Non-empty after whitespace stripping
- **Amount**: 
  - Optional leading `+`
  - 1-12 decimal digits before optional decimal point
  - If decimal point present, 1-2 digits after
  - Non-negative, no exponent notation

## Features

- Handles quoted fields with embedded commas, newlines, and quotes (doubled)
- Unicode category names supported
- Exact decimal arithmetic (no floating-point errors)
- Streaming read (doesn't load entire file into memory)
- Blank records are silently ignored

## Example

```python
from solution import aggregate

result = aggregate('data.csv')
# result might be: {'food': '150.00', 'rent': '200.00'}
```

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
