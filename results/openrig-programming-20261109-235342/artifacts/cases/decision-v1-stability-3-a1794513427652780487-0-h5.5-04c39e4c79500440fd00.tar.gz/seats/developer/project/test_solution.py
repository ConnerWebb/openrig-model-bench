import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,100.00\nfood,50.00\nrent,200.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '150.00', 'rent': '200.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  100.00  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '100.00'})
    
    def test_quoted_categories_with_commas(self):
        """Test categories containing commas"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n"a,b",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '150.00'})
    
    def test_embedded_newlines(self):
        """Test categories with embedded newlines"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"two\nlines",100.00\n"two\nlines",50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '150.00'})
    
    def test_quoted_quotes(self):
        """Test categories with embedded quotes (doubled)"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Use ASCII comma (,) not full-width comma (，)
            content = 'category,amount\n日本，100.00\n日本，50.00\n'.replace('，', ',')
            p.write_text(content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '150.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,+100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '100.00'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,100.00\n\n\nfood,50.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '150.00'})
    
    def test_sorted_keys(self):
        """Test that result keys are sorted"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nzebra,100.00\napple,50.00\nmango,75.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_two_decimal_places(self):
        """Test that amounts are formatted with exactly two decimal places"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,100\nfood,50.5\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '150.50'})
    
    def test_invalid_header_wrong_name(self):
        """Test that wrong header name raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,amount\nx,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_wrong_count(self):
        """Test that header with wrong field count raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount,extra\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_field_count(self):
        """Test that record with wrong field count raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test that empty category raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,100.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test that NaN amount raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_format(self):
        """Test that invalid amount format raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1.234\n', encoding='utf-8')  # 3 decimal places
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote(self):
        """Test that unclosed quote raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x,100.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file(self):
        """Test that empty file raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_decimal_precision(self):
        """Test exact decimal arithmetic"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,0.10\nfood,0.20\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '0.30'})
    
    def test_large_digits(self):
        """Test amount with up to 12 digits before decimal"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,123456789012.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '123456789012.00'})
    
    def test_amount_too_many_digits(self):
        """Test that amount with more than 12 digits raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,1234567890123.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))


if __name__ == '__main__':
    unittest.main()
