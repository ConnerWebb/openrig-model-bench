# CSV Aggregator Solution

This solution implements a function `aggregate(path: str) -> Dict[str, str]` that reads a UTF-8 CSV file and aggregates amounts by category.

## Requirements

- Read UTF-8 CSV as a stream
- Header must be exactly `category,amount`
- Ignore completely blank records
- Every other record has exactly two fields
- Strip category/amount whitespace; category must not be empty
- Amount has optional +, 1-12 decimal digits, optional decimal point followed by 1 or 2 digits; nonnegative, finite, no exponent
- Reject all malformed input with ValueError
- Accumulate using exact decimal arithmetic
- Return category keys sorted, totals formatted with exactly two decimal places
- CSV quoted commas and embedded newlines are valid

## Function Signature

```python
def aggregate(path: str) -> Dict[str, str]:
    """
    Aggregate CSV data by category, summing amounts with exact decimal arithmetic.
    
    Args:
        path: Path to UTF-8 CSV file with header 'category,amount'
        
    Returns:
        Dictionary with category keys sorted and totals formatted with exactly two decimal places
        
    Raises:
        ValueError: For malformed input
    """
```

## Implementation Details

The solution:
1. Uses `csv.reader` to properly parse CSV with quoted fields and embedded newlines
2. Validates the header is exactly `category,amount`
3. Processes each row, validating format and rejecting malformed data
4. Uses `decimal.Decimal` for exact arithmetic
5. Formats results with exactly 2 decimal places
6. Returns sorted dictionary of results