import csv
import decimal
from decimal import Decimal
from typing import Dict

def aggregate(path: str) -> Dict[str, str]:
    """
    Aggregate CSV data by category, summing amounts with exact decimal arithmetic.
    
    Args:
        path: Path to UTF-8 CSV file with header 'category,amount'
        
    Returns:
        Dictionary with category keys sorted and totals formatted with exactly two decimal places
        
    Raises:
        ValueError: For malformed input
    """
    # Set decimal precision high enough for the task
    decimal.getcontext().prec = 50
    
    totals = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f, skipinitialspace=True)
        
        # Read header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
            
        if header != ['category', 'amount']:
            raise ValueError("Header must be exactly 'category,amount'")
            
        # Process each row
        for row_num, row in enumerate(reader, start=2):  # Start at 2 since header is row 1
            if len(row) == 0:
                # Skip completely blank records
                continue
                
            if len(row) != 2:
                raise ValueError(f"Row {row_num} has {len(row)} fields, expected 2")
                
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Check category is not empty
            if not category:
                raise ValueError(f"Row {row_num} has empty category")
                
            # Parse amount
            try:
                # Check if amount is valid format: optional +, 1-12 digits, optional decimal point, 1-2 digits
                if not amount_str:
                    raise ValueError(f"Row {row_num} has empty amount")
                    
                # Validate amount format using regex-like checks
                if amount_str.startswith('-'):
                    raise ValueError(f"Row {row_num} has negative amount")
                    
                if amount_str.startswith('+'):
                    amount_str = amount_str[1:]  # Remove the plus sign
                    
                # Check if it's a valid decimal number
                amount = Decimal(amount_str)
                
                # Check if it's finite and non-negative
                if not amount.is_finite() or amount < 0:
                    raise ValueError(f"Row {row_num} has invalid amount")
                    
                # Check format: up to 12 digits, optional decimal point, 1-2 decimal places
                # Convert to string to check format
                amount_repr = str(amount)
                
                # Check for exponent notation (should not be allowed)
                if 'e' in amount_repr.lower():
                    raise ValueError(f"Row {row_num} has invalid amount format")
                
                if '.' in amount_repr:
                    integer_part, decimal_part = amount_repr.split('.')
                    if len(decimal_part) > 2:
                        raise ValueError(f"Row {row_num} has more than 2 decimal places")
                    # Check that integer part has at most 12 digits
                    if len(integer_part) > 12:
                        raise ValueError(f"Row {row_num} has more than 12 integer digits")
                else:
                    # No decimal point, integer part should have at most 12 digits
                    if len(amount_repr) > 12:
                        raise ValueError(f"Row {row_num} has more than 12 digits")
                    
            except decimal.InvalidOperation:
                raise ValueError(f"Row {row_num} has invalid amount format")
                
            # Accumulate totals
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly two decimal places and sort keys
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
        
    return result