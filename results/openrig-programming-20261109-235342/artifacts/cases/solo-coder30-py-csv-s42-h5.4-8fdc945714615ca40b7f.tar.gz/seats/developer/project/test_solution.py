import unittest
import tempfile
import os
from solution import aggregate

class TestAggregate(unittest.TestCase):
    
    def test_case_00(self):
        # Test case from public-inputs/case-00.csv
        csv_content = '''category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            expected = {
                "a,b": "599.14",
                "food": "2262.01",
                "rent": "2215.92",
                "two\nlines": "1434.24",
                "x\"quote": "1458.60",
                "日本": "909.01"
            }
            self.assertEqual(result, expected)
            os.unlink(f.name)
    
    def test_case_01(self):
        # Test case from public-inputs/case-01.csv
        csv_content = '''category,amount
rent,204.44
rent,965.51
"x""quote",464.96
"a,b",758.07
food,329.33
"a,b",273.11
"two
lines",38.36
food,127.88
rent,128.71
"a,b",182.35
"two
lines",626.01
"two
lines",741.38
"x""quote",469.53
"a,b",124.37
rent,397.36
"x""quote",283.13
rent,754.49
"two
lines",624.22
"x""quote",420.82
"a,b",124.22
日本,984.39
日本,817.87
"x""quote",338.00
日本,978.27
food,45.98
rent,290.01
"two
lines",427.32
日本,660.85
"x""quote",402.73
rent,353.84
rent,70.22
"two
lines",704.87
"two
lines",312.64
rent,788.02
food,277.54
日本,577.44
"a,b",612.46
"two
lines",339.11
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            expected = {
                "a,b": "2074.58",
                "food": "780.73",
                "rent": "3952.60",
                "two\nlines": "3813.91",
                "x\"quote": "2379.17",
                "日本": "4018.82"
            }
            self.assertEqual(result, expected)
            os.unlink(f.name)
    
    def test_empty_file(self):
        csv_content = '''category,amount
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {})
            os.unlink(f.name)
    
    def test_invalid_header(self):
        csv_content = '''wrong,amount
x,1
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_wrong_number_of_fields(self):
        csv_content = '''category,amount
x,1,2
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_empty_category(self):
        csv_content = '''category,amount
,1
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_invalid_amount_nan(self):
        csv_content = '''category,amount
x,NaN
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_unterminated_quote(self):
        csv_content = '''category,amount
"x,1
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)
    
    def test_negative_amount(self):
        csv_content = '''category,amount
x,-1
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

if __name__ == '__main__':
    unittest.main()