import unittest
import solution
import tempfile
import pathlib

class TestAggregate(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.path = pathlib.Path(self.temp_dir.name)
    
    def tearDown(self):
        self.temp_dir.cleanup()
    
    def write_csv(self, content: str) -> str:
        p = self.path / 'test.csv'
        p.write_text(content, encoding='utf-8')
        return str(p)
    
    def test_basic_case(self):
        csv_content = """category,amount
food,100.50
rent,200.75
food,50.25
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'food': '150.75', 'rent': '200.75'})
    
    def test_quoted_fields(self):
        csv_content = """category,amount
"food",100.50
"rent",200.75
"food",50.25
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'food': '150.75', 'rent': '200.75'})
    
    def test_embedded_newlines(self):
        csv_content = """category,amount
"line1
line2",100.50
rent,200.75
"line1
line2",50.25
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'line1\nline2': '150.75', 'rent': '200.75'})
    
    def test_whitespace_stripping(self):
        csv_content = """category,amount
  food  ,  100.50  
rent,200.75
  food  ,  50.25  
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'food': '150.75', 'rent': '200.75'})
    
    def test_invalid_header(self):
        csv_content = """wrong,amount
food,100.50
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_empty_category(self):
        csv_content = """category,amount
,100.50
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_invalid_amount(self):
        csv_content = """category,amount
food,abc
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_nan_amount(self):
        csv_content = """category,amount
food,NaN
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_exponent_amount(self):
        csv_content = """category,amount
food,1e2
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_negative_amount(self):
        csv_content = """category,amount
food,-100.50
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_blank_record(self):
        csv_content = """category,amount
food,100.50

rent,200.75
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'food': '100.50', 'rent': '200.75'})
    
    def test_three_fields(self):
        csv_content = """category,amount
food,100.50,extra
"""
        path = self.write_csv(csv_content)
        with self.assertRaises(ValueError):
            solution.aggregate(path)
    
    def test_unicode_categories(self):
        csv_content = """category,amount
日本,100.50
food,200.75
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'日本': '100.50', 'food': '200.75'})
    
    def test_comma_in_quoted_field(self):
        csv_content = """category,amount
"a,b",100.50
food,200.75
"""
        path = self.write_csv(csv_content)
        result = solution.aggregate(path)
        self.assertEqual(result, {'a,b': '100.50', 'food': '200.75'})

if __name__ == '__main__':
    unittest.main()
