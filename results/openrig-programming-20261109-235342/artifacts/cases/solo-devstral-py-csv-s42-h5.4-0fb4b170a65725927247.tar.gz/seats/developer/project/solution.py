import csv
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.
    
    The CSV must have exactly two columns: 'category' and 'amount'.
    - Header must be exactly: category,amount
    - Ignore completely blank records
    - Every other record must have exactly two fields
    - Strip whitespace from category and amount
    - Category must not be empty after stripping
    - Amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits
    - Reject malformed input with ValueError
    - Use exact decimal arithmetic for accumulation
    - Return category keys sorted, totals formatted with exactly two decimal places
    """
    totals = {}
    
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        # Read header
        try:
            header = next(reader)
        except StopIteration:
            # Empty file
            return {}
        
        # Validate header
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        # Process each row
        for row in reader:
            # Skip completely blank records
            if not row:
                continue
            
            # Must have exactly two fields
            if len(row) != 2:
                raise ValueError("Row must have exactly two fields")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category cannot be empty")
            
            # Parse amount with strict validation
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError("Invalid amount format")
            
            # Validate amount format: nonnegative, finite, no exponent
            if amount.is_nan() or amount.is_infinite():
                raise ValueError("Amount must be finite")
            if amount < 0:
                raise ValueError("Amount must be nonnegative")
            
            # Check for exponent (should not be present)
            if 'e' in amount_str.lower() or 'E' in amount_str:
                raise ValueError("Amount cannot contain exponent")
            
            # Validate decimal places: exactly 0, 1, or 2
            if amount.as_tuple().exponent < -2:
                raise ValueError("Amount must have at most 2 decimal places")
            
            # Validate digit count: at most 12 digits
            # Remove leading + and decimal point for counting
            digits_only = amount_str.lstrip('+')
            if '.' in digits_only:
                integer_part, decimal_part = digits_only.split('.', 1)
                total_digits = len(integer_part) + len(decimal_part)
            else:
                total_digits = len(digits_only)
            
            if total_digits > 12:
                raise ValueError("Amount must have at most 12 digits")
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Return sorted by category key, formatted with exactly two decimal places
    return {k: str(totals[k].quantize(Decimal('0.01'))) for k in sorted(totals.keys())}
