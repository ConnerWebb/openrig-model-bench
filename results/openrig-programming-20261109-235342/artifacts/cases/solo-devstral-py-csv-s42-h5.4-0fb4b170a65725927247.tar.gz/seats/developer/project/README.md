# CSV Aggregator

This project implements a CSV aggregator that reads a UTF-8 CSV file and aggregates monetary amounts by category.

## Function Signature

```python
def aggregate(path: str) -> dict[str, str]
```

## Requirements

1. **CSV Format**: Must have exactly two columns with header `category,amount`
2. **Data Validation**:
   - Ignore completely blank records
   - Every other record must have exactly two fields
   - Strip whitespace from category and amount
   - Category must not be empty after stripping
   - Amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits
   - Reject malformed input with `ValueError`
3. **Arithmetic**: Use exact decimal arithmetic for accumulation
4. **Output**: Return category keys sorted, totals formatted with exactly two decimal places

## Features

- Handles quoted fields with commas and embedded newlines
- Supports Unicode characters in category names
- Strict validation of amount format (no exponents, no negative, no NaN, no infinity)
- Efficient streaming CSV parsing (does not read entire file into memory)

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

## Implementation Details

The implementation uses Python's `csv` module for robust CSV parsing and `Decimal` for exact arithmetic. All validation is performed according to the specification in TASK.txt.
