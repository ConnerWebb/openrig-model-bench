import builtins
import json
import pathlib
import tempfile
import unittest

import solution

CASES = json.loads(pathlib.Path("PUBLIC_CASES.json").read_text(encoding="utf-8"))


class AggregateTests(unittest.TestCase):
    def _run(self, csv_text: str):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / "input.csv"
            p.write_text(csv_text, encoding="utf-8")
            return solution.aggregate(str(p))

    def test_public_cases(self):
        for i, case in enumerate(CASES):
            with self.subTest(case=i):
                expected = case["expected"]
                if "error" in expected:
                    exc = getattr(builtins, expected["error"])
                    with self.assertRaises(exc):
                        self._run(case["driver_input"]["csv"])
                else:
                    self.assertEqual(
                        self._run(case["driver_input"]["csv"]), expected["value"]
                    )

    def test_blank_lines_ignored(self):
        self.assertEqual(
            self._run("category,amount\n\na,1.5\n\n\nb,2\n"),
            {"a": "1.50", "b": "2.00"},
        )

    def test_exact_decimal_accumulation(self):
        self.assertEqual(
            self._run("category,amount\na,0.1\na,0.2\n"), {"a": "0.30"}
        )

    def test_plus_sign_and_no_decimal(self):
        self.assertEqual(
            self._run("category,amount\na,+12\nb,3.4\n"),
            {"a": "12.00", "b": "3.40"},
        )

    def test_twelve_digit_max(self):
        self.assertEqual(
            self._run("category,amount\na,999999999999\n"),
            {"a": "999999999999.00"},
        )

    def test_bad_amounts(self):
        for bad in ["1.234", "1e3", "-0", "1.", ".5", "1,000", " 1 2", ""]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    self._run(f"category,amount\na,{bad}\n")

    def test_bad_header_and_records(self):
        for bad in ["", "Category,amount\na,1\n", "category,amount\na,1,2\n",
                    "category,amount\n ,1\n"]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    self._run(bad)


if __name__ == "__main__":
    unittest.main()
