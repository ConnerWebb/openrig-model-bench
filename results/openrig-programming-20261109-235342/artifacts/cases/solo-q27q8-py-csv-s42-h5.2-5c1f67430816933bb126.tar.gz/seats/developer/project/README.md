# CSV category/amount aggregator

`solution.aggregate(path: str) -> dict[str, str]`

Reads a UTF-8 CSV file **as a stream** (via `csv.reader` over the open file
handle; the file is never loaded into memory in one go).

## Contract

- Header must be exactly `category,amount` (case-sensitive, no extra fields).
- Completely blank records are ignored; every other record must have exactly
  two fields.
- `category` and `amount` are whitespace-stripped; category must be
  non-empty after stripping.
- Amount grammar: optional `+`, 1–12 decimal digits, optional `.` followed by
  1 or 2 digits. Nonnegative, finite, no exponent, no thousands separators.
- Any malformed input (bad header, wrong field count, empty category, bad
  amount, unterminated quote, etc.) raises `ValueError`.
- Accumulation uses `decimal.Decimal` for exact arithmetic.
- Returns `{category: total}` with keys sorted and totals formatted with
  exactly two decimal places.
- Quoted fields with embedded commas/newlines are valid CSV and supported.

## Tests

`test_solution.py` (stdlib `unittest`) covers all public cases in
`PUBLIC_CASES.json` plus edge cases: blank lines, exact decimal sums,
12-digit bounds, and malformed inputs.

Run: `python3 -m unittest test_solution -v`
