#pragma once
#include <iostream>
#include <map>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <sstream>

std::map<std::string, std::int64_t> aggregate(std::istream& in);