#include "solution.hpp"
#include <iostream>
#include <map>
#include <string>
#include <cstdint>
#include <sstream>
#include <stdexcept>

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read header
    std::string header_line;
    if (!std::getline(in, header_line)) {
        return result;
    }
    
    // Validate header
    if (header_line != "category,amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    // Read data lines
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        
        // Find the first comma to separate category and amount
        size_t comma_pos = line.find(',');
        if (comma_pos != std::string::npos) {
            std::string category = line.substr(0, comma_pos);
            std::string amount_str = line.substr(comma_pos + 1);
            
            // Trim category (remove leading/trailing whitespace)
            size_t first = category.find_first_not_of(" \t\r");
            if (first == std::string::npos) {
                throw std::invalid_argument("Empty category");
            }
            size_t last = category.find_last_not_of(" \t\r");
            category = category.substr(first, (last - first + 1));
            
            if (category.empty()) {
                throw std::invalid_argument("Empty category");
            }
            
            // Parse amount
            std::int64_t amount;
            try {
                amount = std::stoll(amount_str);
            } catch (const std::out_of_range&) {
                throw std::invalid_argument("Amount out of range");
            } catch (const std::invalid_argument&) {
                throw std::invalid_argument("Invalid amount format");
            }
            
            result[category] += amount;
        } else {
            throw std::invalid_argument("Wrong field count");
        }
    }
    
    return result;
}