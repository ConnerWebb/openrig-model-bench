# CSV Aggregator Solution

This solution implements a function to aggregate CSV data by category, summing the amounts for each category.

## Function Signature
```cpp
std::map<std::string, std::int64_t> aggregate(std::istream& in);
```

## Features
- Parses CSV input with "category,amount" header
- Sums amounts for each category
- Handles whitespace trimming in category names
- Throws `std::invalid_argument` for invalid inputs
- Properly handles empty lines and malformed data

## Input Format
The input should be a CSV stream with:
- Header line: "category,amount"
- Data lines: "category,amount" (one per line)
- Categories may have leading/trailing whitespace (which is trimmed)

## Output
Returns a `std::map<std::string, std::int64_t>` where:
- Keys are category names (trimmed)
- Values are the sum of amounts for each category

## Error Handling
- Throws `std::invalid_argument` for invalid headers
- Throws `std::invalid_argument` for malformed lines
- Throws `std::invalid_argument` for invalid amount formats
- Throws `std::invalid_argument` for out-of-range amounts