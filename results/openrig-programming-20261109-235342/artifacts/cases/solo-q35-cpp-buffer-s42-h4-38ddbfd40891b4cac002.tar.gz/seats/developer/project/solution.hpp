#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Default constructor
    Buffer(std::size_t n = 0) : p(n > 0 ? new std::uint8_t[n] : nullptr), n(n) {}

    // Destructor
    ~Buffer() {
        delete[] p;
    }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p(other.n > 0 ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (other.n > 0) {
            std::copy(other.p, other.p + other.n, p);
        }
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] p;
            n = other.n;
            p = n > 0 ? new std::uint8_t[n] : nullptr;
            if (n > 0) {
                std::copy(other.p, other.p + other.n, p);
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Size accessor
    std::size_t size() const noexcept {
        return n;
    }

    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize with prefix preservation and zero-initialization
    void resize(std::size_t k) {
        if (k == n) return;

        std::uint8_t* new_p = k > 0 ? new std::uint8_t[k] : nullptr;

        if (k < n) {
            // Shrink: copy prefix
            if (n > 0 && new_p != nullptr) {
                std::copy(p, p + k, new_p);
            }
        } else {
            // Grow: copy all existing and zero-initialize new bytes
            if (n > 0) {
                std::copy(p, p + n, new_p);
            }
            // Zero-initialize remaining bytes
            if (k > n && new_p != nullptr) {
                std::fill(new_p + n, new_p + k, static_cast<std::uint8_t>(0));
            }
        }

        delete[] p;
        p = new_p;
        n = k;
    }
};
