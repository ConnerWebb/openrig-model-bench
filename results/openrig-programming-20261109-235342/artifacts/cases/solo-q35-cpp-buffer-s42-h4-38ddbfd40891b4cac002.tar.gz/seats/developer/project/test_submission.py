#!/usr/bin/env python3
"""Tests for Buffer class implementation using unittest."""

import json
import subprocess
import sys
import tempfile
import os
import unittest


def compile_and_run_cpp_test(test_code: str, solution_path: str) -> tuple[bool, str, str]:
    """Compile and run C++ test code, return (success, stdout, stderr)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.cpp")
        with open(test_file, "w") as f:
            f.write(test_code)
        
        # Copy solution.hpp to temp dir
        solution_file = os.path.join(tmpdir, "solution.hpp")
        with open(solution_path, "r") as src:
            with open(solution_file, "w") as dst:
                dst.write(src.read())
        
        exe_file = os.path.join(tmpdir, "test")
        compile_cmd = [
            "clang++", "-std=c++20", "-fuse-ld=bfd", "-Wall", "-Wextra",
            "-o", exe_file, test_file
        ]
        
        try:
            compile_result = subprocess.run(
                compile_cmd, capture_output=True, text=True, timeout=30
            )
            if compile_result.returncode != 0:
                return False, "", compile_result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "Compilation timeout"
        
        run_result = subprocess.run(
            [exe_file], capture_output=True, text=True, timeout=10
        )
        return run_result.returncode == 0, run_result.stdout, run_result.stderr


def parse_test_output(stdout: str) -> dict:
    """Parse test output into a dictionary."""
    result = {}
    for line in stdout.strip().split('\n'):
        line = line.strip()
        if not line:
            continue
        if line.startswith("VALUE:"):
            result['value'] = [int(x) for x in line[6:].split(',')]
        elif line.startswith("COPY_SIZE:"):
            result['copy_size'] = int(line[10:])
        elif line.startswith("COPY:"):
            result['copy'] = [int(x) for x in line[5:].split(',')]
        elif line.startswith("MOVED_SIZE:"):
            result['moved_size'] = int(line[12:])
        elif line.startswith("ORIGINAL_AFTER_MOVE_SIZE:"):
            result['original_after_move_size'] = int(line[27:])
        elif line.startswith("BOUNDS:"):
            result['bounds'] = line[7:] == "true"
    return result


class TestBuffer(unittest.TestCase):
    """Test cases for Buffer class."""

    def load_public_cases(self):
        """Load public test cases from JSON file."""
        with open("PUBLIC_CASES.json", "r") as f:
            return json.load(f)

    def test_public_cases(self):
        """Run all public test cases."""
        cases = self.load_public_cases()
        solution_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "solution.hpp")
        
        for i, case in enumerate(cases):
            driver_input = case["driver_input"]
            expected = case["expected"]
            
            test_code = f'''
#include <iostream>
#include <vector>
#include <stdexcept>
#include "solution.hpp"

int main() {{
    std::vector<std::string> parts;
    std::string input = "{driver_input}";
    std::string current;
    for (char c : input) {{
        if (c == ' ') {{
            if (!current.empty()) {{
                parts.push_back(current);
                current.clear();
            }}
        }} else {{
            current += c;
        }}
    }}
    if (!current.empty()) {{
        parts.push_back(current);
    }}

    if (parts.empty()) {{
        std::cerr << "No input" << std::endl;
        return 1;
    }}

    size_t initial_size = std::stoull(parts[0]);
    std::vector<uint8_t> initial_data;
    for (size_t i = 1; i < parts.size(); ++i) {{
        initial_data.push_back(std::stoull(parts[i]));
    }}

    Buffer buf(initial_size);
    for (size_t i = 0; i < initial_data.size() && i < initial_size; ++i) {{
        buf[i] = initial_data[i];
    }}

    // Test resize to larger size
    buf.resize(70);

    // Output value
    std::cout << "VALUE:";
    for (size_t i = 0; i < buf.size(); ++i) {{
        std::cout << (i > 0 ? "," : "") << (int)buf[i];
    }}
    std::cout << std::endl;

    // Test copy
    Buffer copy = buf;
    std::cout << "COPY_SIZE:" << copy.size() << std::endl;
    std::cout << "COPY:";
    for (size_t i = 0; i < copy.size(); ++i) {{
        std::cout << (i > 0 ? "," : "") << (int)copy[i];
    }}
    std::cout << std::endl;

    // Test move
    Buffer moved = std::move(buf);
    std::cout << "MOVED_SIZE:" << moved.size() << std::endl;
    std::cout << "ORIGINAL_AFTER_MOVE_SIZE:" << moved.size() << std::endl;

    // Test bounds checking
    try {{
        buf[1000] = 0;
        std::cout << "BOUNDS:false" << std::endl;
    }} catch (const std::out_of_range& e) {{
        std::cout << "BOUNDS:true" << std::endl;
    }}

    return 0;
}}
'''
            success, stdout, stderr = compile_and_run_cpp_test(test_code, solution_path)
            if not success:
                self.fail(f"Case {i+1} compilation/execution failed: {stderr}")
            
            result = parse_test_output(stdout)
            
            if 'value' in expected:
                self.assertEqual(result.get('value'), expected['value'],
                               f"Case {i+1} value mismatch")
            
            if 'moved_size' in expected:
                self.assertEqual(result.get('moved_size'), expected['moved_size'],
                               f"Case {i+1} moved size mismatch")
            
            if 'copy' in expected:
                self.assertEqual(result.get('copy'), expected['copy'],
                               f"Case {i+1} copy mismatch")
            
            if 'bounds' in expected:
                self.assertEqual(result.get('bounds'), expected['bounds'],
                               f"Case {i+1} bounds check mismatch")


if __name__ == "__main__":
    unittest.main(verbosity=2)
