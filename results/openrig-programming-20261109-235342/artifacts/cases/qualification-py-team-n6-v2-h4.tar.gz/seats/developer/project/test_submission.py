import unittest,validation
class ModuleCheck(unittest.TestCase):
 def test_normalize(self):
  x=[{'id':' a ','category':' b ','cents':2}];self.assertEqual(validation.normalize(x),[{'id':'a','category':'b','cents':2}]);self.assertEqual(x[0]['id'],' a ');self.assertEqual(validation.normalize([]),[])
