# validation.py

## Module: `validation`

### `normalize(records)`

Validates and normalizes a list of record dictionaries.

**Parameters:**
- `records`: List of dictionaries, each with keys `id`, `category`, and `cents`

**Validation rules:**
- Each record must be a dictionary with exactly the keys `id`, `category`, and `cents`
- `id`: must be a non-empty string after stripping whitespace
- `category`: must be a non-empty string after stripping whitespace
- `cents`: must be a non-negative integer (excluding booleans)

**Returns:**
- A new list of normalized record dictionaries with stripped `id` and `category` values

**Raises:**
- `ValueError`: If any record fails validation

**Behavior:**
- Does not mutate the input records
- Preserves duplicates and input order
- Returns fresh dictionaries for each normalized record
