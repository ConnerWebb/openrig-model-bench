import unittest
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    """Test the normalize function in validation module."""
    
    def test_valid_record(self):
        """Test normalizing a valid record."""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])
        # Should not mutate input
        self.assertEqual(records[0]['id'], ' x ')
    
    def test_empty_list(self):
        """Test normalizing empty list."""
        result = validation.normalize([])
        self.assertEqual(result, [])
    
    def test_multiple_valid_records(self):
        """Test normalizing multiple valid records."""
        records = [
            {'id': ' 1 ', 'category': ' a ', 'cents': 10},
            {'id': ' 2 ', 'category': ' b ', 'cents': 20}
        ]
        result = validation.normalize(records)
        self.assertEqual(result, [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'b', 'cents': 20}
        ])
    
    def test_invalid_record_missing_key(self):
        """Test that missing keys raise ValueError."""
        records = [{'id': 'x', 'category': 'a'}]  # missing 'cents'
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_extra_key(self):
        """Test that extra keys raise ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': 5, 'extra': 'bad'}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_non_string_id(self):
        """Test that non-string id raises ValueError."""
        records = [{'id': 123, 'category': 'a', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_empty_id(self):
        """Test that empty id raises ValueError."""
        records = [{'id': '', 'category': 'a', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_whitespace_only_id(self):
        """Test that whitespace-only id raises ValueError."""
        records = [{'id': '   ', 'category': 'a', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_non_string_category(self):
        """Test that non-string category raises ValueError."""
        records = [{'id': 'x', 'category': 123, 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_empty_category(self):
        """Test that empty category raises ValueError."""
        records = [{'id': 'x', 'category': '', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_whitespace_only_category(self):
        """Test that whitespace-only category raises ValueError."""
        records = [{'id': 'x', 'category': '   ', 'cents': 5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_non_int_cents(self):
        """Test that non-int cents raises ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': 5.5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_negative_cents(self):
        """Test that negative cents raises ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_boolean_cents(self):
        """Test that boolean cents raises ValueError."""
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_invalid_record_not_dict(self):
        """Test that non-dict record raises ValueError."""
        records = ['not a dict']
        with self.assertRaises(ValueError):
            validation.normalize(records)
    
    def test_returns_fresh_copies(self):
        """Test that normalize returns fresh copies, not same objects."""
        records = [{'id': 'x', 'category': 'a', 'cents': 5}]
        result = validation.normalize(records)
        self.assertIsNot(result[0], records[0])
        # Modifying result should not affect input
        result[0]['id'] = 'modified'
        self.assertEqual(records[0]['id'], 'x')


class TestStorage(unittest.TestCase):
    """Test the deduplicate function in storage module."""
    
    def test_no_duplicates(self):
        """Test deduplicating records with no duplicates."""
        records = [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'b', 'cents': 20}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result, records)
    
    def test_with_duplicates(self):
        """Test deduplicating records with duplicates."""
        records = [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '1', 'category': 'b', 'cents': 20},
            {'id': '2', 'category': 'c', 'cents': 30}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result, [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'c', 'cents': 30}
        ])
    
    def test_first_wins(self):
        """Test that first occurrence wins."""
        records = [
            {'id': 'x', 'category': 'a', 'cents': 10},
            {'id': 'x', 'category': 'b', 'cents': 20},
            {'id': 'x', 'category': 'c', 'cents': 30}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 10}])
    
    def test_empty_list(self):
        """Test deduplicating empty list."""
        result = storage.deduplicate([])
        self.assertEqual(result, [])
    
    def test_returns_fresh_copies(self):
        """Test that deduplicate returns fresh copies."""
        records = [{'id': 'x', 'category': 'a', 'cents': 5}]
        result = storage.deduplicate(records)
        self.assertIsNot(result[0], records[0])
        # Modifying result should not affect input
        result[0]['category'] = 'modified'
        self.assertEqual(records[0]['category'], 'a')
    
    def test_preserves_order(self):
        """Test that order is preserved based on first occurrence."""
        records = [
            {'id': '3', 'category': 'c', 'cents': 30},
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'b', 'cents': 20},
            {'id': '1', 'category': 'a', 'cents': 15}
        ]
        result = storage.deduplicate(records)
        self.assertEqual([r['id'] for r in result], ['3', '1', '2'])


class TestLedgerProcess(unittest.TestCase):
    """Test the process function in ledger module."""
    
    def test_basic_process(self):
        """Test basic process functionality."""
        records = [{'id': 'x', 'category': 'a', 'cents': 5}]
        result = ledger.process(records)
        self.assertEqual(result, {'events': [{'id': 'x', 'category': 'a', 'cents': 5}], 'totals': {'a': 5}})
    
    def test_empty_list(self):
        """Test processing empty list."""
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})
    
    def test_deduplication(self):
        """Test that duplicates are removed."""
        records = [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '1', 'category': 'b', 'cents': 20}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'a')
    
    def test_total_calculation(self):
        """Test total calculation."""
        records = [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'a', 'cents': 20},
            {'id': '3', 'category': 'b', 'cents': 30}
        ]
        result = ledger.process(records)
        self.assertEqual(result['totals'], {'a': 30, 'b': 30})
    
    def test_totals_sorted(self):
        """Test that totals keys are sorted."""
        records = [
            {'id': '1', 'category': 'c', 'cents': 10},
            {'id': '2', 'category': 'a', 'cents': 20},
            {'id': '3', 'category': 'b', 'cents': 30}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])
    
    def test_minimum_cents_filter(self):
        """Test minimum_cents filter."""
        records = [
            {'id': '1', 'category': 'a', 'cents': 5},
            {'id': '2', 'category': 'a', 'cents': 15},
            {'id': '3', 'category': 'a', 'cents': 25}
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['cents'], 15)
        self.assertEqual(result['events'][1]['cents'], 25)
        self.assertEqual(result['totals'], {'a': 40})
    
    def test_minimum_cents_zero_default(self):
        """Test that minimum_cents defaults to 0."""
        records = [{'id': '1', 'category': 'a', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
    
    def test_minimum_cents_validation_negative(self):
        """Test that negative minimum_cents raises ValueError."""
        records = [{'id': '1', 'category': 'a', 'cents': 5}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)
    
    def test_minimum_cents_validation_boolean(self):
        """Test that boolean minimum_cents raises ValueError."""
        records = [{'id': '1', 'category': 'a', 'cents': 5}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)
    
    def test_validation_in_process(self):
        """Test that invalid records raise ValueError in process."""
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_no_mutation_of_input(self):
        """Test that input is not mutated."""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = {'id': ' x ', 'category': ' a ', 'cents': 5}
        ledger.process(records)
        self.assertEqual(records[0], original)
    
    def test_no_shared_mutable_return(self):
        """Test that returned data is not shared."""
        result1 = ledger.process([{'id': '1', 'category': 'a', 'cents': 5}])
        result2 = ledger.process([{'id': '2', 'category': 'b', 'cents': 10}])
        # Modifying result1 should not affect result2
        result1['totals']['a'] = 999
        self.assertEqual(result2['totals'].get('a'), None)
    
    def test_complex_scenario(self):
        """Test a complex scenario with validation, deduplication, and filtering."""
        records = [
            {'id': ' 1 ', 'category': ' a ', 'cents': 10},
            {'id': ' 1 ', 'category': ' b ', 'cents': 20},  # duplicate, first wins
            {'id': ' 2 ', 'category': ' a ', 'cents': 5},   # filtered by minimum_cents
            {'id': ' 3 ', 'category': ' b ', 'cents': 30}
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['id'], '1')
        self.assertEqual(result['events'][0]['category'], 'a')
        self.assertEqual(result['events'][0]['cents'], 10)
        self.assertEqual(result['events'][1]['id'], '3')
        self.assertEqual(result['events'][1]['category'], 'b')
        self.assertEqual(result['events'][1]['cents'], 30)
        self.assertEqual(result['totals'], {'a': 10, 'b': 30})
    
    def test_keyword_only_minimum_cents(self):
        """Test that minimum_cents is keyword-only."""
        records = [{'id': '1', 'category': 'a', 'cents': 5}]
        # Should raise TypeError if called as positional argument
        with self.assertRaises(TypeError):
            ledger.process(records, 10)


class TestIntegration(unittest.TestCase):
    """Integration tests for the full pipeline."""
    
    def test_full_pipeline(self):
        """Test the full pipeline from raw input to output."""
        # Raw input with whitespace and duplicates
        raw_records = [
            {'id': ' 8 ', 'category': ' c ', 'cents': 1},
            {'id': ' 4 ', 'category': ' a ', 'cents': 96},
            {'id': ' 3 ', 'category': ' b ', 'cents': 11},
            {'id': ' 3 ', 'category': ' c ', 'cents': 7},  # duplicate, first wins (cents=1)
        ]
        
        # Normalize
        normalized = validation.normalize(raw_records)
        self.assertEqual(normalized[0]['id'], '8')
        self.assertEqual(normalized[1]['id'], '4')
        
        # Deduplicate
        deduped = storage.deduplicate(normalized)
        self.assertEqual(len(deduped), 3)  # 4 records, 1 duplicate
        
        # Process with ledger
        result = ledger.process(raw_records)
        self.assertEqual(len(result['events']), 3)
        self.assertEqual(result['totals'], {'a': 96, 'b': 11, 'c': 1})  # c=1 from first record, not 8


if __name__ == '__main__':
    unittest.main()
