# Ledger Toolkit

A Python library for processing transaction records with validation, deduplication, and aggregation.

## Modules

### validation.py

```python
def normalize(records) -> list
```

Validates and normalizes a list of records. Each record must be a dict with exactly three keys:
- `id`: nonempty string (whitespace will be stripped)
- `category`: nonempty string (whitespace will be stripped)
- `cents`: nonnegative integer (booleans are invalid)

Returns a fresh list of normalized records. Raises `ValueError` on invalid input.

### storage.py

```python
def deduplicate(records) -> list
```

Takes validated records and returns a fresh list retaining only the first occurrence of each `id` in input order.

### ledger.py

```python
def process(records, *, minimum_cents=0) -> dict
```

Processes records through validation, deduplication, and filtering:
1. Validates all records using `normalize()`
2. Deduplicates using `deduplicate()`
3. Filters by `minimum_cents` (default 0)
4. Returns `{'events': [...], 'totals': {...}}` where `totals` keys are sorted

## Usage

```python
from ledger import process

records = [
    {'id': ' 1 ', 'category': ' a ', 'cents': 10},
    {'id': ' 1 ', 'category': ' b ', 'cents': 20},  # duplicate id, ignored
    {'id': ' 2 ', 'category': ' a ', 'cents': 30},
]

result = process(records)
# result = {
#   'events': [{'id': '1', 'category': 'a', 'cents': 10}, {'id': '2', 'category': 'a', 'cents': 30}],
#   'totals': {'a': 40}
# }

# With minimum filter
result = process(records, minimum_cents=15)
# result = {
#   'events': [{'id': '2', 'category': 'a', 'cents': 30}],
#   'totals': {'a': 30}
# }
```

## Validation Rules

- `id`: must be a nonempty string after stripping whitespace
- `category`: must be a nonempty string after stripping whitespace
- `cents`: must be a nonnegative integer (not a boolean)

## Notes

- Input data is never mutated
- Each call returns fresh data structures
- Empty input returns `{'events': [], 'totals': {}}`
