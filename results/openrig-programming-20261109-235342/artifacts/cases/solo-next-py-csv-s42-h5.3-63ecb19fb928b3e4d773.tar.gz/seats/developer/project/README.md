# CSV Aggregate Solution

Implements `aggregate(path: str) -> dict[str, str]` that reads a UTF-8 CSV file with header `category,amount`, accumulates amounts per category using exact decimal arithmetic, and returns totals sorted by category key with exactly two decimal places.

## Requirements

- Header must be exactly `category,amount`
- Blank lines are ignored
- Each non-blank record must have exactly two fields
- Category must not be empty after stripping whitespace
- Amount format: optional `+`, 1–12 digits, optional decimal point followed by 1–2 digits
- Rejects `NaN`, `Infinity`, exponents, and malformed input with `ValueError`
- Supports CSV quoting (commas, embedded newlines, embedded quotes)

## Usage

```python
from solution import aggregate
result = aggregate("data.csv")
# result: {"category": "123.45", ...}
```
