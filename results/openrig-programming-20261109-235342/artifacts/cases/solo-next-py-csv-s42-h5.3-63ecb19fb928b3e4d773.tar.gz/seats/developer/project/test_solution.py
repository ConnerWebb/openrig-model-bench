import unittest
import csv
import os
import tempfile
from solution import aggregate


class TestAggregate(unittest.TestCase):

    def test_basic(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nfood,100.50\nrent,200.25\n")
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"food": "100.50", "rent": "200.25"})
            os.unlink(f.name)

    def test_sum(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nfood,100.50\nfood,99.50\n")
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"food": "200.00"})
            os.unlink(f.name)

    def test_sorted_keys(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nz,1\na,2\nm,3\n")
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(list(result.keys()), ["a", "m", "z"])
            os.unlink(f.name)

    def test_whitespace_stripping(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\n  food  ,  100.50  \n")
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"food": "100.50"})
            os.unlink(f.name)

    def test_empty_category_raises(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\n,100\n")
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_wrong_header_raises(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("wrong,amount\nx,1\n")
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_extra_field_raises(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nx,1,2\n")
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_nan_raises(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\nx,NaN\n")
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_quoted_comma(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write('category,amount\n"a,b",100\n')
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"a,b": "100.00"})
            os.unlink(f.name)

    def test_embedded_newline(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write('category,amount\n"two\nlines",100\n')
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"two\nlines": "100.00"})
            os.unlink(f.name)

    def test_quoted_quote(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write('category,amount\n"x""quote",100\n')
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"x\"quote": "100.00"})
            os.unlink(f.name)

    def test_blank_line_ignored(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("category,amount\n\nfood,100\n")
            f.flush()
            result = aggregate(f.name)
            self.assertEqual(result, {"food": "100.00"})
            os.unlink(f.name)

    def test_public_case_00(self):
        with open('public-inputs/case-00.csv', 'r', encoding='utf-8') as f:
            content = f.read()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(content)
            f.flush()
            result = aggregate(f.name)
            expected = {
                "a,b": "599.14",
                "food": "2262.01",
                "rent": "2215.92",
                "two\nlines": "1434.24",
                "x\"quote": "1458.60",
                "日本": "909.01"
            }
            self.assertEqual(result, expected)
            os.unlink(f.name)

    def test_public_case_04(self):
        with open('public-inputs/case-04.csv', 'r', encoding='utf-8') as f:
            content = f.read()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_public_case_05(self):
        with open('public-inputs/case-05.csv', 'r', encoding='utf-8') as f:
            content = f.read()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_public_case_06(self):
        with open('public-inputs/case-06.csv', 'r', encoding='utf-8') as f:
            content = f.read()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_public_case_07(self):
        with open('public-inputs/case-07.csv', 'r', encoding='utf-8') as f:
            content = f.read()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)

    def test_public_case_08(self):
        with open('public-inputs/case-08.csv', 'r', encoding='utf-8') as f:
            content = f.read()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
            os.unlink(f.name)


if __name__ == '__main__':
    unittest.main()
