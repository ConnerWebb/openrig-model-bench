import unittest
import os
import tempfile
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def setUp(self):
        """Create temporary directory for test files."""
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary directory."""
        import shutil
        shutil.rmtree(self.temp_dir)

    def create_test_file(self, content: str) -> str:
        """Helper to create a test CSV file."""
        path = os.path.join(self.temp_dir, 'test.csv')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return path

    def test_basic_aggregation(self):
        """Test basic aggregation with simple data."""
        csv_content = """category,amount
food,100.00
food,200.00
rent,150.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '300.00')
        self.assertEqual(result['rent'], '150.00')

    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = """category,amount
  food  ,  100.50  
  rent  ,  200.75  
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '100.50')
        self.assertEqual(result['rent'], '200.75')

    def test_empty_category_rejected(self):
        """Test that empty category raises ValueError."""
        csv_content = """category,amount
,100.00
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('Category cannot be empty', str(cm.exception))

    def test_wrong_header_rejected(self):
        """Test that wrong header raises ValueError."""
        csv_content = """wrong,amount
food,100.00
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('header must be', str(cm.exception))

    def test_extra_fields_rejected(self):
        """Test that rows with extra fields raise ValueError."""
        csv_content = """category,amount
food,100.00,extra
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('Expected 2 fields', str(cm.exception))

    def test_insufficient_fields_rejected(self):
        """Test that rows with insufficient fields raise ValueError."""
        csv_content = """category,amount
food,100.00
rent
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('Expected 2 fields', str(cm.exception))

    def test_invalid_amount_rejected(self):
        """Test that invalid amounts raise ValueError."""
        csv_content = """category,amount
food,100.00
rent,NaN
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('must be finite', str(cm.exception))

    def test_negative_amount_rejected(self):
        """Test that negative amounts raise ValueError."""
        csv_content = """category,amount
food,100.00
rent,-50.00
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('cannot be negative', str(cm.exception))

    def test_non_finite_amount_rejected(self):
        """Test that non-finite amounts raise ValueError."""
        csv_content = """category,amount
food,100.00
rent,Infinity
"""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('must be finite', str(cm.exception))

    def test_empty_file_rejected(self):
        """Test that empty file raises ValueError."""
        csv_content = ""
        path = self.create_test_file(csv_content)
        with self.assertRaises(ValueError) as cm:
            aggregate(path)
        self.assertIn('empty', str(cm.exception))

    def test_blank_rows_ignored(self):
        """Test that completely blank rows are ignored."""
        csv_content = """category,amount
food,100.00

rent,200.00

"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '100.00')
        self.assertEqual(result['rent'], '200.00')

    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas."""
        csv_content = """category,amount
"a,b",100.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['a,b'], '100.00')

    def test_quoted_fields_with_newlines(self):
        """Test quoted fields containing newlines."""
        csv_content = """category,amount
"two
lines",100.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['two\nlines'], '100.00')

    def test_double_quotes_in_quotes(self):
        """Test double quotes within quoted fields."""
        csv_content = """category,amount
"x""quote",100.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['x"quote'], '100.00')

    def test_decimal_precision(self):
        """Test that decimal arithmetic is exact."""
        csv_content = """category,amount
food,0.01
food,0.02
food,0.03
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '0.06')

    def test_sorted_output(self):
        """Test that output keys are sorted."""
        csv_content = """category,amount
z,100.00
a,200.00
m,300.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        keys = list(result.keys())
        self.assertEqual(keys, ['a', 'm', 'z'])

    def test_two_decimal_places(self):
        """Test that totals are formatted to exactly 2 decimal places."""
        csv_content = """category,amount
food,1.00
rent,2.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '1.00')
        self.assertEqual(result['rent'], '2.00')

    def test_case_sensitive_categories(self):
        """Test that categories are case-sensitive."""
        csv_content = """category,amount
Food,100.00
food,200.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['Food'], '100.00')
        self.assertEqual(result['food'], '200.00')

    def test_unicode_categories(self):
        """Test that unicode categories work correctly."""
        csv_content = """category,amount
日本,100.00
中国,200.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['日本'], '100.00')
        self.assertEqual(result['中国'], '200.00')

    def test_large_amounts(self):
        """Test handling of large amounts."""
        csv_content = """category,amount
food,999999999999.99
rent,1.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '999999999999.99')
        self.assertEqual(result['rent'], '1.00')

    def test_zero_amount(self):
        """Test that zero amounts are handled correctly."""
        csv_content = """category,amount
food,0.00
rent,0.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '0.00')
        self.assertEqual(result['rent'], '0.00')

    def test_plus_sign_amount(self):
        """Test that amounts with leading + are handled."""
        csv_content = """category,amount
food,+100.00
rent,+200.00
"""
        path = self.create_test_file(csv_content)
        result = aggregate(path)
        self.assertEqual(result['food'], '100.00')
        self.assertEqual(result['rent'], '200.00')


if __name__ == '__main__':
    unittest.main()