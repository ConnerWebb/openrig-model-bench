# CSV Aggregator

A Python utility that reads CSV files with `category` and `amount` columns, aggregates amounts by category using exact decimal arithmetic, and returns the results as a sorted dictionary with totals formatted to exactly 2 decimal places.

## Features

- **Exact Decimal Arithmetic**: Uses Python's `Decimal` type for precise financial calculations
- **CSV Parsing**: Handles quoted fields with embedded commas and newlines
- **Input Validation**: Strict validation of CSV format and data
- **Whitespace Handling**: Strips whitespace from category and amount fields
- **Error Handling**: Raises `ValueError` for malformed input

## API

### `aggregate(path: str) -> Dict[str, str]`

Reads a CSV file and returns aggregated totals.

**Parameters:**
- `path` (str): Path to the CSV file

**Returns:**
- `Dict[str, str]`: Dictionary mapping category names to total amounts as strings with 2 decimal places

**Raises:**
- `ValueError`: If the CSV header is not "category,amount" or any record is malformed

## CSV Format

The CSV file must have a header row with exactly two columns: `category` and `amount`.

### Example CSV

```csv
category,amount
food,100.00
rent,200.50
"two
lines",150.75
"x""quote",99.99
日本,300.00
```

### Quoted Fields

- Fields containing commas or newlines must be quoted
- Double quotes within quoted fields are escaped with another double quote

## Input Validation

The function validates:

1. **Header**: Must be exactly "category,amount"
2. **Row Count**: Each non-blank row must have exactly 2 fields
3. **Category**: Must not be empty after stripping whitespace
4. **Amount**: Must be a valid decimal number, finite, and non-negative
5. **Blank Rows**: Completely blank rows are ignored

## Error Cases

The function raises `ValueError` for:

- Empty CSV file
- Wrong header format
- Rows with incorrect number of fields
- Empty category names
- Invalid amount formats (NaN, Infinity, negative numbers)
- Non-finite amounts

## Usage

```python
from solution import aggregate

result = aggregate('expenses.csv')
print(result)
# Output: {'food': '300.00', 'rent': '200.50', ...}
```

## Testing

Run the test suite:

```bash
python -m unittest test_solution.py
```

## Implementation Details

- Uses Python's built-in `csv` module for parsing
- Uses `Decimal` from the `decimal` module for exact arithmetic
- Reads the file as a stream (not loading entire file into memory)
- Formats all totals to exactly 2 decimal places using string formatting