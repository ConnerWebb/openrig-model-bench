import csv
import io
from decimal import Decimal, InvalidOperation
from typing import Dict


def aggregate(path: str) -> Dict[str, str]:
    """
    Read a CSV file with category and amount columns, aggregate amounts by category,
    and return sorted category keys with totals formatted to 2 decimal places.

    Args:
        path: Path to the CSV file

    Returns:
        Dictionary mapping category names to total amounts as strings with 2 decimal places

    Raises:
        ValueError: If the CSV header is not "category,amount" or any record is malformed
    """
    totals: Dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("CSV file is empty")

        # Validate header
        if header != ['category', 'amount']:
            raise ValueError("CSV header must be 'category,amount'")

        for row in reader:
            # Skip completely blank rows
            if not row or all(cell.strip() == '' for cell in row):
                continue

            # Validate row has exactly two fields
            if len(row) != 2:
                raise ValueError(f"Expected 2 fields, got {len(row)}")

            category, amount_str = row

            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()

            # Validate category is not empty
            if not category:
                raise ValueError("Category cannot be empty")

            # Parse amount with strict validation
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")

            # Validate amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits
            # This is validated by Decimal constructor, but we ensure it's finite and non-negative
            if not amount.is_finite():
                raise ValueError(f"Amount must be finite: {amount_str}")
            if amount < 0:
                raise ValueError(f"Amount cannot be negative: {amount_str}")
            # Reject scientific notation
            if 'e' in amount_str.lower():
                raise ValueError(f"Invalid amount: {amount_str}")
            # Reject amounts with more than 2 decimal places
            if '.' in amount_str:
                decimal_part = amount_str.split('.')[1]
                if len(decimal_part) > 2:
                    raise ValueError(f"Invalid amount: {amount_str}")

            # Accumulate using exact decimal arithmetic
            totals[category] = totals.get(category, Decimal('0')) + amount

    # Return sorted keys with totals formatted to exactly 2 decimal places
    return {category: f"{amount:.2f}" for category, amount in sorted(totals.items())}