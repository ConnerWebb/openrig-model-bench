# Ledger Processing Module

A Python module for processing ledger records with validation, deduplication, and aggregation.

## Features

- **Validation**: Ensures each record has exactly `id`, `category`, and `cents` fields with proper types
- **Deduplication**: First occurrence of an `id` wins; duplicates are ignored
- **Normalization**: Strips whitespace from `id` and `category` fields
- **Filtering**: Optional `minimum_cents` parameter to filter records by cents value
- **Aggregation**: Computes totals per category with sorted keys

## Usage

```python
from ledger import process

records = [
    {"id": "x", "category": "a", "cents": 100},
    {"id": "y", "category": "b", "cents": 200},
    {"id": "x", "category": "c", "cents": 300}  # duplicate id, ignored
]

result = process(records, minimum_cents=50)
# Returns:
# {
#     "events": [
#         {"id": "x", "category": "a", "cents": 100},
#         {"id": "y", "category": "b", "cents": 200}
#     ],
#     "totals": {"a": 100, "b": 200}
# }
```

## API

### `process(records, minimum_cents=0)`

Process a list of ledger records.

**Parameters:**
- `records`: List of dictionaries with keys `id`, `category`, `cents`
- `minimum_cents`: Optional filter for minimum cents value (default: 0)

**Returns:**
- Dictionary with:
  - `events`: List of normalized records (deduplicated, filtered)
  - `totals`: Dictionary mapping category to sum of cents (keys sorted)

**Raises:**
- `ValueError`: If any record is invalid or `minimum_cents` is invalid

## Record Validation Rules

1. Each record must be a dictionary with exactly three keys: `id`, `category`, `cents`
2. `id` must be a non-empty string (after stripping whitespace)
3. `category` must be a non-empty string (after stripping whitespace)
4. `cents` must be a non-negative integer (booleans are invalid)

## Module Structure

- `ledger.py`: Public facade module
- `engine.py`: Implementation module with validation and processing logic
- `test_ledger.py`: Unit tests

## Running Tests

```bash
python -m unittest test_ledger.py
```
