"""Unit tests for ledger module."""
import unittest
import copy
import ledger


class TestLedgerProcess(unittest.TestCase):
    """Tests for the process function."""

    def test_empty_input(self):
        """process([]) returns empty events/totals."""
        result = ledger.process([])
        self.assertEqual(result, {"events": [], "totals": {}})

    def test_single_valid_record(self):
        """Single valid record is processed correctly."""
        records = [{"id": "x", "category": "a", "cents": 100}]
        result = ledger.process(records)
        self.assertEqual(result["events"], [{"id": "x", "category": "a", "cents": 100}])
        self.assertEqual(result["totals"], {"a": 100})

    def test_whitespace_stripping(self):
        """Whitespace is stripped from id and category."""
        records = [{"id": " x ", "category": " a ", "cents": 100}]
        result = ledger.process(records)
        self.assertEqual(result["events"][0]["id"], "x")
        self.assertEqual(result["events"][0]["category"], "a")

    def test_deduplication_first_wins(self):
        """First occurrence of an id wins."""
        records = [
            {"id": "x", "category": "a", "cents": 100},
            {"id": "x", "category": "b", "cents": 200}
        ]
        result = ledger.process(records)
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(result["events"][0]["category"], "a")
        self.assertEqual(result["totals"], {"a": 100})

    def test_minimum_cents_filter(self):
        """minimum_cents filter works correctly."""
        records = [
            {"id": "x", "category": "a", "cents": 50},
            {"id": "y", "category": "b", "cents": 100}
        ]
        result = ledger.process(records, minimum_cents=75)
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(result["events"][0]["id"], "y")
        self.assertEqual(result["totals"], {"b": 100})

    def test_totals_sorted_keys(self):
        """Totals keys are sorted."""
        records = [
            {"id": "x", "category": "c", "cents": 10},
            {"id": "y", "category": "a", "cents": 20},
            {"id": "z", "category": "b", "cents": 30}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result["totals"].keys()), ["a", "b", "c"])
        self.assertEqual(result["totals"], {"a": 20, "b": 30, "c": 10})

    def test_input_not_mutated(self):
        """Input records are not mutated."""
        records = [{"id": "x", "category": " a ", "cents": 100}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_boolean_cents_invalid(self):
        """Boolean value for cents raises ValueError."""
        records = [{"id": "x", "category": "a", "cents": True}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_negative_cents_invalid(self):
        """Negative cents raises ValueError."""
        records = [{"id": "x", "category": "a", "cents": -1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_empty_id_invalid(self):
        """Empty id raises ValueError."""
        records = [{"id": "", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_whitespace_only_id_invalid(self):
        """Whitespace-only id raises ValueError."""
        records = [{"id": "   ", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_empty_category_invalid(self):
        """Empty category raises ValueError."""
        records = [{"id": "x", "category": "", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_extra_keys_invalid(self):
        """Extra keys in record raises ValueError."""
        records = [{"id": "x", "category": "a", "cents": 1, "extra": 2}]
        with self.assertRaises(ValueError):
            ledger.process(records)

    def test_minimum_cents_validation(self):
        """Invalid minimum_cents raises ValueError."""
        records = [{"id": "x", "category": "a", "cents": 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)

    def test_multiple_records_with_filter(self):
        """Multiple records with minimum_cents filter."""
        records = [
            {"id": "x", "category": "a", "cents": 10},
            {"id": "y", "category": "b", "cents": 20},
            {"id": "z", "category": "a", "cents": 30}
        ]
        result = ledger.process(records, minimum_cents=15)
        self.assertEqual(len(result["events"]), 2)
        self.assertEqual(result["totals"], {"a": 30, "b": 20})

    def test_input_unchanged_after_multiple_calls(self):
        """Input remains unchanged after multiple process calls."""
        records = [{"id": "x", "category": "a", "cents": 100}]
        original = copy.deepcopy(records)
        ledger.process(records)
        ledger.process(records)
        self.assertEqual(records, original)


if __name__ == "__main__":
    unittest.main()
