"""Public facade module for ledger processing."""
from typing import Any, Dict, List

from engine import process as engine_process


def process(records: List[Dict[str, Any]], minimum_cents: int = 0) -> Dict[str, Any]:
    """
    Process ledger records and return events and totals.

    Args:
        records: List of record dictionaries with id, category, cents keys.
        minimum_cents: Optional filter for minimum cents value (default 0).

    Returns:
        Dictionary with 'events' (list of normalized records) and 'totals'
        (dict of category sums, keys sorted).

    Raises:
        ValueError: If any record is invalid.
    """
    return engine_process(records, minimum_cents)
