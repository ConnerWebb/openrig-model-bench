"""Implementation module for ledger processing."""
from typing import Any, Dict, List, Tuple


def _is_valid_id(value: Any) -> bool:
    """Check if value is a nonempty stripped string."""
    return isinstance(value, str) and value.strip() != ""


def _is_valid_category(value: Any) -> bool:
    """Check if value is a nonempty stripped string."""
    return isinstance(value, str) and value.strip() != ""


def _is_valid_cents(value: Any) -> bool:
    """Check if value is a nonnegative integer (excluding booleans)."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return value >= 0
    return False


def _validate_record(record: Dict[str, Any]) -> None:
    """Validate a single record, raising ValueError if invalid."""
    if not isinstance(record, dict):
        raise ValueError("Record must be a dictionary")

    # Check required keys exist
    required_keys = {"id", "category", "cents"}
    if set(record.keys()) != required_keys:
        raise ValueError("Record must have exactly id, category, and cents keys")

    # Validate id
    if not _is_valid_id(record["id"]):
        raise ValueError("id must be a nonempty stripped string")

    # Validate category
    if not _is_valid_category(record["category"]):
        raise ValueError("category must be a nonempty stripped string")

    # Validate cents
    if not _is_valid_cents(record["cents"]):
        raise ValueError("cents must be a nonnegative integer")


def _normalize_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Create a normalized copy of a record with stripped strings."""
    return {
        "id": record["id"].strip(),
        "category": record["category"].strip(),
        "cents": record["cents"]
    }


def process(records: List[Dict[str, Any]], minimum_cents: int = 0) -> Dict[str, Any]:
    """
    Process ledger records and return events and totals.

    Args:
        records: List of record dictionaries with id, category, cents keys.
        minimum_cents: Optional filter for minimum cents value (default 0).

    Returns:
        Dictionary with 'events' (list of normalized records) and 'totals'
        (dict of category sums, keys sorted).

    Raises:
        ValueError: If any record is invalid.
    """
    # Validate minimum_cents parameter
    if not isinstance(minimum_cents, int) or isinstance(minimum_cents, bool):
        raise ValueError("minimum_cents must be a nonnegative integer")
    if minimum_cents < 0:
        raise ValueError("minimum_cents must be nonnegative")

    # Handle empty input
    if not records:
        return {"events": [], "totals": {}}

    # Validate all records first (fail fast)
    for record in records:
        _validate_record(record)

    # Deduplicate: first occurrence wins
    seen_ids = set()
    events: List[Dict[str, Any]] = []

    for record in records:
        normalized = _normalize_record(record)
        record_id = normalized["id"]

        if record_id not in seen_ids:
            # Apply minimum_cents filter
            if normalized["cents"] >= minimum_cents:
                events.append(normalized)
            seen_ids.add(record_id)

    # Calculate totals
    totals_dict: Dict[str, int] = {}
    for event in events:
        category = event["category"]
        totals_dict[category] = totals_dict.get(category, 0) + event["cents"]

    # Sort totals keys
    sorted_totals = dict(sorted(totals_dict.items()))

    return {"events": events, "totals": sorted_totals}
