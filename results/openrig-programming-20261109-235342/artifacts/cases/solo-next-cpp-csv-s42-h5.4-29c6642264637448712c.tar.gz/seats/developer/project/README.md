# CSV Aggregator

This project implements a CSV parser and aggregator for category/amount data.

## Features

- Parses CSV with quoted fields containing commas, newlines, and escaped quotes
- Aggregates amounts by category
- Handles integer overflow detection
- Supports Windows and Unix line endings

## Usage

```cpp
#include "solution.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::string csv = "category,amount\nfood,100\nrent,500\nfood,50\n";
    std::istringstream iss(csv);
    auto result = aggregate(iss);
    
    for (const auto& [cat, amt] : result) {
        std::cout << cat << ": " << amt << "\n";
    }
    return 0;
}
```

## Build

```bash
clang++ -std=c++20 -Wall -Wextra -o myapp myapp.cpp solution.hpp
```
