#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <map>
#include <string>
#include <sstream>
#include <stdexcept>
#include <cstdint>
#include <cctype>

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

std::int64_t parse_int64(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty amount");
    std::size_t pos = 0;
    bool negative = false;
    if (s[0] == '-') {
        negative = true;
        pos = 1;
    } else if (s[0] == '+') {
        pos = 1;
    }
    if (pos >= s.size()) throw std::invalid_argument("no digits in amount");
    for (size_t i = pos; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("invalid digit in amount");
        }
    }
    std::string absStr = s.substr(pos);
    if (absStr.empty()) throw std::invalid_argument("no digits in amount");
    if (absStr.size() > 19) throw std::invalid_argument("overflow in amount");
    std::int64_t result = 0;
    for (char c : absStr) {
        int digit = c - '0';
        if (result > (std::numeric_limits<std::int64_t>::max() - digit) / 10) {
            throw std::invalid_argument("overflow in amount");
        }
        result = result * 10 + digit;
    }
    if (negative) {
        if (result == std::numeric_limits<std::int64_t>::min()) {
            throw std::invalid_argument("overflow in amount");
        }
        result = -result;
    }
    return result;
}

std::string read_quoted_field(std::istream& is) {
    std::string result;
    while (is.good()) {
        int c = is.get();
        if (c == EOF) {
            throw std::invalid_argument("unterminated quoted field");
        }
        char ch = static_cast<char>(c);
        if (ch == '"') {
            int next = is.get();
            if (next == EOF) {
                return result;
            }
            char nch = static_cast<char>(next);
            if (nch == '"') {
                result += '"';
            } else if (nch == ',') {
                return result;
            } else if (nch == '\n') {
                return result;
            } else if (nch == '\r') {
                int next2 = is.get();
                if (next2 == '\n') {
                    return result;
                } else if (next2 != EOF) {
                    is.putback(static_cast<char>(next2));
                }
                return result;
            } else {
                throw std::invalid_argument("invalid character after quote");
            }
        } else {
            result += ch;
        }
    }
    throw std::invalid_argument("unterminated quoted field");
}

std::string read_unquoted_field(std::istream& is) {
    std::string result;
    while (is.good()) {
        int c = is.get();
        if (c == EOF) {
            return result;
        }
        char ch = static_cast<char>(c);
        if (ch == ',' || ch == '\n' || ch == '\r') {
            if (ch == '\r') {
                int next = is.get();
                if (next == '\n') {
                    is.putback('\n');
                } else if (next != EOF) {
                    is.putback(static_cast<char>(next));
                }
            }
            return result;
        }
        result += ch;
    }
    return result;
}

std::string read_field(std::istream& is) {
    int c = is.get();
    if (c == EOF) {
        return "";
    }
    char ch = static_cast<char>(c);
    if (ch == '"') {
        return read_quoted_field(is);
    } else {
        is.putback(ch);
        return read_unquoted_field(is);
    }
}

std::string read_line(std::istream& is) {
    std::string result;
    bool in_quotes = false;
    while (is.good()) {
        int c = is.get();
        if (c == EOF) {
            return result;
        }
        char ch = static_cast<char>(c);
        if (ch == '"') {
            in_quotes = !in_quotes;
            result += ch;
        } else if ((ch == '\r' || ch == '\n') && !in_quotes) {
            if (ch == '\r') {
                int next = is.get();
                if (next == '\n') {
                    return result;
                } else if (next != EOF) {
                    is.putback(static_cast<char>(next));
                }
                return result;
            } else {
                return result;
            }
        } else {
            result += ch;
        }
    }
    return result;
}

} // namespace

std::map<std::string, std::int64_t> aggregate(std::istream& is) {
    std::string header_line = read_line(is);
    std::istringstream header_ss(header_line);
    std::string field1 = read_field(header_ss);
    std::string field2 = read_field(header_ss);
    if (field1 != "category" || field2 != "amount") {
        throw std::invalid_argument("invalid header");
    }
    std::string leftover = read_field(header_ss);
    if (leftover != "" || !header_ss.eof()) {
        throw std::invalid_argument("extra fields in header");
    }

    std::map<std::string, std::int64_t> result;

    while (is.good()) {
        std::string line = read_line(is);
        if (line.empty()) {
            continue;
        }
        std::istringstream line_ss(line);
        std::string category = read_field(line_ss);
        std::string amount_str = read_field(line_ss);
        std::string extra = read_field(line_ss);
        if (extra != "" || !line_ss.eof()) {
            throw std::invalid_argument("wrong field count");
        }
        if (category.empty()) {
            throw std::invalid_argument("empty category");
        }
        category = trim(category);
        if (category.empty()) {
            throw std::invalid_argument("empty category after trim");
        }
        std::int64_t amount = parse_int64(amount_str);
        std::int64_t current = result[category];
        if ((amount > 0 && current > std::numeric_limits<std::int64_t>::max() - amount) ||
            (amount < 0 && current < std::numeric_limits<std::int64_t>::min() - amount)) {
            throw std::invalid_argument("overflow in amount");
        }
        result[category] = current + amount;
    }

    return result;
}

#endif
