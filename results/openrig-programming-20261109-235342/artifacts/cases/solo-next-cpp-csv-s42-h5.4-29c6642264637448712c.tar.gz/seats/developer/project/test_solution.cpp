#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <cassert>
#include "solution.hpp"

void test_basic() {
    std::string input = "category,amount\nfood,100\nrent,200\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 2);
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
}

void test_negative() {
    std::string input = "category,amount\nfood,-50\nfood,30\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["food"] == -20);
}

void test_quoted_comma() {
    std::string input = "category,amount\n\"a,b\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["a,b"] == 100);
}

void test_quoted_newline() {
    std::string input = "category,amount\n\"two\nlines\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
}

void test_escaped_quote() {
    std::string input = "category,amount\n\"x\"\"quote\",100\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result.size() == 1);
    assert(result["x\"quote"] == 100);
}

void test_header_error() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_extra_fields() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_empty_category() {
    std::string input = "category,amount\n,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_nan() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_unterminated_quote() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_exponent() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_overflow_positive() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_overflow_accumulation() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_min_negative() {
    std::string input = "category,amount\nx,-9223372036854775808\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["x"] == -9223372036854775807LL - 1);
}

void test_min_negative_overflow() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_00() {
    std::string input = "category,amount\n\"x\"\"quote\",51268\nfood,4725\nrent,69177\nrent,4517\nfood,-3853\n\"x\"\"quote\",-22826\n\"x\"\"quote\",-4598\n\"x\"\"quote\",-26830\n日本,39039\n\"a,b\",29914\nrent,15786\n日本,-8138\nfood,15570\n\"x\"\"quote\",-26030\n\"two\nlines\",54977\n\"x\"\"quote\",-5124\nrent,12112\n\"two\nlines\",28447\nfood,57027\nfood,2732\n";
    std::istringstream iss(input);
    auto result = aggregate(iss);
    assert(result["a,b"] == 29914);
    assert(result["food"] == 76201);
    assert(result["rent"] == 101592);
    assert(result["two\nlines"] == 83424);
    assert(result["x\"quote"] == -34140);
    assert(result["日本"] == 30901);
}

void test_public_case_04() {
    std::string input = "wrong,amount\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_05() {
    std::string input = "category,amount\nx,1,2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_06() {
    std::string input = "category,amount\n,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_07() {
    std::string input = "category,amount\nx,NaN\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_08() {
    std::string input = "category,amount\n\"x,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_09() {
    std::string input = "category,amount\nx,1e2\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_10() {
    std::string input = "category,amount\nx,9223372036854775808\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_11() {
    std::string input = "category,amount\nx,9223372036854775807\nx,1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

void test_public_case_12() {
    std::string input = "category,amount\nx,-9223372036854775808\nx,-1\n";
    std::istringstream iss(input);
    try {
        aggregate(iss);
        assert(false && "should throw");
    } catch (const std::invalid_argument&) {
    }
}

int main() {
    test_basic();
    test_negative();
    test_quoted_comma();
    test_quoted_newline();
    test_escaped_quote();
    test_header_error();
    test_extra_fields();
    test_empty_category();
    test_nan();
    test_unterminated_quote();
    test_exponent();
    test_overflow_positive();
    test_overflow_accumulation();
    test_min_negative();
    test_min_negative_overflow();
    test_public_case_00();
    test_public_case_04();
    test_public_case_05();
    test_public_case_06();
    test_public_case_07();
    test_public_case_08();
    test_public_case_09();
    test_public_case_10();
    test_public_case_11();
    test_public_case_12();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
