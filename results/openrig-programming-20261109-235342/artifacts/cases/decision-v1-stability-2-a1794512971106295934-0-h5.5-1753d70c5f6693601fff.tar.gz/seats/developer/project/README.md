# Solution: CSV Aggregator

## Overview

This module implements a CSV aggregator that reads UTF-8 CSV files with a `category,amount` header and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Returns a dict with sorted category keys and totals formatted to 2 decimal places.
    Raises ValueError for malformed input.
    """
```

## Features

- **Streaming CSV parsing**: Uses Python's `csv` module for proper handling of quoted fields, embedded commas, and newlines
- **Exact decimal arithmetic**: Uses `decimal.Decimal` to avoid floating-point precision issues
- **Strict validation**:
  - Header must be exactly `category,amount`
  - Each record must have exactly two fields (except blank lines)
  - Category must not be empty after stripping whitespace
  - Amount must match pattern: optional `+`, 1-12 digits, optional decimal point with 1-2 digits
  - Amounts must be nonnegative and finite (no NaN, inf, or exponents)
- **Output**: Sorted keys with values formatted to exactly 2 decimal places

## Running Tests

```bash
python -m unittest test_solution.py
```

Or use the project's test runner:

```bash
run_tests
```

## Examples

Input CSV:
```csv
category,amount
food,10.50
rent,20.25
food,5.00
```

Output:
```python
{"food": "15.50", "rent": "20.25"}
```

## Error Cases

Raises `ValueError` for:
- Invalid header
- Wrong number of fields in a record
- Empty category
- Malformed amount (wrong digit count, exponent, NaN, negative, etc.)
- Unclosed quotes in CSV
