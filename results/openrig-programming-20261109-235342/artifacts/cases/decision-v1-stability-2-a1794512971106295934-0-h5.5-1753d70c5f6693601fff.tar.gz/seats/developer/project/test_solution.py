import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    def test_case_00(self):
        # Load actual public input file
        input_path = pathlib.Path('/work/public-inputs/case-00.csv')
        result = aggregate(str(input_path))
        self.assertEqual(result["a,b"], "599.14")
        self.assertEqual(result["food"], "2262.01")
        self.assertEqual(result["rent"], "2215.92")
        self.assertEqual(result["two\nlines"], "1434.24")
        self.assertEqual(result['x"quote'], "1458.60")
        self.assertEqual(result["日本"], "909.01")

    def test_case_04_invalid_header(self):
        csv_content = "wrong,amount\nx,1\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_case_05_wrong_field_count(self):
        csv_content = "category,amount\nx,1,2\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_case_06_empty_category(self):
        csv_content = "category,amount\n,1\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_case_07_nan_amount(self):
        csv_content = "category,amount\nx,NaN\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_case_08_unclosed_quote(self):
        csv_content = "category,amount\n\"x,1\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_blank_records_ignored(self):
        csv_content = """category,amount
food,10.00

rent,20.00

"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result["food"], "10.00")
            self.assertEqual(result["rent"], "20.00")

    def test_whitespace_stripped(self):
        csv_content = """category,amount
  food  ,  10.50  
  rent  ,  20.25  
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result["food"], "10.50")
            self.assertEqual(result["rent"], "20.25")

    def test_optional_plus_sign(self):
        csv_content = """category,amount
food,+10.50
rent,20.25
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result["food"], "10.50")
            self.assertEqual(result["rent"], "20.25")

    def test_integer_amount(self):
        csv_content = """category,amount
food,100
rent,200
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result["food"], "100.00")
            self.assertEqual(result["rent"], "200.00")

    def test_one_decimal_digit(self):
        csv_content = """category,amount
food,10.5
rent,20.2
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result["food"], "10.50")
            self.assertEqual(result["rent"], "20.20")

    def test_two_decimal_digits(self):
        csv_content = """category,amount
food,10.55
rent,20.25
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result["food"], "10.55")
            self.assertEqual(result["rent"], "20.25")

    def test_three_decimal_digits_rejected(self):
        csv_content = """category,amount
food,10.555
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_negative_amount_rejected(self):
        csv_content = """category,amount
food,-10.50
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_exponent_rejected(self):
        csv_content = """category,amount
food,1e2
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_empty_file_rejected(self):
        csv_content = ""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))

    def test_sorted_keys(self):
        csv_content = """category,amount
zebra,10.00
apple,20.00
mango,30.00
"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'input.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
            keys = list(result.keys())
            self.assertEqual(keys, ["apple", "mango", "zebra"])


if __name__ == '__main__':
    unittest.main()
