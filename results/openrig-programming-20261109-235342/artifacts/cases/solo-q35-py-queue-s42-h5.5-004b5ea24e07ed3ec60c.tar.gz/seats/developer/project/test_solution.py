import unittest
import os
import tempfile
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.path = os.path.join(self.temp_dir, 'test.db')
        self.queue = JobQueue(self.path, max_attempts=3)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_invalid_key_raises(self):
        with self.assertRaises(ValueError):
            self.queue.enqueue('', {'v': 1})
        with self.assertRaises(ValueError):
            self.queue.claim('', 0, 1)
        with self.assertRaises(ValueError):
            self.queue.complete('', 'w')
        with self.assertRaises(ValueError):
            self.queue.fail('', 'w')
        with self.assertRaises(ValueError):
            self.queue.status('')

    def test_invalid_lease_raises(self):
        self.queue.enqueue('a', 1)
        with self.assertRaises(ValueError):
            self.queue.claim('w', 0, 0)
        with self.assertRaises(ValueError):
            self.queue.claim('w', 0, -1)

    def test_invalid_max_attempts_raises(self):
        with self.assertRaises(ValueError):
            JobQueue(self.path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.path, max_attempts=-1)

    def test_enqueue_first_unique_wins(self):
        self.assertTrue(self.queue.enqueue('a', 1))
        self.assertFalse(self.queue.enqueue('a', 2))
        status = self.queue.status('a')
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 0)

    def test_claim_returns_oldest_queued(self):
        self.queue.enqueue('a', 1)
        self.queue.enqueue('b', 2)
        result = self.queue.claim('w', 0, 10)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['attempts'], 1)
        status = self.queue.status('a')
        self.assertEqual(status['state'], 'leased')
        self.assertEqual(status['attempts'], 1)

    def test_complete_requires_matching_owner(self):
        self.queue.enqueue('a', 1)
        result = self.queue.claim('w1', 0, 10)
        self.assertTrue(result)
        self.assertFalse(self.queue.complete('a', 'w2'))
        status = self.queue.status('a')
        self.assertEqual(status['state'], 'leased')

    def test_claim_expired_leased_before_new_queued(self):
        self.queue.enqueue('a', 1)
        self.queue.claim('w1', 0, 1)
        result = self.queue.claim('w2', 2, 10)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['attempts'], 2)

    def test_fail_queues_again_unless_max_attempts(self):
        self.queue.enqueue('a', 1)
        result = self.queue.claim('w', 0, 10)
        self.assertTrue(result)
        self.assertTrue(self.queue.fail('a', 'w'))
        result = self.queue.claim('w2', 0, 10)
        self.assertEqual(result['key'], 'a')
        self.assertEqual(result['attempts'], 2)
        self.assertTrue(self.queue.complete('a', 'w2'))
        status = self.queue.status('a')
        self.assertEqual(status['state'], 'done')
        self.assertEqual(status['attempts'], 2)

    def test_status_nonexistent_key(self):
        self.assertIsNone(self.queue.status('nonexistent'))

    def test_status_returns_state_and_attempts(self):
        self.queue.enqueue('a', 1)
        self.queue.claim('w', 0, 10)
        self.queue.fail('a', 'w')
        self.queue.claim('w2', 0, 10)
        self.queue.complete('a', 'w2')
        status = self.queue.status('a')
        self.assertEqual(status['state'], 'done')
        self.assertEqual(status['attempts'], 2)

if __name__ == '__main__':
    unittest.main()
