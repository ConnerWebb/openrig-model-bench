# Job Queue Implementation

A thread-safe job queue implementation using SQLite for persistence.

## Features

- **Enqueue**: Add jobs with unique keys and JSON-compatible payloads
- **Claim**: Assign jobs to workers with lease expiration
- **Complete**: Mark jobs as successfully completed
- **Fail**: Handle job failures with retry logic
- **Status**: Query job state and attempt count

## API

### `JobQueue(path, max_attempts=3)`
Initialize the job queue with a SQLite database path and maximum retry attempts.

### `enqueue(key, payload)`
Add a new job with the given key and payload. Returns `True` if successful, `False` if the key already exists.

### `claim(worker, now, lease)`
Claim the oldest available job for a worker. Returns job details including key, payload, and attempt count, or `None` if no jobs are available.

### `complete(key, worker)`
Mark a job as completed. Returns `True` if successful.

### `fail(key, worker)`
Mark a job as failed. If max attempts are reached, the job is marked as failed permanently. Otherwise, it's queued again for retry.

### `status(key)`
Return the current state and attempt count for a job, or `None` if the job doesn't exist.

## Usage

```python
from solution import JobQueue

queue = JobQueue('jobs.db', max_attempts=3)

# Add a job
queue.enqueue('task1', {'data': 'important'})

# Claim a job
job = queue.claim('worker1', time.time(), 60)
if job:
    # Process the job
    process(job['payload'])
    queue.complete('task1', 'worker1')
else:
    # No jobs available
    pass
```

## Testing

Run the tests with:
```bash
python -m unittest test_solution.py
```

## Error Handling

All methods validate their inputs and raise `ValueError` for invalid parameters:
- Empty or non-string keys
- Invalid lease times (must be positive)
- Invalid max_attempts (must be positive integer)
- Non-JSON-compatible payloads
