import sqlite3
import json
import time

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.max_attempts = max_attempts
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_db()

    def _init_db(self):
        cur = self.conn.cursor()
        cur.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'queued',
                attempts INTEGER NOT NULL DEFAULT 0,
                owner TEXT,
                expiry REAL
            )
        ''')
        self.conn.commit()

    def enqueue(self, key, payload):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        try:
            payload_json = json.dumps(payload)
        except TypeError:
            raise ValueError("payload must be JSON-compatible")
        cur = self.conn.cursor()
        cur.execute(
            'INSERT OR IGNORE INTO jobs (key, payload, state, attempts) VALUES (?, ?, ?, 0)',
            (key, payload_json, 'queued')
        )
        self.conn.commit()
        return cur.rowcount > 0

    def claim(self, worker, now, lease):
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        if not isinstance(now, (int, float)) or now < 0:
            raise ValueError("now must be a non-negative number")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")
        cur = self.conn.cursor()
        cur.execute('''
            SELECT key, payload, attempts FROM jobs
            WHERE (state = 'queued' OR (state = 'leased' AND expiry <= ?))
            AND attempts < ?
            ORDER BY key
            LIMIT 1
        ''', (now, self.max_attempts))
        row = cur.fetchone()
        if not row:
            # Check if there are any jobs that have reached max_attempts
            cur.execute('''
                UPDATE jobs SET state = 'failed'
                WHERE (state = 'queued' OR state = 'leased')
                AND attempts >= ?
            ''', (self.max_attempts,))
            self.conn.commit()
            return None
        key = row['key']
        payload = json.loads(row['payload'])
        attempts = row['attempts']
        cur.execute('''
            UPDATE jobs SET state = 'leased', owner = ?, expiry = ?, attempts = attempts + 1
            WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND expiry <= ?))
            AND attempts < ?
        ''', (worker, now + lease, key, now, self.max_attempts))
        self.conn.commit()
        if cur.rowcount == 0:
            return None
        return {'key': key, 'payload': payload, 'attempts': attempts + 1}

    def complete(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        cur = self.conn.cursor()
        cur.execute('''
            UPDATE jobs SET state = 'done'
            WHERE key = ? AND state = 'leased' AND owner = ?
        ''', (key, worker))
        self.conn.commit()
        return cur.rowcount > 0

    def fail(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        cur = self.conn.cursor()
        cur.execute('''
            SELECT attempts, state FROM jobs WHERE key = ? AND state = 'leased' AND owner = ?
        ''', (key, worker))
        row = cur.fetchone()
        if not row:
            return False
        attempts = row['attempts']
        if attempts >= self.max_attempts:
            cur.execute('UPDATE jobs SET state = \'failed\' WHERE key = ?', (key,))
        else:
            cur.execute('''
                UPDATE jobs SET state = 'queued', owner = NULL, expiry = NULL
                WHERE key = ?
            ''', (key,))
        self.conn.commit()
        return cur.rowcount > 0

    def status(self, key):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        cur = self.conn.cursor()
        cur.execute('SELECT state, attempts FROM jobs WHERE key = ?', (key,))
        row = cur.fetchone()
        if not row:
            return None
        return {'state': row['state'], 'attempts': row['attempts']}
