# JobQueue

SQLite-backed job queue with leases, retries and unique keys.

## API

`JobQueue(path, max_attempts=3)` — opens (or creates) the SQLite DB at `path`.
`max_attempts` must be a positive integer.

- `enqueue(key, payload) -> bool` — insert a job. First unique key wins;
  duplicate keys return `False`. New jobs are `queued` with `attempts=0`.
  `payload` must be JSON-compatible.
- `claim(worker, now, lease) -> dict | None` — atomically claim the oldest
  insertion-order job that is `queued`, or `leased` with `lease_until <= now`,
  and `attempts < max_attempts`. Increments `attempts`, sets owner and lease
  expiry, returns `{"key", "payload", "attempts"}`. Expired final-attempt
  jobs (attempts already at max) are transitioned to `failed`.
- `complete(key, worker) -> bool` — mark a currently leased job `done`;
  requires matching owner.
- `fail(key, worker) -> bool` — requeue a currently leased job, or mark it
  `failed` if attempts are exhausted; requires matching owner.
- `status(key) -> dict | None` — `{"state", "attempts"}` or `None` if unknown.

Invalid arguments (empty worker/key, non-positive lease, non-positive or
non-integer max_attempts) raise `ValueError`.

## Concurrency

All mutations run inside `BEGIN IMMEDIATE` transactions, so separate
instances/processes sharing the same DB file never lose or duplicate live
claims.

## Tests

`python3 -m unittest test_solution -v`
