"""SQLite-backed job queue with leases, retries and unique keys."""
import json
import sqlite3
import threading


class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or isinstance(max_attempts, bool) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self._path = str(path)
        self._max_attempts = max_attempts
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                state TEXT NOT NULL,
                attempts INTEGER NOT NULL,
                owner TEXT,
                lease_until REAL,
                seq INTEGER NOT NULL
            )"""
        )
        self._conn.commit()

    # -- validation helpers -------------------------------------------------
    @staticmethod
    def _check_key(key):
        if not isinstance(key, str) or not key:
            raise ValueError("key must be a nonempty string")

    @staticmethod
    def _check_worker(worker):
        if not isinstance(worker, str) or not worker:
            raise ValueError("worker must be a nonempty string")

    @staticmethod
    def _check_lease(lease):
        if isinstance(lease, bool) or not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")

    # -- public API ----------------------------------------------------------
    def enqueue(self, key, payload):
        self._check_key(key)
        try:
            payload_json = json.dumps(payload)
        except (TypeError, ValueError):
            raise ValueError("payload must be JSON-compatible")
        with self._lock:
            cur = self._conn.execute(
                "INSERT OR IGNORE INTO jobs (key, payload, state, attempts, seq) "
                "VALUES (?, ?, 'queued', 0, (SELECT COALESCE(MAX(seq), -1) + 1 FROM jobs))",
                (key, payload_json),
            )
            self._conn.commit()
            return cur.rowcount > 0

    def claim(self, worker, now, lease):
        self._check_worker(worker)
        self._check_lease(lease)
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                # Expired final-attempt jobs become failed.
                self._conn.execute(
                    "UPDATE jobs SET state = 'failed', owner = NULL, lease_until = NULL "
                    "WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?",
                    (now, self._max_attempts),
                )
                row = self._conn.execute(
                    """SELECT key, payload, attempts FROM jobs
                       WHERE (state = 'queued'
                              OR (state = 'leased' AND lease_until <= ?))
                         AND attempts < ?
                       ORDER BY seq ASC LIMIT 1""",
                    (now, self._max_attempts),
                ).fetchone()
                if row is None:
                    self._conn.execute("COMMIT")
                    return None
                key, payload_json, attempts = row
                new_attempts = attempts + 1
                self._conn.execute(
                    """UPDATE jobs SET state = 'leased', attempts = ?, owner = ?,
                       lease_until = ? WHERE key = ?""",
                    (new_attempts, worker, now + lease, key),
                )
                self._conn.execute("COMMIT")
                return {"key": key, "payload": json.loads(payload_json), "attempts": new_attempts}
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def complete(self, key, worker):
        self._check_key(key)
        self._check_worker(worker)
        with self._lock:
            cur = self._conn.execute(
                "UPDATE jobs SET state = 'done', owner = NULL, lease_until = NULL "
                "WHERE key = ? AND state = 'leased' AND owner = ?",
                (key, worker),
            )
            self._conn.commit()
            return cur.rowcount > 0

    def fail(self, key, worker):
        self._check_key(key)
        self._check_worker(worker)
        with self._lock:
            row = self._conn.execute(
                "SELECT attempts FROM jobs WHERE key = ? AND state = 'leased' AND owner = ?",
                (key, worker),
            ).fetchone()
            if row is None:
                self._conn.commit()
                return False
            attempts = row[0]
            if attempts >= self._max_attempts:
                new_state = "failed"
            else:
                new_state = "queued"
            self._conn.execute(
                "UPDATE jobs SET state = ?, owner = NULL, lease_until = NULL WHERE key = ?",
                (new_state, key),
            )
            self._conn.commit()
            return True

    def status(self, key):
        self._check_key(key)
        with self._lock:
            row = self._conn.execute(
                "SELECT state, attempts FROM jobs WHERE key = ?", (key,)
            ).fetchone()
            if row is None:
                return None
            return {"state": row[0], "attempts": row[1]}
