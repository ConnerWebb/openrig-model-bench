import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import solution


class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "q.db")
        self.q = solution.JobQueue(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def test_enqueue_unique(self):
        self.assertTrue(self.q.enqueue("a", {"v": 1}))
        self.assertFalse(self.q.enqueue("a", "ignored"))
        self.assertEqual(self.q.status("a"), {"state": "queued", "attempts": 0})

    def test_claim_and_complete(self):
        self.q.enqueue("a", {"v": 5})
        r = self.q.claim("w", 0, 5)
        self.assertEqual(r, {"key": "a", "payload": {"v": 5}, "attempts": 1})
        self.assertFalse(self.q.complete("a", "wrong"))
        self.assertTrue(self.q.complete("a", "w"))
        self.assertEqual(self.q.status("a"), {"state": "done", "attempts": 1})
        self.assertIsNone(self.q.claim("w2", 100, 5))

    def test_fail_requeues(self):
        self.q.enqueue("a", 1)
        self.q.claim("w", 0, 5)
        self.assertTrue(self.q.fail("a", "w"))
        self.assertEqual(self.q.status("a"), {"state": "queued", "attempts": 1})
        r = self.q.claim("w2", 1, 5)
        self.assertEqual(r["attempts"], 2)

    def test_fail_exhausts(self):
        self.q.enqueue("a", 1)
        for i in range(3):
            r = self.q.claim("w", i, 5)
            self.assertIsNotNone(r)
            self.assertTrue(self.q.fail("a", "w"))
        self.assertEqual(self.q.status("a"), {"state": "failed", "attempts": 3})
        self.assertIsNone(self.q.claim("w", 100, 5))

    def test_expired_final_attempt_becomes_failed(self):
        q = solution.JobQueue(self.path, max_attempts=1)
        q.enqueue("x", 0)
        q.claim("w", 0, 2)
        # fail() with attempts exhausted -> failed
        self.assertTrue(q.fail("x", "w"))
        self.assertEqual(q.status("x"), {"state": "failed", "attempts": 1})
        self.assertIsNone(q.claim("other", 100, 2))

    def test_expired_lease_reclaimable(self):
        self.q.enqueue("a", 1)
        self.q.claim("w", 0, 2)
        r = self.q.claim("w2", 2, 2)
        self.assertEqual(r, {"key": "a", "payload": 1, "attempts": 2})

    def test_oldest_first(self):
        self.q.enqueue("b", 2)
        self.q.enqueue("a", 1)
        r = self.q.claim("w", 0, 5)
        self.assertEqual(r["key"], "b")

    def test_status_missing(self):
        self.assertIsNone(self.q.status("nope"))

    def test_invalid_args(self):
        with self.assertRaises(ValueError):
            self.q.claim("", 0, 1)
        with self.assertRaises(ValueError):
            self.q.claim("w", 0, 0)
        with self.assertRaises(ValueError):
            self.q.claim("w", 0, -1)
        with self.assertRaises(ValueError):
            self.q.enqueue("", 1)
        with self.assertRaises(ValueError):
            self.q.complete("a", "")
        with self.assertRaises(ValueError):
            self.q.fail("a", "")
        with self.assertRaises(ValueError):
            self.q.status("")
        with self.assertRaises(ValueError):
            solution.JobQueue(self.path, 0)
        with self.assertRaises(ValueError):
            solution.JobQueue(self.path, -1)
        with self.assertRaises(ValueError):
            solution.JobQueue(self.path, 1.5)

    def test_shared_db(self):
        q2 = solution.JobQueue(self.path)
        self.q.enqueue("a", {"x": 1})
        self.assertEqual(q2.status("a"), {"state": "queued", "attempts": 0})
        r = q2.claim("w", 0, 5)
        self.assertEqual(r["key"], "a")
        self.assertTrue(self.q.complete("a", "w"))

    def test_payload_types(self):
        self.q.enqueue("n", 42)
        self.q.enqueue("s", "hi")
        self.q.enqueue("l", [1, 2])
        self.assertEqual(self.q.claim("w", 0, 5)["payload"], 42)
        self.assertEqual(self.q.claim("w", 0, 5)["payload"], "hi")
        self.assertEqual(self.q.claim("w", 0, 5)["payload"], [1, 2])

    def test_complete_wrong_state(self):
        self.q.enqueue("a", 1)
        self.assertFalse(self.q.complete("a", "w"))  # not leased
        self.assertFalse(self.q.fail("a", "w"))


if __name__ == "__main__":
    unittest.main()
