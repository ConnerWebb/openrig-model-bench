#include "solution.hpp"
#include <iostream>
#include <sstream>
int main(){
    std::string data((std::istreambuf_iterator<char>(std::cin)), std::istreambuf_iterator<char>());
    std::istringstream in(data);
    try{auto m=aggregate(in);std::cout<<"{\n";bool first=true;for(auto &p:m){if(!first)std::cout<<",\n";first=false;std::cout<<"  \""<<p.first<<"\": "<<p.second;}std::cout<<"\n}\n";}catch(const std::exception &e){std::cerr<<e.what();return 1;}
}
