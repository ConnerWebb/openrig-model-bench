#pragma once
#include <cstdint>
#include <istream>
#include <map>
#include <string>
#include <stdexcept>
#include <limits>
#include <vector>
#include <fstream>

inline std::map<std::string,std::int64_t> aggregate(std::istream& in){
    std::string line;
    auto trim=[&](std::string s){
        const auto ws=[&](char c){return c==' '||c=='\t'||c=='\r';};
        size_t b=0; while(b<s.size() && ws(s[b])) ++b;
        size_t e=s.size(); while(e>b && ws(s[e-1])) --e;
        return s.substr(b,e-b);
    };
    if(!std::getline(in,line)) throw std::invalid_argument("empty input");
    if(trim(line)!="category,amount") throw std::invalid_argument("wrong header");
    std::map<std::string,std::int64_t> result;
    while(std::getline(in,line)){
        if(line.find_first_not_of(" \t\r\n")==std::string::npos) continue;
        std::string field; bool in_quote=false; std::vector<std::string> fields;
        for(size_t i=0;i<line.size();++i){char c=line[i];
            if(in_quote){
                if(c=='\"'){
                    if(i+1<line.size() && line[i+1]=='\"'){field.push_back('"');++i;continue;}
                    in_quote=false;continue;
                }else{field.push_back(c);}
            }else{
                if(c=='\"'){in_quote=true;}
                else if(c==','){fields.push_back(trim(field));field.clear();}
                else{field.push_back(c);}
            }
        }
        if(in_quote) throw std::invalid_argument("unterminated quote");
        fields.push_back(trim(field));
        if(fields.size()!=2) throw std::invalid_argument("wrong field count");
        const std::string& cat=fields[0]; const std::string& amt=fields[1];
        if(cat.empty()||amt.empty()) throw std::invalid_argument("empty field");
        try{
            size_t idx=0; long long val=std::stoll(amt,&idx,10);
            if(idx!=amt.size()) throw std::invalid_argument("invalid amount");
            __int128 sum=(__int128)result[cat]+val;
            if(sum< std::numeric_limits<std::int64_t>::min() || sum> std::numeric_limits<std::int64_t>::max()) throw std::invalid_argument("overflow");
            result[cat]=(long long)sum;
        }catch(const std::exception&){throw std::invalid_argument("invalid amount");}
    }
    return result;
}
