# README for solo-gpt20-cpp-csv-s42-h5.5

## Problem

Implement a header‑only C++20 library that parses a CSV file and aggregates the `amount` values per `category`.

* Header: `category,amount`
* `amount` is a signed base‑10 64‑bit integer.
* Fields may be quoted (RFC4180). Quoted fields can contain commas, newlines and escaped double quotes.
* Leading/trailing spaces, tabs and CR are trimmed from fields.
* Empty physical records are ignored.
* Any malformed input (wrong header, wrong field count, empty fields, unterminated quotes, overflow) must throw `std::invalid_argument`.
* Return a `std::map<std::string,std::int64_t>` with sorted keys.

The library is header‑only: `solution.hpp`.

## Build & Test

The project uses the provided test harness. Run:

```bash
run_tests
```

This will compile the test binary with Clang‑22 C++20 and run the tests.

## Files

* `solution.hpp` – implementation.
* `test_solution.cpp` – unit tests.
* `README.md` – this file.

## Notes

The implementation is intentionally minimal and does not read the entire file into memory; it processes line by line.

---
