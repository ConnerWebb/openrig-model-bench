# Solution: CSV Aggregator

## Overview

This module implements a CSV aggregator that reads UTF-8 CSV files and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to totals formatted with exactly two decimal places.
        Categories are sorted alphabetically.
        
    Raises:
        ValueError: If the input is malformed (wrong header, invalid amount format, etc.)
    """
```

## Input Format

- CSV file with header exactly `category,amount`
- Quoted fields may contain commas, embedded newlines, and escaped quotes (as `""`)
- Blank records (all fields empty/whitespace) are ignored
- Non-blank records must have exactly two fields
- Category: non-empty after stripping whitespace
- Amount: optional `+`, 1-12 decimal digits, optional decimal point followed by 1-2 digits

## Output Format

- Dictionary with category keys sorted alphabetically
- Values formatted as strings with exactly two decimal places (e.g., `"150.00"`)

## Example

Input CSV:
```csv
category,amount
food,100.50
rent,200.00
food,50.00
```

Output:
```python
{'food': '150.50', 'rent': '200.00'}
```

## Running Tests

```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
