# Buffer Library

A safe, RAII-managed buffer abstraction implementing size tracking, bounds-checked access, and resize semantics with proper move semantics and exception safety.

## Interface

- `Buffer(std::size_t n = 0)`: Constructs a buffer with optional initial size.
- `~Buffer()`: Destructor that safely deallocates memory.
- `std::size_t size() const noexcept`: Returns current size.
- `uint8_t& operator[](std::size_t i)`: Mutable element access with bounds checking.
- `const uint8_t& operator[](std::size_t i) const`: Const element access with bounds checking.
- `void resize(std::size_t k)`: Resizes buffer, preserving existing data.

## Move Semantics

- Move construction and move assignment are `noexcept`.
- Moved-from buffers have size 0 and can be reused.
- Self-move/copy preserves content.

## Safety Guarantees

- No memory leaks, double frees, or stale reads.
- Bounds checking prevents out-of-range access.
- Resize operations preserve existing data and zero-initialize new bytes.

## Example Usage

```cpp
Buffer buf(10);
buf[0] = 42;
std::size_t s = buf.size();
```

## Testing

Run `run_tests` to verify compliance with public cases.