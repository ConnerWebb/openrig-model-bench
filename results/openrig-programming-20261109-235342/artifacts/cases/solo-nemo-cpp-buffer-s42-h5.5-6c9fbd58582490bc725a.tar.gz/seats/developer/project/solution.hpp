#pragma once
#include <cstdint>
#include <cstddef>
class Buffer{std::uint8_t* p;std::size_t n;public:Buffer(std::size_t n=0):p(new std::uint8_t[n]),n(n){}~Buffer(){delete[] p;}std::size_t size()const{return n;}std::uint8_t&operator[](std::size_t i){return p[i];}const std::uint8_t&operator[](std::size_t i)const{return p[i];}void resize(std::size_t k){n=k;}};
