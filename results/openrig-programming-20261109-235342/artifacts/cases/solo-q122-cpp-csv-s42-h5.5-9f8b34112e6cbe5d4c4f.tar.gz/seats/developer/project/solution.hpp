#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <istream>
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <cctype>
#include <limits>

namespace {

// Strip leading/trailing spaces, tabs, and CR from a string
std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse a CSV line into fields. Returns true if more lines follow, false if EOF.
// Handles quoted fields with embedded commas, newlines, and escaped quotes.
// Sets eof_reached if we hit EOF.
bool parseLine(std::istream& in, std::vector<std::string>& fields, bool& eof_reached) {
    fields.clear();
    eof_reached = false;
    
    int c = in.peek();
    if (c == EOF) {
        eof_reached = true;
        return false;
    }
    
    while (true) {
        std::string field;
        c = in.get();
        
        if (c == EOF) {
            // End of file, this is the last field
            fields.push_back(field);
            eof_reached = true;
            return false;
        }
        
        if (c == '"') {
            // Quoted field
            while (true) {
                c = in.get();
                if (c == EOF) {
                    eof_reached = true;
                    throw std::invalid_argument("Unclosed quoted field");
                }
                if (c == '"') {
                    // Check for escaped quote
                    int next = in.get();
                    if (next == '"') {
                        // Escaped quote, add one quote
                        field += '"';
                    } else {
                        // End of quoted field
                        // Now read until comma or newline
                        if (next == EOF) {
                            eof_reached = true;
                            fields.push_back(field);
                            return false;
                        }
                        if (next == ',') {
                            // Field ends here, move to next field
                            break;
                        }
                        if (next == '\n') {
                            fields.push_back(field);
                            return true;  // More lines follow
                        }
                        if (next == '\r') {
                            int after = in.get();
                            if (after == '\n') {
                                fields.push_back(field);
                                return true;
                            }
                            // \r alone - end of line
                            fields.push_back(field);
                            return true;
                        }
                        // Any other character after closing quote is malformed
                        throw std::invalid_argument("Invalid character after closing quote");
                    }
                } else {
                    field += static_cast<char>(c);
                }
            }
        } else {
            // Unquoted field - read until comma or newline
            if (c != ',') {
                field += static_cast<char>(c);
                while (true) {
                    c = in.get();
                    if (c == EOF) {
                        eof_reached = true;
                        fields.push_back(field);
                        return false;
                    }
                    if (c == ',') {
                        break;
                    }
                    if (c == '\n') {
                        fields.push_back(field);
                        return true;
                    }
                    if (c == '\r') {
                        int next = in.get();
                        if (next == '\n') {
                            fields.push_back(field);
                            return true;
                        }
                        // \r alone - end of line
                        fields.push_back(field);
                        return true;
                    }
                    field += static_cast<char>(c);
                }
            }
            // If c was comma, field is empty, which is fine
        }
        
        // We hit a comma, add the field and continue to next field
        fields.push_back(field);
    }
}

// Parse int64 from string, rejecting overflow, decimals, exponents
std::int64_t parseAmount(const std::string& s) {
    if (s.empty()) {
        throw std::invalid_argument("Empty amount");
    }
    
    size_t start = 0;
    bool negative = false;
    
    if (s[0] == '+') {
        start = 1;
    } else if (s[0] == '-') {
        negative = true;
        start = 1;
    }
    
    if (start >= s.size()) {
        throw std::invalid_argument("No digits in amount");
    }
    
    // Check all remaining chars are digits
    for (size_t i = start; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("Invalid character in amount");
        }
    }
    
    // Parse with overflow check
    std::string digits = s.substr(start);
    
    // Check for overflow before parsing
    if (digits.size() > 19) {
        throw std::invalid_argument("Amount overflow");
    }
    
    // Use unsigned long long for parsing, then check bounds
    unsigned long long val = 0;
    for (char c : digits) {
        val = val * 10 + (c - '0');
    }
    
    if (negative) {
        if (val > static_cast<unsigned long long>(std::numeric_limits<std::int64_t>::max()) + 1ULL) {
            throw std::invalid_argument("Amount underflow");
        }
        if (val == static_cast<unsigned long long>(std::numeric_limits<std::int64_t>::max()) + 1ULL) {
            return std::numeric_limits<std::int64_t>::min();
        }
        return -static_cast<std::int64_t>(val);
    } else {
        if (val > static_cast<unsigned long long>(std::numeric_limits<std::int64_t>::max())) {
            throw std::invalid_argument("Amount overflow");
        }
        return static_cast<std::int64_t>(val);
    }
}

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read header line
    bool eof = false;
    std::vector<std::string> fields;
    bool more = parseLine(in, fields, eof);
    
    if (fields.size() != 2) {
        throw std::invalid_argument("Header must have exactly 2 fields");
    }
    
    std::string f1 = strip(fields[0]);
    std::string f2 = strip(fields[1]);
    
    if (f1 != "category") {
        throw std::invalid_argument("Invalid header: expected 'category'");
    }
    if (f2 != "amount") {
        throw std::invalid_argument("Invalid header: expected 'amount'");
    }
    
    // Read data rows
    while (!eof) {
        std::vector<std::string> row;
        more = parseLine(in, row, eof);
        
        // If we hit EOF and got an empty row, that's normal (no more data)
        if (row.empty() && eof) {
            break;
        }
        
        if (row.size() != 2) {
            throw std::invalid_argument("Each row must have exactly 2 fields");
        }
        
        std::string cat = strip(row[0]);
        std::string amtStr = strip(row[1]);
        
        if (cat.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        if (amtStr.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        std::int64_t amount = parseAmount(amtStr);
        
        // Check for overflow in accumulation
        auto it = result.find(cat);
        if (it != result.end()) {
            std::int64_t oldVal = it->second;
            if (amount > 0 && oldVal > std::numeric_limits<std::int64_t>::max() - amount) {
                throw std::invalid_argument("Accumulation overflow");
            }
            if (amount < 0 && oldVal < std::numeric_limits<std::int64_t>::min() - amount) {
                throw std::invalid_argument("Accumulation underflow");
            }
            it->second = oldVal + amount;
        } else {
            result[cat] = amount;
        }
    }
    
    return result;
}

#endif // SOLUTION_HPP
