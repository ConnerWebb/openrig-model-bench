# CSV Aggregator

This project implements a CSV parser that aggregates amounts by category.

## Features

- Parses CSV files with proper handling of quoted fields
- Supports multiline fields within quotes
- Handles escaped quotes (double quotes)
- Validates input and throws errors for:
  - Empty category names
  - Wrong header format
  - Wrong field count per row
  - Unclosed quoted fields
  - Invalid number formats (NaN, exponents)
  - Integer overflow/underflow during parsing or accumulation

## API

The main function is `aggregate(std::istream& input)` which:
- Takes a CSV input stream
- Returns a `std::map<std::string, std::int64_t>` with aggregated amounts by category
- Throws `std::invalid_argument` for invalid input

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o solution solution.cpp
clang++ -std=c++20 -fuse-ld=bfd -o test_solution test_solution.cpp
```

## Testing

Run the test suite:
```bash
./test_solution
```

Or use the project's test runner:
```bash
run_tests
```
