#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_basic() {
    std::string csv = "category,amount\nfoo,100\nbar,200\nfoo,50\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["foo"] == 150);
    assert(result["bar"] == 200);
    std::cout << "test_basic passed\n";
}

void test_quoted_fields() {
    std::string csv = "category,amount\n\"a,b\",100\n\"x\"\"quote\",50\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["x\"quote"] == 50);
    std::cout << "test_quoted_fields passed\n";
}

void test_multiline_field() {
    std::string csv = "category,amount\n\"two\nlines\",100\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
    std::cout << "test_multiline_field passed\n";
}

void test_negative() {
    std::string csv = "category,amount\nfoo,-100\nbar,50\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["foo"] == -100);
    assert(result["bar"] == 50);
    std::cout << "test_negative passed\n";
}

void test_optional_plus() {
    std::string csv = "category,amount\nfoo,+100\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["foo"] == 100);
    std::cout << "test_optional_plus passed\n";
}

void test_strip_spaces() {
    std::string csv = "category,amount\n  foo  ,  100  \n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["foo"] == 100);
    std::cout << "test_strip_spaces passed\n";
}

void test_empty_category_error() {
    std::string csv = "category,amount\n,100\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category_error passed\n";
    }
}

void test_wrong_header_error() {
    std::string csv = "wrong,amount\nfoo,100\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_header_error passed\n";
    }
}

void test_wrong_field_count_error() {
    std::string csv = "category,amount\nfoo,100,extra\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count_error passed\n";
    }
}

void test_unclosed_quote_error() {
    std::string csv = "category,amount\n\"foo,100\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_unclosed_quote_error passed\n";
    }
}

void test_nan_error() {
    std::string csv = "category,amount\nfoo,NaN\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_nan_error passed\n";
    }
}

void test_exponent_error() {
    std::string csv = "category,amount\nfoo,1e2\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_exponent_error passed\n";
    }
}

void test_overflow_error() {
    std::string csv = "category,amount\nfoo,9223372036854775808\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow_error passed\n";
    }
}

void test_accumulation_overflow() {
    std::string csv = "category,amount\nfoo,9223372036854775807\nfoo,1\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_accumulation_overflow passed\n";
    }
}

void test_accumulation_underflow() {
    std::string csv = "category,amount\nfoo,-9223372036854775808\nfoo,-1\n";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_accumulation_underflow passed\n";
    }
}

void test_min_value() {
    std::string csv = "category,amount\nfoo,-9223372036854775808\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == std::numeric_limits<std::int64_t>::min());
    std::cout << "test_min_value passed\n";
}

void test_max_value() {
    std::string csv = "category,amount\nfoo,9223372036854775807\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == std::numeric_limits<std::int64_t>::max());
    std::cout << "test_max_value passed\n";
}

void test_empty_input() {
    std::string csv = "category,amount\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result.empty());
    std::cout << "test_empty_input passed\n";
}

void test_unicode() {
    std::string csv = "category,amount\n日本,100\n";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["日本"] == 100);
    std::cout << "test_unicode passed\n";
}

int main() {
    test_basic();
    test_quoted_fields();
    test_multiline_field();
    test_negative();
    test_optional_plus();
    test_strip_spaces();
    test_empty_category_error();
    test_wrong_header_error();
    test_wrong_field_count_error();
    test_unclosed_quote_error();
    test_nan_error();
    test_exponent_error();
    test_overflow_error();
    test_accumulation_overflow();
    test_accumulation_underflow();
    test_min_value();
    test_max_value();
    test_empty_input();
    test_unicode();
    
    std::cout << "All tests passed!\n";
    return 0;
}
