#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_basic() {
    std::string csv = "category,amount\nfood,100\nrent,200\nfood,50";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["food"] == 150);
    assert(result["rent"] == 200);
    std::cout << "test_basic passed\n";
}

void test_quoted_fields() {
    std::string csv = "category,amount\n\"a,b\",100\n\"x\"\"quote\",200";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 2);
    assert(result["a,b"] == 100);
    assert(result["x\"quote"] == 200);
    std::cout << "test_quoted_fields passed\n";
}

void test_multiline_quoted() {
    std::string csv = "category,amount\n\"two\nlines\",100\n\"two\nlines\",50";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result.size() == 1);
    assert(result["two\nlines"] == 150);
    std::cout << "test_multiline_quoted passed\n";
}

void test_negative() {
    std::string csv = "category,amount\nfood,100\nfood,-30";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["food"] == 70);
    std::cout << "test_negative passed\n";
}

void test_optional_plus() {
    std::string csv = "category,amount\nfood,+100\nfood,+50";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["food"] == 150);
    std::cout << "test_optional_plus passed\n";
}

void test_strip_outer() {
    std::string csv = "category,amount\n  food  ,  100  \n\trent\t,\t200\t";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    assert(result["food"] == 100);
    assert(result["rent"] == 200);
    std::cout << "test_strip_outer passed\n";
}

void test_empty_category_rejected() {
    std::string csv = "category,amount\n,100";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category_rejected passed\n";
    }
}

void test_wrong_header() {
    std::string csv = "wrong,amount\nx,1";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_header passed\n";
    }
}

void test_wrong_field_count() {
    std::string csv = "category,amount\nx,1,2";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count passed\n";
    }
}

void test_unterminated_quote() {
    std::string csv = "category,amount\n\"x,1";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_unterminated_quote passed\n";
    }
}

void test_invalid_amount() {
    std::string csv = "category,amount\nx,NaN";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_amount passed\n";
    }
}

void test_exponent_rejected() {
    std::string csv = "category,amount\nx,1e2";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_exponent_rejected passed\n";
    }
}

void test_overflow_positive() {
    std::string csv = "category,amount\nx,9223372036854775808";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow_positive passed\n";
    }
}

void test_max_int64() {
    std::string csv = "category,amount\nx,9223372036854775807";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["x"] == 9223372036854775807LL);
    std::cout << "test_max_int64 passed\n";
}

void test_min_int64() {
    std::string csv = "category,amount\nx,-9223372036854775808";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["x"] == -9223372036854775808LL);
    std::cout << "test_min_int64 passed\n";
}

void test_accumulation_overflow() {
    std::string csv = "category,amount\nx,9223372036854775807\nx,1";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_accumulation_overflow passed\n";
    }
}

void test_empty_input() {
    std::string csv = "";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_input passed\n";
    }
}

void test_empty_amount() {
    std::string csv = "category,amount\nx,";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_amount passed\n";
    }
}

void test_sorted_keys() {
    std::string csv = "category,amount\nzebra,1\napple,2\nmango,3";
    std::istringstream in(csv);
    auto result = aggregate(in);
    
    auto it = result.begin();
    assert(it->first == "apple");
    ++it;
    assert(it->first == "mango");
    ++it;
    assert(it->first == "zebra");
    std::cout << "test_sorted_keys passed\n";
}

int main() {
    test_basic();
    test_quoted_fields();
    test_multiline_quoted();
    test_negative();
    test_optional_plus();
    test_strip_outer();
    test_empty_category_rejected();
    test_wrong_header();
    test_wrong_field_count();
    test_unterminated_quote();
    test_invalid_amount();
    test_exponent_rejected();
    test_overflow_positive();
    test_max_int64();
    test_min_int64();
    test_accumulation_overflow();
    test_empty_input();
    test_empty_amount();
    test_sorted_keys();
    
    std::cout << "All tests passed!\n";
    return 0;
}
