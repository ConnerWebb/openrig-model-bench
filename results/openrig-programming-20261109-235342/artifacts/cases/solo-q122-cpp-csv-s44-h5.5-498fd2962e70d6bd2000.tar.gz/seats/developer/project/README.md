# CSV Aggregator

A header-only C++ library that parses CSV data with a `category,amount` header and aggregates amounts by category.

## Features

- Parses CSV with proper handling of quoted fields (commas, newlines, escaped double quotes)
- Strips outer spaces, tabs, and CR from fields
- Validates that category is non-empty
- Parses amount as signed int64 (optional +/-, no decimals/exponents)
- Aggregates amounts by category
- Returns sorted map (std::map)
- Rejects malformed input with std::invalid_argument

## Usage

```cpp
#include "solution.hpp"
#include <sstream>
#include <iostream>

int main() {
    std::string csv = "category,amount\nfood,100\nrent,200\nfood,50";
    std::istringstream in(csv);
    
    try {
        auto result = aggregate(in);
        for (const auto& [category, amount] : result) {
            std::cout << category << ": " << amount << "\n";
        }
    } catch (const std::invalid_argument& e) {
        std::cerr << "Error: " << e.what() << "\n";
    }
    
    return 0;
}
```

## Error Handling

The function throws `std::invalid_argument` for:
- Empty input
- Wrong header format
- Wrong number of fields per record
- Empty category
- Invalid amount format (non-integer, decimals, exponents)
- Integer overflow (input or accumulation)
- Unterminated quoted fields
