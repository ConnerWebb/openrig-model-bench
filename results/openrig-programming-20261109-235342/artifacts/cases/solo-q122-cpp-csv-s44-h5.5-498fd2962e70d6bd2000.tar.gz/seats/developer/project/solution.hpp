#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <cctype>
#include <limits>
#include <algorithm>
#include <optional>

namespace {

// Strip leading/trailing spaces, tabs, and CR from a string
std::string strip_outer(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse a single CSV field from the stream, handling quotes
// Returns the field content (unquoted, with escaped quotes unescaped)
// Sets eof if we hit end of stream
// Returns empty string if we hit end of line (comma or newline consumed)
std::string parse_field(std::istream& in, bool& eof, bool& end_of_line) {
    eof = false;
    end_of_line = false;
    std::string result;
    int c = in.get();
    
    if (c == EOF) {
        eof = true;
        return "";
    }
    
    if (c == '"') {
        // Quoted field
        while (true) {
            c = in.get();
            if (c == EOF) {
                // Unterminated quote
                throw std::invalid_argument("Unterminated quoted field");
            }
            if (c == '"') {
                // Check for escaped quote
                int next = in.get();
                if (next == '"') {
                    // Escaped quote, add one quote
                    result += '"';
                } else {
                    // End of quoted field
                    // Now we need to find the delimiter (comma) or end of line
                    if (next == EOF) {
                        eof = true;
                        end_of_line = true;
                        return result;
                    }
                    if (next == ',') {
                        return result;
                    }
                    if (next == '\n') {
                        end_of_line = true;
                        return result;
                    }
                    if (next == '\r') {
                        int after_cr = in.get();
                        if (after_cr == '\n') {
                            end_of_line = true;
                        }
                        // Treat \r alone or \r\n as end of line
                        end_of_line = true;
                        return result;
                    }
                    // Any other char after closing quote is malformed
                    throw std::invalid_argument("Invalid character after quoted field");
                }
            } else {
                result += static_cast<char>(c);
            }
        }
    } else {
        // Unquoted field
        while (c != ',' && c != '\n' && c != '\r' && c != EOF) {
            result += static_cast<char>(c);
            c = in.get();
        }
        if (c == ',') {
            return result;
        }
        if (c == '\n') {
            end_of_line = true;
            return result;
        }
        if (c == '\r') {
            int next = in.get();
            if (next == '\n') {
                end_of_line = true;
            }
            end_of_line = true;
            return result;
        }
        if (c == EOF) {
            eof = true;
        }
        return result;
    }
}

// Parse a line from the stream, returning fields
// Returns empty optional if EOF at start (no data)
std::optional<std::vector<std::string>> parse_line(std::istream& in) {
    std::vector<std::string> fields;
    bool eof = false;
    bool end_of_line = false;
    
    // Check if we're at EOF before starting
    int peek = in.peek();
    if (peek == EOF) {
        return std::nullopt;
    }
    
    while (true) {
        std::string field = parse_field(in, eof, end_of_line);
        fields.push_back(field);
        
        if (eof || end_of_line) {
            break;
        }
    }
    
    return fields;
}

// Parse int64 with optional leading +/-, no decimals/exponents
// Returns nullopt if invalid
std::optional<std::int64_t> parse_int64(const std::string& s) {
    if (s.empty()) return std::nullopt;
    
    size_t start = 0;
    bool negative = false;
    
    if (s[0] == '+') {
        start = 1;
    } else if (s[0] == '-') {
        negative = true;
        start = 1;
    }
    
    if (start >= s.size()) return std::nullopt;
    
    // Check all remaining chars are digits
    for (size_t i = start; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            return std::nullopt;
        }
    }
    
    // Convert digit by digit to detect overflow
    std::uint64_t result = 0;
    for (size_t i = start; i < s.size(); ++i) {
        int digit = s[i] - '0';
        if (result > (std::numeric_limits<std::uint64_t>::max() - digit) / 10) {
            return std::nullopt;
        }
        result = result * 10 + digit;
    }
    
    // Now check if result fits in int64 range
    if (negative) {
        // INT64_MIN is -9223372036854775808, which is 9223372036854775808 in abs
        // INT64_MAX is 9223372036854775807
        const std::uint64_t INT64_MAX_ABS = 9223372036854775807ULL;
        const std::uint64_t INT64_MIN_ABS = 9223372036854775808ULL;
        
        if (result > INT64_MIN_ABS) {
            return std::nullopt;
        }
        if (result == INT64_MIN_ABS) {
            return std::numeric_limits<std::int64_t>::min();
        }
        if (result > INT64_MAX_ABS) {
            return std::nullopt;
        }
        return -static_cast<std::int64_t>(result);
    } else {
        const std::uint64_t INT64_MAX_VAL = 9223372036854775807ULL;
        if (result > INT64_MAX_VAL) {
            return std::nullopt;
        }
        return static_cast<std::int64_t>(result);
    }
}

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read header line
    auto header = parse_line(in);
    if (!header.has_value()) {
        throw std::invalid_argument("Empty input");
    }
    
    // Validate header is exactly "category,amount"
    if (header->size() != 2) {
        throw std::invalid_argument("Header must have exactly 2 fields");
    }
    
    std::string h0 = strip_outer((*header)[0]);
    std::string h1 = strip_outer((*header)[1]);
    
    if (h0 != "category" || h1 != "amount") {
        throw std::invalid_argument("Header must be exactly 'category,amount'");
    }
    
    // Process data lines
    while (true) {
        auto line = parse_line(in);
        if (!line.has_value()) {
            break; // EOF
        }
        
        if (line->empty()) {
            continue; // Empty line
        }
        
        // Check field count
        if (line->size() != 2) {
            throw std::invalid_argument("Each record must have exactly 2 fields");
        }
        
        std::string category = strip_outer((*line)[0]);
        std::string amount_str = strip_outer((*line)[1]);
        
        // Category must be non-empty
        if (category.empty()) {
            throw std::invalid_argument("Category must be non-empty");
        }
        
        // Amount must be empty or valid int64
        if (amount_str.empty()) {
            throw std::invalid_argument("Amount field must not be empty");
        }
        
        auto amount = parse_int64(amount_str);
        if (!amount.has_value()) {
            throw std::invalid_argument("Invalid amount format");
        }
        
        // Check for overflow in accumulation
        auto it = result.find(category);
        if (it != result.end()) {
            std::int64_t current = it->second;
            std::int64_t add = *amount;
            
            // Check for overflow before adding
            if (add > 0) {
                if (current > std::numeric_limits<std::int64_t>::max() - add) {
                    throw std::invalid_argument("Accumulation overflow");
                }
            } else if (add < 0) {
                if (current < std::numeric_limits<std::int64_t>::min() - add) {
                    throw std::invalid_argument("Accumulation overflow");
                }
            }
            
            it->second = current + add;
        } else {
            result[category] = *amount;
        }
    }
    
    return result;
}

#endif // SOLUTION_HPP
