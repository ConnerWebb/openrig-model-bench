# Buffer

A small C++20 RAII byte buffer (`solution.hpp`).

## API

- `Buffer(std::size_t n = 0)` — constructs a buffer of `n` zero-initialized `uint8_t` bytes.
- `std::size_t size() const noexcept` — number of bytes.
- `uint8_t& operator[](std::size_t i)` / `const uint8_t& operator[](std::size_t i) const`
  — element access; throws `std::out_of_range` if `i >= size()`.
- `void resize(std::size_t k)` — resizes to `k` bytes, preserving the prefix and
  zero-initializing newly added bytes.
- Deep-copy construction and copy assignment (independent storage).
- `noexcept` move construction and move assignment; moved-from buffers have size 0
  and are safe to reuse.
- Self-copy and self-move preserve content.

## Implementation

Backed by `std::vector<std::uint8_t>`; all special members are defaulted, giving
RAII semantics with no leaks, double frees or stale reads.

## Tests

`test_buffer.cpp` is a standalone C++ test (plain `main`, `assert`-based) covering
construction, bounds checking, resize semantics, deep copy, self-copy, move
semantics, reuse after move, and the `noexcept` move traits.

Build & run:

```
clang++ -std=c++20 -fsanitize=address,undefined -g test_buffer.cpp -o /tmp/test_buffer
/tmp/test_buffer
```
