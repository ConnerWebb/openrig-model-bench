#include "solution.hpp"
#include <cassert>
#include <cstdint>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

static void test_default_and_sized() {
    Buffer a;
    assert(a.size() == 0);
    Buffer b(5);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) assert(b[i] == 0);
}

static void test_bounds() {
    Buffer b(3);
    bool caught = false;
    try { (void)b[3]; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
    const Buffer& cb = b;
    caught = false;
    try { (void)cb[10]; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
}

static void test_resize() {
    Buffer b(4);
    for (int i = 0; i < 4; ++i) b[i] = static_cast<std::uint8_t>(10 + i);
    b.resize(6);
    assert(b.size() == 6);
    for (int i = 0; i < 4; ++i) assert(b[i] == 10 + i);
    assert(b[4] == 0 && b[5] == 0);
    b.resize(2);
    assert(b.size() == 2 && b[0] == 10 && b[1] == 11);
    b.resize(0);
    assert(b.size() == 0);
    b.resize(3);
    assert(b.size() == 3 && b[2] == 0);
}

static void test_copy() {
    Buffer a(4);
    for (int i = 0; i < 4; ++i) a[i] = static_cast<std::uint8_t>(i * 10);
    Buffer b = a;
    b[0] = 255;
    assert(a[0] == 0);
    assert(b.size() == 4);
    Buffer c;
    c = a;
    assert(c.size() == 4 && c[3] == 30);
}

static void test_self_copy() {
    Buffer a(4);
    for (int i = 0; i < 4; ++i) a[i] = static_cast<std::uint8_t>(i + 1);
    a = a;
    assert(a.size() == 4 && a[0] == 1 && a[3] == 4);
}

static void test_move() {
    Buffer a(4);
    for (int i = 0; i < 4; ++i) a[i] = static_cast<std::uint8_t>(i + 100);
    Buffer b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 4 && b[0] == 100 && b[3] == 103);
    b = std::move(b);
    assert(b.size() == 4 && b[1] == 101);
    Buffer c(2);
    c[0] = 7;
    c = std::move(b);
    assert(c.size() == 4 && c[2] == 102);
    assert(b.size() == 0);
}

static void test_reuse_after_move() {
    Buffer a(3);
    a[0] = 1;
    Buffer b = std::move(a);
    a.resize(2);
    assert(a.size() == 2 && a[0] == 0 && a[1] == 0);
    a[1] = 9;
    assert(b.size() == 3 && b[0] == 1);
}

static void test_nothrow_traits() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

int main() {
    test_default_and_sized();
    test_bounds();
    test_resize();
    test_copy();
    test_self_copy();
    test_move();
    test_reuse_after_move();
    test_nothrow_traits();
    return 0;
}
