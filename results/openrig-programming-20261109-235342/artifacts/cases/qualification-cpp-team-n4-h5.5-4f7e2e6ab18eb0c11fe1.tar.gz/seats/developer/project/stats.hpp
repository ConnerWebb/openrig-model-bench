#pragma once
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <cmath>

class RunningStats {
public:
 void add(double value) {
  if (std::isnan(value) || std::isinf(value)) {
   throw std::invalid_argument("invalid value");
  }
  if (count_ == 0) {
   min_ = max_ = value;
  } else {
   if (value < min_) min_ = value;
   if (value > max_) max_ = value;
  }
  ++count_;
  double delta = value - mean_;
  mean_ += delta / count_;
  double delta2 = value - mean_;
  m2_ += delta * delta2;
 }
 
 void merge(const RunningStats& other) {
  if (other.count_ == 0) return;
  if (count_ == 0) {
   *this = other;
   return;
  }
  double new_count = count_ + other.count_;
  double delta = other.mean_ - mean_;
  mean_ = (mean_ * count_ + other.mean_ * other.count_) / new_count;
  m2_ += other.m2_ + delta * delta * count_ * other.count_ / new_count;
  if (other.min_ < min_) min_ = other.min_;
  if (other.max_ > max_) max_ = other.max_;
  count_ = new_count;
 }
 
 uint64_t count() const { return count_; }
 
 double mean() const {
  if (count_ == 0) throw std::domain_error("no data");
  return mean_;
 }
 
 double variance() const {
  if (count_ == 0) throw std::domain_error("no data");
  return m2_ / count_;
 }
 
 double minimum() const {
  if (count_ == 0) throw std::domain_error("no data");
  return min_;
 }
 
 double maximum() const {
  if (count_ == 0) throw std::domain_error("no data");
  return max_;
 }
 
private:
 uint64_t count_ = 0;
 double mean_ = 0.0;
 double m2_ = 0.0;
 double min_ = std::numeric_limits<double>::infinity();
 double max_ = -std::numeric_limits<double>::infinity();
};
