#include "cache.hpp"
#include <cassert>
#include <iostream>

void test_basic() {
 LruCache cache(3);
 cache.put(1, "one");
 cache.put(2, "two");
 cache.put(3, "three");
 auto snap = cache.snapshot();
 assert(snap.size() == 3);
 assert(snap[0].first == 3 && snap[0].second == "three");
 assert(snap[1].first == 2 && snap[1].second == "two");
 assert(snap[2].first == 1 && snap[2].second == "one");
}

void test_eviction() {
 LruCache cache(2);
 cache.put(1, "one");
 cache.put(2, "two");
 cache.put(3, "three");
 auto snap = cache.snapshot();
 assert(snap.size() == 2);
 assert(snap[0].first == 3 && snap[0].second == "three");
 assert(snap[1].first == 2 && snap[1].second == "two");
}

void test_get_mru() {
 LruCache cache(3);
 cache.put(1, "one");
 cache.put(2, "two");
 std::string out;
 assert(cache.get(1, out) == true && out == "one");
 cache.put(3, "three");
 auto snap = cache.snapshot();
 assert(snap[0].first == 3);
 assert(snap[1].first == 1);
 assert(snap[2].first == 2);
}

void test_update() {
 LruCache cache(2);
 cache.put(1, "one");
 cache.put(1, "ONE");
 assert(cache.size() == 1);
 auto snap = cache.snapshot();
 assert(snap[0].first == 1 && snap[0].second == "ONE");
}

void test_erase() {
 LruCache cache(3);
 cache.put(1, "one");
 cache.put(2, "two");
 assert(cache.erase(1) == true);
 assert(cache.erase(1) == false);
 assert(cache.size() == 1);
}

void test_capacity_zero() {
 LruCache cache(0);
 cache.put(1, "one");
 assert(cache.size() == 0);
}

void test_miss() {
 LruCache cache(2);
 std::string out = "UNCHANGED";
 assert(cache.get(999, out) == false);
 assert(out == "UNCHANGED");
}

int main() {
 test_basic();
 test_eviction();
 test_get_mru();
 test_update();
 test_erase();
 test_capacity_zero();
 test_miss();
 std::cout << "All cache tests passed" << std::endl;
 return 0;
}
