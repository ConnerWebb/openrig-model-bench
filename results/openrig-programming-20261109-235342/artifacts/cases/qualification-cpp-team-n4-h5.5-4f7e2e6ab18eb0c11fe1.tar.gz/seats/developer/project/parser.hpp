#pragma once
#include <map>
#include <string>
#include <cstdint>
#include <istream>
#include <stdexcept>
#include <limits>
#include <vector>
#include <cerrno>
#include <cstdlib>

inline std::map<std::string,std::int64_t> aggregate(std::istream& in){
 std::map<std::string,std::int64_t> out;std::vector<std::string> row;std::string f;bool quote=false,closed=false,at_start=true,header=false;int ch;
 auto trim=[](std::string s){auto a=s.find_first_not_of(" \t\r"),b=s.find_last_not_of(" \t\r");return a==std::string::npos?std::string():s.substr(a,b-a+1);};
 auto parse_int=[](const std::string& s)->std::int64_t{
  if(s.empty())throw std::invalid_argument("empty");
  char* endptr=nullptr;
  errno=0;
  auto val=strtoll(s.c_str(),&endptr,10);
  if(errno==ERANGE)throw std::invalid_argument("overflow");
  if(endptr!=s.c_str()+s.size())throw std::invalid_argument("number");
  return val;
 };
 auto record=[&]{if(row.empty()&&f.empty()&&!closed)return;row.push_back(f);f.clear();closed=false;at_start=true;if(!header){if(row!=std::vector<std::string>{"category","amount"})throw std::invalid_argument("header");header=true;}else{if(row.size()!=2)throw std::invalid_argument("columns");auto k=trim(row[0]),v=trim(row[1]);if(k.empty()||v.empty())throw std::invalid_argument("empty");std::size_t p=0;if(v[0]=='+'||v[0]=='-')p++;if(p==v.size())throw std::invalid_argument("number");for(auto i=p;i<v.size();i++)if(v[i]<'0'||v[i]>'9')throw std::invalid_argument("digit");auto n=parse_int(v);auto old=out[k];if((n>0&&old>std::numeric_limits<std::int64_t>::max()-n)||(n<0&&old<std::numeric_limits<std::int64_t>::min()-n))throw std::invalid_argument("overflow");out[k]=old+n;}row.clear();};
 while((ch=in.get())!=EOF){char c=ch;if(quote){if(c=='"'){if(in.peek()=='"'){in.get();f+='"';}else{quote=false;closed=true;}}else f+=c;continue;}if(c=='"'){if(!at_start||closed)throw std::invalid_argument("quote");quote=true;at_start=false;}else if(c==','){row.push_back(f);f.clear();at_start=true;closed=false;}else if(c=='\n'){record();}else{if(closed&&c!='\r')throw std::invalid_argument("after quote");if(!closed){f+=c;at_start=false;}}}
 if(quote)throw std::invalid_argument("quote");record();if(!header)throw std::invalid_argument("header");return out;
}
