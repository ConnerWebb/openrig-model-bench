#include "stats.hpp"
#include <cassert>
#include <iostream>
#include <cmath>

void test_empty() {
 RunningStats rs;
 assert(rs.count() == 0);
 try { rs.mean(); assert(false); } catch (const std::domain_error&) {}
 try { rs.variance(); assert(false); } catch (const std::domain_error&) {}
 try { rs.minimum(); assert(false); } catch (const std::domain_error&) {}
 try { rs.maximum(); assert(false); } catch (const std::domain_error&) {}
}

void test_single() {
 RunningStats rs;
 rs.add(5.0);
 assert(rs.count() == 1);
 assert(rs.mean() == 5.0);
 assert(rs.variance() == 0.0);
 assert(rs.minimum() == 5.0);
 assert(rs.maximum() == 5.0);
}

void test_multiple() {
 RunningStats rs;
 rs.add(1.0);
 rs.add(2.0);
 rs.add(3.0);
 assert(rs.count() == 3);
 assert(std::abs(rs.mean() - 2.0) < 1e-9);
 assert(std::abs(rs.variance() - 2.0/3.0) < 1e-9);
 assert(rs.minimum() == 1.0);
 assert(rs.maximum() == 3.0);
}

void test_nan_reject() {
 RunningStats rs;
 rs.add(1.0);
 try { rs.add(std::nan("")); assert(false); } catch (const std::invalid_argument&) {}
 assert(rs.count() == 1);
}

void test_inf_reject() {
 RunningStats rs;
 try { rs.add(std::numeric_limits<double>::infinity()); assert(false); } catch (const std::invalid_argument&) {}
 try { rs.add(-std::numeric_limits<double>::infinity()); assert(false); } catch (const std::invalid_argument&) {}
 assert(rs.count() == 0);
}

void test_merge() {
 RunningStats a, b;
 a.add(1.0);
 a.add(2.0);
 b.add(3.0);
 b.add(4.0);
 a.merge(b);
 assert(a.count() == 4);
 assert(std::abs(a.mean() - 2.5) < 1e-9);
 assert(std::abs(a.variance() - 1.25) < 1e-9);
 assert(a.minimum() == 1.0);
 assert(a.maximum() == 4.0);
}

void test_merge_empty() {
 RunningStats a;
 a.add(1.0);
 a.merge(RunningStats());
 assert(a.count() == 1);
 RunningStats b;
 b.merge(a);
 assert(b.count() == 1);
}

void test_self_merge() {
 RunningStats rs;
 rs.add(10.0);
 rs.merge(rs);
 assert(rs.count() == 2);
 assert(rs.mean() == 10.0);
 assert(rs.variance() == 0.0);
}

int main() {
 test_empty();
 test_single();
 test_multiple();
 test_nan_reject();
 test_inf_reject();
 test_merge();
 test_merge_empty();
 test_self_merge();
 std::cout << "All stats tests passed" << std::endl;
 return 0;
}
