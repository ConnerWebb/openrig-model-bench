#include "parser.hpp"
#include <sstream>
#include <cassert>
#include <iostream>

void test_basic() {
 std::string text = "category,amount\nfood,100\nrent,500\n";
 std::istringstream in(text);
 auto out = aggregate(in);
 assert(out.size() == 2);
 assert(out["food"] == 100);
 assert(out["rent"] == 500);
}

void test_negative() {
 std::string text = "category,amount\nfood,-50\nrent,100\n";
 std::istringstream in(text);
 auto out = aggregate(in);
 assert(out["food"] == -50);
 assert(out["rent"] == 100);
}

void test_quoted() {
 std::string text = "category,amount\n\"a,b\",100\n";
 std::istringstream in(text);
 auto out = aggregate(in);
 assert(out.size() == 1);
 assert(out["a,b"] == 100);
}

void test_escaped_quotes() {
 std::string text = "category,amount\n\"a\"\"b\",100\n";
 std::istringstream in(text);
 auto out = aggregate(in);
 assert(out["a\"b"] == 100);
}

void test_multiline() {
 std::string text = "category,amount\n\"two\nlines\",100\n";
 std::istringstream in(text);
 auto out = aggregate(in);
 assert(out["two\nlines"] == 100);
}

void test_accumulation() {
 std::string text = "category,amount\nfood,100\nfood,200\nfood,300\n";
 std::istringstream in(text);
 auto out = aggregate(in);
 assert(out["food"] == 600);
}

void test_wrong_header() {
 std::string text = "wrong,amount\nx,1\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_wrong_columns() {
 std::string text = "category,amount\nx,1,2\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_empty_category() {
 std::string text = "category,amount\n,1\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_nan() {
 std::string text = "category,amount\nx,NaN\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_exponent() {
 std::string text = "category,amount\nx,1e2\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_overflow_positive() {
 std::string text = "category,amount\nx,9223372036854775808\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_overflow_accumulation() {
 std::string text = "category,amount\nx,9223372036854775807\nx,1\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_overflow_negative() {
 std::string text = "category,amount\nx,-9223372036854775808\nx,-1\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

void test_unclosed_quote() {
 std::string text = "category,amount\n\"x,1\n";
 std::istringstream in(text);
 try { aggregate(in); assert(false); } catch (const std::invalid_argument&) {}
}

int main() {
 test_basic();
 test_negative();
 test_quoted();
 test_escaped_quotes();
 test_multiline();
 test_accumulation();
 test_wrong_header();
 test_wrong_columns();
 test_empty_category();
 test_nan();
 test_exponent();
 test_overflow_positive();
 test_overflow_accumulation();
 test_overflow_negative();
 test_unclosed_quote();
 std::cout << "All parser tests passed" << std::endl;
 return 0;
}
