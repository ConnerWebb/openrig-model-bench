#include "parser.hpp"
#include <sstream>
#include <cassert>
#include <iostream>

void test_basic() {
  std::string text = "category,amount\na,100\nb,200\n";
  std::istringstream in(text);
  auto res = aggregate(in);
  assert(res.at("a") == 100);
  assert(res.at("b") == 200);
  std::cout << "test_basic passed\n";
}

void test_negative() {
  std::string text = "category,amount\na,-50\nb,+75\n";
  std::istringstream in(text);
  auto res = aggregate(in);
  assert(res.at("a") == -50);
  assert(res.at("b") == 75);
  std::cout << "test_negative passed\n";
}

void test_quoted() {
  std::string text = "category,amount\n\"a,b\",100\n";
  std::istringstream in(text);
  auto res = aggregate(in);
  assert(res.at("a,b") == 100);
  std::cout << "test_quoted passed\n";
}

void test_escaped_quotes() {
  std::string text = "category,amount\n\"a\"\"b\",100\n";
  std::istringstream in(text);
  auto res = aggregate(in);
  assert(res.at("a\"b") == 100);
  std::cout << "test_escaped_quotes passed\n";
}

void test_multiline() {
  std::string text = "category,amount\n\"two\nlines\",100\n";
  std::istringstream in(text);
  auto res = aggregate(in);
  assert(res.at("two\nlines") == 100);
  std::cout << "test_multiline passed\n";
}

void test_accumulation() {
  std::string text = "category,amount\na,100\na,200\n";
  std::istringstream in(text);
  auto res = aggregate(in);
  assert(res.at("a") == 300);
  std::cout << "test_accumulation passed\n";
}

void test_wrong_header() {
  std::string text = "wrong,amount\na,100\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_wrong_header passed\n";
  }
}

void test_wrong_columns() {
  std::string text = "category,amount\na,1,2\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_wrong_columns passed\n";
  }
}

void test_empty_category() {
  std::string text = "category,amount\n,100\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_empty_category passed\n";
  }
}

void test_nan() {
  std::string text = "category,amount\na,NaN\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_nan passed\n";
  }
}

void test_exponent() {
  std::string text = "category,amount\na,1e2\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_exponent passed\n";
  }
}

void test_overflow_positive() {
  std::string text = "category,amount\nx,9223372036854775808\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_overflow_positive passed\n";
  }
}

void test_overflow_accumulation() {
  std::string text = "category,amount\nx,9223372036854775807\nx,1\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_overflow_accumulation passed\n";
  }
}

void test_overflow_negative() {
  std::string text = "category,amount\nx,-9223372036854775808\nx,-1\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_overflow_negative passed\n";
  }
}

void test_unclosed_quote() {
  std::string text = "category,amount\n\"x,1\n";
  std::istringstream in(text);
  try {
    aggregate(in);
    assert(false && "should throw");
  } catch (const std::invalid_argument&) {
    std::cout << "test_unclosed_quote passed\n";
  }
}

int main() {
  test_basic();
  test_negative();
  test_quoted();
  test_escaped_quotes();
  test_multiline();
  test_accumulation();
  test_wrong_header();
  test_wrong_columns();
  test_empty_category();
  test_nan();
  test_exponent();
  test_overflow_positive();
  test_overflow_accumulation();
  test_overflow_negative();
  test_unclosed_quote();
  std::cout << "All parser tests passed\n";
  return 0;
}
