# CSV Aggregation Solution

This module provides a function to aggregate CSV data by category.

## API

### `aggregate(path: str) -> dict[str, str]`

Reads a UTF-8 CSV file with header `category,amount` and returns a dictionary mapping each category to its total amount (formatted with exactly two decimal places).

### Requirements

- Header must be exactly `category,amount`
- Each non-blank record must have exactly two fields
- Category must not be empty after stripping whitespace
- Amount must be nonnegative, finite, with optional `+` prefix, 1-12 digits, and optional decimal point with 1-2 decimal places
- Uses exact decimal arithmetic for accumulation
- Returns categories sorted alphabetically

### Errors

Raises `ValueError` for:
- Empty file
- Invalid header (wrong names or field count)
- Non-blank records with wrong field count
- Empty category
- Invalid amount format (NaN, exponent, too many digits, too many decimal places, negative)
- Unclosed quotes

### Example

```python
from solution import aggregate

result = aggregate("data.csv")
# Returns: {'food': '150.00', 'rent': '200.00'}
```
