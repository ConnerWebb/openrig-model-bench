import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        csv_content = "category,amount\nfood,100.00\nfood,50.00\nrent,200.00\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '150.00', 'rent': '200.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        csv_content = "category,amount\n  food  ,  100.50  \n  rent  ,  200.25  \n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '100.50', 'rent': '200.25'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored"""
        csv_content = "category,amount\nfood,100.00\n\nrent,200.00\n   \nfood,50.00\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '150.00', 'rent': '200.00'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas"""
        csv_content = 'category,amount\n"a,b",100.00\n"c,d",200.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'a,b': '100.00', 'c,d': '200.00'})
    
    def test_embedded_newlines(self):
        """Test fields with embedded newlines"""
        csv_content = 'category,amount\n"line1\nline2",100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'line1\nline2': '100.00'})
    
    def test_escaped_quotes(self):
        """Test escaped quotes in fields"""
        csv_content = 'category,amount\n"x""quote",100.00\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        csv_content = "category,amount\nfood,+100.50\nrent,+200\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '100.50', 'rent': '200.00'})
    
    def test_integer_amounts(self):
        """Test integer amounts (no decimal point)"""
        csv_content = "category,amount\nfood,100\nrent,200\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        # Build CSV with explicit ASCII commas
        lines = ["category,amount"]
        lines.append("日本" + "," + "100.00")
        lines.append("한국" + "," + "200.00")
        csv_content = "\n".join(lines) + "\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {'日本': '100.00', '한국': '200.00'})
    
    def test_sorted_output(self):
        """Test that output is sorted by category"""
        csv_content = "category,amount\nzebra,100.00\napple,200.00\nmango,150.00\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_invalid_header_wrong_names(self):
        """Test that wrong header names raise ValueError"""
        csv_content = "wrong,amount\nx,1\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_wrong_field_count(self):
        """Test that header with wrong field count raises ValueError"""
        csv_content = "category,amount,extra\nx,1,2\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category(self):
        """Test that empty category raises ValueError"""
        csv_content = "category,amount\n,100.00\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test that NaN amount raises ValueError"""
        csv_content = "category,amount\nx,NaN\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_too_many_fields(self):
        """Test that record with too many fields raises ValueError"""
        csv_content = "category,amount\nx,1,2\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote(self):
        """Test that unclosed quote raises ValueError"""
        csv_content = 'category,amount\n"x,1\n'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_negative_amount(self):
        """Test that negative amount raises ValueError"""
        csv_content = "category,amount\nx,-100.00\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_with_exponent(self):
        """Test that exponent notation raises ValueError"""
        csv_content = "category,amount\nx,1e2\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_too_many_digits(self):
        """Test that amount with more than 12 digits raises ValueError"""
        csv_content = "category,amount\nx,1234567890123\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_amount_too_many_decimal_places(self):
        """Test that amount with more than 2 decimal places raises ValueError"""
        csv_content = "category,amount\nx,100.123\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file(self):
        """Test that empty file raises ValueError"""
        csv_content = ""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only(self):
        """Test file with only header"""
        csv_content = "category,amount\n"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
