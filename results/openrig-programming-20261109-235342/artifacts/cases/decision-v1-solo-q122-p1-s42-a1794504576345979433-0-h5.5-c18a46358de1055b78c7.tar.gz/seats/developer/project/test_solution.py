"""
Tests for solution.py aggregate function.
Uses unittest.TestCase/test_* methods as required.
"""
import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation."""
        csv_content = "category,amount\nfood,10.00\nfood,20.00\nrent,50.00"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'food': '30.00',
            'rent': '50.00'
        })
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = "category,amount\n  food  ,  10.50  \n  rent  ,  20.25  "
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'food': '10.50',
            'rent': '20.25'
        })
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas."""
        csv_content = 'category,amount\n"a,b",100.00\n"a,b",50.00'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'a,b': '150.00'
        })
    
    def test_quoted_fields_with_newlines(self):
        """Test quoted fields containing newlines."""
        csv_content = 'category,amount\n"two\nlines",100.00\n"two\nlines",50.00'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'two\nlines': '150.00'
        })
    
    def test_escaped_quotes(self):
        """Test escaped quotes in quoted fields."""
        csv_content = 'category,amount\n"x""quote",100.00\n"x""quote",50.00'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'x"quote': '150.00'
        })
    
    def test_unicode_categories(self):
        """Test unicode category names."""
        # Build CSV with explicit ASCII comma to avoid full-width comma issues
        lines = ['category,amount']
        lines.append('日本' + ',' + '100.00')
        lines.append('日本' + ',' + '50.00')
        lines.append('한국' + ',' + '25.00')
        csv_content = '\n'.join(lines)
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            '日本': '150.00',
            '한국': '25.00'
        })
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign."""
        csv_content = "category,amount\nfood,+10.50\nfood,+20.25"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'food': '30.75'
        })
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        csv_content = "category,amount\nfood,10.00\n\n\nrent,20.00\n   \nfood,5.00"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'food': '15.00',
            'rent': '20.00'
        })
    
    def test_sorted_output(self):
        """Test that output is sorted by category."""
        csv_content = "category,amount\nzebra,10.00\napple,20.00\nmango,30.00"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
    
    def test_two_decimal_formatting(self):
        """Test that amounts are formatted to exactly 2 decimal places."""
        csv_content = "category,amount\nfood,10\nfood,20.5\nfood,30.55"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        # 10 + 20.5 + 30.55 = 61.05
        self.assertEqual(result, {
            'food': '61.05'
        })
    
    def test_invalid_amount_too_many_decimals(self):
        """Test that amounts with more than 2 decimal places are rejected."""
        csv_content = "category,amount\nfood,10.001"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_exponent(self):
        """Test that amounts with exponent notation are rejected."""
        csv_content = "category,amount\nfood,1e2"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_negative(self):
        """Test that negative amounts are rejected."""
        csv_content = "category,amount\nfood,-10.00"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_nan(self):
        """Test that NaN amounts are rejected."""
        csv_content = "category,amount\nfood,NaN"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_wrong_name(self):
        """Test that wrong header names are rejected."""
        csv_content = "wrong,amount\nx,1"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_wrong_field_count(self):
        """Test that records with wrong field count are rejected."""
        csv_content = "category,amount\nx,1,2"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_empty_category(self):
        """Test that empty category is rejected."""
        csv_content = "category,amount\n,10.00"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_unclosed_quote(self):
        """Test that unclosed quotes are rejected."""
        csv_content = 'category,amount\n"x,10.00'
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_max_digits_amount(self):
        """Test amount with maximum 12 digits before decimal."""
        csv_content = "category,amount\nfood,999999999999"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {
            'food': '999999999999.00'
        })
    
    def test_too_many_digits_amount(self):
        """Test that amount with more than 12 digits is rejected."""
        csv_content = "category,amount\nfood,1000000000000"  # 13 digits
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_file(self):
        """Test that empty file raises ValueError."""
        csv_content = ""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_header_only(self):
        """Test file with only header returns empty dict."""
        csv_content = "category,amount"
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text(csv_content, encoding='utf-8')
            result = aggregate(str(p))
        
        self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
