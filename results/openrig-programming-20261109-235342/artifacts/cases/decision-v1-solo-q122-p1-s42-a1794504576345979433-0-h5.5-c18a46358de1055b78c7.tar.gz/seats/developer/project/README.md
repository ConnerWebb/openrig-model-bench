# CSV Aggregator

A Python module that reads UTF-8 CSV files with `category,amount` headers and aggregates amounts by category using exact decimal arithmetic.

## Features

- Proper CSV parsing with support for quoted fields containing commas, newlines, and escaped quotes
- Whitespace stripping from category and amount fields
- Exact decimal arithmetic using Python's `Decimal` type
- Strict amount validation:
  - Optional leading `+` sign
  - 1-12 digits before decimal point
  - Optional decimal point with 1-2 digits after
  - Nonnegative values only
  - No exponent notation
- Sorted output by category name
- Results formatted to exactly 2 decimal places

## Usage

```python
from solution import aggregate

result = aggregate('input.csv')
# Returns dict like {'food': '30.00', 'rent': '50.00'}
```

## Error Handling

Raises `ValueError` for:
- Empty files
- Invalid header (must be exactly `category,amount`)
- Records with wrong field count (non-blank records must have exactly 2 fields)
- Empty category names
- Invalid amount formats (too many digits, too many decimals, exponent notation, negative values)
- Malformed CSV (unclosed quotes, etc.)

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```
