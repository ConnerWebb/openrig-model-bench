"""
CSV aggregator: reads UTF-8 CSV with category,amount header.
Accumulates amounts by category using exact decimal arithmetic.
Returns sorted dict with totals formatted to 2 decimal places.
"""
import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount: optional +, 1-12 decimal digits, optional decimal point followed by 1-2 digits.
    Nonnegative, finite, no exponent. Reject malformed input with ValueError.
    Accumulate using exact decimal arithmetic.
    Return category keys sorted, totals formatted with exactly two decimal places.
    """
    # Read file content
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Parse CSV using Python's csv module which handles quoted fields, embedded commas, newlines
    reader = csv.reader(StringIO(content))
    
    # Read and validate header
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("Empty CSV file")
    
    if len(header) != 2:
        raise ValueError("Header must have exactly 2 fields")
    
    if header[0].strip() != 'category' or header[1].strip() != 'amount':
        raise ValueError("Header must be exactly 'category,amount'")
    
    # Accumulate amounts by category using Decimal for exact arithmetic
    totals: dict[str, Decimal] = {}
    
    for row in reader:
        # Skip completely blank records (all fields empty or whitespace)
        if all(field.strip() == '' for field in row):
            continue
        
        # Every non-blank record must have exactly 2 fields
        if len(row) != 2:
            raise ValueError("Every non-blank record must have exactly 2 fields")
        
        category = row[0].strip()
        amount_str = row[1].strip()
        
        # Category must not be empty
        if not category:
            raise ValueError("Category must not be empty")
        
        # Validate amount format
        # Pattern: optional +, 1-12 digits, optional decimal point with 1-2 digits after
        # Must be nonnegative, finite, no exponent
        amount_pattern = r'^\+?\d{1,12}(\.\d{1,2})?$'
        if not re.match(amount_pattern, amount_str):
            raise ValueError(f"Invalid amount format: {amount_str}")
        
        # Parse as Decimal for exact arithmetic
        try:
            amount = Decimal(amount_str)
        except InvalidOperation:
            raise ValueError(f"Invalid amount: {amount_str}")
        
        # Check for nonnegative (should be guaranteed by regex, but double-check)
        if amount < 0:
            raise ValueError(f"Amount must be nonnegative: {amount_str}")
        
        # Accumulate
        if category in totals:
            totals[category] += amount
        else:
            totals[category] = amount
    
    # Format results with exactly 2 decimal places, sorted by category
    result = {}
    for category in sorted(totals.keys()):
        total = totals[category]
        # Format to exactly 2 decimal places
        formatted = f"{total:.2f}"
        result[category] = formatted
    
    return result
