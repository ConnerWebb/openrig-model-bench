# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep Copy**: Copy constructor and copy assignment perform deep copies of the buffer contents.
- **Noexcept Move**: Move constructor and move assignment are noexcept and leave the moved-from buffer in a valid, reusable state (size 0).
- **Bounds Checking**: Both mutable and const `operator[]` throw `std::out_of_range` on invalid indices.
- **Resize**: Preserves existing data prefix and zero-initializes new elements when growing.
- **RAII**: Proper resource management with no memory leaks or double frees.

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized.

### Destructor
```cpp
~Buffer();
```
Releases allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy of the buffer contents.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Transfer ownership. The moved-from buffer has size 0 and can be reused.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
`size()` returns the buffer size. `operator[]` throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes the buffer to `k` bytes. Existing data is preserved up to the new size; new bytes are zero-initialized.

## Example

```cpp
Buffer a(5);
a[0] = 1;
a[1] = 2;

Buffer b(a);  // Deep copy
b[0] = 99;    // Does not affect a

Buffer c = std::move(a);  // Move, a.size() == 0
a.resize(3);  // a is reusable
```

## Building and Testing

Compile with C++20 and Clang:
```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

Run the public test suite:
```bash
run_tests
```
