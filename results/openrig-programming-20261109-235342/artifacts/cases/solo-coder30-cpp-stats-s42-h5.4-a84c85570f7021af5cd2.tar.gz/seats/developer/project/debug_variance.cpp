#include <iostream>
#include <iomanip>
#include "include/stats.hpp"

int main() {
    RunningStats rs;
    
    // Test case 0 from the public cases
    double values[] = {1000000030.0, 1000000058.0, 999999902.0, 999999967.0, 999999939.0, 1000000093.0, 999999951.0, 999999967.0, 999999922.0, 999999951.0, 1000000031.0, 999999914.0, 1000000052.0, 999999949.0, 1000000029.0, 999999906.0, 1000000077.0, 1000000034.0, 999999993.0, 1000000017.0, 1000000094.0, 999999933.0, 999999989.0, 1000000065.0, 999999942.0, 999999909.0, 999999989.0, 1000000055.0, 999999907.0, 999999999.0, 1000000065.0, 1000000049.0, 999999948.0, 999999938.0, 999999982.0, 1000000011.0, 1000000014.0, 999999924.0, 1000000069.0, 999999905.0, 999999963.0, 1000000054.0};
    
    for (int i = 0; i < 42; i++) {
        rs.add(values[i]);
    }
    
    std::cout << std::fixed << std::setprecision(17);
    std::cout << "Count: " << rs.count() << std::endl;
    std::cout << "Mean: " << rs.mean() << std::endl;
    std::cout << "Variance: " << rs.variance() << std::endl;
    std::cout << "Min: " << rs.minimum() << std::endl;
    std::cout << "Max: " << rs.maximum() << std::endl;
    
    return 0;
}