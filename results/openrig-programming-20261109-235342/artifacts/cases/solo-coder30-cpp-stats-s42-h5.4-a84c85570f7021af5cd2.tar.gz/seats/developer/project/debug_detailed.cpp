#include <iostream>
#include <iomanip>
#include <vector>
#include "include/stats.hpp"

int main() {
    // Replicate exactly what the driver does for case 0
    int n = 42, split = 9, self = 0;
    
    // Values from case-00.json
    std::vector<double> values = {
        1000000030.0, 1000000058.0, 999999902.0, 999999967.0, 999999939.0, 
        1000000093.0, 999999951.0, 999999967.0, 999999922.0, 999999951.0, 
        1000000031.0, 999999914.0, 1000000052.0, 999999949.0, 1000000029.0, 
        999999906.0, 1000000077.0, 1000000034.0, 999999993.0, 1000000017.0, 
        1000000094.0, 999999933.0, 999999989.0, 1000000065.0, 999999942.0, 
        999999909.0, 999999989.0, 1000000055.0, 999999907.0, 999999999.0, 
        1000000065.0, 1000000049.0, 999999948.0, 999999938.0, 999999982.0, 
        1000000011.0, 1000000014.0, 999999924.0, 1000000069.0, 999999905.0, 
        999999963.0, 1000000054.0
    };
    
    RunningStats a, b;
    
    // Add first 'split' values to a
    for (int i = 0; i < split; i++) {
        a.add(values[i]);
    }
    
    // Add remaining values to b
    for (int i = split; i < n; i++) {
        b.add(values[i]);
    }
    
    std::cout << std::fixed << std::setprecision(17);
    std::cout << "Stats a:" << std::endl;
    std::cout << "  Count: " << a.count() << std::endl;
    std::cout << "  Mean: " << a.mean() << std::endl;
    std::cout << "  Variance: " << a.variance() << std::endl;
    std::cout << "  Min: " << a.minimum() << std::endl;
    std::cout << "  Max: " << a.maximum() << std::endl;
    
    std::cout << "Stats b:" << std::endl;
    std::cout << "  Count: " << b.count() << std::endl;
    std::cout << "  Mean: " << b.mean() << std::endl;
    std::cout << "  Variance: " << b.variance() << std::endl;
    std::cout << "  Min: " << b.minimum() << std::endl;
    std::cout << "  Max: " << b.maximum() << std::endl;
    
    // Merge b into a
    a.merge(b);
    
    std::cout << "After merge:" << std::endl;
    std::cout << "  Count: " << a.count() << std::endl;
    std::cout << "  Mean: " << a.mean() << std::endl;
    std::cout << "  Variance: " << a.variance() << std::endl;
    std::cout << "  Min: " << a.minimum() << std::endl;
    std::cout << "  Max: " << a.maximum() << std::endl;
    
    return 0;
}