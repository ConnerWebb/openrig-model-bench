#ifndef STATS_HPP
#define STATS_HPP

#include <cstdint>
#include <stdexcept>

class RunningStats {
public:
    RunningStats();
    
    void add(double value);
    void merge(const RunningStats& other);
    
    uint64_t count() const;
    double mean() const;
    double variance() const;
    double minimum() const;
    double maximum() const;

private:
    uint64_t n_;
    double sum_;
    double sum_squares_;
    double min_;
    double max_;
    bool initialized_;
    
    void validateValue(double value) const;
};

#endif // STATS_HPP