#include "stats.hpp"
#include <limits>
#include <stdexcept>
#include <cmath>

RunningStats::RunningStats() : n_(0), sum_(0.0), sum_squares_(0.0), min_(0.0), max_(0.0) {}

void RunningStats::add(double value) {
    if (std::isnan(value) || std::isinf(value)) {
        throw std::invalid_argument("Invalid value: NaN or infinity");
    }
    
    if (n_ == 0) {
        min_ = max_ = value;
    } else {
        if (value < min_) min_ = value;
        if (value > max_) max_ = value;
    }
    
    n_++;
    sum_ += value;
    sum_squares_ += value * value;
}

void RunningStats::merge(const RunningStats& other) {
    if (other.n_ == 0) {
        return;
    }
    
    if (n_ == 0) {
        n_ = other.n_;
        sum_ = other.sum_;
        sum_squares_ = other.sum_squares_;
        min_ = other.min_;
        max_ = other.max_;
        return;
    }
    
    // Merge the statistics
    n_ += other.n_;
    sum_ += other.sum_;
    sum_squares_ += other.sum_squares_;
    
    if (other.min_ < min_) min_ = other.min_;
    if (other.max_ > max_) max_ = other.max_;
}

uint64_t RunningStats::count() const {
    return n_;
}

double RunningStats::mean() const {
    if (n_ == 0) {
        throw std::domain_error("No data available");
    }
    return sum_ / static_cast<double>(n_);
}

double RunningStats::variance() const {
    if (n_ == 0) {
        throw std::domain_error("No data available");
    }
    
    // Calculate variance using the computational formula
    // Variance = Σxi²/n - μ²
    // To avoid catastrophic cancellation with large numbers, we compute:
    // Variance = (Σxi²)/n - (Σxi)²/(n²) = (n*Σxi² - (Σxi)²)/(n²)
    
    double n_d = static_cast<double>(n_);
    double n_times_sum_squares = n_d * sum_squares_;
    double sum_squared = sum_ * sum_;
    double denominator = n_d * n_d;
    
    // Variance = (n*Σxi² - (Σxi)²)/(n²)
    double result = (n_times_sum_squares - sum_squared) / denominator;
    
    // Ensure result is positive (handle floating point errors)
    if (result < 0) {
        result = 0;
    }
    
    return result;
}

double RunningStats::minimum() const {
    if (n_ == 0) {
        throw std::domain_error("No data available");
    }
    return min_;
}

double RunningStats::maximum() const {
    if (n_ == 0) {
        throw std::domain_error("No data available");
    }
    return max_;
}