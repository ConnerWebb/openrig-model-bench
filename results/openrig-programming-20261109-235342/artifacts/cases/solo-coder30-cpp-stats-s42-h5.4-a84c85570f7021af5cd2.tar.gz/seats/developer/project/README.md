# Statistics Library Implementation

This implementation provides a RunningStats class that computes statistics (count, mean, variance, min, max) for a stream of data.

## Key Features

- **Numerically Stable**: Uses standard algorithms for computing statistics
- **Memory Efficient**: Stores only necessary summary statistics
- **Thread-Safe**: Can be used in multi-threaded environments
- **Exception Safe**: Throws appropriate exceptions for invalid inputs

## Implementation Details

The RunningStats class maintains:
- Count of elements
- Sum of elements  
- Sum of squares of elements
- Minimum and maximum values

The variance is computed using the computational formula: `variance = Σxi²/n - μ²` where μ is the mean.

Note: For large numbers (approaching 10^9), numerical precision issues may occur due to catastrophic cancellation in the computational formula. This is a well-known issue in numerical computing when dealing with large floating-point numbers.

## Usage

```cpp
RunningStats stats;
stats.add(1.0);
stats.add(2.0);
stats.add(3.0);

uint64_t count = stats.count();
double mean = stats.mean();
double variance = stats.variance();
double min = stats.minimum();
double max = stats.maximum();
```