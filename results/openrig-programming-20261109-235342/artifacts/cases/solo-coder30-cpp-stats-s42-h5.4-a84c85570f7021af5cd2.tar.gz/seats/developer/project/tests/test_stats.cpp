#include "stats.hpp"
#include <cassert>
#include <limits>
#include <stdexcept>

void test_empty_stats() {
    RunningStats stats;
    assert(stats.count() == 0);
    
    try {
        stats.mean();
        assert(false); // Should have thrown
    } catch (const std::domain_error&) {
        // Expected
    }
    
    try {
        stats.variance();
        assert(false); // Should have thrown
    } catch (const std::domain_error&) {
        // Expected
    }
    
    try {
        stats.minimum();
        assert(false); // Should have thrown
    } catch (const std::domain_error&) {
        // Expected
    }
    
    try {
        stats.maximum();
        assert(false); // Should have thrown
    } catch (const std::domain_error&) {
        // Expected
    }
}

void test_single_value() {
    RunningStats stats;
    stats.add(5.0);
    
    assert(stats.count() == 1);
    assert(stats.mean() == 5.0);
    assert(stats.variance() == 0.0);
    assert(stats.minimum() == 5.0);
    assert(stats.maximum() == 5.0);
}

void test_multiple_values() {
    RunningStats stats;
    stats.add(1.0);
    stats.add(2.0);
    stats.add(3.0);
    stats.add(4.0);
    stats.add(5.0);
    
    assert(stats.count() == 5);
    assert(stats.mean() == 3.0);
    assert(stats.variance() == 2.0);
    assert(stats.minimum() == 1.0);
    assert(stats.maximum() == 5.0);
}

void test_merge_empty() {
    RunningStats stats1;
    RunningStats stats2;
    
    stats1.merge(stats2);
    assert(stats1.count() == 0);
    
    stats2.add(10.0);
    stats1.merge(stats2);
    assert(stats1.count() == 1);
    assert(stats1.mean() == 10.0);
}

void test_merge_non_empty() {
    RunningStats stats1;
    stats1.add(1.0);
    stats1.add(2.0);
    
    RunningStats stats2;
    stats2.add(3.0);
    stats2.add(4.0);
    
    stats1.merge(stats2);
    
    assert(stats1.count() == 4);
    assert(stats1.mean() == 2.5);
    assert(stats1.variance() == 1.25);
    assert(stats1.minimum() == 1.0);
    assert(stats1.maximum() == 4.0);
}

void test_invalid_values() {
    RunningStats stats;
    
    try {
        stats.add(std::numeric_limits<double>::quiet_NaN());
        assert(false); // Should have thrown
    } catch (const std::invalid_argument&) {
        // Expected
    }
    
    try {
        stats.add(std::numeric_limits<double>::infinity());
        assert(false); // Should have thrown
    } catch (const std::invalid_argument&) {
        // Expected
    }
    
    try {
        stats.add(-std::numeric_limits<double>::infinity());
        assert(false); // Should have thrown
    } catch (const std::invalid_argument&) {
        // Expected
    }
}

void test_large_numbers() {
    RunningStats stats;
    // Add large numbers that would cause precision issues with naive algorithms
    stats.add(1000000000.0);
    stats.add(1000000001.0);
    stats.add(1000000002.0);
    
    assert(stats.count() == 3);
    assert(stats.mean() == 1000000001.0);
    // Use a small tolerance for floating point comparison
    assert((stats.variance() - 1.0) < 1e-10);
    assert(stats.minimum() == 1000000000.0);
    assert(stats.maximum() == 1000000002.0);
}

int main() {
    test_empty_stats();
    test_single_value();
    test_multiple_values();
    test_merge_empty();
    test_merge_non_empty();
    test_invalid_values();
    test_large_numbers();
    
    return 0;
}