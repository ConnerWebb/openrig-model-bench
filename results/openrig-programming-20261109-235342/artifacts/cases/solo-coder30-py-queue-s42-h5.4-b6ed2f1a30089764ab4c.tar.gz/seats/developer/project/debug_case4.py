import json
import sqlite3

# Let's debug case 4 step by step
# max_attempts: 1
# ops: [
#   ["enqueue", "x", 0],
#   ["claim", "w", 0, 2],
#   ["claim", "other", 2, 2],
#   ["status", "x"]
# ]

# Let's simulate what should happen:

# Step 1: enqueue "x", 0
# Should create job with state "queued", attempts 0

# Step 2: claim "w", 0, 2
# Should find queued job, update to leased state with owner "w", expiry = 0 + 2 = 2, attempts = 1

# Step 3: claim "other", 2, 2  
# Should try to find job that is either queued OR leased and expired (expiry <= 2)
# Job is leased with expiry = 2, so it's expired at time 2
# But it should be claimed by "other" worker, but it's already claimed by "w"

# Actually, let me check the claim logic more carefully.

# The claim method checks:
# WHERE (state = 'queued' OR (state = 'leased' AND expiry <= ?))
# AND attempts < ?
# ORDER BY created_at ASC LIMIT 1

# So if job is leased and expiry <= now, it can be claimed by anyone.
# But if job is leased and expiry > now, it can only be claimed by the owner.

# In case 4:
# Step 1: enqueue "x", 0 - creates job with state "queued", attempts 0
# Step 2: claim "w", 0, 2 - finds queued job, updates to leased with owner "w", expiry = 2, attempts = 1
# Step 3: claim "other", 2, 2 - finds job that is leased and expiry = 2 <= now = 2, so can be claimed by anyone
# But the test says it should return null, which means it didn't find a job.

# Wait, let me re-read the claim logic. It's checking if the job can be updated by this worker.
# The claim method does:
# UPDATE jobs SET state = 'leased', owner = ?, expiry = ?, attempts = ?, updated_at = strftime('%s', 'now')
# WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND expiry <= ?))

# So if the job is leased and expiry <= now, it can be claimed by anyone.
# But if it's leased and expiry > now, it can only be claimed by the owner.

# In case 4:
# Step 1: enqueue "x", 0 - state = "queued", attempts = 0
# Step 2: claim "w", 0, 2 - finds queued job, updates to leased with owner "w", expiry = 2, attempts = 1
# Step 3: claim "other", 2, 2 - finds job that is leased with expiry = 2 <= now = 2, so can be claimed by anyone
# But the test expects it to return null.

# This suggests that the job should be in "failed" state, not "leased" state.

# Maybe there's a different interpretation. Let me look at the problem description again.

# The problem says:
# "If a job is leased and not completed within the time, it should fail."

# But in case 4, the job is leased for 2 seconds from time 0, so it should expire at time 2.
# At time 2, when we try to claim it with worker "other", it should be available.
# But the test expects it to be in "failed" state.

# I think I misunderstood the problem. Let me read the problem description once more.