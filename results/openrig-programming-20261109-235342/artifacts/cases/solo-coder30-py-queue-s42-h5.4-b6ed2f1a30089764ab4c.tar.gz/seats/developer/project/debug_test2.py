#!/usr/bin/env python3

import json
import tempfile
import pathlib
import sys
sys.path.insert(0, '/work')
import solution

# Run the exact failing test case
test_case = {
    "max_attempts": 1,
    "ops": [
        ["enqueue", "x", 0],
        ["claim", "w", 0, 2],
        ["claim", "other", 2, 2],
        ["status", "x"]
    ]
}

with tempfile.TemporaryDirectory() as d:
    q = solution.JobQueue(str(pathlib.Path(d)/'q.db'), test_case.get('max_attempts',3))
    out = []
    
    for op in test_case.get('ops',[]):
        print(f"Executing: {op}")
        result = getattr(q,op[0])(*op[1:])
        print(f"Result: {result}")
        out.append(result)
    
    print(f"Full output: {out}")
    expected = [True, {"key": "x", "payload": 0, "attempts": 1}, None, {"state": "failed", "attempts": 1}]
    print(f"Expected: {expected}")
    
    # Let's also check the database state manually
    import sqlite3
    conn = sqlite3.connect(str(pathlib.Path(d)/'q.db'))
    cursor = conn.execute('SELECT * FROM jobs')
    rows = cursor.fetchall()
    print(f"Database rows: {rows}")
    
    # Let's also check what happens if we try to claim again
    print("Trying to claim again...")
    result = q.claim("another_worker", 5, 2)
    print(f"Second claim result: {result}")
    
    cursor = conn.execute('SELECT * FROM jobs')
    rows = cursor.fetchall()
    print(f"Database rows after second claim attempt: {rows}")
    conn.close()