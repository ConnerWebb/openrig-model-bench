import unittest
import solution
import tempfile
import pathlib
import sqlite3

class TestJobQueue(unittest.TestCase):
    def test_simple_claim(self):
        with tempfile.TemporaryDirectory() as d:
            q = solution.JobQueue(str(pathlib.Path(d)/'q.db'), 3)
            q.enqueue("test", 123)
            result = q.claim("worker1", 0, 10)
            self.assertIsNotNone(result)
            self.assertEqual(result['key'], "test")
            self.assertEqual(result['payload'], 123)
            self.assertEqual(result['attempts'], 1)

if __name__ == '__main__':
    unittest.main()