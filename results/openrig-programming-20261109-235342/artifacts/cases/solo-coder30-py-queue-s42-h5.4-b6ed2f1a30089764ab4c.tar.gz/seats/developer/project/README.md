# Job Queue Implementation

This is a simple job queue implementation with the following features:
- Enqueue jobs with payloads
- Claim jobs for workers with lease times
- Complete or fail jobs
- Track attempts and job states
- Handle job expiration and requeuing

## Methods

### `__init__(self, path, max_attempts=3)`
Initialize the job queue with a database file path and maximum attempts.

### `enqueue(self, key, payload)`
Enqueue a job with the given key and payload.

### `claim(self, worker, now, lease)`
Claim a job for a worker. Returns job dict or None if no job available.

### `complete(self, key, worker)`
Complete a job, marking it as done.

### `fail(self, key, worker)`
Fail a job, either requeueing it or marking as failed if max attempts exceeded.

### `status(self, key)`
Get the status of a job.

## Job States

- `queued`: Job is available for claiming
- `leased`: Job is claimed by a worker
- `done`: Job has been completed
- `failed`: Job has failed after max attempts

## Database Schema

The implementation uses SQLite with a jobs table:
- `key`: Unique job identifier
- `payload`: JSON-encoded job payload
- `state`: Current job state
- `owner`: Worker that owns the job (for leased state)
- `expiry`: Expiry timestamp for leased jobs
- `attempts`: Number of times the job has been attempted
- `created_at`: Job creation timestamp
- `updated_at`: Last update timestamp