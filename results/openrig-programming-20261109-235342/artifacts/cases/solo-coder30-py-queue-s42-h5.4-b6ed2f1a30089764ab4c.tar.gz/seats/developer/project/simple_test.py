import json
import tempfile
import pathlib
import solution

# Test a simple case that should work
test_input = {
    "ops": [
        ["enqueue", "test", {"data": "value"}],
        ["claim", "worker1", 0, 10],
        ["complete", "test", "worker1"]
    ]
}

with tempfile.TemporaryDirectory() as d:
    q = solution.JobQueue(str(pathlib.Path(d)/'q.db'))
    out = []
    for op in test_input.get('ops', []):
        print(f"Executing: {op}")
        result = getattr(q, op[0])(*op[1:])
        print(f"Result: {result}")
        out.append(result)
    
    print(f"Final output: {json.dumps({'value': out})}")