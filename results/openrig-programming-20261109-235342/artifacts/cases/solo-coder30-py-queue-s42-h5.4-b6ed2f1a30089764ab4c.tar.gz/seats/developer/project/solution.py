import sqlite3
import json
import time
import os

class JobQueue:
    def __init__(self, path, max_attempts=3):
        self.path = path
        self.max_attempts = max_attempts
        conn = sqlite3.connect(path)
        try:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL,
                    owner TEXT,
                    expiry REAL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                )
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_jobs_state_expiry ON jobs(state, expiry)
            ''')
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def enqueue(self, key, payload):
        """Enqueue a job. Returns True if successful."""
        if not key:
            raise ValueError("Key must be non-empty")
        
        conn = sqlite3.connect(self.path)
        try:
            conn.execute('''
                INSERT OR IGNORE INTO jobs (key, payload, state, created_at, updated_at)
                VALUES (?, ?, 'queued', strftime('%s', 'now'), strftime('%s', 'now'))
            ''', (key, json.dumps(payload)))
            conn.commit()
            return conn.total_changes > 0
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def claim(self, worker, now, lease):
        """Claim a job for a worker. Returns job dict or None if no job available."""
        if not worker:
            raise ValueError("Worker must be non-empty")
        if lease <= 0:
            raise ValueError("Lease must be positive")
        
        conn = sqlite3.connect(self.path)
        try:
            # Find a job that is either queued or leased and expired
            # We need to select the oldest job that meets criteria
            cursor = conn.execute('''
                SELECT key, payload, attempts, state, owner FROM jobs 
                WHERE (state = 'queued' OR (state = 'leased' AND expiry <= ?))
                AND attempts < ?
                ORDER BY created_at ASC
                LIMIT 1
            ''', (now, self.max_attempts))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            key, payload, attempts, state, owner = row
            
            # If job is already leased to a different worker, return None
            if state == 'leased' and owner != worker:
                return None
            
            # If job has reached max_attempts, return None (can't claim)
            if attempts >= self.max_attempts:
                return None
            
            # Update the job to be leased
            expiry = now + lease
            # First, try to update the job to be leased by this worker
            conn.execute('''
                UPDATE jobs 
                SET state = 'leased', owner = ?, expiry = ?, attempts = ?, updated_at = strftime('%s', 'now')
                WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND expiry <= ?))
            ''', (worker, expiry, attempts + 1, key, now))
            
            conn.commit()
            
            # Check if the update actually affected a row
            if conn.total_changes == 0:
                return None
            
            # Return the claimed job
            return {
                'key': key,
                'payload': json.loads(payload),
                'attempts': attempts + 1
            }
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def fail(self, key):
        """Fail a job."""
        conn = sqlite3.connect(self.path)
        try:
            conn.execute('''
                UPDATE jobs 
                SET state = 'failed', updated_at = strftime('%s', 'now')
                WHERE key = ?
            ''', (key,))
            conn.commit()
            return conn.total_changes > 0
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def complete(self, key, worker):
        """Complete a job if it's owned by the worker."""
        conn = sqlite3.connect(self.path)
        try:
            cursor = conn.execute('''
                SELECT owner FROM jobs WHERE key = ?
            ''', (key,))
            row = cursor.fetchone()
            if not row:
                return False
            owner = row[0]
            if owner != worker:
                return False
            
            conn.execute('''
                UPDATE jobs 
                SET state = 'done', updated_at = strftime('%s', 'now')
                WHERE key = ?
            ''', (key,))
            conn.commit()
            return conn.total_changes > 0
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def status(self, key):
        """Get the status of a job."""
        conn = sqlite3.connect(self.path)
        try:
            cursor = conn.execute('''
                SELECT state, attempts FROM jobs WHERE key = ?
            ''', (key,))
            row = cursor.fetchone()
            if not row:
                return None
            state, attempts = row
            return {
                'state': state,
                'attempts': attempts
            }
        except Exception:
            raise
        finally:
            conn.close()