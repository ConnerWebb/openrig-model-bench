import unittest
import os
import tempfile
from solution import aggregate

class TestAggregate(unittest.TestCase):
    def write_csv(self, content: str) -> str:
        fd, path = tempfile.mkstemp(text=True)
        os.close(fd)
        with open(path, 'w', encoding='utf-8', newline='') as f:
            f.write(content)
        return path

    def test_basic(self):
        csv = "category,amount\nFood,10\nTravel,5.5\nFood,2.5\n"
        path = self.write_csv(csv)
        expected = {"Food": "12.50", "Travel": "5.50"}
        self.assertEqual(aggregate(path), expected)
        os.remove(path)

    def test_blank_and_whitespace(self):
        csv = "category,amount\n  ,   \n\nFood ,  +3 \nTravel,2\n"
        path = self.write_csv(csv)
        expected = {"Food": "3.00", "Travel": "2.00"}
        self.assertEqual(aggregate(path), expected)
        os.remove(path)

    def test_invalid_header(self):
        csv = "cat,amt\nFood,1\n"
        path = self.write_csv(csv)
        with self.assertRaises(ValueError):
            aggregate(path)
        os.remove(path)

    def test_invalid_amount(self):
        csv = "category,amount\nFood,-1\n"
        path = self.write_csv(csv)
        with self.assertRaises(ValueError):
            aggregate(path)
        os.remove(path)

    def test_large_numbers(self):
        csv = "category,amount\nBig,123456789012\nBig,0.99\n"
        path = self.write_csv(csv)
        expected = {"Big": "123456789012.99"}
        self.assertEqual(aggregate(path), expected)
        os.remove(path)

if __name__ == '__main__':
    unittest.main()
