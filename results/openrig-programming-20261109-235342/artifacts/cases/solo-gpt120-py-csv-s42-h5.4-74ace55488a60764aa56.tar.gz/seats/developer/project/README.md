# CSV Category Aggregator

This repository provides a single function `aggregate(path: str) -> dict[str, str]` that reads a UTF‑8 CSV file and returns the total amount per category.

## Specification
- The CSV **must** have a header exactly `category,amount` (case‑sensitive).
- Blank rows (all fields empty after stripping) are ignored.
- Every non‑blank row must contain exactly two fields.
- Whitespace around each field is stripped.
- `category` must be non‑empty after stripping.
- `amount` may optionally start with `+` and must match the pattern:
  - 1‑12 decimal digits
  - optional decimal point followed by 1 or 2 digits
  - No negative numbers, exponents, or other symbols.
- All arithmetic uses `decimal.Decimal` for exact precision.
- The function returns a dictionary mapping each category to a string formatted with **exactly two decimal places**. Keys are sorted alphabetically.
- Errors in format raise `ValueError`.

## Implementation Details
- The CSV is streamed using Python's built‑in `csv` module; the whole file is never loaded into memory.
- Amount parsing validates the format with a regular expression before converting to `Decimal`.
- Totals are accumulated in a `dict[str, Decimal]` and finally quantized to two decimal places.

## Running Tests
```bash
python -m unittest test_solution.py
```
All tests are self‑contained and use temporary files.
