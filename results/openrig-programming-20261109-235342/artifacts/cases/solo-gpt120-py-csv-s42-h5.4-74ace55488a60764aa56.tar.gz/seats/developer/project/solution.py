import csv
import decimal
from decimal import Decimal
from typing import Dict

def _parse_amount(val: str) -> Decimal:
    # Strip whitespace
    val = val.strip()
    # Validate format: optional +, digits 1-12, optional . with 1-2 digits
    # No negative, no exponent
    if not val:
        raise ValueError("Empty amount")
    if val.startswith('+'):
        val = val[1:]
    # Use Decimal for exactness, but validate pattern
    import re
    if not re.fullmatch(r"\d{1,12}(?:\.\d{1,2})?", val):
        raise ValueError(f"Invalid amount format: {val}")
    return Decimal(val)

def aggregate(path: str) -> Dict[str, str]:
    """Read a UTF-8 CSV file at *path* and aggregate amounts per category.

    The CSV must have a header exactly ``category,amount`` (case‑sensitive).
    Blank rows are ignored. Each non‑blank row must contain exactly two fields.
    Whitespace around fields is stripped. ``category`` must be non‑empty after
    stripping. ``amount`` must match the pattern ``+?\d{1,12}(.\d{1,2})?`` and be
    non‑negative. All arithmetic uses :class:`decimal.Decimal` for exactness.
    The returned dictionary maps each category to a string formatted with two
    decimal places, sorted by category.
    """
    decimal.getcontext().prec = 28  # sufficient precision
    totals: Dict[str, Decimal] = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("CSV is empty")
        if header != ["category", "amount"]:
            raise ValueError("Header must be exactly 'category,amount'")
        for row in reader:
            # Skip completely blank records (all fields empty after stripping)
            if len(row) == 0:
                continue
            # CSV may return rows with fewer fields; treat missing as blank
            if len(row) != 2:
                raise ValueError(f"Row does not have exactly two fields: {row}")
            cat_raw, amt_raw = row
            if cat_raw.strip() == "" and amt_raw.strip() == "":
                # completely blank record
                continue
            category = cat_raw.strip()
            if not category:
                raise ValueError("Category cannot be empty")
            amount = _parse_amount(amt_raw)
            totals[category] = totals.get(category, Decimal('0')) + amount
    # Prepare output with sorted keys and two decimal places
    result: Dict[str, str] = {}
    for cat in sorted(totals.keys()):
        # Quantize to two decimal places
        quantized = totals[cat].quantize(Decimal('0.01'))
        result[cat] = f"{quantized:.2f}"
    return result
