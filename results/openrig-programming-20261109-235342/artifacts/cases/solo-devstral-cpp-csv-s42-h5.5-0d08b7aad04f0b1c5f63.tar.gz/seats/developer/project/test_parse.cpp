#include "solution.hpp"
#include <iostream>

int main() {
    std::istringstream input("category,amount\n\"x\"\"quote\",51268\n");
    try {
        auto result = aggregate(input);
        for (const auto& p : result) {
            std::cout << "Category: '" << p.first << "' Amount: " << p.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
