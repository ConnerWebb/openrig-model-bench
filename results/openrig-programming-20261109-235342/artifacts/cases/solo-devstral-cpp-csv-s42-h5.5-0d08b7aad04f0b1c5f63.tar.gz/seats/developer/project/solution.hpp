#pragma once

#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <limits>
#include <stdexcept>
#include <cctype>

namespace detail {

// Trim whitespace from both ends
inline std::string trim(const std::string& str) {
    size_t start = str.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = str.find_last_not_of(" \t\r\n");
    return str.substr(start, end - start + 1);
}

// Parse int64 from string
inline int64_t parse_int64(const std::string& str) {
    if (str.empty()) {
        throw std::invalid_argument("Empty string");
    }

    size_t pos = 0;
    bool negative = false;

    // Check for sign
    if (str[0] == '+') {
        pos = 1;
    } else if (str[0] == '-') {
        negative = true;
        pos = 1;
    }

    // Check for empty after sign
    if (pos == str.size()) {
        throw std::invalid_argument("Invalid integer format");
    }

    // Parse digits
    int64_t result = 0;
    for (; pos < str.size(); ++pos) {
        if (!std::isdigit(str[pos])) {
            throw std::invalid_argument("Invalid integer format");
        }

        int digit = str[pos] - '0';

        // Check for overflow
        if (result > (std::numeric_limits<int64_t>::max() - digit) / 10) {
            throw std::overflow_error("Integer overflow");
        }

        result = result * 10 + digit;
    }

    return negative ? -result : result;
}

// Read a complete CSV line (handling quoted fields that span multiple lines)
inline std::string read_csv_line(std::istream& in) {
    std::string line;
    char c;
    bool in_quotes = false;

    while (in.get(c)) {
        if (c == '"') {
            // Check if this is an escaped quote
            if (in.peek() == '"') {
                in.get(c); // consume the second quote
                line += '"';
            } else {
                in_quotes = !in_quotes;
                line += c;
            }
        } else if (c == '\n' || c == '\r') {
            if (!in_quotes) {
                // End of line
                return line;
            }
            // Otherwise, it's part of a quoted field, include it
            line += c;
        } else {
            line += c;
        }
    }

    if (in_quotes) {
        throw std::invalid_argument("Unterminated quoted field");
    }

    return line;
}

// Parse a single field from a stream
inline std::string parse_field(std::istream& in) {
    char c;
    if (!in.get(c)) {
        return "";
    }

    // Check if field is quoted
    if (c == '"') {
        std::string result;
        result += c; // Add opening quote

        while (in.get(c)) {
            result += c;
            if (c == '"') {
                // Check if next character is also a quote (escape)
                if (in.peek() == '"') {
                    in.get(c); // consume the second quote
                    result += '"';
                } else {
                    // End of quoted field
                    return result;
                }
            }
        }
        throw std::invalid_argument("Unterminated quoted field");
    } else {
        // Unquoted field
        std::string result;
        result += c;
        while (in.peek() != EOF && in.peek() != ',' && in.peek() != '\n' && in.peek() != '\r') {
            result += in.get();
        }
        return result;
    }
}

} // namespace detail

// Main aggregation function
inline std::map<std::string, int64_t> aggregate(std::istream& in) {
    std::map<std::string, int64_t> result;
    bool header_read = false;

    while (in.peek() != EOF) {
        std::string line = detail::read_csv_line(in);

        // Skip empty lines
        if (line.empty() || line.find_first_not_of(" \t\r") == std::string::npos) {
            continue;
        }

        std::istringstream line_stream(line);
        std::vector<std::string> fields;

        // Parse fields
        while (line_stream.peek() != EOF) {
            std::string field = detail::parse_field(line_stream);
            fields.push_back(field);

            // Skip comma or newline
            if (line_stream.peek() == ',') {
                line_stream.get();
            } else if (line_stream.peek() == '\n' || line_stream.peek() == '\r') {
                break;
            }
        }

        // Check for empty line
        if (fields.empty()) {
            continue;
        }

        // Check if this is the header
        if (!header_read) {
            if (fields.size() != 2 || detail::trim(fields[0]) != "category" || detail::trim(fields[1]) != "amount") {
                throw std::invalid_argument("Invalid header: expected 'category,amount'");
            }
            header_read = true;
            continue;
        }

        // Check we have exactly 2 fields
        if (fields.size() != 2) {
            throw std::invalid_argument("Invalid number of fields");
        }

        std::string category = detail::trim(fields[0]);
        std::string amount_str = detail::trim(fields[1]);

        // Validate category is not empty
        if (category.empty()) {
            throw std::invalid_argument("Category cannot be empty");
        }

        // Validate amount
        if (amount_str.empty()) {
            throw std::invalid_argument("Amount cannot be empty");
        }

        // Parse amount
        int64_t amount;
        try {
            amount = detail::parse_int64(amount_str);
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount format");
        }

        // Aggregate with overflow checking
        try {
            // Check for overflow before adding
            if (amount > 0 && result[category] > std::numeric_limits<int64_t>::max() - amount) {
                throw std::invalid_argument("Overflow in accumulation");
            }
            if (amount < 0 && result[category] < std::numeric_limits<int64_t>::min() - amount) {
                throw std::invalid_argument("Overflow in accumulation");
            }
            result[category] += amount;
        } catch (const std::exception&) {
            throw std::invalid_argument("Overflow in accumulation");
        }
    }

    return result;
}
