#include "solution.hpp"
#include <iostream>
#include <fstream>

int main() {
    std::ifstream input("public-inputs/case-00.csv");
    std::string line;
    int line_num = 0;
    while (std::getline(input, line)) {
        line_num++;
        std::cout << "Line " << line_num << ": '" << line << "'" << std::endl;
    }
    return 0;
}
