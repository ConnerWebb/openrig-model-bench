#include "solution.hpp"
#include <iostream>
#include <sstream>
#include <stdexcept>

int main() {
    // Test 1: Basic case
    {
        std::istringstream input("category,amount\nfood,100\nfood,200\nrent,300\n");
        auto result = aggregate(input);
        if (result.size() != 2 || result["food"] != 300 || result["rent"] != 300) {
            std::cerr << "Test 1 failed" << std::endl;
            return 1;
        }
    }

    // Test 2: Quoted fields
    {
        std::istringstream input("category,amount\n\"foo bar\",100\n\"baz\",200\n");
        auto result = aggregate(input);
        if (result.size() != 2 || result["foo bar"] != 100 || result["baz"] != 200) {
            std::cerr << "Test 2 failed" << std::endl;
            return 1;
        }
    }

    // Test 3: Escaped quotes
    {
        std::istringstream input("category,amount\n\"x\"\"quote\",100\n");
        auto result = aggregate(input);
        if (result.size() != 1 || result["x\"quote"] != 100) {
            std::cerr << "Test 3 failed" << std::endl;
            return 1;
        }
    }

    // Test 4: Empty lines
    {
        std::istringstream input("category,amount\n\nfood,100\n\n\n");
        auto result = aggregate(input);
        if (result.size() != 1 || result["food"] != 100) {
            std::cerr << "Test 4 failed" << std::endl;
            return 1;
        }
    }

    // Test 5: Negative amounts
    {
        std::istringstream input("category,amount\nfood,100\nfood,-50\n");
        auto result = aggregate(input);
        if (result.size() != 1 || result["food"] != 50) {
            std::cerr << "Test 5 failed" << std::endl;
            return 1;
        }
    }

    // Test 6: Invalid header
    {
        std::istringstream input("wrong,amount\nfood,100\n");
        try {
            aggregate(input);
            std::cerr << "Test 6 failed - should have thrown" << std::endl;
            return 1;
        } catch (const std::invalid_argument&) {
            // Expected
        }
    }

    // Test 7: Invalid field count
    {
        std::istringstream input("category,amount\nfood,100,extra\n");
        try {
            aggregate(input);
            std::cerr << "Test 7 failed - should have thrown" << std::endl;
            return 1;
        } catch (const std::invalid_argument&) {
            // Expected
        }
    }

    // Test 8: Empty category
    {
        std::istringstream input("category,amount\n,100\n");
        try {
            aggregate(input);
            std::cerr << "Test 8 failed - should have thrown" << std::endl;
            return 1;
        } catch (const std::invalid_argument&) {
            // Expected
        }
    }

    // Test 9: Invalid amount
    {
        std::istringstream input("category,amount\nfood,abc\n");
        try {
            aggregate(input);
            std::cerr << "Test 9 failed - should have thrown" << std::endl;
            return 1;
        } catch (const std::invalid_argument&) {
            // Expected
        }
    }

    // Test 10: Unterminated quote
    {
        std::istringstream input("category,amount\n\"foo,100\n");
        try {
            aggregate(input);
            std::cerr << "Test 10 failed - should have thrown" << std::endl;
            return 1;
        } catch (const std::invalid_argument&) {
            // Expected
        }
    }

    std::cout << "All tests passed!" << std::endl;
    return 0;
}
