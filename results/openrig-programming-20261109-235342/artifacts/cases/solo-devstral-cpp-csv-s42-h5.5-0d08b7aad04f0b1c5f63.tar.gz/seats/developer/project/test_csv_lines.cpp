#include "solution.hpp"
#include <iostream>
#include <fstream>

int main() {
    std::ifstream input("public-inputs/case-00.csv");
    std::string line;
    int line_num = 0;
    while (input.peek() != EOF) {
        line_num++;
        line = detail::read_csv_line(input);
        std::cout << "Line " << line_num << ": '" << line << "'" << std::endl;
        
        std::istringstream line_stream(line);
        std::vector<std::string> fields;
        while (line_stream.peek() != EOF) {
            std::string field = detail::parse_field(line_stream);
            fields.push_back(field);
            std::cout << "  Field: '" << field << "'" << std::endl;
            if (line_stream.peek() == ',') {
                line_stream.get();
            } else if (line_stream.peek() == '\n' || line_stream.peek() == '\r') {
                break;
            }
        }
        std::cout << "  Total fields: " << fields.size() << std::endl;
    }
    return 0;
}
