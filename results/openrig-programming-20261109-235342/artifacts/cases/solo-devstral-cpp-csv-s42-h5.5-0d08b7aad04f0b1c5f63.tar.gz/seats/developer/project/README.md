# CSV Aggregator

This project implements a C++ header-only library for aggregating CSV data by category.

## Features

- Parses CSV with header "category,amount"
- Supports quoted fields with escaped quotes
- Handles multi-line quoted fields
- Validates data and throws exceptions on errors
- Aggregates amounts by category
- Returns results as a map with sorted keys

## API

```cpp
#include "solution.hpp"

std::map<std::string, int64_t> aggregate(std::istream& input);
```

## Error Handling

The function throws `std::invalid_argument` for:
- Invalid header format
- Wrong number of fields
- Empty category or amount
- Invalid integer format
- Unterminated quoted fields
- Overflow in integer parsing

## Building

```bash
# Compile with C++20
clang++ -std=c++20 -I. -o test test_solution.cpp
```

## Testing

Run the test suite:
```bash
./test
```

## Public Cases

The `public-inputs` directory contains test cases that verify the implementation.
