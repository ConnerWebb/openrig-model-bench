#include "solution.hpp"
#include <iostream>
#include <fstream>

int main() {
    std::ifstream input("public-inputs/case-00.csv");
    try {
        auto result = aggregate(input);
        for (const auto& p : result) {
            std::cout << "Category: '" << p.first << "' Amount: " << p.second << std::endl;
        }
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
