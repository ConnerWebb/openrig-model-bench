#include "solution.hpp"
#include <iostream>
#include <stdexcept>
#include <cassert>
#include <cstring>

class TestBuffer {
public:
    void test_constructor_default() {
        Buffer b;
        assert(b.size() == 0);
        std::cout << "test_constructor_default passed\n";
    }

    void test_constructor_with_size() {
        Buffer b(10);
        assert(b.size() == 10);
        for (std::size_t i = 0; i < 10; ++i) {
            assert(b[i] == 0);
        }
        std::cout << "test_constructor_with_size passed\n";
    }

    void test_constructor_with_values() {
        Buffer b(5);
        b[0] = 1;
        b[1] = 2;
        b[2] = 3;
        b[3] = 4;
        b[4] = 5;
        assert(b[0] == 1);
        assert(b[1] == 2);
        assert(b[2] == 3);
        assert(b[3] == 4);
        assert(b[4] == 5);
        std::cout << "test_constructor_with_values passed\n";
    }

    void test_copy_constructor() {
        Buffer b1(5);
        b1[0] = 10;
        b1[1] = 20;
        b1[2] = 30;
        Buffer b2(b1);
        assert(b2.size() == 5);
        assert(b2[0] == 10);
        assert(b2[1] == 20);
        assert(b2[2] == 30);
        b1[0] = 99;
        assert(b2[0] == 10);  // Independent copy
        std::cout << "test_copy_constructor passed\n";
    }

    void test_copy_assignment() {
        Buffer b1(5);
        b1[0] = 10;
        b1[1] = 20;
        Buffer b2;
        b2 = b1;
        assert(b2.size() == 5);
        assert(b2[0] == 10);
        assert(b2[1] == 20);
        b1[0] = 99;
        assert(b2[0] == 10);  // Independent copy
        std::cout << "test_copy_assignment passed\n";
    }

    void test_self_copy() {
        Buffer b(5);
        b[0] = 10;
        b = b;
        assert(b.size() == 5);
        assert(b[0] == 10);
        std::cout << "test_self_copy passed\n";
    }

    void test_move_constructor() {
        Buffer b1(5);
        b1[0] = 10;
        b1[1] = 20;
        Buffer b2(std::move(b1));
        assert(b2.size() == 5);
        assert(b2[0] == 10);
        assert(b2[1] == 20);
        assert(b1.size() == 0);  // Moved-from has size 0
        std::cout << "test_move_constructor passed\n";
    }

    void test_move_assignment() {
        Buffer b1(5);
        b1[0] = 10;
        b1[1] = 20;
        Buffer b2;
        b2 = std::move(b1);
        assert(b2.size() == 5);
        assert(b2[0] == 10);
        assert(b2[1] == 20);
        assert(b1.size() == 0);  // Moved-from has size 0
        std::cout << "test_move_assignment passed\n";
    }

    void test_self_move() {
        Buffer b(5);
        b[0] = 10;
        b = std::move(b);
        assert(b.size() == 5);
        assert(b[0] == 10);
        std::cout << "test_self_move passed\n";
    }

    void test_size() {
        Buffer b(10);
        assert(b.size() == 10);
        Buffer b2;
        assert(b2.size() == 0);
        std::cout << "test_size passed\n";
    }

    void test_operator_index_mutable() {
        Buffer b(5);
        b[0] = 100;
        b[1] = 200;
        assert(b[0] == 100);
        assert(b[1] == 200);
        std::cout << "test_operator_index_mutable passed\n";
    }

    void test_operator_index_const() {
        Buffer b(5);
        b[0] = 100;
        b[1] = 200;
        const Buffer& cb = b;
        assert(cb[0] == 100);
        assert(cb[1] == 200);
        std::cout << "test_operator_index_const passed\n";
    }

    void test_bounds_checking() {
        Buffer b(5);
        try {
            b[10];
            assert(false);  // Should not reach here
        } catch (const std::out_of_range&) {
            // Expected
        }
        std::cout << "test_bounds_checking passed\n";
    }

    void test_resize_smaller() {
        Buffer b(10);
        b[0] = 1;
        b[1] = 2;
        b.resize(5);
        assert(b.size() == 5);
        assert(b[0] == 1);
        assert(b[1] == 2);
        for (std::size_t i = 2; i < 5; ++i) {
            assert(b[i] == 0);
        }
        std::cout << "test_resize_smaller passed\n";
    }

    void test_resize_larger() {
        Buffer b(5);
        b[0] = 1;
        b[1] = 2;
        b.resize(10);
        assert(b.size() == 10);
        assert(b[0] == 1);
        assert(b[1] == 2);
        for (std::size_t i = 2; i < 10; ++i) {
            assert(b[i] == 0);
        }
        std::cout << "test_resize_larger passed\n";
    }

    void test_resize_preserves_prefix() {
        Buffer b(10);
        for (std::size_t i = 0; i < 10; ++i) {
            b[i] = static_cast<std::uint8_t>(i * 10);
        }
        b.resize(7);
        assert(b.size() == 7);
        for (std::size_t i = 0; i < 7; ++i) {
            assert(b[i] == static_cast<std::uint8_t>(i * 10));
        }
        std::cout << "test_resize_preserves_prefix passed\n";
    }

    void test_resize_zero() {
        Buffer b(10);
        b.resize(0);
        assert(b.size() == 0);
        std::cout << "test_resize_zero passed\n";
    }

    void test_no_leaks() {
        Buffer b(100);
        // No memory leak if destructor works
        std::cout << "test_no_leaks passed\n";
    }

    void test_moved_from_reusable() {
        Buffer b1(10);
        b1[0] = 1;
        Buffer b2(std::move(b1));
        b2[0] = 2;
        assert(b2[0] == 2);
        assert(b1.size() == 0);
        std::cout << "test_moved_from_reusable passed\n";
    }

    void run_all() {
        test_constructor_default();
        test_constructor_with_size();
        test_constructor_with_values();
        test_copy_constructor();
        test_copy_assignment();
        test_self_copy();
        test_move_constructor();
        test_move_assignment();
        test_self_move();
        test_size();
        test_operator_index_mutable();
        test_operator_index_const();
        test_bounds_checking();
        test_resize_smaller();
        test_resize_larger();
        test_resize_preserves_prefix();
        test_resize_zero();
        test_no_leaks();
        test_moved_from_reusable();
        std::cout << "All tests passed!\n";
    }
};

int main() {
    TestBuffer test;
    test.run_all();
    return 0;
}