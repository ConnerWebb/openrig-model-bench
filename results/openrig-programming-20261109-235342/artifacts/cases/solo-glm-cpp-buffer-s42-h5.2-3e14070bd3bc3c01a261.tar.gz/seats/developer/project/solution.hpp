#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Constructor with optional size
    explicit Buffer(std::size_t n = 0) : p(new std::uint8_t[n]), n(n) {
        if (n > 0) {
            std::fill(p, p + n, 0);
        }
    }

    // Destructor
    ~Buffer() {
        if (p) {
            delete[] p;
        }
    }

    // Copy constructor
    Buffer(const Buffer& other) : n(other.n) {
        p = new std::uint8_t[n];
        std::copy(other.p, other.p + n, p);
    }

    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = new std::uint8_t[other.n];
            std::copy(other.p, other.p + other.n, new_p);
            delete[] p;
            p = new_p;
            n = other.n;
        }
        return *this;
    }

    // Move constructor
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Size accessor
    std::size_t size() const noexcept {
        return n;
    }

    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize preserving prefix and zero-initializing new bytes
    void resize(std::size_t k) {
        std::uint8_t* new_p = new std::uint8_t[k];
        std::size_t copy_len = std::min(n, k);
        std::copy(p, p + copy_len, new_p);
        std::fill(new_p + copy_len, new_p + k, 0);
        delete[] p;
        p = new_p;
        n = k;
    }
};