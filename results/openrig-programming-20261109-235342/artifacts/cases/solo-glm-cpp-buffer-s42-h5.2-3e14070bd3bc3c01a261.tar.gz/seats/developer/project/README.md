# Buffer Library

A C++20 RAII-based buffer implementation with deep copy semantics, move semantics, and bounds-checked element access.

## Features

- **RAII**: Automatic memory management with proper constructors and destructors
- **Deep Copy**: Copy constructor and copy assignment perform deep copies
- **Move Semantics**: noexcept move construction and move assignment
- **Bounds Checking**: operator[] throws std::out_of_range on invalid access
- **Resize**: Preserves existing prefix and zero-initializes new bytes

## API

### Constructor
```cpp
Buffer(std::size_t n = 0)
```
Creates a buffer of size `n` with zero-initialized bytes.

### Destructor
```cpp
~Buffer()
```
Frees allocated memory.

### Copy Operations
```cpp
Buffer(const Buffer& other)
Buffer& operator=(const Buffer& other)
```
Creates a deep copy of another buffer.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept
Buffer& operator=(Buffer&& other) noexcept
```
Moves ownership of resources. Moved-from buffers have size 0 and reusable memory.

### Size
```cpp
std::size_t size() const noexcept
```
Returns the current buffer size.

### Element Access
```cpp
std::uint8_t& operator[](std::size_t i)
const std::uint8_t& operator[](std::size_t i) const
```
Returns reference to element at index `i`. Throws std::out_of_range if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k)
```
Resizes buffer to size `k`. Preserves first `min(size(), k)` elements and zero-initializes remaining positions.

## Requirements Met

- ✓ RAII with no leaks
- ✓ Deep copy construction/assignment
- ✓ noexcept move construction/assignment
- ✓ Moved-from buffers have size 0
- ✓ Bounds-checked operator[] throwing std::out_of_range
- ✓ resize() preserves prefix and zero-initializes new bytes
- ✓ No double frees, stale reads, or undefined behavior