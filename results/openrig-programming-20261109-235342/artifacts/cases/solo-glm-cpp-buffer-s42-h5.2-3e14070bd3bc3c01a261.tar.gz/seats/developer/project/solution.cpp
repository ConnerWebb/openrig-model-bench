#include "solution.hpp"
#include <iostream>
#include <sstream>
#include <vector>
#include <string>

// Test runner
int main() {
    std::cout << "Buffer tests running...\n";
    return 0;
}