#include <cassert>
#include <cstdint>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#include "solution.hpp"

static void check(const std::vector<std::uint8_t>& a, const std::vector<std::uint8_t>& b) {
    assert(a.size() == b.size());
    for (std::size_t i = 0; i < a.size(); ++i) assert(a[i] == b[i]);
}

int main() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);

    // default construction
    {
        Buffer b;
        assert(b.size() == 0);
    }

    // construction zero-initializes
    {
        Buffer b(5);
        assert(b.size() == 5);
        for (std::size_t i = 0; i < 5; ++i) assert(b[i] == 0);
    }

    // bounds checking (mutable + const)
    {
        Buffer b(3);
        bool caught = false;
        try { (void)b[3]; } catch (const std::out_of_range&) { caught = true; }
        assert(caught);
        const Buffer& cb = b;
        caught = false;
        try { (void)cb[100]; } catch (const std::out_of_range&) { caught = true; }
        assert(caught);
    }

    // deep copy construction
    {
        Buffer a(4);
        a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4;
        Buffer b = a;
        b[0] = 255;
        assert(a[0] == 1);
        assert(b[0] == 255);
    }

    // deep copy assignment
    {
        Buffer a(4);
        a[0] = 9;
        Buffer b(2);
        b = a;
        assert(b.size() == 4);
        assert(b[0] == 9);
        a[0] = 0;
        assert(b[0] == 9);
    }

    // self copy assignment preserves content
    {
        Buffer a(3);
        a[0] = 7; a[1] = 8; a[2] = 9;
        a = a;
        assert(a.size() == 3);
        assert(a[0] == 7 && a[1] == 8 && a[2] == 9);
    }

    // move construction
    {
        Buffer a(3);
        a[0] = 1; a[1] = 2; a[2] = 3;
        Buffer b = std::move(a);
        assert(b.size() == 3);
        assert(b[0] == 1 && b[1] == 2 && b[2] == 3);
        assert(a.size() == 0);
        // moved-from is reusable
        a.resize(2);
        a[0] = 42;
        assert(a.size() == 2 && a[0] == 42);
    }

    // move assignment
    {
        Buffer a(3);
        a[0] = 5;
        Buffer b(1);
        b = std::move(a);
        assert(b.size() == 3);
        assert(b[0] == 5);
        assert(a.size() == 0);
    }

    // self move assignment preserves content
    {
        Buffer a(3);
        a[0] = 1; a[1] = 2; a[2] = 3;
        a = std::move(a);
        assert(a.size() == 3);
        assert(a[0] == 1 && a[1] == 2 && a[2] == 3);
    }

    // resize grow: preserve prefix, zero-init new
    {
        Buffer a(3);
        a[0] = 10; a[1] = 20; a[2] = 30;
        a.resize(6);
        assert(a.size() == 6);
        assert(a[0] == 10 && a[1] == 20 && a[2] == 30);
        assert(a[3] == 0 && a[4] == 0 && a[5] == 0);
    }

    // resize shrink
    {
        Buffer a(5);
        a[0] = 1; a[4] = 5;
        a.resize(2);
        assert(a.size() == 2);
        assert(a[0] == 1 && a[1] == 0);
    }

    // resize to zero
    {
        Buffer a(4);
        a.resize(0);
        assert(a.size() == 0);
    }

    // full byte range
    {
        Buffer a(256);
        for (std::size_t i = 0; i < 256; ++i) a[i] = (std::uint8_t)i;
        for (std::size_t i = 0; i < 256; ++i) assert(a[i] == (std::uint8_t)i);
    }

    return 0;
}
