# Buffer

A small RAII byte buffer (`std::uint8_t`) in C++20, implemented in `solution.hpp`.

## API

- `Buffer(std::size_t n = 0)` — constructs a buffer of `n` zero-initialized bytes.
- `std::size_t size() const noexcept` — number of bytes.
- `std::uint8_t& operator[](std::size_t i)` / `const std::uint8_t& operator[](std::size_t i) const`
  — element access; throws `std::out_of_range` if `i >= size()`.
- `void resize(std::size_t k)` — resizes to `k` bytes, preserving the existing prefix and
  zero-initializing any new bytes.
- Deep-copy construction and copy assignment (independent storage).
- `noexcept` move construction and move assignment; a moved-from buffer has size 0 and is reusable.
- Self-copy and self-move assignment preserve content.

## Implementation notes

Storage is a `std::vector<std::uint8_t>`, so the class is leak-free, exception-safe, and free of
double frees or stale reads. Move operations are the default `noexcept` vector moves; the
self-assignment guards prevent undefined behavior from self-move.

## Tests

`test_buffer.cpp` is a standalone C++ program (no framework) covering construction, zero-init,
bounds checking (mutable and const), deep copy, self-copy, move construction/assignment,
moved-from reuse, self-move, resize grow/shrink/zero, and the full 0–255 byte range.

Build and run:

```sh
clang++ -std=c++20 -O2 -Wall -Wextra test_buffer.cpp -o /tmp/test_buffer && /tmp/test_buffer
```
