# fetch_pages Implementation

This implementation provides a function `fetch_pages(url, retries=2, timeout=1.0)` that fetches JSON pages over HTTP using Python's standard library.

## Function Signature
```python
def fetch_pages(url: str, retries: int = 2, timeout: float = 1.0) -> List[int]
```

## Features

- Fetches JSON pages over HTTP/HTTPS using Python stdlib
- Each page is an object with `items` (list of integers) and `next` (URL)
- Follows `next` URLs to collect all items in order
- Resolves relative URLs against the current URL
- Validates that all items are integers
- Handles retries for specific HTTP status codes (429, 500, 502, 503, 504)
- Prevents infinite loops by detecting repeated URLs
- Validates input parameters
- Rejects cross-origin URLs
- Supports both absolute and relative `next` URLs

## Parameters

- `url`: Starting HTTP/HTTPS URL
- `retries`: Number of retry attempts for each page (default: 2)
- `timeout`: Timeout for HTTP requests in seconds (default: 1.0)

## Returns

A list of integers from all pages in order.

## Exceptions

- `ValueError`: For invalid URLs, JSON parsing errors, HTTP errors, or invalid page structure

## Usage Example

```python
items = fetch_pages("http://example.com/api/page1")
```

## Implementation Details

The function:
1. Validates input parameters
2. Ensures the initial URL uses HTTP or HTTPS scheme
3. Fetches pages with retry logic for specific HTTP status codes
4. Validates page structure and data types
5. Resolves relative URLs using `urllib.parse.urljoin`
6. Prevents cycles by tracking visited URLs
7. Returns all items in the order they appear across pages