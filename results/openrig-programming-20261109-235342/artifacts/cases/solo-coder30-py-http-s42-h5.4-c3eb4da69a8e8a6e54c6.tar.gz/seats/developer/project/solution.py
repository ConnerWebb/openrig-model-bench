import urllib.request
import urllib.parse
import json
from typing import List

def fetch_pages(url: str, retries: int = 2, timeout: float = 1.0) -> List[int]:
    """
    Fetch JSON pages over HTTP using Python stdlib.
    
    Each page is exactly an object with items (list of integers) and next 
    (same-origin absolute URL, relative URL, or null).
    
    Args:
        url: Starting URL
        retries: Number of retry attempts for each page (default 2)
        timeout: Timeout for HTTP requests in seconds (default 1.0)
        
    Returns:
        List of integers from all pages in order
        
    Raises:
        ValueError: For invalid URLs, JSON parsing errors, or HTTP errors
    """
    # Validate inputs
    if retries < 0:
        raise ValueError("retries must be >= 0")
    if timeout <= 0:
        raise ValueError("timeout must be > 0")
        
    # Validate initial URL scheme
    parsed_url = urllib.parse.urlparse(url)
    if parsed_url.scheme not in ('http', 'https'):
        raise ValueError("Initial URL must be HTTP or HTTPS")
        
    # Store visited URLs to prevent cycles
    visited_urls = set()
    
    # Store results
    result = []
    
    # Current URL
    current_url = url
    
    while current_url is not None:
        # Check for cycles
        if current_url in visited_urls:
            raise ValueError("Repeated page URL detected")
        visited_urls.add(current_url)
        
        # Fetch the page
        page_data = None
        retry_count = 0
        
        while page_data is None:
            try:
                # Create request with timeout
                req = urllib.request.Request(current_url)
                req.add_header('Accept', 'application/json')
                
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    content = response.read()
                    page_data = json.loads(content)
                    
            except urllib.error.HTTPError as e:
                # Retry only on specific status codes
                if e.code in (429, 500, 502, 503, 504) and retry_count < retries:
                    retry_count += 1
                    continue
                else:
                    raise ValueError(f"HTTP error {e.code}: {e.reason}")
                    
            except urllib.error.URLError as e:
                # For network errors, retry if we have retries left
                if retry_count < retries:
                    retry_count += 1
                    continue
                else:
                    raise ValueError(f"Network error: {str(e)}")
                    
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON response")
                
            except Exception as e:
                raise ValueError(f"Unexpected error: {str(e)}")
                
        # Validate page structure
        if not isinstance(page_data, dict):
            raise ValueError("Page must be a JSON object")
            
        if 'items' not in page_data:
            raise ValueError("Page must contain 'items' field")
            
        if 'next' not in page_data:
            raise ValueError("Page must contain 'next' field")
            
        if not isinstance(page_data['items'], list):
            raise ValueError("'items' must be a list")
            
        # Validate items are integers (but not booleans, which are subclass of int in Python)
        for item in page_data['items']:
            if not isinstance(item, int) or isinstance(item, bool):
                raise ValueError("All items must be integers")
                
        # Add items to result
        result.extend(page_data['items'])
        
        # Get next URL
        next_url = page_data['next']
        if next_url is None:
            current_url = None
        else:
            # Resolve relative URLs
            if isinstance(next_url, str):
                # If it's a relative URL, resolve it against current URL
                if not next_url.startswith(('http://', 'https://')):
                    # Resolve relative URL
                    current_parsed = urllib.parse.urlparse(current_url)
                    resolved = urllib.parse.urljoin(current_url, next_url)
                    current_url = resolved
                else:
                    # Check if it's same origin
                    next_parsed = urllib.parse.urlparse(next_url)
                    current_parsed = urllib.parse.urlparse(current_url)
                    if (next_parsed.scheme == current_parsed.scheme and 
                        next_parsed.netloc == current_parsed.netloc):
                        current_url = next_url
                    else:
                        raise ValueError("Cross-origin URL detected")
            else:
                raise ValueError("next must be a string or null")
    
    return result