import unittest
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import solution
from unittest.mock import patch, MagicMock
import urllib.request
import json

class TestFetchPages(unittest.TestCase):
    
    def test_basic_functionality(self):
        """Test basic functionality with simple case"""
        # This would require a real HTTP server, so we'll mock it
        pass
    
    def test_invalid_initial_url_scheme(self):
        """Test that non-http/https URLs raise ValueError"""
        with self.assertRaises(ValueError):
            solution.fetch_pages("ftp://example.com")
            
        with self.assertRaises(ValueError):
            solution.fetch_pages("file:///etc/passwd")
            
    def test_negative_retries(self):
        """Test that negative retries raise ValueError"""
        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", retries=-1)
            
    def test_zero_timeout(self):
        """Test that zero timeout raises ValueError"""
        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", timeout=0)
            
    def test_negative_timeout(self):
        """Test that negative timeout raises ValueError"""
        with self.assertRaises(ValueError):
            solution.fetch_pages("http://example.com", timeout=-1)

if __name__ == '__main__':
    unittest.main()