import unittest,tempfile,pathlib,subprocess
class CorrectReference(unittest.TestCase):
 def test_library(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/"check.cpp").write_text('#include "solution.hpp"\n#include <cassert>\nint main(){Buffer a(2);a[0]=17;auto b=a;b[0]=23;assert(a[0]==17);a.resize(3);assert(a[2]==0);}');r=subprocess.run(["clang++","-fuse-ld=bfd","-std=c++20","-pthread","-I/work",str(p/"check.cpp"),"-o",str(p/"check")],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(subprocess.run([str(p/"check")]).returncode,0)
