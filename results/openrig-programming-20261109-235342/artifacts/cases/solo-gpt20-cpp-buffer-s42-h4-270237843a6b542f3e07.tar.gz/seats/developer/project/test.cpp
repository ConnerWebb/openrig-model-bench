#include "solution.hpp"
#include <cassert>
#include <iostream>

int main(){
    {
        Buffer b;
        assert(b.size()==0u);
    }
    {
        Buffer b(5);
        assert(b.size()==5u);
        for(size_t i=0;i<5;i++) assert(b[i]==0u);
    }
    {
        Buffer b(3);
        bool caught=false;
        try{b[3];}catch(const std::out_of_range&){caught=true;}
        assert(caught);
    }
    {
        Buffer b(2); b[0]=1; b[1]=2; b.resize(5);
        assert(b.size()==5u); assert(b[0]==1u); assert(b[1]==2u);
        for(size_t i=2;i<5;i++) assert(b[i]==0u);
    }
    {
        Buffer b(4); b[0]=1; b[1]=2; b[2]=3; b[3]=4; b.resize(2);
        assert(b.size()==2u); assert(b[0]==1u); assert(b[1]==2u);
    }
    {
        Buffer a(3); a[0]=5; a[1]=6; a[2]=7; Buffer b=a;
        assert(b.size()==3u); assert(b[0]==5u); a[0]=0; assert(b[0]==5u);
    }
    {
        Buffer a(3); a[0]=5; a[1]=6; a[2]=7; Buffer b=std::move(a);
        assert(b.size()==3u); assert(b[0]==5u); assert(a.size()==0u);
    }
    {
        Buffer b(2); b[0]=1; b[1]=2; b=b; assert(b.size()==2u); assert(b[0]==1u);
    }
    {
        Buffer b(2); b[0]=1; b[1]=2; b=std::move(b); assert(b.size()==2u); assert(b[0]==1u);
    }
    std::cout<<"All tests passed"<<std::endl;
    return 0;
}
