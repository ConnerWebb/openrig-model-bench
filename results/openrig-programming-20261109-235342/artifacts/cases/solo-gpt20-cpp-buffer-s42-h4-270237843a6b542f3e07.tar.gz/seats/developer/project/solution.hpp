#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>
#include <stdexcept>

class Buffer {
public:
    Buffer(size_t n = 0) : data_(n, 0) {}
    Buffer(const Buffer& other) : data_(other.data_) {}
    Buffer(Buffer&& other) noexcept : data_(std::move(other.data_)) {
        other.data_.clear();
    }
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            data_ = other.data_;
        }
        return *this;
    }
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            data_ = std::move(other.data_);
            other.data_.clear();
        }
        return *this;
    }
    size_t size() const noexcept { return data_.size(); }
    uint8_t& operator[](size_t i) {
        if (i >= data_.size()) throw std::out_of_range("Buffer index out of range");
        return data_[i];
    }
    const uint8_t& operator[](size_t i) const {
        if (i >= data_.size()) throw std::out_of_range("Buffer index out of range");
        return data_[i];
    }
    void resize(size_t new_size) {
        if (new_size > data_.size()) {
            data_.resize(new_size, 0);
        } else {
            data_.resize(new_size);
        }
    }
private:
    std::vector<uint8_t> data_;
};
