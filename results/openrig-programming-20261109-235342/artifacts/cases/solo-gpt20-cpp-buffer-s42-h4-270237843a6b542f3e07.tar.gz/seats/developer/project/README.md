# Buffer Library

This project implements a simple `Buffer` class in C++20 that manages a dynamic array of `uint8_t` bytes. It provides basic functionality such as construction, resizing, element access with bounds checking, and copy/move semantics.

## Features
- Default and size-based construction.
- `size()` returns current number of bytes.
- Mutable and const `operator[]` with bounds checking.
- `resize()` preserves existing data and zero-initializes new bytes.
- Deep-copy construction and assignment.
- Noexcept move construction and assignment.
- Moved-from buffers become empty and reusable.
- Self-copy and self-move operations preserve content.

## Build & Test
The tests use GoogleTest. Compile with:
```
clang++ -std=c++20 -fuse-ld=bfd -pthread test.cpp -lgtest -lgtest_main -o test
```
Run with:
```
./test
```

## License
MIT
