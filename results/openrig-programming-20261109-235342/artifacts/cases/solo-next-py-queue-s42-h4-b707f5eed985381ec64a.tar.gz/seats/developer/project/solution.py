"""JobQueue: SQLite-based job queue with claim/complete/fail semantics."""

import json
import sqlite3
from typing import Any, Optional


class JobQueue:
    """A thread-safe job queue using SQLite for persistence."""

    def __init__(self, path: str, max_attempts: int = 3) -> None:
        """Initialize the queue.

        Args:
            path: Path to the SQLite database file.
            max_attempts: Maximum attempts before a job is marked as failed.

        Raises:
            ValueError: If max_attempts is not a positive integer.
        """
        if max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self._path = path
        self._max_attempts = max_attempts
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        """Get a database connection with proper settings."""
        conn = sqlite3.connect(self._path, isolation_level=None)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _init_db(self) -> None:
        """Initialize the database schema."""
        conn = self._get_conn()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'queued',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    owner TEXT,
                    lease_until REAL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_state_owner ON jobs(state, owner, lease_until)")
        finally:
            conn.close()

    def enqueue(self, key: str, payload: Any) -> bool:
        """Add a job to the queue.

        Args:
            key: Unique job identifier.
            payload: JSON-compatible payload value.

        Returns:
            True if the job was added, False if key already exists.

        Raises:
            ValueError: If key is empty.
        """
        if not key:
            raise ValueError("key must be non-empty")
        payload_json = json.dumps(payload)
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT OR IGNORE INTO jobs (key, payload, state, attempts) VALUES (?, ?, 'queued', 0)",
                (key, payload_json)
            )
            return conn.total_changes > 0
        finally:
            conn.close()

    def claim(self, worker: str, now: float, lease: float) -> Optional[dict]:
        """Claim a job for a worker.

        Args:
            worker: Worker identifier.
            now: Current timestamp.
            lease: Lease duration in seconds.

        Returns:
            Claimed job as {key, payload, attempts} or None if no jobs available.

        Raises:
            ValueError: If worker is empty or lease is not positive.
        """
        if not worker:
            raise ValueError("worker must be non-empty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        lease_until = now + lease

        conn = self._get_conn()
        try:
            # Use a transaction with immediate locking to prevent race conditions
            conn.execute("BEGIN IMMEDIATE")
            try:
                # First, expire any leases that have passed for leased jobs only
                # If lease expired and attempts >= max_attempts, mark as failed
                # Otherwise, requeue with attempts reset to 0
                conn.execute(
                    """UPDATE jobs SET owner = NULL, lease_until = NULL, state = 
                       CASE WHEN attempts >= ? THEN 'failed' ELSE 'queued' END,
                       attempts = CASE WHEN attempts >= ? THEN attempts ELSE 0 END
                       WHERE state = 'leased' AND lease_until IS NOT NULL AND lease_until <= ?""",
                    (self._max_attempts, self._max_attempts, now)
                )

                # Find the oldest queued job with attempts < max_attempts
                cursor = conn.execute(
                    """SELECT key, payload, attempts FROM jobs
                       WHERE state = 'queued' AND attempts < ?
                       ORDER BY key LIMIT 1""",
                    (self._max_attempts,)
                )
                row = cursor.fetchone()

                if row is None:
                    # No job found, but lease expiration may have changed state
                    # Commit the transaction to persist any lease expirations
                    conn.execute("COMMIT")
                    return None

                key, payload_json, attempts = row
                payload = json.loads(payload_json)

                # Update the job to claimed state (only if still queued)
                # Use total_changes to verify the update actually happened
                conn.execute(
                    """UPDATE jobs SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
                       WHERE key = ? AND state = 'queued'""",
                    (worker, lease_until, attempts + 1, key)
                )

                if conn.total_changes == 0:
                    # Another thread claimed this job first
                    conn.execute("ROLLBACK")
                    return None

                conn.execute("COMMIT")
                return {"key": key, "payload": payload, "attempts": attempts + 1}
            except:
                conn.execute("ROLLBACK")
                raise
        finally:
            conn.close()

    def complete(self, key: str, worker: str) -> bool:
        """Mark a job as completed.

        Args:
            key: Job identifier.
            worker: Worker identifier (must match current owner).

        Returns:
            True if the job was completed, False if the worker doesn't match.

        Raises:
            ValueError: If key or worker is empty.
        """
        if not key or not worker:
            raise ValueError("key and worker must be non-empty")

        conn = self._get_conn()
        try:
            cursor = conn.execute("SELECT owner FROM jobs WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row is None:
                return False
            current_owner = row[0]

            if current_owner != worker:
                return False

            conn.execute("UPDATE jobs SET state = 'done' WHERE key = ?", (key,))
            return True
        finally:
            conn.close()

    def fail(self, key: str, worker: str) -> bool:
        """Mark a job as failed and requeue it.

        Args:
            key: Job identifier.
            worker: Worker identifier (must match current owner).

        Returns:
            True if the job was failed/requeued, False if the worker doesn't match.

        Raises:
            ValueError: If key or worker is empty.
        """
        if not key or not worker:
            raise ValueError("key and worker must be non-empty")

        conn = self._get_conn()
        try:
            cursor = conn.execute("SELECT owner, attempts FROM jobs WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row is None:
                return False
            current_owner, attempts = row

            if current_owner != worker:
                return False

            if attempts >= self._max_attempts:
                conn.execute("UPDATE jobs SET state = 'failed' WHERE key = ?", (key,))
            else:
                conn.execute(
                    "UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?",
                    (key,)
                )
            return True
        finally:
            conn.close()

    def status(self, key: str) -> Optional[dict]:
        """Get the status of a job.

        Args:
            key: Job identifier.

        Returns:
            {state, attempts} or None if job doesn't exist.
        """
        conn = self._get_conn()
        try:
            cursor = conn.execute("SELECT state, attempts FROM jobs WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row is None:
                return None
            state, attempts = row
            return {"state": state, "attempts": attempts}
        finally:
            conn.close()
