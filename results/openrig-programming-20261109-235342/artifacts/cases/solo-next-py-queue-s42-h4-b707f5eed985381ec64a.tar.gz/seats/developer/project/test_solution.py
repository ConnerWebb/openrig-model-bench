"""Tests for JobQueue."""

import json
import os
import tempfile
import threading
import time
import unittest

from solution import JobQueue


class TestBasicOperations(unittest.TestCase):
    """Test basic enqueue/claim/complete/fail operations."""

    def test_enqueue_new_key(self):
        """Enqueue returns True for new key."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            self.assertTrue(q.enqueue("a", {"v": 5304}))
        finally:
            os.unlink(path)

    def test_enqueue_duplicate_key(self):
        """Enqueue returns False for duplicate key."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            self.assertTrue(q.enqueue("a", {"v": 5304}))
            self.assertFalse(q.enqueue("a", "ignored"))
        finally:
            os.unlink(path)

    def test_claim_returns_job(self):
        """Claim returns the oldest queued job."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("a", {"v": 5304})
            result = q.claim("w", 0, 5)
            self.assertEqual(result, {"key": "a", "payload": {"v": 5304}, "attempts": 1})
        finally:
            os.unlink(path)

    def test_claim_wrong_owner_complete(self):
        """Complete returns False if worker doesn't match."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("a", {"v": 5304})
            q.claim("w", 0, 5)
            self.assertFalse(q.complete("a", "wrong"))
        finally:
            os.unlink(path)

    def test_fail_requeues(self):
        """Fail requeues the job if attempts < max_attempts."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("a", {"v": 5304})
            q.claim("w", 0, 5)
            self.assertTrue(q.fail("a", "w"))
            # Should be able to claim again
            result = q.claim("w2", 1, 5)
            self.assertEqual(result, {"key": "a", "payload": {"v": 5304}, "attempts": 2})
        finally:
            os.unlink(path)

    def test_complete_marks_done(self):
        """Complete marks job as done."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("a", {"v": 5304})
            q.claim("w", 0, 5)
            self.assertTrue(q.complete("a", "w"))
            self.assertEqual(q.status("a"), {"state": "done", "attempts": 1})
        finally:
            os.unlink(path)

    def test_claim_after_complete(self):
        """Completed jobs are not claimed."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("a", {"v": 5304})
            q.claim("w", 0, 5)
            q.complete("a", "w")
            self.assertIsNone(q.claim("w3", 100, 5))
        finally:
            os.unlink(path)


class TestMaxAttempts(unittest.TestCase):
    """Test max_attempts behavior."""

    def test_fail_exhausted_attempts(self):
        """Job is marked failed when attempts exceed max_attempts."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path, max_attempts=1)
            q.enqueue("x", 0)
            q.claim("w", 0, 2)
            self.assertTrue(q.fail("x", "w"))
            self.assertEqual(q.status("x"), {"state": "failed", "attempts": 1})
        finally:
            os.unlink(path)

    def test_no_claim_after_max_attempts(self):
        """Job is not claimed after max_attempts exhausted."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path, max_attempts=1)
            q.enqueue("x", 0)
            q.claim("w", 0, 2)
            q.fail("x", "w")
            # Job should be marked failed, not requeued
            self.assertIsNone(q.claim("other", 2, 2))
            self.assertEqual(q.status("x"), {"state": "failed", "attempts": 1})
        finally:
            os.unlink(path)


class TestValidation(unittest.TestCase):
    """Test validation of arguments."""

    def test_empty_key(self):
        """Enqueue raises ValueError for empty key."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.enqueue("", {"v": 1})
        finally:
            os.unlink(path)

    def test_empty_worker(self):
        """Claim raises ValueError for empty worker."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.claim("", 0, 5)
        finally:
            os.unlink(path)

    def test_zero_lease(self):
        """Claim raises ValueError for zero lease."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.claim("w", 0, 0)
        finally:
            os.unlink(path)

    def test_negative_lease(self):
        """Claim raises ValueError for negative lease."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.claim("w", 0, -1)
        finally:
            os.unlink(path)

    def test_zero_max_attempts(self):
        """JobQueue raises ValueError for zero max_attempts."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            with self.assertRaises(ValueError):
                JobQueue(path, max_attempts=0)
        finally:
            os.unlink(path)

    def test_negative_max_attempts(self):
        """JobQueue raises ValueError for negative max_attempts."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            with self.assertRaises(ValueError):
                JobQueue(path, max_attempts=-1)
        finally:
            os.unlink(path)

    def test_empty_key_complete(self):
        """Complete raises ValueError for empty key."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.complete("", "w")
        finally:
            os.unlink(path)

    def test_empty_worker_complete(self):
        """Complete raises ValueError for empty worker."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.complete("a", "")
        finally:
            os.unlink(path)

    def test_empty_key_fail(self):
        """Fail raises ValueError for empty key."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.fail("", "w")
        finally:
            os.unlink(path)

    def test_empty_worker_fail(self):
        """Fail raises ValueError for empty worker."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            with self.assertRaises(ValueError):
                q.fail("a", "")
        finally:
            os.unlink(path)


class TestLeaseExpiration(unittest.TestCase):
    """Test lease expiration behavior."""

    def test_lease_expiration_requeues(self):
        """Lease expiration requeues the job."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("x", 0)
            q.claim("w", 0, 2)
            # At t=3, lease has expired
            result = q.claim("other", 3, 5)
            self.assertEqual(result, {"key": "x", "payload": 0, "attempts": 1})
        finally:
            os.unlink(path)

    def test_lease_expiration_with_max_attempts(self):
        """Lease expiration with max_attempts marks job as failed."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path, max_attempts=1)
            q.enqueue("x", 0)
            q.claim("w", 0, 2)
            # At t=2, lease expires and attempts >= max_attempts
            result = q.claim("other", 2, 2)
            self.assertIsNone(result)
            self.assertEqual(q.status("x"), {"state": "failed", "attempts": 1})
        finally:
            os.unlink(path)


class TestConcurrent(unittest.TestCase):
    """Test concurrent access."""

    def test_concurrent_claims(self):
        """Multiple threads claim unique jobs."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            # Add 12 jobs
            for i in range(12):
                q.enqueue(str(i), {"i": i})

            results = []
            lock = threading.Lock()

            def worker(worker_id):
                result = q.claim(f"worker-{worker_id}", 0, 100)
                if result:
                    with lock:
                        results.append(result["key"])

            # Start 12 threads
            threads = [threading.Thread(target=worker, args=(i,)) for i in range(12)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()

            # All 12 jobs should be claimed uniquely
            self.assertEqual(len(results), 12)
            self.assertEqual(set(results), {str(i) for i in range(12)})
        finally:
            os.unlink(path)


class TestPayloadTypes(unittest.TestCase):
    """Test various payload types."""

    def test_dict_payload(self):
        """Dict payload is preserved."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            payload = {"a": 1, "b": [1, 2, 3], "c": {"nested": True}}
            q.enqueue("x", payload)
            result = q.claim("w", 0, 5)
            self.assertEqual(result["payload"], payload)
        finally:
            os.unlink(path)

    def test_list_payload(self):
        """List payload is preserved."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            payload = [1, 2, 3]
            q.enqueue("x", payload)
            result = q.claim("w", 0, 5)
            self.assertEqual(result["payload"], payload)
        finally:
            os.unlink(path)

    def test_string_payload(self):
        """String payload is preserved."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("x", "hello")
            result = q.claim("w", 0, 5)
            self.assertEqual(result["payload"], "hello")
        finally:
            os.unlink(path)

    def test_number_payload(self):
        """Number payload is preserved."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("x", 42)
            result = q.claim("w", 0, 5)
            self.assertEqual(result["payload"], 42)
        finally:
            os.unlink(path)


class TestStatus(unittest.TestCase):
    """Test status function."""

    def test_status_nonexistent(self):
        """Status returns None for nonexistent job."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            self.assertIsNone(q.status("nonexistent"))
        finally:
            os.unlink(path)

    def test_status_queued(self):
        """Status returns correct state for queued job."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("x", 0)
            self.assertEqual(q.status("x"), {"state": "queued", "attempts": 0})
        finally:
            os.unlink(path)

    def test_status_done(self):
        """Status returns correct state for done job."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path)
            q.enqueue("x", 0)
            q.claim("w", 0, 5)
            q.complete("x", "w")
            self.assertEqual(q.status("x"), {"state": "done", "attempts": 1})
        finally:
            os.unlink(path)

    def test_status_failed(self):
        """Status returns correct state for failed job."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            q = JobQueue(path, max_attempts=1)
            q.enqueue("x", 0)
            q.claim("w", 0, 2)
            q.fail("x", "w")
            self.assertEqual(q.status("x"), {"state": "failed", "attempts": 1})
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
