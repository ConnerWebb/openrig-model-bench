# JobQueue

A SQLite-based job queue implementation in Python.

## Features

- Thread-safe operations using SQLite transactions
- Lease-based claiming with automatic expiration
- Configurable max attempts before job failure
- Atomic operations to prevent duplicate claims

## Usage

```python
from solution import JobQueue

# Create a queue
q = JobQueue("jobs.db", max_attempts=3)

# Enqueue a job
q.enqueue("task-1", {"url": "https://example.com"})

# Claim a job (returns None if no jobs available)
job = q.claim("worker-1", now=0, lease=60)
if job:
    print(f"Processing {job['key']} (attempt {job['attempts']})")
    
    # Mark as complete
    q.complete(job['key'], "worker-1")
    
    # Or mark as failed (requeues if attempts < max_attempts)
    # q.fail(job['key'], "worker-1")

# Check job status
status = q.status("task-1")
print(status)  # {'state': 'done', 'attempts': 1}
```

## API

### `JobQueue(path, max_attempts=3)`

Create a new job queue.

- `path`: Path to the SQLite database file
- `max_attempts`: Maximum number of claim attempts before marking job as failed

### `enqueue(key, payload) -> bool`

Add a job to the queue.

- `key`: Unique job identifier
- `payload`: JSON-serializable job data

Returns `True` if the job was added, `False` if a job with the same key already exists.

### `claim(worker, now, lease) -> dict | None`

Claim the oldest queued job.

- `worker`: Worker identifier
- `now`: Current timestamp (for lease calculation)
- `lease`: Lease duration in seconds

Returns a dict with `key`, `payload`, and `attempts`, or `None` if no jobs available.

### `complete(key, worker) -> bool`

Mark a job as completed.

- `key`: Job identifier
- `worker`: Worker identifier (must match current owner)

Returns `True` if the job was completed, `False` if the worker doesn't match.

### `fail(key, worker) -> bool`

Mark a job as failed and requeue it.

- `key`: Job identifier
- `worker`: Worker identifier (must match current owner)

Returns `True` if the job was failed, `False` if the worker doesn't match. The job is requeued if `attempts < max_attempts`, otherwise marked as failed.

### `status(key) -> dict | None`

Get the status of a job.

- `key`: Job identifier

Returns a dict with `state` and `attempts`, or `None` if the job doesn't exist.

## Job States

- `queued`: Job is waiting to be claimed
- `leased`: Job is currently claimed by a worker
- `done`: Job was successfully completed
- `failed`: Job failed after reaching `max_attempts`

## Lease Expiration

When a lease expires (`lease_until <= now`), the job is automatically requeued (if `attempts < max_attempts`) or marked as failed. This ensures that jobs don't remain stuck if a worker crashes.
