#include <iostream>
#include <cassert>
#include <stdexcept>
#include <cstdint>
#include <cstddef>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
    std::cout << "test_constructor_with_size passed\n";
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    a[0] = 99;
    assert(b[0] == 10);
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 10);
    a[0] = 99;
    assert(b[0] == 10);
    std::cout << "test_copy_assignment passed\n";
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(a.size() == 0);
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(3);
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(a.size() == 0);
    std::cout << "test_move_assignment passed\n";
}

void test_move_from_reusable() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    a.resize(3);
    assert(a.size() == 3);
    a[0] = 42;
    assert(a[0] == 42);
    std::cout << "test_move_from_reusable passed\n";
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 10;
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 10);
    std::cout << "test_self_copy passed\n";
}

void test_self_move() {
    Buffer a(5);
    a[0] = 10;
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 10);
    std::cout << "test_self_move passed\n";
}

void test_bounds_check_mutable() {
    Buffer a(5);
    try {
        (void)a[5];
        assert(false);
    } catch (const std::out_of_range&) {
        // expected
    }
    std::cout << "test_bounds_check_mutable passed\n";
}

void test_bounds_check_const() {
    const Buffer a(5);
    try {
        (void)a[5];
        assert(false);
    } catch (const std::out_of_range&) {
        // expected
    }
    std::cout << "test_bounds_check_const passed\n";
}

void test_resize_expand() {
    Buffer a(3);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 0);
    assert(a[4] == 0);
    std::cout << "test_resize_expand passed\n";
}

void test_resize_shrink() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    std::cout << "test_resize_shrink passed\n";
}

void test_resize_same_size() {
    Buffer a(5);
    a[0] = 1;
    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1);
    std::cout << "test_resize_same_size passed\n";
}

void test_resize_zero() {
    Buffer a(5);
    a[0] = 1;
    a.resize(0);
    assert(a.size() == 0);
    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 0);
    std::cout << "test_resize_zero passed\n";
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
    std::cout << "test_noexcept_move passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_move_from_reusable();
    test_self_copy();
    test_self_move();
    test_bounds_check_mutable();
    test_bounds_check_const();
    test_resize_expand();
    test_resize_shrink();
    test_resize_same_size();
    test_resize_zero();
    test_noexcept_move();
    std::cout << "All tests passed!\n";
    return 0;
}
