# Buffer Library

A C++20 RAII-based buffer class with deep-copy semantics, move support, and bounds checking.

## Features

- `Buffer(size_t n=0)`: Construct buffer of given size, zero-initialized
- `size() const noexcept`: Return current buffer size
- `operator[](size_t)`: Mutable and const access with bounds checking (throws `std::out_of_range`)
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction and assignment
- Noexcept move construction and assignment
- Self-assignment and self-move preserve content
- RAII: no leaks, no double frees, no stale reads

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // 10 zero-initialized bytes
b[0] = 42;              // modify first byte
Buffer c = b;           // deep copy
Buffer d = std::move(c); // move (c is now empty and reusable)
b.resize(20);           // grow, new bytes zero-initialized
```

## Testing

Run the test suite with `run_tests`. The driver compiles with Clang 22, C++20, `-fuse-ld=bfd`.
