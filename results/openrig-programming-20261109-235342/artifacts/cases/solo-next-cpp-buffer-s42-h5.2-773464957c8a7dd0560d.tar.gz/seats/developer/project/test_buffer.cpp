#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"
#include <cassert>

void test_default_construct() {
    Buffer b;
    assert(b.size() == 0);
}

void test_construct_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }
}

void test_construct_with_values() {
    Buffer b(5);
    for (std::size_t i = 0; i < 5; ++i) {
        b[i] = static_cast<std::uint8_t>(i + 1);
    }
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i + 1));
    }
}

void test_copy_construct() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    Buffer b(a);
    assert(b.size() == 3);
    assert(b[0] == 10); assert(b[1] == 20); assert(b[2] == 30);
    b[0] = 99;
    assert(a[0] == 10);
}

void test_move_construct() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    assert(b.size() == 3);
    assert(b[0] == 10); assert(b[1] == 20); assert(b[2] == 30);
}

void test_copy_assign() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    Buffer b;
    b = a;
    assert(b.size() == 3);
    assert(b[0] == 10); assert(b[1] == 20); assert(b[2] == 30);
    b[0] = 99;
    assert(a[0] == 10);
}

void test_move_assign() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    Buffer b;
    b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 3);
    assert(b[0] == 10); assert(b[1] == 20); assert(b[2] == 30);
}

void test_self_copy() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    a = a;
    assert(a.size() == 3);
    assert(a[0] == 10); assert(a[1] == 20); assert(a[2] == 30);
}

void test_self_move() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    a = std::move(a);
    assert(a.size() == 3);
    assert(a[0] == 10); assert(a[1] == 20); assert(a[2] == 30);
}

void test_bounds_check() {
    Buffer b(5);
    try {
        (void)b[5];
        assert(false);
    } catch (const std::out_of_range&) {
    }
}

void test_const_bounds_check() {
    const Buffer b(5);
    try {
        (void)b[5];
        assert(false);
    } catch (const std::out_of_range&) {
    }
}

void test_resize_grow() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    a.resize(6);
    assert(a.size() == 6);
    assert(a[0] == 10); assert(a[1] == 20); assert(a[2] == 30);
    assert(a[3] == 0); assert(a[4] == 0); assert(a[5] == 0);
}

void test_resize_shrink() {
    Buffer a(6);
    a[0] = 10; a[1] = 20; a[2] = 30; a[3] = 40; a[4] = 50; a[5] = 60;
    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 10); assert(a[1] == 20); assert(a[2] == 30);
}

void test_resize_to_zero() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    a.resize(0);
    assert(a.size() == 0);
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

void test_deep_copy_independence() {
    Buffer a(4);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4;
    Buffer b = a;
    Buffer c = std::move(b);
    c[0] = 99;
    assert(a[0] == 1);
    assert(c[0] == 99);
}

void test_reuse_moved_from() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    Buffer b = std::move(a);
    assert(a.size() == 0);
    a = Buffer(2);
    a[0] = 5; a[1] = 6;
    assert(a.size() == 2);
    assert(a[0] == 5); assert(a[1] == 6);
}

void test_large_buffer() {
    Buffer b(1000);
    assert(b.size() == 1000);
    for (std::size_t i = 0; i < 1000; ++i) {
        b[i] = static_cast<std::uint8_t>(i & 0xFF);
    }
    for (std::size_t i = 0; i < 1000; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i & 0xFF));
    }
}

void test_empty_buffer_operations() {
    Buffer a;
    Buffer b = a;
    Buffer c = std::move(a);
    assert(b.size() == 0);
    assert(c.size() == 0);
    b.resize(5);
    assert(b.size() == 5);
}

void run_all_tests() {
    test_default_construct();
    test_construct_size();
    test_construct_with_values();
    test_copy_construct();
    test_move_construct();
    test_copy_assign();
    test_move_assign();
    test_self_copy();
    test_self_move();
    test_bounds_check();
    test_const_bounds_check();
    test_resize_grow();
    test_resize_shrink();
    test_resize_to_zero();
    test_noexcept_move();
    test_deep_copy_independence();
    test_reuse_moved_from();
    test_large_buffer();
    test_empty_buffer_operations();
    std::cout << "All tests passed!" << std::endl;
}

int main() {
    run_all_tests();
    return 0;
}
