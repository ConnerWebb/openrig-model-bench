# Binary Record Encoder/Decoder

Implements `encode` and `decode` functions for a binary format with:
- Magic bytes: `OGC1\n`
- Little-endian uint32 count
- For each record: uint32 id, uint16 name length, raw name bytes, int64 value

Validates: count <= 10000, name length <= 1024, unique IDs, no trailing bytes.
