#include "solution.hpp"
#include <vector>
#include <string>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <unordered_set>
#include <algorithm>

void test_roundtrip() {
    std::vector<Record> records = {
        {0, "test", 12345},
        {1, "日本語", -67890}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    if (decoded.size() != records.size()) throw std::runtime_error("size mismatch");
    for (size_t i = 0; i < records.size(); ++i) {
        if (decoded[i].id != records[i].id) throw std::runtime_error("id mismatch");
        if (decoded[i].name != records[i].name) throw std::runtime_error("name mismatch");
        if (decoded[i].value != records[i].value) throw std::runtime_error("value mismatch");
    }
}

void test_empty() {
    std::vector<Record> records;
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    if (decoded.size() != 0) throw std::runtime_error("empty size mismatch");
}

void test_magic() {
    std::vector<uint8_t> bad = {0x4f, 0x47, 0x43, 0x32, 0x0a};
    try {
        decode(bad);
        throw std::runtime_error("should reject bad magic");
    } catch (const std::runtime_error&) {}
}

void test_truncated() {
    std::vector<uint8_t> bad = {0x4f, 0x47, 0x43, 0x31, 0x0a, 0x01};
    try {
        decode(bad);
        throw std::runtime_error("should reject truncated");
    } catch (const std::runtime_error&) {}
}

void test_duplicate_id() {
    std::vector<Record> records = {{1, "a", 1}, {1, "b", 2}};
    try {
        encode(records);
        throw std::runtime_error("should reject duplicate id");
    } catch (const std::runtime_error&) {}
}

void test_name_too_long() {
    std::vector<Record> records = {{1, std::string(1025, 'a'), 1}};
    try {
        encode(records);
        throw std::runtime_error("should reject long name");
    } catch (const std::runtime_error&) {}
}

void test_count_too_large() {
    std::vector<Record> records(10001, {1, "a", 1});
    try {
        encode(records);
        throw std::runtime_error("should reject count > 10000");
    } catch (const std::runtime_error&) {}
}

void test_trailing_bytes() {
    std::vector<uint8_t> data = {0x4f, 0x47, 0x43, 0x31, 0x0a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01};
    try {
        decode(data);
        throw std::runtime_error("should reject trailing bytes");
    } catch (const std::runtime_error&) {}
}

std::vector<uint8_t> hex_decode(const std::string& hex) {
    std::vector<uint8_t> data;
    for (size_t i = 0; i < hex.size(); i += 2) {
        data.push_back((std::stoul(hex.substr(i, 2), nullptr, 16)));
    }
    return data;
}

std::string strip_quotes(const std::string& s) {
    if (s.size() >= 2 && s.front() == '"' && s.back() == '"') {
        return s.substr(1, s.size() - 2);
    }
    return s;
}

std::string unescape_json_string(const std::string& s) {
    std::string result;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '\\' && i + 1 < s.size()) {
            char next = s[i+1];
            if (next == '"') { result += '"'; ++i; }
            else if (next == '\\') { result += '\\'; ++i; }
            else if (next == 'n') { result += '\n'; ++i; }
            else if (next == 'r') { result += '\r'; ++i; }
            else if (next == 't') { result += '\t'; ++i; }
            else if (next == 'u' && i + 5 < s.size()) {
                result += (char)std::stoul(s.substr(i+2, 4), nullptr, 16);
                i += 5;
            } else {
                result += next;
                ++i;
            }
        } else {
            result += s[i];
        }
    }
    return result;
}

void test_case(const std::string& path) {
    std::ifstream t(path);
    std::stringstream buffer;
    buffer << t.rdbuf();
    std::string input = buffer.str();
    input = strip_quotes(input);
    // Convert \" to " for std::quoted to work
    for (size_t i = 0; i + 1 < input.size(); ++i) {
        if (input[i] == '\\' && input[i+1] == '"') {
            input[i] = '"';
            input.erase(i+1, 1);
        }
    }
    std::istringstream iss(input);
    int mode;
    iss >> mode;
    if (mode == 0) {
        int n;
        iss >> n;
        std::vector<Record> records;
        for (int i = 0; i < n; ++i) {
            Record r;
            iss >> r.id;
            iss >> std::quoted(r.name);
            iss >> r.value;
            std::cerr << "Record " << i << ": id=" << r.id << " name=" << r.name << " value=" << r.value << std::endl;
            records.push_back(r);
        }
        auto encoded = encode(records);
        std::ostringstream hex;
        hex << std::hex << std::setfill('0');
        for (auto b : encoded) hex << std::setw(2) << (int)b;
        auto decoded = decode(encoded);
        if (decoded.size() != records.size()) throw std::runtime_error("decoded size mismatch");
        for (size_t i = 0; i < records.size(); ++i) {
            if (decoded[i].id != records[i].id) throw std::runtime_error("decoded id mismatch");
            if (decoded[i].name != records[i].name) throw std::runtime_error("decoded name mismatch");
            if (decoded[i].value != records[i].value) throw std::runtime_error("decoded value mismatch");
        }
    } else {
        std::string hex;
        iss >> hex;
        auto data = hex_decode(hex);
        auto decoded = decode(data);
        auto reencoded = encode(decoded);
        if (reencoded.size() != data.size()) throw std::runtime_error("reencoded size mismatch");
        for (size_t i = 0; i < data.size(); ++i) {
            if (reencoded[i] != data[i]) throw std::runtime_error("reencoded byte mismatch");
        }
    }
}

int main() {
    try {
        test_roundtrip();
        test_empty();
        test_magic();
        test_truncated();
        test_duplicate_id();
        test_name_too_long();
        test_count_too_large();
        test_trailing_bytes();
        test_case("public-inputs/case-00.json");
        test_case("public-inputs/case-01.json");
        test_case("public-inputs/case-02.json");
        test_case("public-inputs/case-03.json");
        test_case("public-inputs/case-04.json");
        test_case("public-inputs/case-05.json");
        test_case("public-inputs/case-06.json");
        test_case("public-inputs/case-07.json");
        test_case("public-inputs/case-08.json");
        test_case("public-inputs/case-09.json");
        test_case("public-inputs/case-10.json");
        test_case("public-inputs/case-11.json");
        test_case("public-inputs/case-12.json");
        test_case("public-inputs/case-13.json");
        test_case("public-inputs/case-14.json");
        std::cout << "All tests passed" << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
