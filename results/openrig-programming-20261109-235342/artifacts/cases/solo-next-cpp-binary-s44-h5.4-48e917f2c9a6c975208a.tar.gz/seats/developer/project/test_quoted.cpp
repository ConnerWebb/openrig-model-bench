#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

int main() {
    std::string input = "0 10 0 \\\"0\\\" 68856894251056856 1 \\\"b c0\\\" -233957124999232821";
    std::istringstream iss(input);
    int mode;
    iss >> mode;
    std::cout << "mode=" << mode << std::endl;
    int n;
    iss >> n;
    std::cout << "n=" << n << std::endl;
    for (int i = 0; i < n; ++i) {
        Record r;
        iss >> r.id;
        std::cout << "id=" << r.id << std::endl;
        iss >> std::quoted(r.name);
        std::cout << "name=" << r.name << std::endl;
        iss >> r.value;
        std::cout << "value=" << r.value << std::endl;
    }
    return 0;
}
