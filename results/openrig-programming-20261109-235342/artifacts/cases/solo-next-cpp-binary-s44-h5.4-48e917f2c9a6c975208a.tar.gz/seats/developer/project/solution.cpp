#include "solution.hpp"
#include <unordered_set>

std::vector<uint8_t> encode(const std::vector<Record>& records) {
    if (records.size() > 10000) {
        throw std::runtime_error("count exceeds 10000");
    }
    
    std::unordered_set<uint32_t> seen_ids;
    for (const auto& r : records) {
        if (seen_ids.count(r.id)) {
            throw std::runtime_error("duplicate id");
        }
        seen_ids.insert(r.id);
        if (r.name.size() > 1024) {
            throw std::runtime_error("name too long");
        }
    }
    
    std::vector<uint8_t> result;
    result.push_back('O');
    result.push_back('G');
    result.push_back('C');
    result.push_back('1');
    result.push_back('\n');
    
    uint32_t count = static_cast<uint32_t>(records.size());
    result.push_back(count & 0xFF);
    result.push_back((count >> 8) & 0xFF);
    result.push_back((count >> 16) & 0xFF);
    result.push_back((count >> 24) & 0xFF);
    
    for (const auto& r : records) {
        uint32_t id = r.id;
        result.push_back(id & 0xFF);
        result.push_back((id >> 8) & 0xFF);
        result.push_back((id >> 16) & 0xFF);
        result.push_back((id >> 24) & 0xFF);
        
        uint16_t name_len = static_cast<uint16_t>(r.name.size());
        result.push_back(name_len & 0xFF);
        result.push_back((name_len >> 8) & 0xFF);
        
        for (char c : r.name) {
            result.push_back(static_cast<uint8_t>(c));
        }
        
        int64_t val = r.value;
        result.push_back(val & 0xFF);
        result.push_back((val >> 8) & 0xFF);
        result.push_back((val >> 16) & 0xFF);
        result.push_back((val >> 24) & 0xFF);
        result.push_back((val >> 32) & 0xFF);
        result.push_back((val >> 40) & 0xFF);
        result.push_back((val >> 48) & 0xFF);
        result.push_back((val >> 56) & 0xFF);
    }
    
    return result;
}

std::vector<Record> decode(std::span<const uint8_t> data) {
    if (data.size() < 5) {
        throw std::runtime_error("truncated data");
    }
    
    if (data[0] != 'O' || data[1] != 'G' || data[2] != 'C' || data[3] != '1' || data[4] != '\n') {
        throw std::runtime_error("bad magic");
    }
    
    if (data.size() < 9) {
        throw std::runtime_error("truncated count");
    }
    
    uint32_t count = static_cast<uint32_t>(data[5]) |
                     (static_cast<uint32_t>(data[6]) << 8) |
                     (static_cast<uint32_t>(data[7]) << 16) |
                     (static_cast<uint32_t>(data[8]) << 24);
    
    if (count > 10000) {
        throw std::runtime_error("count exceeds 10000");
    }
    
    std::vector<Record> records;
    records.reserve(count);
    
    std::unordered_set<uint32_t> seen_ids;
    size_t pos = 9;
    
    for (uint32_t i = 0; i < count; ++i) {
        if (pos + 4 > data.size()) {
            throw std::runtime_error("truncated id");
        }
        
        uint32_t id = static_cast<uint32_t>(data[pos]) |
                      (static_cast<uint32_t>(data[pos+1]) << 8) |
                      (static_cast<uint32_t>(data[pos+2]) << 16) |
                      (static_cast<uint32_t>(data[pos+3]) << 24);
        pos += 4;
        
        if (seen_ids.count(id)) {
            throw std::runtime_error("duplicate id");
        }
        seen_ids.insert(id);
        
        if (pos + 2 > data.size()) {
            throw std::runtime_error("truncated name length");
        }
        
        uint16_t name_len = static_cast<uint16_t>(data[pos]) |
                            (static_cast<uint16_t>(data[pos+1]) << 8);
        pos += 2;
        
        if (name_len > 1024) {
            throw std::runtime_error("name too long");
        }
        
        if (pos + name_len > data.size()) {
            throw std::runtime_error("truncated name");
        }
        
        std::string name;
        name.reserve(name_len);
        for (uint16_t j = 0; j < name_len; ++j) {
            name.push_back(static_cast<char>(data[pos + j]));
        }
        pos += name_len;
        
        if (pos + 8 > data.size()) {
            throw std::runtime_error("truncated value");
        }
        
        int64_t value = static_cast<int64_t>(data[pos]) |
                        (static_cast<int64_t>(data[pos+1]) << 8) |
                        (static_cast<int64_t>(data[pos+2]) << 16) |
                        (static_cast<int64_t>(data[pos+3]) << 24) |
                        (static_cast<int64_t>(data[pos+4]) << 32) |
                        (static_cast<int64_t>(data[pos+5]) << 40) |
                        (static_cast<int64_t>(data[pos+6]) << 48) |
                        (static_cast<int64_t>(data[pos+7]) << 56);
        pos += 8;
        
        records.push_back({id, name, value});
    }
    
    if (pos != data.size()) {
        throw std::runtime_error("trailing bytes");
    }
    
    return records;
}
