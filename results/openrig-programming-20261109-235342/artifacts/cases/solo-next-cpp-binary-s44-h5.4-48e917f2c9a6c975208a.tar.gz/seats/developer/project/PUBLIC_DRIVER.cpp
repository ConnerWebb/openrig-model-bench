#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"
std::string js(const std::string&s){std::ostringstream o;o<<'"';for(unsigned char c:s){if(c=='"'||c=='\\')o<<'\\'<<c;else if(c=='\n')o<<"\\n";else if(c=='\r')o<<"\\r";else if(c=='\t')o<<"\\t";else if(c<32)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)c<<std::dec;else o<<c;}o<<'"';return o.str();}
int main(){try{
int mode;std::cin>>mode;std::vector<std::uint8_t> bytes;if(mode==0){int n;std::cin>>n;std::vector<Record> r;for(int i=0;i<n;i++){Record a;std::cin>>a.id>>std::quoted(a.name)>>a.value;r.push_back(a);}bytes=encode(r);}else{std::string h;std::cin>>h;for(std::size_t i=0;i<h.size();i+=2)bytes.push_back(std::stoul(h.substr(i,2),nullptr,16));}auto out=decode(bytes);std::cout<<"{\"value\":[";for(std::size_t i=0;i<out.size();i++){if(i)std::cout<<',';std::cout<<"["<<out[i].id<<','<<js(out[i].name)<<','<<out[i].value<<']';}std::cout<<"],\"hex\":\""<<std::hex<<std::setfill('0');for(auto v:bytes)std::cout<<std::setw(2)<<(int)v;std::cout<<"\"}";
}catch(const std::exception&e){std::cout<<"{\"error\":\"ValueError\"}";}catch(...){std::cout<<"{\"error\":\"ValueError\"}";}std::cout<<std::endl;}
