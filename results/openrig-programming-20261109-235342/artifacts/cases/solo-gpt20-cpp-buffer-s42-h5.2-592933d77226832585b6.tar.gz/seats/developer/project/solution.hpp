#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>
#include <stdexcept>

// Buffer is a simple dynamic byte buffer with bounds-checked access.
// It supports copy, move, resize and element access.
class Buffer {
public:
    // Default constructor creates empty buffer.
    Buffer(size_t n = 0) : data_(n, 0) {}

    // Copy constructor
    Buffer(const Buffer& other) : data_(other.data_) {}

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : data_(std::move(other.data_)) {
        // moved-from buffer should be empty and reusable
        other.data_.clear();
    }

    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            data_ = other.data_;
        }
        return *this;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            data_ = std::move(other.data_);
            other.data_.clear();
        }
        return *this;
    }

    // Size of buffer
    size_t size() const noexcept { return data_.size(); }

    // Mutable element access with bounds check
    uint8_t& operator[](size_t idx) {
        if (idx >= data_.size()) {
            throw std::out_of_range("Buffer index out of range");
        }
        return data_[idx];
    }

    // Const element access with bounds check
    const uint8_t& operator[](size_t idx) const {
        if (idx >= data_.size()) {
            throw std::out_of_range("Buffer index out of range");
        }
        return data_[idx];
    }

    // Resize buffer, preserving existing data and zero-initializing new bytes
    void resize(size_t new_size) {
        if (new_size > data_.size()) {
            data_.resize(new_size, 0);
        } else {
            data_.resize(new_size);
        }
    }

private:
    std::vector<uint8_t> data_;
};
