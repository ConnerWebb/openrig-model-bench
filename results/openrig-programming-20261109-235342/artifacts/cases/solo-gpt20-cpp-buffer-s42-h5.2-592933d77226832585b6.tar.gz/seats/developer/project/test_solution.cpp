#include "solution.hpp"
#include <cassert>
#include <iostream>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0u);
}

void test_size_constructor() {
    Buffer b(10);
    assert(b.size() == 10u);
    for (size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0u);
    }
}

void test_element_access() {
    Buffer b(5);
    b[2] = 42;
    assert(b[2] == 42u);
    bool threw = false;
    try { b[5]; } catch (const std::out_of_range&) { threw = true; }
    assert(threw);
}

void test_resize_preserve() {
    Buffer b(3);
    b[0] = 1; b[1] = 2; b[2] = 3;
    b.resize(5);
    assert(b.size() == 5u);
    assert(b[0] == 1u && b[1] == 2u && b[2] == 3u);
    assert(b[3] == 0u && b[4] == 0u);
    b.resize(2);
    assert(b.size() == 2u);
    assert(b[0] == 1u && b[1] == 2u);
}

void test_copy_constructor() {
    Buffer a(4);
    a[0] = 9; a[1] = 8; a[2] = 7; a[3] = 6;
    Buffer b(a);
    assert(b.size() == 4u);
    for (size_t i = 0; i < 4; ++i) assert(b[i] == a[i]);
}

void test_move_constructor() {
    Buffer a(3);
    a[0] = 5; a[1] = 4; a[2] = 3;
    Buffer b(std::move(a));
    assert(b.size() == 3u);
    assert(a.size() == 0u);
    assert(b[0] == 5u);
}

void test_copy_assignment() {
    Buffer a(2); a[0] = 1; a[1] = 2;
    Buffer b;
    b = a;
    assert(b.size() == 2u && b[0] == 1u && b[1] == 2u);
}

void test_move_assignment() {
    Buffer a(2); a[0] = 3; a[1] = 4;
    Buffer b;
    b = std::move(a);
    assert(b.size() == 2u && a.size() == 0u && b[0] == 3u);
}

void test_self_copy() {
    Buffer b(2); b[0] = 7; b[1] = 8;
    b = b;
    assert(b.size() == 2u && b[0] == 7u && b[1] == 8u);
}

void test_self_move() {
    Buffer b(2); b[0] = 9; b[1] = 10;
    b = std::move(b);
    assert(b.size() == 2u && b[0] == 9u && b[1] == 10u);
}

int main() {
    test_default_constructor();
    test_size_constructor();
    test_element_access();
    test_resize_preserve();
    test_copy_constructor();
    test_move_constructor();
    test_copy_assignment();
    test_move_assignment();
    test_self_copy();
    test_self_move();
    std::cout << "All tests passed.\n";
    return 0;
}
