# Buffer Library

This repository contains a minimal C++20 implementation of a dynamic byte buffer (`Buffer`).

## Features
- Dynamic resizing with zero‑initialization of new bytes.
- Bounds‑checked element access (`operator[]`).
- Copy and move semantics with `noexcept` move operations.
- Self‑copy and self‑move are safe and preserve content.
- Uses `std::vector<uint8_t>` internally for RAII and safety.

## Building and Testing
The tests use Google Test. Compile with:
```
clang++ -std=c++20 -I. -pthread test_solution.cpp -lgtest -lgtest_main -o test_solution
```
Run the tests:
```
./test_solution
```

## Usage
```cpp
#include "solution.hpp"

Buffer buf(10); // 10 zeroed bytes
buf[3] = 42;
buf.resize(20); // new bytes zeroed
```
