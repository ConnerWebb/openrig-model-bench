import csv
import decimal
from decimal import Decimal, InvalidOperation
from typing import Dict

def _validate_amount(s: str) -> Decimal:
    # Strip whitespace already done by caller
    # Regex-like validation: optional +, 1-12 digits, optional . with 1-2 digits
    # No exponent, no negative, no leading zeros restriction not needed
    if not s:
        raise ValueError('empty amount')
    if s[0] == '+':
        s = s[1:]
    # split decimal point
    parts = s.split('.')
    if len(parts) > 2:
        raise ValueError('multiple dots')
    int_part = parts[0]
    if not int_part.isdigit():
        raise ValueError('int part not digits')
    if len(int_part) > 12:
        raise ValueError('int part too long')
    if len(parts) == 2:
        frac = parts[1]
        if not (1 <= len(frac) <= 2) or not frac.isdigit():
            raise ValueError('fraction invalid')
    # Use Decimal for exact arithmetic
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise ValueError('invalid decimal')
    if d.is_nan() or d.is_infinite() or d < 0:
        raise ValueError('nonpositive or special')
    # enforce max 12 digits before decimal
    if d.adjusted() + 1 > 12:  # adjusted gives exponent of most significant digit
        raise ValueError('too many digits')
    return d

def aggregate(path: str) -> Dict[str, str]:
    """Read CSV file at *path* and return a dict mapping category to total amount.
    Totals are formatted as strings with exactly two decimal places.
    """
    totals: Dict[str, Decimal] = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError('empty file')
        if header != ['category', 'amount']:
            raise ValueError('invalid header')
        for row in reader:
            # Skip completely blank records (no fields)
            if not row:
                continue
            if len(row) != 2:
                raise ValueError('row length not 2')
            cat, amt = row[0].strip(), row[1].strip()
            if not cat:
                raise ValueError('empty category')
            dec = _validate_amount(amt)
            totals[cat] = totals.get(cat, Decimal('0')) + dec
    # format results sorted by key
    result = {k: f"{totals[k].quantize(Decimal('0.01')):.2f}" for k in sorted(totals)}
    return result
