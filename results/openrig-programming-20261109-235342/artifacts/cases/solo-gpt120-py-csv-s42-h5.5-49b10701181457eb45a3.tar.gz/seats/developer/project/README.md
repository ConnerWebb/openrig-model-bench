# CSV Category Aggregator

This repository implements a single function `aggregate(path: str) -> dict[str, str]` that reads a UTF‑8 CSV file containing two columns **category** and **amount**.

## Requirements
- The CSV header must be exactly `category,amount`.
- Blank rows are ignored.
- Each record must have exactly two fields.
- Whitespace around fields is stripped.
- `category` must be a non‑empty string.
- `amount` must be a non‑negative decimal with:
  - optional leading `+`
  - 1‑12 digits before an optional decimal point
  - optional 1‑2 digits after the decimal point
  - no exponent, no negative sign, no NaN/Infinity
- Invalid input raises `ValueError`.

## Behaviour
The function aggregates amounts per category using exact decimal arithmetic (`decimal.Decimal`).
Results are returned as a dictionary with keys sorted alphabetically and values formatted as strings with exactly two decimal places.

## Implementation notes
- Uses Python's `csv` module for proper handling of quoted fields, embedded commas and newlines.
- Validation of the amount is performed in `_validate_amount`.
- Totals are accumulated in a `Decimal` and finally quantized to two decimal places.

## Tests
`test_solution.py` contains unit tests that load the public cases from `PUBLIC_CASES.json` and verify both correct aggregation and proper error handling.

## Usage
```python
from solution import aggregate
result = aggregate('path/to/file.csv')
print(result)
```
