import unittest
import solution

from pathlib import Path

class TestAggregate(unittest.TestCase):
    def run_case(self, case_file: str, expect: dict):
        # load csv
        csv_path = Path('public-inputs') / case_file
        # invoke driver via python -c
        data = {"value": solution.aggregate(str(csv_path))}
        self.assertEqual(data, expect)

    def test_cases(self):
        # load PUBLIC_CASES.json
        import json
        cases = json.load(open('PUBLIC_CASES.json'))
        for i, case in enumerate(cases):
            with self.subTest(i=i):
                expected = case['expected']
                # driver expects either value or error
                if 'value' in expected:
                    self.run_case(Path(case['input_file']).name, {'value': expected['value']})
                else:
                    # expect error
                    csv_path = Path('public-inputs') / Path(case['input_file']).name
                    try:
                        solution.aggregate(str(csv_path))
                    except Exception as e:
                        self.assertEqual(type(e).__name__, expected['error'])
                    else:
                        self.fail('Expected exception')

if __name__ == '__main__':
    unittest.main()
