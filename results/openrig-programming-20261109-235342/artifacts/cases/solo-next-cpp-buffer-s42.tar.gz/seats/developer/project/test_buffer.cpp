#include "solution.hpp"
#include <cassert>
#include <iostream>
#include <stdexcept>

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
    std::cout << "test_default_constructor passed\n";
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    std::cout << "test_constructor_with_size passed\n";
}

void test_copy_constructor() {
    Buffer b1(5);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    
    Buffer b2(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    
    // Verify deep copy - modifying b1 doesn't affect b2
    b1[0] = 99;
    assert(b2[0] == 1);
    std::cout << "test_copy_constructor passed\n";
}

void test_copy_assignment() {
    Buffer b1(3);
    b1[0] = 10;
    b1[1] = 20;
    b1[2] = 30;
    
    Buffer b2;
    b2 = b1;
    
    assert(b2.size() == 3);
    assert(b2[0] == 10);
    assert(b2[1] == 20);
    assert(b2[2] == 30);
    
    // Verify deep copy
    b1[0] = 99;
    assert(b2[0] == 10);
    std::cout << "test_copy_assignment passed\n";
}

void test_self_copy() {
    Buffer b(4);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    
    b = b;
    
    assert(b.size() == 4);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 4);
    std::cout << "test_self_copy passed\n";
}

void test_move_constructor() {
    Buffer b1(5);
    b1[0] = 7;
    
    Buffer b2(std::move(b1));
    
    assert(b2.size() == 5);
    assert(b2[0] == 7);
    assert(b1.size() == 0);
    std::cout << "test_move_constructor passed\n";
}

void test_move_assignment() {
    Buffer b1(3);
    b1[0] = 5;
    
    Buffer b2;
    b2 = std::move(b1);
    
    assert(b2.size() == 3);
    assert(b2[0] == 5);
    assert(b1.size() == 0);
    std::cout << "test_move_assignment passed\n";
}

void test_self_move() {
    Buffer b(4);
    b[0] = 1;
    b[1] = 2;
    
    b = std::move(b);
    
    assert(b.size() == 4);
    assert(b[0] == 1);
    assert(b[1] == 2);
    std::cout << "test_self_move passed\n";
}

void test_move_reusability() {
    Buffer b1(5);
    b1[0] = 100;
    
    Buffer b2;
    b2 = std::move(b1);
    
    // Reuse moved-from buffer
    b1 = Buffer(3);
    b1[0] = 200;
    
    assert(b1.size() == 3);
    assert(b1[0] == 200);
    assert(b2.size() == 5);
    assert(b2[0] == 100);
    std::cout << "test_move_reusability passed\n";
}

void test_bounds_check() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    try {
        b[5];
        assert(false && "Should have thrown out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    try {
        b[3];
        assert(false && "Should have thrown out_of_range");
    } catch (const std::out_of_range&) {
        // Expected
    }
    std::cout << "test_bounds_check passed\n";
}

void test_const_operator_bracket() {
    const Buffer b(3);
    assert(b.size() == 3);
    assert(b[0] == 0);
    assert(b[1] == 0);
    assert(b[2] == 0);
    std::cout << "test_const_operator_bracket passed\n";
}

void test_resize_preserve() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    std::cout << "test_resize_preserve passed\n";
}

void test_resize_expand() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    b.resize(6);
    assert(b.size() == 6);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
    assert(b[5] == 0);
    std::cout << "test_resize_expand passed\n";
}

void test_resize_shrink() {
    Buffer b(6);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    b[5] = 6;
    
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    std::cout << "test_resize_shrink passed\n";
}

void test_resize_empty_to_nonempty() {
    Buffer b;
    b.resize(4);
    assert(b.size() == 4);
    assert(b[0] == 0);
    assert(b[1] == 0);
    assert(b[2] == 0);
    assert(b[3] == 0);
    std::cout << "test_resize_empty_to_nonempty passed\n";
}

void test_resize_nonempty_to_empty() {
    Buffer b(3);
    b[0] = 1;
    b.resize(0);
    assert(b.size() == 0);
    std::cout << "test_resize_nonempty_to_empty passed\n";
}

void test_resize_noop() {
    Buffer b(3);
    b[0] = 1;
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    std::cout << "test_resize_noop passed\n";
}

void test_noexcept_specifications() {
    Buffer b(1);
    const Buffer cb(1);
    
    // Test that these operations are noexcept
    static_assert(noexcept(Buffer()));
    static_assert(noexcept(Buffer(5)));
    static_assert(noexcept(Buffer(b)));
    static_assert(noexcept(Buffer(std::move(b))));
    static_assert(noexcept(cb.size()));
    static_assert(noexcept(b.resize(5)));
    std::cout << "test_noexcept_specifications passed\n";
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy();
    test_move_constructor();
    test_move_assignment();
    test_self_move();
    test_move_reusability();
    test_bounds_check();
    test_const_operator_bracket();
    test_resize_preserve();
    test_resize_expand();
    test_resize_shrink();
    test_resize_empty_to_nonempty();
    test_resize_nonempty_to_empty();
    test_resize_noop();
    test_noexcept_specifications();
    
    std::cout << "\nAll tests passed!\n";
    return 0;
}
