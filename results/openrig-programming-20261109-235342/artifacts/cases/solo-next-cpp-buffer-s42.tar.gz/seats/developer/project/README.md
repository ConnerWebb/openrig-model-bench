# Buffer Library

A C++20 RAII-based buffer class with deep-copy semantics, move support, and bounds checking.

## Features

- **RAII Memory Management**: Automatic memory allocation and deallocation
- **Deep Copy**: Copy constructor and assignment operator create independent copies
- **Move Semantics**: Efficient move construction and assignment with noexcept guarantees
- **Bounds Checking**: `operator[]` throws `std::out_of_range` for invalid indices
- **Const Support**: Both mutable and const versions of `operator[]`
- **Resize with Preservation**: `resize()` preserves existing data and zero-initializes new bytes

## Usage

```cpp
#include "solution.hpp"

// Create a buffer of size 10
Buffer buf(10);

// Access elements with bounds checking
buf[0] = 42;
std::uint8_t value = buf[5];

// Copy (deep copy)
Buffer copy = buf;

// Move
Buffer moved = std::move(buf);

// Resize (preserves prefix, zero-initializes new bytes)
buf.resize(20);
```

## API

### Constructors
- `Buffer(size_t n = 0)` - Default constructor, creates buffer of specified size
- `Buffer(const Buffer&)` - Copy constructor
- `Buffer(Buffer&&) noexcept` - Move constructor

### Assignment Operators
- `Buffer& operator=(const Buffer&)` - Copy assignment
- `Buffer& operator=(Buffer&&) noexcept` - Move assignment

### Destructor
- `~Buffer()` - Destructor, frees memory

### Methods
- `size_t size() const noexcept` - Returns buffer size
- `uint8_t& operator[](size_t i)` - Mutable element access (throws on bounds)
- `const uint8_t& operator[](size_t i) const` - Const element access (throws on bounds)
- `void resize(size_t new_size)` - Resizes buffer, preserving prefix

## Testing

Run the test suite with:

```bash
clang++ -std=c++20 -fuse-ld=bfd test_buffer.cpp -o test_buffer && ./test_buffer
```

## Requirements

- C++20 compatible compiler (tested with Clang 22)
- Standard library support
