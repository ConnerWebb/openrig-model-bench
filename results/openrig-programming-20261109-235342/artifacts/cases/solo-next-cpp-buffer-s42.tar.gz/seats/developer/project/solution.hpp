#pragma once
#include <cstdint>
#include <cstddef>
#include <algorithm>
#include <stdexcept>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Default constructor
    Buffer(std::size_t size = 0) noexcept : p(size > 0 ? new std::uint8_t[size]() : nullptr), n(size) {}

    // Copy constructor
    Buffer(const Buffer& other) noexcept : p(other.n > 0 ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (p && other.p) {
            std::copy(other.p, other.p + n, p);
        }
    }

    // Move constructor
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            std::uint8_t* new_p = other.n > 0 ? new std::uint8_t[other.n] : nullptr;
            if (new_p && other.p) {
                std::copy(other.p, other.p + other.n, new_p);
            }
            delete[] p;
            p = new_p;
            n = other.n;
        }
        return *this;
    }

    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Destructor
    ~Buffer() { delete[] p; }

    // Size
    std::size_t size() const noexcept { return n; }

    // Mutable operator[]
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Const operator[]
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    // Resize preserving prefix and zero-initializing new bytes
    void resize(std::size_t new_size) noexcept {
        if (new_size == n) return;
        
        std::uint8_t* new_p = new_size > 0 ? new std::uint8_t[new_size] : nullptr;
        
        // Copy existing elements (preserving prefix)
        std::size_t copy_size = std::min(n, new_size);
        if (new_p && p && copy_size > 0) {
            std::copy(p, p + copy_size, new_p);
        }
        
        // Zero-initialize new bytes
        if (new_p && new_size > n) {
            std::fill(new_p + n, new_p + new_size, 0);
        }
        
        delete[] p;
        p = new_p;
        n = new_size;
    }
};
