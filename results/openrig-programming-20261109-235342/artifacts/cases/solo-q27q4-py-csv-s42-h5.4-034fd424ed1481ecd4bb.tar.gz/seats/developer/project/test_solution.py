import json
import pathlib
import tempfile
import unittest

import solution


def _run(csv_text: str):
    with tempfile.TemporaryDirectory() as directory:
        path = pathlib.Path(directory) / "input.csv"
        path.write_text(csv_text, encoding="utf-8")
        return solution.aggregate(str(path))


class AggregateTests(unittest.TestCase):
    def test_public_cases(self):
        cases = json.loads(pathlib.Path("PUBLIC_CASES.json").read_text(encoding="utf-8"))
        for index, case in enumerate(cases):
            with self.subTest(case=index):
                if "error" in case["expected"]:
                    expected = ValueError
                    with self.assertRaises(expected):
                        _run(case["driver_input"]["csv"])
                else:
                    self.assertEqual(_run(case["driver_input"]["csv"]), case["expected"]["value"])

    def test_blank_records_ignored(self):
        self.assertEqual(_run("category,amount\n\nx,1.50\n\n"), {"x": "1.50"})

    def test_optional_plus_and_integers(self):
        self.assertEqual(_run("category,amount\na,+5\nb,0\nc,123456789012\n"),
                         {"a": "5.00", "b": "0.00", "c": "123456789012.00"})

    def test_exact_decimal_accumulation(self):
        self.assertEqual(_run("category,amount\nx,0.1\nx,0.2\n"), {"x": "0.30"})

    def test_rejects_bad_amounts(self):
        for bad in ["x,1.001\n", "x,1e2\n", "x,-1\n", "x,NaN\n", "x,+\n", "x,1234567890123\n", "x,.5\n", "x,5.\n"]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    _run(f"category,amount\n{bad}")

    def test_rejects_bad_structure(self):
        for bad in ["wrong,amount\nx,1\n", "category,amount\nx,1,2\n", "category,amount\n,1\n", "category,amount\n\"x,1\n", "category,amount\nx\n"]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    _run(bad)

    def test_empty_file_rejected(self):
        with self.assertRaises(ValueError):
            _run("")


if __name__ == "__main__":
    unittest.main()
