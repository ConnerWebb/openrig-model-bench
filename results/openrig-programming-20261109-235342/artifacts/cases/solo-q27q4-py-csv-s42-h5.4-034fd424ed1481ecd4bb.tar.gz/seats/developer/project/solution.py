"""Aggregate a category,amount CSV stream into exact decimal totals."""

import csv
import re
from decimal import Decimal

_AMOUNT_RE = re.compile(r"^[+]?[0-9]{1,12}(\.[0-9]{1,2})?$")


def _parse_amount(raw: str) -> Decimal:
    text = raw.strip()
    if not _AMOUNT_RE.match(text):
        raise ValueError(f"malformed amount: {raw!r}")
    return Decimal(text)


def aggregate(path: str) -> dict[str, str]:
    totals: dict[str, Decimal] = {}
    with open(path, "r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, None)
        if header is None or [field.strip() for field in header] != ["category", "amount"]:
            raise ValueError("header must be exactly category,amount")
        for record in reader:
            if not record:
                continue
            if len(record) != 2:
                raise ValueError(f"record must have exactly two fields: {record!r}")
            category = record[0].strip()
            if not category:
                raise ValueError("category must not be empty")
            totals[category] = totals.get(category, Decimal(0)) + _parse_amount(record[1])
    return {key: f"{totals[key]:.2f}" for key in sorted(totals)}
