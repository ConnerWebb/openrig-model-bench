# CSV category aggregator

`solution.aggregate(path)` reads a UTF-8 CSV file as a stream and returns a
dict mapping each category to its total amount formatted with exactly two
decimal places, with keys sorted.

## Contract

- The header must be exactly `category,amount` (fields compared after
  stripping surrounding whitespace).
- Completely blank records are ignored; every other record must have exactly
  two fields.
- Category and amount are stripped of surrounding whitespace; category must
  be non-empty.
- Amount: optional `+`, 1–12 decimal digits, optional `.` followed by 1 or 2
  digits. Nonnegative, finite, no exponent. Anything else raises `ValueError`.
- Quoted commas and embedded newlines are valid CSV and are supported.
- Totals use exact `decimal.Decimal` arithmetic; results are formatted with
  two decimal places.
- Any malformed input (bad header, wrong field count, empty category, bad
  amount, unterminated quote) raises `ValueError`.
- The file is consumed line-by-line via `csv.reader`; it is never read into
  memory just to parse it.

## Tests

`test_solution.py` covers all public cases in `PUBLIC_CASES.json` plus
edge cases (blank records, `+` prefix, 12-digit integers, exact decimal
accumulation, malformed amounts and structure, empty file).

Run with: `python3 -m unittest test_solution -v`
