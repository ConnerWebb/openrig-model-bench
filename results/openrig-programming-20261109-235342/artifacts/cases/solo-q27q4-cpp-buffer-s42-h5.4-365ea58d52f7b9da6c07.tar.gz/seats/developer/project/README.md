# Buffer

A small C++20 byte buffer (`Buffer`) implemented in `solution.hpp`.

## API

- `Buffer(std::size_t n = 0)` — constructs a buffer of `n` zero-initialized `uint8_t` bytes.
- `std::size_t size() const noexcept` — number of bytes.
- `uint8_t& operator[](std::size_t i)` / `const uint8_t& operator[](std::size_t i) const` —
  element access; throws `std::out_of_range` when `i >= size()`.
- `void resize(std::size_t k)` — resizes to `k` bytes, preserving the prefix and
  zero-initializing any new bytes.
- Deep-copy construction and copy assignment (independent storage).
- `noexcept` move construction and move assignment; moved-from buffers have size 0
  and are reusable. Self-copy and self-move preserve content.

## Implementation

Backed by `std::vector<std::uint8_t>` (RAII, no manual `new`/`delete`, no leaks or
double frees). Move operations are the default `noexcept` ones.

## Tests

`test_buffer.cpp` is a standalone C++ test (plain `assert`-based, `main` returns 0 on
success). Build and run:

```
clang++ -std=c++20 -O1 -fsanitize=address,undefined test_buffer.cpp -o /tmp/test_buffer
/tmp/test_buffer
```
