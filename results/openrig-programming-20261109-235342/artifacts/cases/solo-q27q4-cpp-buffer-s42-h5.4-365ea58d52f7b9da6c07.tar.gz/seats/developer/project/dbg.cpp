#include "solution.hpp"
#include <cstdio>
int main(){
    Buffer a(4);
    a[0]=10; a[3]=20;
    Buffer b = std::move(a);
    std::printf("after move a.size=%zu b.size=%zu\n", a.size(), b.size());
    a[0]=5;
    std::printf("a.size=%zu a[0]=%d\n", a.size(), (int)a[0]);
    return 0;
}
