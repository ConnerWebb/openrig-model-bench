#include "solution.hpp"
#include <cassert>
#include <cstdint>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

static void test_default_and_sized() {
    Buffer a;
    assert(a.size() == 0);
    Buffer b(5);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) assert(b[i] == 0);
}

static void test_bounds() {
    Buffer b(3);
    b[0] = 1; b[2] = 2;
    bool threw = false;
    try { (void)b[3]; } catch (const std::out_of_range&) { threw = true; }
    assert(threw);
    const Buffer& cb = b;
    threw = false;
    try { (void)cb[3]; } catch (const std::out_of_range&) { threw = true; }
    assert(threw);
    assert(cb[1] == 0);
}

static void test_resize() {
    Buffer b(4);
    b[0] = 9; b[3] = 7;
    b.resize(8);
    assert(b.size() == 8);
    assert(b[0] == 9 && b[3] == 7);
    for (std::size_t i = 4; i < 8; ++i) assert(b[i] == 0);
    b.resize(2);
    assert(b.size() == 2 && b[0] == 9);
    b.resize(0);
    assert(b.size() == 0);
}

static void test_copy() {
    Buffer a(3);
    a[0] = 1; a[1] = 2; a[2] = 3;
    Buffer b = a;
    b[0] = 255;
    assert(a[0] == 1);
    a = a; // self-copy
    assert(a[0] == 1 && a[2] == 3);
    Buffer c;
    c = a;
    assert(c.size() == 3 && c[2] == 3);
}

static void test_move() {
    Buffer a(4);
    a[0] = 10; a[3] = 20;
    Buffer b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 4 && b[0] == 10 && b[3] == 20);
    a[0] = 5; // reusable
    assert(a.size() == 1 && a[0] == 5);
    Buffer c(2);
    c[1] = 42;
    Buffer d = std::move(c);
    assert(c.size() == 0);
    assert(d.size() == 2 && d[1] == 42);
}

static void test_noexcept_traits() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

int main() {
    test_default_and_sized();
    test_bounds();
    test_resize();
    test_copy();
    test_move();
    test_noexcept_traits();
    return 0;
}
