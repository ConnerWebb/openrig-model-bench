#include <iostream>
#include <cassert>
#include <stdexcept>
#include <cstdint>
#include <cstddef>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
}

void test_mutable_operator() {
    Buffer b(5);
    b[0] = 10;
    b[1] = 20;
    b[2] = 30;
    assert(b[0] == 10);
    assert(b[1] == 20);
    assert(b[2] == 30);
}

void test_const_operator() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    const Buffer& cb = b;
    assert(cb[0] == 1);
    assert(cb[1] == 2);
    assert(cb[2] == 3);
}

void test_bounds_check() {
    Buffer b(5);
    bool caught = false;
    try {
        (void)b[5];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    
    caught = false;
    try {
        const Buffer& cb = b;
        (void)cb[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    
    // Modify original, copy should be unchanged
    a[0] = 99;
    assert(b[0] == 1);
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    
    Buffer b(3);
    b = a;
    
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    
    // Modify original, copy should be unchanged
    a[0] = 99;
    assert(b[0] == 1);
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    
    a = a;
    
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    
    Buffer b(std::move(a));
    
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(a.size() == 0);
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    
    Buffer b(3);
    b = std::move(a);
    
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(a.size() == 0);
}

void test_self_move() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    
    a = std::move(a);
    
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
}

void test_moved_from_reusable() {
    Buffer a(5);
    a[0] = 1;
    
    Buffer b(std::move(a));
    
    // a should be reusable
    a.resize(3);
    assert(a.size() == 3);
    a[0] = 10;
    a[1] = 20;
    a[2] = 30;
    assert(a[0] == 10);
}

void test_resize_larger() {
    Buffer a(3);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    
    a.resize(5);
    
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
    assert(a[3] == 0);
    assert(a[4] == 0);
}

void test_resize_smaller() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;
    
    a.resize(3);
    
    assert(a.size() == 3);
    assert(a[0] == 1);
    assert(a[1] == 2);
    assert(a[2] == 3);
}

void test_resize_same() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    
    a.resize(5);
    
    assert(a.size() == 5);
    assert(a[0] == 1);
    assert(a[1] == 2);
}

void test_resize_zero() {
    Buffer a(5);
    a[0] = 1;
    
    a.resize(0);
    
    assert(a.size() == 0);
    
    // Should be reusable
    a.resize(3);
    assert(a.size() == 3);
    assert(a[0] == 0);
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>, "Move constructor should be noexcept");
    static_assert(std::is_nothrow_move_assignable_v<Buffer>, "Move assignment should be noexcept");
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_mutable_operator();
    test_const_operator();
    test_bounds_check();
    test_copy_constructor();
    test_copy_assignment();
    test_self_copy();
    test_move_constructor();
    test_move_assignment();
    test_self_move();
    test_moved_from_reusable();
    test_resize_larger();
    test_resize_smaller();
    test_resize_same();
    test_resize_zero();
    test_noexcept_move();
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
