# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep copy construction/assignment**: Copies are independent of the original
- **Noexcept move operations**: Move construction and assignment are noexcept; moved-from buffers have size 0 and are reusable
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Resize with preservation**: `resize()` preserves existing prefix and zero-initializes new elements
- **RAII**: Automatic resource management with no memory leaks

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized.

### Destructor
```cpp
~Buffer();
```
Frees the underlying memory.

### Copy Operations
```cpp
Buffer(const Buffer& other);
Buffer& operator=(const Buffer& other);
```
Deep copy: the new buffer owns its own memory.

### Move Operations
```cpp
Buffer(Buffer&& other) noexcept;
Buffer& operator=(Buffer&& other) noexcept;
```
Transfer ownership. The moved-from buffer has `size() == 0` and is reusable.

### Accessors
```cpp
std::size_t size() const noexcept;
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
`size()` returns the buffer size. `operator[]` throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resizes the buffer to `k` bytes. Existing prefix is preserved; new bytes are zero-initialized.

## Example

```cpp
Buffer a(5);
a[0] = 1;
a[1] = 2;

Buffer b(a);  // Deep copy
b[0] = 99;    // Does not affect a

Buffer c = std::move(a);  // Move, a.size() == 0
a.resize(3);  // a is reusable
```

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

## Testing

Run `run_tests` to execute all public checks.
