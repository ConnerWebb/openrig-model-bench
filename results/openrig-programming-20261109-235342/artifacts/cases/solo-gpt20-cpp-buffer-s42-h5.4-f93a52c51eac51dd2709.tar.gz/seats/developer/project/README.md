# Buffer Library

This repository implements a simple `Buffer` class in C++20 that stores a dynamic array of `uint8_t` values. The implementation uses `std::vector<uint8_t>` internally and provides a minimal API required by the assignment.

## Features
- Default and size constructors.
- `size()` returns current number of elements.
- Mutable and const `operator[]` with bounds checking (throws `std::out_of_range`).
- `resize(size_t)` preserves existing data, zero‑initializes new elements, and truncates when shrinking.
- Deep copy construction and assignment.
- Move construction and assignment are `noexcept` and leave the moved‑from buffer empty.
- Self‑copy and self‑move operations are safe.

## Build & Test
The tests use Google Test. Compile with:
```
clang++ -std=c++20 -I. -pthread test_solution.cpp -lgtest -lgtest_main -o test_solution
```
Run the tests:
```
./test_solution
```

The repository also contains a `run_tests` script that will be invoked by the evaluation harness.
