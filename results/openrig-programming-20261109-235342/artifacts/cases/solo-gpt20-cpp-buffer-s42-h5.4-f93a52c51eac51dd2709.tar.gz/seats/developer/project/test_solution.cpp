#include "solution.hpp"
#include <cassert>
#include <iostream>

void test_default_constructor(){
    Buffer b; assert(b.size()==0u);
}

void test_size_constructor(){
    Buffer b(10); assert(b.size()==10u); for(size_t i=0;i<10;++i) assert(b[i]==0u);
}

void test_bounds(){
    Buffer b(5); bool caught=false; try{b[5];}catch(const std::out_of_range&){caught=true;} assert(caught);
}

void test_resize_increase(){
    Buffer b(3); b[0]=1;b[1]=2;b[2]=3; b.resize(6); assert(b.size()==6u); assert(b[0]==1u); assert(b[3]==0u);
}

void test_resize_decrease(){
    Buffer b(5); for(size_t i=0;i<5;++i) b[i]=i+1; b.resize(2); assert(b.size()==2u); assert(b[1]==2u);
}

void test_copy(){
    Buffer a(4); a[0]=1;a[1]=2;a[2]=3;a[3]=4; Buffer b(a); assert(b.size()==4u); for(size_t i=0;i<4;++i) assert(b[i]==a[i]);
}

void test_move(){
    Buffer a(2); a[0]=9;a[1]=10; Buffer b(std::move(a)); assert(b.size()==2u); assert(a.size()==0u);
}

int main(){
    test_default_constructor();
    test_size_constructor();
    test_bounds();
    test_resize_increase();
    test_resize_decrease();
    test_copy();
    test_move();
    std::cout<<"All tests passed."<<std::endl;
    return 0;
}
