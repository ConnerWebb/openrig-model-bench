#include "solution.hpp"
#include <iostream>
#include <cassert>

int main() {
    // Use capacity 10 to avoid blocking
    BoundedQueue<int> queue(10);
    
    // Push some items
    for (int i = 0; i < 10; ++i) {
        queue.push(i);
    }
    
    // Pop and verify
    for (int i = 0; i < 10; ++i) {
        auto val = queue.pop();
        assert(val.has_value());
        assert(*val == i);
    }
    
    // Close and verify no more items
    queue.close();
    assert(!queue.pop().has_value());
    
    std::cout << "Public test passed!" << std::endl;
    return 0;
}
