#include "solution.hpp"
#include <thread>
#include <vector>
#include <iostream>
#include <cassert>
#include <chrono>
#include <atomic>
#include <future>

// Test basic push/pop
void test_basic() {
    BoundedQueue<int> queue(5);
    queue.push(1);
    queue.push(2);
    queue.push(3);
    
    assert(queue.pop().value() == 1);
    assert(queue.pop().value() == 2);
    assert(queue.pop().value() == 3);
    // Queue is now empty and open - pop would block forever
    // We need to close it to make pop return nullopt
    queue.close();
    assert(!queue.pop().has_value());
}

// Test capacity limit - simplified
void test_capacity() {
    BoundedQueue<int> queue(3);
    assert(queue.push(1));
    assert(queue.push(2));
    assert(queue.push(3));
    
    // Verify we can pop the 3 items
    assert(queue.pop().value() == 1);
    assert(queue.pop().value() == 2);
    assert(queue.pop().value() == 3);
    queue.close();
    assert(!queue.pop().has_value());
}

// Test close and drain
void test_close_drain() {
    BoundedQueue<int> queue(5);
    queue.push(1);
    queue.push(2);
    queue.push(3);
    
    queue.close();
    
    // Should still be able to pop remaining items
    assert(queue.pop().value() == 1);
    assert(queue.pop().value() == 2);
    assert(queue.pop().value() == 3);
    assert(!queue.pop().has_value());
}

// Test push returns false after close
void test_push_after_close() {
    BoundedQueue<int> queue(5);
    queue.close();
    
    assert(!queue.push(1));
}

// Test idempotent close
void test_idempotent_close() {
    BoundedQueue<int> queue(5);
    queue.close();
    queue.close(); // Should not crash
}

// Test zero capacity throws
void test_zero_capacity() {
    bool threw = false;
    try {
        BoundedQueue<int> queue(0);
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
}

// Test move-only type
void test_move_only() {
    BoundedQueue<std::unique_ptr<int>> queue(5);
    auto ptr = std::make_unique<int>(42);
    queue.push(std::move(ptr));
    
    auto result = queue.pop();
    assert(result.has_value());
    assert(*result.value() == 42);
    queue.close();
    assert(!queue.pop().has_value());
}

int main() {
    test_basic();
    std::cout << "test_basic passed" << std::endl;
    
    test_capacity();
    std::cout << "test_capacity passed" << std::endl;
    
    test_close_drain();
    std::cout << "test_close_drain passed" << std::endl;
    
    test_push_after_close();
    std::cout << "test_push_after_close passed" << std::endl;
    
    test_idempotent_close();
    std::cout << "test_idempotent_close passed" << std::endl;
    
    test_zero_capacity();
    std::cout << "test_zero_capacity passed" << std::endl;
    
    test_move_only();
    std::cout << "test_move_only passed" << std::endl;
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
