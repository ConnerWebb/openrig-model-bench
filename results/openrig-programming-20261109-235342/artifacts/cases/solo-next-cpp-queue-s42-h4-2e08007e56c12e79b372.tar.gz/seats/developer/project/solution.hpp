#ifndef BOUNDED_QUEUE_HPP
#define BOUNDED_QUEUE_HPP

#include <queue>
#include <optional>
#include <stdexcept>
#include <mutex>
#include <condition_variable>
#include <atomic>

template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity) : capacity_(capacity), closed_(false) {
        if (capacity == 0) {
            throw std::invalid_argument("Capacity cannot be zero");
        }
    }

    bool push(T value) {
        std::unique_lock<std::mutex> lock(mutex_);
        
        // Wait while queue is full and not closed
        cv_not_full_.wait(lock, [this]() {
            return queue_.size() < capacity_ || closed_;
        });
        
        // If closed while waiting, return false
        if (closed_) {
            return false;
        }
        
        queue_.push(std::move(value));
        cv_not_empty_.notify_one();
        return true;
    }

    std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        
        // Wait while queue is empty and not closed (or has data)
        cv_not_empty_.wait(lock, [this]() {
            return !queue_.empty() || closed_;
        });
        
        // If queue is empty after waking, return nullopt
        if (queue_.empty()) {
            return std::nullopt;
        }
        
        auto value = std::move(queue_.front());
        queue_.pop();
        cv_not_full_.notify_one();
        return value;
    }

    void close() {
        std::unique_lock<std::mutex> lock(mutex_);
        if (closed_) {
            return; // Idempotent
        }
        closed_ = true;
        
        // Wake all waiting threads
        cv_not_empty_.notify_all();
        cv_not_full_.notify_all();
    }

private:
    size_t capacity_;
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable cv_not_empty_;
    std::condition_variable cv_not_full_;
    std::atomic<bool> closed_;
};

#endif // BOUNDED_QUEUE_HPP
