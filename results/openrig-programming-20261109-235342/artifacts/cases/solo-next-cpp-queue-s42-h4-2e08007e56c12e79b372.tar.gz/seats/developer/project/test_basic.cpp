#include "solution.hpp"
#include <iostream>
#include <cassert>

int main() {
    BoundedQueue<int> queue(5);
    queue.push(1);
    queue.push(2);
    queue.push(3);
    
    std::cout << "Popped: " << queue.pop().value() << std::endl;
    std::cout << "Popped: " << queue.pop().value() << std::endl;
    std::cout << "Popped: " << queue.pop().value() << std::endl;
    std::cout << "Empty check: " << (queue.pop().has_value() ? "has value" : "no value") << std::endl;
    
    std::cout << "Basic test passed!" << std::endl;
    return 0;
}
