# BoundedQueue

A thread-safe, header-only bounded queue implementation in C++20.

## Features

- **Thread-safe**: Uses mutex and condition variables for synchronization
- **Blocking operations**: `push()` blocks when full, `pop()` blocks when empty
- **Graceful shutdown**: `close()` allows consumers to drain remaining items
- **FIFO ordering**: Elements are returned in the order they were pushed
- **Move-only support**: Works with move-only types via `std::move`
- **Idempotent close**: Calling `close()` multiple times is safe

## Usage

```cpp
#include "solution.hpp"
#include <thread>
#include <iostream>

int main() {
    BoundedQueue<int> queue(5);
    
    // Producer thread
    std::thread producer([&queue]() {
        for (int i = 0; i < 10; ++i) {
            queue.push(i);
        }
        queue.close();
    });
    
    // Consumer thread
    std::thread consumer([&queue]() {
        while (auto value = queue.pop()) {
            std::cout << *value << std::endl;
        }
    });
    
    producer.join();
    consumer.join();
    
    return 0;
}
```

## API

### `explicit BoundedQueue(size_t capacity)`

Creates a new bounded queue with the specified capacity. Throws `std::invalid_argument` if capacity is zero.

### `bool push(T value)`

Pushes a value into the queue. Blocks if the queue is full until space becomes available or the queue is closed. Returns `false` after the queue is closed, `true` on success.

### `std::optional<T> pop()`

Pops a value from the queue. Blocks if the queue is empty until data becomes available or the queue is closed. Returns `std::nullopt` when the queue is closed and empty.

### `void close()`

Closes the queue, waking all waiting producers and consumers. Producers will receive `false` from `push()`. Consumers will drain remaining items, then receive `std::nullopt`. Idempotent.

## Thread Safety

All operations are thread-safe. Multiple producers and consumers can operate concurrently.

## Resource Management

The queue releases resources on destruction. Callers should close the queue and join all threads before destruction for clean shutdown.
