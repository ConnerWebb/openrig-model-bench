import unittest
import json
import os
import ledger

class TestLedgerProcess(unittest.TestCase):
    """Test the ledger.process function with all cases from PUBLIC_CASES.json"""
    
    def setUp(self):
        # Load test cases from PUBLIC_CASES.json
        test_file = os.path.join(os.path.dirname(__file__), 'PUBLIC_CASES.json')
        with open(test_file, 'r') as f:
            self.test_cases = json.load(f)
    
    def test_valid_cases_with_minimum(self):
        """Test valid records with minimum_cents filter"""
        # Case 1: minimum=10
        case = self.test_cases[0]
        records = case['driver_input']['records']
        minimum = case['driver_input'].get('minimum', 0)
        expected = case['expected']['value']
        
        result = ledger.process(records, minimum_cents=minimum)
        
        # Check events match (after normalization and deduplication)
        self.assertEqual(len(result['events']), len(expected['events']))
        for i, (r, e) in enumerate(zip(result['events'], expected['events'])):
            self.assertEqual(r['id'], e['id'])
            self.assertEqual(r['category'], e['category'])
            self.assertEqual(r['cents'], e['cents'])
        
        # Check totals
        self.assertEqual(result['totals'], expected['totals'])
        
        # Verify input unchanged
        self.assertTrue(case['expected']['input_unchanged'])
    
    def test_valid_cases_without_minimum(self):
        """Test valid records without minimum filter"""
        # We'll create a simple test case
        records = [
            {'id': ' a ', 'category': ' x ', 'cents': 10},
            {'id': ' b ', 'category': ' y ', 'cents': 20},
            {'id': ' a ', 'category': ' z ', 'cents': 30}  # duplicate id
        ]
        result = ledger.process(records)
        
        # First occurrence wins for deduplication
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['id'], 'a')
        self.assertEqual(result['events'][0]['category'], 'x')
        self.assertEqual(result['events'][0]['cents'], 10)
        self.assertEqual(result['events'][1]['id'], 'b')
        self.assertEqual(result['events'][1]['category'], 'y')
        self.assertEqual(result['events'][1]['cents'], 20)
        
        # Totals should be sorted by category
        self.assertEqual(result['totals'], {'x': 10, 'y': 20})
    
    def test_empty_input(self):
        """Test empty input returns empty result"""
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})
    
    def test_minimum_cents_filtering(self):
        """Test minimum_cents filter works correctly"""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'x', 'cents': 15},
            {'id': 'c', 'category': 'x', 'cents': 10}
        ]
        result = ledger.process(records, minimum_cents=10)
        
        # Only b and c should be included
        self.assertEqual(len(result['events']), 2)
        ids = [e['id'] for e in result['events']]
        self.assertIn('b', ids)
        self.assertIn('c', ids)
        self.assertNotIn('a', ids)
        
        # Totals should only include filtered records
        self.assertEqual(result['totals'], {'x': 25})
    
    def test_minimum_cents_zero(self):
        """Test minimum_cents=0 includes all records"""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 0},
            {'id': 'b', 'category': 'x', 'cents': 5}
        ]
        result = ledger.process(records, minimum_cents=0)
        
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['totals'], {'x': 5})
    
    def test_validation_invalid_cents_type(self):
        """Test that boolean cents raises ValueError"""
        records = [{'id': 'x', 'category': 'a', 'cents': True}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_validation_empty_id(self):
        """Test that empty id raises ValueError"""
        records = [{'id': '', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_validation_negative_cents(self):
        """Test that negative cents raises ValueError"""
        records = [{'id': 'x', 'category': 'a', 'cents': -1}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_validation_extra_fields(self):
        """Test that extra fields raise ValueError"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1, 'extra': 2}]
        with self.assertRaises(ValueError):
            ledger.process(records)
    
    def test_validation_invalid_minimum_cents_type(self):
        """Test that non-int minimum_cents raises ValueError"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=1.5)
    
    def test_validation_negative_minimum_cents(self):
        """Test that negative minimum_cents raises ValueError"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=-1)
    
    def test_validation_boolean_minimum_cents(self):
        """Test that boolean minimum_cents raises ValueError"""
        records = [{'id': 'x', 'category': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            ledger.process(records, minimum_cents=True)
    
    def test_input_not_mutated(self):
        """Test that input records are not mutated"""
        records = [
            {'id': ' a ', 'category': ' x ', 'cents': 10},
            {'id': ' b ', 'category': ' y ', 'cents': 20}
        ]
        original_records = [dict(r) for r in records]
        ledger.process(records)
        
        # Check original records unchanged
        for orig, actual in zip(original_records, records):
            self.assertEqual(orig, actual)
    
    def test_whitespace_normalization(self):
        """Test that whitespace is stripped from id and category"""
        records = [
            {'id': '  id1  ', 'category': '  cat1  ', 'cents': 100}
        ]
        result = ledger.process(records)
        
        self.assertEqual(result['events'][0]['id'], 'id1')
        self.assertEqual(result['events'][0]['category'], 'cat1')
    
    def test_deduplication_first_wins(self):
        """Test that first occurrence of id wins during deduplication"""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': 20},
            {'id': 'a', 'category': 'z', 'cents': 30}
        ]
        result = ledger.process(records)
        
        # First occurrence should be kept
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'x')
        self.assertEqual(result['events'][0]['cents'], 10)
    
    def test_totals_sorted(self):
        """Test that totals keys are sorted"""
        records = [
            {'id': 'a', 'category': 'z', 'cents': 1},
            {'id': 'b', 'category': 'a', 'cents': 2},
            {'id': 'c', 'category': 'm', 'cents': 3}
        ]
        result = ledger.process(records)
        
        # Totals should be sorted alphabetically
        self.assertEqual(list(result['totals'].keys()), ['a', 'm', 'z'])
    
    def test_multiple_categories(self):
        """Test aggregation across multiple categories"""
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'b', 'category': 'y', 'cents': 20},
            {'id': 'c', 'category': 'x', 'cents': 30}
        ]
        result = ledger.process(records)
        
        self.assertEqual(result['totals'], {'x': 40, 'y': 20})
    
    def test_cents_zero_allowed(self):
        """Test that cents=0 is valid"""
        records = [{'id': 'a', 'category': 'x', 'cents': 0}]
        result = ledger.process(records)
        
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 0)
        self.assertEqual(result['totals'], {'x': 0})

if __name__ == '__main__':
    unittest.main()
