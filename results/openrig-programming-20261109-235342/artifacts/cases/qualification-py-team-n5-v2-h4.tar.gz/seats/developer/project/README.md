# Validation Module

This module provides record validation functionality for processing data records.

## Module: validation

### `normalize(records)`

Validate and normalize a list of records.

**Parameters:**
- `records` (list): List of record dictionaries to validate

**Returns:**
- list: A new list of normalized records with stripped whitespace

**Raises:**
- ValueError: If any record is invalid

**Validation Rules:**
- Each record must be a dictionary with exactly three keys: `id`, `category`, `cents`
- `id`: Must be a non-empty string after stripping whitespace
- `category`: Must be a non-empty string after stripping whitespace
- `cents`: Must be a non-negative integer (not a boolean)

**Behavior:**
- Whitespace is stripped from `id` and `category` strings
- Records are returned in the same order as input
- Duplicates are preserved (deduplication is handled by a separate module)
- Input records are not mutated
- A new list is always returned

**Example:**
```python
from validation import normalize

records = [
    {'id': ' 8 ', 'category': ' c ', 'cents': 1},
    {'id': ' 4 ', 'category': ' a ', 'cents': 96},
]

normalized = normalize(records)
# Result:
# [
#     {'id': '8', 'category': 'c', 'cents': 1},
#     {'id': '4', 'category': 'a', 'cents': 96},
# ]
```

## Related Modules

- `storage.py`: Contains `deduplicate(records)` for removing duplicate records by id
- `ledger.py`: Contains `process(records, minimum_cents=0)` for full processing pipeline
