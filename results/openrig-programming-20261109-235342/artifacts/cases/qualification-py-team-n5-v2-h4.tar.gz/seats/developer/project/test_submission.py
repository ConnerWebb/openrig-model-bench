import unittest
import validation


class TestNormalize(unittest.TestCase):
    """Tests for validation.normalize() function."""

    def test_normalize_strips_whitespace(self):
        """Test that id and category whitespace is stripped."""
        records = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'a', 'category': 'b', 'cents': 2}])

    def test_normalize_preserves_input_unchanged(self):
        """Test that input records are not mutated."""
        records = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        original_id = records[0]['id']
        validation.normalize(records)
        self.assertEqual(records[0]['id'], original_id)

    def test_normalize_returns_fresh_list(self):
        """Test that a new list is returned."""
        records = [{'id': 'a', 'category': 'b', 'cents': 2}]
        result = validation.normalize(records)
        self.assertIsNot(result, records)

    def test_normalize_empty_input(self):
        """Test empty input returns empty list."""
        self.assertEqual(validation.normalize([]), [])

    def test_normalize_preserves_order_and_duplicates(self):
        """Test that order and duplicates are preserved."""
        records = [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'b', 'cents': 20},
            {'id': '1', 'category': 'c', 'cents': 30},
        ]
        result = validation.normalize(records)
        expected = [
            {'id': '1', 'category': 'a', 'cents': 10},
            {'id': '2', 'category': 'b', 'cents': 20},
            {'id': '1', 'category': 'c', 'cents': 30},
        ]
        self.assertEqual(result, expected)

    def test_normalize_cents_zero_allowed(self):
        """Test that cents=0 is valid."""
        records = [{'id': 'a', 'category': 'b', 'cents': 0}]
        result = validation.normalize(records)
        self.assertEqual(result, [{'id': 'a', 'category': 'b', 'cents': 0}])

    def test_normalize_cents_negative_raises(self):
        """Test that negative cents raises ValueError."""
        records = [{'id': 'a', 'category': 'b', 'cents': -1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_cents_bool_raises(self):
        """Test that bool cents raises ValueError."""
        records = [{'id': 'a', 'category': 'b', 'cents': True}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_empty_id_raises(self):
        """Test that empty id raises ValueError."""
        records = [{'id': '', 'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_whitespace_only_id_raises(self):
        """Test that whitespace-only id raises ValueError."""
        records = [{'id': '   ', 'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_empty_category_raises(self):
        """Test that empty category raises ValueError."""
        records = [{'id': 'a', 'category': '', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_whitespace_only_category_raises(self):
        """Test that whitespace-only category raises ValueError."""
        records = [{'id': 'a', 'category': '   ', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_extra_fields_raises(self):
        """Test that extra fields raise ValueError."""
        records = [{'id': 'a', 'category': 'b', 'cents': 1, 'extra': 2}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_missing_id_raises(self):
        """Test that missing id raises ValueError."""
        records = [{'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_missing_category_raises(self):
        """Test that missing category raises ValueError."""
        records = [{'id': 'a', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_missing_cents_raises(self):
        """Test that missing cents raises ValueError."""
        records = [{'id': 'a', 'category': 'b'}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_id_not_string_raises(self):
        """Test that non-string id raises ValueError."""
        records = [{'id': 123, 'category': 'b', 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_category_not_string_raises(self):
        """Test that non-string category raises ValueError."""
        records = [{'id': 'a', 'category': 123, 'cents': 1}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_cents_not_int_raises(self):
        """Test that non-int cents raises ValueError."""
        records = [{'id': 'a', 'category': 'b', 'cents': 1.5}]
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_record_not_dict_raises(self):
        """Test that non-dict record raises ValueError."""
        records = ['not a dict']
        with self.assertRaises(ValueError):
            validation.normalize(records)

    def test_normalize_mixed_valid_invalid_raises(self):
        """Test that mixed valid/invalid raises ValueError."""
        records = [
            {'id': 'a', 'category': 'b', 'cents': 1},
            {'id': 'c', 'category': 'd', 'cents': -1},
        ]
        with self.assertRaises(ValueError):
            validation.normalize(records)


if __name__ == '__main__':
    unittest.main()
