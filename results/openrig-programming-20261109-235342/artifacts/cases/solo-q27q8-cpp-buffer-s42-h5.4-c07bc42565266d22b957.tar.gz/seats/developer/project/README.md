# Buffer

A small RAII byte buffer (`uint8_t`) in C++20, implemented in `solution.hpp`.

## API

- `Buffer(std::size_t n = 0)` — constructs a buffer of `n` zero-initialized bytes.
- `std::size_t size() const noexcept` — number of bytes.
- `std::uint8_t& operator[](std::size_t i)` / `const std::uint8_t& operator[](std::size_t i) const`
  — element access; throws `std::out_of_range` if `i >= size()`.
- `void resize(std::size_t k)` — resizes to `k` bytes, preserving the existing prefix and
  zero-initializing any new bytes.
- Copy construction / copy assignment: deep copies (independent storage).
- Move construction / move assignment: `noexcept`; the moved-from buffer has size 0 and is
  safe to reuse.
- Self-copy and self-move preserve content.

## Implementation notes

Storage is a `std::vector<std::uint8_t>`, so the class is exception-safe, leak-free, and has
no stale reads or double frees. Move operations are the default (noexcept) vector moves.

## Tests

`test_buffer.cpp` is a standalone C++ test (plain `assert`s, `main()`-based) covering:
construction, zero-init, deep copy, copy assignment, move construction/assignment,
moved-from reuse, self-copy/self-move, resize grow/shrink/zero, bounds checking on both
mutable and const access, and the noexcept move traits.

Build & run:

```
clang++ -std=c++20 -Wall -Wextra -fsanitize=address,undefined test_buffer.cpp -o /tmp/test_buffer && /tmp/test_buffer
```
