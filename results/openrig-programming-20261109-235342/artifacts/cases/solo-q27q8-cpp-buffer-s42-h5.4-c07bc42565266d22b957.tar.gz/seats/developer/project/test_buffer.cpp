#include <cassert>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#include "solution.hpp"

static void test_default_and_ctor() {
    Buffer a;
    assert(a.size() == 0);
    Buffer b(5);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) assert(b[i] == 0);
}

static void test_copy_is_deep() {
    Buffer a(4);
    a[0] = 1; a[1] = 2; a[2] = 3; a[3] = 4;
    Buffer b = a;
    b[0] = 99;
    assert(a[0] == 1);
    assert(b[0] == 99);
    assert(b[1] == 2 && b[2] == 3 && b[3] == 4);
}

static void test_copy_assign() {
    Buffer a(3);
    a[0] = 10; a[1] = 20; a[2] = 30;
    Buffer b(1);
    b = a;
    assert(b.size() == 3);
    assert(b[0] == 10 && b[1] == 20 && b[2] == 30);
    a[0] = 1;
    assert(b[0] == 10);
}

static void test_move() {
    Buffer a(3);
    a[0] = 7; a[1] = 8; a[2] = 9;
    Buffer b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 3);
    assert(b[0] == 7 && b[1] == 8 && b[2] == 9);
    // moved-from is reusable
    b.resize(2);
    b[0] = 1; b[1] = 2;
    assert(b.size() == 2);
}

static void test_move_assign() {
    Buffer a(2);
    a[0] = 5; a[1] = 6;
    Buffer b(4);
    b = std::move(a);
    assert(a.size() == 0);
    assert(b.size() == 2);
    assert(b[0] == 5 && b[1] == 6);
}

static void test_self_copy() {
    Buffer a(3);
    a[0] = 1; a[1] = 2; a[2] = 3;
    a = a;
    assert(a.size() == 3);
    assert(a[0] == 1 && a[1] == 2 && a[2] == 3);
}

static void test_self_move() {
    Buffer a(3);
    a[0] = 1; a[1] = 2; a[2] = 3;
    a = std::move(a);
    assert(a.size() == 3);
    assert(a[0] == 1 && a[1] == 2 && a[2] == 3);
}

static void test_resize_grow_shrink() {
    Buffer a(3);
    a[0] = 1; a[1] = 2; a[2] = 3;
    a.resize(5);
    assert(a.size() == 5);
    assert(a[0] == 1 && a[1] == 2 && a[2] == 3);
    assert(a[3] == 0 && a[4] == 0);
    a.resize(2);
    assert(a.size() == 2);
    assert(a[0] == 1 && a[1] == 2);
    a.resize(0);
    assert(a.size() == 0);
}

static void test_bounds() {
    Buffer a(2);
    bool caught = false;
    try { (void)a[2]; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
    caught = false;
    try { a[100] = 1; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
    const Buffer& ca = a;
    caught = false;
    try { (void)ca[2]; } catch (const std::out_of_range&) { caught = true; }
    assert(caught);
    // valid access still works
    a[1] = 42;
    assert(ca[1] == 42);
}

static void test_noexcept_traits() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
    static_assert(std::is_nothrow_destructible_v<Buffer>);
}

int main() {
    test_default_and_ctor();
    test_copy_is_deep();
    test_copy_assign();
    test_move();
    test_move_assign();
    test_self_copy();
    test_self_move();
    test_resize_grow_shrink();
    test_bounds();
    test_noexcept_traits();
    return 0;
}
