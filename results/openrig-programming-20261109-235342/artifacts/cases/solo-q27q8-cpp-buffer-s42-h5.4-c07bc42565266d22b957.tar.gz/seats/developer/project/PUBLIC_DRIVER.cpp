#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"
std::string js(const std::string&s){std::ostringstream o;o<<'"';for(unsigned char c:s){if(c=='"'||c=='\\')o<<'\\'<<c;else if(c=='\n')o<<"\\n";else if(c=='\r')o<<"\\r";else if(c=='\t')o<<"\\t";else if(c<32)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)c<<std::dec;else o<<c;}o<<'"';return o.str();}
int main(){try{
static_assert(std::is_nothrow_move_constructible_v<Buffer> && std::is_nothrow_move_assignable_v<Buffer>);int n,grow;std::cin>>n>>grow;Buffer a(n);for(int i=0;i<n;i++){int v;std::cin>>v;a[i]=v;}Buffer b=a;if(n)b[0]^=255;Buffer c=std::move(b);std::size_t old=b.size();a=a;a=std::move(a);a.resize(grow);bool checked=false;try{(void)a[a.size()];}catch(const std::out_of_range&){checked=true;}const Buffer& ca=a;std::cout<<"{\"value\":[";for(std::size_t i=0;i<ca.size();i++){if(i)std::cout<<',';std::cout<<(int)ca[i];}std::cout<<"],\"moved_size\":"<<old<<",\"copy\":[";for(std::size_t i=0;i<c.size();i++){if(i)std::cout<<',';std::cout<<(int)c[i];}std::cout<<"],\"bounds\":"<<(checked?"true":"false")<<'}';
}catch(const std::exception&e){std::cout<<"{\"error\":\"ValueError\"}";}catch(...){std::cout<<"{\"error\":\"ValueError\"}";}std::cout<<std::endl;}
