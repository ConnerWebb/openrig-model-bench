#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <utility>
#include <vector>

class Buffer {
    std::vector<std::uint8_t> data_;

public:
    explicit Buffer(std::size_t n = 0) : data_(n, 0) {}

    Buffer(const Buffer& other) : data_(other.data_) {}

    Buffer(Buffer&& other) noexcept = default;

    Buffer& operator=(const Buffer& other) {
        if (this != &other) data_ = other.data_;
        return *this;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) data_ = std::move(other.data_);
        return *this;
    }

    ~Buffer() = default;

    std::size_t size() const noexcept { return data_.size(); }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= data_.size()) throw std::out_of_range("Buffer index out of range");
        return data_[i];
    }

    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= data_.size()) throw std::out_of_range("Buffer index out of range");
        return data_[i];
    }

    void resize(std::size_t k) { data_.resize(k, 0); }
};
