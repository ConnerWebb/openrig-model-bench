# Buffer Implementation

This is a complete implementation of a `Buffer` class in C++20 that meets all the specified requirements.

## Features

- **RAII**: Proper resource management with constructor, destructor, copy constructor, copy assignment, move constructor, and move assignment
- **Bounds Checking**: Both mutable and const `operator[]` throw `std::out_of_range` when accessing invalid indices
- **Resize**: `resize(size_t)` preserves the prefix and zero-initializes new bytes
- **Memory Safety**: No leaks, double frees, stale reads, or undefined behavior
- **Move Semantics**: Noexcept move construction and assignment with moved-from buffers becoming size 0 and reusable
- **Copy Semantics**: Deep copy construction and assignment
- **Self Operations**: Self-copy and self-move preserve content

## Interface

```cpp
class Buffer {
public:
    // Constructor
    explicit Buffer(std::size_t n = 0);
    
    // Destructor
    ~Buffer();
    
    // Copy constructor
    Buffer(const Buffer& other);
    
    // Copy assignment
    Buffer& operator=(const Buffer& other);
    
    // Move constructor
    Buffer(Buffer&& other) noexcept;
    
    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept;
    
    // Size getter
    std::size_t size() const noexcept;
    
    // Mutable operator[]
    std::uint8_t& operator[](std::size_t i);
    
    // Const operator[]
    const std::uint8_t& operator[](std::size_t i) const;
    
    // Resize method
    void resize(std::size_t k);
};
```

## Requirements Met

1. ✅ `Buffer(size_t n=0)` - Constructor with default parameter
2. ✅ `size() const noexcept` - Size getter with noexcept
3. ✅ Mutable/const `operator[](size_t)` with bounds-check `out_of_range`
4. ✅ `resize(size_t)` preserving prefix and zero-initializing new bytes
5. ✅ Elements are `uint8_t`
6. ✅ Deep-copy construction/assignment
7. ✅ Noexcept move construction/assignment
8. ✅ Moved-from buffers size 0 and reusable
9. ✅ Self-copy/self-move preserve content
10. ✅ RAII, no leaks, double frees, stale reads or undefined behavior
11. ✅ Standard containers are allowed