#include <iostream>
#include "solution.hpp"

int main() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    std::cout << "Before resize, b[3] = " << (int)b[3] << std::endl;
    
    b.resize(8);
    std::cout << "After resize, b[3] = " << (int)b[3] << std::endl;
    std::cout << "After resize, b[4] = " << (int)b[4] << std::endl;
    std::cout << "After resize, b[5] = " << (int)b[5] << std::endl;
    std::cout << "After resize, b[6] = " << (int)b[6] << std::endl;
    std::cout << "After resize, b[7] = " << (int)b[7] << std::endl;
    
    return 0;
}