#include <cassert>
#include <stdexcept>
#include "solution.hpp"

void test_constructor() {
    Buffer b(10);
    assert(b.size() == 10);
    
    Buffer b2;
    assert(b2.size() == 0);
}

void test_copy() {
    Buffer b1(5);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    
    Buffer b2 = b1;
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    
    // Modify original, should not affect copy
    b1[0] = 99;
    assert(b2[0] == 1);
}

void test_assignment() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    
    Buffer b2(2);
    b2[0] = 99;
    b2[1] = 88;
    
    b2 = b1;
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
}

void test_move() {
    Buffer b1(3);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;
    
    Buffer b2 = std::move(b1);
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    
    // b1 should be empty now
    assert(b1.size() == 0);
}

void test_resize() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    b.resize(8);
    assert(b.size() == 8);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);  // Should be zero-initialized
    assert(b[4] == 0);
    assert(b[5] == 0);
    assert(b[6] == 0);
    assert(b[7] == 0);
    
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
}

void test_bounds_check() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    try {
        b[5] = 10;  // Should throw
        assert(false);
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    try {
        const Buffer& cb = b;
        (void)cb[5];  // Should throw
        assert(false);
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_self_operations() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    // Self assignment
    b = b;
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    
    // Self move
    Buffer b2 = std::move(b);
    assert(b2.size() == 3);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);
    assert(b.size() == 0);
}

int main() {
    test_constructor();
    test_copy();
    test_assignment();
    test_move();
    test_resize();
    test_bounds_check();
    test_self_operations();
    
    return 0;
}