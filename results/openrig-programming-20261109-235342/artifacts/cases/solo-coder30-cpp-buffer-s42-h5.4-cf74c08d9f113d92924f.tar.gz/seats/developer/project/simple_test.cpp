#include <iostream>
#include <cassert>
#include "solution.hpp"

int main() {
    // Test basic functionality
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    
    std::cout << "Initial size: " << b.size() << std::endl;
    std::cout << "b[0] = " << (int)b[0] << std::endl;
    std::cout << "b[1] = " << (int)b[1] << std::endl;
    std::cout << "b[2] = " << (int)b[2] << std::endl;
    
    b.resize(8);
    std::cout << "After resize to 8, size: " << b.size() << std::endl;
    std::cout << "b[0] = " << (int)b[0] << std::endl;
    std::cout << "b[1] = " << (int)b[1] << std::endl;
    std::cout << "b[2] = " << (int)b[2] << std::endl;
    std::cout << "b[3] = " << (int)b[3] << std::endl;
    std::cout << "b[4] = " << (int)b[4] << std::endl;
    std::cout << "b[5] = " << (int)b[5] << std::endl;
    std::cout << "b[6] = " << (int)b[6] << std::endl;
    std::cout << "b[7] = " << (int)b[7] << std::endl;
    
    // Check that new elements are zero-initialized
    assert(b[3] == 0);
    assert(b[4] == 0);
    assert(b[5] == 0);
    assert(b[6] == 0);
    assert(b[7] == 0);
    
    std::cout << "All assertions passed!" << std::endl;
    return 0;
}