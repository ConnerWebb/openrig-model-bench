import unittest
import os
import tempfile
import json
from solution import aggregate


class TestAggregate(unittest.TestCase):

    def test_public_case_00(self):
        csv_content = """category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本,690.39
"a,b",599.14
rent,457.86
日本,218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
"""
        expected = {
            "a,b": "599.14",
            "food": "2262.01",
            "rent": "2215.92",
            "two\nlines": "1434.24",
            "x\"quote": "1458.60",
            "日本": "909.01"
        }
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(path)
            self.assertEqual(result, expected)

    def test_public_case_04_invalid_header(self):
        csv_content = "wrong,amount\nx,1\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_public_case_05_extra_field(self):
        csv_content = "category,amount\nx,1,2\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_public_case_06_empty_category(self):
        csv_content = "category,amount\n,1\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_public_case_07_nan(self):
        csv_content = "category,amount\nx,NaN\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_public_case_08_unclosed_quote(self):
        csv_content = "category,amount\n\"x,1\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_blank_row_ignored(self):
        csv_content = "category,amount\nx,100\n\ny,200\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(path)
            self.assertEqual(result, {"x": "100.00", "y": "200.00"})

    def test_whitespace_stripping(self):
        csv_content = "category,amount\n  x  ,  100.50  \n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(path)
            self.assertEqual(result, {"x": "100.50"})

    def test_positive_sign_allowed(self):
        csv_content = "category,amount\nx,+100.50\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            result = aggregate(path)
            self.assertEqual(result, {"x": "100.50"})

    def test_amount_with_exponent_rejected(self):
        csv_content = "category,amount\nx,1e5\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_amount_too_many_digits(self):
        csv_content = "category,amount\nx,1234567890123\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_amount_no_fractional_digits(self):
        csv_content = "category,amount\nx,100.\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_amount_fractional_too_many_digits(self):
        csv_content = "category,amount\nx,100.123\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_empty_file_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write("")
            with self.assertRaises(ValueError):
                aggregate(path)

    def test_header_only_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.csv")
            with open(path, 'w', encoding='utf-8') as f:
                f.write("category,amount\n")
            result = aggregate(path)
            self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
