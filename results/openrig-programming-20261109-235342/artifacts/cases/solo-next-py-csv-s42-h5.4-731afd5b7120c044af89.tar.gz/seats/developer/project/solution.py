import csv
from decimal import Decimal, InvalidOperation
import os


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted, totals formatted
    with exactly two decimal places. CSV quoted commas and embedded newlines are valid.
    """
    totals: dict[str, Decimal] = {}

    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)

        # Read header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")

        if header != ['category', 'amount']:
            raise ValueError("Invalid header")

        for row in reader:
            # Check for blank row (entire row is empty or only whitespace)
            if not row or all(cell.strip() == '' for cell in row):
                continue

            # Must have exactly two fields
            if len(row) != 2:
                raise ValueError("Invalid row: expected 2 fields")

            category_raw, amount_raw = row

            # Strip whitespace
            category = category_raw.strip()
            amount_str = amount_raw.strip()

            # Category must not be empty
            if not category:
                raise ValueError("Empty category")

            # Validate amount format
            if not _is_valid_amount(amount_str):
                raise ValueError(f"Invalid amount: {amount_str}")

            # Parse amount with Decimal
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")

            # Check for NaN or infinity
            if not amount.is_finite():
                raise ValueError(f"Invalid amount: {amount_str}")

            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount

    # Format results with exactly two decimal places
    result: dict[str, str] = {}
    for cat in sorted(totals.keys()):
        value = totals[cat]
        result[cat] = f"{value:.2f}"

    return result


def _is_valid_amount(s: str) -> bool:
    """
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent.
    """
    if not s:
        return False

    # Check for exponent (not allowed)
    if 'e' in s.lower():
        return False

    # Handle optional leading +
    if s.startswith('+'):
        s = s[1:]
        if not s:
            return False

    # Split on decimal point
    if '.' in s:
        parts = s.split('.')
        if len(parts) != 2:
            return False
        integer_part, fractional_part = parts

        # Integer part: 1-12 digits
        if not (1 <= len(integer_part) <= 12):
            return False
        if not integer_part.isdigit():
            return False

        # Fractional part: 1-2 digits
        if not (1 <= len(fractional_part) <= 2):
            return False
        if not fractional_part.isdigit():
            return False
    else:
        # No decimal point: just 1-12 digits
        if not (1 <= len(s) <= 12):
            return False
        if not s.isdigit():
            return False

    return True
