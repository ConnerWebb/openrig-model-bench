# CSV Aggregate Solution

This solution implements `aggregate(path: str) -> dict[str, str]` as specified.

## Features

- Reads UTF-8 CSV files using Python's `csv` module for proper handling of quoted fields and embedded newlines
- Validates header is exactly `category,amount`
- Ignores blank rows
- Strips whitespace from category and amount fields
- Validates amount format: optional `+`, 1-12 integer digits, optional decimal point with 1-2 fractional digits
- Rejects NaN, infinity, and exponents
- Uses `Decimal` for exact arithmetic
- Returns sorted keys with values formatted to exactly 2 decimal places

## Tests

Run with `python -m unittest test_solution.py`
