import csv
import re
from decimal import Decimal, InvalidOperation

def aggregate(path: str) -> dict[str, str]:
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            raise ValueError("Empty file")
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        for row in reader:
            if len(row) != 2:
                raise ValueError("Invalid row field count")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate amount format
            # Pattern: optional +, 1-12 digits, optional decimal point followed by 1-2 digits
            amount_pattern = r'^\+?(?:\d{1,12}(?:\.\d{1,2})?|\d{1,12})$'
            if not re.match(amount_pattern, amount_str):
                raise ValueError("Invalid amount format")
            
            # Parse as Decimal and validate
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError("Invalid amount")
            
            # Check for NaN, infinity, or negative
            if amount.is_nan() or amount.is_infinite() or amount < 0:
                raise ValueError("Invalid amount value")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format totals with exactly 2 decimal places, sort by category
    result = {}
    for cat in sorted(totals.keys()):
        total = totals[cat]
        result[cat] = f"{total:.2f}"
    
    return result
