# aggregate

Implementation of `aggregate(path: str) -> dict[str, str]` per qualification task.

## Contract

- Read UTF-8 CSV as a stream.
- Header must be exactly `category,amount`.
- Ignore completely blank records; every other record has exactly two fields.
- Strip category/amount whitespace; category must not be empty.
- Amount has optional `+`, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits; nonnegative, finite, no exponent.
- Reject all malformed input with `ValueError`.
- Accumulate using exact decimal arithmetic.
- Return category keys sorted, totals formatted with exactly two decimal places.
- CSV quoted commas and embedded newlines are valid.

## Tests

Run `python test_submission.py` to execute unit tests.
