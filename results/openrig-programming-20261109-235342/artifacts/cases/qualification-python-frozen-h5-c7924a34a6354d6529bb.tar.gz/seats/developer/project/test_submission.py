import unittest
import tempfile
import pathlib
import solution


class TestAggregate(unittest.TestCase):
    def test_basic_sum(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,0.10\na,0.20\n')
            self.assertEqual(solution.aggregate(str(p)), {'a': '0.30'})

    def test_quoted_fields(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n"x""quote",812.68\nfood,347.25\n')
            self.assertEqual(solution.aggregate(str(p)), {'x"quote': '812.68', 'food': '347.25'})

    def test_embedded_newlines(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\ntwo\nlines,849.77\n')
            self.assertEqual(solution.aggregate(str(p)), {'two\nlines': '849.77'})

    def test_unicode_categories(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n日本,690.39\n')
            self.assertEqual(solution.aggregate(str(p)), {'日本': '690.39'})

    def test_comma_in_quoted_field(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n"a,b",599.14\n')
            self.assertEqual(solution.aggregate(str(p)), {'a,b': '599.14'})

    def test_negative_amount_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,-1\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_nan_amount_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,NaN\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_exponent_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,1e2\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_decimal_places_over_two_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,1.001\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_amount_with_leading_plus(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,+1.50\n')
            self.assertEqual(solution.aggregate(str(p)), {'x': '1.50'})

    def test_amount_twelve_digits(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,1000000000000\n')
            self.assertEqual(solution.aggregate(str(p)), {'x': '1000000000000.00'})

    def test_wrong_header_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('wrong,amount\nx,1\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_too_many_columns_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nx,1,2\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_empty_category_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n,1\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_unclosed_quote_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n"x,1\n')
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_blank_line_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\na,1.00\n\nb,2.00\n')
            self.assertEqual(solution.aggregate(str(p)), {'a': '1.00', 'b': '2.00'})

    def test_whitespace_stripping(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\n  a  ,  1.00  \n')
            self.assertEqual(solution.aggregate(str(p)), {'a': '1.00'})

    def test_sorted_keys(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text('category,amount\nz,1.00\na,2.00\nm,3.00\n')
            self.assertEqual(solution.aggregate(str(p)), {'a': '2.00', 'm': '3.00', 'z': '1.00'})

    def test_multiple_rows_public_case_00(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-00.csv').read_text(encoding='utf-8'))
            result = solution.aggregate(str(p))
            expected = {
                '"a,b"': '1056.55',
                '"two\nlines"': '1434.24',
                'food': '2165.03',
                '日本': '909.01',
                'rent': '2566.19',
                'x"quote': '1460.60'
            }
            self.assertEqual(result, expected)

    def test_multiple_rows_public_case_01(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-01.csv').read_text(encoding='utf-8'))
            result = solution.aggregate(str(p))
            expected = {
                '"a,b"': '1872.17',
                '"two\nlines"': '2741.94',
                'food': '1326.74',
                '日本': '3041.78',
                'rent': '4561.16',
                'x"quote': '2390.56'
            }
            self.assertEqual(result, expected)

    def test_multiple_rows_public_case_02(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-02.csv').read_text(encoding='utf-8'))
            result = solution.aggregate(str(p))
            expected = {
                '"a,b"': '1956.28',
                '"two\nlines"': '1699.71',
                'food': '1088.43',
                '日本': '814.06',
                'x"quote': '2666.14'
            }
            self.assertEqual(result, expected)

    def test_multiple_rows_public_case_03(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-03.csv').read_text(encoding='utf-8'))
            result = solution.aggregate(str(p))
            expected = {
                '"a,b"': '1079.77',
                '"two\nlines"': '1316.88',
                'food': '1327.96',
                '日本': '2394.76',
                'x"quote': '1844.07'
            }
            self.assertEqual(result, expected)

    def test_multiple_rows_public_case_04(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-04.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_05(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-05.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_06(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-06.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_07(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-07.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_08(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-08.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_09(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-09.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_10(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-10.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_11(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-11.csv').read_text(encoding='utf-8'))
            with self.assertRaises(ValueError):
                solution.aggregate(str(p))

    def test_multiple_rows_public_case_12(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'x.csv'
            p.write_text(pathlib.Path('public-inputs/case-12.csv').read_text(encoding='utf-8'))
            self.assertEqual(solution.aggregate(str(p)), {'x': '1000000000000.00'})


if __name__ == '__main__':
    unittest.main()
