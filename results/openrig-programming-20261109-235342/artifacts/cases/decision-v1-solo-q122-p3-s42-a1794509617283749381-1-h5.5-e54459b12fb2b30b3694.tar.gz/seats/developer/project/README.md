# Buffer Library

A C++20 buffer implementation with deep-copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep-copy construction/assignment**: Copies are independent of the original
- **Noexcept move operations**: Efficient transfers with moved-from buffers having size 0
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Resize with preservation**: `resize()` preserves prefix and zero-initializes new bytes
- **RAII**: Automatic resource management, no leaks or double frees

## API

### Constructor
```cpp
Buffer(std::size_t n = 0);
```
Creates a buffer of `n` bytes, zero-initialized.

### Size
```cpp
std::size_t size() const noexcept;
```
Returns the current size of the buffer.

### Element Access
```cpp
std::uint8_t& operator[](std::size_t i);
const std::uint8_t& operator[](std::size_t i) const;
```
Access element at index `i`. Throws `std::out_of_range` if `i >= size()`.

### Resize
```cpp
void resize(std::size_t k);
```
Resize to `k` bytes, preserving existing prefix and zero-initializing new bytes.

## Example

```cpp
Buffer a(5);
a[0] = 1;
a[1] = 2;

Buffer b(a);  // Deep copy
b[0] = 99;    // Does not affect a

Buffer c = std::move(a);  // Move, a.size() becomes 0
```

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```
