"""
Aggregate CSV categories with exact decimal arithmetic.
"""
import csv
from decimal import Decimal, InvalidOperation
from typing import Dict


def aggregate(path: str) -> Dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Ignore completely blank records; every other record has exactly two fields.
    Strip category/amount whitespace; category must not be empty.
    Amount has optional +, 1–12 decimal digits, optional decimal point followed by 1 or 2 digits;
    nonnegative, finite, no exponent. Reject all malformed input with ValueError.
    Accumulate using exact decimal arithmetic. Return category keys sorted,
    totals formatted with exactly two decimal places.
    CSV quoted commas and embedded newlines are valid.
    """
    totals: Dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: {header}")
        
        for row in reader:
            # Skip completely blank records
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Expected 2 fields, got {len(row)}")
            
            category_raw, amount_raw = row
            
            # Strip whitespace
            category = category_raw.strip()
            amount_str = amount_raw.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate and parse amount
            amount = _parse_amount(amount_str)
            
            # Accumulate
            totals[category] = totals.get(category, Decimal('0')) + amount
    
    # Format and return sorted results
    result = {}
    for cat in sorted(totals.keys()):
        total = totals[cat]
        result[cat] = f"{total:.2f}"
    
    return result


def _parse_amount(s: str) -> Decimal:
    """
    Parse amount with optional +, 1–12 decimal digits, optional decimal point
    followed by 1 or 2 digits; nonnegative, finite, no exponent.
    """
    if not s:
        raise ValueError("Empty amount")
    
    # Remove optional leading +
    if s.startswith('+'):
        s = s[1:]
    
    if not s:
        raise ValueError("Empty amount after stripping +")
    
    # Check for exponent (not allowed)
    if 'e' in s.lower():
        raise ValueError("Exponent not allowed")
    
    # Check for NaN, Inf, etc.
    if s.lower() in ('nan', 'inf', '-inf', '+inf', 'infinity', '-infinity'):
        raise ValueError("Invalid amount: NaN/Inf not allowed")
    
    # Validate format: must have at least one digit
    if not s.isdigit() and '.' not in s:
        # Contains non-digit characters (like letters)
        raise ValueError(f"Invalid amount: {s}")
    
    if '.' not in s:
        # No decimal point - must be 1-12 digits
        if len(s) < 1 or len(s) > 12:
            raise ValueError(f"Amount length out of range: {len(s)}")
        try:
            return Decimal(s)
        except InvalidOperation:
            raise ValueError(f"Invalid amount: {s}")
    else:
        parts = s.split('.')
        if len(parts) != 2:
            raise ValueError(f"Invalid decimal format: {s}")
        
        int_part, frac_part = parts
        
        # Integer part can be empty (for values like .5) or have digits
        if int_part == '' and frac_part == '':
            raise ValueError("Invalid amount: no digits")
        
        # Validate integer part
        if int_part != '':
            if len(int_part) > 12:
                raise ValueError(f"Integer part too long: {len(int_part)}")
            # Check for non-digit characters
            if not int_part.isdigit():
                raise ValueError(f"Invalid integer part: {int_part}")
            int_val = int(int_part)
            if int_val < 0:
                raise ValueError("Negative integer part not allowed")
        
        # Validate fractional part (1-2 digits)
        if frac_part == '':
            raise ValueError("Missing fractional digits")
        if len(frac_part) < 1 or len(frac_part) > 2:
            raise ValueError(f"Fractional part must be 1-2 digits: {len(frac_part)}")
        
        # Check for non-digit characters in fractional part
        if not frac_part.isdigit():
            raise ValueError(f"Invalid fractional part: {frac_part}")
        

        
        try:
            return Decimal(s)
        except InvalidOperation:
            raise ValueError(f"Invalid amount: {s}")
