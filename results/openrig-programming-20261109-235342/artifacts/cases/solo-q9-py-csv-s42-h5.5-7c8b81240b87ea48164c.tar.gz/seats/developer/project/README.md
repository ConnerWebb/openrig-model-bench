# CSV Aggregate Solution

This solution implements the `aggregate(path: str) -> dict[str, str]` function that reads a UTF-8 CSV file and aggregates amounts by category.

## Usage

```python
from solution import aggregate

result = aggregate('input.csv')
print(result)
```

## Features

- Reads CSV files with header `category,amount`
- Handles quoted fields with embedded commas, newlines, and quotes
- Strips whitespace from category and amount
- Validates category is not empty
- Validates amount format (optional + prefix, 1-12 decimal digits, optional decimal point with 1-2 digits)
- Rejects negative amounts, NaN, Inf, and other invalid values
- Uses exact decimal arithmetic for accumulation
- Returns sorted category keys with totals formatted to 2 decimal places

## Tests

Run `python3 -m unittest test_submission` to execute all tests.
