"""
Unit tests for solution.aggregate using unittest.TestCase.
"""
import unittest
import tempfile
import os
from solution import aggregate


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""
    
    def test_simple(self):
        """Test simple aggregation."""
        csv_content = """category,amount
food,100.00
food,200.00
rent,50.00
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['food'], '300.00')
                self.assertEqual(result['rent'], '50.00')
            finally:
                os.unlink(f.name)
    
    def test_quoted_category(self):
        """Test quoted category with embedded quotes."""
        csv_content = '''category,amount
"x""quote",100.00
"x""quote",200.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['x"quote'], '300.00')
            finally:
                os.unlink(f.name)
    
    def test_multiline_category(self):
        """Test category with embedded newlines."""
        csv_content = '''category,amount
"two
lines",100.00
"two
lines",200.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['two\nlines'], '300.00')
            finally:
                os.unlink(f.name)
    
    def test_comma_in_category(self):
        """Test category with embedded comma."""
        csv_content = '''category,amount
"a,b",100.00
"a,b",200.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['a,b'], '300.00')
            finally:
                os.unlink(f.name)
    
    def test_unicode_category(self):
        """Test unicode category."""
        csv_content = '''category,amount
日本,100.00
日本,200.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['日本'], '300.00')
            finally:
                os.unlink(f.name)
    
    def test_empty_category_rejected(self):
        """Test that empty category is rejected."""
        csv_content = '''category,amount
,100.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_negative_amount_rejected(self):
        """Test that negative amount is rejected."""
        csv_content = '''category,amount
food,-100.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_nan_rejected(self):
        """Test that NaN is rejected."""
        csv_content = '''category,amount
food,NaN
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_empty_amount_rejected(self):
        """Test that empty amount is rejected."""
        csv_content = '''category,amount
food,
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                with self.assertRaises(ValueError):
                    aggregate(f.name)
            finally:
                os.unlink(f.name)
    
    def test_plus_prefix(self):
        """Test amount with + prefix."""
        csv_content = '''category,amount
food,+100.00
food,+200.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(result['food'], '300.00')
            finally:
                os.unlink(f.name)
    
    def test_sorted_output(self):
        """Test that output is sorted by category."""
        csv_content = '''category,amount
z,100.00
a,200.00
m,300.00
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()
            try:
                result = aggregate(f.name)
                self.assertEqual(list(result.keys()), ['a', 'm', 'z'])
            finally:
                os.unlink(f.name)


if __name__ == '__main__':
    unittest.main()
