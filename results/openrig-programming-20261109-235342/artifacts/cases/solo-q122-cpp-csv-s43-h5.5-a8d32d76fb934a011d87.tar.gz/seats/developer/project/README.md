# CSV Aggregator

This project implements a CSV parser that aggregates amounts by category.

## API

The main function is `aggregate(std::istream& in)` which:
- Parses a CSV file with header `category,amount`
- Aggregates amounts by category
- Returns a `std::map<std::string, std::int64_t>` with sorted keys
- Throws `std::invalid_argument` on malformed input or overflow

## Features

- Handles quoted fields with escaped quotes (`""`)
- Supports CRLF, LF, and CR line endings
- Strips leading/trailing whitespace from fields
- Validates header format
- Rejects overflow during parsing and aggregation
- Supports negative amounts and explicit `+` prefix

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_solution test_solution.cpp
./test_solution
```

## Testing

Run `run_tests` to execute all public and authored tests.
