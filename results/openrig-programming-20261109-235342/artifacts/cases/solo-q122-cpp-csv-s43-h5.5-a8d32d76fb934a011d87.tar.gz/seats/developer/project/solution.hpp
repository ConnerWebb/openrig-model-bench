#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <istream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <limits>
#include <cctype>

namespace {

// Strip leading/trailing spaces, tabs, and CR from a string
std::string strip_outer(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) {
        ++start;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (s[end] == ' ' || s[end] == '\t' || s[end] == '\r')) {
        --end;
    }
    return s.substr(start, end - start + 1);
}

// Parse a single CSV field from the stream, handling quotes.
// The delimiter (comma or newline/EOF) is NOT consumed from the stream.
// Returns the field content (unquoted, with escaped quotes unescaped).
// Throws on malformed input.
std::string parse_field(std::istream& in) {
    std::string field;
    int c = in.get();
    
    if (c == EOF) {
        return "";
    }
    
    if (c == '"') {
        // Quoted field
        while (true) {
            c = in.get();
            if (c == EOF) {
                throw std::invalid_argument("Unclosed quoted field");
            }
            if (c == '"') {
                // Check for escaped quote
                int next = in.get();
                if (next == '"') {
                    // Escaped quote, add one quote
                    field += '"';
                } else {
                    // End of quoted field - push back the delimiter
                    if (next != EOF) {
                        in.unget();
                    }
                    return field;
                }
            } else {
                field += static_cast<char>(c);
            }
        }
    } else {
        // Unquoted field
        while (c != ',' && c != '\n' && c != '\r' && c != EOF) {
            field += static_cast<char>(c);
            c = in.get();
        }
        // Push back the delimiter
        if (c != EOF) {
            in.unget();
        }
        return field;
    }
}

// Parse a signed int64, rejecting overflow and invalid formats
int64_t parse_int64(const std::string& s) {
    if (s.empty()) {
        throw std::invalid_argument("Empty amount field");
    }
    
    size_t start = 0;
    bool negative = false;
    
    if (s[0] == '+') {
        start = 1;
    } else if (s[0] == '-') {
        negative = true;
        start = 1;
    }
    
    if (start >= s.size()) {
        throw std::invalid_argument("Amount has no digits");
    }
    
    // Check all remaining chars are digits
    for (size_t i = start; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) {
            throw std::invalid_argument("Amount contains non-digit characters");
        }
    }
    
    // Use string length to quickly detect potential overflow
    // INT64_MAX = 9223372036854775807 (19 digits)
    // INT64_MIN = -9223372036854775808 (19 digits)
    size_t num_digits = s.size() - start;
    if (num_digits > 19) {
        throw std::invalid_argument("Amount overflow");
    }
    
    // Parse as uint64_t first
    uint64_t result = 0;
    for (size_t i = start; i < s.size(); ++i) {
        uint64_t digit = s[i] - '0';
        result = result * 10 + digit;
    }
    
    // Check bounds
    if (negative) {
        uint64_t min_abs = static_cast<uint64_t>(std::numeric_limits<int64_t>::min()) * -1ULL;
        if (result > min_abs) {
            throw std::invalid_argument("Amount overflow");
        }
        if (result == min_abs) {
            // Special case: INT64_MIN
            return std::numeric_limits<int64_t>::min();
        }
        return -static_cast<int64_t>(result);
    } else {
        if (result > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
            throw std::invalid_argument("Amount overflow");
        }
        return static_cast<int64_t>(result);
    }
}

// Consume the line ending (LF, CRLF, or CR) from the stream
void consume_line_ending(std::istream& in) {
    int c = in.get();
    if (c == '\n') {
        return;
    }
    if (c == '\r') {
        int next = in.get();
        if (next == '\n') {
            return;
        }
        if (next != EOF) {
            in.unget();
        }
        return;
    }
    if (c != EOF) {
        in.unget();
    }
}

// Check if we're at a line ending or EOF
bool at_line_end_or_eof(std::istream& in) {
    int c = in.peek();
    return c == '\n' || c == '\r' || c == EOF;
}

} // anonymous namespace

std::map<std::string, std::int64_t> aggregate(std::istream& in) {
    std::map<std::string, std::int64_t> result;
    
    // Read and validate header
    std::string field1 = parse_field(in);
    std::string field1_stripped = strip_outer(field1);
    
    if (field1_stripped != "category") {
        throw std::invalid_argument("Invalid header: expected 'category'");
    }
    
    // Check for comma
    int c = in.peek();
    if (c != ',') {
        throw std::invalid_argument("Expected comma after first header field");
    }
    in.get();
    
    std::string field2 = parse_field(in);
    std::string field2_stripped = strip_outer(field2);
    
    if (field2_stripped != "amount") {
        throw std::invalid_argument("Invalid header: expected 'amount'");
    }
    
    // Check for extra fields in header
    c = in.peek();
    if (c == ',') {
        in.get();
        std::string extra = parse_field(in);
        throw std::invalid_argument("Too many header fields");
    }
    if (!at_line_end_or_eof(in)) {
        throw std::invalid_argument("Invalid character after header");
    }
    
    // Consume line ending after header
    consume_line_ending(in);
    
    // Parse data rows
    while (true) {
        // Check if we're at EOF
        if (in.peek() == EOF) {
            break;
        }
        
        // Read first field (category)
        std::string cat = parse_field(in);
        std::string cat_stripped = strip_outer(cat);
        
        // Check for empty category
        if (cat_stripped.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        
        // Check for comma
        c = in.peek();
        if (c != ',') {
            throw std::invalid_argument("Expected comma after category");
        }
        in.get();
        
        // Read second field (amount)
        std::string amt_str = parse_field(in);
        std::string amt_stripped = strip_outer(amt_str);
        
        // Check for empty amount
        if (amt_stripped.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        // Check for extra fields
        c = in.peek();
        if (c == ',') {
            in.get();
            std::string extra = parse_field(in);
            throw std::invalid_argument("Too many fields in data row");
        }
        if (!at_line_end_or_eof(in)) {
            throw std::invalid_argument("Invalid character after data row");
        }
        
        // Consume line ending
        consume_line_ending(in);
        
        // Parse amount
        int64_t amount = parse_int64(amt_stripped);
        
        // Check for overflow during aggregation using safe arithmetic
        int64_t current = result[cat_stripped];
        
        if (amount > 0) {
            if (current > std::numeric_limits<int64_t>::max() - amount) {
                throw std::invalid_argument("Aggregation overflow");
            }
        } else if (amount < 0) {
            // For negative amounts, check if current + amount < INT64_MIN
            // This is equivalent to: current < INT64_MIN - amount
            // But INT64_MIN - amount = INT64_MIN + |amount|, which can overflow
            // Instead: current < INT64_MIN - amount means current + amount < INT64_MIN
            // We check: if amount is negative, |amount| = -amount (but -INT64_MIN is UB)
            // Use: current < INT64_MIN - amount => current + |amount| < 0 (if we could compute it)
            // Better: check if current < INT64_MIN - amount by rearranging:
            // current + amount < INT64_MIN => current < INT64_MIN - amount
            // Since amount is negative, let's use: current < INT64_MIN + |amount|
            // But we can't compute |amount| for INT64_MIN
            // Alternative: check if current < INT64_MIN - amount by using unsigned arithmetic
            // INT64_MIN - amount = INT64_MIN + (-amount)
            // For amount = -1: INT64_MIN - (-1) = INT64_MIN + 1
            // For amount = INT64_MIN: INT64_MIN - INT64_MIN = 0 (but -INT64_MIN is UB)
            
            // Safe approach: check if current < INT64_MIN - amount
            // Since amount < 0, let's compute the threshold differently
            // current + amount < INT64_MIN
            // current < INT64_MIN - amount
            // Since amount is negative, -amount is positive (except for INT64_MIN)
            // For amount = INT64_MIN, -amount is UB, so handle separately
            
            if (amount == std::numeric_limits<int64_t>::min()) {
                // Adding INT64_MIN to anything will underflow (except INT64_MAX + INT64_MIN = -1, which is fine)
                // Actually: current + INT64_MIN < INT64_MIN when current < 0
                // current + INT64_MIN >= INT64_MIN when current >= 0
                // So underflow happens when current < 0
                if (current < 0) {
                    throw std::invalid_argument("Aggregation underflow");
                }
            } else {
                // amount is negative but not INT64_MIN, so -amount is safe
                int64_t threshold = std::numeric_limits<int64_t>::min() - amount;
                if (current < threshold) {
                    throw std::invalid_argument("Aggregation underflow");
                }
            }
        }
        
        // Aggregate
        result[cat_stripped] = current + amount;
    }
    
    return result;
}

#endif // SOLUTION_HPP
