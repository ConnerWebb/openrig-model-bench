#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <cstdint>
#include <stdexcept>
#include <cassert>
#include "solution.hpp"

void test_basic() {
    std::string csv = "category,amount\nfoo,10\nbar,20\nfoo,5";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["foo"] == 15);
    assert(result["bar"] == 20);
    std::cout << "test_basic passed\n";
}

void test_quoted_fields() {
    std::string csv = "category,amount\n\"a,b\",10\n\"x\"\"quote\",20";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["a,b"] == 10);
    assert(result["x\"quote"] == 20);
    std::cout << "test_quoted_fields passed\n";
}

void test_multiline_quoted() {
    std::string csv = "category,amount\n\"two\nlines\",100";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result.size() == 1);
    assert(result["two\nlines"] == 100);
    std::cout << "test_multiline_quoted passed\n";
}

void test_negative() {
    std::string csv = "category,amount\nfoo,-10\nbar,20\nfoo,-5";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == -15);
    assert(result["bar"] == 20);
    std::cout << "test_negative passed\n";
}

void test_with_plus() {
    std::string csv = "category,amount\nfoo,+10\nbar,+20";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == 10);
    assert(result["bar"] == 20);
    std::cout << "test_with_plus passed\n";
}

void test_strip_outer_spaces() {
    std::string csv = "category,amount\n  foo  ,  10  \n  bar  ,  20  ";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result.size() == 2);
    assert(result["foo"] == 10);
    assert(result["bar"] == 20);
    std::cout << "test_strip_outer_spaces passed\n";
}

void test_invalid_header() {
    std::string csv = "wrong,amount\nfoo,10";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_invalid_header passed\n";
    }
}

void test_wrong_field_count() {
    std::string csv = "category,amount\nfoo,10,extra";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_wrong_field_count passed\n";
    }
}

void test_empty_category() {
    std::string csv = "category,amount\n,10";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_category passed\n";
    }
}

void test_non_digit_amount() {
    std::string csv = "category,amount\nfoo,abc";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_non_digit_amount passed\n";
    }
}

void test_overflow_positive() {
    std::string csv = "category,amount\nfoo,9223372036854775808";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow_positive passed\n";
    }
}

void test_overflow_negative() {
    std::string csv = "category,amount\nfoo,-9223372036854775809";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_overflow_negative passed\n";
    }
}

void test_max_values() {
    std::string csv = "category,amount\nfoo,9223372036854775807\nbar,-9223372036854775808";
    std::istringstream in(csv);
    auto result = aggregate(in);
    assert(result["foo"] == 9223372036854775807LL);
    assert(result["bar"] == -9223372036854775808LL);
    std::cout << "test_max_values passed\n";
}

void test_unclosed_quote() {
    std::string csv = "category,amount\n\"foo,10";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_unclosed_quote passed\n";
    }
}

void test_empty_amount() {
    std::string csv = "category,amount\nfoo,";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_empty_amount passed\n";
    }
}

void test_scientific_notation_rejected() {
    std::string csv = "category,amount\nfoo,1e2";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_scientific_notation_rejected passed\n";
    }
}

void test_nan_rejected() {
    std::string csv = "category,amount\nfoo,NaN";
    std::istringstream in(csv);
    try {
        aggregate(in);
        assert(false && "Should have thrown");
    } catch (const std::invalid_argument&) {
        std::cout << "test_nan_rejected passed\n";
    }
}

void test_sorted_keys() {
    std::string csv = "category,amount\nzebra,1\napple,2\nmango,3";
    std::istringstream in(csv);
    auto result = aggregate(in);
    auto it = result.begin();
    assert(it->first == "apple");
    ++it;
    assert(it->first == "mango");
    ++it;
    assert(it->first == "zebra");
    std::cout << "test_sorted_keys passed\n";
}

int main() {
    test_basic();
    test_quoted_fields();
    test_multiline_quoted();
    test_negative();
    test_with_plus();
    test_strip_outer_spaces();
    test_invalid_header();
    test_wrong_field_count();
    test_empty_category();
    test_non_digit_amount();
    test_overflow_positive();
    test_overflow_negative();
    test_max_values();
    test_unclosed_quote();
    test_empty_amount();
    test_scientific_notation_rejected();
    test_nan_rejected();
    test_sorted_keys();
    std::cout << "All tests passed!\n";
    return 0;
}
