# CSV Category Aggregator

This repository implements a single function `aggregate(path: str) -> dict[str, str]` that reads a UTF‑8 CSV file and returns the sum of amounts for each category.

## Specification
- The CSV must have a header exactly `category,amount` (case‑sensitive, whitespace ignored).
- Records may be quoted and contain embedded newlines – the standard `csv` module handles this.
- Blank lines are ignored.
- Each non‑blank record must contain **exactly two fields**.
- `category` is stripped of surrounding whitespace and must not be empty.
- `amount` is stripped and must match the pattern:
  - optional leading `+`
  - 1‑12 decimal digits
  - optional decimal point followed by 1‑2 digits
  - non‑negative, finite, no exponent.
- Invalid input raises `ValueError`.
- Sums are calculated with `decimal.Decimal` for exact arithmetic.
- The returned dictionary is sorted by category name and each total is formatted with exactly two decimal places.

## Running the tests
```bash
python -m unittest test_solution.py
```
All public cases from `PUBLIC_CASES.json` are exercised, plus additional error checks.

## Design notes
- Uses streaming CSV reading; the file is never fully loaded into memory.
- Validation is performed manually to avoid regex overhead and to keep the logic clear.
- Decimal context defaults are sufficient because the allowed range is limited by the specification.
