import csv
import decimal
from decimal import Decimal

def aggregate(path: str) -> dict[str, str]:
    # Use Decimal for exact arithmetic
    totals: dict[str, Decimal] = {}
    # Define validation regex via manual checks
    def valid_amount(s: str) -> bool:
        # optional leading +, digits 1-12, optional . with 1-2 digits
        if not s:
            return False
        if s[0] == '+':
            s = s[1:]
        # split on decimal point
        parts = s.split('.')
        if len(parts) > 2:
            return False
        int_part = parts[0]
        if not int_part.isdigit() or not (1 <= len(int_part) <= 12):
            return False
        if len(parts) == 2:
            frac = parts[1]
            if not (1 <= len(frac) <= 2) or not frac.isdigit():
                return False
        return True

    with open(path, newline='', encoding='utf-8') as f:
        # csv reader handles quoted fields and newlines
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError('empty file')
        if [h.strip() for h in header] != ['category', 'amount']:
            raise ValueError('invalid header')
        for row in reader:
            # skip completely blank records (no fields)
            if not row:
                continue
            if len(row) != 2:
                raise ValueError('row does not have exactly two fields')
            cat_raw, amt_raw = row
            cat = cat_raw.strip()
            amt = amt_raw.strip()
            if cat == '':
                raise ValueError('empty category')
            if not valid_amount(amt):
                raise ValueError('invalid amount')
            # Convert to Decimal
            dec = Decimal(amt)
            if dec.is_nan() or dec.is_infinite() or dec < 0:
                raise ValueError('non‑negative finite amount required')
            totals[cat] = totals.get(cat, Decimal('0')) + dec
    # Prepare output sorted keys with two decimal places
    result = {k: f"{totals[k]:.2f}" for k in sorted(totals)}
    return result
