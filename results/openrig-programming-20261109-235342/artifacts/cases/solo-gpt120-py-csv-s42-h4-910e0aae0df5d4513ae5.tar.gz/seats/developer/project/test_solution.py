import unittest
import os
import json
from solution import aggregate

class TestAggregate(unittest.TestCase):
    def run_case(self, csv_content, expected):
        # write temporary file
        path = '/tmp/tmp.csv'
        with open(path, 'w', encoding='utf-8') as f:
            f.write(csv_content)
        if 'error' in expected:
            with self.assertRaises(ValueError):
                aggregate(path)
        else:
            result = aggregate(path)
            self.assertEqual(result, expected['value'])
        os.remove(path)

    def test_public_cases(self):
        # load public cases from file
        with open('PUBLIC_CASES.json', 'r', encoding='utf-8') as f:
            cases = json.load(f)
        for case in cases:
            csv = case['driver_input']['csv']
            expected = case['expected']
            with self.subTest(csv=csv[:30]):
                self.run_case(csv, expected)

if __name__ == '__main__':
    unittest.main()
