import sqlite3
import json
import time

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        cur.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT NOT NULL,
                attempts INTEGER NOT NULL,
                owner TEXT,
                lease_until REAL,
                inserted_at REAL NOT NULL
            )
        ''')
        conn.commit()
        conn.close()

    def enqueue(self, key, payload):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not isinstance(payload, (str, int, float, bool, type(None), list, dict)):
            # JSON-compatible check - try to serialize
            try:
                json.dumps(payload)
            except (TypeError, ValueError):
                raise ValueError("payload must be JSON-compatible")
        
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        inserted_at = time.time()
        payload_str = json.dumps(payload)
        cur.execute('''
            INSERT INTO jobs (key, payload, state, attempts, owner, lease_until, inserted_at)
            VALUES (?, ?, 'queued', 0, NULL, NULL, ?)
            ON CONFLICT(key) DO NOTHING
        ''', (key, payload_str, inserted_at))
        affected = cur.rowcount
        conn.commit()
        conn.close()
        return affected > 0

    def claim(self, worker, now, lease):
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")
        
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        
        # First, check for expired jobs at final attempt and mark them as failed
        cur.execute('''
            UPDATE jobs SET state = 'failed', owner = NULL, lease_until = NULL
            WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?
        ''', (now, self.max_attempts))
        
        # Find the oldest job that is queued or leased (expired) with attempts < max_attempts
        cur.execute('''
            SELECT key, payload, attempts, inserted_at
            FROM jobs
            WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
              AND attempts < ?
            ORDER BY inserted_at ASC
            LIMIT 1
        ''', (now, self.max_attempts))
        
        row = cur.fetchone()
        if row is None:
            conn.close()
            return None
        
        key, payload_str, attempts, inserted_at = row
        new_attempts = attempts + 1
        lease_until = now + lease
        
        cur.execute('''
            UPDATE jobs
            SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
            WHERE key = ?
        ''', (worker, lease_until, new_attempts, key))
        
        conn.commit()
        conn.close()
        
        payload = json.loads(payload_str)
        return {"key": key, "payload": payload, "attempts": new_attempts}

    def complete(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        
        cur.execute('''
            SELECT owner, state FROM jobs WHERE key = ?
        ''', (key,))
        
        row = cur.fetchone()
        if row is None:
            conn.close()
            return False
        
        owner, state = row
        if owner != worker:
            conn.close()
            return False
        
        cur.execute('''
            UPDATE jobs SET state = 'done' WHERE key = ?
        ''', (key,))
        
        conn.commit()
        conn.close()
        return True

    def fail(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        
        cur.execute('''
            SELECT owner, state, attempts FROM jobs WHERE key = ?
        ''', (key,))
        
        row = cur.fetchone()
        if row is None:
            conn.close()
            return False
        
        owner, state, attempts = row
        if owner != worker:
            conn.close()
            return False
        
        if attempts >= self.max_attempts:
            # Mark as failed
            cur.execute('''
                UPDATE jobs SET state = 'failed', owner = NULL, lease_until = NULL WHERE key = ?
            ''', (key,))
        else:
            # Re-queue
            cur.execute('''
                UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?
            ''', (key,))
        
        conn.commit()
        conn.close()
        return True

    def status(self, key):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        
        cur.execute('''
            SELECT state, attempts, lease_until FROM jobs WHERE key = ?
        ''', (key,))
        
        row = cur.fetchone()
        conn.close()
        
        if row is None:
            return None
        
        state, attempts, lease_until = row
        
        # If the job is leased and has expired and is at max_attempts, it should be considered failed
        if state == 'leased' and lease_until is not None and attempts >= self.max_attempts:
            # We need to check if lease has expired - but we don't have 'now' here
            # The status method doesn't receive 'now', so we can't determine if it's expired
            # Looking at the test case, it seems like the status should reflect the current state
            # after any expired final-attempt jobs have been marked as failed
            pass
        
        return {"state": state, "attempts": attempts}
