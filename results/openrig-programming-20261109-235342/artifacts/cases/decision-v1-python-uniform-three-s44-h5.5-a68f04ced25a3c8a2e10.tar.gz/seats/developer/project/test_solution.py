import unittest
import tempfile
import os
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.temp_dir)

    def test_enqueue_first_wins(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("key1", {"data": 1}))
        self.assertFalse(q.enqueue("key1", {"data": 2}))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_claim_returns_oldest(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", 1)
        q.enqueue("b", 2)
        result = q.claim("worker1", 100.0, 10.0)
        self.assertEqual(result["key"], "a")
        self.assertEqual(result["attempts"], 1)

    def test_claim_expired_leased_job(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", 1)
        # Manually set as leased with expired time
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        conn.execute("UPDATE jobs SET state='leased', owner='w1', lease_until=50 WHERE key='a'")
        conn.commit()
        conn.close()
        
        result = q.claim("worker2", 100.0, 10.0)
        self.assertEqual(result["key"], "a")
        self.assertEqual(result["attempts"], 1)

    def test_complete_requires_owner(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", 1)
        q.claim("worker1", 100.0, 10.0)
        self.assertFalse(q.complete("a", "wrong_worker"))
        self.assertTrue(q.complete("a", "worker1"))
        status = q.status("a")
        self.assertEqual(status["state"], "done")

    def test_fail_requeues_if_attempts_remaining(self):
        q = JobQueue(self.db_path, max_attempts=3)
        q.enqueue("a", 1)
        q.claim("worker1", 100.0, 10.0)
        self.assertTrue(q.fail("a", "worker1"))
        status = q.status("a")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 1)

    def test_fail_marks_failed_at_max_attempts(self):
        q = JobQueue(self.db_path, max_attempts=2)
        q.enqueue("a", 1)
        q.claim("worker1", 100.0, 10.0)
        q.fail("a", "worker1")
        q.claim("worker1", 100.0, 10.0)
        self.assertTrue(q.fail("a", "worker1"))
        status = q.status("a")
        self.assertEqual(status["state"], "failed")

    def test_status_returns_none_for_unknown_key(self):
        q = JobQueue(self.db_path)
        self.assertIsNone(q.status("unknown"))

    def test_value_error_invalid_key(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue("", "payload")
        with self.assertRaises(ValueError):
            q.claim("", 0, 1)
        with self.assertRaises(ValueError):
            q.complete("", "worker")
        with self.assertRaises(ValueError):
            q.fail("", "worker")
        with self.assertRaises(ValueError):
            q.status("")

    def test_value_error_invalid_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("a", 1)
        with self.assertRaises(ValueError):
            q.claim("", 0, 1)
        with self.assertRaises(ValueError):
            q.complete("a", "")
        with self.assertRaises(ValueError):
            q.fail("a", "")

    def test_value_error_invalid_lease(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.claim("worker", 0, 0)
        with self.assertRaises(ValueError):
            q.claim("worker", 0, -1)

    def test_value_error_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_claim_returns_none_when_no_jobs(self):
        q = JobQueue(self.db_path)
        self.assertIsNone(q.claim("worker", 0, 1))

    def test_claim_respects_max_attempts(self):
        q = JobQueue(self.db_path, max_attempts=1)
        q.enqueue("a", 1)
        result = q.claim("worker1", 0, 5)
        self.assertIsNotNone(result)
        # After max attempts, should not be claimable
        result2 = q.claim("worker2", 100, 5)
        self.assertIsNone(result2)

    def test_expired_final_attempt_becomes_failed(self):
        q = JobQueue(self.db_path, max_attempts=1)
        q.enqueue("a", 1)
        # Claim it
        q.claim("worker1", 0, 5)
        # Now try to claim again after lease expires - should not get it
        result = q.claim("worker2", 100, 5)
        self.assertIsNone(result)
        status = q.status("a")
        self.assertEqual(status["state"], "failed")

    def test_payload_json_compatibility(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("a", {"nested": {"key": "value"}}))
        self.assertTrue(q.enqueue("b", [1, 2, 3]))
        self.assertTrue(q.enqueue("c", None))
        self.assertTrue(q.enqueue("d", True))
        self.assertTrue(q.enqueue("e", 3.14))

if __name__ == '__main__':
    unittest.main()
