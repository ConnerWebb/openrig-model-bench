# JobQueue - SQLite-based Job Queue Implementation

A thread-safe job queue implementation using SQLite for persistence, supporting atomic claim operations, lease management, and retry logic.

## API

### JobQueue(path, max_attempts=3)

Initialize a job queue backed by SQLite database at `path`.

- `path`: Path to SQLite database file
- `max_attempts`: Maximum number of times a job can be claimed (default: 3)

### Methods

#### enqueue(key, payload) -> bool
Add a new job to the queue.

- `key`: Unique string identifier for the job
- `payload`: JSON-compatible value to store with the job
- Returns `True` if job was inserted, `False` if key already exists

#### claim(worker, now, lease) -> dict or None
Atomically claim the oldest available job.

- `worker`: Name/ID of the worker claiming the job
- `now`: Current timestamp (float)
- `lease`: Lease duration in seconds (must be > 0)
- Returns `{"key": str, "payload": any, "attempts": int}` or `None` if no jobs available

Claims the oldest job that is:
- In `queued` state, OR
- In `leased` state with `lease_until <= now` (expired lease)

And has `attempts < max_attempts`.

#### complete(key, worker) -> bool
Mark a claimed job as complete.

- `key`: Job key
- `worker`: Must match the current owner
- Returns `True` if successful, `False` otherwise

#### fail(key, worker) -> bool
Mark a claimed job as failed (re-queue or mark permanently failed).

- `key`: Job key
- `worker`: Must match the current owner
- If `attempts < max_attempts`: re-queues the job
- If `attempts >= max_attempts`: marks job as permanently failed
- Returns `True` if successful, `False` otherwise

#### status(key) -> dict or None
Get the current status of a job.

- `key`: Job key
- Returns `{"state": str, "attempts": int}` or `None` if key not found

## State Machine

```
queued --claim--> leased --complete--> done
    |               |
    |               +--fail (attempts < max)--> queued
    |               +--fail (attempts >= max)--> failed
    +--claim (max attempts)--> failed
```

## Validation

All methods raise `ValueError` for:
- Empty or non-string `key` or `worker`
- Non-positive `lease` duration
- Non-positive `max_attempts`

## Thread Safety

Multiple processes/threads can safely share the same database file. SQLite handles concurrency.

## Example

```python
from solution import JobQueue

q = JobQueue("/tmp/queue.db", max_attempts=3)

# Add jobs
q.enqueue("job1", {"task": "process_data"})
q.enqueue("job2", {"task": "send_email"})

# Claim and process
result = q.claim("worker1", 1000.0, 60.0)
if result:
    print(f"Processing {result['key']}")
    # ... do work ...
    q.complete(result["key"], "worker1")
```
