# BoundedQueue

Thread-safe bounded blocking queue in C++20.

## API

```cpp
template<class T>
class BoundedQueue {
public:
    explicit BoundedQueue(size_t capacity); // throws if capacity == 0
    bool push(T value); // blocks while full, returns false after close
    std::optional<T> pop(); // blocks while empty/open, nullopt after close
    void close(); // idempotent, wakes all waiters
};
```

## Build & Test

```bash
clang++ -std=c++20 -pthread -o solution_test solution_test.cpp
./solution_test
```

## Driver

```bash
clang++ -std=c++20 -pthread -o driver PUBLIC_DRIVER.cpp solution.hpp
echo "0 4 0 1" | ./driver
```
