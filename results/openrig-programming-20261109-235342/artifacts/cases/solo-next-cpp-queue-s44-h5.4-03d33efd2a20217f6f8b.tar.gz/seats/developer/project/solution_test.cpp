#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <atomic>
#include <cassert>
#include <optional>
#include <queue>
#include <chrono>
#include "solution.hpp"

void test_basic_push_pop() {
    BoundedQueue<int> q(2);
    assert(q.push(1));
    assert(q.push(2));
    assert(!q.push(3));
    auto v1 = q.pop();
    assert(v1.has_value() && *v1 == 1);
    auto v2 = q.pop();
    assert(v2.has_value() && *v2 == 2);
    assert(!q.pop().has_value());
}

void test_zero_capacity() {
    bool threw = false;
    try {
        BoundedQueue<int> q(0);
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    assert(threw);
}

void test_close_wakes_all() {
    BoundedQueue<int> q(1);
    std::atomic<bool> p1_done{false}, p2_done{false};
    std::thread p1([&] { 
        bool ok = q.push(1); 
        p1_done = true; 
        (void)ok; 
    });
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    std::thread p2([&] { 
        bool ok = q.push(2); 
        p2_done = true; 
        (void)ok; 
    });
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    q.close();
    p1.join();
    p2.join();
    auto v1 = q.pop();
    auto v2 = q.pop();
    assert(v1.has_value() && !v2.has_value());
}

void test_move_only_type() {
    BoundedQueue<std::unique_ptr<int>> q(2);
    q.push(std::make_unique<int>(42));
    q.push(std::make_unique<int>(43));
    auto v1 = q.pop();
    auto v2 = q.pop();
    assert(v1.has_value() && **v1 == 42);
    assert(v2.has_value() && **v2 == 43);
}

void test_close_idempotent() {
    BoundedQueue<int> q(2);
    q.close();
    q.close();
    assert(!q.push(1));
    assert(!q.pop().has_value());
}

void test_producer_consumer() {
    BoundedQueue<int> q(10);
    std::vector<int> got;
    std::mutex m;
    std::thread consumer([&] {
        while (auto v = q.pop()) {
            std::lock_guard<std::mutex> lock(m);
            got.push_back(*v);
        }
    });
    std::thread producer([&] {
        for (int i = 0; i < 100; ++i) {
            q.push(i);
        }
        q.close();
    });
    producer.join();
    consumer.join();
    assert(got.size() == 100);
}

int main() {
    test_basic_push_pop();
    test_zero_capacity();
    test_close_wakes_all();
    test_move_only_type();
    test_close_idempotent();
    test_producer_consumer();
    std::cout << "All tests passed." << std::endl;
    return 0;
}
