#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"
std::string js(const std::string&s){std::ostringstream o;o<<'"';for(unsigned char c:s){if(c=='"'||c=='\\')o<<'\\'<<c;else if(c=='\n')o<<"\\n";else if(c=='\r')o<<"\\r";else if(c=='\t')o<<"\\t";else if(c<32)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)c<<std::dec;else o<<c;}o<<'"';return o.str();}
int main(){try{
int mode,cap,n,p;std::cin>>mode>>cap>>n>>p;if(mode==0){BoundedQueue<int> q(cap);q.close();q.close();std::cout<<"{\"value\":["<<(q.push(1)?"true":"false")<<','<<(q.pop()?"true":"false")<<"]}";}else if(mode==3){BoundedQueue<int> q(1);q.push(17);std::atomic<bool> started=false,accepted=true;std::thread t([&]{started=true;accepted=q.push(23);});while(!started.load())std::this_thread::yield();q.close();t.join();auto a=q.pop(),b=q.pop();std::cout<<"{\"value\":["<<(accepted?"true":"false")<<','<<a.value_or(-1)<<','<<(b?"true":"false")<<"]}";}else if(mode==2){BoundedQueue<std::unique_ptr<int>> q(cap);q.push(std::make_unique<int>(n));q.close();auto v=q.pop();std::cout<<"{\"value\":"<<**v<<'}';}else{BoundedQueue<int> q(cap);std::vector<int> got;std::mutex m;std::vector<std::thread> workers;for(int j=0;j<p;j++)workers.emplace_back([&]{while(auto v=q.pop()){std::lock_guard l(m);got.push_back(*v);}});std::vector<std::thread> prod;for(int j=0;j<p;j++)prod.emplace_back([&,j]{for(int i=j;i<n;i+=p){if(!q.push(i))throw std::runtime_error("closed early");std::this_thread::yield();}});for(auto&t:prod)t.join();q.close();for(auto&t:workers)t.join();std::sort(got.begin(),got.end());std::cout<<"{\"value\":[";for(std::size_t i=0;i<got.size();i++){if(i)std::cout<<',';std::cout<<got[i];}std::cout<<"]}";}
}catch(const std::exception&e){std::cout<<"{\"error\":\"ValueError\"}";}catch(...){std::cout<<"{\"error\":\"ValueError\"}";}std::cout<<std::endl;}
