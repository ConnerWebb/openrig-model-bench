"""CSV category amount aggregator with exact decimal arithmetic."""

import csv
import io
import re
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    """
    Read a UTF-8 CSV file and aggregate amounts by category.
    
    Args:
        path: Path to the CSV file.
        
    Returns:
        Dictionary with category keys (sorted) and totals formatted
        with exactly two decimal places.
        
    Raises:
        ValueError: If the CSV is malformed.
    """
    # Pattern for valid amount: optional +, 1-12 digits, optional . followed by 1-2 digits
    amount_pattern = re.compile(r'^\+?[0-9]{1,12}(\.[0-9]{1,2})?$')
    
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        # Use csv.reader to handle quoted fields, embedded commas, and newlines
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("CSV file is empty")
        
        if len(header) != 2 or header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly 'category,amount'")
        
        # Process data rows
        for row_num, row in enumerate(reader, start=2):
            # Skip completely blank records (empty list from csv.reader)
            if len(row) == 0:
                continue
            
            # Every non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Row {row_num}: expected exactly 2 fields, got {len(row)}")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError(f"Row {row_num}: category cannot be empty")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Row {row_num}: invalid amount format '{amount_str}'")
            
            # Parse and accumulate using exact decimal arithmetic
            try:
                amount = Decimal(amount_str)
                # Check for non-finite values (though regex should prevent this)
                if not amount.is_finite():
                    raise ValueError(f"Row {row_num}: amount must be finite")
            except InvalidOperation:
                raise ValueError(f"Row {row_num}: invalid amount '{amount_str}'")
            
            totals[category] = totals.get(category, Decimal('0')) + amount
    
    # Format totals with exactly two decimal places and sort keys
    return {k: str(v.quantize(Decimal('0.01'))) for k, v in sorted(totals.items())}
