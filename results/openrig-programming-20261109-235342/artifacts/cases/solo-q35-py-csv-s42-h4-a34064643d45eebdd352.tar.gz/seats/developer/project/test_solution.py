"""Tests for the CSV category amount aggregator."""

import tempfile
import os
import unittest
from decimal import Decimal
from solution import aggregate


def write_csv_tempfile(csv_content: str) -> str:
    """Helper to write CSV content to a temporary file."""
    fd, path = tempfile.mkstemp(suffix='.csv', text=True)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
            f.write(csv_content)
        return path
    except:
        os.close(fd)
        raise


class TestAggregate(unittest.TestCase):
    """Test cases for the aggregate function."""

    def test_basic_aggregation(self):
        """Test basic aggregation of amounts by category."""
        csv_content = """category,amount
food,347.25
rent,991.77
food,261.47
rent,345.17"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '608.72', 'rent': '1336.94'})
        finally:
            os.unlink(path)

    def test_sorted_keys(self):
        """Test that returned keys are sorted."""
        csv_content = """category,amount
zebra,100.00
apple,200.00
mango,300.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(list(result.keys()), ['apple', 'mango', 'zebra'])
        finally:
            os.unlink(path)

    def test_quoted_field_with_comma(self):
        """Test handling of quoted fields containing commas."""
        csv_content = """category,amount
"a,b",599.14
food,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            # The csv module strips the quotes - they are delimiters, not data
            self.assertEqual(result, {'a,b': '599.14', 'food': '100.00'})
        finally:
            os.unlink(path)

    def test_quoted_field_with_embedded_newline(self):
        """Test handling of quoted fields containing newlines."""
        csv_content = """category,amount
"two
lines",849.77
food,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertIn('two\nlines', result)
            self.assertEqual(result['two\nlines'], '849.77')
        finally:
            os.unlink(path)

    def test_quoted_field_with_escaped_quotes(self):
        """Test handling of quoted fields with escaped quotes."""
        csv_content = """category,amount
"x""quote",812.68
food,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertIn('x"quote', result)
            self.assertEqual(result['x"quote'], '812.68')
        finally:
            os.unlink(path)

    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = """category,amount
  food  ,  347.25  
 rent , 991.77"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertIn('food', result)
            self.assertIn('rent', result)
            self.assertEqual(result['food'], '347.25')
            self.assertEqual(result['rent'], '991.77')
        finally:
            os.unlink(path)

    def test_blank_lines_ignored(self):
        """Test that completely blank lines are ignored."""
        csv_content = """category,amount
food,100.00

rent,200.00

"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
        finally:
            os.unlink(path)

    def test_unicode_categories(self):
        """Test handling of unicode category names."""
        # Use proper regular comma (U+002C)
        csv_content = "category,amount\n日本,690.39\n日本,218.62\nfood,100.00\n"
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertIn('日本', result)
            self.assertEqual(result['日本'], '909.01')
        finally:
            os.unlink(path)

    def test_optional_plus_sign(self):
        """Test that optional + sign is accepted."""
        csv_content = """category,amount
food,+347.25
rent,991.77"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '347.25', 'rent': '991.77'})
        finally:
            os.unlink(path)

    def test_max_digits_allowed(self):
        """Test that 12 digits are allowed."""
        csv_content = """category,amount
food,123456789012.12
rent,123456789012"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result['food'], '123456789012.12')
            self.assertEqual(result['rent'], '123456789012.00')
        finally:
            os.unlink(path)

    def test_too_many_digits_rejected(self):
        """Test that more than 12 digits is rejected."""
        csv_content = """category,amount
food,1234567890123.12"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_three_decimal_places_rejected(self):
        """Test that more than 2 decimal places is rejected."""
        csv_content = """category,amount
food,123.123"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_scientific_notation_rejected(self):
        """Test that scientific notation is rejected."""
        csv_content = """category,amount
food,1e2"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_nan_rejected(self):
        """Test that NaN is rejected."""
        csv_content = """category,amount
food,NaN"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_empty_category_rejected(self):
        """Test that empty category is rejected."""
        csv_content = """category,amount
,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_wrong_header_rejected(self):
        """Test that wrong header is rejected."""
        csv_content = """wrong,amount
food,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_too_many_fields_rejected(self):
        """Test that rows with too many fields are rejected."""
        csv_content = """category,amount
food,100.00,extra"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_too_few_fields_rejected(self):
        """Test that rows with too few fields are rejected."""
        csv_content = """category,amount
food"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_empty_csv_rejected(self):
        """Test that empty CSV file is rejected."""
        csv_content = ""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_header_only(self):
        """Test CSV with only header."""
        csv_content = """category,amount"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {})
        finally:
            os.unlink(path)

    def test_single_record(self):
        """Test single data record."""
        csv_content = """category,amount
food,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.00'})
        finally:
            os.unlink(path)

    def test_amount_without_decimal(self):
        """Test amounts without decimal point."""
        csv_content = """category,amount
food,100
rent,200"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
        finally:
            os.unlink(path)

    def test_amount_with_one_decimal(self):
        """Test amounts with one decimal place."""
        csv_content = """category,amount
food,100.5
rent,200.7"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '100.50', 'rent': '200.70'})
        finally:
            os.unlink(path)

    def test_large_aggregation(self):
        """Test aggregation with many records."""
        csv_content = "category,amount\n"
        for i in range(100):
            csv_content += f"food,{i}.50\n"
            csv_content += f"rent,{i}.25\n"
        
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            # Sum of i.50 for i in 0..99 = sum(i) + 0.50*100 = 4950 + 50 = 5000.00
            # Sum of i.25 for i in 0..99 = sum(i) + 0.25*100 = 4950 + 25 = 4975.00
            self.assertEqual(result['food'], '5000.00')
            self.assertEqual(result['rent'], '4975.00')
        finally:
            os.unlink(path)

    def test_negative_amount_rejected(self):
        """Test that negative amounts are rejected."""
        csv_content = """category,amount
food,-100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_zero_amount_accepted(self):
        """Test that zero amount is accepted."""
        csv_content = """category,amount
food,0
rent,0.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {'food': '0.00', 'rent': '0.00'})
        finally:
            os.unlink(path)

    def test_whitespace_only_category_rejected(self):
        """Test that whitespace-only category is rejected."""
        csv_content = """category,amount
   ,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)

    def test_complex_quoted_field(self):
        """Test complex quoted field with multiple special characters."""
        csv_content = """category,amount
"category, with ""quotes"" and, comma",123.45
food,100.00"""
        path = write_csv_tempfile(csv_content)
        try:
            result = aggregate(path)
            self.assertIn('category, with "quotes" and, comma', result)
            self.assertEqual(result['category, with "quotes" and, comma'], '123.45')
        finally:
            os.unlink(path)


if __name__ == '__main__':
    unittest.main()
