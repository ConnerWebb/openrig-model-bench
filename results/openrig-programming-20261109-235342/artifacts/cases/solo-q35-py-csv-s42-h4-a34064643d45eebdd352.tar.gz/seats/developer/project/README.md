# CSV Category Amount Aggregator

A Python module that reads UTF-8 CSV files and aggregates monetary amounts by category using exact decimal arithmetic.

## Function Signature

```python
def aggregate(path: str) -> dict[str, str]
```

## Usage

```python
from solution import aggregate

result = aggregate('data.csv')
# Returns: {'category1': '123.45', 'category2': '678.90', ...}
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount` (case-sensitive)
- **Records**: Each data row must have exactly two fields
- **Category**: Non-empty string (whitespace is stripped)
- **Amount**: Must match the pattern `\+?[0-9]{1,12}(\.[0-9]{1,2})?`
  - Optional leading `+`
  - 1 to 12 decimal digits
  - Optional decimal point followed by 1 or 2 digits
  - Nonnegative and finite values only
  - No scientific notation (e.g., `1e2` is invalid)

## Features

- **Streaming CSV parsing**: Uses Python's `csv` module to handle quoted fields, embedded commas, and embedded newlines correctly
- **Exact decimal arithmetic**: Uses Python's `decimal.Decimal` for precise monetary calculations
- **Sorted output**: Returns dictionary with category keys in sorted order
- **Formatted totals**: All totals are formatted with exactly two decimal places

## Error Handling

Raises `ValueError` for:
- Empty CSV file
- Header not exactly `category,amount`
- Rows with incorrect number of fields
- Empty category names
- Invalid amount formats (wrong digit count, scientific notation, NaN, etc.)

## Example

Input CSV:
```csv
category,amount
food,347.25
rent,991.77
food,261.47
rent,345.17
```

Output:
```python
{
    'food': '608.72',
    'rent': '1336.94'
}
```

## Implementation Notes

- The CSV is parsed as a stream; the entire file is not loaded into memory at once
- Python's `csv.reader` handles RFC 4180 compliant CSV parsing including:
  - Quoted fields with embedded commas
  - Quoted fields with embedded newlines
  - Escaped quotes (doubled quotes `""`)
- Decimal arithmetic ensures no floating-point rounding errors
