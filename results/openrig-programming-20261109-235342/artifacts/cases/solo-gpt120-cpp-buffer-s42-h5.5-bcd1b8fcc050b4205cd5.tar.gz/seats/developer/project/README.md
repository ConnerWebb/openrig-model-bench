# Buffer Library

This repository provides a small `Buffer` class implementing a mutable byte array with safe semantics.

## Features
- **RAII management** using `std::unique_ptr<uint8_t[]>` – no manual `delete`.
- Deep‑copy copy‑constructor and copy‑assignment.
- noexcept move‑constructor and move‑assignment; moved‑from objects become empty and reusable.
- Bounds‑checked element access (`operator[]`) throwing `std::out_of_range`.
- `resize` preserves existing data, zero‑initialises any newly allocated bytes, and works for both growth and shrinkage.
- `size()` returns the current number of bytes.

## Usage Example
```cpp
#include "solution.hpp"

int main() {
    Buffer buf(4);          // creates 4 zero‑initialized bytes
    buf[0] = 0xAA;
    buf[1] = 0xBB;
    buf.resize(6);          // new bytes are zero‑filled
    // buf now contains: AA BB 00 00 00 00
}
```

## Building & Testing
The project uses the standard C++20 toolchain (Clang 22). Tests are written with GoogleTest and can be run via the provided `run_tests` command.

```bash
# compile and run tests (handled by the evaluation harness)
run_tests
```

All tests should pass, confirming correct behavior of construction, copy/move semantics, bounds checking, and resizing.
