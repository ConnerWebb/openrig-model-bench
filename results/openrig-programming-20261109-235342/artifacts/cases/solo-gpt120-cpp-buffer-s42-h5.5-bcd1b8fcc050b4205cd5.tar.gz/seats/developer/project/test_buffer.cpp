#include <iostream>
#include <stdexcept>
#include "solution.hpp"

int main() {
    // Helper lambda for reporting failures
    auto ok = [](bool cond, const char* msg){ if(!cond){ std::cerr << "FAIL: " << msg << std::endl; return false; } return true; };
    // Default construction
    Buffer buf;
    if(!ok(buf.size()==0, "default size")) return 1;
    try{ buf[0]; return 1; } catch(const std::out_of_range&){ }
    // Construction and access
    Buffer buf5(5);
    if(!ok(buf5.size()==5, "size5")) return 1;
    for(size_t i=0;i<buf5.size();++i){ if(!ok(buf5[i]==0, "zero init")) return 1; buf5[i]=static_cast<std::uint8_t>(i+1); }
    for(size_t i=0;i<buf5.size();++i){ if(!ok(buf5[i]==static_cast<std::uint8_t>(i+1), "value set")) return 1; }
    try{ buf5[5]; return 1; } catch(const std::out_of_range&){ }
    // Copy semantics
    Buffer copy = buf5;
    if(!ok(copy.size()==5 && copy[2]==3, "copy ctor")) return 1;
    copy[1]=99; if(!ok(buf5[1]==2, "copy independence")) return 1;
    Buffer assign; assign = buf5; if(!ok(assign.size()==5 && assign[4]==5, "copy assign")) return 1;
    // Move semantics
    Buffer src(2); src[0]=5; src[1]=6;
    Buffer moved = std::move(src);
    if(!ok(moved.size()==2 && moved[0]==5 && src.size()==0, "move ctor")) return 1;
    Buffer dst; dst = std::move(moved);
    if(!ok(dst.size()==2 && dst[1]==6 && moved.size()==0, "move assign")) return 1;
    // Resize preserve
    Buffer rbuf(3); rbuf[0]=1; rbuf[1]=2; rbuf[2]=3;
    rbuf.resize(5);
    if(!ok(rbuf.size()==5 && rbuf[0]==1 && rbuf[3]==0 && rbuf[4]==0, "resize grow")) return 1;
    rbuf.resize(2);
    if(!ok(rbuf.size()==2 && rbuf[0]==1 && rbuf[1]==2, "resize shrink")) return 1;
    // Self assignment
    Buffer self(2); self[0]=7; self[1]=8;
    self = self; if(!ok(self[0]==7 && self[1]==8, "self copy assign")) return 1;
    self = std::move(self); if(!ok(self[0]==7 && self[1]==8, "self move assign")) return 1;
    std::cout << "All tests passed" << std::endl;
    return 0;
}
