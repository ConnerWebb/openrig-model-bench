#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <memory>

class Buffer {
    std::unique_ptr<std::uint8_t[]> p_; // managed array
    std::size_t n_ = 0;
public:
    // Constructors
    Buffer(std::size_t n = 0) : p_(n ? new std::uint8_t[n] : nullptr), n_(n) {
        // zero-initialize new buffer
        if (p_) std::fill_n(p_.get(), n_, 0);
    }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p_(other.n_ ? new std::uint8_t[other.n_] : nullptr), n_(other.n_) {
        if (p_) std::copy_n(other.p_.get(), n_, p_.get());
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            Buffer tmp(other); // copy‑and‑swap idiom
            swap(tmp);
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p_(std::move(other.p_)), n_(other.n_) {
        other.n_ = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            p_ = std::move(other.p_);
            n_ = other.n_;
            other.n_ = 0;
        }
        return *this;
    }

    // Destructor (default works with unique_ptr)
    ~Buffer() = default;

    // Size accessor
    std::size_t size() const noexcept { return n_; }

    // Bounds‑checked element access (mutable)
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n_) throw std::out_of_range("Buffer index out of range");
        return p_[i];
    }

    // Bounds‑checked element access (const)
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n_) throw std::out_of_range("Buffer index out of range");
        return p_[i];
    }

    // Resize while preserving existing prefix and zero‑initializing new bytes
    void resize(std::size_t k) {
        if (k == n_) return;
        std::unique_ptr<std::uint8_t[]> new_buf(k ? new std::uint8_t[k] : nullptr);
        if (new_buf) {
            // copy the common prefix
            std::size_t copy_len = std::min(n_, k);
            if (copy_len) std::copy_n(p_.get(), copy_len, new_buf.get());
            // zero‑initialize any newly added elements
            if (k > n_) std::fill_n(new_buf.get() + n_, k - n_, 0);
        }
        p_ = std::move(new_buf);
        n_ = k;
    }

    // Swap helper
    void swap(Buffer& other) noexcept {
        using std::swap;
        swap(p_, other.p_);
        swap(n_, other.n_);
    }
};

// Enable ADL swap
inline void swap(Buffer& a, Buffer& b) noexcept { a.swap(b); }
