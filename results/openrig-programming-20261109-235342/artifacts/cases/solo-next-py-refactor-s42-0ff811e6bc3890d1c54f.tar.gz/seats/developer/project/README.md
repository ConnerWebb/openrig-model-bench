# Ledger

A simple ledger processing module that validates, deduplicates, and aggregates financial records.

## Overview

The `ledger` module provides a `process()` function that:

- Validates each record has required fields with correct types
- Deduplicates records by ID (first occurrence wins)
- Optionally filters records by minimum cents value
- Returns events in input order with totals aggregated by category

## Installation

No external dependencies required. Uses Python 3.14 stdlib only.

## Usage

```python
from ledger import process

records = [
    {'id': 'a', 'category': 'food', 'cents': 1500},
    {'id': 'b', 'category': 'transport', 'cents': 2000},
    {'id': 'c', 'category': 'food', 'cents': 750},
]

result = process(records)
print(result)
# {'events': [...], 'totals': {'food': 2250, 'transport': 2000}}
```

### Filtering by minimum cents

```python
result = process(records, minimum_cents=1000)
# Only includes records with cents >= 1000
```

## Record Format

Each record must be a dictionary with:

- `id`: non-empty string (whitespace is stripped)
- `category`: non-empty string (whitespace is stripped)
- `cents`: non-negative integer (booleans are invalid)

## Validation

The module raises `ValueError` for:

- Missing required fields
- Invalid field types
- Empty strings after stripping
- Negative cents values
- Boolean values for cents or minimum_cents
- Duplicate IDs (first occurrence wins)

## API

### `process(records, minimum_cents=0)`

Process a list of records and return events with totals.

**Args:**
- `records`: List of record dictionaries
- `minimum_cents`: Filter threshold (default: 0)

**Returns:**
```python
{
    'events': [
        {'id': str, 'category': str, 'cents': int},
        ...
    ],
    'totals': {
        'category': int,  # Sum of cents per category
        ...
    }
}
```

**Raises:**
- `ValueError`: If any record is invalid

## Testing

Run tests with:
```bash
python -m unittest test_ledger
```
