"""Ledger engine implementation - internal module."""

from typing import Any


def _validate_record(record: Any) -> dict:
    """Validate a single record and return normalized form.
    
    Args:
        record: The record to validate
        
    Returns:
        Normalized record dict with stripped strings
        
    Raises:
        ValueError: If record is invalid
    """
    # Must be a dict
    if not isinstance(record, dict):
        raise ValueError("Record must be a dictionary")
    
    # Check required keys exist
    if 'id' not in record or 'category' not in record or 'cents' not in record:
        raise ValueError("Record must have id, category, and cents fields")
    
    record_id = record['id']
    category = record['category']
    cents = record['cents']
    
    # Validate id: must be nonempty stripped string
    if not isinstance(record_id, str):
        raise ValueError("id must be a string")
    record_id = record_id.strip()
    if not record_id:
        raise ValueError("id must be non-empty after stripping")
    
    # Validate category: must be nonempty stripped string
    if not isinstance(category, str):
        raise ValueError("category must be a string")
    category = category.strip()
    if not category:
        raise ValueError("category must be non-empty after stripping")
    
    # Validate cents: must be nonnegative integer (not boolean)
    if isinstance(cents, bool):
        raise ValueError("cents must be an integer, not a boolean")
    if not isinstance(cents, int):
        raise ValueError("cents must be an integer")
    if cents < 0:
        raise ValueError("cents must be non-negative")
    
    return {'id': record_id, 'category': category, 'cents': cents}


def process(records: list, minimum_cents: int = 0) -> dict:
    """Process records and return events with totals.
    
    Args:
        records: List of record dicts with id, category, cents
        minimum_cents: Filter threshold (nonnegative integer, not boolean)
        
    Returns:
        {'events': [...], 'totals': {category: sum_cents}}
        
    Raises:
        ValueError: If any record is invalid
    """
    # Validate minimum_cents parameter
    if isinstance(minimum_cents, bool):
        raise ValueError("minimum_cents must be an integer, not a boolean")
    if not isinstance(minimum_cents, int):
        raise ValueError("minimum_cents must be an integer")
    if minimum_cents < 0:
        raise ValueError("minimum_cents must be non-negative")
    
    # Handle empty input
    if not records:
        return {'events': [], 'totals': {}}
    
    # First pass: validate all records (including duplicates)
    seen_ids = set()
    validated_records = []
    
    for record in records:
        normalized = _validate_record(record)
        # Check for duplicate id (first occurrence wins - silently skip)
        if normalized['id'] not in seen_ids:
            seen_ids.add(normalized['id'])
            validated_records.append(normalized)
    
    # Apply minimum_cents filter and build result
    events = []
    totals_dict = {}
    
    for record in validated_records:
        if record['cents'] >= minimum_cents:
            events.append(record)
            category = record['category']
            if category in totals_dict:
                totals_dict[category] += record['cents']
            else:
                totals_dict[category] = record['cents']
    
    # Sort totals keys
    sorted_totals = dict(sorted(totals_dict.items()))
    
    return {'events': events, 'totals': sorted_totals}
