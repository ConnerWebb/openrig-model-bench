"""Tests for ledger module."""

import unittest
from ledger import process


class TestLedgerProcess(unittest.TestCase):
    """Tests for process() function."""
    
    def test_empty_input(self):
        """process([]) returns empty events/totals."""
        result = process([])
        self.assertEqual(result, {'events': [], 'totals': {}})
    
    def test_empty_input_with_minimum_cents(self):
        """process([], minimum_cents=5) returns empty events/totals."""
        result = process([], minimum_cents=5)
        self.assertEqual(result, {'events': [], 'totals': {}})
    
    def test_single_valid_record(self):
        """Single valid record is returned correctly."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 100}]
        result = process(records)
        self.assertEqual(result['events'], [{'id': 'a', 'category': 'cat1', 'cents': 100}])
        self.assertEqual(result['totals'], {'cat1': 100})
    
    def test_multiple_records_totals(self):
        """Totals are summed correctly per category."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 100},
            {'id': 'b', 'category': 'cat1', 'cents': 50},
            {'id': 'c', 'category': 'cat2', 'cents': 25},
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 3)
        self.assertEqual(result['totals'], {'cat1': 150, 'cat2': 25})
    
    def test_totals_keys_sorted(self):
        """Totals keys are sorted alphabetically."""
        records = [
            {'id': 'a', 'category': 'zebra', 'cents': 10},
            {'id': 'b', 'category': 'apple', 'cents': 20},
            {'id': 'c', 'category': 'mango', 'cents': 30},
        ]
        result = process(records)
        self.assertEqual(list(result['totals'].keys()), ['apple', 'mango', 'zebra'])
    
    def test_minimum_cents_filter(self):
        """minimum_cents filters records correctly."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 10},
            {'id': 'b', 'category': 'cat1', 'cents': 50},
            {'id': 'c', 'category': 'cat1', 'cents': 100},
        ]
        result = process(records, minimum_cents=50)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['events'][0]['id'], 'b')
        self.assertEqual(result['events'][1]['id'], 'c')
        self.assertEqual(result['totals'], {'cat1': 150})
    
    def test_minimum_cents_zero_default(self):
        """minimum_cents defaults to 0."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 0}]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['totals'], {'cat1': 0})
    
    def test_first_occurrence_wins_deduplication(self):
        """First occurrence of duplicate id wins."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 100},
            {'id': 'a', 'category': 'cat2', 'cents': 200},
        ]
        result = process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'cat1')
        self.assertEqual(result['events'][0]['cents'], 100)
    
    def test_whitespace_stripping(self):
        """Whitespace is stripped from id and category."""
        records = [{'id': '  a  ', 'category': '  cat1  ', 'cents': 100}]
        result = process(records)
        self.assertEqual(result['events'][0]['id'], 'a')
        self.assertEqual(result['events'][0]['category'], 'cat1')
    
    def test_input_not_mutated(self):
        """Original records are not mutated."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 100}]
        original = {'id': 'a', 'category': 'cat1', 'cents': 100}
        process(records)
        self.assertEqual(records[0], original)
    
    def test_no_shared_mutable_return(self):
        """Returned data is not shared between calls."""
        result1 = process([{'id': 'a', 'category': 'cat1', 'cents': 100}])
        result2 = process([{'id': 'b', 'category': 'cat2', 'cents': 200}])
        # Modifying result1 should not affect result2
        result1['events'].append({'id': 'x', 'category': 'x', 'cents': 0})
        self.assertEqual(len(result2['events']), 1)
    
    def test_invalid_record_not_dict(self):
        """Non-dict record raises ValueError."""
        with self.assertRaises(ValueError):
            process(['not a dict'])
    
    def test_invalid_record_missing_id(self):
        """Record missing id raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'category': 'cat1', 'cents': 100}])
    
    def test_invalid_record_missing_category(self):
        """Record missing category raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'cents': 100}])
    
    def test_invalid_record_missing_cents(self):
        """Record missing cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1'}])
    
    def test_invalid_id_not_string(self):
        """Non-string id raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 123, 'category': 'cat1', 'cents': 100}])
    
    def test_invalid_id_empty_string(self):
        """Empty string id raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': '', 'category': 'cat1', 'cents': 100}])
    
    def test_invalid_id_whitespace_only(self):
        """Whitespace-only id raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': '   ', 'category': 'cat1', 'cents': 100}])
    
    def test_invalid_category_not_string(self):
        """Non-string category raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 123, 'cents': 100}])
    
    def test_invalid_category_empty_string(self):
        """Empty string category raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': '', 'cents': 100}])
    
    def test_invalid_cents_not_integer(self):
        """Non-integer cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1', 'cents': 10.5}])
    
    def test_invalid_cents_negative(self):
        """Negative cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1', 'cents': -1}])
    
    def test_invalid_cents_boolean(self):
        """Boolean cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([{'id': 'a', 'category': 'cat1', 'cents': True}])
    
    def test_invalid_minimum_cents_not_integer(self):
        """Non-integer minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=10.5)
    
    def test_invalid_minimum_cents_negative(self):
        """Negative minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=-1)
    
    def test_invalid_minimum_cents_boolean(self):
        """Boolean minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            process([], minimum_cents=True)
    
    def test_invalid_minimum_cents_zero(self):
        """Zero minimum_cents is valid."""
        records = [{'id': 'a', 'category': 'cat1', 'cents': 0}]
        result = process(records, minimum_cents=0)
        self.assertEqual(len(result['events']), 1)
    
    def test_input_order_preserved(self):
        """Events are returned in input order."""
        records = [
            {'id': 'c', 'category': 'cat3', 'cents': 30},
            {'id': 'a', 'category': 'cat1', 'cents': 10},
            {'id': 'b', 'category': 'cat2', 'cents': 20},
        ]
        result = process(records)
        self.assertEqual([e['id'] for e in result['events']], ['c', 'a', 'b'])
    
    def test_filter_applied_after_deduplication(self):
        """Filter is applied after deduplication."""
        records = [
            {'id': 'a', 'category': 'cat1', 'cents': 10},
            {'id': 'a', 'category': 'cat1', 'cents': 100},
        ]
        result = process(records, minimum_cents=50)
        # First occurrence (cents=10) is kept, but filtered out
        self.assertEqual(len(result['events']), 0)


if __name__ == '__main__':
    unittest.main()
