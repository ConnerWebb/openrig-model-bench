#include <cassert>
#include <cstdint>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#include "solution.hpp"

int main() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);

    // default + sized construction zero-initialized
    Buffer d;
    assert(d.size() == 0);
    Buffer b(5);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) assert(b[i] == 0);

    // write/read
    for (std::size_t i = 0; i < 5; ++i) b[i] = static_cast<std::uint8_t>(i * 10);
    assert(b[3] == 30);

    // bounds checks (mutable and const)
    bool threw = false;
    try { (void)b[5]; } catch (const std::out_of_range&) { threw = true; }
    assert(threw);
    const Buffer& cb = b;
    threw = false;
    try { (void)cb[5]; } catch (const std::out_of_range&) { threw = true; }
    assert(threw);
    assert(cb[4] == 40);

    // deep copy: independent storage
    Buffer c = b;
    c[0] = 255;
    assert(b[0] == 0);
    assert(c[0] == 255);
    for (std::size_t i = 1; i < 5; ++i) assert(c[i] == b[i]);

    // self-copy preserves content
    c = c;
    assert(c.size() == 5 && c[0] == 255 && c[4] == 40);

    // move construction: source size 0, reusable
    Buffer m = std::move(c);
    assert(c.size() == 0);
    assert(m.size() == 5 && m[0] == 255);
    c.resize(3);
    c[0] = 7;
    assert(c.size() == 3 && c[0] == 7);

    // move assignment
    Buffer t(2);
    t = std::move(m);
    assert(m.size() == 0);
    assert(t.size() == 5 && t[0] == 255 && t[4] == 40);

    // self-move preserves content
    t = std::move(t);
    assert(t.size() == 5 && t[0] == 255 && t[4] == 40);

    // copy assignment
    Buffer u(1);
    u = t;
    assert(u.size() == 5 && u[0] == 255);
    u[1] = 9;
    assert(t[1] == 10);

    // self-assignment
    u = u;
    assert(u.size() == 5 && u[1] == 9);

    // resize grow: prefix preserved, new bytes zero
    Buffer r(3);
    r[0] = 1; r[1] = 2; r[2] = 3;
    r.resize(6);
    assert(r.size() == 6);
    assert(r[0] == 1 && r[1] == 2 && r[2] == 3);
    assert(r[3] == 0 && r[4] == 0 && r[5] == 0);

    // resize shrink: prefix kept
    r.resize(2);
    assert(r.size() == 2 && r[0] == 1 && r[1] == 2);

    // resize to 0
    r.resize(0);
    assert(r.size() == 0);
    threw = false;
    try { (void)r[0]; } catch (const std::out_of_range&) { threw = true; }
    assert(threw);

    // large resize
    Buffer big(100000);
    big[99999] = 42;
    big.resize(200000);
    assert(big.size() == 200000 && big[99999] == 42 && big[199999] == 0);

    return 0;
}
