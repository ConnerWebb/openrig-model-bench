# Buffer

A small C++20 byte buffer class (`Buffer` in `solution.hpp`) storing `std::uint8_t`
elements backed by a `std::vector<std::uint8_t>` (RAII, no manual `new`/`delete`).

## API

- `Buffer(std::size_t n = 0)` — constructs a buffer of `n` zero-initialized bytes.
- `std::size_t size() const noexcept` — number of bytes.
- `std::uint8_t& operator[](std::size_t i)` / `const std::uint8_t& operator[](std::size_t i) const`
  — element access; throws `std::out_of_range` when `i >= size()`.
- `void resize(std::size_t k)` — resizes to `k` bytes, preserving the existing prefix
  and zero-initializing any new bytes.
- Deep copy construction/assignment: copies own independent storage; self-copy is a no-op
  that preserves content.
- `noexcept` move construction/assignment: transfers storage; moved-from buffers have
  size 0 and remain reusable; self-move preserves content.

## Build / test

```sh
clang++ -std=c++20 -O2 -Wall -Wextra -o /tmp/test_solution test_solution.cpp
/tmp/test_solution
```

The fixed public runner is `PUBLIC_DRIVER.cpp` (compiled against `solution.hpp`);
`run_tests` executes the public checks plus this test.
