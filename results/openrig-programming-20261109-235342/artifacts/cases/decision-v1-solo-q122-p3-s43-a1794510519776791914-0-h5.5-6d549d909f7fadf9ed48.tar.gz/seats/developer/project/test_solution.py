import unittest
import tempfile
import pathlib
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_basic_aggregation(self):
        """Test basic category aggregation"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.50\nrent,20.25\nfood,5.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '16.00', 'rent': '20.25'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n  food  ,  10.50  \n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_quoted_fields_with_commas(self):
        """Test quoted fields containing commas"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"a,b",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'a,b': '100.00'})
    
    def test_quoted_fields_with_embedded_newlines(self):
        """Test quoted fields containing embedded newlines"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            content = 'category,amount\n"two\nlines",50.00\n'
            p.write_text(content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'two\nlines': '50.00'})
    
    def test_escaped_quotes(self):
        """Test escaped quotes in quoted fields"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x""quote",100.00\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_blank_lines_ignored(self):
        """Test that completely blank lines are ignored"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.00\n\nrent,20.00\n\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.00', 'rent': '20.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,+10.50\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_integer_amounts(self):
        """Test integer amounts (no decimal point)"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,100\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '100.00'})
    
    def test_one_decimal_digit(self):
        """Test amount with one decimal digit"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.5\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.50'})
    
    def test_two_decimal_digits(self):
        """Test amount with two decimal digits"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nfood,10.55\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'food': '10.55'})
    
    def test_invalid_header_wrong_names(self):
        """Test that wrong header names raise ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('wrong,amount\nx,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_header_extra_columns(self):
        """Test that header with extra columns raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount,extra\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_record_wrong_field_count(self):
        """Test that record with wrong field count raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1,2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_empty_category_raises_error(self):
        """Test that empty category raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n,10.00\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_nan_amount_raises_error(self):
        """Test that NaN amount raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,NaN\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_invalid_amount_format(self):
        """Test that invalid amount format raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1.234\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_exponent_not_allowed(self):
        """Test that exponent notation raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1e2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_unclosed_quote_raises_error(self):
        """Test that unclosed quote raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\n"x,1\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))
    
    def test_sorted_output(self):
        """Test that output is sorted by category key"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nzebra,1.00\napple,2.00\nmango,3.00\n', encoding='utf-8')
            result = aggregate(str(p))
            keys = list(result.keys())
            self.assertEqual(keys, ['apple', 'mango', 'zebra'])
    
    def test_unicode_categories(self):
        """Test unicode category names"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            # Use ASCII comma as field separator, unicode in category name
            header = 'category,amount\n'
            line = '日本' + ',' + '100.00\n'
            content = header + line
            p.write_text(content, encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'日本': '100.00'})
    
    def test_large_integer_amount(self):
        """Test large integer amount (12 digits)"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,999999999999\n', encoding='utf-8')
            result = aggregate(str(p))
            self.assertEqual(result, {'x': '999999999999.00'})
    
    def test_too_many_digits_raises_error(self):
        """Test that more than 12 digits raises ValueError"""
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'test.csv'
            p.write_text('category,amount\nx,1234567890123\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                aggregate(str(p))


if __name__ == '__main__':
    unittest.main()
