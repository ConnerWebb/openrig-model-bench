# CSV Aggregation Solution

## Overview

This module provides a `aggregate` function that reads a UTF-8 CSV file, validates its structure, and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with totals formatted to 2 decimal places.
    Raise ValueError for any malformed input.
    """
```

## Input Format

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank line must have exactly 2 fields
- **Category**: Whitespace-stripped, must not be empty
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits before optional decimal point
  - If decimal point present, 1-2 digits after
  - Non-negative, finite, no exponent notation

## Output Format

- Dictionary with category keys sorted alphabetically
- Values formatted as strings with exactly 2 decimal places

## Error Handling

Raises `ValueError` for:
- Invalid header (wrong column names or count)
- Records with wrong number of fields
- Empty category names
- Invalid amount formats (wrong digit count, exponent notation, etc.)
- Unclosed quotes in CSV fields

## Example

```python
>>> aggregate('data.csv')
{'food': '2262.01', 'rent': '2215.92', 'x"quote': '1458.60'}
```

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
