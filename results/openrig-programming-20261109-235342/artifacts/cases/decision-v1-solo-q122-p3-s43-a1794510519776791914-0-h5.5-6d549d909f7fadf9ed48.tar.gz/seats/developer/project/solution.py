import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with totals formatted to 2 decimal places.
    Raise ValueError for any malformed input.
    """
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        # Read header line and validate
        header_line = f.readline()
        if not header_line:
            raise ValueError("Empty file")
        
        # Parse header using csv module to handle quoted fields
        header_reader = csv.reader(StringIO(header_line))
        try:
            header = next(header_reader)
        except StopIteration:
            raise ValueError("Empty header")
        
        if header != ['category', 'amount']:
            raise ValueError("Invalid header")
        
        # Process remaining lines as CSV
        # We need to handle the file as a stream but csv.reader needs the whole content
        # for multi-line quoted fields. We'll read the rest and parse.
        rest = f.read()
        
        reader = csv.reader(StringIO(rest))
        
        for row in reader:
            # Skip completely blank records (empty row or all empty strings)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every non-blank record must have exactly 2 fields
            if len(row) != 2:
                raise ValueError("Record must have exactly 2 fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate amount format: optional +, 1-12 digits, optional decimal with 1-2 digits
            # Pattern: ^\+?[0-9]{1,12}(\.[0-9]{1,2})?$
            amount_pattern = r'^\+?[0-9]{1,12}(\.[0-9]{1,2})?$'
            if not re.match(amount_pattern, amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse as Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Check non-negative and finite
            if amount < 0:
                raise ValueError("Amount must be non-negative")
            if not amount.is_finite():
                raise ValueError("Amount must be finite")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly 2 decimal places, sorted by key
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
