# CSV Expense Aggregation

`solution.py` implements `aggregate(path: str) -> dict[str, str]`.

## Contract

- Reads a UTF-8 CSV file **as a stream** (line by line; multi-line quoted
  fields are buffered incrementally, never the whole file).
- The first line must be exactly `category,amount` (a trailing newline is
  tolerated).
- Completely blank records are ignored. Every other record must have
  exactly two fields.
- `category` and `amount` are stripped of surrounding whitespace; the
  category must be non-empty after stripping.
- `amount` grammar: optional `+`, 1–12 decimal digits, optional `.`
  followed by 1 or 2 digits. Nonnegative, finite, no exponent. Anything
  else (including `NaN`, `Infinity`, `-1`, `1e2`, `1.001`, 13+ digits)
  is rejected.
- All malformed input (bad header, wrong field count, empty category,
  bad amount, unterminated quote, empty file) raises `ValueError`.
- Totals use exact `decimal.Decimal` arithmetic.
- Returns a dict with **sorted** category keys and totals formatted with
  exactly two decimal places (e.g. `"599.14"`, `"5.00"`).
- CSV quoting is supported: embedded commas, embedded newlines, and
  doubled `""` escapes inside quoted fields.

## Usage

```python
from solution import aggregate
result = aggregate('input.csv')
# {'food': '2262.01', 'rent': '2215.92', ...}
```

## Tests

`test_solution.py` (stdlib `unittest`) covers all 13 public cases in
`PUBLIC_CASES.json` plus edge cases: blank records, whitespace, digit
limits, decimal limits, sign/exponent/NaN rejection, header checks,
quoting, exact decimal accumulation, and key sorting.

Run with: `python3 -m unittest test_solution -v`
