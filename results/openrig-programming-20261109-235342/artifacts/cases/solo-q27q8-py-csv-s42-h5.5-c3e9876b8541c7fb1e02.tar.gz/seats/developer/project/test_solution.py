import json
import os
import tempfile
import unittest

from solution import aggregate


def _run(csv_text):
    d = tempfile.mkdtemp()
    p = os.path.join(d, 'input.csv')
    with open(p, 'w', encoding='utf-8') as f:
        f.write(csv_text)
    return aggregate(p)


class TestAggregate(unittest.TestCase):
    def test_public_cases(self):
        cases = json.load(open('PUBLIC_CASES.json', encoding='utf-8'))
        for c in cases:
            csv = c['driver_input']['csv']
            exp = c['expected']
            if 'error' in exp:
                with self.assertRaises(ValueError):
                    _run(csv)
            else:
                self.assertEqual(_run(csv), exp['value'])

    def test_blank_records_ignored(self):
        self.assertEqual(
            _run('category,amount\n\nx,1.00\n\n\ny,2.50\n'),
            {'x': '1.00', 'y': '2.50'})

    def test_whitespace_stripped(self):
        self.assertEqual(
            _run('category,amount\n  x  ,  +12.3 \n'),
            {'x': '12.30'})

    def test_no_decimal_point(self):
        self.assertEqual(_run('category,amount\nx,5\n'), {'x': '5.00'})

    def test_twelve_digits_ok(self):
        self.assertEqual(
            _run('category,amount\nx,999999999999\n'),
            {'x': '999999999999.00'})

    def test_thirteen_digits_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,10000000000000\n')

    def test_three_decimal_digits_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,1.234\n')

    def test_negative_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,-0.01\n')

    def test_exponent_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,1e3\n')

    def test_nan_inf_bad(self):
        for bad in ('NaN', 'nan', 'Infinity', '-Infinity', 'inf'):
            with self.assertRaises(ValueError):
                _run('category,amount\nx,%s\n' % bad)

    def test_bad_header(self):
        with self.assertRaises(ValueError):
            _run('Category,amount\nx,1\n')

    def test_empty_file(self):
        with self.assertRaises(ValueError):
            _run('')

    def test_header_only(self):
        self.assertEqual(_run('category,amount\n'), {})

    def test_three_fields_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,1,2\n')

    def test_one_field_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx\n')

    def test_empty_category_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\n   ,1\n')

    def test_unterminated_quote_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\n"x,1\n')

    def test_exact_decimal_accumulation(self):
        # 0.1 + 0.2 must be exactly 0.30, not 0.30000000000000004
        self.assertEqual(
            _run('category,amount\nx,0.1\nx,0.2\n'),
            {'x': '0.30'})

    def test_sorted_keys(self):
        result = _run('category,amount\nz,1\na,2\nm,3\n')
        self.assertEqual(list(result), ['a', 'm', 'z'])

    def test_quoted_comma_and_newline(self):
        self.assertEqual(
            _run('category,amount\n"a,b",1.5\n"t\nw",2.5\n'),
            {'a,b': '1.50', 't\nw': '2.50'})

    def test_quoted_double_quote(self):
        self.assertEqual(
            _run('category,amount\n"x""y",3\n'),
            {'x"y': '3.00'})

    def test_plus_sign(self):
        self.assertEqual(_run('category,amount\nx,+7\n'), {'x': '7.00'})

    def test_two_decimal_digits_ok(self):
        self.assertEqual(_run('category,amount\nx,1.99\n'), {'x': '1.99'})

    def test_dot_only_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,.\n')

    def test_trailing_dot_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,1.\n')

    def test_empty_amount_bad(self):
        with self.assertRaises(ValueError):
            _run('category,amount\nx,\n')


if __name__ == '__main__':
    unittest.main()
