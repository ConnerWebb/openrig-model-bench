"""Streaming CSV expense aggregation.

aggregate(path) reads a UTF-8 CSV file with header ``category,amount`` and
returns a dict mapping each category to its total, formatted with exactly
two decimal places.  Keys are sorted.  All malformed input raises
``ValueError``.  The file is parsed as a stream (line by line, with
multi-line quoted fields handled incrementally).
"""

import re
from decimal import Decimal

_AMOUNT_RE = re.compile(r'\A\+?(?:\d{1,12})(?:\.\d{1,2})?\Z')


def _parse_amount(text):
    if not _AMOUNT_RE.match(text):
        raise ValueError('malformed amount: %r' % (text,))
    return Decimal(text)


def _split_record(record):
    """Split one complete CSV record into fields (handles quoting)."""
    fields = []
    cur = []
    in_quotes = False
    i = 0
    n = len(record)
    while i < n:
        ch = record[i]
        if in_quotes:
            if ch == '"':
                if i + 1 < n and record[i + 1] == '"':
                    cur.append('"')
                    i += 2
                    continue
                in_quotes = False
                i += 1
                continue
            cur.append(ch)
            i += 1
            continue
        if ch == '"':
            in_quotes = True
            i += 1
            continue
        if ch == ',':
            fields.append(''.join(cur))
            cur = []
            i += 1
            continue
        cur.append(ch)
        i += 1
    if in_quotes:
        raise ValueError('unterminated quoted field')
    fields.append(''.join(cur))
    return fields


def aggregate(path):
    totals = {}
    with open(path, 'r', encoding='utf-8', newline='') as f:
        header = f.readline()
        if header.rstrip('\r\n') != 'category,amount':
            raise ValueError('bad header: %r' % (header,))
        buf = ''
        in_quotes = False
        for line in f:
            buf += line
            in_quotes = buf.count('"') % 2 == 1
            if in_quotes:
                continue
            record = buf
            buf = ''
            if record.strip() == '':
                continue
            fields = _split_record(record)
            if len(fields) != 2:
                raise ValueError('record must have exactly two fields: %r'
                                 % (record,))
            category = fields[0].strip()
            if category == '':
                raise ValueError('empty category')
            amount = _parse_amount(fields[1].strip())
            totals[category] = totals.get(category, Decimal('0')) + amount
        if in_quotes:
            raise ValueError('unterminated quoted field')
    return {k: format(totals[k], '.2f') for k in sorted(totals)}
