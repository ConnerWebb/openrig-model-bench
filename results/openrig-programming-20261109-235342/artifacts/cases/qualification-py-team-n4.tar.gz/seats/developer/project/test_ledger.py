import unittest
import ledger
import validation
import storage


class TestNormalize(unittest.TestCase):
    def test_valid_record(self):
        r = {'id': ' x ', 'category': ' a ', 'cents': 5, 'rejected': False}
        result = validation.normalize([r])
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5, 'rejected': False}])

    def test_preserves_duplicates(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 10, 'rejected': False}
        r2 = {'id': '1', 'category': 'b', 'cents': 20, 'rejected': True}
        result = validation.normalize([r1, r2])
        self.assertEqual(len(result), 2)

    def test_invalid_not_dict(self):
        with self.assertRaises(ValueError):
            validation.normalize(['not a dict'])

    def test_invalid_extra_keys(self):
        r = {'id': '1', 'category': 'a', 'cents': 5, 'rejected': False, 'extra': 'x'}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_missing_keys(self):
        r = {'id': '1', 'category': 'a'}  # missing 'cents'
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_empty_id(self):
        r = {'id': '', 'category': 'a', 'cents': 5, 'rejected': False}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_whitespace_id(self):
        r = {'id': '   ', 'category': 'a', 'cents': 5, 'rejected': False}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_empty_category(self):
        r = {'id': '1', 'category': '', 'cents': 5, 'rejected': False}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_negative_cents(self):
        r = {'id': '1', 'category': 'a', 'cents': -1, 'rejected': False}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_cents_float(self):
        r = {'id': '1', 'category': 'a', 'cents': 5.5, 'rejected': False}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_invalid_rejected_not_bool(self):
        r = {'id': '1', 'category': 'a', 'cents': 5, 'rejected': 'false'}
        with self.assertRaises(ValueError):
            validation.normalize([r])

    def test_empty_input(self):
        result = validation.normalize([])
        self.assertEqual(result, [])


class TestDeduplicate(unittest.TestCase):
    def test_deduplicates_by_id(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 10, 'rejected': False}
        r2 = {'id': '1', 'category': 'b', 'cents': 20, 'rejected': True}
        r3 = {'id': '2', 'category': 'c', 'cents': 30, 'rejected': False}
        result = storage.deduplicate([r1, r2, r3])
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], '1')
        self.assertEqual(result[1]['id'], '2')

    def test_first_occurrence_wins(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 10, 'rejected': False}
        r2 = {'id': '1', 'category': 'b', 'cents': 20, 'rejected': True}
        result = storage.deduplicate([r1, r2])
        self.assertEqual(result[0]['category'], 'a')

    def test_empty_input(self):
        result = storage.deduplicate([])
        self.assertEqual(result, [])

    def test_no_duplicates(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 10, 'rejected': False}
        r2 = {'id': '2', 'category': 'b', 'cents': 20, 'rejected': True}
        result = storage.deduplicate([r1, r2])
        self.assertEqual(len(result), 2)


class TestProcess(unittest.TestCase):
    def test_basic_process(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5, 'rejected': False}]
        result = ledger.process(r)
        self.assertEqual(result['totals'], {'a': 5})
        self.assertEqual(r[0]['id'], ' x ')  # Input not mutated

    def test_empty_input(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_invalid_minimum_cents_negative(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_invalid_minimum_cents_float(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=1.5)

    def test_minimum_cents_filtering(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 10, 'rejected': False}
        r2 = {'id': '2', 'category': 'b', 'cents': 20, 'rejected': True}
        r3 = {'id': '3', 'category': 'c', 'cents': 5, 'rejected': False}
        result = ledger.process([r1, r2, r3], minimum_cents=10)
        self.assertEqual(len(result['events']), 2)
        self.assertEqual(result['totals'], {'a': 10, 'b': 20})

    def test_deduplication_before_filtering(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 20, 'rejected': False}
        r2 = {'id': '1', 'category': 'b', 'cents': 10, 'rejected': True}
        result = ledger.process([r1, r2], minimum_cents=10)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'a')

    def test_totals_sorted(self):
        r1 = {'id': '1', 'category': 'c', 'cents': 10, 'rejected': False}
        r2 = {'id': '2', 'category': 'a', 'cents': 20, 'rejected': False}
        r3 = {'id': '3', 'category': 'b', 'cents': 30, 'rejected': False}
        result = ledger.process([r1, r2, r3])
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_rejected_field_preserved(self):
        r1 = {'id': '1', 'category': 'a', 'cents': 10, 'rejected': True}
        r2 = {'id': '2', 'category': 'b', 'cents': 20, 'rejected': False}
        result = ledger.process([r1, r2])
        self.assertEqual(result['events'][0]['rejected'], True)
        self.assertEqual(result['events'][1]['rejected'], False)


if __name__ == '__main__':
    unittest.main()
