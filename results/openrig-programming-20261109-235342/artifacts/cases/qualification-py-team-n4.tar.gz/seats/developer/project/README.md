# Ledger Toolkit

A Python library for processing ledger records with validation, deduplication, and aggregation.

## Modules

### validation.py

**`normalize(records)`** - Validates and normalizes records.

- **Parameters**: `records` - List of record dictionaries
- **Returns**: Fresh list of normalized records
- **Validates**:
  - Each record must be a dict with exactly: `id`, `category`, `cents`, `rejected`
  - `id`: non-empty stripped string
  - `category`: non-empty stripped string
  - `cents`: integer >= 0
  - `rejected`: boolean
- **Raises**: `ValueError` for invalid input
- **Note**: Preserves duplicates (does not deduplicate)

### storage.py

**`deduplicate(records)`** - Removes duplicate records by id.

- **Parameters**: `records` - List of validated record dictionaries
- **Returns**: Fresh list with first occurrence of each id retained
- **Behavior**: First occurrence of an id wins; input order preserved

### ledger.py

**`process(records, *, minimum_cents=0)`** - Full processing pipeline.

- **Parameters**:
  - `records` - List of record dictionaries
  - `minimum_cents` - Filter threshold (default: 0), must be int >= 0
- **Returns**: `{'events': [...], 'totals': {...}}`
  - `events`: List of normalized, deduplicated records with cents >= minimum_cents
  - `totals`: Dict mapping category -> sum of cents, keys sorted
- **Pipeline**: normalize → deduplicate → filter by minimum_cents
- **Raises**: `ValueError` for invalid input or negative minimum_cents

## Usage Examples

```python
from ledger import process

records = [
    {'id': ' 1 ', 'category': ' a ', 'cents': 10, 'rejected': False},
    {'id': ' 2 ', 'category': ' b ', 'cents': 20, 'rejected': True},
    {'id': ' 1 ', 'category': ' c ', 'cents': 30, 'rejected': False},  # duplicate id
]

result = process(records)
# events: [{'id': '1', 'category': 'a', 'cents': 10, 'rejected': False},
#          {'id': '2', 'category': 'b', 'cents': 20, 'rejected': True}]
# totals: {'a': 10, 'b': 20}

result = process(records, minimum_cents=15)
# events: [{'id': '2', 'category': 'b', 'cents': 20, 'rejected': True}]
# totals: {'b': 20}
```

## Validation Rules

1. Record must be a dict with exactly four keys: `id`, `category`, `cents`, `rejected`
2. `id` must be a non-empty string after stripping whitespace
3. `category` must be a non-empty string after stripping whitespace
4. `cents` must be an integer >= 0
5. `rejected` must be a boolean

## Testing

Run tests with: `python -m unittest test_ledger.py`
