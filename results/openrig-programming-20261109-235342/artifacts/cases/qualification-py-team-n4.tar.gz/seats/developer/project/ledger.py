from validation import normalize
from storage import deduplicate

def process(records, *, minimum_cents=0):
    if type(minimum_cents) != int or minimum_cents < 0:
        raise ValueError('minimum')
    validated = normalize(records)
    deduped = deduplicate(validated)
    events = [r for r in deduped if r['cents'] >= minimum_cents]
    totals = {}
    for r in events:
        totals[r['category']] = totals.get(r['category'], 0) + r['cents']
    return {'events': events, 'totals': dict(sorted(totals.items()))}
