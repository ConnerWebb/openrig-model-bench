def normalize(records):
    out = []
    for r in records:
        if not isinstance(r, dict):
            raise ValueError('record')
        required_keys = {'id', 'category', 'cents'}
        optional_keys = {'rejected'}
        if not required_keys.issubset(r.keys()) or not r.keys() <= (required_keys | optional_keys):
            raise ValueError('record')
        if not isinstance(r['id'], str) or not r['id'].strip():
            raise ValueError('record')
        if not isinstance(r['category'], str) or not r['category'].strip():
            raise ValueError('record')
        if type(r['cents']) != int or r['cents'] < 0:
            raise ValueError('record')
        rejected = r.get('rejected', False)
        if type(rejected) != bool:
            raise ValueError('record')
        normalized = {
            'id': r['id'].strip(),
            'category': r['category'].strip(),
            'cents': r['cents']
        }
        if 'rejected' in r:
            normalized['rejected'] = rejected
        out.append(normalized)
    return out
