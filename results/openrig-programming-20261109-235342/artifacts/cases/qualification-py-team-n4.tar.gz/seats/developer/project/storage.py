def deduplicate(records):
    seen = set()
    out = []
    for r in records:
        if r['id'] not in seen:
            seen.add(r['id'])
            out.append(dict(r))
    return out
