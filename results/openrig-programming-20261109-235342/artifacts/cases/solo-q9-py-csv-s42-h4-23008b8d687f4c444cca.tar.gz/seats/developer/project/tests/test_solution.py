#!/usr/bin/env python3
"""
Tests for solution.py aggregate function.
"""

import csv
import io
import os
import tempfile
import unittest
from solution import aggregate


def _write_csv(content: str) -> str:
    """Write CSV content to a temporary file and return its path."""
    fd, path = tempfile.mkstemp(suffix='.csv')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(content)
    return path


class TestAggregate(unittest.TestCase):
    """Tests for the aggregate function."""
    
    def test_basic_aggregation(self):
        """Test basic aggregation from first public case."""
        csv_content = """category,amount
"x""quote",812.68
food,347.25
rent,991.77
rent,345.17
food,261.47
"x""quote",71.74
"x""quote",254.02
"x""quote",31.70
日本，690.39
"a,b",599.14
rent,457.86
日本，218.62
food,455.70
"x""quote",39.70
"two
lines",849.77
"x""quote",248.76
rent,421.12
"two
lines",584.47
food,870.27
food,327.32
"""
        expected = {
            "a,b": "599.14",
            "food": "2262.01",
            "rent": "2215.92",
            "two\nlines": "1434.24",
            "x\"quote": "1458.60",
            "日本": "909.01"
        }
        
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, expected)
        finally:
            os.unlink(path)
    
    def test_second_case(self):
        """Test second public case."""
        csv_content = """category,amount
rent,204.44
rent,965.51
"x""quote",464.96
"a,b",758.07
food,329.33
"a,b",273.11
"two
lines",38.36
food,127.88
rent,128.71
"a,b",182.35
"two
lines",626.01
"two
lines",741.38
"x""quote",469.53
"a,b",124.37
rent,397.36
"x""quote",283.13
rent,754.49
"two
lines",624.22
"x""quote",420.82
"a,b",124.22
日本，984.39
日本，817.87
"x""quote",338.00
日本，978.27
food,45.98
rent,290.01
"two
lines",427.32
日本，660.85
"x""quote",402.73
rent,353.84
rent,70.22
"two
lines",704.87
"two
lines",312.64
rent,788.02
food,277.54
日本，577.44
"a,b",612.46
"two
lines",339.11
"""
        expected = {
            "a,b": "2074.58",
            "food": "780.73",
            "rent": "3952.60",
            "two\nlines": "3813.91",
            "x\"quote": "2379.17",
            "日本": "4018.82"
        }
        
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, expected)
        finally:
            os.unlink(path)
    
    def test_third_case(self):
        """Test third public case."""
        csv_content = """category,amount
"two
lines",701.11
日本，417.63
"x""quote",636.47
"x""quote",645.43
food,534.59
rent,595.15
"a,b",845.38
"x""quote",656.79
日本，380.85
日本，17.78
food,553.84
"two
lines",84.37
"a,b",325.24
"a,b",783.67
日本，198.80
"two
lines",889.26
"x""quote",727.84
"a,b",777.27
"two
lines",64.97
"""
        expected = {
            "a,b": "2731.56",
            "food": "1088.43",
            "rent": "595.15",
            "two\nlines": "1739.71",
            "x\"quote": "2666.53",
            "日本": "1015.06"
        }
        
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, expected)
        finally:
            os.unlink(path)
    
    def test_invalid_header(self):
        """Test that wrong header raises ValueError."""
        csv_content = """wrong,amount
x,1
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_wrong_field_count(self):
        """Test that record with wrong field count raises ValueError."""
        csv_content = """category,amount
x,1,2
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        csv_content = """category,amount
,1
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_nan_amount(self):
        """Test that NaN amount raises ValueError."""
        csv_content = """category,amount
x,NaN
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_exponent_notation(self):
        """Test that exponent notation raises ValueError."""
        csv_content = """category,amount
x,1e2
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_negative_amount(self):
        """Test that negative amount raises ValueError."""
        csv_content = """category,amount
x,-1
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_quoted_field_with_comma(self):
        """Test that quoted field with comma is handled correctly."""
        csv_content = """category,amount
"x,1",100.00
"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {"x,1": "100.00"})
        finally:
            os.unlink(path)
    
    def test_embedded_newline_in_category(self):
        """Test that embedded newline in category is handled."""
        csv_content = """category,amount
"two
lines",100.00
"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {"two\nlines": "100.00"})
        finally:
            os.unlink(path)
    
    def test_blank_record_ignored(self):
        """Test that blank records are ignored."""
        csv_content = """category,amount

food,100.00

rent,200.00

"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {"food": "100.00", "rent": "200.00"})
        finally:
            os.unlink(path)
    
    def test_plus_prefix(self):
        """Test that + prefix is handled."""
        csv_content = """category,amount
x,+100.00
"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {"x": "100.00"})
        finally:
            os.unlink(path)
    
    def test_decimal_places(self):
        """Test that amounts with 1-2 decimal places work."""
        csv_content = """category,amount
x,1.1
y,1.11
z,10
"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {"x": "1.10", "y": "1.11", "z": "10.00"})
        finally:
            os.unlink(path)
    
    def test_sorted_output(self):
        """Test that output is sorted by category key."""
        csv_content = """category,amount
z,100.00
a,200.00
m,300.00
"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(list(result.keys()), ["a", "m", "z"])
        finally:
            os.unlink(path)
    
    def test_large_integer_amount(self):
        """Test that large integer amounts (12 digits) are accepted."""
        csv_content = """category,amount
x,100000000000
"""
        path = _write_csv(csv_content)
        try:
            result = aggregate(path)
            self.assertEqual(result, {"x": "100000000000.00"})
        finally:
            os.unlink(path)
    
    def test_too_many_decimal_digits(self):
        """Test that amounts with more than 2 decimal digits raise ValueError."""
        csv_content = """category,amount
x,1.123
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_too_many_integer_digits(self):
        """Test that amounts with more than 12 integer digits raise ValueError."""
        csv_content = """category,amount
x,1000000000000
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_empty_amount(self):
        """Test that empty amount raises ValueError."""
        csv_content = """category,amount
x,
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_only_decimal_point(self):
        """Test that only decimal point raises ValueError."""
        csv_content = """category,amount
x,.
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_decimal_point_no_digits_after(self):
        """Test that decimal point with no digits after raises ValueError."""
        csv_content = """category,amount
x,1.
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_infinity(self):
        """Test that infinity raises ValueError."""
        csv_content = """category,amount
x,inf
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)
    
    def test_negative_zero(self):
        """Test that negative zero is handled."""
        csv_content = """category,amount
x,-0
"""
        path = _write_csv(csv_content)
        try:
            with self.assertRaises(ValueError):
                aggregate(path)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
