#!/usr/bin/env python3
"""
Aggregate CSV amounts by category using exact decimal arithmetic.
"""

import csv
from decimal import Decimal, InvalidOperation
from typing import Iterator


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Args:
        path: Path to CSV file with header exactly "category,amount"
        
    Returns:
        dict[str, str]: Category keys sorted alphabetically, values formatted with exactly 2 decimal places
        
    Raises:
        ValueError: If header is wrong, record has wrong field count, category is empty,
                    amount is malformed, or any other validation failure
    """
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("CSV file is empty")
        
        # Strip whitespace from header fields
        header = [field.strip() for field in header]
        
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: expected ['category', 'amount'], got {header}")
        
        # Process records as a stream
        for row in reader:
            # Ignore completely blank records
            if not row or (len(row) == 1 and row[0].strip() == ''):
                continue
            
            # Every other record must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Record has {len(row)} fields, expected 2")
            
            category_raw, amount_raw = row
            
            # Strip whitespace
            category = category_raw.strip()
            amount_str = amount_raw.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category is empty")
            
            # Validate and parse amount
            amount = _parse_amount(amount_str)
            
            # Accumulate using exact decimal arithmetic
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly two decimal places
    result: dict[str, str] = {}
    for category in sorted(totals.keys()):
        value = totals[category]
        # Format with exactly 2 decimal places
        formatted = f"{value:.2f}"
        result[category] = formatted
    
    return result


def _parse_amount(amount_str: str) -> Decimal:
    """
    Parse and validate an amount string.
    
    Valid format: optional +, 1-12 decimal digits, optional decimal point followed by 1-2 digits
    Nonnegative, finite, no exponent.
    
    Args:
        amount_str: The amount string to parse
        
    Returns:
        Decimal: The parsed amount
        
    Raises:
        ValueError: If the amount is malformed
    """
    if not amount_str:
        raise ValueError("Amount is empty")
    
    # Remove leading + if present
    if amount_str.startswith('+'):
        amount_str = amount_str[1:]
    
    if not amount_str:
        raise ValueError("Amount is empty after stripping +")
    
    # Check for exponent notation
    if 'e' in amount_str.lower():
        raise ValueError("Amount contains exponent notation")
    
    # Validate format: optional decimal point with 1-2 digits after
    # Pattern: digits optionally followed by . and 1-2 digits
    # Must have at least 1 digit total
    
    # Split on decimal point
    if '.' in amount_str:
        parts = amount_str.split('.')
        if len(parts) != 2:
            raise ValueError(f"Amount has multiple decimal points: {amount_str}")
        
        integer_part, fractional_part = parts
        
        # Integer part must be non-empty and contain only digits
        if not integer_part or not integer_part.isdigit():
            raise ValueError(f"Invalid integer part in amount: {amount_str}")
        
        # Check integer part length (1-12 digits)
        if len(integer_part) > 12:
            raise ValueError(f"Integer part must have 1-12 digits: {amount_str}")
        
        # Fractional part must be 1-2 digits if present
        if not fractional_part:
            raise ValueError(f"Decimal point must be followed by 1-2 digits: {amount_str}")
        if len(fractional_part) > 2:
            raise ValueError(f"Fractional part must have 1-2 digits: {amount_str}")
        if not fractional_part.isdigit():
            raise ValueError(f"Fractional part contains non-digits: {amount_str}")
    else:
        # No decimal point - entire string is integer part
        if not amount_str.isdigit():
            raise ValueError(f"Amount contains non-digit characters: {amount_str}")
        
        # Check integer part length (1-12 digits)
        if len(amount_str) > 12:
            raise ValueError(f"Integer part must have 1-12 digits: {amount_str}")
    
    # Try to parse as Decimal
    try:
        amount = Decimal(amount_str)
    except InvalidOperation:
        raise ValueError(f"Cannot parse amount: {amount_str}")
    
    # Check for negative or NaN or Infinity
    if amount < 0:
        raise ValueError(f"Amount must be nonnegative: {amount_str}")
    if not amount.is_finite():
        raise ValueError(f"Amount must be finite: {amount_str}")
    if amount.is_nan():
        raise ValueError(f"Amount is NaN: {amount_str}")
    
    return amount


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        result = aggregate(sys.argv[1])
        print(result)
    else:
        print("Usage: python solution.py <csv_path>")
