#pragma once
#include <cstdint>
#include <limits>

class RunningStats {
public:
    void add(double x);
    void merge(const RunningStats& other);
    std::uint64_t count() const;
    double mean() const;
    double variance() const;
    double minimum() const;
    double maximum() const;

private:
    std::uint64_t n = 0;
    double mean_val = 0.0;
    double m2 = 0.0;
    double min_val = std::numeric_limits<double>::infinity();
    double max_val = -std::numeric_limits<double>::infinity();
};
