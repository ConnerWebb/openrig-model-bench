#include "stats.hpp"
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <vector>
#include <iomanip>

static bool approx_equal(double a, double b, double abs_tol = 1e-4, double rel_tol = 1e-6) {
    if (std::isnan(a) || std::isnan(b)) return false;
    if (std::isinf(a) || std::isinf(b)) return false;
    double diff = std::abs(a - b);
    if (diff <= abs_tol) return true;
    double max_val = std::max(std::abs(a), std::abs(b));
    return diff <= max_val * rel_tol;
}

static void test_empty_stats() {
    RunningStats rs;
    if (rs.count() != 0) throw std::runtime_error("empty count");
    try {
        rs.mean();
        throw std::runtime_error("mean should throw");
    } catch (const std::domain_error&) {}
    try {
        rs.variance();
        throw std::runtime_error("variance should throw");
    } catch (const std::domain_error&) {}
    try {
        rs.minimum();
        throw std::runtime_error("minimum should throw");
    } catch (const std::domain_error&) {}
    try {
        rs.maximum();
        throw std::runtime_error("maximum should throw");
    } catch (const std::domain_error&) {}
}

static void test_single_value() {
    RunningStats rs;
    rs.add(42.0);
    if (rs.count() != 1) throw std::runtime_error("count should be 1");
    if (!approx_equal(rs.mean(), 42.0)) throw std::runtime_error("mean mismatch");
    if (!approx_equal(rs.variance(), 0.0)) throw std::runtime_error("variance mismatch");
    if (!approx_equal(rs.minimum(), 42.0)) throw std::runtime_error("min mismatch");
    if (!approx_equal(rs.maximum(), 42.0)) throw std::runtime_error("max mismatch");
}

static void test_reject_nan() {
    RunningStats rs;
    try {
        rs.add(std::nan(""));
        throw std::runtime_error("should reject nan");
    } catch (const std::invalid_argument&) {}
    if (rs.count() != 0) throw std::runtime_error("count should be 0 after nan");
}

static void test_reject_inf() {
    RunningStats rs;
    try {
        rs.add(std::numeric_limits<double>::infinity());
        throw std::runtime_error("should reject inf");
    } catch (const std::invalid_argument&) {}
    if (rs.count() != 0) throw std::runtime_error("count should be 0 after inf");
}

static void test_merge_empty() {
    RunningStats rs1, rs2;
    rs1.merge(rs2);
    if (rs1.count() != 0) throw std::runtime_error("merge empty should be no-op");
    rs2.merge(rs1);
    if (rs2.count() != 0) throw std::runtime_error("merge into empty should be no-op");
}

static void test_merge_into_empty() {
    RunningStats rs1, rs2;
    rs1.add(10.0);
    rs1.add(20.0);
    rs2.merge(rs1);
    if (rs2.count() != 2) throw std::runtime_error("merge count");
    if (!approx_equal(rs2.mean(), 15.0)) throw std::runtime_error("merge mean");
}

static void test_self_merge() {
    RunningStats rs;
    rs.add(10.0);
    rs.add(20.0);
    double orig_mean = rs.mean();
    rs.merge(rs);
    if (rs.count() != 4) throw std::runtime_error("self merge count");
    if (!approx_equal(rs.mean(), orig_mean)) throw std::runtime_error("self merge mean");
}

static void test_large_values() {
    RunningStats rs;
    std::vector<double> vals = {
        1e9, 1e9+10, 1e9+20, 1e9+30, 1e9+40
    };
    for (double v : vals) rs.add(v);
    double expected_mean = 1e9 + 20.0;
    if (!approx_equal(rs.mean(), expected_mean)) throw std::runtime_error("large mean");
}

static void test_merge_preserves_values() {
    RunningStats rs1, rs2;
    rs1.add(1.0);
    rs1.add(2.0);
    rs2.add(3.0);
    rs2.add(4.0);
    rs1.merge(rs2);
    if (rs1.count() != 4) throw std::runtime_error("merge count");
    if (!approx_equal(rs1.mean(), 2.5)) throw std::runtime_error("merge mean");
    if (!approx_equal(rs1.minimum(), 1.0)) throw std::runtime_error("merge min");
    if (!approx_equal(rs1.maximum(), 4.0)) throw std::runtime_error("merge max");
}

static void run_all_tests() {
    std::vector<std::pair<std::string, void(*)()>> tests = {
        {"empty_stats", test_empty_stats},
        {"single_value", test_single_value},
        {"reject_nan", test_reject_nan},
        {"reject_inf", test_reject_inf},
        {"merge_empty", test_merge_empty},
        {"merge_into_empty", test_merge_into_empty},
        {"self_merge", test_self_merge},
        {"large_values", test_large_values},
        {"merge_preserves_values", test_merge_preserves_values}
    };
    int passed = 0, failed = 0;
    for (auto& t : tests) {
        try {
            t.second();
            std::cout << "PASS: " << t.first << std::endl;
            passed++;
        } catch (const std::exception& e) {
            std::cout << "FAIL: " << t.first << " - " << e.what() << std::endl;
            failed++;
        }
    }
    std::cout << "Results: " << passed << " passed, " << failed << " failed" << std::endl;
    if (failed > 0) throw std::runtime_error("some tests failed");
}

int main() {
    try {
        run_all_tests();
        return 0;
    } catch (...) {
        return 1;
    }
}
