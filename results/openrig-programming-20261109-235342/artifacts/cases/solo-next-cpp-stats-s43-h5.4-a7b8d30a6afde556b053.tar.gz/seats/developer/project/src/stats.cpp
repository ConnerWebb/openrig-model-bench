#include "stats.hpp"
#include <cmath>
#include <stdexcept>

void RunningStats::add(double x) {
    if (std::isnan(x) || std::isinf(x)) {
        throw std::invalid_argument("NaN or infinity not allowed");
    }
    if (n == 0) {
        min_val = x;
        max_val = x;
        mean_val = x;
        m2 = 0.0;
    } else {
        if (x < min_val) min_val = x;
        if (x > max_val) max_val = x;
        double delta = x - mean_val;
        mean_val += delta / (n + 1);
        double delta2 = x - mean_val;
        m2 += delta * delta2;
    }
    n++;
}

void RunningStats::merge(const RunningStats& other) {
    if (other.n == 0) {
        return;
    }
    if (n == 0) {
        n = other.n;
        mean_val = other.mean_val;
        m2 = other.m2;
        min_val = other.min_val;
        max_val = other.max_val;
    } else {
        double delta = other.mean_val - mean_val;
        double n1 = n;
        double n2 = other.n;
        n += other.n;
        mean_val += delta * n2 / n;
        m2 += other.m2 + delta * delta * n1 * n2 / n;
        if (other.min_val < min_val) min_val = other.min_val;
        if (other.max_val > max_val) max_val = other.max_val;
    }
}

std::uint64_t RunningStats::count() const {
    return n;
}

double RunningStats::mean() const {
    if (n == 0) {
        throw std::domain_error("mean of empty stats");
    }
    return mean_val;
}

double RunningStats::variance() const {
    if (n == 0) {
        throw std::domain_error("variance of empty stats");
    }
    return m2 / n;
}

double RunningStats::minimum() const {
    if (n == 0) {
        throw std::domain_error("minimum of empty stats");
    }
    return min_val;
}

double RunningStats::maximum() const {
    if (n == 0) {
        throw std::domain_error("maximum of empty stats");
    }
    return max_val;
}
