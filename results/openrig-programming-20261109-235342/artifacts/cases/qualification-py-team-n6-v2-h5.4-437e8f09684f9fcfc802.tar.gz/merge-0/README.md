# Ledger Toolkit

A lightweight toolkit for processing transaction-like records with validation, deduplication, and aggregation.

## Modules

### `validation.py`
- `normalize(records) -> list`: Validates and normalizes each record.
  - **Validation rules**:
    - Record must be a `dict` with exactly keys: `id`, `category`, `cents`.
    - `id` and `category` must be non-empty strings after stripping whitespace.
    - `cents` must be a non-negative integer (booleans are invalid).
  - Returns a fresh list of normalized records (strings stripped, values preserved).
  - Raises `ValueError` on any invalid record.

### `storage.py`
- `deduplicate(records) -> list`: Removes duplicate `id`s, keeping first occurrence.
  - Input must already be validated (e.g., via `normalize`).
  - Returns a fresh list without mutating input.

### `ledger.py`
- `process(records, *, minimum_cents=0) -> dict`:
  - Composes `normalize` and `deduplicate`.
  - Filters records with `cents >= minimum_cents` (non-negative integer; booleans invalid).
  - Returns `{'events': [...], 'totals': {...}}` where:
    - `events` preserves input order of unique records.
    - `totals` is a dict of `category -> sum(cents)` with keys sorted.

## Usage

```python
from ledger import process

records = [
    {'id': 'x', 'category': 'A', 'cents': 10},
    {'id': 'y', 'category': 'B', 'cents': 20},
    {'id': 'x', 'category': 'C', 'cents': 5},  # duplicate id, ignored
]

result = process(records, minimum_cents=8)
# result = {
#   'events': [{'id': 'x', 'category': 'A', 'cents': 10},
#              {'id': 'y', 'category': 'B', 'cents': 20}],
#   'totals': {'A': 10, 'B': 20}
# }
```

## Guarantees

- No mutation of input data.
- No hidden global state.
- No shared mutable returns.
- `process([])` returns `{'events': [], 'totals': {}}`.
