import unittest
import copy
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    def test_normalize_valid_record(self):
        r = {'id': ' x ', 'category': ' a ', 'cents': 5}
        result = validation.normalize([r])
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])
        self.assertEqual(r['id'], ' x ')  # input not mutated

    def test_normalize_empty_list(self):
        self.assertEqual(validation.normalize([]), [])

    def test_normalize_missing_key(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a'}])

    def test_normalize_extra_key(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': 5, 'extra': 1}])

    def test_normalize_non_string_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 1, 'category': 'a', 'cents': 5}])

    def test_normalize_empty_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '', 'category': 'a', 'cents': 5}])

    def test_normalize_whitespace_only_id(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '   ', 'category': 'a', 'cents': 5}])

    def test_normalize_non_string_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 1, 'cents': 5}])

    def test_normalize_empty_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '', 'cents': 5}])

    def test_normalize_whitespace_only_category(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '   ', 'cents': 5}])

    def test_normalize_negative_cents(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': -1}])

    def test_normalize_cents_as_bool(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': True}])

    def test_normalize_cents_as_float(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': 5.0}])

    def test_normalize_cents_as_str(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': '5'}])

    def test_normalize_input_not_mutated(self):
        r = {'id': 'x', 'category': 'a', 'cents': 5}
        original = copy.deepcopy(r)
        validation.normalize([r])
        self.assertEqual(r, original)

    def test_normalize_returns_fresh_list(self):
        r = {'id': 'x', 'category': 'a', 'cents': 5}
        result = validation.normalize([r])
        result.append({'id': 'y', 'category': 'b', 'cents': 10})
        self.assertEqual(len(validation.normalize([r])), 1)


class TestStorage(unittest.TestCase):
    def test_deduplicate_basic(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'b', 'category': 'y', 'cents': 2},
            {'id': 'a', 'category': 'z', 'cents': 3},
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'a')
        self.assertEqual(result[1]['id'], 'b')

    def test_deduplicate_empty_list(self):
        self.assertEqual(storage.deduplicate([]), [])

    def test_deduplicate_preserves_first_occurrence(self):
        records = [
            {'id': 'x', 'category': 'first', 'cents': 10},
            {'id': 'x', 'category': 'second', 'cents': 20},
        ]
        result = storage.deduplicate(records)
        self.assertEqual(result[0]['category'], 'first')

    def test_deduplicate_input_not_mutated(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        original = copy.deepcopy(records)
        storage.deduplicate(records)
        self.assertEqual(records, original)

    def test_deduplicate_returns_fresh_list(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 1}]
        result = storage.deduplicate(records)
        result.append({'id': 'b', 'category': 'y', 'cents': 2})
        self.assertEqual(len(storage.deduplicate(records)), 1)


class TestLedger(unittest.TestCase):
    def test_process_basic(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        self.assertEqual(ledger.process(r)['totals'], {'a': 5})
        self.assertEqual(r[0]['id'], ' x ')  # input not mutated

    def test_process_empty_list(self):
        self.assertEqual(ledger.process([]), {'events': [], 'totals': {}})

    def test_process_deduplication(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': 20},
        ]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['category'], 'x')

    def test_process_minimum_cents(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'y', 'cents': 15},
        ]
        result = ledger.process(records, minimum_cents=10)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['cents'], 15)

    def test_process_minimum_cents_bool_invalid(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)

    def test_process_minimum_cents_negative(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_process_invalid_record_raises(self):
        with self.assertRaises(ValueError):
            ledger.process([{'id': '', 'category': 'a', 'cents': 5}])

    def test_process_input_not_mutated(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_process_totals_sorted_keys(self):
        records = [
            {'id': 'a', 'category': 'z', 'cents': 1},
            {'id': 'b', 'category': 'a', 'cents': 2},
            {'id': 'c', 'category': 'm', 'cents': 3},
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'm', 'z'])

    def test_process_returns_fresh_events(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        result = ledger.process(records)
        result['events'].append({'id': 'b', 'category': 'y', 'cents': 20})
        self.assertEqual(len(ledger.process(records)['events']), 1)

    def test_process_returns_fresh_totals(self):
        records = [{'id': 'a', 'category': 'x', 'cents': 10}]
        result = ledger.process(records)
        result['totals']['y'] = 100
        self.assertEqual(ledger.process(records)['totals'], {'x': 10})

    def test_process_composition_validation_then_deduplicate(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 10},
            {'id': 'a', 'category': 'y', 'cents': 20},
            {'id': 'b', 'category': 'z', 'cents': 5},
        ]
        norm = validation.normalize(records)
        dedup = storage.deduplicate(norm)
        result = ledger.process(records)
        self.assertEqual(result['events'], dedup)


if __name__ == '__main__':
    unittest.main()
