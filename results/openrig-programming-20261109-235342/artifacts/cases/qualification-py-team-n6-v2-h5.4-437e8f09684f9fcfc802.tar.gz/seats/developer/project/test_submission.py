import unittest
import validation


class TestNormalize(unittest.TestCase):
    def test_basic_valid(self):
        x = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        self.assertEqual(validation.normalize(x), [{'id': 'a', 'category': 'b', 'cents': 2}])
        self.assertEqual(x[0]['id'], ' a ')  # no mutation

    def test_empty_input(self):
        self.assertEqual(validation.normalize([]), [])

    def test_duplicates_preserved(self):
        records = [
            {'id': 'x', 'category': 'cat', 'cents': 1},
            {'id': 'x', 'category': 'cat', 'cents': 2},
        ]
        result = validation.normalize(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['cents'], 1)
        self.assertEqual(result[1]['cents'], 2)

    def test_input_not_mutated(self):
        records = [{'id': ' a ', 'category': ' b ', 'cents': 2}]
        _ = validation.normalize(records)
        self.assertEqual(records[0]['id'], ' a ')
        self.assertEqual(records[0]['category'], ' b ')

    def test_invalid_not_dict(self):
        with self.assertRaises(ValueError):
            validation.normalize(['not a dict'])

    def test_invalid_missing_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y'}])

    def test_invalid_extra_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': 1, 'extra': 0}])

    def test_invalid_id_not_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 1, 'category': 'y', 'cents': 0}])

    def test_invalid_category_not_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 1, 'cents': 0}])

    def test_invalid_id_empty(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '', 'category': 'y', 'cents': 0}])

    def test_invalid_category_empty(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '', 'cents': 0}])

    def test_invalid_cents_bool(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': True}])

    def test_invalid_cents_negative(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': -1}])

    def test_invalid_cents_float(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': 1.5}])

    def test_invalid_cents_string(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'y', 'cents': '1'}])

    def test_whitespace_stripped(self):
        records = [{'id': '  x  ', 'category': '  cat  ', 'cents': 10}]
        result = validation.normalize(records)
        self.assertEqual(result[0]['id'], 'x')
        self.assertEqual(result[0]['category'], 'cat')

    def test_zero_cents_allowed(self):
        records = [{'id': 'x', 'category': 'y', 'cents': 0}]
        self.assertEqual(validation.normalize(records), [{'id': 'x', 'category': 'y', 'cents': 0}])


if __name__ == '__main__':
    unittest.main()
