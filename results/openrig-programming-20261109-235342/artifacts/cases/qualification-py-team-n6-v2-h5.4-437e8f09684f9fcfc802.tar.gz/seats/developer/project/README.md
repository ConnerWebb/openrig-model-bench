# validation.py

## Module boundary
`validation.py` provides a single function `normalize(records)` that validates and normalizes a list of record dictionaries.

## API signature
```python
def normalize(records: list) -> list:
    """
    Validate and normalize a list of records.

    Each record must be a dict with exactly the keys: 'id', 'category', 'cents'.

    - 'id' and 'category' must be nonempty strings; they are stripped of whitespace.
    - 'cents' must be a nonnegative integer (booleans are rejected).
    - Returns a new list of normalized dictionaries.
    - Raises ValueError if any record is invalid.
    - Input list and its items are never mutated.
    """
```

## Validation rules
1. `records` must be a list.
2. Each element must be a dict.
3. Dict keys must be exactly `{'id', 'category', 'cents'}` (no more, no less).
4. `id` and `category` must be nonempty strings after stripping whitespace.
5. `cents` must be an integer, not a boolean, and must be >= 0.

## Usage examples
```python
from validation import normalize

# Valid input
records = [
    {'id': '  A1  ', 'category': '  food  ', 'cents': 100},
    {'id': 'B2', 'category': 'drink', 'cents': 0},
]
normalized = normalize(records)
# normalized[0]['id'] == 'A1'
# normalized[1]['cents'] == 0

# Invalid: missing key
try:
    normalize([{'id': 'x', 'category': 'y'}])
except ValueError:
    pass

# Invalid: cents is a boolean
try:
    normalize([{'id': 'x', 'category': 'y', 'cents': True}])
except ValueError:
    pass
```
