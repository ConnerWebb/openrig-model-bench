import unittest
import ledger
import validation
import storage


class TestValidation(unittest.TestCase):
    def test_valid_record(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = validation.normalize(r)
        self.assertEqual(result, [{'id': 'x', 'category': 'a', 'cents': 5}])

    def test_invalid_not_list(self):
        with self.assertRaises(ValueError):
            validation.normalize("not a list")

    def test_invalid_record_keys(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x'}])

    def test_invalid_id_empty(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '', 'category': 'a', 'cents': 1}])

    def test_invalid_id_whitespace_only(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': '   ', 'category': 'a', 'cents': 1}])

    def test_invalid_category_empty(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': '', 'cents': 1}])

    def test_invalid_cents_negative(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': -1}])

    def test_invalid_cents_bool(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': True}])

    def test_invalid_cents_float(self):
        with self.assertRaises(ValueError):
            validation.normalize([{'id': 'x', 'category': 'a', 'cents': 1.5}])


class TestStorage(unittest.TestCase):
    def test_deduplicate_first_wins(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['category'], 'x')

    def test_deduplicate_preserves_order(self):
        records = [
            {'id': 'b', 'category': 'x', 'cents': 1},
            {'id': 'a', 'category': 'y', 'cents': 2},
            {'id': 'b', 'category': 'z', 'cents': 3}
        ]
        result = storage.deduplicate(records)
        self.assertEqual([r['id'] for r in result], ['b', 'a'])

    def test_deduplicate_no_dupes(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 1},
            {'id': 'b', 'category': 'y', 'cents': 2}
        ]
        result = storage.deduplicate(records)
        self.assertEqual(len(result), 2)


class TestLedger(unittest.TestCase):
    def test_empty_input(self):
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_basic_process(self):
        r = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        result = ledger.process(r)
        self.assertEqual(result['totals'], {'a': 5})
        self.assertEqual(result['events'][0]['id'], 'x')

    def test_minimum_cents_filter(self):
        records = [
            {'id': 'a', 'category': 'x', 'cents': 5},
            {'id': 'b', 'category': 'x', 'cents': 10}
        ]
        result = ledger.process(records, minimum_cents=7)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'b')
        self.assertEqual(result['totals'], {'x': 10})

    def test_minimum_cents_bool_rejected(self):
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)

    def test_totals_sorted(self):
        records = [
            {'id': 'a', 'category': 'c', 'cents': 1},
            {'id': 'b', 'category': 'a', 'cents': 2},
            {'id': 'c', 'category': 'b', 'cents': 3}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_input_not_mutated(self):
        records = [{'id': ' x ', 'category': ' a ', 'cents': 5}]
        original = dict(records[0])
        ledger.process(records)
        self.assertEqual(records[0], original)

    def test_returned_data_is_fresh(self):
        result1 = ledger.process([{'id': 'a', 'category': 'x', 'cents': 1}])
        result2 = ledger.process([{'id': 'a', 'category': 'x', 'cents': 1}])
        self.assertIsNot(result1['events'], result2['events'])
        self.assertIsNot(result1['totals'], result2['totals'])


if __name__ == '__main__':
    unittest.main()
