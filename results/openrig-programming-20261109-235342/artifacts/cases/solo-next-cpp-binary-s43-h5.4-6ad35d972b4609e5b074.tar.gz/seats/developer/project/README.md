# C++ Binary Serialization Solution

This project implements a binary serialization format for a `Record` struct with the following fields:
- `id`: uint32_t
- `name`: std::string (max 1024 bytes)
- `value`: int64_t

## Format

- Magic bytes: `OGC1\n` (ASCII)
- Count: uint32_t little-endian (max 10000)
- For each record:
  - id: uint32_t little-endian
  - name length: uint16_t little-endian
  - name: raw bytes (name length bytes)
  - value: int64_t little-endian two's complement

## Functions

- `std::vector<uint8_t> encode(const std::vector<Record>&)`: Serialize records to binary
- `std::vector<Record> decode(std::span<const uint8_t>)`: Deserialize binary to records

## Validation

- Rejects: bad magic, count > 10000, name length > 1024, duplicate IDs, truncation, trailing bytes
- Empty record list is valid

## Build

```bash
clang++ -std=c++20 -fuse-ld=bfd -o solution_test solution_test.cpp
./solution_test
```
