#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include <cstring>
#include "solution.hpp"

static int tests_passed = 0;
static int tests_failed = 0;

void assert_equal(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b) {
    if (a.size() != b.size()) {
        std::cerr << "Size mismatch: " << a.size() << " vs " << b.size() << std::endl;
        tests_failed++;
        return;
    }
    for (size_t i = 0; i < a.size(); ++i) {
        if (a[i] != b[i]) {
            std::cerr << "Byte mismatch at " << i << ": " << (int)a[i] << " vs " << (int)b[i] << std::endl;
            tests_failed++;
            return;
        }
    }
    tests_passed++;
}

void assert_equal(const std::vector<Record>& a, const std::vector<Record>& b) {
    if (a.size() != b.size()) {
        std::cerr << "Record count mismatch: " << a.size() << " vs " << b.size() << std::endl;
        tests_failed++;
        return;
    }
    for (size_t i = 0; i < a.size(); ++i) {
        if (a[i].id != b[i].id) {
            std::cerr << "Record " << i << " id mismatch: " << a[i].id << " vs " << b[i].id << std::endl;
            tests_failed++;
            return;
        }
        if (a[i].name != b[i].name) {
            std::cerr << "Record " << i << " name mismatch: " << a[i].name << " vs " << b[i].name << std::endl;
            tests_failed++;
            return;
        }
        if (a[i].value != b[i].value) {
            std::cerr << "Record " << i << " value mismatch: " << a[i].value << " vs " << b[i].value << std::endl;
            tests_failed++;
            return;
        }
    }
    tests_passed++;
}

void test_empty() {
    std::vector<Record> records;
    auto encoded = encode(records);
    std::vector<uint8_t> expected = {'O','G','C','1','\n',0,0,0,0};
    assert_equal(encoded, expected);
    auto decoded = decode(encoded);
    assert_equal(decoded, records);
}

void test_single() {
    std::vector<Record> records = {{1, "test", -123456789LL}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert_equal(decoded, records);
}

void test_multiple() {
    std::vector<Record> records = {
        {0, "0", 68856894251056856LL},
        {1, "b c0", -233957124999232821LL},
        {2, "日本0", -232942477253485299LL}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert_equal(decoded, records);
}

void test_duplicate_id() {
    std::vector<Record> records = {{1, "a", 1}, {1, "b", 2}};
    try {
        auto encoded = encode(records);
        auto decoded = decode(encoded);
        tests_failed++;
    } catch (...) {
        tests_passed++;
    }
}

void test_trailing_bytes() {
    std::vector<Record> records = {{1, "a", 1}};
    auto encoded = encode(records);
    encoded.push_back(0);
    try {
        decode(encoded);
        tests_failed++;
    } catch (...) {
        tests_passed++;
    }
}

void test_bad_magic() {
    std::vector<uint8_t> bad = {'X','G','C','1','\n',0,0,0,0};
    try {
        decode(bad);
        tests_failed++;
    } catch (...) {
        tests_passed++;
    }
}

void test_truncated() {
    std::vector<uint8_t> bad = {'O','G','C','1','\n',1,0,0,0};
    try {
        decode(bad);
        tests_failed++;
    } catch (...) {
        tests_passed++;
    }
}

void test_name_too_long() {
    std::vector<Record> records = {{1, std::string(1025, 'a'), 1}};
    try {
        encode(records);
        tests_failed++;
    } catch (...) {
        tests_passed++;
    }
}

void test_too_many_records() {
    std::vector<Record> records;
    for (int i = 0; i < 10001; ++i) {
        records.push_back({(uint32_t)i, "x", 1});
    }
    try {
        encode(records);
        tests_failed++;
    } catch (...) {
        tests_passed++;
    }
}

void test_roundtrip_public_case() {
    std::vector<Record> records = {
        {0, "0", 68856894251056856LL},
        {1, "b c0", -233957124999232821LL},
        {2, "日本0", -232942477253485299LL},
        {3, "0", 955139844676822483LL},
        {4, "b c0", -982883216065862986LL},
        {5, "日本0", -1013209677606831142LL},
        {6, "x\"y0", 328776324058667354LL},
        {7, "x\"y0", -1264979447955638LL},
        {8, "0", -433595158558128308LL},
        {9, "b c0", 220906017986201192LL}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    assert_equal(decoded, records);
}

int main() {
    test_empty();
    test_single();
    test_multiple();
    test_duplicate_id();
    test_trailing_bytes();
    test_bad_magic();
    test_truncated();
    test_name_too_long();
    test_too_many_records();
    test_roundtrip_public_case();

    std::cout << "Tests passed: " << tests_passed << ", failed: " << tests_failed << std::endl;
    return tests_failed > 0 ? 1 : 0;
}
