# JobQueue Implementation

A SQLite-based job queue implementation with support for claiming, completing, and failing jobs with retry logic.

## Features

- **Unique key enforcement**: First enqueue wins for duplicate keys
- **Atomic claiming**: Selects oldest available job, increments attempts, sets owner and lease expiry
- **Lease management**: Jobs with expired leases become available for re-claiming
- **Retry logic**: Failed jobs re-queue unless max_attempts is exhausted
- **Concurrent safety**: Uses SQLite WAL mode for multi-process access

## API

```python
class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3)
    def enqueue(self, key: str, payload: any) -> bool
    def claim(self, worker: str, now: float, lease: float) -> dict | None
    def complete(self, key: str, worker: str) -> bool
    def fail(self, key: str, worker: str) -> bool
    def status(self, key: str) -> dict | None
```

### Methods

- `enqueue(key, payload)`: Adds a job if key is unique. Returns True on success, False if key exists.
- `claim(worker, now, lease)`: Atomically claims the oldest available job. Returns `{key, payload, attempts}` or None.
- `complete(key, worker)`: Marks job as done if owned by worker. Returns True on success.
- `fail(key, worker)`: Re-queues or marks as failed if owned by worker. Returns True if job existed.
- `status(key)`: Returns `{state, attempts}` or None if key doesn't exist.

### States

- `queued`: Available for claiming
- `leased`: Currently claimed with expiry
- `done`: Successfully completed
- `failed`: Exhausted all attempts

## Validation

- `key` and `worker` must be non-empty strings
- `lease` must be positive
- `max_attempts` must be a positive integer
- Invalid arguments raise `ValueError`

## Testing

Run tests with:
```bash
python3 -m unittest test_solution.py
```

Or use the project's fixed runner:
```bash
run_tests
```
