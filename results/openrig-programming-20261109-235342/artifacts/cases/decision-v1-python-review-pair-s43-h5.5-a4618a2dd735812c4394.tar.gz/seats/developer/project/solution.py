import sqlite3
import json
import time

class JobQueue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT,
                state TEXT NOT NULL DEFAULT 'queued',
                attempts INTEGER NOT NULL DEFAULT 0,
                owner TEXT,
                lease_until REAL,
                inserted_at REAL NOT NULL DEFAULT (strftime('%s', 'now'))
            )
        """)
        conn.commit()
        conn.close()

    def _get_conn(self):
        conn = sqlite3.connect(self.path)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def enqueue(self, key, payload):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        conn = self._get_conn()
        try:
            cursor = conn.execute(
                "INSERT OR IGNORE INTO jobs (key, payload, state, attempts, inserted_at) VALUES (?, ?, 'queued', 0, strftime('%s', 'now'))",
                (key, json.dumps(payload))
            )
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    def claim(self, worker, now, lease):
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        if not isinstance(lease, (int, float)) or lease <= 0:
            raise ValueError("lease must be a positive number")
        
        conn = self._get_conn()
        try:
            # First, check for expired jobs with final attempts and mark them as failed
            conn.execute("""
                UPDATE jobs SET state = 'failed'
                WHERE state = 'leased' AND lease_until <= ? AND attempts >= ?
            """, (now, self.max_attempts))
            
            # Find the oldest job that is queued or leased (expired) with attempts < max_attempts
            cursor = conn.execute("""
                SELECT key, payload, attempts FROM jobs
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                AND attempts < ?
                ORDER BY inserted_at ASC
                LIMIT 1
            """, (now, self.max_attempts))
            
            row = cursor.fetchone()
            if row is None:
                return None
            
            key, payload_json, attempts = row
            new_attempts = attempts + 1
            lease_until = now + lease
            
            # If this is the final attempt, mark as failed immediately
            if new_attempts >= self.max_attempts:
                conn.execute("""
                    UPDATE jobs SET state = 'failed', owner = ?, lease_until = ?, attempts = ?
                    WHERE key = ?
                """, (worker, lease_until, new_attempts, key))
            else:
                conn.execute("""
                    UPDATE jobs SET state = 'leased', owner = ?, lease_until = ?, attempts = ?
                    WHERE key = ?
                """, (worker, lease_until, new_attempts, key))
            
            conn.commit()
            return {"key": key, "payload": json.loads(payload_json), "attempts": new_attempts}
        finally:
            conn.close()

    def complete(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = self._get_conn()
        try:
            cursor = conn.execute("""
                UPDATE jobs SET state = 'done'
                WHERE key = ? AND state = 'leased' AND owner = ?
            """, (key, worker))
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    def fail(self, key, worker):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        if not worker or not isinstance(worker, str):
            raise ValueError("worker must be a non-empty string")
        
        conn = self._get_conn()
        try:
            # Get the job's attempts
            cursor = conn.execute("""
                SELECT attempts FROM jobs WHERE key = ? AND state = 'leased' AND owner = ?
            """, (key, worker))
            row = cursor.fetchone()
            if row is None:
                return False
            
            attempts = row[0]
            if attempts >= self.max_attempts:
                # Mark as failed
                conn.execute("""
                    UPDATE jobs SET state = 'failed' WHERE key = ?
                """, (key,))
            else:
                # Re-queue
                conn.execute("""
                    UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL
                    WHERE key = ?
                """, (key,))
            conn.commit()
            return True
        finally:
            conn.close()

    def status(self, key):
        if not key or not isinstance(key, str):
            raise ValueError("key must be a non-empty string")
        
        conn = self._get_conn()
        try:
            cursor = conn.execute("""
                SELECT state, attempts FROM jobs WHERE key = ?
            """, (key,))
            row = cursor.fetchone()
            if row is None:
                return None
            return {"state": row[0], "attempts": row[1]}
        finally:
            conn.close()
