import unittest
import tempfile
import os
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, 'test.db')

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.temp_dir)

    def test_enqueue_first_wins(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("key1", {"data": 1}))
        self.assertFalse(q.enqueue("key1", {"data": 2}))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 0)

    def test_claim_basic(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        result = q.claim("worker1", 100.0, 5.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["key"], "key1")
        self.assertEqual(result["payload"], {"data": 1})
        self.assertEqual(result["attempts"], 1)

    def test_claim_no_available_jobs(self):
        q = JobQueue(self.db_path)
        result = q.claim("worker1", 100.0, 5.0)
        self.assertIsNone(result)

    def test_claim_expired_lease(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        # Claim with short lease
        result1 = q.claim("worker1", 100.0, 1.0)
        self.assertIsNotNone(result1)
        # Try to claim again before lease expires
        result2 = q.claim("worker2", 100.5, 5.0)
        self.assertIsNone(result2)
        # After lease expires
        result3 = q.claim("worker2", 102.0, 5.0)
        self.assertIsNotNone(result3)
        self.assertEqual(result3["key"], "key1")
        self.assertEqual(result3["attempts"], 2)

    def test_complete_success(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 100.0, 5.0)
        self.assertTrue(q.complete("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "done")

    def test_complete_wrong_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 100.0, 5.0)
        self.assertFalse(q.complete("key1", "wrong_worker"))

    def test_fail_requeue(self):
        q = JobQueue(self.db_path, max_attempts=3)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 100.0, 5.0)
        self.assertTrue(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 1)

    def test_fail_exhausted_attempts(self):
        q = JobQueue(self.db_path, max_attempts=2)
        q.enqueue("key1", {"data": 1})
        q.claim("worker1", 100.0, 5.0)
        self.assertTrue(q.fail("key1", "worker1"))
        # After fail, job is re-queued with attempts=1
        status = q.status("key1")
        self.assertEqual(status["state"], "queued")
        self.assertEqual(status["attempts"], 1)
        # Claim again, now attempts=2 and job becomes failed
        result = q.claim("worker1", 100.0, 5.0)
        self.assertIsNotNone(result)
        self.assertEqual(result["attempts"], 2)
        # Job is now failed, so fail() should return False
        self.assertFalse(q.fail("key1", "worker1"))
        status = q.status("key1")
        self.assertEqual(status["state"], "failed")

    def test_status_nonexistent(self):
        q = JobQueue(self.db_path)
        self.assertIsNone(q.status("nonexistent"))

    def test_invalid_max_attempts(self):
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=0)
        with self.assertRaises(ValueError):
            JobQueue(self.db_path, max_attempts=-1)

    def test_invalid_key(self):
        q = JobQueue(self.db_path)
        with self.assertRaises(ValueError):
            q.enqueue("", {"data": 1})
        with self.assertRaises(ValueError):
            q.claim("", 100.0, 5.0)
        with self.assertRaises(ValueError):
            q.complete("", "worker1")
        with self.assertRaises(ValueError):
            q.fail("", "worker1")
        with self.assertRaises(ValueError):
            q.status("")

    def test_invalid_worker(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        with self.assertRaises(ValueError):
            q.claim("", 100.0, 5.0)
        with self.assertRaises(ValueError):
            q.complete("key1", "")
        with self.assertRaises(ValueError):
            q.fail("key1", "")

    def test_invalid_lease(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        with self.assertRaises(ValueError):
            q.claim("worker1", 100.0, 0)
        with self.assertRaises(ValueError):
            q.claim("worker1", 100.0, -1)

    def test_claim_oldest_first(self):
        q = JobQueue(self.db_path)
        q.enqueue("key1", {"data": 1})
        q.enqueue("key2", {"data": 2})
        result = q.claim("worker1", 100.0, 5.0)
        self.assertEqual(result["key"], "key1")

    def test_case_from_task(self):
        q = JobQueue(self.db_path)
        self.assertTrue(q.enqueue("a", {"v": 5304}))
        self.assertFalse(q.enqueue("a", "ignored"))
        result = q.claim("w", 0, 5)
        self.assertEqual(result, {"key": "a", "payload": {"v": 5304}, "attempts": 1})
        self.assertFalse(q.complete("a", "wrong"))
        self.assertTrue(q.fail("a", "w"))
        result = q.claim("w2", 1, 5)
        self.assertEqual(result, {"key": "a", "payload": {"v": 5304}, "attempts": 2})
        self.assertTrue(q.complete("a", "w2"))
        status = q.status("a")
        self.assertEqual(status, {"state": "done", "attempts": 2})
        result = q.claim("w3", 100, 5)
        self.assertIsNone(result)

    def test_max_attempts_1(self):
        q = JobQueue(self.db_path, max_attempts=1)
        self.assertTrue(q.enqueue("x", 0))
        result = q.claim("w", 0, 2)
        self.assertIsNotNone(result)
        result = q.claim("other", 2, 2)
        self.assertIsNone(result)
        status = q.status("x")
        self.assertEqual(status["state"], "failed")

if __name__ == '__main__':
    unittest.main()
