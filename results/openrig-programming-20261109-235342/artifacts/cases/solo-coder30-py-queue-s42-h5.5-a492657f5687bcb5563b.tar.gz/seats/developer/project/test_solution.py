import unittest
import tempfile
import os
import json
from solution import JobQueue

class TestJobQueue(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, 'test.db')
        self.queue = JobQueue(self.db_path, max_attempts=3)
    
    def tearDown(self):
        self.temp_dir.cleanup()
    
    def test_enqueue_new_job(self):
        """Test enqueuing a new job"""
        result = self.queue.enqueue('job1', {'data': 'test'})
        self.assertTrue(result)
        
        # Try to enqueue again with same key
        result = self.queue.enqueue('job1', {'data': 'test2'})
        self.assertFalse(result)
    
    def test_claim_and_complete(self):
        """Test claiming and completing a job"""
        self.queue.enqueue('job1', {'data': 'test'})
        
        # Claim the job
        job = self.queue.claim('worker1', 0, 10)
        self.assertIsNotNone(job)
        self.assertEqual(job['key'], 'job1')
        self.assertEqual(job['attempts'], 1)
        
        # Complete the job
        result = self.queue.complete('job1', 'worker1')
        self.assertTrue(result)
        
        # Check status
        status = self.queue.status('job1')
        self.assertIsNotNone(status)
        self.assertEqual(status['state'], 'done')
        self.assertEqual(status['attempts'], 1)
    
    def test_claim_and_fail(self):
        """Test claiming and failing a job"""
        self.queue.enqueue('job1', {'data': 'test'})
        
        # Claim the job
        job = self.queue.claim('worker1', 0, 10)
        self.assertIsNotNone(job)
        
        # Fail the job
        result = self.queue.fail('job1', 'worker1')
        self.assertTrue(result)
        
        # Check status
        status = self.queue.status('job1')
        self.assertIsNotNone(status)
        self.assertEqual(status['state'], 'queued')
        self.assertEqual(status['attempts'], 2)
    
    def test_fail_final_attempt(self):
        """Test failing a job on its final attempt"""
        self.queue.enqueue('job1', {'data': 'test'})
        
        # Claim and fail 2 times to reach max attempts
        for i in range(2):
            job = self.queue.claim('worker1', 0, 10)
            self.assertIsNotNone(job)
            result = self.queue.fail('job1', 'worker1')
            self.assertTrue(result)
        
        # Claim and fail for the final time
        job = self.queue.claim('worker1', 0, 10)
        self.assertIsNotNone(job)
        result = self.queue.fail('job1', 'worker1')
        self.assertTrue(result)
        
        # Check status - should be failed
        status = self.queue.status('job1')
        self.assertIsNotNone(status)
        self.assertEqual(status['state'], 'failed')
        self.assertEqual(status['attempts'], 3)
    
    def test_status_nonexistent(self):
        """Test status of non-existent job"""
        status = self.queue.status('nonexistent')
        self.assertIsNone(status)
    
    def test_claim_expired_lease(self):
        """Test claiming a job with expired lease"""
        self.queue.enqueue('job1', {'data': 'test'})
        
        # Claim the job
        job = self.queue.claim('worker1', 0, 10)
        self.assertIsNotNone(job)
        
        # Claim again with expired lease (now < lease_until)
        job2 = self.queue.claim('worker2', 5, 10)
        self.assertIsNone(job2)
        
        # Claim again with valid expired lease (now > lease_until)
        job3 = self.queue.claim('worker2', 15, 10)
        self.assertIsNotNone(job3)
        self.assertEqual(job3['key'], 'job1')
        self.assertEqual(job3['attempts'], 2)
    
    def test_invalid_arguments(self):
        """Test that invalid arguments raise ValueError"""
        with self.assertRaises(ValueError):
            self.queue.enqueue('', {'data': 'test'})
        
        with self.assertRaises(ValueError):
            self.queue.claim('worker', 0, 10)
        
        with self.assertRaises(ValueError):
            self.queue.claim('', 0, 10)
        
        with self.assertRaises(ValueError):
            self.queue.claim('worker', 0, 0)
        
        with self.assertRaises(ValueError):
            self.queue.complete('job1', '')
        
        with self.assertRaises(ValueError):
            self.queue.fail('job1', '')
        
        with self.assertRaises(ValueError):
            self.queue.status('')

if __name__ == '__main__':
    unittest.main()