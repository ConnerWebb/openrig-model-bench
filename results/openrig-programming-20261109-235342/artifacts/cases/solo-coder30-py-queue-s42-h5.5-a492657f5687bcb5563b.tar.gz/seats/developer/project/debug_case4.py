#!/usr/bin/env python3

import tempfile
import os
from solution import JobQueue

# Create a temporary database
temp_dir = tempfile.TemporaryDirectory()
db_path = os.path.join(temp_dir.name, 'test.db')

# Create queue with max_attempts=1
queue = JobQueue(db_path, max_attempts=1)

print("Step 1: enqueue 'x' with payload 0")
result = queue.enqueue('x', 0)
print(f"Enqueue result: {result}")

print("\nStep 2: claim by 'w' at time 0 with lease 2")
job = queue.claim('w', 0, 2)
print(f"Claim result: {job}")

print("\nStep 3: claim by 'other' at time 2 with lease 2")
job2 = queue.claim('other', 2, 2)
print(f"Second claim result: {job2}")

print("\nStep 4: status")
status = queue.status('x')
print(f"Status: {status}")

temp_dir.cleanup()