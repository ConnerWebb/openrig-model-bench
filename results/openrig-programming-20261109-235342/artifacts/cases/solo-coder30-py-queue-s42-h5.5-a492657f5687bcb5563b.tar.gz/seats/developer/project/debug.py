import sqlite3
import json

# Let's manually trace through what should happen
conn = sqlite3.connect('test.db', check_same_thread=False)
conn.execute("PRAGMA foreign_keys = ON")

# Create table
conn.execute('''
    CREATE TABLE IF NOT EXISTS jobs (
        key TEXT PRIMARY KEY,
        payload TEXT NOT NULL,
        state TEXT NOT NULL DEFAULT 'queued',
        owner TEXT,
        lease_until REAL,
        attempts INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    )
''')

# Enqueue a job
payload_json = json.dumps({"v": 5304})
conn.execute('''
    INSERT INTO jobs (key, payload) 
    VALUES (?, ?)
''', ('a', payload_json))

# Check the job
cursor = conn.execute('SELECT * FROM jobs WHERE key = ?', ('a',))
print("After enqueue:", cursor.fetchone())

# Claim the job
now = 0
lease = 5
cursor = conn.execute('''
    SELECT key, payload, attempts FROM jobs 
    WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
    AND attempts < ?
    ORDER BY created_at ASC
    LIMIT 1
''', (now, 3))

row = cursor.fetchone()
print("Job to claim:", row)

if row:
    key, payload_json, attempts = row
    print(f"Key: {key}, Payload: {payload_json}, Attempts: {attempts}")
    
    # Update the job to be leased
    lease_until = now + lease
    attempts += 1
    
    print(f"Updating to leased with lease_until: {lease_until}")
    
    conn.execute('''
        UPDATE jobs 
        SET state = 'leased', 
            owner = ?, 
            lease_until = ?, 
            attempts = ?,
            updated_at = strftime('%s', 'now')
        WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
    ''', ('w', lease_until, attempts, key, now))
    
    print("Update affected rows:", conn.rowcount)
    
    cursor = conn.execute('SELECT * FROM jobs WHERE key = ?', ('a',))
    print("After claim:", cursor.fetchone())

conn.commit()
conn.close()