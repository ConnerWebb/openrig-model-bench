#!/usr/bin/env python3

import tempfile
import os
from solution import JobQueue

# Create a temporary database file
with tempfile.TemporaryDirectory() as d:
    db_path = os.path.join(d, 'test.db')
    
    # Create queue with max_attempts=1
    jq = JobQueue(path=db_path, max_attempts=1)
    
    print("Step 1: enqueue")
    result = jq.enqueue('x', 0)
    print(f"Enqueue result: {result}")
    
    print("\nStep 2: claim by w")
    result = jq.claim('w', 0, 2)
    print(f"Claim result: {result}")
    
    print("\nStep 3: claim by other")
    result = jq.claim('other', 2, 2)
    print(f"Second claim result: {result}")
    
    print("\nStep 4: status")
    status = jq.status('x')
    print(f"Status: {status}")