#!/usr/bin/env python3

import sys
sys.path.insert(0, '/work')

from solution import JobQueue
import tempfile
import os

# Create a temporary database file
with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
    db_path = f.name

try:
    # Create job queue
    jq = JobQueue(db_path)
    
    # Test the exact sequence from failing case
    print("1. Enqueue job 'a'")
    result1 = jq.enqueue("a", {"v": 5304})
    print(f"   Result: {result1}")
    
    print("2. Try to enqueue 'a' again (should return False)")
    result2 = jq.enqueue("a", "ignored")
    print(f"   Result: {result2}")
    
    print("3. Claim job 'a' with worker 'w' at time 0 with lease 5")
    job3 = jq.claim("w", 0, 5)
    print(f"   Result: {job3}")
    
    print("4. Try to complete with wrong worker 'wrong' (should return False)")
    result4 = jq.complete("a", "wrong")
    print(f"   Result: {result4}")
    
    print("5. Fail job 'a' with worker 'w'")
    result5 = jq.fail("a", "w")
    print(f"   Result: {result5}")
    
    print("6. Claim again with worker 'w2' at time 1 with lease 5")
    job6 = jq.claim("w2", 1, 5)
    print(f"   Result: {job6}")
    
    print("7. Complete with worker 'w2'")
    result7 = jq.complete("a", "w2")
    print(f"   Result: {result7}")
    
    print("8. Status of job 'a'")
    status8 = jq.status("a")
    print(f"   Result: {status8}")
    
    print("9. Try to claim with worker 'w3' at time 100")
    job9 = jq.claim("w3", 100, 5)
    print(f"   Result: {job9}")
    
finally:
    # Clean up
    os.unlink(db_path)