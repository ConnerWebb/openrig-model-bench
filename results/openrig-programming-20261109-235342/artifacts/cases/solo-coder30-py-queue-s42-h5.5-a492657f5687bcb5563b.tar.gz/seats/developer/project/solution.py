import sqlite3
import json
from contextlib import contextmanager

class JobQueue:
    def __init__(self, path, max_attempts=3):
        self.path = path
        self.max_attempts = max_attempts
        self._init_db()
    
    def _get_db(self):
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    
    def _init_db(self):
        with self._get_db() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS jobs (
                    key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'queued',
                    owner TEXT,
                    lease_until REAL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                )
            ''')
    
    def enqueue(self, key, payload):
        """Add a job to the queue. Returns True if the job was added, False if a job with the same key already exists."""
        if not key:
            raise ValueError("Key must be non-empty")
        
        payload_json = json.dumps(payload)
        
        try:
            with self._get_db() as conn:
                conn.execute('''
                    INSERT INTO jobs (key, payload) 
                    VALUES (?, ?)
                ''', (key, payload_json))
                return True
        except sqlite3.IntegrityError:
            # Job with this key already exists
            return False
    
    def claim(self, worker, now, lease):
        """Claim a job for processing. Returns job dict or None if no job available."""
        if not worker:
            raise ValueError("Worker must be non-empty")
        if lease <= 0:
            raise ValueError("Lease must be positive")
        
        with self._get_db() as conn:
            # Find a job that is either queued or leased and expired
            cursor = conn.execute('''
                SELECT key, payload, attempts FROM jobs 
                WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                ORDER BY created_at ASC
                LIMIT 1
            ''', (now,))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            key, payload_json, attempts = row
            
            # Check if this claim would exceed max attempts
            new_attempts = attempts + 1
            if new_attempts > self.max_attempts:
                # This job has already been claimed max_attempts times, so it's failed
                # Mark the job as failed
                conn.execute('''
                    UPDATE jobs 
                    SET state = 'failed',
                        updated_at = strftime('%s', 'now')
                    WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
                ''', (key, now))
                return None
            
            # Update the job to be leased
            lease_until = now + lease
            conn.execute('''
                UPDATE jobs 
                SET state = 'leased', 
                    owner = ?, 
                    lease_until = ?, 
                    attempts = ?,
                    updated_at = strftime('%s', 'now')
                WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
            ''', (worker, lease_until, new_attempts, key, now))
            
            if conn.total_changes == 0:
                # Another process claimed this job
                return None
            
            # Return the job details
            return {
                'key': key,
                'payload': json.loads(payload_json),
                'attempts': new_attempts
            }
    
    def complete(self, key, worker):
        """Mark a job as completed. Returns True if successful."""
        if not key or not worker:
            raise ValueError("Key and worker must be non-empty")
        
        with self._get_db() as conn:
            # Check if the job exists and is owned by the worker
            cursor = conn.execute('''
                SELECT state FROM jobs WHERE key = ? AND owner = ?
            ''', (key, worker))
            
            row = cursor.fetchone()
            if not row:
                return False
            
            state = row[0]
            
            # If job is not leased, we can't complete it
            if state != 'leased':
                return False
            
            # Mark as completed
            conn.execute('''
                UPDATE jobs 
                SET state = 'done',
                    updated_at = strftime('%s', 'now')
                WHERE key = ? AND owner = ? AND state = 'leased'
            ''', (key, worker))
            
            # Return True if the update was successful
            return conn.total_changes > 0
    
    def fail(self, key, worker):
        """Mark a job as failed. Returns True if successful."""
        if not key or not worker:
            raise ValueError("Key and worker must be non-empty")
        
        with self._get_db() as conn:
            # Check if the job exists and is owned by the worker
            cursor = conn.execute('''
                SELECT attempts, state FROM jobs WHERE key = ? AND owner = ?
            ''', (key, worker))
            
            row = cursor.fetchone()
            if not row:
                return False
            
            attempts, state = row
            
            # If job is not leased, we can't fail it
            if state != 'leased':
                return False
            
            # Increment attempts when failing
            new_attempts = attempts + 1
            
            # Check if this is the final attempt
            if new_attempts >= self.max_attempts:
                # Mark as failed
                conn.execute('''
                    UPDATE jobs 
                    SET state = 'failed',
                        updated_at = strftime('%s', 'now')
                    WHERE key = ? AND owner = ? AND state = 'leased'
                ''', (key, worker))
            else:
                # Otherwise, reset to queued state and increment attempts
                conn.execute('''
                    UPDATE jobs 
                    SET state = 'queued',
                        attempts = ?,
                        owner = NULL,
                        lease_until = NULL,
                        updated_at = strftime('%s', 'now')
                    WHERE key = ? AND owner = ? AND state = 'leased'
                ''', (new_attempts, key, worker))
            
            # Return True if the update was successful
            return conn.total_changes > 0
    
    def status(self, key):
        """Get the status of a job. Returns a dict with state and attempts or None if the job doesn't exist."""
        if not key:
            raise ValueError("Key must be non-empty")
        
        with self._get_db() as conn:
            cursor = conn.execute('''
                SELECT state, attempts FROM jobs WHERE key = ?
            ''', (key,))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            state, attempts = row
            return {
                'state': state,
                'attempts': attempts
            }