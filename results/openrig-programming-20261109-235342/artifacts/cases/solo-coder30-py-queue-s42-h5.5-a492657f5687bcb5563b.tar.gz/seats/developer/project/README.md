# JobQueue Implementation

This is a SQLite-based implementation of a JobQueue system with the following features:

## Features

- **Thread-safe**: Uses SQLite with proper locking mechanisms
- **Distributed**: Multiple instances/processes can share the same database
- **Atomic operations**: All operations are atomic and prevent lost/duplicate claims
- **Leasing**: Jobs can be leased for processing with a timeout
- **Retry logic**: Failed jobs are retried up to `max_attempts` times
- **Status tracking**: Each job maintains its state and attempt count

## API

### `JobQueue(path, max_attempts=3)`

Creates a new JobQueue instance using the specified SQLite database file.

### `enqueue(key, payload) -> bool`

Add a job to the queue. Returns `True` if the job was added, `False` if a job with the same key already exists.

### `claim(worker, now, lease) -> dict or None`

Claim a job for processing. Returns a dictionary with job details or `None` if no job is available.

### `complete(key, worker) -> bool`

Mark a job as completed. Returns `True` if successful.

### `fail(key, worker) -> bool`

Mark a job as failed. Returns `True` if successful.

### `status(key) -> dict or None`

Get the status of a job. Returns a dictionary with `state` and `attempts` or `None` if the job doesn't exist.

## Requirements

- Python 3.6+
- SQLite3 (included in standard library)

## Usage Example

```python
from solution import JobQueue

# Create a queue
queue = JobQueue('jobs.db', max_attempts=3)

# Add jobs
queue.enqueue('job1', {'data': 'example'})
queue.enqueue('job2', {'data': 'another'})

# Claim a job
job = queue.claim('worker1', time.time(), 30.0)
if job:
    print(f"Processing job {job['key']}")
    # ... process job ...
    queue.complete(job['key'], 'worker1')
```