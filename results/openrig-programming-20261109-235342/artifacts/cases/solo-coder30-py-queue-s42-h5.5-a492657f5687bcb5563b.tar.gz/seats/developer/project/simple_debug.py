import json
import sqlite3

# Let me trace through the exact case 0 sequence
def debug_case_0():
    print("=== Debugging Case 0 Step by Step ===")
    
    # Create a fresh database
    conn = sqlite3.connect('debug2.db')
    conn.execute("PRAGMA foreign_keys = ON")
    
    # Initialize table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS jobs (
            key TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            state TEXT NOT NULL DEFAULT 'queued',
            owner TEXT,
            lease_until REAL,
            attempts INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        )
    ''')
    
    # Clear any existing data
    conn.execute("DELETE FROM jobs")
    
    # Step 1: enqueue "a" with {"v": 5304} - should return True
    try:
        conn.execute('''
            INSERT INTO jobs (key, payload) 
            VALUES (?, ?)
        ''', ('a', json.dumps({"v": 5304})))
        print("Step 1: Enqueue 'a' - SUCCESS")
    except Exception as e:
        print(f"Step 1: Enqueue 'a' - FAILED: {e}")
    
    # Step 2: enqueue "a" with "ignored" - should return False
    try:
        conn.execute('''
            INSERT INTO jobs (key, payload) 
            VALUES (?, ?)
        ''', ('a', "ignored"))
        print("Step 2: Enqueue 'a' again - UNEXPECTED SUCCESS")
    except sqlite3.IntegrityError:
        print("Step 2: Enqueue 'a' again - SUCCESS (correctly failed)")
    
    # Step 3: claim by worker "w" at time 0 with lease 5 - should return job with attempts = 1
    cursor = conn.execute('''
        SELECT key, payload, attempts FROM jobs 
        WHERE (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
        AND attempts < ?
        ORDER BY created_at ASC
        LIMIT 1
    ''', (0, 3))
    
    row = cursor.fetchone()
    print(f"Step 3: Find job - Found row: {row}")
    
    if row:
        key, payload_json, attempts = row
        print(f"Found job: key={key}, payload={payload_json}, attempts={attempts}")
        
        # Update to leased
        lease_until = 0 + 5
        attempts += 1
        
        rows_affected = conn.execute('''
            UPDATE jobs 
            SET state = 'leased', 
                owner = ?, 
                lease_until = ?, 
                attempts = ?,
                updated_at = strftime('%s', 'now')
            WHERE key = ? AND (state = 'queued' OR (state = 'leased' AND lease_until <= ?))
        ''', ('w', lease_until, attempts, key, 0))
        
        print(f"Step 3: Update to leased - Rows affected: {rows_affected.rowcount}")
        
        # Check the job status
        cursor = conn.execute('SELECT key, state, owner, lease_until, attempts FROM jobs WHERE key = ?', ('a',))
        row = cursor.fetchone()
        print(f"Step 3: Job status after claim: {row}")
    
    # Step 4: complete "a" with wrong worker "wrong" - should return False
    # This is a bit tricky - I need to check if the complete works correctly
    # Let's just see what happens when we try to complete with wrong worker
    rows_affected = conn.execute('''
        UPDATE jobs 
        SET state = 'done',
            updated_at = strftime('%s', 'now')
        WHERE key = ? AND owner = ? AND state = 'leased'
    ''', ('a', 'wrong'))
    
    print(f"Step 4: Complete with wrong worker - Rows affected: {rows_affected.rowcount}")
    
    # Check status after step 4
    cursor = conn.execute('SELECT key, state, owner, lease_until, attempts FROM jobs WHERE key = ?', ('a',))
    row = cursor.fetchone()
    print(f"Step 4: Job status after wrong complete: {row}")
    
    # Step 5: fail "a" with correct worker "w" - should return True
    # This is where I think the problem is
    rows_affected = conn.execute('''
        SELECT attempts, state FROM jobs WHERE key = ?
    ''', ('a',))
    
    row = rows_affected.fetchone()
    if row:
        attempts, state = row
        print(f"Step 5: Before fail - attempts={attempts}, state={state}")
        
        # The fail logic should reset the job to queued state with incremented attempts
        if state == 'leased':
            # Check if this is the final attempt
            if attempts >= 3:  # max_attempts
                # Mark as failed
                conn.execute('''
                    UPDATE jobs 
                    SET state = 'failed',
                        updated_at = strftime('%s', 'now')
                    WHERE key = ? AND owner = ? AND state = 'leased'
                ''', ('a', 'w'))
                print("Step 5: Fail - Marked as failed (final attempt)")
            else:
                # Reset to queued state with incremented attempts
                conn.execute('''
                    UPDATE jobs 
                    SET state = 'queued',
                        attempts = attempts + 1,
                        owner = NULL,
                        lease_until = NULL,
                        updated_at = strftime('%s', 'now')
                    WHERE key = ? AND owner = ? AND state = 'leased'
                ''', ('a', 'w'))
                print("Step 5: Fail - Reset to queued with incremented attempts")
    
    # Check final status
    cursor = conn.execute('SELECT key, state, owner, lease_until, attempts FROM jobs WHERE key = ?', ('a',))
    row = cursor.fetchone()
    print(f"Step 5: Job status after fail: {row}")
    
    conn.commit()
    conn.close()

debug_case_0()