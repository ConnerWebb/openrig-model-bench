# Buffer Library

A C++20 RAII buffer class for managing dynamically allocated byte arrays.

## Features

- **RAII**: Automatic memory management with constructor/destructor
- **Bounds checking**: `operator[]` throws `std::out_of_range` for invalid indices
- **Deep copy**: Copy constructor and assignment perform deep copies
- **Move semantics**: Noexcept move constructor and assignment
- **Resizable**: `resize()` preserves existing data and zero-initializes new bytes
- **Self-assignment safe**: Handles self-copy and self-move correctly
- **Moved-from state**: Moved-from buffers have size 0 and are reusable

## API

```cpp
class Buffer {
    // Default constructor (creates empty buffer)
    Buffer(std::size_t n = 0);

    // Destructor
    ~Buffer();

    // Size accessor
    std::size_t size() const noexcept;

    // Mutable element access with bounds checking
    std::uint8_t& operator[](std::size_t i);

    // Const element access with bounds checking
    const std::uint8_t& operator[](std::size_t i) const;

    // Deep copy constructor
    Buffer(const Buffer& other);

    // Deep copy assignment
    Buffer& operator=(const Buffer& other);

    // Noexcept move constructor
    Buffer(Buffer&& other) noexcept;

    // Noexcept move assignment
    Buffer& operator=(Buffer&& other) noexcept;

    // Resize: preserve prefix, zero-initialize new bytes
    void resize(std::size_t k);
};
```

## Usage Examples

```cpp
// Create buffer of size 10
Buffer buf(10);

// Access elements (throws if out of bounds)
buf[0] = 42;
uint8_t val = buf[5];

// Copy buffer
Buffer copy = buf;

// Move buffer
Buffer moved = std::move(buf);

// Resize buffer
buf.resize(20); // Preserves first 10 bytes, zeros bytes 10-19
```

## Testing

Run tests with:
```bash
g++ -std=c++20 -o test Buffer_test.cpp
./test < input
```

Input format: `n grow v1 v2 ... vn`
- `n`: initial buffer size
- `grow`: target size after resize
- `v1...vn`: initial values

Output format: JSON with `value`, `moved_size`, `copy`, and `bounds` fields.
