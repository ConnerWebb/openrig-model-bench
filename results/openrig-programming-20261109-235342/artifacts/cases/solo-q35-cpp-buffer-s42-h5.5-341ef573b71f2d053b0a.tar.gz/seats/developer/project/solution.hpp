#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    // Default constructor
    Buffer(std::size_t n = 0) : p(n > 0 ? new std::uint8_t[n] : nullptr), n(n) {}

    // Destructor
    ~Buffer() { delete[] p; }

    // Size
    std::size_t size() const noexcept { return n; }

    // Mutable operator[]
    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("index out of range");
        }
        return p[i];
    }

    // Const operator[]
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("index out of range");
        }
        return p[i];
    }

    // Copy constructor (deep copy)
    Buffer(const Buffer& other) : p(other.n > 0 ? new std::uint8_t[other.n] : nullptr), n(other.n) {
        if (other.n > 0 && p) {
            std::copy(other.p, other.p + other.n, p);
        }
    }

    // Copy assignment (deep copy)
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] p;
            n = other.n;
            p = n > 0 ? new std::uint8_t[n] : nullptr;
            if (n > 0 && p) {
                std::copy(other.p, other.p + other.n, p);
            }
        }
        return *this;
    }

    // Move constructor (noexcept)
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    // Move assignment (noexcept)
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    // Resize: preserve prefix, zero-initialize new bytes
    void resize(std::size_t k) {
        if (k == n) return;
        if (k == 0) {
            delete[] p;
            p = nullptr;
            n = 0;
            return;
        }
        std::uint8_t* new_p = new std::uint8_t[k];
        std::size_t copy_len = std::min(n, k);
        if (copy_len > 0 && p) {
            std::copy(p, p + copy_len, new_p);
        }
        delete[] p;
        p = new_p;
        n = k;
        // Zero-initialize new bytes
        if (k > copy_len) {
            std::fill(p + copy_len, p + k, static_cast<std::uint8_t>(0));
        }
    }
};
