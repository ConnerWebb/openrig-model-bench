import zipfile
import os
import shutil


def extract_zip(archive_path: str, outdir: str) -> list[str]:
    """
    Extract a ZIP archive into a NEW directory, returning sorted member file paths.
    Reject with ValueError before creating any output if:
    - outdir exists
    - any member is absolute
    - contains .. components
    - backslashes
    - drive-colon (e.g., C:)
    - duplicate normalized file/directory path
    - a symbolic link
    """
    # Validate outdir does not exist
    if os.path.exists(outdir):
        raise ValueError("Output directory already exists")

    # Read the ZIP file and validate all entries before extraction
    with zipfile.ZipFile(archive_path, 'r') as zf:
        # Collect all entries and validate
        entries = []
        seen_paths = set()

        for info in zf.infolist():
            # Get the filename
            name = info.filename

            # Skip directories (they end with /)
            if name.endswith('/'):
                continue

            # Check for symbolic links by checking external_attr
            # Symlinks have type bit set (bit 3 of version field)
            # or external_attr with symlink bit (0o120000)
            ext_attr = info.external_attr >> 16
            if (ext_attr & 0o170000) == 0o120000:  # S_IFLNK
                raise ValueError("Symbolic link found in archive")

            # Check for backslashes
            if '\\' in name:
                raise ValueError("Backslash in path")

            # Check for drive colon (e.g., C:)
            if ':' in name:
                raise ValueError("Drive colon in path")

            # Check for absolute path
            if name.startswith('/') or name.startswith('\\'):
                raise ValueError("Absolute path in archive")

            # Check for .. components
            parts = name.split('/')
            if '..' in parts:
                raise ValueError(".. component in path")

            # Normalize the path
            normalized = os.path.normpath(name)

            # Check for duplicates (including directory entries)
            if normalized in seen_paths:
                raise ValueError("Duplicate path in archive")
            seen_paths.add(normalized)

            # Add parent directories to seen_paths to prevent conflicts
            # e.g., if we have 'a' and 'a/b', 'a' is a duplicate of 'a/'
            parts = normalized.split(os.sep)
            for i in range(1, len(parts)):
                parent = os.sep.join(parts[:i])
                if parent in seen_paths:
                    raise ValueError("Duplicate path in archive")
                seen_paths.add(parent)

            entries.append((name, normalized))

        # Sort entries by normalized path
        entries.sort(key=lambda x: x[1])

        # Create output directory
        os.makedirs(outdir, exist_ok=True)

        # Extract all entries
        for name, normalized in entries:
            # Get the full path
            full_path = os.path.join(outdir, normalized)

            # Ensure the path is within outdir
            if not os.path.abspath(full_path).startswith(os.path.abspath(outdir) + os.sep) and \
               os.path.abspath(full_path) != os.path.abspath(outdir):
                raise ValueError("Path traversal attempt")

            # Create parent directories if needed
            parent_dir = os.path.dirname(full_path)
            if parent_dir:
                os.makedirs(parent_dir, exist_ok=True)

            # Extract the file
            with zf.open(name) as source:
                with open(full_path, 'wb') as target:
                    shutil.copyfileobj(source, target)

    # Return sorted list of file paths (relative to outdir)
    result = []
    for name, _ in entries:
        result.append(name)
    return sorted(result)
