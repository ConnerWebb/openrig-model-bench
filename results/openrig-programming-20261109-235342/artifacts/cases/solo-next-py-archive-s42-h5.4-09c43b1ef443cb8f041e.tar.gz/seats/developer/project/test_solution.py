import unittest
import zipfile
import os
import tempfile
import shutil
from solution import extract_zip


class TestExtractZip(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_basic_extraction(self):
        """Test basic extraction with nested directories"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('folder/', '')
            zf.writestr('folder/a.txt', '5304')
            zf.writestr('b.txt', 'hello 日本')

        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, ['b.txt', 'folder/a.txt'])

        # Verify file contents
        self.assertEqual(open(os.path.join(outdir, 'b.txt')).read(), 'hello 日本')
        self.assertEqual(open(os.path.join(outdir, 'folder/a.txt')).read(), '5304')

    def test_outdir_exists_raises(self):
        """Test that existing outdir raises ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')
        os.makedirs(outdir)

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_absolute_path_raises(self):
        """Test that absolute paths raise ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('/absolute', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_dot_dot_raises(self):
        """Test that .. paths raise ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('../x', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_backslash_raises(self):
        """Test that backslashes raise ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a\\b', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_drive_colon_raises(self):
        """Test that drive colon raises ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('C:bad', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_duplicate_entries_raises(self):
        """Test that duplicate entries raise ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a', 'content1')
            zf.writestr('a', 'content2')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_duplicate_with_subpath_raises(self):
        """Test that 'a' and 'a/b' raise ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a', 'content1')
            zf.writestr('a/b', 'content2')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_symlink_raises(self):
        """Test that symbolic links raise ValueError"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            info = zipfile.ZipInfo('link')
            info.external_attr = (0o120777 << 16)
            zf.writestr(info, '/elsewhere')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

    def test_empty_zip(self):
        """Test that empty ZIP creates empty outdir"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            pass

        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, [])
        self.assertTrue(os.path.isdir(outdir))
        self.assertEqual(len(os.listdir(outdir)), 0)

    def test_preserves_utf8(self):
        """Test that UTF-8 content is preserved"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('utf8.txt', '日本語')

        result = extract_zip(zip_path, outdir)
        self.assertEqual(result, ['utf8.txt'])
        self.assertEqual(open(os.path.join(outdir, 'utf8.txt')).read(), '日本語')

    def test_no_overwrite_existing_files(self):
        """Test that existing files are not overwritten"""
        zip_path = os.path.join(self.test_dir, 'test.zip')
        outdir = os.path.join(self.test_dir, 'out')
        os.makedirs(outdir)
        with open(os.path.join(outdir, 'keep'), 'w') as f:
            f.write('preserve')

        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('a.txt', 'content')

        with self.assertRaises(ValueError):
            extract_zip(zip_path, outdir)

        # Verify original file is preserved
        self.assertEqual(open(os.path.join(outdir, 'keep')).read(), 'preserve')


if __name__ == '__main__':
    unittest.main()
