# extract_zip Implementation

This project implements `extract_zip(archive_path, outdir) -> list[str]` as specified in TASK.txt.

## Functionality

Extracts a ZIP archive into a NEW directory, returning sorted member file paths.

### Validation Rules

The function raises `ValueError` before creating any output if:
- `outdir` already exists
- Any member path is absolute
- Any member contains `..` components
- Any member contains backslashes
- Any member contains a drive colon (e.g., `C:`)
- There are duplicate normalized file/directory paths
- Any member is a symbolic link

### Behavior

- Creates a new output directory
- Preserves UTF-8 file contents
- Preserves nested directory structure
- Returns a sorted list of member file paths
- Empty ZIP creates an empty output directory
- No output on malformed ZIP or validation failure

## Running Tests

```bash
python3 test_solution.py
```

## Public Test Driver

```bash
python3 PUBLIC_DRIVER.py < public-inputs/case-XX.json
```
