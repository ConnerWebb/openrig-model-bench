# Buffer Library

A C++20 buffer implementation with deep-copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep-copy construction/assignment**: Each copy owns its own memory
- **Noexcept move operations**: Efficient transfers with moved-from buffers having size 0
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Resize with preservation**: `resize()` preserves existing data and zero-initializes new elements
- **RAII**: Automatic memory management, no leaks or double frees

## API

```cpp
class Buffer {
    Buffer(std::size_t n = 0);                    // Construct with n zero-initialized bytes
    ~Buffer();                                    // Destructor (RAII)
    
    Buffer(const Buffer& other);                  // Deep copy constructor
    Buffer& operator=(const Buffer& other);       // Deep copy assignment
    
    Buffer(Buffer&& other) noexcept;              // Noexcept move constructor
    Buffer& operator=(Buffer&& other) noexcept;   // Noexcept move assignment
    
    std::size_t size() const noexcept;            // Return buffer size
    
    std::uint8_t& operator[](std::size_t i);      // Mutable access with bounds check
    const std::uint8_t& operator[](std::size_t i) const;  // Const access with bounds check
    
    void resize(std::size_t k);                   // Resize, preserving prefix, zero-init new
};
```

## Usage Example

```cpp
Buffer a(10);           // Create buffer of 10 zero-initialized bytes
a[0] = 42;              // Set first element
Buffer b(a);            // Deep copy - b is independent of a
Buffer c = std::move(b); // Move - b is now empty (size 0)
c.resize(20);           // Resize to 20, preserving first 10 elements
```

## Building and Testing

Compile with C++20 and Clang:
```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

Run public tests:
```bash
run_tests
```

## Requirements

- C++20 compiler
- Clang 22+ recommended
