#include <iostream>
#include <cassert>
#include <stdexcept>
#include <cstdint>
#include <cstddef>
#include "solution.hpp"

void test_default_constructor() {
    Buffer b;
    assert(b.size() == 0);
}

void test_constructor_with_size() {
    Buffer b(10);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < b.size(); ++i) {
        assert(b[i] == 0);
    }
}

void test_copy_constructor() {
    Buffer a(5);
    a[0] = 10;
    a[1] = 20;
    Buffer b(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(b[1] == 20);
    a[0] = 99;
    assert(b[0] == 10);  // Deep copy verified
}

void test_copy_assignment() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(3);
    b = a;
    assert(b.size() == 5);
    assert(b[0] == 10);
    a[0] = 99;
    assert(b[0] == 10);  // Deep copy verified
}

void test_move_constructor() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(std::move(a));
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(a.size() == 0);  // Moved-from is empty
}

void test_move_assignment() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(3);
    b = std::move(a);
    assert(b.size() == 5);
    assert(b[0] == 10);
    assert(a.size() == 0);  // Moved-from is empty
}

void test_move_noexcept() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

void test_self_copy() {
    Buffer a(5);
    a[0] = 10;
    a = a;
    assert(a.size() == 5);
    assert(a[0] == 10);
}

void test_self_move() {
    Buffer a(5);
    a[0] = 10;
    a = std::move(a);
    assert(a.size() == 5);
    assert(a[0] == 10);
}

void test_bounds_check_mutable() {
    Buffer b(5);
    try {
        (void)b[10];
        assert(false);  // Should not reach here
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_bounds_check_const() {
    const Buffer b(5);
    try {
        (void)b[10];
        assert(false);  // Should not reach here
    } catch (const std::out_of_range&) {
        // Expected
    }
}

void test_resize_larger() {
    Buffer b(3);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b.resize(5);
    assert(b.size() == 5);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
    assert(b[3] == 0);
    assert(b[4] == 0);
}

void test_resize_smaller() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    b[2] = 3;
    b[3] = 4;
    b[4] = 5;
    b.resize(3);
    assert(b.size() == 3);
    assert(b[0] == 1);
    assert(b[1] == 2);
    assert(b[2] == 3);
}

void test_resize_same() {
    Buffer b(5);
    b[0] = 1;
    std::size_t old_size = b.size();
    b.resize(5);
    assert(b.size() == old_size);
    assert(b[0] == 1);
}

void test_moved_from_reusable() {
    Buffer a(5);
    a[0] = 10;
    Buffer b(std::move(a));
    assert(a.size() == 0);
    a.resize(3);
    assert(a.size() == 3);
    a[0] = 100;
    assert(a[0] == 100);
}

int main() {
    test_default_constructor();
    test_constructor_with_size();
    test_copy_constructor();
    test_copy_assignment();
    test_move_constructor();
    test_move_assignment();
    test_move_noexcept();
    test_self_copy();
    test_self_move();
    test_bounds_check_mutable();
    test_bounds_check_const();
    test_resize_larger();
    test_resize_smaller();
    test_resize_same();
    test_moved_from_reusable();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
