# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep copy construction/assignment**: Copies are independent of the original
- **Noexcept move operations**: Efficient transfers with moved-from buffers having size 0
- **Bounds-checked access**: Throws `std::out_of_range` on invalid indices
- **Safe resize**: Preserves prefix, zero-initializes new elements
- **RAII**: Automatic resource management, no leaks or double frees

## API

```cpp
class Buffer {
    Buffer(std::size_t n = 0);                    // Construct with size (zero-initialized)
    ~Buffer();                                    // Destructor

    Buffer(const Buffer& other);                  // Deep copy constructor
    Buffer& operator=(const Buffer& other);       // Deep copy assignment

    Buffer(Buffer&& other) noexcept;              // Move constructor
    Buffer& operator=(Buffer&& other) noexcept;   // Move assignment

    std::size_t size() const noexcept;            // Get buffer size
    std::uint8_t& operator[](std::size_t i);      // Mutable access (bounds-checked)
    const std::uint8_t& operator[](std::size_t i) const;  // Const access (bounds-checked)
    void resize(std::size_t k);                   // Resize, preserving prefix
};
```

## Usage Example

```cpp
Buffer a(10);
a[0] = 42;
Buffer b = a;           // Deep copy
Buffer c = std::move(b); // Move, b is now size 0
a.resize(20);           // a now has 20 elements, first 10 preserved
```

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o test_buffer test_buffer.cpp
./test_buffer
```

## Testing

Run `run_tests` to execute all public checks including ASan/UBSan validation.
