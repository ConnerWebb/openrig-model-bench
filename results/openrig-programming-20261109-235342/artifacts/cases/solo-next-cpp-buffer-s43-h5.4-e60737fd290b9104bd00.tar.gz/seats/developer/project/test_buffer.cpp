#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <memory>
#include <atomic>
#include <type_traits>
#include <cstdint>
#include <stdexcept>
#include "solution.hpp"

void test_default_construct() {
    Buffer b;
    if (b.size() != 0) {
        std::cout << "FAIL: default construct size" << std::endl;
        exit(1);
    }
}

void test_construct_size() {
    Buffer b(10);
    if (b.size() != 10) {
        std::cout << "FAIL: construct size" << std::endl;
        exit(1);
    }
    for (std::size_t i = 0; i < b.size(); ++i) {
        if (b[i] != 0) {
            std::cout << "FAIL: construct size init" << std::endl;
            exit(1);
        }
    }
}

void test_copy_construct() {
    Buffer a(5);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    Buffer b(a);
    if (b.size() != 5) {
        std::cout << "FAIL: copy construct size" << std::endl;
        exit(1);
    }
    if (b[0] != 1 || b[1] != 2 || b[2] != 3) {
        std::cout << "FAIL: copy construct values" << std::endl;
        exit(1);
    }
}

void test_copy_assign() {
    Buffer a(5);
    a[0] = 10;
    Buffer b;
    b = a;
    if (b.size() != 5 || b[0] != 10) {
        std::cout << "FAIL: copy assign" << std::endl;
        exit(1);
    }
}

void test_self_copy() {
    Buffer a(3);
    a[0] = 100;
    a = a;
    if (a.size() != 3 || a[0] != 100) {
        std::cout << "FAIL: self copy" << std::endl;
        exit(1);
    }
}

void test_move_construct() {
    Buffer a(4);
    a[0] = 20;
    Buffer b(std::move(a));
    if (a.size() != 0) {
        std::cout << "FAIL: move construct src size" << std::endl;
        exit(1);
    }
    if (b.size() != 4 || b[0] != 20) {
        std::cout << "FAIL: move construct dst" << std::endl;
        exit(1);
    }
}

void test_move_assign() {
    Buffer a(4);
    a[0] = 30;
    Buffer b;
    b = std::move(a);
    if (a.size() != 0) {
        std::cout << "FAIL: move assign src size" << std::endl;
        exit(1);
    }
    if (b.size() != 4 || b[0] != 30) {
        std::cout << "FAIL: move assign dst" << std::endl;
        exit(1);
    }
}

void test_self_move() {
    Buffer a(3);
    a[0] = 200;
    a = std::move(a);
    if (a.size() != 3 || a[0] != 200) {
        std::cout << "FAIL: self move" << std::endl;
        exit(1);
    }
}

void test_bounds() {
    Buffer b(5);
    try {
        (void)b[5];
        std::cout << "FAIL: bounds" << std::endl;
        exit(1);
    } catch (const std::out_of_range&) {
    }
}

void test_resize_grow() {
    Buffer a(3);
    a[0] = 1;
    a[1] = 2;
    a.resize(6);
    if (a.size() != 6) {
        std::cout << "FAIL: resize grow size" << std::endl;
        exit(1);
    }
    if (a[0] != 1 || a[1] != 2) {
        std::cout << "FAIL: resize grow values" << std::endl;
        exit(1);
    }
    for (std::size_t i = 2; i < 6; ++i) {
        if (a[i] != 0) {
            std::cout << "FAIL: resize grow new bytes" << std::endl;
            exit(1);
        }
    }
}

void test_resize_shrink() {
    Buffer a(6);
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a.resize(3);
    if (a.size() != 3 || a[0] != 1 || a[1] != 2 || a[2] != 3) {
        std::cout << "FAIL: resize shrink" << std::endl;
        exit(1);
    }
}

void test_const_access() {
    const Buffer b(3);
    if (b[0] != 0) {
        std::cout << "FAIL: const access" << std::endl;
        exit(1);
    }
}

void test_noexcept_move() {
    static_assert(std::is_nothrow_move_constructible_v<Buffer>);
    static_assert(std::is_nothrow_move_assignable_v<Buffer>);
}

int main() {
    test_default_construct();
    test_construct_size();
    test_copy_construct();
    test_copy_assign();
    test_self_copy();
    test_move_construct();
    test_move_assign();
    test_self_move();
    test_bounds();
    test_resize_grow();
    test_resize_shrink();
    test_const_access();
    test_noexcept_move();
    std::cout << "All tests passed" << std::endl;
    return 0;
}
