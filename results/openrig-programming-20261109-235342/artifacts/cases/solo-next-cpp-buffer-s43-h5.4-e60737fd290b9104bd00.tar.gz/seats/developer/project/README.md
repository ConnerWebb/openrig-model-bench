# Buffer Library

A C++20 RAII-based buffer class with deep-copy semantics, noexcept move operations, and bounds-checked access.

## Features

- `Buffer(size_t n=0)`: Construct buffer of given size, zero-initialized
- `size() const noexcept`: Return current size
- `operator[](size_t)`: Mutable and const bounds-checked access (throws `std::out_of_range`)
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction and assignment
- Noexcept move construction and assignment
- Self-assignment and self-move preserve content
- RAII, no leaks or double frees

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);           // 10 zero-initialized bytes
b[0] = 42;              // modify first byte
Buffer c = b;           // deep copy
Buffer d = std::move(c); // move (c is now empty)
d.resize(20);           // grow, new bytes zeroed
```

## Testing

Compile and run `test_buffer.cpp` with C++20:

```bash
clang++ -std=c++20 -o test_buffer test_buffer.cpp && ./test_buffer
```
