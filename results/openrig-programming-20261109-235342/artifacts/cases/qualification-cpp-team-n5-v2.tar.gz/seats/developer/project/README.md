# CSV Aggregation Module

This module provides a CSV parser and aggregator that reads category/amount pairs and returns a sorted map of category totals.

## API

```cpp
std::map<std::string,std::int64_t> aggregate(std::istream& in)
```

Parses CSV input with header `category,amount` and returns aggregated totals.

### Behavior

- **Header validation**: First line must be exactly `category,amount`
- **Field count**: Each data row must have exactly 2 fields
- **Quoted fields**: Supports commas, newlines, and escaped quotes (`""`) within quotes
- **Whitespace**: Strips outer spaces/tabs/CR from fields
- **Number format**: Signed base10 int64 with optional leading +/-, no decimals
- **Overflow**: Throws `std::invalid_argument` on accumulation overflow
- **Empty records**: Ignored
- **Error handling**: Throws `std::invalid_argument` for malformed input

### Test Coverage

- Basic parsing with simple values
- Quoted fields with embedded commas and newlines
- Escaped quotes within quoted fields
- Unicode characters
- Negative amounts
- Overflow detection
