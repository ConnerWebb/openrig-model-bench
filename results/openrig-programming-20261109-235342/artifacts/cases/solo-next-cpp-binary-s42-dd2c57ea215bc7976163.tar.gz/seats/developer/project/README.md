# C++ Binary Serialization (solo-next-cpp-binary-s42)

This project implements a binary encoding/decoding system for a `Record` structure.

## Format Specification

The binary format is defined as:

- **Magic bytes**: `OGC1` (ASCII, 4 bytes)
- **Record count**: `uint32_t` in little-endian (4 bytes)
- **Per-record**:
  - `id`: `uint32_t` in little-endian (4 bytes)
  - `name_length`: `uint16_t` in little-endian (2 bytes)
  - `name`: raw bytes (variable length, max 1024)
  - `value`: `int64_t` in little-endian two's complement (8 bytes)

## Constraints

- Maximum record count: 10,000
- Maximum name length: 1,024 bytes
- IDs must be unique
- No trailing bytes allowed
- No truncation allowed

## Usage

```cpp
#include "solution.hpp"

// Encode
std::vector<Record> records = {{1, "test", -42}};
auto encoded = encode(records);

// Decode
auto decoded = decode(encoded);
```

## Building and Testing

```bash
# Compile
clang++ -std=c++20 -fuse-ld=bfd -o tests tests.cpp solution.cpp

# Run tests
./tests
```

## Error Handling

Throws `std::exception` (or derived) for:
- Invalid magic bytes
- Count exceeds 10,000
- Name length exceeds 1,024
- Duplicate IDs
- Truncated data
- Trailing bytes
- Overflow conditions
