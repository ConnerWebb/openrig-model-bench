#include "solution.hpp"
#include <cassert>
#include <iostream>
#include <vector>
#include <cstring>

void test_empty() {
    std::vector<Record> empty;
    auto encoded = encode(empty);
    assert(encoded.size() == 8); // magic(4) + count(4)
    
    auto decoded = decode(encoded);
    assert(decoded.size() == 0);
    std::cout << "test_empty passed\n";
}

void test_single_record() {
    std::vector<Record> records = {{123, "test", -42}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    
    assert(decoded.size() == 1);
    assert(decoded[0].id == 123);
    assert(decoded[0].name == "test");
    assert(decoded[0].value == -42);
    std::cout << "test_single_record passed\n";
}

void test_multiple_records() {
    std::vector<Record> records = {
        {1, "first", 100},
        {2, "second", -200},
        {3, "third", 0}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    
    assert(decoded.size() == 3);
    assert(decoded[0].id == 1 && decoded[0].name == "first" && decoded[0].value == 100);
    assert(decoded[1].id == 2 && decoded[1].name == "second" && decoded[1].value == -200);
    assert(decoded[2].id == 3 && decoded[2].name == "third" && decoded[2].value == 0);
    std::cout << "test_multiple_records passed\n";
}

void test_large_name() {
    std::string name(1024, 'x');
    std::vector<Record> records = {{1, name, 0}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    
    assert(decoded[0].name.size() == 1024);
    assert(decoded[0].name == name);
    std::cout << "test_large_name passed\n";
}

void test_negative_values() {
    std::vector<Record> records = {
        {1, "neg", -1},
        {2, "min64", INT64_MIN},
        {3, "max64", INT64_MAX}
    };
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    
    assert(decoded[0].value == -1);
    assert(decoded[1].value == INT64_MIN);
    assert(decoded[2].value == INT64_MAX);
    std::cout << "test_negative_values passed\n";
}

void test_duplicate_id() {
    std::vector<Record> records = {{1, "a", 1}, {1, "b", 2}};
    auto encoded = encode(records);
    
    bool threw = false;
    try {
        decode(encoded);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_duplicate_id passed\n";
}

void test_invalid_magic() {
    std::vector<uint8_t> data = {0xFF, 0xFF, 0xFF, 0xFF, 0, 0, 0, 0};
    bool threw = false;
    try {
        decode(data);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_invalid_magic passed\n";
}

void test_trailing_bytes() {
    std::vector<Record> records = {{1, "a", 1}};
    auto encoded = encode(records);
    encoded.push_back(0); // Add trailing byte
    
    bool threw = false;
    try {
        decode(encoded);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_trailing_bytes passed\n";
}

void test_truncated_data() {
    std::vector<Record> records = {{1, "a", 1}};
    auto encoded = encode(records);
    encoded.pop_back(); // Remove last byte
    
    bool threw = false;
    try {
        decode(encoded);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_truncated_data passed\n";
}

void test_count_overflow() {
    std::vector<uint8_t> data(8);
    std::memcpy(data.data(), "OGC1", 4);
    // Write count = 10001 (just over limit)
    data[4] = 0x31; // 10001 = 0x2711
    data[5] = 0x27;
    data[6] = 0;
    data[7] = 0;
    
    bool threw = false;
    try {
        decode(data);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_count_overflow passed\n";
}

void test_name_length_overflow() {
    std::vector<Record> records = {{1, "", 1}};
    auto encoded = encode(records);
    
    // Corrupt name length to be 1025 (at offset 12-13)
    encoded[12] = 0x01; // low byte of name_len
    encoded[13] = 0x04; // high byte = 0x0401 = 1025
    
    bool threw = false;
    try {
        decode(encoded);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_name_length_overflow passed\n";
}

void test_name_truncation() {
    std::vector<Record> records = {{1, "abc", 1}};
    auto encoded = encode(records);
    
    // Truncate by 1 byte (part of name)
    encoded.pop_back();
    
    bool threw = false;
    try {
        decode(encoded);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_name_truncation passed\n";
}

void test_value_truncation() {
    std::vector<Record> records = {{1, "a", 1}};
    auto encoded = encode(records);
    
    // Truncate by 1 byte (part of value)
    encoded.pop_back();
    
    bool threw = false;
    try {
        decode(encoded);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_value_truncation passed\n";
}

void test_header_truncation() {
    std::vector<uint8_t> data = {'O', 'G', 'C', '1', 0, 0, 0, 1}; // magic + count=1, but no record data
    bool threw = false;
    try {
        decode(data);
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);
    std::cout << "test_header_truncation passed\n";
}

void test_empty_name() {
    std::vector<Record> records = {{1, "", 123}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    
    assert(decoded[0].name.empty());
    assert(decoded[0].value == 123);
    std::cout << "test_empty_name passed\n";
}

void test_special_characters_in_name() {
    std::string name = "test\nwith\ttabs\0\0nulls";
    std::vector<Record> records = {{1, name, 1}};
    auto encoded = encode(records);
    auto decoded = decode(encoded);
    
    assert(decoded[0].name == name);
    std::cout << "test_special_characters_in_name passed\n";
}

int main() {
    test_empty();
    test_single_record();
    test_multiple_records();
    test_large_name();
    test_negative_values();
    test_duplicate_id();
    test_invalid_magic();
    test_trailing_bytes();
    test_truncated_data();
    test_count_overflow();
    test_name_length_overflow();
    test_name_truncation();
    test_value_truncation();
    test_header_truncation();
    test_empty_name();
    test_special_characters_in_name();
    
    std::cout << "\nAll tests passed!\n";
    return 0;
}
