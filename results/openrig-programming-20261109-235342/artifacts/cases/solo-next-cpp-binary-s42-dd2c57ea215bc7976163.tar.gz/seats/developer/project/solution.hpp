#ifndef SOLUTION_HPP
#define SOLUTION_HPP

#include <cstdint>
#include <string>
#include <vector>
#include <span>
#include <stdexcept>
#include <cstring>
#include <algorithm>

struct Record {
    uint32_t id;
    std::string name;
    int64_t value;
};

namespace {

// Helper to read little-endian uint32
uint32_t read_le32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}

// Helper to read little-endian uint16
uint16_t read_le16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0]) |
           (static_cast<uint16_t>(p[1]) << 8);
}

// Helper to read little-endian int64 (two's complement)
int64_t read_le64(const uint8_t* p) {
    uint64_t raw = static_cast<uint64_t>(p[0]) |
                   (static_cast<uint64_t>(p[1]) << 8) |
                   (static_cast<uint64_t>(p[2]) << 16) |
                   (static_cast<uint64_t>(p[3]) << 24) |
                   (static_cast<uint64_t>(p[4]) << 32) |
                   (static_cast<uint64_t>(p[5]) << 40) |
                   (static_cast<uint64_t>(p[6]) << 48) |
                   (static_cast<uint64_t>(p[7]) << 56);
    return static_cast<int64_t>(raw);
}

// Helper to write little-endian uint32
void write_le32(uint8_t* p, uint32_t v) {
    p[0] = static_cast<uint8_t>(v & 0xFF);
    p[1] = static_cast<uint8_t>((v >> 8) & 0xFF);
    p[2] = static_cast<uint8_t>((v >> 16) & 0xFF);
    p[3] = static_cast<uint8_t>((v >> 24) & 0xFF);
}

// Helper to write little-endian uint16
void write_le16(uint8_t* p, uint16_t v) {
    p[0] = static_cast<uint8_t>(v & 0xFF);
    p[1] = static_cast<uint8_t>((v >> 8) & 0xFF);
}

// Helper to write little-endian int64 (two's complement)
void write_le64(uint8_t* p, int64_t v) {
    uint64_t uv = static_cast<uint64_t>(v);
    p[0] = static_cast<uint8_t>(uv & 0xFF);
    p[1] = static_cast<uint8_t>((uv >> 8) & 0xFF);
    p[2] = static_cast<uint8_t>((uv >> 16) & 0xFF);
    p[3] = static_cast<uint8_t>((uv >> 24) & 0xFF);
    p[4] = static_cast<uint8_t>((uv >> 32) & 0xFF);
    p[5] = static_cast<uint8_t>((uv >> 40) & 0xFF);
    p[6] = static_cast<uint8_t>((uv >> 48) & 0xFF);
    p[7] = static_cast<uint8_t>((uv >> 56) & 0xFF);
}

// Magic bytes: "OGC1" in ASCII
const uint8_t MAGIC[4] = {'O', 'G', 'C', '1'};

} // anonymous namespace

inline std::vector<uint8_t> encode(const std::vector<Record>& records) {
    // Validate count
    if (records.size() > 10000) {
        throw std::runtime_error("Record count exceeds maximum of 10000");
    }

    // Calculate required size
    size_t size = 4 + 4; // magic + count
    for (const auto& rec : records) {
        if (rec.name.size() > 1024) {
            throw std::runtime_error("Name length exceeds maximum of 1024 bytes");
        }
        size += 4 + 2 + rec.name.size() + 8; // id + name_len + name + value
    }

    std::vector<uint8_t> result(size);
    uint8_t* p = result.data();

    // Write magic
    std::memcpy(p, MAGIC, 4);
    p += 4;

    // Write count (little-endian)
    write_le32(p, static_cast<uint32_t>(records.size()));
    p += 4;

    // Write each record
    for (const auto& rec : records) {
        // Write id (little-endian)
        write_le32(p, rec.id);
        p += 4;

        // Write name length (little-endian uint16)
        write_le16(p, static_cast<uint16_t>(rec.name.size()));
        p += 2;

        // Write name bytes
        std::memcpy(p, rec.name.data(), rec.name.size());
        p += rec.name.size();

        // Write value (little-endian int64 two's complement)
        write_le64(p, rec.value);
        p += 8;
    }

    return result;
}

inline std::vector<Record> decode(std::span<const uint8_t> data) {
    // Check minimum size for magic + count
    if (data.size() < 8) {
        throw std::runtime_error("Data too short for header");
    }

    // Check magic
    if (std::memcmp(data.data(), MAGIC, 4) != 0) {
        throw std::runtime_error("Invalid magic bytes");
    }

    // Read count
    uint32_t count = read_le32(data.data() + 4);
    
    // Validate count
    if (count > 10000) {
        throw std::runtime_error("Record count exceeds maximum of 10000");
    }

    std::vector<Record> records;
    records.reserve(count);

    // Track seen IDs for uniqueness check
    std::vector<uint32_t> seen_ids;
    seen_ids.reserve(count);

    const uint8_t* p = data.data() + 8;
    const uint8_t* end = data.data() + data.size();

    for (uint32_t i = 0; i < count; ++i) {
        // Check we have enough bytes for header (id + name_len)
        if (p + 6 > end) {
            throw std::runtime_error("Truncated record header");
        }

        // Read id
        uint32_t id = read_le32(p);
        p += 4;

        // Check for duplicate ID
        if (std::find(seen_ids.begin(), seen_ids.end(), id) != seen_ids.end()) {
            throw std::runtime_error("Duplicate record ID");
        }
        seen_ids.push_back(id);

        // Read name length
        uint16_t name_len = read_le16(p);
        p += 2;

        // Validate name length
        if (name_len > 1024) {
            throw std::runtime_error("Name length exceeds maximum of 1024 bytes");
        }

        // Check we have enough bytes for name
        if (p + name_len > end) {
            throw std::runtime_error("Truncated record name");
        }

        // Read name
        std::string name(reinterpret_cast<const char*>(p), name_len);
        p += name_len;

        // Check we have enough bytes for value
        if (p + 8 > end) {
            throw std::runtime_error("Truncated record value");
        }

        // Read value
        int64_t value = read_le64(p);
        p += 8;

        records.push_back({id, name, value});
    }

    // Check for trailing bytes
    if (p != end) {
        throw std::runtime_error("Trailing bytes in data");
    }

    return records;
}

#endif // SOLUTION_HPP
