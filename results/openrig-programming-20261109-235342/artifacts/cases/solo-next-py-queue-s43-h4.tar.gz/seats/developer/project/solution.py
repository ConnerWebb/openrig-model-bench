import sqlite3
import json
import os
import threading
from typing import Optional, Dict, Any


class JobQueue:
    def __init__(self, path: str, max_attempts: int = 3):
        if max_attempts <= 0:
            raise ValueError("max_attempts must be a positive integer")
        self.path = path
        self.max_attempts = max_attempts
        self._lock = threading.Lock()
        self._init_db()

    def _init_db(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        conn = sqlite3.connect(self.path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'queued',
                attempts INTEGER NOT NULL DEFAULT 0,
                owner TEXT,
                lease_until REAL
            )
        """)
        conn.commit()
        conn.close()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def enqueue(self, key: str, payload: Any) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        payload_json = json.dumps(payload)
        conn = self._get_conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT OR IGNORE INTO jobs (key, payload, state, attempts) VALUES (?, ?, 'queued', 0)",
                (key, payload_json)
            )
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    def claim(self, worker: str, now: float, lease: float) -> Optional[Dict[str, Any]]:
        if not worker:
            raise ValueError("worker must be nonempty")
        if lease <= 0:
            raise ValueError("lease must be positive")
        
        with self._lock:
            conn = self._get_conn()
            cursor = conn.cursor()
            try:
                # Mark jobs with expired leases and attempts >= max_attempts as failed
                cursor.execute(
                    """UPDATE jobs SET state = 'failed', owner = NULL, lease_until = NULL
                       WHERE lease_until IS NOT NULL AND lease_until <= ? AND attempts >= ? AND state != 'done'""",
                    (now, self.max_attempts)
                )
                
                # Expire any remaining leases that have passed
                cursor.execute(
                    "UPDATE jobs SET owner = NULL, lease_until = NULL WHERE lease_until IS NOT NULL AND lease_until <= ?",
                    (now,)
                )
                
                # Find the oldest queued job
                cursor.execute(
                    "SELECT key, payload, attempts, rowid FROM jobs WHERE state = 'queued' AND attempts < ? ORDER BY key ASC LIMIT 1",
                    (self.max_attempts,)
                )
                row = cursor.fetchone()
                
                if row is None:
                    return None
                
                key = row["key"]
                payload = json.loads(row["payload"])
                attempts = row["attempts"]
                rowid = row["rowid"]
                
                new_attempts = attempts + 1
                
                # Determine new state
                if new_attempts >= self.max_attempts:
                    state = 'failed'
                    owner = None
                    lease_until = None
                else:
                    state = 'leased'
                    owner = worker
                    lease_until = now + lease
                
                # Atomically update the job
                cursor.execute(
                    """UPDATE jobs SET state = ?, attempts = ?, owner = ?, lease_until = ?
                       WHERE rowid = ?""",
                    (state, new_attempts, owner, lease_until, rowid)
                )
                
                if cursor.rowcount == 0:
                    return None
                
                conn.commit()
                
                return {"key": key, "payload": payload, "attempts": new_attempts}
            finally:
                conn.close()

    def complete(self, key: str, worker: str) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        if not worker:
            raise ValueError("worker must be nonempty")
        conn = self._get_conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """UPDATE jobs SET state = 'done', owner = NULL, lease_until = NULL
                   WHERE key = ? AND owner = ? AND state = 'leased'""",
                (key, worker)
            )
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    def fail(self, key: str, worker: str) -> bool:
        if not key:
            raise ValueError("key must be nonempty")
        if not worker:
            raise ValueError("worker must be nonempty")
        conn = self._get_conn()
        cursor = conn.cursor()
        try:
            # First, get the current state
            cursor.execute(
                "SELECT state, attempts, owner FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            
            if row is None:
                return False
            
            current_state = row["state"]
            attempts = row["attempts"]
            owner = row["owner"]
            
            # Can only fail a leased job that we own
            if current_state != 'leased' or owner != worker:
                return False
            
            # If this is the final attempt, mark as failed
            if attempts >= self.max_attempts:
                cursor.execute(
                    "UPDATE jobs SET state = 'failed', owner = NULL, lease_until = NULL WHERE key = ?",
                    (key,)
                )
            else:
                # Otherwise, put back in queued state
                cursor.execute(
                    "UPDATE jobs SET state = 'queued', owner = NULL, lease_until = NULL WHERE key = ?",
                    (key,)
                )
            
            conn.commit()
            return True
        finally:
            conn.close()

    def status(self, key: str) -> Optional[Dict[str, Any]]:
        if not key:
            raise ValueError("key must be nonempty")
        conn = self._get_conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "SELECT state, attempts, owner, lease_until FROM jobs WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            
            if row is None:
                return None
            
            return {
                "state": row["state"],
                "attempts": row["attempts"],
                "owner": row["owner"],
                "lease_until": row["lease_until"]
            }
        finally:
            conn.close()
