import os
import tempfile
import json
import pytest
from solution import JobQueue


def test_enqueue_basic():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        assert q.enqueue("a", {"v": 5304}) is True
        assert q.enqueue("a", "ignored") is False
    finally:
        os.unlink(path)


def test_claim_basic():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        q.enqueue("a", {"v": 5304})
        result = q.claim("w", 0, 5)
        assert result == {"key": "a", "payload": {"v": 5304}, "attempts": 1}
    finally:
        os.unlink(path)


def test_claim_wrong_owner_complete():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        q.enqueue("a", {"v": 5304})
        q.claim("w", 0, 5)
        assert q.complete("a", "wrong") is False
    finally:
        os.unlink(path)


def test_fail_and_requeue():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        q.enqueue("a", {"v": 5304})
        q.claim("w", 0, 5)
        assert q.fail("a", "w") is True
        result = q.claim("w2", 1, 5)
        assert result == {"key": "a", "payload": {"v": 5304}, "attempts": 2}
    finally:
        os.unlink(path)


def test_complete():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        q.enqueue("a", {"v": 5304})
        q.claim("w", 0, 5)
        q.fail("a", "w")
        q.claim("w2", 1, 5)
        assert q.complete("a", "w2") is True
        assert q.status("a") == {"state": "done", "attempts": 2}
    finally:
        os.unlink(path)


def test_claim_no_jobs():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        assert q.claim("w3", 100, 5) is None
    finally:
        os.unlink(path)


def test_invalid_args():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        with pytest.raises(ValueError):
            JobQueue(path, max_attempts=0)
        with pytest.raises(ValueError):
            JobQueue(path, max_attempts=-1)
        q = JobQueue(path)
        with pytest.raises(ValueError):
            q.enqueue("", {"v": 1})
        with pytest.raises(ValueError):
            q.claim("", 0, 5)
        with pytest.raises(ValueError):
            q.claim("w", 0, 0)
        with pytest.raises(ValueError):
            q.claim("w", 0, -1)
        with pytest.raises(ValueError):
            q.complete("", "w")
        with pytest.raises(ValueError):
            q.fail("", "w")
        with pytest.raises(ValueError):
            q.status("")
    finally:
        os.unlink(path)


def test_lease_expiry():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        q.enqueue("a", {"v": 8330})
        q.claim("w", 0, 5)
        # Lease expires at t=5, so at t=6 it should be available again
        result = q.claim("w2", 6, 5)
        assert result == {"key": "a", "payload": {"v": 8330}, "attempts": 2}
    finally:
        os.unlink(path)


def test_max_attempts_fail():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path, max_attempts=3)
        q.enqueue("a", {"v": 9999})
        for _ in range(3):
            q.claim("w", 0, 100)
            q.fail("a", "w")
        assert q.status("a") == {"state": "failed", "attempts": 3}
    finally:
        os.unlink(path)


def test_status_not_found():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as f:
        path = f.name
    try:
        q = JobQueue(path)
        assert q.status("nonexistent") is None
    finally:
        os.unlink(path)
