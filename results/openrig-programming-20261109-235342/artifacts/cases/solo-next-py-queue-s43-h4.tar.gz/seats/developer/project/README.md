# JobQueue

A SQLite-backed job queue implementation in Python.

## Usage

```python
from solution import JobQueue

# Create a queue
q = JobQueue("jobs.db", max_attempts=3)

# Enqueue a job (first unique key wins)
q.enqueue("task1", {"data": "payload"})

# Claim a job for a worker
job = q.claim("worker1", now=0, lease=60)
if job:
    print(f"Processing {job['key']} (attempt {job['attempts']})")

# Complete a job
q.complete("task1", "worker1")

# Fail a job (requeues if attempts < max_attempts)
q.fail("task1", "worker1")

# Check job status
status = q.status("task1")
print(status)  # {'state': 'queued' | 'done' | 'failed', 'attempts': int}
```

## API

### `JobQueue(path, max_attempts=3)`

Create a new job queue. `path` is the SQLite database file path. `max_attempts` is the maximum number of claim attempts before a job is marked as failed.

### `enqueue(key, payload) -> bool`

Add a job to the queue. Returns `True` if the job was added, `False` if a job with that key already exists.

### `claim(worker, now, lease) -> dict | None`

Claim the oldest queued job for a worker. Returns a dict with `key`, `payload`, and `attempts`, or `None` if no jobs are available.

- `worker`: unique worker identifier
- `now`: current timestamp (for lease expiry calculations)
- `lease`: lease duration in seconds

### `complete(key, worker) -> bool`

Mark a job as completed. Returns `True` if successful, `False` if the job doesn't exist or was claimed by a different worker.

### `fail(key, worker) -> bool`

Mark a job as failed. If `attempts < max_attempts`, the job is requeued; otherwise, it's marked as failed. Returns `True` if successful.

### `status(key) -> dict | None`

Get the status of a job. Returns `{'state': str, 'attempts': int}` or `None` if not found.

## State transitions

- `enqueue` → `queued`
- `claim` → `queued` (with owner/lease_until set)
- `complete` → `done`
- `fail` → `queued` (if attempts < max_attempts) or `failed` (if attempts >= max_attempts)
