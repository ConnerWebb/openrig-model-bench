#pragma once
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <utility>
#include <vector>

class Buffer {
public:
    Buffer() = default;
    explicit Buffer(std::size_t n) : data_(n, 0) {}

    Buffer(const Buffer& other) : data_(other.data_) {}
    Buffer(Buffer&& other) noexcept : data_(std::move(other.data_)) {}

    Buffer& operator=(const Buffer& other) {
        if (this != &other) data_ = other.data_;
        return *this;
    }
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) data_ = std::move(other.data_);
        return *this;
    }

    std::size_t size() const noexcept { return data_.size(); }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= data_.size()) throw std::out_of_range("Buffer::operator[]: index out of range");
        return data_[i];
    }
    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= data_.size()) throw std::out_of_range("Buffer::operator[]: index out of range");
        return data_[i];
    }

    void resize(std::size_t n) { data_.resize(n, 0); }

private:
    std::vector<std::uint8_t> data_;
};
