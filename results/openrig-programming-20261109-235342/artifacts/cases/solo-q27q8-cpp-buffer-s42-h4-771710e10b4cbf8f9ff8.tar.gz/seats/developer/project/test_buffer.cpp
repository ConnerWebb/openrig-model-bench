#include "solution.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>

static void expect_out_of_range(const char* what) {
    try {
        Buffer b(4);
        (void)b;
        if (std::string(what) == "mutable") {
            b[4];
        } else {
            const Buffer& c = b;
            c[4];
        }
        std::cerr << "FAIL: " << what << " did not throw\n";
        std::exit(1);
    } catch (const std::out_of_range&) {
    } catch (...) {
        std::cerr << "FAIL: " << what << " threw wrong exception\n";
        std::exit(1);
    }
}

int main() {
    // Default construction
    {
        Buffer b;
        assert(b.size() == 0);
    }

    // Sizing and zero-initialization
    {
        Buffer b(5);
        assert(b.size() == 5);
        for (std::size_t i = 0; i < 5; ++i) assert(b[i] == 0);
    }

    // Mutable access and write
    {
        Buffer b(3);
        b[0] = 1;
        b[1] = 2;
        b[2] = 3;
        assert(b[0] == 1 && b[1] == 2 && b[2] == 3);
    }

    // Const access
    {
        Buffer b(2);
        b[0] = 7;
        b[1] = 9;
        const Buffer& c = b;
        assert(c[0] == 7 && c[1] == 9);
    }

    // Bounds checking
    expect_out_of_range("mutable");
    expect_out_of_range("const");
    {
        Buffer b;
        try {
            b[0];
            std::cerr << "FAIL: empty buffer did not throw\n";
            return 1;
        } catch (const std::out_of_range&) {
        }
    }

    // Resize up: preserve prefix, zero-init new
    {
        Buffer b(3);
        b[0] = 10;
        b[1] = 20;
        b[2] = 30;
        b.resize(6);
        assert(b.size() == 6);
        assert(b[0] == 10 && b[1] == 20 && b[2] == 30);
        assert(b[3] == 0 && b[4] == 0 && b[5] == 0);
    }

    // Resize down: truncate
    {
        Buffer b(5);
        for (std::size_t i = 0; i < 5; ++i) b[i] = static_cast<std::uint8_t>(i + 1);
        b.resize(2);
        assert(b.size() == 2);
        assert(b[0] == 1 && b[1] == 2);
    }

    // Resize to zero
    {
        Buffer b(4);
        b[0] = 5;
        b.resize(0);
        assert(b.size() == 0);
    }

    // Deep copy construction
    {
        Buffer a(4);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        a[3] = 4;
        Buffer b(a);
        assert(b.size() == 4);
        assert(b[0] == 1 && b[1] == 2 && b[2] == 3 && b[3] == 4);
        b[0] = 99;
        assert(a[0] == 1);  // independent storage
    }

    // Deep copy assignment
    {
        Buffer a(3);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        Buffer b(2);
        b = a;
        assert(b.size() == 3);
        assert(b[0] == 1 && b[1] == 2 && b[2] == 3);
        b[2] = 42;
        assert(a[2] == 3);
    }

    // Self-copy assignment preserves content
    {
        Buffer a(3);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        a = a;
        assert(a.size() == 3);
        assert(a[0] == 1 && a[1] == 2 && a[2] == 3);
    }

    // Move construction
    {
        Buffer a(4);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        a[3] = 4;
        Buffer b(std::move(a));
        assert(b.size() == 4);
        assert(b[0] == 1 && b[1] == 2 && b[2] == 3 && b[3] == 4);
        assert(a.size() == 0);  // moved-from is size 0
    }

    // Moved-from buffer is reusable
    {
        Buffer a(3);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        Buffer b(std::move(a));
        a.resize(2);
        assert(a.size() == 2);
        a[0] = 100;
        a[1] = 200;
        assert(a[0] == 100 && a[1] == 200);
        assert(b[0] == 1);  // original data intact in b
    }

    // Move assignment
    {
        Buffer a(3);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        Buffer b(2);
        b = std::move(a);
        assert(b.size() == 3);
        assert(b[0] == 1 && b[1] == 2 && b[2] == 3);
        assert(a.size() == 0);
    }

    // Self-move assignment preserves content
    {
        Buffer a(3);
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        a = std::move(a);
        assert(a.size() == 3);
        assert(a[0] == 1 && a[1] == 2 && a[2] == 3);
    }

    // uint8_t element type
    {
        Buffer b(1);
        b[0] = 255;
        assert(b[0] == 255);
        static_assert(sizeof(b[0]) == 1, "element must be one byte");
    }

    std::cout << "all tests passed\n";
    return 0;
}
