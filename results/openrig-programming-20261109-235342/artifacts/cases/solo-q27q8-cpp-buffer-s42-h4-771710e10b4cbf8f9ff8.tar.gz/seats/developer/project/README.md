# Buffer

A small C++20 byte buffer class (`Buffer` in `solution.hpp`) with RAII semantics.

## API

- `Buffer()` — default-construct an empty buffer.
- `Buffer(std::size_t n)` — construct a buffer of `n` zero-initialized `std::uint8_t` bytes.
- `size() const noexcept` — number of bytes.
- `operator[](std::size_t i)` (mutable and const) — element access; throws `std::out_of_range` if `i >= size()`.
- `resize(std::size_t n)` — resize, preserving the existing prefix and zero-initializing any new bytes.
- Copy construction/assignment — deep copy, independent storage.
- Move construction/assignment — `noexcept`; the moved-from buffer has size 0 and remains reusable.
- Self-copy and self-move assignment preserve content.

## Build and test

```sh
clang++ -std=c++20 -O2 -Wall -Wextra -o /tmp/test_buffer test_buffer.cpp
/tmp/test_buffer
```

The fixed public runner (Python 3.14 stdlib, Clang 22, `-fuse-ld=bfd`) is invoked via `run_tests`.
