# LRU Cache Module

Header-only C++20 LRU cache with O(1) operations.

## Features

- O(1) average time complexity for `get`, `put`, and `erase`
- Most recently used items at front of snapshot
- Capacity-based eviction of least recently used items
- Proper RAII semantics

## Usage

```cpp
#include "cache.hpp"

LruCache<int, std::string> cache(3);
cache.put(1, "one");
cache.put(2, "two");
cache.put(3, "three");

std::string value;
cache.get(1, value); // value == "one", key 1 is now MRU

auto snapshot = cache.snapshot(); // [(1,"one"), (3,"three"), (2,"two")]
```

## API

```cpp
template<typename K, typename V>
class LruCache {
public:
    explicit LruCache(size_t capacity);
    
    void put(K key, V value);
    bool get(K key, V& out);
    bool erase(K key);
    size_t size() const;
    std::vector<std::pair<K, V>> snapshot() const;
};
```

## Notes

- Capacity 0 stores nothing
- `get` and `put` make keys most recently used
- `snapshot` returns items from MRU to LRU order
- Updating existing key doesn't evict others
