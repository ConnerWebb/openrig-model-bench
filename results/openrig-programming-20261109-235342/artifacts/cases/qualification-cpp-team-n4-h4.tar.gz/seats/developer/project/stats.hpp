#ifndef STATS_HPP
#define STATS_HPP

#include <cstdint>
#include <stdexcept>
#include <limits>
#include <cmath>

class RunningStats {
public:
    RunningStats() : count_(0), mean_(0.0), m2_(0.0), min_(std::numeric_limits<double>::max()), max_(std::numeric_limits<double>::lowest()) {}
    
    void add(double value) {
        // Reject NaN and infinity
        if (std::isnan(value) || std::isinf(value)) {
            throw std::invalid_argument("NaN or infinity not allowed");
        }
        
        count_++;
        
        double delta = value - mean_;
        mean_ += delta / static_cast<double>(count_);
        double delta2 = value - mean_;
        m2_ += delta * delta2;
        
        if (value < min_) {
            min_ = value;
        }
        if (value > max_) {
            max_ = value;
        }
    }
    
    void merge(const RunningStats& other) {
        if (other.count_ == 0) {
            return; // No-op for empty other
        }
        
        if (count_ == 0) {
            // Copy from other
            count_ = other.count_;
            mean_ = other.mean_;
            m2_ = other.m2_;
            min_ = other.min_;
            max_ = other.max_;
            return;
        }
        
        // Merge using Welford's online algorithm
        double new_count = count_ + other.count_;
        double delta = other.mean_ - mean_;
        
        mean_ = mean_ + delta * (static_cast<double>(other.count_) / new_count);
        
        // Update m2 using the merge formula
        m2_ = m2_ + other.m2_ + delta * delta * (static_cast<double>(count_) * static_cast<double>(other.count_) / new_count);
        
        if (other.min_ < min_) {
            min_ = other.min_;
        }
        if (other.max_ > max_) {
            max_ = other.max_;
        }
        
        count_ = new_count;
    }
    
    uint64_t count() const {
        return count_;
    }
    
    double mean() const {
        if (count_ == 0) {
            throw std::domain_error("No data available");
        }
        return mean_;
    }
    
    double variance() const {
        if (count_ == 0) {
            throw std::domain_error("No data available");
        }
        return m2_ / static_cast<double>(count_);
    }
    
    double minimum() const {
        if (count_ == 0) {
            throw std::domain_error("No data available");
        }
        return min_;
    }
    
    double maximum() const {
        if (count_ == 0) {
            throw std::domain_error("No data available");
        }
        return max_;
    }

private:
    uint64_t count_;
    double mean_;
    double m2_;
    double min_;
    double max_;
};

#endif // STATS_HPP
