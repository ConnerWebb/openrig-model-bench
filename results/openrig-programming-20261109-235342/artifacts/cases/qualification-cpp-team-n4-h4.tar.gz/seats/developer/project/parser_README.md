# CSV Parser Module

Header-only C++20 CSV parsing library with aggregation support.

## Features

- Parses CSV with header `category,amount`
- Handles quoted fields with embedded commas, newlines, and escaped quotes
- Validates field count, header, and data formats
- Returns `std::map<std::string, std::int64_t>` with sorted keys
- Throws `std::invalid_argument` for malformed input

## Usage

```cpp
#include "parser.hpp"
#include <sstream>

std::string csv = "category,amount\nfood,100\nrent,500";
std::istringstream input(csv);
auto result = csv::aggregate(input);
// result["food"] == 100, result["rent"] == 500
```

## API

```cpp
namespace csv {
    std::map<std::string, std::int64_t> aggregate(std::istream& input);
}
```

## Error Handling

- Wrong field count in header or data rows
- Invalid header (must be `category,amount`)
- Empty category or amount fields
- Invalid amount format (no decimals, exponents, or whitespace)
- Integer overflow in parsing or accumulation
