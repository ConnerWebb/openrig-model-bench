# Running Stats Module

Header-only C++20 running statistics with stable online formulas.

## Features

- Welford's online algorithm for stable mean/variance computation
- Merge operation for combining statistics from multiple datasets
- Tracks count, mean, variance (population), min, and max
- Rejects NaN and infinity values

## Usage

```cpp
#include "stats.hpp"

RunningStats stats;
stats.add(1.0);
stats.add(2.0);
stats.add(3.0);

uint64_t count = stats.count();     // 3
double mean = stats.mean();         // 2.0
double var = stats.variance();      // 0.666...
double min = stats.minimum();       // 1.0
double max = stats.maximum();       // 3.0
```

## API

```cpp
class RunningStats {
public:
    RunningStats();
    
    void add(double value);
    void merge(const RunningStats& other);
    
    uint64_t count() const;
    double mean() const;
    double variance() const;  // Population variance
    double minimum() const;
    double maximum() const;
};
```

## Error Handling

- `mean()`, `variance()`, `minimum()`, `maximum()` throw `std::domain_error` when count is 0
- `add()` throws `std::invalid_argument` for NaN or infinity

## Numerical Stability

Uses Welford's online algorithm with merge support for numerical stability with large values.
