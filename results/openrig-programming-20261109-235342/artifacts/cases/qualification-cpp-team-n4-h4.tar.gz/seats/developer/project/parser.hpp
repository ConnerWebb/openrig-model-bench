#ifndef PARSER_HPP
#define PARSER_HPP

#include <map>
#include <string>
#include <sstream>
#include <stdexcept>
#include <cctype>
#include <algorithm>
#include <cstdint>
#include <vector>
#include <limits>

// Strip whitespace, CR, and tabs from both ends of a string
inline std::string strip(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (std::isspace(static_cast<unsigned char>(s[start])) || s[start] == '\r')) {
        start++;
    }
    if (start == s.size()) return "";
    size_t end = s.size() - 1;
    while (end > start && (std::isspace(static_cast<unsigned char>(s[end])) || s[end] == '\r')) {
        end--;
    }
    return s.substr(start, end - start + 1);
}

// Parse a CSV field that may be quoted
// Returns the parsed field and advances pos past the field
inline std::string parse_field(const std::string& s, size_t& pos) {
    if (pos >= s.size()) {
        return "";
    }
    
    if (s[pos] == '"') {
        // Quoted field
        pos++; // skip opening quote
        std::string result;
        while (pos < s.size()) {
            if (s[pos] == '"') {
                if (pos + 1 < s.size() && s[pos + 1] == '"') {
                    // Escaped quote
                    result += '"';
                    pos += 2;
                } else {
                    // End of quoted field
                    pos++; // skip closing quote
                    return result;
                }
            } else {
                result += s[pos];
                pos++;
            }
        }
        // Reached end of input inside quotes - malformed
        throw std::invalid_argument("Unterminated quoted field");
    } else {
        // Unquoted field - read until comma or newline
        std::string result;
        while (pos < s.size() && s[pos] != ',' && s[pos] != '\n' && s[pos] != '\r') {
            result += s[pos];
            pos++;
        }
        return result;
    }
}

// Parse a complete CSV record (line)
// Returns vector of fields
inline std::vector<std::string> parse_record(const std::string& s, size_t& pos) {
    std::vector<std::string> fields;
    while (pos < s.size()) {
        std::string field = parse_field(s, pos);
        fields.push_back(field);
        
        if (pos >= s.size()) {
            break;
        }
        
        if (s[pos] == ',') {
            pos++; // skip comma
        } else if (s[pos] == '\n') {
            pos++; // skip newline
            break;
        } else if (s[pos] == '\r') {
            pos++; // skip CR
            if (pos < s.size() && s[pos] == '\n') {
                pos++; // skip LF after CR
            }
            break;
        }
    }
    return fields;
}

// Main aggregate function - parses CSV and returns map of category -> sum
inline std::map<std::string, std::int64_t> aggregate(std::istream& input) {
    std::string line;
    std::string full_input;
    
    // Read entire input
    while (std::getline(input, line)) {
        full_input += line + "\n";
    }
    
    size_t pos = 0;
    
    // Skip empty lines at start
    while (pos < full_input.size() && (full_input[pos] == '\n' || full_input[pos] == '\r')) {
        pos++;
    }
    
    if (pos >= full_input.size()) {
        throw std::invalid_argument("Empty input");
    }
    
    // Parse header
    std::vector<std::string> header = parse_record(full_input, pos);
    if (header.size() != 2) {
        throw std::invalid_argument("Wrong field count in header");
    }
    if (strip(header[0]) != "category" || strip(header[1]) != "amount") {
        throw std::invalid_argument("Invalid header");
    }
    
    std::map<std::string, std::int64_t> result;
    
    // Parse data rows
    while (pos < full_input.size()) {
        // Skip empty lines
        while (pos < full_input.size() && (full_input[pos] == '\n' || full_input[pos] == '\r')) {
            pos++;
        }
        if (pos >= full_input.size()) {
            break;
        }
        
        std::vector<std::string> fields = parse_record(full_input, pos);
        
        if (fields.size() != 2) {
            throw std::invalid_argument("Wrong field count in data row");
        }
        
        std::string category = strip(fields[0]);
        std::string amount_str = strip(fields[1]);
        
        if (category.empty()) {
            throw std::invalid_argument("Empty category field");
        }
        if (amount_str.empty()) {
            throw std::invalid_argument("Empty amount field");
        }
        
        // Parse amount - must be signed base10 int64, no decimals/exponents
        std::int64_t amount;
        size_t parsed_len = 0;
        bool has_sign = false;
        size_t start_pos = 0;
        
        if (amount_str[0] == '+' || amount_str[0] == '-') {
            has_sign = true;
            start_pos = 1;
        } else {
            start_pos = 0;
        }
        
        // Check for invalid characters
        for (size_t i = start_pos; i < amount_str.size(); i++) {
            if (!std::isdigit(static_cast<unsigned char>(amount_str[i]))) {
                throw std::invalid_argument("Invalid amount format");
            }
        }
        
        // Check for overflow before parsing
        const std::string min_int64_str = "-9223372036854775808";
        const std::string max_int64_str = "9223372036854775807";
        
        std::string abs_str = amount_str;
        if (has_sign) {
            abs_str = amount_str.substr(1);
        }
        
        // Check length
        if (abs_str.size() > max_int64_str.size()) {
            throw std::invalid_argument("Integer overflow");
        }
        if (abs_str.size() == max_int64_str.size()) {
            if (amount_str[0] == '-') {
                if (abs_str > max_int64_str.substr(1)) {
                    throw std::invalid_argument("Integer overflow");
                }
            } else {
                if (abs_str > max_int64_str) {
                    throw std::invalid_argument("Integer overflow");
                }
            }
        }
        
        try {
            amount = std::stoll(amount_str, &parsed_len);
            if (parsed_len != amount_str.size()) {
                throw std::invalid_argument("Invalid amount format");
            }
        } catch (const std::exception&) {
            throw std::invalid_argument("Invalid amount format");
        }
        
        // Check for overflow when accumulating
        if ((amount > 0 && result[category] > 0 && result[category] > std::numeric_limits<std::int64_t>::max() - amount) ||
            (amount < 0 && result[category] < 0 && result[category] < std::numeric_limits<std::int64_t>::min() - amount)) {
            throw std::invalid_argument("Integer overflow in accumulation");
        }
        
        result[category] += amount;
    }
    
    return result;
}

#endif // PARSER_HPP
