#ifndef CACHE_HPP
#define CACHE_HPP

#include <list>
#include <unordered_map>
#include <vector>
#include <utility>
#include <stdexcept>

template<typename K = int, typename V = std::string>
class LruCache {
public:
    explicit LruCache(size_t capacity) : capacity_(capacity) {
        if (capacity_ == 0) {
            capacity_ = 1; // Store nothing, but allow operations
        }
    }
    
    void put(K key, V value) {
        if (capacity_ == 0) {
            return;
        }
        
        auto it = map_.find(key);
        if (it != map_.end()) {
            // Update existing key
            it->second.value = std::move(value);
            // Move to front (MRU)
            list_.splice(list_.begin(), list_, it->second.iter);
            return;
        }
        
        // Check if we need to evict
        if (list_.size() >= capacity_) {
            // Evict LRU (back of list)
            K evict_key = list_.back();
            list_.pop_back();
            map_.erase(evict_key);
        }
        
        // Insert new key at front (MRU)
        list_.push_front(key);
        map_[key] = {list_.begin(), std::move(value)};
    }
    
    bool get(K key, V& out) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }
        
        out = it->second.value;
        // Move to front (MRU)
        list_.splice(list_.begin(), list_, it->second.iter);
        return true;
    }
    
    bool erase(K key) {
        auto it = map_.find(key);
        if (it == map_.end()) {
            return false;
        }
        
        list_.erase(it->second.iter);
        map_.erase(it);
        return true;
    }
    
    size_t size() const {
        return list_.size();
    }
    
    std::vector<std::pair<K, V>> snapshot() const {
        std::vector<std::pair<K, V>> result;
        result.reserve(list_.size());
        
        for (const auto& key : list_) {
            auto it = map_.find(key);
            if (it != map_.end()) {
                result.emplace_back(key, it->second.value);
            }
        }
        
        return result;
    }

private:
    size_t capacity_;
    std::list<K> list_; // Front is MRU, back is LRU
    struct Node {
        typename std::list<K>::iterator iter;
        V value;
    };
    std::unordered_map<K, Node> map_;
};

#endif // CACHE_HPP
