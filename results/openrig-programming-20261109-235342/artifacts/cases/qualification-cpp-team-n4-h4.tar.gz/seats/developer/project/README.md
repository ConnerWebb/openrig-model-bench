# Local Analytics Toolkit

Header-only C++20 analytics toolkit with CSV parsing, LRU caching, and running statistics.

## Modules

- **parser.hpp**: CSV parsing with aggregation
- **cache.hpp**: LRU cache with O(1) operations
- **stats.hpp**: Running statistics with stable online formulas
- **solution.hpp**: Umbrella header including all modules

## Usage

```cpp
#include "solution.hpp"
#include <sstream>

// Parse CSV and aggregate
std::string csv = "category,amount\nfood,100\nrent,500";
std::istringstream input(csv);
auto totals = csv::aggregate(input);

// Use LRU cache
LruCache<int, std::string> cache(10);
for (const auto& [cat, amount] : totals) {
    cache.put(cat.size(), std::to_string(amount));
}

// Accumulate running stats
RunningStats stats;
for (const auto& [cat, amount] : totals) {
    stats.add(static_cast<double>(amount));
}
```

## Requirements

- C++20 compatible compiler
- Standard library support

## License

Public domain / CC0
