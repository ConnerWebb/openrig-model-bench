# Solution: CSV Aggregator

## Overview

This module implements a CSV aggregator that reads UTF-8 CSV files and accumulates amounts by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly category,amount.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with totals formatted to 2 decimal places.
    Raise ValueError on any malformed input.
    """
```

## Requirements

- Header must be exactly `category,amount`
- Blank records (all fields empty/whitespace) are ignored
- Every non-blank record must have exactly 2 fields
- Category and amount whitespace is stripped
- Category must not be empty
- Amount format: optional `+`, 1-12 digits, optional decimal point with 1-2 digits
- Amount must be nonnegative and finite (no exponent notation)
- CSV supports quoted fields with embedded commas, newlines, and escaped quotes (`""`)
- Returns dict sorted by category key, with values formatted to exactly 2 decimal places
- Raises `ValueError` on any malformed input

## Running Tests

```bash
python3 -m unittest test_solution.py
```

Or use the project's test runner:

```bash
run_tests
```

## Example

Input CSV:
```
category,amount
food,10.50
rent,20.25
food,5.50
```

Output:
```python
{'food': '16.00', 'rent': '20.25'}
```
