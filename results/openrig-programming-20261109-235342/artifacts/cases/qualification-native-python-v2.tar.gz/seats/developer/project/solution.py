"""CSV aggregation module with exact decimal arithmetic."""

import csv
import re
from decimal import Decimal, InvalidOperation


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream and aggregate amounts by category.
    
    Header must be exactly 'category,amount'. Ignore blank records.
    Each non-blank record must have exactly two fields.
    Category must not be empty after stripping whitespace.
    Amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits.
    Returns dict with sorted category keys and totals formatted to 2 decimal places.
    """
    # Amount validation regex: optional +, 1-12 digits, optional decimal with 1-2 digits
    amount_pattern = re.compile(r'^\+?(?:\d{1,12}(?:\.\d{1,2})?|\d{1,12})$')
    
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as csvfile:
        reader = csv.reader(csvfile)
        
        # Read and validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty CSV file")
        
        if header != ['category', 'amount']:
            raise ValueError(f"Invalid header: {header}")
        
        for row in reader:
            # Skip completely blank records (empty row or row with empty strings only)
            if not row or all(field.strip() == '' for field in row):
                continue
            
            # Each non-blank record must have exactly two fields
            if len(row) != 2:
                raise ValueError(f"Invalid field count: {len(row)} fields")
            
            category, amount_str = row
            
            # Strip whitespace
            category = category.strip()
            amount_str = amount_str.strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Empty category")
            
            # Validate amount format
            if not amount_pattern.match(amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse with Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format output with sorted keys and exactly 2 decimal places
    result: dict[str, str] = {}
    for key in sorted(totals.keys()):
        # Quantize to 2 decimal places
        total = totals[key].quantize(Decimal('0.01'))
        result[key] = str(total)
    
    return result
