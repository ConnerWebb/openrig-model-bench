"""Tests for solution.aggregate."""

import os
import tempfile

import solution


def _run(csv_text: str):
    fd, path = tempfile.mkstemp(suffix=".csv")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(csv_text)
        return solution.aggregate(path)
    finally:
        os.unlink(path)


def _expect_error(csv_text: str):
    try:
        _run(csv_text)
    except ValueError:
        return
    raise AssertionError(f"expected ValueError for {csv_text!r}")


def test_public_case_1():
    result = _run(
        'category,amount\n"x""quote",812.68\nfood,347.25\nrent,991.77\n'
        "rent,345.17\nfood,261.47\n\"x\"\"quote\",71.74\n\"x\"\"quote\",254.02\n"
        "\"x\"\"quote\",31.70\n日本,690.39\n\"a,b\",599.14\nrent,457.86\n"
        "日本,218.62\nfood,455.70\n\"x\"\"quote\",39.70\n\"two\nlines\",849.77\n"
        "\"x\"\"quote\",248.76\nrent,421.12\n\"two\nlines\",584.47\nfood,870.27\n"
        "food,327.32\n"
    )
    assert result == {
        "a,b": "599.14",
        "food": "2262.01",
        "rent": "2215.92",
        "two\nlines": "1434.24",
        'x"quote': "1458.60",
        "日本": "909.01",
    }


def test_public_case_2():
    result = _run(
        "category,amount\nrent,204.44\nrent,965.51\n\"x\"\"quote\",464.96\n"
        "\"a,b\",758.07\nfood,329.33\n\"a,b\",273.11\n\"two\nlines\",38.36\n"
        "food,127.88\nrent,128.71\n\"a,b\",182.35\n\"two\nlines\",626.01\n"
        "\"two\nlines\",741.38\n\"x\"\"quote\",469.53\n\"a,b\",124.37\nrent,397.36\n"
        "\"x\"\"quote\",283.13\nrent,754.49\n\"two\nlines\",624.22\n"
        "\"x\"\"quote\",420.82\n\"a,b\",124.22\n日本,984.39\n日本,817.87\n"
        "\"x\"\"quote\",338.00\n日本,978.27\nfood,45.98\nrent,290.01\n"
        "\"two\nlines\",427.32\n日本,660.85\n\"x\"\"quote\",402.73\nrent,353.84\n"
        "rent,70.22\n\"two\nlines\",704.87\n\"two\nlines\",312.64\nrent,788.02\n"
        "food,277.54\n日本,577.44\n\"a,b\",612.46\n\"two\nlines\",339.11\n"
    )
    assert result == {
        "a,b": "2074.58",
        "food": "780.73",
        "rent": "3952.60",
        "two\nlines": "3813.91",
        'x"quote': "2379.17",
        "日本": "4018.82",
    }


def test_public_case_3():
    result = _run(
        "category,amount\n\"two\nlines\",701.11\n日本,417.63\n\"x\"\"quote\",636.47\n"
        "\"x\"\"quote\",645.43\nfood,534.59\nrent,595.15\n\"a,b\",845.38\n"
        "\"x\"\"quote\",656.79\n日本,380.85\n日本,17.78\nfood,553.84\n"
        "\"two\nlines\",84.37\n\"a,b\",325.24\n\"a,b\",783.67\n日本,198.80\n"
        "\"two\nlines\",889.26\n\"x\"\"quote\",727.84\n\"a,b\",777.27\n"
        "\"two\nlines\",64.97\n"
    )
    assert result == {
        "a,b": "2731.56",
        "food": "1088.43",
        "rent": "595.15",
        "two\nlines": "1739.71",
        'x"quote': "2666.53",
        "日本": "1015.06",
    }


def test_public_case_4():
    result = _run(
        "category,amount\n\"two\nlines\",134.37\n\"x\"\"quote\",700.99\n日本,826.90\n"
        "\"a,b\",402.93\n日本,720.86\n\"x\"\"quote\",405.45\n日本,847.00\nfood,352.26\n"
        "\"two\nlines\",420.71\n\"two\nlines\",881.80\n\"a,b\",476.84\n"
        "\"x\"\"quote\",137.81\n\"x\"\"quote\",589.82\n\"x\"\"quote\",615.63\n"
        "food,975.70\n\"a,b\",652.20\nrent,631.30\n日本,898.98\n"
    )
    assert result == {
        "a,b": "1531.97",
        "food": "1327.96",
        "rent": "631.30",
        "two\nlines": "1436.88",
        'x"quote': "2449.70",
        "日本": "3293.74",
    }


def test_public_error_cases():
    _expect_error("wrong,amount\nx,1\n")
    _expect_error("category,amount\nx,1,2\n")
    _expect_error("category,amount\n,1\n")
    _expect_error("category,amount\nx,NaN\n")
    _expect_error('category,amount\n"x,1\n')
    _expect_error("category,amount\nx,1e2\n")
    _expect_error("category,amount\nx,-1\n")
    _expect_error("category,amount\nx,1.001\n")
    _expect_error("category,amount\nx,1000000000000\n")


def test_blank_records_ignored():
    result = _run("category,amount\n\nfood,1.00\n\n\nfood,2.00\n")
    assert result == {"food": "3.00"}


def test_whitespace_stripped():
    result = _run("category,amount\n  food  ,  1.5  \nfood,0.25\n")
    assert result == {"food": "1.75"}


def test_optional_plus_sign():
    result = _run("category,amount\nx,+42\n")
    assert result == {"x": "42.00"}


def test_integer_amounts():
    result = _run("category,amount\nx,0\ny,123456789012\n")
    assert result == {"x": "0.00", "y": "123456789012.00"}


def test_one_decimal_digit():
    result = _run("category,amount\nx,5.5\n")
    assert result == {"x": "5.50"}


def test_exact_decimal_accumulation():
    result = _run("category,amount\nx,0.1\nx,0.2\n")
    assert result == {"x": "0.30"}


def test_two_decimal_places_formatting():
    result = _run("category,amount\nx,1\ny,1.99\n")
    assert result == {"x": "1.00", "y": "1.99"}


def test_keys_sorted():
    result = _run("category,amount\nz,1\na,1\nm,1\n")
    assert list(result) == ["a", "m", "z"]


def test_rejects_bad_amounts():
    for bad in ("", "1.", ".5", "1.234", "+", "-", "1 2", "0x10", "1e0", "1E0"):
        _expect_error(f"category,amount\nx,{bad}\n")


def test_rejects_empty_category():
    _expect_error("category,amount\n   ,1\n")


def test_rejects_missing_header():
    _expect_error("x,1\n")


def test_rejects_wrong_field_count():
    _expect_error("category,amount\nx\n")
    _expect_error("category,amount\nx,1,2\n")


def test_rejects_unclosed_quote():
    _expect_error('category,amount\n"x,1\n')


def test_rejects_header_case_and_order():
    _expect_error("Category,amount\nx,1\n")
    _expect_error("amount,category\n1,x\n")
