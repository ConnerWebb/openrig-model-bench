# CSV Category Aggregator

`solution.py` implements `aggregate(path: str) -> dict[str, str]`.

## Contract

- Reads a UTF-8 CSV file **as a stream** (line-by-line via `csv.reader`; the
  whole file is never loaded into memory just to parse it).
- The header must be exactly `category,amount` (whitespace around fields is
  stripped before comparison).
- Completely blank records are ignored; every other record must have exactly
  two fields.
- `category` and `amount` are stripped of surrounding whitespace.
  `category` must be non-empty after stripping.
- `amount` must match `^[+]?[0-9]{1,12}(\.[0-9]{1,2})?$`:
  optional `+`, 1–12 decimal digits, optional decimal point followed by
  1–2 digits. Nonnegative, finite, no exponent.
- Any malformed input (bad header, wrong field count, empty category, bad
  amount, unclosed quote, missing header) raises `ValueError`.
- Totals are accumulated with exact `decimal.Decimal` arithmetic.
- The result maps each category to its total formatted with exactly two
  decimal places, with keys sorted.
- Quoted commas and embedded newlines in fields are valid CSV and are
  handled correctly.

## Usage

```python
from solution import aggregate

totals = aggregate("data.csv")
# e.g. {"food": "2262.01", "rent": "2215.92"}
```

## Tests

`test_solution.py` covers the public cases plus edge cases (blank records,
whitespace, `+` sign, integer amounts, decimal precision, sorting, and all
malformed-input rejections). Run with:

```
python3 -m pytest test_solution.py -v
```
