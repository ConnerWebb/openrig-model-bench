"""Streaming CSV aggregation.

aggregate(path) reads a UTF-8 CSV file as a stream, validates each record
against a strict contract, and returns per-category totals using exact
decimal arithmetic.
"""

from __future__ import annotations

import csv
import re
from decimal import Decimal

_HEADER = ("category", "amount")
_AMOUNT_RE = re.compile(r"^[+]?[0-9]{1,12}(\.[0-9]{1,2})?$")


def _validate_amount(raw: str) -> Decimal:
    text = raw.strip()
    if not _AMOUNT_RE.match(text):
        raise ValueError(f"malformed amount: {raw!r}")
    return Decimal(text)


def aggregate(path: str) -> dict[str, str]:
    totals: dict[str, Decimal] = {}
    with open(path, "r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("missing header") from None
        if tuple(field.strip() for field in header) != _HEADER:
            raise ValueError("header must be exactly category,amount")
        for record in reader:
            if not record or all(not field.strip() for field in record):
                continue
            if len(record) != 2:
                raise ValueError(f"record must have exactly two fields: {record!r}")
            category = record[0].strip()
            if not category:
                raise ValueError("category must not be empty")
            amount = _validate_amount(record[1])
            totals[category] = totals.get(category, Decimal(0)) + amount
    return {key: f"{value:.2f}" for key, value in sorted(totals.items())}
