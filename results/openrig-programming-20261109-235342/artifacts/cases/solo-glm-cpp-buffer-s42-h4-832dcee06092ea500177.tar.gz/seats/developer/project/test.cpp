#include "solution.hpp"
#include <iostream>
#include <cassert>
#include <vector>
#include <cstring>

void test_basic_operations() {
    std::cout << "Testing basic operations..." << std::endl;

    Buffer b(10);
    assert(b.size() == 10);
    assert(b[0] == 0);
    assert(b[9] == 0);

    b[0] = 42;
    b[5] = 255;
    assert(b[0] == 42);
    assert(b[5] == 255);

    std::cout << "  Basic operations: PASS" << std::endl;
}

void test_resize_preserves_prefix() {
    std::cout << "Testing resize preserves prefix..." << std::endl;

    Buffer b(10);
    for (std::size_t i = 0; i < 10; ++i) {
        b[i] = static_cast<std::uint8_t>(i * 10);
    }

    b.resize(5);
    assert(b.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i * 10));
    }

    b.resize(15);
    assert(b.size() == 15);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i * 10));
    }
    for (std::size_t i = 5; i < 15; ++i) {
        assert(b[i] == 0);
    }

    std::cout << "  Resize preserves prefix: PASS" << std::endl;
}

void test_resize_zero_initializes_new_bytes() {
    std::cout << "Testing resize zero-initializes new bytes..." << std::endl;

    Buffer b(5);
    b[0] = 100;
    b[1] = 200;

    b.resize(10);
    assert(b.size() == 10);
    assert(b[0] == 100);
    assert(b[1] == 200);
    for (std::size_t i = 2; i < 10; ++i) {
        assert(b[i] == 0);
    }

    std::cout << "  Resize zero-initializes new bytes: PASS" << std::endl;
}

void test_bounds_checking() {
    std::cout << "Testing bounds checking..." << std::endl;

    Buffer b(5);
    bool caught = false;
    try {
        b[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);

    caught = false;
    try {
        const Buffer& cb = b;
        cb[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);

    std::cout << "  Bounds checking: PASS" << std::endl;
}

void test_move_construction() {
    std::cout << "Testing move construction..." << std::endl;

    Buffer b1(10);
    for (std::size_t i = 0; i < 10; ++i) {
        b1[i] = static_cast<std::uint8_t>(i * 20);
    }

    Buffer b2 = std::move(b1);
    assert(b2.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b2[i] == static_cast<std::uint8_t>(i * 20));
    }
    check_moved_state(b1);
    assert(b1.size() == 0);

    std::cout << "  Move construction: PASS" << std::endl;
}

void test_move_assignment() {
    std::cout << "Testing move assignment..." << std::endl;

    Buffer b1(10);
    for (std::size_t i = 0; i < 10; ++i) {
        b1[i] = static_cast<std::uint8_t>(i * 30);
    }

    Buffer b2(5);
    b2 = std::move(b1);
    assert(b2.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b2[i] == static_cast<std::uint8_t>(i * 30));
    }
    check_moved_state(b1);
    assert(b1.size() == 0);

    std::cout << "  Move assignment: PASS" << std::endl;
}

void test_self_move_preserves_content() {
    std::cout << "Testing self-move preserves content..." << std::endl;

    Buffer b(10);
    for (std::size_t i = 0; i < 10; ++i) {
        b[i] = static_cast<std::uint8_t>(i * 40);
    }

    b = std::move(b);
    assert(b.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == static_cast<std::uint8_t>(i * 40));
    }

    std::cout << "  Self-move preserves content: PASS" << std::endl;
}

void test_deep_copy_semantics() {
    std::cout << "Testing deep copy semantics..." << std::endl;

    Buffer b1(5);
    b1[0] = 1;
    b1[1] = 2;
    b1[2] = 3;

    Buffer b2(b1);
    assert(b2.size() == 5);
    assert(b2[0] == 1);
    assert(b2[1] == 2);
    assert(b2[2] == 3);

    b2[0] = 99;
    assert(b1[0] == 1);
    assert(b2[0] == 99);

    std::cout << "  Deep copy semantics: PASS" << std::endl;
}

void test_no_leaks() {
    std::cout << "Testing no memory leaks..." << std::endl;

    {
        Buffer b1(10);
        Buffer b2 = std::move(b1);
        Buffer b3(5);
        b3 = std::move(b2);
    }

    std::cout << "  No memory leaks: PASS" << std::endl;
}

void test_no_double_free() {
    std::cout << "Testing no double free..." << std::endl;

    {
        Buffer b1(10);
        Buffer b2 = std::move(b1);
        Buffer b3 = std::move(b2);
        Buffer b4 = std::move(b3);
    }

    std::cout << "  No double free: PASS" << std::endl;
}

void test_no_stale_reads() {
    std::cout << "Testing no stale reads..." << std::endl;

    Buffer b1(10);
    for (std::size_t i = 0; i < 10; ++i) {
        b1[i] = static_cast<std::uint8_t>(i * 50);
    }

    Buffer b2 = std::move(b1);
    assert(b2.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b2[i] == static_cast<std::uint8_t>(i * 50));
    }

    std::cout << "  No stale reads: PASS" << std::endl;
}

void test_zero_initialization() {
    std::cout << "Testing zero initialization..." << std::endl;

    Buffer b(10);
    for (std::size_t i = 0; i < 10; ++i) {
        assert(b[i] == 0);
    }

    std::cout << "  Zero initialization: PASS" << std::endl;
}

void test_public_cases() {
    std::cout << "Testing public cases..." << std::endl;

    std::vector<std::uint8_t> input1 = {20, 65, 4, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97};
    Buffer b1(input1.size());
    for (std::size_t i = 0; i < input1.size(); ++i) {
        b1[i] = input1[i];
    }

    std::vector<std::uint8_t> expected1 = {
        4, 135, 79, 102, 134, 44, 102, 28, 99, 12, 187, 234, 66, 178, 85, 18, 178, 15, 198, 97,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };

    assert(b1.size() == expected1.size());
    for (std::size_t i = 0; i < expected1.size(); ++i) {
        assert(b1[i] == expected1[i]);
    }

    std::cout << "  Public cases: PASS" << std::endl;
}

int main() {
    std::cout << "Running Buffer tests..." << std::endl;
    std::cout << std::endl;

    test_basic_operations();
    test_resize_preserves_prefix();
    test_resize_zero_initializes_new_bytes();
    test_bounds_checking();
    test_move_construction();
    test_move_assignment();
    test_self_move_preserves_content();
    test_deep_copy_semantics();
    test_no_leaks();
    test_no_double_free();
    test_no_stale_reads();
    test_zero_initialization();
    test_public_cases();

    std::cout << std::endl;
    std::cout << "All tests passed!" << std::endl;

    return 0;
}