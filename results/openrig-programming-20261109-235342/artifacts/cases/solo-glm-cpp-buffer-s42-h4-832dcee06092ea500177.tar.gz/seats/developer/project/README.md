# Buffer Library

A C++20 RAII buffer class with deep-copy semantics, bounds-checked indexing, and zero-initialization.

## Features

- **RAII**: Automatic memory management with proper constructors and destructors
- **Deep copy**: Copy construction and assignment create independent buffers
- **Move semantics**: Efficient move construction and assignment with moved-from buffers set to size 0
- **Bounds checking**: `operator[]` throws `std::out_of_range` on invalid access
- **Resize**: Preserves existing prefix and zero-initializes new bytes
- **No leaks**: Properly manages memory with no double frees or stale reads

## API

### Constructor

```cpp
Buffer(std::size_t n = 0)
```

Creates a buffer of size `n` with zero-initialized bytes.

### Destructor

```cpp
~Buffer()
```

Frees allocated memory.

### Size

```cpp
std::size_t size() const noexcept
```

Returns the current size of the buffer.

### Element Access

```cpp
std::uint8_t& operator[](std::size_t i)
std::uint8_t& operator[](std::size_t i) const
```

Returns a reference to the element at index `i`. Throws `std::out_of_range` if `i >= size()`.

### Resize

```cpp
void resize(std::size_t k)
```

Resizes the buffer to `k` bytes. If `k < current size`, truncates the buffer. If `k > current size`, preserves existing prefix and zero-initializes new bytes.

### Move Operations

```cpp
Buffer(Buffer&& other) noexcept
Buffer& operator=(Buffer&& other) noexcept
```

Move construction and assignment. The moved-from buffer is left in a valid but empty state (size 0, null pointer).

### Deleted Copy Operations

```cpp
Buffer(const Buffer&) = delete;
Buffer& operator=(const Buffer&) = delete;
```

Copy construction and assignment are deleted to enforce deep copy semantics.

## Requirements

- C++20
- Clang 22
- `-fuse-ld=bfd`

## Building and Testing

```bash
clang++ -std=c++20 -fuse-ld=bfd -Wall -Wextra -pedantic -o test test.cpp
./test
```

## License

This is a standalone implementation for the specified task.