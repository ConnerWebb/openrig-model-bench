#pragma once
#include <cstdint>
#include <cstddef>
#include <algorithm>
#include <stdexcept>

class Buffer {
    std::uint8_t* p;
    std::size_t n;

public:
    explicit Buffer(std::size_t n = 0) : p(n ? new std::uint8_t[n] : nullptr), n(n) {}

    ~Buffer() {
        delete[] p;
    }

    // Deleted copy operations to enforce deep copy semantics
    Buffer(const Buffer&) = delete;
    Buffer& operator=(const Buffer&) = delete;

    // Move operations
    Buffer(Buffer&& other) noexcept : p(other.p), n(other.n) {
        other.p = nullptr;
        other.n = 0;
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] p;
            p = other.p;
            n = other.n;
            other.p = nullptr;
            other.n = 0;
        }
        return *this;
    }

    std::size_t size() const noexcept {
        return n;
    }

    std::uint8_t& operator[](std::size_t i) {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    const std::uint8_t& operator[](std::size_t i) const {
        if (i >= n) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p[i];
    }

    void resize(std::size_t k) {
        if (k < n) {
            n = k;
        } else {
            std::uint8_t* new_p = new std::uint8_t[k];
            std::copy(p, p + n, new_p);
            delete[] p;
            p = new_p;
            n = k;
        }
    }

    // Friend function to allow testing of moved-from state
    friend void check_moved_state(const Buffer& b);
};