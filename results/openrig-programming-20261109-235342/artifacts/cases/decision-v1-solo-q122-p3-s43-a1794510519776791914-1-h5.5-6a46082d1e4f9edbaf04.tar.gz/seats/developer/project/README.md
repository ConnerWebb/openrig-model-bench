# Buffer Library

A C++20 buffer implementation with deep copy semantics, noexcept move operations, and bounds-checked access.

## Features

- **Deep copy construction/assignment**: Each copy owns its own memory
- **Noexcept move operations**: Efficient transfers with moved-from buffer having size 0
- **Bounds-checked access**: `operator[]` throws `std::out_of_range` on invalid indices
- **Safe resize**: Preserves existing data, zero-initializes new elements
- **RAII**: Automatic memory management, no leaks or double frees

## API

```cpp
class Buffer {
    Buffer(std::size_t n = 0);                    // Construct with n zero-initialized bytes
    ~Buffer();                                    // Destructor (RAII)
    
    Buffer(const Buffer& other);                  // Deep copy constructor
    Buffer& operator=(const Buffer& other);       // Deep copy assignment
    
    Buffer(Buffer&& other) noexcept;              // Move constructor
    Buffer& operator=(Buffer&& other) noexcept;   // Move assignment
    
    std::size_t size() const noexcept;            // Return buffer size
    std::uint8_t& operator[](std::size_t i);      // Mutable access with bounds check
    const std::uint8_t& operator[](std::size_t i) const;  // Const access with bounds check
    void resize(std::size_t k);                   // Resize, preserving prefix
};
```

## Usage Example

```cpp
Buffer a(10);           // Create buffer of 10 zero-initialized bytes
a[0] = 42;              // Safe access (throws if out of bounds)
Buffer b = a;           // Deep copy
Buffer c = std::move(b); // Move, b now has size 0
a.resize(20);           // Resize to 20, preserving first 10 bytes
```

## Building

```bash
clang++ -std=c++20 -fuse-ld=bfd -o driver PUBLIC_DRIVER.cpp
```

## Testing

Run the test suite:
```bash
python3 test_buffer.py
```

Or use the framework:
```bash
run_tests
```
