import unittest
import subprocess
import json
import sys

class TestBuffer(unittest.TestCase):
    def run_driver(self, input_data):
        """Run the C++ driver with given input and return parsed JSON output."""
        result = subprocess.run(
            ['./driver'],
            input=input_data,
            capture_output=True,
            text=True,
            timeout=10
        )
        output = result.stdout.strip()
        return json.loads(output)

    def test_case_00(self):
        """Test case from public-inputs/case-00.json"""
        input_data = "20 65 4 135 79 102 134 44 102 28 99 12 187 234 66 178 85 18 178 15 198 97"
        result = self.run_driver(input_data)
        self.assertTrue(result.get('bounds', False))
        self.assertEqual(result.get('moved_size', 0), 0)
        # Check that copy has first byte XORed with 255
        copy = result.get('copy', [])
        self.assertEqual(copy[0], 4 ^ 255)  # 251
        self.assertEqual(len(copy), 20)

    def test_case_01(self):
        """Test case from public-inputs/case-01.json"""
        input_data = "9 41 223 228 49 10 127 75 79 126 181"
        result = self.run_driver(input_data)
        self.assertTrue(result.get('bounds', False))
        copy = result.get('copy', [])
        self.assertEqual(copy[0], 223 ^ 255)  # 32
        self.assertEqual(len(copy), 9)

    def test_case_02(self):
        """Test case from public-inputs/case-02.json"""
        input_data = "19 74 8 128 179 106 201 14 35 49 127 50 151 71 212 244 252 183 151 48 104"
        result = self.run_driver(input_data)
        self.assertTrue(result.get('bounds', False))
        copy = result.get('copy', [])
        self.assertEqual(copy[0], 8 ^ 255)  # 247
        self.assertEqual(len(copy), 19)

    def test_case_03(self):
        """Test case from public-inputs/case-03.json"""
        input_data = "19 79 110 82 225 243 164 133 48 132 12 17 96 113 241 166 157 124 138 72 27"
        result = self.run_driver(input_data)
        self.assertTrue(result.get('bounds', False))
        copy = result.get('copy', [])
        self.assertEqual(copy[0], 110 ^ 255)  # 145
        self.assertEqual(len(copy), 19)

    def test_empty_buffer(self):
        """Test empty buffer construction and resize."""
        input_data = "0 10"
        result = self.run_driver(input_data)
        self.assertTrue(result.get('bounds', False))
        self.assertEqual(len(result.get('value', [])), 10)

    def test_zero_size_buffer(self):
        """Test buffer with size 0."""
        input_data = "0 0"
        result = self.run_driver(input_data)
        self.assertTrue(result.get('bounds', False))
        self.assertEqual(len(result.get('value', [])), 0)

if __name__ == '__main__':
    unittest.main()
