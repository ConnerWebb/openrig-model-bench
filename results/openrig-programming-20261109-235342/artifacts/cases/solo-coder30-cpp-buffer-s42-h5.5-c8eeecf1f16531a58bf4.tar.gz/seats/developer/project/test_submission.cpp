#include <iostream>
#include <cassert>
#include <stdexcept>
#include "solution.hpp"

int main() {
    // Test default constructor
    Buffer b1;
    assert(b1.size() == 0);
    
    // Test constructor with size
    Buffer b2(10);
    assert(b2.size() == 10);
    
    // Test operator[]
    b2[0] = 42;
    assert(b2[0] == 42);
    
    // Test const operator[]
    const Buffer& cb2 = b2;
    assert(cb2[0] == 42);
    
    // Test resize
    b2.resize(15);
    assert(b2.size() == 15);
    assert(b2[0] == 42); // Should preserve existing content
    
    // Test copy constructor
    Buffer b3(b2);
    assert(b3.size() == 15);
    assert(b3[0] == 42);
    
    // Test copy assignment
    Buffer b4;
    b4 = b2;
    assert(b4.size() == 15);
    assert(b4[0] == 42);
    
    // Test move constructor
    Buffer b5(std::move(b2));
    assert(b2.size() == 0); // Moved from buffer should be empty
    assert(b5.size() == 15);
    assert(b5[0] == 42);
    
    // Test move assignment
    Buffer b6;
    b6 = std::move(b5);
    assert(b5.size() == 0); // Moved from buffer should be empty
    assert(b6.size() == 15);
    assert(b6[0] == 42);
    
    // Test bounds checking
    try {
        b6[100] = 5; // Should throw
        assert(false); // Should not reach here
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    try {
        const Buffer& cb6 = b6;
        volatile auto val = cb6[100]; // Should throw
        assert(false); // Should not reach here
    } catch (const std::out_of_range&) {
        // Expected
    }
    
    // Test resize with zero-initialization
    Buffer b7(5);
    b7[0] = 10;
    b7[4] = 20;
    b7.resize(8);
    assert(b7.size() == 8);
    assert(b7[0] == 10);
    assert(b7[4] == 20);
    assert(b7[5] == 0); // Should be zero-initialized
    assert(b7[7] == 0); // Should be zero-initialized
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}