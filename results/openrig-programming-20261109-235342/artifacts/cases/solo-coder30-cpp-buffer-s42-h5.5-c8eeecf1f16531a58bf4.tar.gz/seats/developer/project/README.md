# Buffer Implementation

This is a C++20 implementation of a `Buffer` class that manages a dynamic array of `uint8_t` elements.

## Features

- **RAII**: Proper resource management with constructor, destructor, copy constructor, copy assignment, move constructor, and move assignment
- **Bounds Checking**: Both `operator[]` methods perform bounds checking and throw `std::out_of_range` when accessing invalid indices
- **Resize**: `resize()` method preserves existing content and zero-initializes new elements
- **Move Semantics**: Noexcept move constructor and assignment with proper state management
- **Deep Copy**: Copy constructor and assignment perform deep copying
- **Self Operations**: Self-copy and self-move operations are handled correctly

## Methods

- `Buffer(std::size_t n = 0)`: Construct buffer with n elements (default 0)
- `~Buffer()`: Destructor
- `size() const noexcept`: Get buffer size
- `operator[](std::size_t i)`: Access element (mutable)
- `operator[](std::size_t i) const`: Access element (const)
- `resize(std::size_t k)`: Resize buffer, preserving prefix and zero-initializing new elements

## Exception Safety

- All move operations are noexcept
- Copy operations throw `std::out_of_range` on bounds violation
- No memory leaks or undefined behavior