# Buffer Library

A C++20 Buffer class with the following features:

## Features
- `Buffer(size_t n=0)` - Construct with optional initial size
- `size() const noexcept` - Return current size
- `mutable operator[](size_t)` - Mutable access with bounds checking
- `const operator[](size_t)` - Const access with bounds checking
- `resize(size_t)` - Resize while preserving prefix and zero-initializing new bytes
- Deep-copy construction and assignment
- Noexcept move construction and assignment
- Moved-from buffers are size 0 and reusable
- Self-copy/self-move preserve content

## Implementation Details
- Uses RAII for memory management
- No leaks, double frees, or undefined behavior
- Bounds-checked access throws `std::out_of_range` on invalid indices
- Elements are `uint8_t`

## Tests
Run `run_tests` to execute all tests including:
- Basic buffer operations
- Move semantics
- Copy semantics
- Resize operations
- Const operator
- Bounds checking
