#include <iostream>
#include <sstream>
#include <cassert>
#include "solution.hpp"

void test_buffer_basic() {
    // Test empty buffer
    Buffer b;
    assert(b.size() == 0);
    
    // Test construction with size
    Buffer b1(5);
    assert(b1.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b1[i] == 0);
    }
    
    // Test resize (grow)
    b1.resize(10);
    assert(b1.size() == 10);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b1[i] == 0);
    }
    for (std::size_t i = 5; i < 10; ++i) {
        assert(b1[i] == 0);
    }
    
    // Test resize (shrink)
    b1.resize(3);
    assert(b1.size() == 3);
    for (std::size_t i = 0; i < 3; ++i) {
        assert(b1[i] == 0);
    }
    
    // Test setting values
    b1[0] = 42;
    b1[2] = 100;
    assert(b1[0] == 42);
    assert(b1[2] == 100);
    
    // Test bounds check
    bool caught = false;
    try {
        b1[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    
    std::cout << "test_buffer_basic: PASSED" << std::endl;
}

int main() {
    test_buffer_basic();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
