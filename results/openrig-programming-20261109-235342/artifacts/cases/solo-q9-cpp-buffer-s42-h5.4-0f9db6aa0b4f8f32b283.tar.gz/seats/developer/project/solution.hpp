#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <memory>
#include <algorithm>

class Buffer {
public:
    using value_type = std::uint8_t;
    using size_type = std::size_t;

private:
    std::unique_ptr<std::uint8_t[]> p_;
    size_type n_;

public:
    Buffer() noexcept : p_(nullptr), n_(0) {}

    explicit Buffer(size_type n) noexcept {
        if (n == 0) {
            p_ = nullptr;
            n_ = 0;
        } else {
            p_ = std::make_unique<std::uint8_t[]>(n);
            std::fill(p_.get(), p_.get() + n, static_cast<std::uint8_t>(0));
            n_ = n;
        }
    }

    ~Buffer() = default;

    // Deep-copy constructor
    Buffer(const Buffer& other) noexcept {
        n_ = other.n_;
        if (n_ == 0) {
            p_ = nullptr;
        } else {
            p_ = std::make_unique<std::uint8_t[]>(n_);
            std::copy(other.p_.get(), other.p_.get() + n_, p_.get());
        }
    }

    // Deep-copy assignment
    Buffer& operator=(const Buffer& other) noexcept {
        if (this != &other) {
            n_ = other.n_;
            if (n_ == 0) {
                p_ = nullptr;
            } else {
                p_ = std::make_unique<std::uint8_t[]>(n_);
                std::copy(other.p_.get(), other.p_.get() + n_, p_.get());
            }
        }
        return *this;
    }

    // Move constructor
    Buffer(Buffer&& other) noexcept : p_(std::move(other.p_)), n_(other.n_) {
        other.p_ = nullptr;
        other.n_ = 0;
    }

    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            p_ = std::move(other.p_);
            n_ = other.n_;
            other.p_ = nullptr;
            other.n_ = 0;
        }
        return *this;
    }

    size_type size() const noexcept {
        return n_;
    }

    // Mutable operator[] - throws out_of_range on bounds
    std::uint8_t& operator[](size_type i) {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    // Const operator[] - throws out_of_range on bounds
    std::uint8_t const& operator[](size_type i) const {
        if (i >= n_) {
            throw std::out_of_range("Buffer index out of range");
        }
        return p_[i];
    }

    void resize(size_type k) {
        if (k == 0) {
            p_ = nullptr;
            n_ = 0;
            return;
        }
        
        if (k > n_) {
            // Grow: preserve prefix, zero-initialize new bytes
            auto new_p = std::make_unique<std::uint8_t[]>(k);
            if (p_) {
                std::copy(p_.get(), p_.get() + n_, new_p.get());
                std::fill(new_p.get() + n_, new_p.get() + k, static_cast<std::uint8_t>(0));
            } else {
                std::fill(new_p.get(), new_p.get() + k, static_cast<std::uint8_t>(0));
            }
            p_ = std::move(new_p);
            n_ = k;
        } else if (k < n_) {
            // Shrink: preserve prefix
            auto new_p = std::make_unique<std::uint8_t[]>(k);
            std::copy(p_.get(), p_.get() + k, new_p.get());
            p_ = std::move(new_p);
            n_ = k;
        }
    }
};
