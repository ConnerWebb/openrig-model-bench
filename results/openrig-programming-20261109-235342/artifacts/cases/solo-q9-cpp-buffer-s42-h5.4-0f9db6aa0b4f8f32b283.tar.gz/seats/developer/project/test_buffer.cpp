#include <iostream>
#include <sstream>
#include <cassert>
#include "solution.hpp"

void test_buffer_basic() {
    // Test empty buffer
    Buffer b;
    assert(b.size() == 0);
    
    // Test construction with size
    Buffer b1(5);
    assert(b1.size() == 5);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b1[i] == 0);
    }
    
    // Test resize (grow)
    b1.resize(10);
    assert(b1.size() == 10);
    for (std::size_t i = 0; i < 5; ++i) {
        assert(b1[i] == 0);
    }
    for (std::size_t i = 5; i < 10; ++i) {
        assert(b1[i] == 0);
    }
    
    // Test resize (shrink)
    b1.resize(3);
    assert(b1.size() == 3);
    for (std::size_t i = 0; i < 3; ++i) {
        assert(b1[i] == 0);
    }
    
    // Test setting values
    b1[0] = 42;
    b1[2] = 100;
    assert(b1[0] == 42);
    assert(b1[2] == 100);
    
    // Test bounds check
    bool caught = false;
    try {
        b1[10];
    } catch (const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
    
    std::cout << "test_buffer_basic: PASSED" << std::endl;
}

void test_buffer_move() {
    Buffer b(5);
    b[0] = 1;
    b[1] = 2;
    
    Buffer c = std::move(b);
    assert(c.size() == 5);
    assert(c[0] == 1);
    assert(c[1] == 2);
    assert(b.size() == 0);
    
    std::cout << "test_buffer_move: PASSED" << std::endl;
}

void test_buffer_copy() {
    Buffer b(5);
    b[0] = 42;
    b[1] = 100;
    
    Buffer c = b;  // Copy constructor
    assert(c.size() == 5);
    assert(c[0] == 42);
    assert(c[1] == 100);
    
    // Modify original
    b[0] = 123;
    assert(c[0] == 42);  // Copy should be independent
    
    std::cout << "test_buffer_copy: PASSED" << std::endl;
}

void test_buffer_move_assignment() {
    Buffer b(5);
    b[0] = 1;
    
    Buffer c(10);
    c[0] = 2;
    
    c = std::move(b);
    assert(c.size() == 5);
    assert(c[0] == 1);
    assert(b.size() == 0);
    
    std::cout << "test_buffer_move_assignment: PASSED" << std::endl;
}

void test_buffer_copy_assignment() {
    Buffer b(5);
    b[0] = 42;
    
    Buffer c(10);
    c[0] = 123;
    
    c = b;  // Copy assignment
    assert(c.size() == 5);
    assert(c[0] == 42);
    assert(c[1] == 0);  // New elements should be zero
    
    std::cout << "test_buffer_copy_assignment: PASSED" << std::endl;
}

void test_buffer_self_move() {
    Buffer b(5);
    b[0] = 42;
    b[1] = 100;
    
    Buffer c = std::move(b);
    assert(c.size() == 5);
    assert(c[0] == 42);
    assert(c[1] == 100);
    
    std::cout << "test_buffer_self_move: PASSED" << std::endl;
}

void test_buffer_resize_zero() {
    Buffer b(5);
    b[0] = 42;
    
    b.resize(0);
    assert(b.size() == 0);
    
    std::cout << "test_buffer_resize_zero: PASSED" << std::endl;
}

void test_buffer_const_operator() {
    Buffer b(5);
    b[0] = 42;
    
    const Buffer& cb = b;
    std::ostringstream oss;
    oss << (int)cb[0];
    assert(oss.str() == "42");
    
    std::cout << "test_buffer_const_operator: PASSED" << std::endl;
}

int main() {
    test_buffer_basic();
    test_buffer_move();
    test_buffer_copy();
    test_buffer_move_assignment();
    test_buffer_copy_assignment();
    test_buffer_self_move();
    test_buffer_resize_zero();
    test_buffer_const_operator();
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
