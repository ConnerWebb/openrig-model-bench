#!/usr/bin/env python3
import subprocess
import sys
import os
import unittest

class TestBuffer(unittest.TestCase):
    """Test suite for Buffer class"""
    
    def test_buffer_basic(self):
        """Test basic buffer operations"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_basic',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_basic'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_move(self):
        """Test move semantics"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_move',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_move'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_copy(self):
        """Test copy semantics"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_copy',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_copy'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_move_assignment(self):
        """Test move assignment"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_move_assign',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_move_assign'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_copy_assignment(self):
        """Test copy assignment"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_copy_assign',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_copy_assign'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_self_move(self):
        """Test self-move preserves content"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_self_move',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_self_move'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_resize_zero(self):
        """Test resize to zero"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_resize_zero',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_resize_zero'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")
    
    def test_buffer_const_operator(self):
        """Test const operator[]"""
        cmd = [
            'clang++', '-std=c++20', '-fuse-ld=bfd', '-o', '/tmp/test_const_op',
            '-I/work', '/work/test_buffer.cpp'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Compilation failed: {result.stderr}")
        result = subprocess.run(['/tmp/test_const_op'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, f"Test failed: {result.stderr}")

def main():
    suite = unittest.TestLoader().loadTestsFromTestCase(TestBuffer)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return 0 if result.wasSuccessful() else 1

if __name__ == "__main__":
    sys.exit(main())
