# Ledger Processing Module

A Python module for processing ledger records with validation, deduplication, and aggregation.

## Files

- `ledger.py` - Public facade module
- `engine.py` - Implementation module
- `test_ledger.py` - Unit tests
- `PUBLIC_DRIVER.py` - Public test driver

## API

### `ledger.process(records, minimum_cents=0)`

Process a list of records and return events and totals.

**Args:**
- `records`: List of record dicts with exactly `id`, `category`, and `cents` keys.
- `minimum_cents`: Filter records with `cents >= minimum_cents` (nonnegative integer, default 0).

**Returns:**
- Dict with:
  - `events`: List of normalized records (id/category stripped) in input order, filtered by minimum_cents.
  - `totals`: Dict mapping category (str) to sum of cents, keys sorted alphabetically.

**Raises:**
- `ValueError`: If any record is invalid or minimum_cents is invalid.

## Validation Rules

- Each record must be a dict with exactly the keys: `id`, `category`, `cents`.
- `id`: must be a nonempty stripped string.
- `category`: must be a nonempty stripped string.
- `cents`: must be a nonnegative integer (booleans are invalid).
- First occurrence of an `id` wins; duplicate ids raise `ValueError`.
- `minimum_cents` must be a nonnegative integer (booleans are invalid).

## Behavior

- Input records are never mutated.
- Returned data structures are new objects (no shared mutability).
- Records are normalized by stripping whitespace from `id` and `category`.
- Records with `cents < minimum_cents` are excluded from `events` and `totals`.
- `process([])` returns `{'events': [], 'totals': {}}`.

## Running Tests

```bash
python3 -m unittest test_ledger.py
```

## Example

```python
import ledger

records = [
    {'id': ' 1 ', 'category': ' a ', 'cents': 100},
    {'id': '2', 'category': 'b', 'cents': 50}
]

result = ledger.process(records)
# result = {
#     'events': [
#         {'id': '1', 'category': 'a', 'cents': 100},
#         {'id': '2', 'category': 'b', 'cents': 50}
#     ],
#     'totals': {'a': 100, 'b': 50}
# }
```
