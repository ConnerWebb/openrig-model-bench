"""Implementation module for ledger processing."""
from typing import Dict, List, Any


def _is_valid_id(value: Any) -> bool:
    """Check if value is a nonempty stripped string."""
    return isinstance(value, str) and value.strip() != ""


def _is_valid_category(value: Any) -> bool:
    """Check if value is a nonempty stripped string."""
    return isinstance(value, str) and value.strip() != ""


def _is_valid_cents(value: Any) -> bool:
    """Check if value is a nonnegative integer (excluding booleans)."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return value >= 0
    return False


def _validate_record(record: Any) -> None:
    """Validate a single record and raise ValueError if invalid."""
    if not isinstance(record, dict):
        raise ValueError("Record must be a dictionary")
    
    required_keys = {'id', 'category', 'cents'}
    if set(record.keys()) != required_keys:
        raise ValueError("Record must have exactly id, category, and cents keys")
    
    record_id = record['id']
    category = record['category']
    cents = record['cents']
    
    if not _is_valid_id(record_id):
        raise ValueError("id must be a nonempty stripped string")
    
    if not _is_valid_category(category):
        raise ValueError("category must be a nonempty stripped string")
    
    if not _is_valid_cents(cents):
        raise ValueError("cents must be a nonnegative integer")


def _normalize_record(record: dict) -> dict:
    """Return a normalized copy of the record with stripped id and category."""
    return {
        'id': record['id'].strip(),
        'category': record['category'].strip(),
        'cents': record['cents']
    }


def process(records: List[dict], minimum_cents: int = 0) -> dict:
    """Process records and return events and totals.
    
    Args:
        records: List of record dicts with id, category, cents keys.
        minimum_cents: Filter records with cents >= minimum_cents (nonnegative int).
    
    Returns:
        dict with 'events' (list of normalized records) and 'totals' (dict of category sums).
    
    Raises:
        ValueError: If any record is invalid or minimum_cents is invalid.
    """
    # Validate minimum_cents
    if not _is_valid_cents(minimum_cents):
        raise ValueError("minimum_cents must be a nonnegative integer")
    
    seen_ids = set()
    events: List[dict] = []
    totals_dict: Dict[str, int] = {}
    
    for record in records:
        _validate_record(record)
        
        normalized = _normalize_record(record)
        stripped_id = normalized['id']
        
        # Only process first occurrence of each id
        if stripped_id not in seen_ids:
            seen_ids.add(stripped_id)
            if normalized['cents'] >= minimum_cents:
                events.append(normalized)
                category = normalized['category']
                totals_dict[category] = totals_dict.get(category, 0) + normalized['cents']
    
    # Sort totals keys
    sorted_totals = {k: totals_dict[k] for k in sorted(totals_dict.keys())}
    
    return {'events': events, 'totals': sorted_totals}
