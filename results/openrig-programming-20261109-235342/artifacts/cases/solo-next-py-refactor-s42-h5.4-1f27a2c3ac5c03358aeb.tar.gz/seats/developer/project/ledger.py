"""Public facade module for ledger processing."""
from typing import List, Dict, Any
from engine import process as _process


def process(records: List[dict], minimum_cents: int = 0) -> dict:
    """Process records and return events and totals.
    
    Args:
        records: List of record dicts with id, category, cents keys.
        minimum_cents: Filter records with cents >= minimum_cents (nonnegative int).
    
    Returns:
        dict with 'events' (list of normalized records) and 'totals' (dict of category sums).
    
    Raises:
        ValueError: If any record is invalid or minimum_cents is invalid.
    """
    return _process(records, minimum_cents)
