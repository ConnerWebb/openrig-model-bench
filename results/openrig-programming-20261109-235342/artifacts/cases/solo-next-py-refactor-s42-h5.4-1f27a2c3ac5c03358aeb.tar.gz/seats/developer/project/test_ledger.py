"""Unit tests for ledger processing."""
import unittest
import copy
import ledger


class TestLedgerProcess(unittest.TestCase):
    """Tests for ledger.process function."""

    def test_empty_input(self):
        """process([]) returns empty events and totals."""
        result = ledger.process([])
        self.assertEqual(result, {'events': [], 'totals': {}})

    def test_single_valid_record(self):
        """Single valid record is processed correctly."""
        records = [{'id': 'x', 'category': 'a', 'cents': 100}]
        result = ledger.process(records)
        expected_events = [{'id': 'x', 'category': 'a', 'cents': 100}]
        self.assertEqual(result, {'events': expected_events, 'totals': {'a': 100}})

    def test_input_not_mutated(self):
        """Original records are not mutated."""
        records = [{'id': 'x', 'category': ' a ', 'cents': 100}]
        original = copy.deepcopy(records)
        ledger.process(records)
        self.assertEqual(records, original)

    def test_strip_id_and_category(self):
        """Id and category are stripped in output."""
        records = [{'id': ' x ', 'category': ' a ', 'cents': 100}]
        result = ledger.process(records)
        self.assertEqual(result['events'][0]['id'], 'x')
        self.assertEqual(result['events'][0]['category'], 'a')

    def test_first_id_wins_duplicates(self):
        """First occurrence of an id wins; duplicates are ignored."""
        records = [
            {'id': 'x', 'category': 'a', 'cents': 100},
            {'id': 'x', 'category': 'b', 'cents': 200}
        ]
        result = ledger.process(records)
        # Only first occurrence should be processed
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'x')
        self.assertEqual(result['events'][0]['category'], 'a')
        self.assertEqual(result['events'][0]['cents'], 100)
        self.assertEqual(result['totals'], {'a': 100})

    def test_minimum_cents_filter(self):
        """minimum_cents filters records correctly."""
        records = [
            {'id': 'x', 'category': 'a', 'cents': 50},
            {'id': 'y', 'category': 'b', 'cents': 100}
        ]
        result = ledger.process(records, minimum_cents=75)
        self.assertEqual(len(result['events']), 1)
        self.assertEqual(result['events'][0]['id'], 'y')
        self.assertEqual(result['totals'], {'b': 100})

    def test_minimum_cents_zero_default(self):
        """minimum_cents defaults to 0."""
        records = [{'id': 'x', 'category': 'a', 'cents': 0}]
        result = ledger.process(records)
        self.assertEqual(len(result['events']), 1)

    def test_totals_sorted_keys(self):
        """Totals keys are sorted."""
        records = [
            {'id': 'x', 'category': 'c', 'cents': 10},
            {'id': 'y', 'category': 'a', 'cents': 20},
            {'id': 'z', 'category': 'b', 'cents': 30}
        ]
        result = ledger.process(records)
        self.assertEqual(list(result['totals'].keys()), ['a', 'b', 'c'])

    def test_totals_sum_correct(self):
        """Totals sum cents per category."""
        records = [
            {'id': 'x', 'category': 'a', 'cents': 100},
            {'id': 'y', 'category': 'a', 'cents': 50},
            {'id': 'z', 'category': 'b', 'cents': 25}
        ]
        result = ledger.process(records)
        self.assertEqual(result['totals'], {'a': 150, 'b': 25})

    def test_invalid_record_not_dict(self):
        """Non-dict record raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process(['not a dict'])

    def test_invalid_record_missing_key(self):
        """Record missing required key raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'x', 'category': 'a'}])

    def test_invalid_record_extra_key(self):
        """Record with extra key raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'x', 'category': 'a', 'cents': 100, 'extra': 1}])

    def test_invalid_id_empty_string(self):
        """Empty id raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': '', 'category': 'a', 'cents': 100}])

    def test_invalid_id_whitespace_only(self):
        """Whitespace-only id raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': '   ', 'category': 'a', 'cents': 100}])

    def test_invalid_category_empty_string(self):
        """Empty category raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'x', 'category': '', 'cents': 100}])

    def test_invalid_cents_negative(self):
        """Negative cents raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'x', 'category': 'a', 'cents': -1}])

    def test_invalid_cents_boolean(self):
        """Boolean cents raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([{'id': 'x', 'category': 'a', 'cents': True}])

    def test_invalid_minimum_cents_negative(self):
        """Negative minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=-1)

    def test_invalid_minimum_cents_boolean(self):
        """Boolean minimum_cents raises ValueError."""
        with self.assertRaises(ValueError):
            ledger.process([], minimum_cents=True)

    def test_input_unchanged_after_multiple_calls(self):
        """Input records unchanged after multiple process calls."""
        records = [{'id': 'x', 'category': 'a', 'cents': 100}]
        original = copy.deepcopy(records)
        ledger.process(records)
        ledger.process(records)
        self.assertEqual(records, original)


if __name__ == '__main__':
    unittest.main()
