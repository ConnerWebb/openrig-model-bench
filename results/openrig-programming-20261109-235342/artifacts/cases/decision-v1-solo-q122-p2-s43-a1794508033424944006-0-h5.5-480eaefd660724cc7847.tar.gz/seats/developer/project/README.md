# CSV Aggregator

This module provides a function to aggregate CSV data by category using exact decimal arithmetic.

## API

```python
def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with amounts formatted to 2 decimal places.
    
    Args:
        path: Path to the CSV file
        
    Returns:
        Dictionary mapping category names to formatted totals (2 decimal places)
        
    Raises:
        ValueError: If the CSV is malformed (wrong header, invalid amounts, etc.)
    """
```

## CSV Format Requirements

- **Header**: Must be exactly `category,amount`
- **Records**: Each non-blank record must have exactly 2 fields
- **Category**: Non-empty after stripping whitespace
- **Amount**: 
  - Optional leading `+` sign
  - 1-12 decimal digits
  - Optional decimal point followed by 1-2 digits
  - No exponent notation, no `NaN`, no negative values

## Features

- Stream-based CSV parsing (doesn't load entire file into memory)
- Proper handling of quoted fields with embedded commas and newlines
- Exact decimal arithmetic using Python's `decimal` module
- UTF-8 encoding support
- Sorted output by category key

## Testing

Run tests with:
```bash
python -m unittest test_solution.py
```

Or use the project's test runner:
```bash
run_tests
```
