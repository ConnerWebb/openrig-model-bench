"""
CSV aggregator: reads UTF-8 CSV, validates header, accumulates amounts by category.
"""
import csv
import re
from decimal import Decimal, InvalidOperation
from io import StringIO


def aggregate(path: str) -> dict[str, str]:
    """
    Read UTF-8 CSV as a stream. Header must be exactly 'category,amount'.
    Accumulate amounts by category using exact decimal arithmetic.
    Return sorted dict with amounts formatted to 2 decimal places.
    """
    totals: dict[str, Decimal] = {}
    
    with open(path, 'r', encoding='utf-8', newline='') as f:
        # Read header line by line to validate
        reader = csv.reader(f)
        
        # Validate header
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("Empty file")
        
        if len(header) != 2:
            raise ValueError("Header must have exactly 2 fields")
        
        if header[0].strip() != 'category' or header[1].strip() != 'amount':
            raise ValueError("Header must be exactly 'category,amount'")
        
        # Process data rows
        for row in reader:
            # Skip completely blank records (empty or all whitespace)
            if not row or all(cell.strip() == '' for cell in row):
                continue
            
            # Every non-blank record must have exactly 2 fields
            if len(row) != 2:
                raise ValueError("Each record must have exactly 2 fields")
            
            category = row[0].strip()
            amount_str = row[1].strip()
            
            # Category must not be empty
            if not category:
                raise ValueError("Category must not be empty")
            
            # Validate amount format: optional +, 1-12 digits, optional decimal point with 1-2 digits
            amount_pattern = r'^\+?[0-9]{1,12}(\.[0-9]{1,2})?$'
            if not re.match(amount_pattern, amount_str):
                raise ValueError(f"Invalid amount format: {amount_str}")
            
            # Parse as Decimal for exact arithmetic
            try:
                amount = Decimal(amount_str)
            except InvalidOperation:
                raise ValueError(f"Invalid amount: {amount_str}")
            
            # Accumulate
            if category in totals:
                totals[category] += amount
            else:
                totals[category] = amount
    
    # Format results with exactly 2 decimal places, sorted by key
    result = {}
    for key in sorted(totals.keys()):
        result[key] = f"{totals[key]:.2f}"
    
    return result
