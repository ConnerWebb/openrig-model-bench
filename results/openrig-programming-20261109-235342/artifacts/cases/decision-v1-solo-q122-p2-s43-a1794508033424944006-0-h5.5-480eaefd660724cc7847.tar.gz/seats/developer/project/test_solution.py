"""
Unit tests for solution.py aggregate function.
"""
import unittest
import tempfile
from solution import aggregate


class TestAggregate(unittest.TestCase):
    
    def test_simple_csv(self):
        """Test basic CSV with simple categories and amounts."""
        csv_content = "category,amount\nfood,100.50\nrent,200.25\nfood,50.25\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'food': '150.75', 'rent': '200.25'})
    
    def test_quoted_fields_with_commas(self):
        """Test CSV with quoted fields containing commas."""
        csv_content = 'category,amount\n"a,b",100.00\n"c,d",200.00\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'a,b': '100.00', 'c,d': '200.00'})
    
    def test_quoted_fields_with_newlines(self):
        """Test CSV with quoted fields containing newlines."""
        csv_content = 'category,amount\n"line1\nline2",100.00\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'line1\nline2': '100.00'})
    
    def test_quoted_quotes(self):
        """Test CSV with escaped quotes (double quotes)."""
        csv_content = 'category,amount\n"x""quote",100.00\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'x"quote': '100.00'})
    
    def test_whitespace_stripping(self):
        """Test that whitespace is stripped from category and amount."""
        csv_content = "category,amount\n  food  ,  100.50  \n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'food': '100.50'})
    
    def test_blank_records_ignored(self):
        """Test that completely blank records are ignored."""
        csv_content = "category,amount\nfood,100.00\n\n\nrent,200.00\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
    
    def test_optional_plus_sign(self):
        """Test amount with optional plus sign."""
        csv_content = "category,amount\nfood,+100.50\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'food': '100.50'})
    
    def test_integer_amounts(self):
        """Test amounts without decimal points."""
        csv_content = "category,amount\nfood,100\nrent,200\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'food': '100.00', 'rent': '200.00'})
    
    def test_invalid_header_wrong_names(self):
        """Test that wrong header names raise ValueError."""
        csv_content = "wrong,amount\nfood,100\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_invalid_header_wrong_field_count(self):
        """Test that header with wrong field count raises ValueError."""
        csv_content = "category,amount,extra\nfood,100\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        csv_content = "category,amount\n,100\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_invalid_amount_nan(self):
        """Test that NaN amount raises ValueError."""
        csv_content = "category,amount\nfood,NaN\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_invalid_amount_exponent(self):
        """Test that exponent notation raises ValueError."""
        csv_content = "category,amount\nfood,1e2\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_invalid_amount_too_many_decimals(self):
        """Test that amount with more than 2 decimal places raises ValueError."""
        csv_content = "category,amount\nfood,100.123\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_invalid_amount_too_many_digits(self):
        """Test that amount with more than 12 digits raises ValueError."""
        csv_content = "category,amount\nfood,1234567890123\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_invalid_record_wrong_field_count(self):
        """Test that record with wrong field count raises ValueError."""
        csv_content = "category,amount\nfood,100,extra\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_unterminated_quote(self):
        """Test that unterminated quote raises ValueError."""
        csv_content = 'category,amount\n"unclosed,100\n'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            with self.assertRaises(ValueError):
                aggregate(f.name)
    
    def test_sorted_output(self):
        """Test that output is sorted by category key."""
        csv_content = "category,amount\nzebra,100\napple,200\nmango,300\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        keys = list(result.keys())
        self.assertEqual(keys, sorted(keys))
    
    def test_unicode_categories(self):
        """Test Unicode category names with ASCII commas."""
        # Build CSV content using explicit ASCII comma (0x2C)
        csv_content = "category,amount\n日本,100.50\n한국,200.25\n"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
            f.write(csv_content)
            f.flush()
            result = aggregate(f.name)
        self.assertEqual(result, {'日本': '100.50', '한국': '200.25'})


if __name__ == '__main__':
    unittest.main()
