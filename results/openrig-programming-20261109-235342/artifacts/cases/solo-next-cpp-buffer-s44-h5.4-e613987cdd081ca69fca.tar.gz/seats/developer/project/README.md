# Buffer Library

A C++20 RAII buffer class with deep-copy semantics, move semantics, bounds checking, and safe resizing.

## Features

- `Buffer(size_t n=0)`: Construct buffer of given size, zero-initialized
- `size() const noexcept`: Return current size
- `operator[](size_t)`: Mutable and const access with bounds-check throwing `std::out_of_range`
- `resize(size_t)`: Resize preserving prefix, zero-initializing new bytes
- Deep-copy construction/assignment
- Noexcept move construction/assignment
- Moved-from buffers have size 0 and are reusable
- Self-copy/self-move preserve content
- RAII, no leaks, double frees, stale reads or undefined behavior

## Usage

```cpp
#include "solution.hpp"

Buffer b(10);          // 10 zero-initialized bytes
b[0] = 42;             // modify first byte
Buffer c = b;          // deep copy
Buffer d = std::move(c); // move
c.resize(20);          // resize, preserve prefix, zero-fill new bytes
```

## Testing

Run `run_tests` to verify correctness with public cases, ASan, UBSan, and custom tests.
