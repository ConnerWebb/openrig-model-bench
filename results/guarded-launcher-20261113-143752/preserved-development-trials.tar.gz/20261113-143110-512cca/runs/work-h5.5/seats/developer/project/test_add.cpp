#include "solution.hpp"
#include <cassert>
#include <iostream>

int main() {
    // Basic positive cases
    assert(add(1, 2) == 3);
    assert(add(17, 25) == 42);
    assert(add(100, 200) == 300);

    // Zero cases
    assert(add(0, 0) == 0);
    assert(add(5, 0) == 5);
    assert(add(0, -3) == -3);

    // Negative cases
    assert(add(-2, 5) == 3);
    assert(add(-5, -3) == -8);
    assert(add(10, -10) == 0);

    std::cout << "All tests passed!" << std::endl;
    return 0;
}
