# Add Function Fix

## Problem
The `add` function in `solution.hpp` was incorrectly returning `a - b` instead of `a + b`.

## Solution
Changed the return statement from `return a - b;` to `return a + b;`.

## API
```cpp
#pragma once
inline int add(int a, int b) { return a + b; }
```

## Testing
Compile and run tests with:
```bash
clang++ -fuse-ld=bfd -std=c++20 -I/work test_add.cpp -o test_add
./test_add
```

The `check.py` script also validates the fix using public test cases.

## Files
- `solution.hpp`: The fixed implementation
- `test_add.cpp`: Standalone test file with assertions
- `check.py`: Public verification script
