# Calc Module

## Fix Applied
The `add(a, b)` function in `calc.py` was corrected to return `a + b` instead of `a - b`.

### Before:
```python
def add(a,b):
    return a-b
```

### After:
```python
def add(a,b):
    return a+b
```

## API
- `add(a: int, b: int) -> int`: Returns the sum of two integers.

## Testing
Run `run_tests` to execute the public test suite and verify the fix.

## Tests
The module includes `unittest` tests in `test_calc.py`:
- `test_sum`: Verifies `add(17, 25) == 42`
- `test_negative`: Verifies `add(-2, 5) == 3`
