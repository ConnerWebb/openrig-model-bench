# Calc Module

## Fix Applied
The `add(a, b)` function in `calc.py` was corrected to return `a + b` instead of `a - b`.

### Before:
```python
def add(a, b):
    return a - b  # Incorrect
```

### After:
```python
def add(a, b):
    return a + b  # Correct
```

## API
- `add(a: int, b: int) -> int`: Returns the sum of two integers.

## Testing
Run `run_tests` to execute the public checks and any additional tests.

## Tests
- `test_sum`: Verifies `add(17, 25) == 42`
- `test_negative`: Verifies `add(-2, 5) == 3`
