#include <iostream>
#include "solution.hpp"

int main() {
    // Test basic addition
    if (add(2, 3) != 5) {
        std::cerr << "FAIL: add(2, 3) != 5\n";
        return 1;
    }
    if (add(0, 0) != 0) {
        std::cerr << "FAIL: add(0, 0) != 0\n";
        return 1;
    }
    if (add(-1, 1) != 0) {
        std::cerr << "FAIL: add(-1, 1) != 0\n";
        return 1;
    }
    if (add(-5, -3) != -8) {
        std::cerr << "FAIL: add(-5, -3) != -8\n";
        return 1;
    }
    if (add(100, 200) != 300) {
        std::cerr << "FAIL: add(100, 200) != 300\n";
        return 1;
    }
    std::cout << "All tests passed.\n";
    return 0;
}
