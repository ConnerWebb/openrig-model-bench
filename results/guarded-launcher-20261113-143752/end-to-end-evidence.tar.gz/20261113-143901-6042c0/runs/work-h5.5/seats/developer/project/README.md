# Fix for add(int, int) in solution.hpp

## Problem
The `add` function in `solution.hpp` was incorrectly returning `a - b` instead of `a + b`.

## Solution
Changed the return statement from `return a - b;` to `return a + b;`.

## API
The function signature remains unchanged:
```cpp
inline int add(int a, int b);
```

## Building and Testing
Compile the standalone test with:
```bash
clang++ -fuse-ld=bfd -std=c++20 test_add.cpp -o test_add
./test_add
```

All assertions in `test_add.cpp` verify correct addition behavior including:
- Positive integers
- Zero
- Negative integers
- Mixed signs
