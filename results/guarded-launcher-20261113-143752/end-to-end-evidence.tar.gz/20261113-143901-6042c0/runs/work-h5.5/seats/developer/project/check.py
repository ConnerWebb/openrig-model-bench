import pathlib,tempfile,subprocess
with tempfile.TemporaryDirectory() as d:
 p=pathlib.Path(d);(p/'check.cpp').write_text('#include "solution.hpp"\n#include <cassert>\nint main(){assert(add(17,25)==42);assert(add(-2,5)==3);assert(add(0,0)==0);}')
 subprocess.run(['clang++','-fuse-ld=bfd','-std=c++20','-I/work',str(p/'check.cpp'),'-o',str(p/'check')],check=True)
 subprocess.run([str(p/'check')],check=True)
