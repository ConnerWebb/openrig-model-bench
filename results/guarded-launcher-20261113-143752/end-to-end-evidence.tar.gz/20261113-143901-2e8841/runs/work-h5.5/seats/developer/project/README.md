# Calc Module Fix

## Issue
The `add(a, b)` function in `calc.py` was incorrectly returning `a - b` instead of `a + b`.

## Fix
Changed the return statement from `return a - b` to `return a + b`.

## API
The function signature remains unchanged:
```python
def add(a, b):
    """Return the sum of a and b."""
    return a + b
```

## Testing
Run `run_tests` to execute the public checks and any additional tests added.

## Tests
- `test_sum`: Verifies `add(17, 25) == 42`
- `test_negative`: Verifies `add(-2, 5) == 3`
