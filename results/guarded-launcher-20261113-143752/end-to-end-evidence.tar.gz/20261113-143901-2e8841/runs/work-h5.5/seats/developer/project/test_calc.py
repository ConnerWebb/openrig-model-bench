import unittest
from calc import add
class Addition(unittest.TestCase):
 def test_sum(self):self.assertEqual(add(17,25),42)
 def test_negative(self):self.assertEqual(add(-2,5),3)
